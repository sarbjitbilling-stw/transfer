
package sbpackage.api.osgi.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.HashMap;
import java.util.Map;


@XmlRootElement(name = "Analytics")
@XmlAccessorType(XmlAccessType.FIELD)
public class AnalyticsSummary {

    @XmlElement(name = "analyticsMap")
    private Map<String, String> analyticsMap = new HashMap<>();


    public Map<String, String> getAnalyticsMap() {
        return analyticsMap;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("analyticsMap", analyticsMap)
                .toString();
    }
}
