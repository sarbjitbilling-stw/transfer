package sbpackage.api.osgi.model.transaction;


import java.util.List;

public class EventDTO {

	private List<AccountEvent> accountList;
	private List<ContactEvent> remindersList;
	private ContactRecord contactRecordsList;
	private List<ActivePaymentPlan> activePaymentPlanList;
	private PaymentPlanDetails paymentPlanDetails;
	private List<PaymentPlanInstallments> paymentPlanInstallmentsList;       

	public List<PaymentPlanInstallments> getPaymentPlanInstallmentsList() {
		return paymentPlanInstallmentsList;
	}

	public void setPaymentPlanInstallmentsList(List<PaymentPlanInstallments> paymentPlanInstallmentsList) {
		this.paymentPlanInstallmentsList = paymentPlanInstallmentsList;
	}

	public List<ActivePaymentPlan> getActivePaymentPlanList() {
		return activePaymentPlanList;
	}

	public void setActivePaymentPlanList(List<ActivePaymentPlan> activePaymentPlanList) {
		this.activePaymentPlanList = activePaymentPlanList;
	}

	public PaymentPlanDetails getPaymentPlanDetails() {
		return paymentPlanDetails;
	}

	public void setPaymentPlanDetails(PaymentPlanDetails paymentPlanDetails) {
		this.paymentPlanDetails = paymentPlanDetails;
	}

	public ContactRecord getContactRecordsList() {
		return contactRecordsList;
	}

	public void setContactRecordsList(ContactRecord contactRecordsList) {
		this.contactRecordsList = contactRecordsList;
	}

	private String paginationKey;

	public List<AccountEvent> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<AccountEvent> accountList) {
		this.accountList = accountList;
	}

	public List<ContactEvent> getRemindersList() {
		return remindersList;
	}

	public void setRemindersList(List<ContactEvent> remindersList) {
		this.remindersList = remindersList;
	}

	public String getPaginationKey() {
		return paginationKey;
	}

	public void setPaginationKey(String paginationKey) {
		this.paginationKey = paginationKey;
	}
}
