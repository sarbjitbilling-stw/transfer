package sbpackage.api.osgi.model.chor;

import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.AccountBrand;
import sbpackage.api.osgi.model.Address;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

/**
 * Created by tellis3 on 25/04/2017.
 */
@XmlType
@XmlRootElement(name = "MoveRequestDetail")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MoveRequestDetail {

    //May need to change this address class
    @XmlElement(name = "address")
    private Address address;

    @XmlElement(name = "date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate date;

    @XmlElement(name = "meterReadings")
    private List<ChorMeterRead> meterReadings;

    private AccountBrand propertyBrand;

    public MoveRequestDetail(Address address,
                             LocalDate date,
                             List<ChorMeterRead> meterReadings){

        this.address = address;
        this.date = date;
        this.meterReadings = meterReadings;

    }

    public MoveRequestDetail(){

    }

    public boolean isMeasured(){
        return getMeterReadings() != null && getMeterReadings().size() > 0; //note, size > 0 even if readings are estimates
    }

    public boolean isFuture(){
        return date.isAfter(LocalDate.now());
    }

    public Address getAddress() {
        return address;
    }

    public LocalDate getDate() {
        return date;
    }

    public List<ChorMeterRead> getMeterReadings() {
        return meterReadings;
    }

    public AccountBrand getPropertyBrand() {
		return propertyBrand;
	}

	public void setPropertyBrand(AccountBrand propertyBrand) {
		this.propertyBrand = propertyBrand;
	}

	@Override
    public String toString() {
        return "MoveRequestDetail{" +
                "address=" + address +
                ", date=" + date +
                ", meterReadings=" + meterReadings +
                '}';
    }
}
