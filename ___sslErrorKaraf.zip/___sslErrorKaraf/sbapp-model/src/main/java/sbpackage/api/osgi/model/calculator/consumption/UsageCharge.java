package sbpackage.api.osgi.model.calculator.consumption;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * Created by rtai on 18/07/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class UsageCharge {

	@XmlElement
	private String usageLevel;

	@XmlElement
	private BigDecimal monthlyCost;

	@XmlElement
	private BigDecimal annualCost;

    @XmlElement
    private BigDecimal monthlySaving;

    @XmlElement
    private BigDecimal annualSaving;
}
