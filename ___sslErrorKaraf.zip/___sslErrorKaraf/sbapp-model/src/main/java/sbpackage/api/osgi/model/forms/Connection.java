package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.collections.CollectionUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Connection {
    private AccountNumber accountNumber;
    private AccountNumberMandatory accountNumberMandatory;
    private Selection billedViaAMeter;
    private BillingAddress billingAddress;
    private Selection domesticCommercial;
    private EstimatedWaterUsage estimatedWaterUsage;
    private PeakFlowRate peakFlowRate;
    private AverageDailyUsage averageDailyUsage;
    private FireFightingRequirementsSelection fireFightingRequirements;
    private FireSprinklerBranch fireSprinklerBranch;
    private FireSprinklerYes fireSprinklerYes;
    private FireSupplyBranch fireSupplyBranch;
    private Fittings fittings;
    private Fittings sewerageFittings;
    private Fittings fittingsFedFromStorage;
    private StorageTankForFittings storageTankForFittings;
    private FlowRateHydrant flowRateHydrant;
    private HotWaterSupply hotWaterSupply;
    private FloorsInBuilding floorsInBuilding;
    private PeopleInBuilding peopleInBuilding;
    private Selection elevationOfProperty;
    private Selection partGRegulations;
    private Selection paymentSchemeQuery;
    private PulsedWaterMeter pulsedWaterMeter;
    private PurposeOfTheProperty purposeOfTheProperty;
    private ReasonForConnection reasonForConnectionGreen;
    private ReasonForConnection reasonForConnectionNonGreen;
    private Retailer retailer;
    private TotalSurfaceArea totalSurfaceArea;
    private Selection typeOfProperty;
    private Selection wasteConnection;
    private Selection wasteContent;
    private WasteLocation wasteLocation;
    private Selection wasteMethod;
    private SelectionArray wastePipeNew;
    private SelectionArray wastePipeExisting;
    private WasteDemarcationChamber wasteDemarcationChamber;
    private SurfaceConnectionsList surfaceConnectionsList;
    private WaterWasteConnection waterWasteConnection;
    private Selection waterConnectionDischarge;
    private Selection existingWaterConnection;
    private Selection retainExistingWaterConnection;

    private static final String DOMESTIC_VALUE = "domestic";
    private static final String COMMERCIAL_VALUE = "commercial";
    private static final String SHARED_SEPARATION = "separation";
    private static final String FIRE_SPRINKLER = "fire_sprinkler";

    private final Set<String> DEFAULT_COMMERCIAL_NON_PROPERTY_TYPES = new HashSet<>(Arrays.asList(
            "agricultural",
            "temporary",
            "fountain"
    ));

    private final Set<String> DEFAULT_DOMESTIC_NON_PROPERTY_TYPES = new HashSet<>(Arrays.asList(
            "fire_sprinkler"
    ));

    public boolean isDomestic() {
        return  isDomesticByDefault() ||
                (domesticCommercial != null &&
                        DOMESTIC_VALUE.equals(domesticCommercial.getSelectedOption()) &&
                        !isSharedSeparation());
    }

    public boolean isLarge() {
        return fittings != null && fittings.isRequiresLargePipe();
    }

    public boolean hasHydrantFlowRateGreaterThan(float min) {
        return flowRateHydrant != null && flowRateHydrant.getFlowRate() > min;
    }

    public boolean hasFireSprinklerFlowRateGreaterThan(float min) {
        return fireSprinklerBranch != null && fireSprinklerBranch.isRequired() &&
                fireSprinklerYes != null && fireSprinklerYes.getFlowRate() > min;
    }

    public boolean isSharedSeparation() {
        return SHARED_SEPARATION.equals(getReasonForConnection().getSelectedOption());
    }

    public boolean isCommercial() {
        return isCommercialByDefault() ||
                (domesticCommercial != null &&
                        COMMERCIAL_VALUE.equals(domesticCommercial.getSelectedOption()) &&
                        !isSharedSeparation());
    }

    public boolean isFireHydrant() {
        return getReasonForConnection() != null &&
                FIRE_SPRINKLER.equals(getReasonForConnection().getSelectedNonPropertyOption());
    }

    public boolean hasConnectedToWasteOptions() {
        return waterWasteConnection != null &&
                CollectionUtils.isNotEmpty(waterWasteConnection.getConnectedToWasteOptions());
    }

    public AccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(AccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public AccountNumberMandatory getAccountNumberMandatory() {
        return accountNumberMandatory;
    }

    public void setAccountNumberMandatory(AccountNumberMandatory accountNumberMandatory) {
        this.accountNumberMandatory = accountNumberMandatory;
    }

    public Selection getBilledViaAMeter() {
        return billedViaAMeter;
    }

    public void setBilledViaAMeter(Selection billedViaAMeter) {
        this.billedViaAMeter = billedViaAMeter;
    }

    private boolean isDomesticByDefault() {
        return DEFAULT_DOMESTIC_NON_PROPERTY_TYPES.contains(getReasonForConnection().getSelectedNonPropertyOption());
    }

    private boolean isCommercialByDefault() {
        return DEFAULT_COMMERCIAL_NON_PROPERTY_TYPES.contains(getReasonForConnection().getSelectedNonPropertyOption());
    }

    private ReasonForConnection getReasonForConnection() {
        return reasonForConnectionGreen != null ? reasonForConnectionGreen : reasonForConnectionNonGreen;
    }

    public SelectionArray getWastePipeNew() {
        return wastePipeNew;
    }

    public void setWastePipeNew(SelectionArray wastePipeNew) {
        this.wastePipeNew = wastePipeNew;
    }

    public SelectionArray getWastePipeExisting() {
        return wastePipeExisting;
    }

    public void setWastePipeExisting(SelectionArray wastePipeExisting) {
        this.wastePipeExisting = wastePipeExisting;
    }

    public WasteDemarcationChamber getWasteDemarcationChamber() {
        return wasteDemarcationChamber;
    }

    public void setWasteDemarcationChamber(WasteDemarcationChamber wasteDemarcationChamber) {
        this.wasteDemarcationChamber = wasteDemarcationChamber;
    }

    public Selection getDomesticCommercial() {
        return domesticCommercial;
    }

    public void setDomesticCommercial(Selection domesticCommercial) {
        this.domesticCommercial = domesticCommercial;
    }

    public EstimatedWaterUsage getEstimatedWaterUsage() {
        return estimatedWaterUsage;
    }

    public void setEstimatedWaterUsage(EstimatedWaterUsage estimatedWaterUsage) {
        this.estimatedWaterUsage = estimatedWaterUsage;
    }

    public FireFightingRequirementsSelection getFireFightingRequirements() {
        return fireFightingRequirements;
    }

    public void setFireFightingRequirements(FireFightingRequirementsSelection fireFightingRequirements) {
        this.fireFightingRequirements = fireFightingRequirements;
    }

    public FireSprinklerBranch getFireSprinklerBranch() {
        return fireSprinklerBranch;
    }

    public void setFireSprinklerBranch(FireSprinklerBranch fireSprinklerBranch) {
        this.fireSprinklerBranch = fireSprinklerBranch;
    }

    public FireSprinklerYes getFireSprinklerYes() {
        return fireSprinklerYes;
    }

    public void setFireSprinklerYes(FireSprinklerYes fireSprinklerYes) {
        this.fireSprinklerYes = fireSprinklerYes;
    }

    public FireSupplyBranch getFireSupplyBranch() {
        return fireSupplyBranch;
    }

    public void setFireSupplyBranch(FireSupplyBranch fireSupplyBranch) {
        this.fireSupplyBranch = fireSupplyBranch;
    }

    public Fittings getFittings() {
        return fittings;
    }

    public void setFittings(Fittings fittings) {
        this.fittings = fittings;
    }

    public FlowRateHydrant getFlowRateHydrant() {
        return flowRateHydrant;
    }

    public void setFlowRateHydrant(FlowRateHydrant flowRateHydrant) {
        this.flowRateHydrant = flowRateHydrant;
    }

    public HotWaterSupply getHotWaterSupply() {
        return hotWaterSupply;
    }

    public void setHotWaterSupply(HotWaterSupply hotWaterSupply) {
        this.hotWaterSupply = hotWaterSupply;
    }

    public Selection getPartGRegulations() {
        return partGRegulations;
    }

    public void setPartGRegulations(Selection partGRegulations) {
        this.partGRegulations = partGRegulations;
    }

    public Selection getPaymentSchemeQuery() {
        return paymentSchemeQuery;
    }

    public void setPaymentSchemeQuery(Selection paymentSchemeQuery) {
        this.paymentSchemeQuery = paymentSchemeQuery;
    }

    public PulsedWaterMeter getPulsedWaterMeter() {
        return pulsedWaterMeter;
    }

    public void setPulsedWaterMeter(PulsedWaterMeter pulsedWaterMeter) {
        this.pulsedWaterMeter = pulsedWaterMeter;
    }

    public PurposeOfTheProperty getPurposeOfTheProperty() {
        return purposeOfTheProperty;
    }

    public void setPurposeOfTheProperty(PurposeOfTheProperty purposeOfTheProperty) {
        this.purposeOfTheProperty = purposeOfTheProperty;
    }

    public ReasonForConnection getReasonForConnectionGreen() {
        return reasonForConnectionGreen;
    }

    public void setReasonForConnectionGreen(ReasonForConnection reasonForConnectionGreen) {
        this.reasonForConnectionGreen = reasonForConnectionGreen;
    }

    public ReasonForConnection getReasonForConnectionNonGreen() {
        return reasonForConnectionNonGreen;
    }

    public void setReasonForConnectionNonGreen(ReasonForConnection reasonForConnectionNonGreen) {
        this.reasonForConnectionNonGreen = reasonForConnectionNonGreen;
    }

    public Retailer getRetailer() {
        return retailer;
    }

    public void setRetailer(Retailer retailer) {
        this.retailer = retailer;
    }

    public TotalSurfaceArea getTotalSurfaceArea() {
        return totalSurfaceArea;
    }

    public void setTotalSurfaceArea(TotalSurfaceArea totalSurfaceArea) {
        this.totalSurfaceArea = totalSurfaceArea;
    }

    public Selection getTypeOfProperty() {
        return typeOfProperty;
    }

    public void setTypeOfProperty(Selection typeOfProperty) {
        this.typeOfProperty = typeOfProperty;
    }

    public Selection getWasteConnection() {
        return wasteConnection;
    }

    public void setWasteConnection(Selection wasteConnection) {
        this.wasteConnection = wasteConnection;
    }

    public Selection getWasteContent() {
        return wasteContent;
    }

    public void setWasteContent(Selection wasteContent) {
        this.wasteContent = wasteContent;
    }

    public WasteLocation getWasteLocation() {
        return wasteLocation;
    }

    public void setWasteLocation(WasteLocation wasteLocation) {
        this.wasteLocation = wasteLocation;
    }

    public Selection getWasteMethod() {
        return wasteMethod;
    }

    public void setWasteMethod(Selection wasteMethod) {
        this.wasteMethod = wasteMethod;
    }

    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    public Fittings getSewerageFittings() {
        return sewerageFittings;
    }

    public void setSewerageFittings(Fittings sewerageFittings) {
        this.sewerageFittings = sewerageFittings;
    }

    public SurfaceConnectionsList getSurfaceConnectionsList() {
        return surfaceConnectionsList;
    }

    public void setSurfaceConnectionsList(SurfaceConnectionsList surfaceConnectionsList) {
        this.surfaceConnectionsList = surfaceConnectionsList;
    }

    public WaterWasteConnection getWaterWasteConnection() {
        return waterWasteConnection;
    }

    public void setWaterWasteConnection(WaterWasteConnection waterWasteConnection) {
        this.waterWasteConnection = waterWasteConnection;
    }

    public Selection getWaterConnectionDischarge() {
        return waterConnectionDischarge;
    }

    public void setWaterConnectionDischarge(Selection waterConnectionDischarge) {
        this.waterConnectionDischarge = waterConnectionDischarge;
    }

	public Selection getExistingWaterConnection() {
		return existingWaterConnection;
	}

	public void setExistingWaterConnection(Selection existingWaterConnection) {
		this.existingWaterConnection = existingWaterConnection;
	}

	public Selection getRetainExistingWaterConnection() {
		return retainExistingWaterConnection;
	}

	public void setRetainExistingWaterConnection(Selection retainExistingWaterConnection) {
		this.retainExistingWaterConnection = retainExistingWaterConnection;
	}

    public PeakFlowRate getPeakFlowRate() {
        return peakFlowRate;
    }

    public void setPeakFlowRate(PeakFlowRate peakFlowRate) {
        this.peakFlowRate = peakFlowRate;
    }

    public AverageDailyUsage getAverageDailyUsage() {
        return averageDailyUsage;
    }

    public void setAverageDailyUsage(AverageDailyUsage averageDailyUsage) {
        this.averageDailyUsage = averageDailyUsage;
    }

    public FloorsInBuilding getFloorsInBuilding() {
        return floorsInBuilding;
    }

    public void setFloorsInBuilding(FloorsInBuilding floorsInBuilding) {
        this.floorsInBuilding = floorsInBuilding;
    }

    public Selection getElevationOfProperty() {
        return elevationOfProperty;
    }

    public void setElevationOfProperty(Selection elevationOfProperty) {
        this.elevationOfProperty = elevationOfProperty;
    }

    public PeopleInBuilding getPeopleInBuilding() {
        return peopleInBuilding;
    }

    public void setPeopleInBuilding(PeopleInBuilding peopleInBuilding) {
        this.peopleInBuilding = peopleInBuilding;
    }

    public Fittings getFittingsFedFromStorage() {
        return fittingsFedFromStorage;
    }

    public void setFittingsFedFromStorage(Fittings fittingsFedFromStorage) {
        this.fittingsFedFromStorage = fittingsFedFromStorage;
    }

    public StorageTankForFittings getStorageTankForFittings() {
        return storageTankForFittings;
    }

    public void setStorageTankForFittings(StorageTankForFittings storageTankForFittings) {
        this.storageTankForFittings = storageTankForFittings;
    }
}
