package sbpackage.api.osgi.model.inmyarea;

import java.util.List;

@lombok.Data
public class ActivityQueueRequest {
    private ActivityQueueType aqType;
    private IncidentAddress address;
    private List<Data> data;
}
