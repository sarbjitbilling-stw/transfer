package sbpackage.api.osgi.model.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * @deprecated
 * @see LocalDateAdapter
 */
public class DateAdapter extends XmlAdapter<String,LocalDate> {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    @Override
    public LocalDate unmarshal(String v) throws Exception {
        LocalDate date = LocalDate.parse(v, formatter);
        return date;
    }

    @Override
    public String marshal(LocalDate v) throws Exception {
        return v.format(formatter);
    }
}
