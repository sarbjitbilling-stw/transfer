package sbpackage.api.osgi.model.referencedata;

/**
 * ContactType encapsulates the ref data value sets from Target. <br/>
 * <br/>
 */
public enum ContactType {

    BILLING_CONTACT("3", "Billing Contact"), CREDIT_MAN("5", "Credit Man"),
    DATA_INTEGRITY_TEAM("74", "Data Integrity Team"), DEBEO_DEBT_RECOVERY("37", "Debeo Debt Recovery"),
    EMAIL_CASE_MANAGEMENT("81", "Email Case Management"), ENFORCEMENTS("53", "Enforcements"), INFO("7", "Info"),
    INTERNAL("21", "Internal"), LANDLORD_PORTAL("86", "Landlord Portal"), OPERATIONS_CONTACT("9", "Operations Contact"),
    PAYMENT_ASSISTANCE_TEAM("85", "Payment Assistance Team"), PYMNT_TRACES("10", "Payment Traces"),
    REFUNDS("69", "Refunds"), SC_NEW_SUPPLIES("26", "SC New Supplies"), SALES("11", "Sales"), TARIFF("87", "Tariff"),
    THIRD_PARTY_CONTACT("80", "Third Party Contact"), VISITS("12", "Visits"),
    VOICE_OF_CUSTOMER("VOC", "Voice Of Customer"), WRITE_OFF("39", "Write Off");


    private String value;
    private String code;

    /**
     * 
     * @param code  - id for retrieval
     * @param value - display name
     */
    ContactType(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public String getCode() {
        return code;
    }

    public static ContactType fromValue(String value) {
        for (ContactType contactType : values()) {
            if (contactType.value.equalsIgnoreCase(value)) {
                return contactType;
            }
        }
        throw new IllegalArgumentException(String.format("No ContactType found for %s", value));
    }

    @Override
    public String toString() {
        return fromValue(value).name();
    }
}
