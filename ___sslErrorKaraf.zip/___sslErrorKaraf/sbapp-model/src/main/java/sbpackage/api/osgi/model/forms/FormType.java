package sbpackage.api.osgi.model.forms;

import java.util.HashMap;
import java.util.Map;

public enum FormType {
    SCWATER,
    SCWASTE,
    SCCOMBINED,
    DEWATER,
    DEWASTE,
    DECOMBINED,
    DVWATER,
    DVWASTE,
    POC,
    WATER_MAIN_REQUISITION,
    ADOPTION_OF_NEW_SEWER,
    ADOPTION_OF_EXISTING_SEWER,
    SEWER_REQUISITION,
    NAVWATER,
    NAVWASTE,
    NAVCOMBINED;


    private static final Map<String, FormType> nameIndex = new HashMap<>();

    static {
        for (FormType formType : FormType.values()) {
            nameIndex.put(formType.name(), formType);
        }
    }

    public static FormType lookupByName(String name) {
        return name == null ? null : nameIndex.get(name.toUpperCase());
    }
}
