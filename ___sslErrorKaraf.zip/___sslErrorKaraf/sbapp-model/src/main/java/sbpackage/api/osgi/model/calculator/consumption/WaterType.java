/**
 * 
 */
package sbpackage.api.osgi.model.calculator.consumption;

public enum WaterType {

	USED, FRESH
}
