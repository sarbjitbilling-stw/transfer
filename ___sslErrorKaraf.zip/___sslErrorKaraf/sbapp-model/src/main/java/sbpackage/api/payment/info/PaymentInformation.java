package sbpackage.api.payment.info;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import sbpackage.api.osgi.model.common.HypermediaDto;
import sbpackage.api.osgi.model.payment.cardpayment.AccountInfo;
import sbpackage.api.osgi.model.payment.rules.PaymentRange;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentInformation extends HypermediaDto{

    
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("id")
    private String id;
    
    @JsonProperty("accountInfo")
    private AccountInfo accountInfo;

    @JsonProperty("paymentAmount")
    private BigDecimal paymentAmount;

    @JsonProperty("paymentRange")
    private PaymentRange paymentRange;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public AccountInfo getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public PaymentRange getPaymentRange() {
        return paymentRange;
    }

    public void setPaymentRange(PaymentRange paymentRange) {
        this.paymentRange = paymentRange;
    }
    
}
