package sbpackage.api.osgi.model.probate;

import java.util.Arrays;

public enum CallerType {
    EXISTING_PRIMARY("P", "Existing Primary"),
    EXISTING_CO_PRIMARY("CP", "Existing Co-primary"),
    NEW_PRIMARY("New_P", "New Primary"),
    NEW_CO_PRIMARY("New_CP", "New Co-primary"),
    EXECUTOR("EXECUTOR", "Executor");

    private final String code;
    private final String description;

    CallerType(final String code, final String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static CallerType findByCode(final String code) {
        return Arrays.stream(CallerType.values()).filter(item -> item.code.equalsIgnoreCase(code)).findFirst().orElse(null);
    }
}
