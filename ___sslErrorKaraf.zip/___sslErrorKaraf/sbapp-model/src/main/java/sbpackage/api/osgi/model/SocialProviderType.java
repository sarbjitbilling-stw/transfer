package sbpackage.api.osgi.model;

public enum SocialProviderType {
    GOOGLE, FACEBOOK, APPLE
}
