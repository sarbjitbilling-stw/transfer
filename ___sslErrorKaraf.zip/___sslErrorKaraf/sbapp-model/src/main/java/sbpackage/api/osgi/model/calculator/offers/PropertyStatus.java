package sbpackage.api.osgi.model.calculator.offers;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum PropertyStatus {
    ACTIVE("A"),
    IN_ACTIVE("I");

    private static final Map<String, PropertyStatus> statusCodeIndex = buildStatusCodeIndex();

    private static final Map<String, PropertyStatus> buildStatusCodeIndex() {
        Map<String, PropertyStatus> index = new HashMap<>();
        for (PropertyStatus measureIndicator : PropertyStatus.values()) {
            index.put(measureIndicator.getStatus().toUpperCase(), measureIndicator);
        }
        return Collections.unmodifiableMap(index);
    }

    private final String status;

    PropertyStatus(String status){
        this.status = status;
    }

    public String getStatus(){
        return this.status;
    }

    public static Optional<PropertyStatus> fromStatusCode(String statusCode) {
        String standardisedStatusCode = statusCode != null ? statusCode.toUpperCase() : statusCode;
        return Optional.ofNullable(statusCodeIndex.get(standardisedStatusCode));
    }

}
