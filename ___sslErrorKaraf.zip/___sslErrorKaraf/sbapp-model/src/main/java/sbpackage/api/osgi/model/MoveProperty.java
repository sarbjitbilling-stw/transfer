package sbpackage.api.osgi.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "MoveProperty")
@XmlAccessorType(XmlAccessType.FIELD)
public class MoveProperty implements Serializable {

	private static final long serialVersionUID = 8114839881917876215L;

	private boolean discloseMoveToAddress;

	private boolean movingAbroad;

	private Move moveFrom;

	private Move moveTo;

	private ProcessOutcomeList outcome;

	public boolean isDiscloseMoveToAddress() {
		return discloseMoveToAddress;
	}

	public void setDiscloseMoveToAddress(boolean discloseMoveToAddress) {
		this.discloseMoveToAddress = discloseMoveToAddress;
	}

    public boolean isMovingAbroad() {
		return movingAbroad;
	}

	public void setMovingAbroad(boolean movingAbroad) {
		this.movingAbroad = movingAbroad;
	}

	public Move getMoveFrom() {
		return moveFrom;
	}

	public void setMoveFrom(Move moveFrom) {
		this.moveFrom = moveFrom;
	}

	public Move getMoveTo() {
		return moveTo;
	}

	public void setMoveTo(Move moveTo) {
		this.moveTo = moveTo;
	}

	public ProcessOutcomeList getOutcome() {
		return outcome;
	}

	public void setOutcome(ProcessOutcomeList outComeList) {
		this.outcome = outComeList;
	}

	@Override
	public String toString() {
		return "MoveProperty [discloseMoveToAddress=" + discloseMoveToAddress + ", movingAbroad=" + movingAbroad
				+ ", moveFrom=" + moveFrom + ", moveTo=" + moveTo + "]";
	}

}
