package sbpackage.api.osgi.model.payment;

public enum PaymentPlanWarning {
    DIRECT_DEBIT_WARNING,
    GENERAL_TARGET_WARNING;

    PaymentPlanWarning() {
    }
}
