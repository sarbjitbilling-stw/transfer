package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement(name = "SystemPolicyDetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class SystemPolicyResponse implements Serializable {

    @XmlElement(name = "systempolicy")
    private String systempolicy;
    @XmlElement(name = "policyVariable")
    private String policyVariable;
    @XmlElement(name = "policyDescription")
	private String policyDescription;
    @XmlElement(name = "policyVariableText")
    private String policyVariableText;
    @XmlElement(name = "policyOption")
    private String policyOption;
    @XmlElement(name = "optionVariable")
    private String optionVariable;
    @XmlElement(name = "optionDescription")
    private String optionDescription;
    @XmlElement(name = "optionVariableText")
    private String optionVariableText;
    @XmlElement(name = "policyGroup")
    private String policyGroup;
	
	public String getSystempolicy() {
		return systempolicy;
	}
	public void setSystempolicy(String systempolicy) {
		this.systempolicy = systempolicy;
	}
	public String getPolicyVariable() {
		return policyVariable;
	}
	public void setPolicyVariable(String policyVariable) {
		this.policyVariable = policyVariable;
	}
	public String getPolicyDescription() {
		return policyDescription;
	}
	public void setPolicyDescription(String policyDescription) {
		this.policyDescription = policyDescription;
	}
	public String getPolicyVariableText() {
		return policyVariableText;
	}
	public void setPolicyVariableText(String policyVariableText) {
		this.policyVariableText = policyVariableText;
	}
	public String getPolicyOption() {
		return policyOption;
	}
	public void setPolicyOption(String policyOption) {
		this.policyOption = policyOption;
	}
	public String getOptionVariable() {
		return optionVariable;
	}
	public void setOptionVariable(String optionVariable) {
		this.optionVariable = optionVariable;
	}
	public String getOptionDescription() {
		return optionDescription;
	}
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	public String getOptionVariableText() {
		return optionVariableText;
	}
	public void setOptionVariableText(String optionVariableText) {
		this.optionVariableText = optionVariableText;
	}
	public String getPolicyGroup() {
		return policyGroup;
	}
	public void setPolicyGroup(String policyGroup) {
		this.policyGroup = policyGroup;
	}
	@Override
	public String toString() {
		return "SystemPolicyResponse [systempolicy=" + systempolicy
				+ ", policyVariable=" + policyVariable + ", policyDescription=" + policyDescription
				+ ", policyVariableText=" + policyVariableText + ", policyOption=" + policyOption + ", optionVariable="
				+ optionVariable + ", optionDescription=" + optionDescription + ", optionVariableText="
				+ optionVariableText + ", policyGroup=" + policyGroup + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((optionDescription == null) ? 0 : optionDescription.hashCode());
		result = prime * result + ((optionVariable == null) ? 0 : optionVariable.hashCode());
		result = prime * result + ((optionVariableText == null) ? 0 : optionVariableText.hashCode());
		result = prime * result + ((policyDescription == null) ? 0 : policyDescription.hashCode());
		result = prime * result + ((policyGroup == null) ? 0 : policyGroup.hashCode());
		result = prime * result + ((policyOption == null) ? 0 : policyOption.hashCode());
		result = prime * result + ((policyVariable == null) ? 0 : policyVariable.hashCode());
		result = prime * result + ((policyVariableText == null) ? 0 : policyVariableText.hashCode());
		result = prime * result + ((systempolicy == null) ? 0 : systempolicy.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SystemPolicyResponse other = (SystemPolicyResponse) obj;
		if (optionDescription == null) {
			if (other.optionDescription != null)
				return false;
		} else if (!optionDescription.equals(other.optionDescription))
			return false;
		if (optionVariable == null) {
			if (other.optionVariable != null)
				return false;
		} else if (!optionVariable.equals(other.optionVariable))
			return false;
		if (optionVariableText == null) {
			if (other.optionVariableText != null)
				return false;
		} else if (!optionVariableText.equals(other.optionVariableText))
			return false;
		if (policyDescription == null) {
			if (other.policyDescription != null)
				return false;
		} else if (!policyDescription.equals(other.policyDescription))
			return false;
		if (policyGroup == null) {
			if (other.policyGroup != null)
				return false;
		} else if (!policyGroup.equals(other.policyGroup))
			return false;
		if (policyOption == null) {
			if (other.policyOption != null)
				return false;
		} else if (!policyOption.equals(other.policyOption))
			return false;
		if (policyVariable == null) {
			if (other.policyVariable != null)
				return false;
		} else if (!policyVariable.equals(other.policyVariable))
			return false;
		if (policyVariableText == null) {
			if (other.policyVariableText != null)
				return false;
		} else if (!policyVariableText.equals(other.policyVariableText))
			return false;
		
		if (systempolicy == null) {
			if (other.systempolicy != null)
				return false;
		} else if (!systempolicy.equals(other.systempolicy))
			return false;
		return true;
	}
	
}
