package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.DateAdapter;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;


@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountInfo {

	@JsonProperty("combinedName")
	@XmlElement(name = "combinedName")
	private String combinedName;

	@JsonProperty("legalEntityNo")
	@XmlElement(name = "legalEntityNo")
	private String legalEntityNo;

	@JsonProperty("isIndividual")
	@XmlElement(name = "isIndividual")
	private String isIndividual;	

	@JsonProperty("startDate")
	@XmlElement(name = "startDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate startDate;

	@JsonProperty("endDate")
	@XmlElement(name = "endDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate endDate;

	@JsonProperty("number")
	@XmlElement(name = "number")
	private Long number;

	@JsonProperty("numberCheckDigit")
	@XmlElement(name = "numberCheckDigit")
	private Long numberCheckDigit;

	@JsonProperty("role")
	@XmlElement(name = "role")
	private RefData role;

	@JsonProperty("status")
	@XmlElement(name = "status")
	private RefData status;

	@JsonProperty("totalBalance")
	@XmlElement(name = "totalBalance")
	private Float totalBalance;

	public String getCombinedName() {
		return combinedName;
	}

	public void setCombinedName(String combinedName) {
		this.combinedName = combinedName;
	}

	public String getLegalEntityNo() {
		return legalEntityNo;
	}

	public void setLegalEntityNo(String legalEntityNo) {
		this.legalEntityNo = legalEntityNo;
	}

	public String getIsIndividual() {
		return isIndividual;
	}

	public void setIsIndividual(String isIndividual) {
		this.isIndividual = isIndividual;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public Long getNumberCheckDigit() {
		return numberCheckDigit;
	}

	public void setNumberCheckDigit(Long numberCheckDigit) {
		this.numberCheckDigit = numberCheckDigit;
	}

	public RefData getRole() {
		return role;
	}

	public void setRole(RefData role) {
		this.role = role;
	}

	public RefData getStatus() {
		return status;
	}

	public void setStatus(RefData status) {
		this.status = status;
	}

	public Float getTotalBalance() {
		return totalBalance;
	}

	public void setTotalBalance(Float totalBalance) {
		this.totalBalance = totalBalance;
	}
}