package sbpackage.api.osgi.model.calculator.offers;

public enum AccountEventTypeWithOutstanding {
    BILLI,    //Tariff Charges
    REBIL,    //Re-Billed Tariff Charges
    ADJST,    //Adjustments
    TRNIN,    //Transfer In
    BBFWD,    //Conversion Balance Bfwd
    SBFWD,    //Summons Balance Bfwd
}