package sbpackage.api.osgi.model;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.calculator.offers.MeasuredIndicator;
import sbpackage.api.osgi.model.calculator.offers.PropertyStatus;
import sbpackage.api.osgi.model.referencedata.RefData;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Property", propOrder =

{ "propertyId", "startDate", "endDate", "measuredIndicator", "status", "address", "rateableValue", "chargingZone",
		"postcode", "addressLine1", "addressLine2", "addressLine3", "addressLine4", "accountNumber" })

@XmlRootElement(name = "Property")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Property {
    
    @XmlEnum
    public enum SupplyStatus {
        //the order is important here, as it is used by Comparable   
        @XmlEnumValue("MULTIPLE")
        MULTIPLE,
        @XmlEnumValue("ON_SUPPLY")
        ON_SUPPLY,
        @XmlEnumValue("PENDING_SUPPLY")
        PENDING_SUPPLY,
        @XmlEnumValue("ENDING_SUPPLY")
        ENDING_SUPPLY,
        @XmlEnumValue("POST_SUPPLY")
        POST_SUPPLY,
        @XmlEnumValue("UNKNOWN")
        UNKNOWN;
        
        private static SupplyStatus getSupplyStatus(Property property){
            LocalDate start = property.getStartDate();
            LocalDate end = property.getEndDate();
            LocalDate now  = LocalDate.now();
            if(!start.isAfter(now) && end==null) return ON_SUPPLY;
            if(!start.isAfter(now) && !end.isBefore(now)) return ENDING_SUPPLY;
            if(start.isAfter(now)) return PENDING_SUPPLY;
            if(end.isBefore(now)) return POST_SUPPLY;
            return UNKNOWN;
        }
    }
	
	@JsonProperty("propertyId")
	@XmlElement(name = "propertyId")
	private String propertyId;

	@JsonProperty("startDate")
	@XmlElement(name = "startDate")
	private LocalDate startDate;

	@JsonProperty("endDate")
	@XmlElement(name = "endDate")
	private LocalDate endDate;

	@JsonProperty("measuredIndicator")
	@XmlElement(name = "measuredIndicator")
	private RefData measuredIndicator;

	@JsonProperty("status")
	@XmlElement(name = "status")
	private RefData status;

	@JsonProperty("address")
	@XmlElement(name = "address")
	private String address;

	@JsonProperty("rateableValue")
	@XmlElement(name = "rateableValue")
	private String rateableValue;

	@JsonProperty("chargingZone")
	@XmlElement(name = "chargingZone")
	private String chargingZone;

	@JsonProperty("postcode")
	@XmlElement(name = "postcode")
	private String postcode;

	@JsonProperty("addressLine1")
	@XmlElement(name = "addressLine1")
	private String addressLine1;

	@JsonProperty("addressLine2")
	@XmlElement(name = "addressLine2")
	private String addressLine2;

	@JsonProperty("addressLine3")
	@XmlElement(name = "addressLine3")
	private String addressLine3;

	@JsonProperty("addressLine4")
	@XmlElement(name = "addressLine4")
	private String addressLine4;

	@JsonProperty("accountNumber")
	@XmlElement(name = "accountNumber")
	private TargetAccountNumber accountNumber;

	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public RefData getMeasuredIndicator() {
		return measuredIndicator;
	}

	public void setMeasuredIndicator(RefData measuredIndicator) {
		this.measuredIndicator = measuredIndicator;
	}

	public RefData getStatus() {
		return status;
	}

	public void setStatus(RefData status) {
		this.status = status;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRateableValue() {
		return rateableValue;
	}

	public void setRateableValue(String rateableValue) {
		this.rateableValue = rateableValue;
	}

	public String getChargingZone() {
		return chargingZone;
	}

	public void setChargingZone(String chargingZone) {
		this.chargingZone = chargingZone;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}


	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}
        
        /* get 'current' property in the following prioity order
           1) start is in the past and end is null
           2) end is in the future
           3) start is in the future
           4) end is in the past

           so:-
            start in the past = 5 points
            end is null = 4 points
            end is in the future = 3 points
            start in the future = 3 points
            end in the past = 1 point

        */
         public int getRelevenceScore(){
            int score =0;
            score += this.getStartDate().isBefore(LocalDate.now())?5:3;
            score += this.getEndDate()==null?4:( this.getEndDate().isBefore(LocalDate.now())?1:3);
            return score;
        }
         
         public SupplyStatus getSupplyStatus(){
             return SupplyStatus.getSupplyStatus(this);
         }        

    public boolean isActive() {
        return hasPropertyStatus(PropertyStatus.ACTIVE);
    }

    public boolean hasPropertyStatus(PropertyStatus testPropertyStatus) {
        if (testPropertyStatus == null) {
            throw new IllegalArgumentException("testPropertyStatus is required");
        }

        if (status == null) {
            return false;
        }

        String propertyStatusCode = status.getCode();
        Optional<PropertyStatus> propertyStatusOptional = PropertyStatus.fromStatusCode(propertyStatusCode);

        return propertyStatusOptional.isPresent() && propertyStatusOptional.get() == testPropertyStatus;
    }

    public boolean isAssessed() {
        return hasMeasuredIndicator(MeasuredIndicator.ASSESSED);
    }

    public boolean isMeasured() {
        return hasMeasuredIndicator(MeasuredIndicator.MEASURED);
    }

    public boolean isUnmeasured() {
        return hasMeasuredIndicator(MeasuredIndicator.UNMEASURED);
    }

    public boolean hasMeasuredIndicator(MeasuredIndicator testMeasuredIndicator) {
        if (testMeasuredIndicator == null) {
            throw new IllegalArgumentException("testMeasuredIndicator is required");
        }

        if (measuredIndicator == null) {
            return false;
        }

        String measuredIndicatorCode = measuredIndicator.getCode();
        Optional<MeasuredIndicator> measuredIndicatorOptional = MeasuredIndicator.fromTargetCode(measuredIndicatorCode);

        return measuredIndicatorOptional.isPresent() && measuredIndicatorOptional.get() == testMeasuredIndicator;
    }

    @Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Property property = (Property) o;
		return Objects.equals(this.propertyId, property.propertyId)
				&& Objects.equals(this.startDate, property.startDate) && Objects.equals(this.endDate, property.endDate)
				&& Objects.equals(this.measuredIndicator, property.measuredIndicator)
				&& Objects.equals(this.status, property.status) && Objects.equals(this.address, property.address)
				&& Objects.equals(this.rateableValue, property.rateableValue)
				&& Objects.equals(this.chargingZone, property.chargingZone)
				&& Objects.equals(this.postcode, property.postcode)
				&& Objects.equals(this.addressLine1, property.addressLine1)
				&& Objects.equals(this.addressLine2, property.addressLine2)
				&& Objects.equals(this.addressLine3, property.addressLine3)
				&& Objects.equals(this.addressLine4, property.addressLine4)
				&& Objects.equals(this.accountNumber, property.accountNumber);

	}

	@Override
	public int hashCode() {

		return Objects.hash(propertyId, startDate, endDate, measuredIndicator, status, address, rateableValue,
				chargingZone, postcode, addressLine1, addressLine2, addressLine3, addressLine4, accountNumber);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("{");
	    sb.append("\"propertyId\":").append("\"").append(propertyId).append("\"");
        sb.append(", \"startDate\":").append("\"").append(startDate).append("\"");
        sb.append(", \"endDate\":").append("\"").append(endDate).append("\"");
        sb.append(", \"measuredIndicator\":").append("\"").append(measuredIndicator).append("\"");
        sb.append(", \"status\":").append("\"").append(status).append("\"");
        sb.append(", \"address\":").append("\"").append(address).append("\"");
        sb.append(", \"rateableValue\":").append("\"").append(rateableValue).append("\"");
        sb.append(", \"chargingZone\":").append("\"").append(chargingZone).append("\"");
        sb.append(", \"postcode\":").append("\"").append(postcode).append("\"");
        sb.append(", \"addressLine1\":").append("\"").append(addressLine1).append("\"");
        sb.append(", \"addressLine2\":").append("\"").append(addressLine2).append("\"");
        sb.append(", \"addressLine3\":").append("\"").append(addressLine3).append("\"");
        sb.append(", \"addressLine4\":").append("\"").append(addressLine4).append("\"");
        sb.append(", \"bankAccountNumber\":").append("\"").append(accountNumber).append("\"");
        sb.append("}");
        return sb.toString();
	}
        
}