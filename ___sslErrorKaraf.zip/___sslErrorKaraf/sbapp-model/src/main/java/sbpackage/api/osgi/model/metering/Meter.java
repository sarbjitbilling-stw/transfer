package sbpackage.api.osgi.model.metering;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.ToStringBuilder;

import sbpackage.api.osgi.model.Address;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.common.HypermediaDto;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Meter")
@XmlRootElement(name = "Meter")
public class Meter extends HypermediaDto {

	@XmlElement(name = "type")
	private String type;

	@XmlElement(name = "accountNumber")
	private TargetAccountNumber accountNumber;

	@XmlElement(name = "cupsUsageAreaCode")
	private String cupsUsageAreaCode;

	@XmlElement(name = "dialDigitsLeft")
	private String dialDigitsLeft;

	@XmlElement(name = "dialDigitsRight")
	private String dialDigitsRight;

	@XmlElement(name = "equipmentStatusCode")
	private String equipmentStatusCode;

	@XmlElement(name = "meterNum")
	private String meterNum;

	@XmlElement(name = "meterManufacturerName")
	private String meterManufacturerName;

	@XmlElement(name = "meterModelCode")
	private String meterModelCode;

	@XmlElement(name = "meterSerialNum")
	private String meterSerialNum;

	@XmlElement(name = "meterLocationCode")
	private String meterLocationCode;

	@XmlElement(name = "meterLocationDescript")
	private String meterLocationDescript;

	@XmlElement(name = "meterSizeCode")
	private String meterSizeCode;

	@XmlElement(name = "meterSizeDescript")
	private String meterSizeDescript;

	@XmlElement(name = "propertyId")
	private String propertyId;

	@XmlElement(name = "registerNum")
	private String registerNum;

	@XmlElement(name = "revenueClassificationCode")
	private String revenueClassificationCode;

	@XmlElement(name = "routeNumber")
	private String routeNumber;

	@XmlElement(name = "servProvCode")
	private String servProvCode;

	@XmlElement(name = "targetInternalEquipNum")
	private String targetInternalEquipNum;

	@XmlElement(name = "targetInternalMeterRegNum")
	private String targetInternalMeterRegNum;

	@XmlElement(name = "unitOfMeasurementCode")
	private String unitOfMeasurementCode;

	@XmlElement(name = "address")
	private Address address = null;

	@XmlElement(name = "captureDate")
	private LocalDate captureDate = null;

	@XmlElement(name = "readingTypeDescription")
	private String readingTypeDescription = null;

	@XmlElement(name = "createdDate")
	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate createdDate = null;

	@XmlElement(name = "reading")
	private String reading = null;

	@XmlElement(name = "readingReason")
	private String readingReason = null;

	@XmlElement(name = "readingReasonText")
	private String readingReasonText = null;

	@XmlElement(name = "overrideValidation")
	private boolean isOverrideValidation = false;

	@XmlElement(name = "serviceAddress")
	private String serviceAddress = null;

	@XmlElement(name = "latestMeterRead")
	private MeterReadDetail latestMeterRead = null;

	@XmlElement(name = "meterReads")
	private List<MeterReadDetail> meterReads = null;
	
	@XmlElement(name = "metaData")
	private MeterMetadata metaData;
	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCupsUsageAreaCode() {
		return cupsUsageAreaCode;
	}

	public void setCupsUsageAreaCode(String cupsUsageAreaCode) {
		this.cupsUsageAreaCode = cupsUsageAreaCode;
	}

	public String getDialDigitsLeft() {
		return dialDigitsLeft;
	}

	public void setDialDigitsLeft(String dialDigitsLeft) {
		this.dialDigitsLeft = dialDigitsLeft;
	}

	public String getDialDigitsRight() {
		return dialDigitsRight;
	}

	public void setDialDigitsRight(String dialDigitsRight) {
		this.dialDigitsRight = dialDigitsRight;
	}

	public String getEquipmentStatusCode() {
		return equipmentStatusCode;
	}

	public void setEquipmentStatusCode(String equipmentStatusCode) {
		this.equipmentStatusCode = equipmentStatusCode;
	}

	public String getMeterNum() {
		return meterNum;
	}

	public void setMeterNum(String meterNum) {
		this.meterNum = meterNum;
	}

	public String getMeterManufacturerName() {
		return meterManufacturerName;
	}

	public void setMeterManufacturerName(String meterManufacturerName) {
		this.meterManufacturerName = meterManufacturerName;
	}

	public String getMeterModelCode() {
		return meterModelCode;
	}

	public void setMeterModelCode(String meterModelCode) {
		this.meterModelCode = meterModelCode;
	}

	public String getMeterSerialNum() {
		return meterSerialNum;
	}

	public void setMeterSerialNum(String meterSerialNum) {
		this.meterSerialNum = meterSerialNum;
	}

	public String getMeterLocationCode() {
		return meterLocationCode;
	}

	public void setMeterLocationCode(String meterLocationCode) {
		this.meterLocationCode = meterLocationCode;
	}

	public String getMeterLocationDescript() {
		return meterLocationDescript;
	}

	public void setMeterLocationDescript(String meterLocationDescript) {
		this.meterLocationDescript = meterLocationDescript;
	}

	public String getMeterSizeCode() {
		return meterSizeCode;
	}

	public void setMeterSizeCode(String meterSizeCode) {
		this.meterSizeCode = meterSizeCode;
	}

	public String getMeterSizeDescript() {
		return meterSizeDescript;
	}

	public void setMeterSizeDescript(String meterSizeDescript) {
		this.meterSizeDescript = meterSizeDescript;
	}

	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public String getRegisterNum() {
		return registerNum;
	}

	public void setRegisterNum(String registerNum) {
		this.registerNum = registerNum;
	}

	public String getRevenueClassificationCode() {
		return revenueClassificationCode;
	}

	public void setRevenueClassificationCode(String revenueClassificationCode) {
		this.revenueClassificationCode = revenueClassificationCode;
	}

	public String getRouteNumber() {
		return routeNumber;
	}

	public void setRouteNumber(String routeNumber) {
		this.routeNumber = routeNumber;
	}

	public String getServProvCode() {
		return servProvCode;
	}

	public void setServProvCode(String servProvCode) {
		this.servProvCode = servProvCode;
	}

	public String getTargetInternalEquipNum() {
		return targetInternalEquipNum;
	}

	public void setTargetInternalEquipNum(String targetInternalEquipNum) {
		this.targetInternalEquipNum = targetInternalEquipNum;
	}

	public String getTargetInternalMeterRegNum() {
		return targetInternalMeterRegNum;
	}

	public void setTargetInternalMeterRegNum(String targetInternalMeterRegNum) {
		this.targetInternalMeterRegNum = targetInternalMeterRegNum;
	}

	public String getUnitOfMeasurementCode() {
		return unitOfMeasurementCode;
	}

	public void setUnitOfMeasurementCode(String unitOfMeasurementCode) {
		this.unitOfMeasurementCode = unitOfMeasurementCode;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getReadingTypeDescription() {
		return readingTypeDescription;
	}

	public void setReadingTypeDescription(String readingTypeDescription) {
		this.readingTypeDescription = readingTypeDescription;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public String getReading() {
		return reading;
	}

	public void setReading(String reading) {
		this.reading = reading;
	}

	public String getReadingReason() {
		return readingReason;
	}

	public void setReadingReason(String readingReason) {
		this.readingReason = readingReason;
	}

	public String getReadingReasonText() {
		return readingReasonText;
	}

	public void setReadingReasonText(String readingReasonText) {
		this.readingReasonText = readingReasonText;
	}

	public boolean isOverrideValidation() {
		return isOverrideValidation;
	}

	public void setOverrideValidation(boolean isOverrideValidation) {
		this.isOverrideValidation = isOverrideValidation;
	}

	public String getServiceAddress() {
		return serviceAddress;
	}

	public void setServiceAddress(String serviceAddress) {
		this.serviceAddress = serviceAddress;
	}

	public MeterReadDetail getLatestMeterRead() {
		return latestMeterRead;
	}

	public void setLatestMeterRead(MeterReadDetail latestMeterRead) {
		this.latestMeterRead = latestMeterRead;
	}

	public List<MeterReadDetail> getMeterReads() {
		return meterReads;
	}

	public void setMeterReads(List<MeterReadDetail> meterReads) {
		this.meterReads = meterReads;
	}

	public LocalDate getCaptureDate() {
		return captureDate;
	}

	public void setCaptureDate(LocalDate captureDate) {
		this.captureDate = captureDate;
	}
	
	public MeterMetadata getMetaData() {
		return metaData;
	}

	public void setMetaData(MeterMetadata metaData) {
		this.metaData = metaData;
	}
	
	@Override
	public String toString() {
		return new ToStringBuilder(this).append("type", type).append("accountNumber", accountNumber)
				.append("cupsUsageAreaCode", cupsUsageAreaCode).append("dialDigitsLeft", dialDigitsLeft)
				.append("dialDigitsRight", dialDigitsRight).append("equipmentStatusCode", equipmentStatusCode)
				.append("meterNum", meterNum).append("meterManufacturerName", meterManufacturerName)
				.append("meterModelCode", meterModelCode).append("meterSerialNum", meterSerialNum)
				.append("meterLocationCode", meterLocationCode).append("meterLocationDescript", meterLocationDescript)
				.append("meterSizeCode", meterSizeCode).append("meterSizeDescript", meterSizeDescript)
				.append("propertyId", propertyId).append("registerNum", registerNum)
				.append("revenueClassificationCode", revenueClassificationCode).append("routeNumber", routeNumber)
				.append("servProvCode", servProvCode).append("targetInternalEquipNum", targetInternalEquipNum)
				.append("targetInternalMeterRegNum", targetInternalMeterRegNum)
				.append("unitOfMeasurementCode", unitOfMeasurementCode).append("address", address)
				.append("readingTypeDescription", readingTypeDescription).append("createdDate", createdDate)
				.append("reading", reading).append("readingReason", readingReason)
				.append("readingReasonText", readingReasonText).append("isOverrideValidation", isOverrideValidation)
				.append("serviceAddress", serviceAddress)
				.append("metaData", metaData).toString();
	}

}
