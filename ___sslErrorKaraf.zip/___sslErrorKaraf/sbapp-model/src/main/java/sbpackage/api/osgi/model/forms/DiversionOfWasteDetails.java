package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DiversionOfWasteDetails {

    private Assets assetsToBeDiverted;
    private ReasonForDiversion reasonForDiversion;
    private PlanningConsent planningConsent;
    private Details principalContractorDetails;
    private String currentStep;

    public Assets getAssetsToBeDiverted() {
        return assetsToBeDiverted;
    }

    public void setAssetsToBeDiverted(Assets assetsToBeDiverted) {
        this.assetsToBeDiverted = assetsToBeDiverted;
    }

    public ReasonForDiversion getReasonForDiversion() {
        return reasonForDiversion;
    }

    public void setReasonForDiversion(ReasonForDiversion reasonForDiversion) {
        this.reasonForDiversion = reasonForDiversion;
    }

    public PlanningConsent getPlanningConsent() {
        return planningConsent;
    }

    public void setPlanningConsent(PlanningConsent planningConsent) {
        this.planningConsent = planningConsent;
    }

    public Details getPrincipalContractorDetails() {
        return principalContractorDetails;
    }

    public void setPrincipalContractorDetails(Details principalContractorDetails) {
        this.principalContractorDetails = principalContractorDetails;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }
}
