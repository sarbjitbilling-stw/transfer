package sbpackage.api.osgi.model.payment.common;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

/**
 * Created by rtai on 07/07/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlan implements Serializable {

	private String facilityCode;

	private String scheduleFreqCode;

	private Long planNumber;

	private Long accountNumber;

	private Long employeeNumber;

	private String suggestIndicator;

	private PlanType planType;

	private BudgetType budgetType;

	private Long paymentNumberExpected;
	
	@XmlElement(name = "length")
    private int length;
    
	private int targetDefaultPlanLength;
	  
    @XmlElement(name = "averageInstallmentAmount")
    private  BigDecimal averageInstallmentAmount;
    
    @XmlElement(name = "defaultPlan")
    private boolean defaultPlan;

	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate nextInstallmentDate;

	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate startDate;

	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate nextReconciliationDate;

	private Long installmentNumber;

	private BigDecimal totalBudgetAmount;

	private Long overflowInstanceNumber;

	private Integer paymentDay;
	
	@XmlElement(name = "reconciliationMethod")
	private String reconciliationMethod;
	
	private Status paymentPlanStatus;
	
	private LocalDate creationDateTime;
	
	private String reminderFlag;
	
	private BigDecimal originalBalance;
	
	private BigDecimal budgetPlanBalance;
	
	private BigDecimal budgetPlanPayAmount;
	
	private BigDecimal installmentAmount;
	
	private String conditionalFlag;
	
	private BigDecimal planPayAmt;
	
	private String cashOnlyFlag;
	
	private String applyInterestFlag;
	
	private String reminderFlg;
	
	@XmlElement(name = "schedule")
	private List<ScheduledPayment> schedule;

	public String getFacilityCode() {
		return facilityCode;
	}

	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}

	public String getScheduleFreqCode() {
		return scheduleFreqCode;
	}

	public void setScheduleFreqCode(String scheduleFreqCode) {
		this.scheduleFreqCode = scheduleFreqCode;
	}

	public Long getPlanNumber() {
		return planNumber;
	}

	public void setPlanNumber(Long planNumber) {
		this.planNumber = planNumber;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Long employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getSuggestIndicator() {
		return suggestIndicator;
	}

	public void setSuggestIndicator(String suggestIndicator) {
		this.suggestIndicator = suggestIndicator;
	}

	public PlanType getPlanType() {
		return planType;
	}

	public void setPlanType(PlanType planType) {
		this.planType = planType;
	}

	public BudgetType getBudgetType() {
		return budgetType;
	}

	public void setBudgetType(BudgetType budgetType) {
		this.budgetType = budgetType;
	}

	public Long getPaymentNumberExpected() {
		return paymentNumberExpected;
	}

	public void setPaymentNumberExpected(Long paymentNumberExpected) {
		this.paymentNumberExpected = paymentNumberExpected;
	}

	public LocalDate getNextInstallmentDate() {
		return nextInstallmentDate;
	}

	public void setNextInstallmentDate(LocalDate nextInstallmentDate) {
		this.nextInstallmentDate = nextInstallmentDate;
	}

	public LocalDate getNextReconciliationDate() {
		return nextReconciliationDate;
	}

	public void setNextReconciliationDate(LocalDate nextReconciliationDate) {
		this.nextReconciliationDate = nextReconciliationDate;
	}

	public Long getInstallmentNumber() {
		return installmentNumber;
	}

	public void setInstallmentNumber(Long installmentNumber) {
		this.installmentNumber = installmentNumber;
	}

	public BigDecimal getTotalBudgetAmount() {
		return totalBudgetAmount;
	}

	public void setTotalBudgetAmount(BigDecimal totalBudgetAmount) {
		this.totalBudgetAmount = totalBudgetAmount;
	}

	public Long getOverflowInstanceNumber() {
		return overflowInstanceNumber;
	}

	public void setOverflowInstanceNumber(Long overflowInstanceNumber) {
		this.overflowInstanceNumber = overflowInstanceNumber;
	}

	public List<ScheduledPayment> getSchedule() {
		return schedule;
	}

	public void setSchedule(List<ScheduledPayment> schedule) {
		this.schedule = schedule;
	}

	public Integer getPaymentDay() {
		return paymentDay;
	}

	public void setPaymentDay(Integer paymentDay) {
		this.paymentDay = paymentDay;
	}
	
	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}	

	public int getTargetDefaultPlanLength() {
		return targetDefaultPlanLength;
	}

	public void setTargetDefaultPlanLength(int targetDefaultPlanLength) {
		this.targetDefaultPlanLength = targetDefaultPlanLength;
	}

	public BigDecimal getAverageInstallmentAmount() {
		return averageInstallmentAmount;
	}

	public void setAverageInstallmentAmount(BigDecimal averageInstallmentAmount) {
		this.averageInstallmentAmount = averageInstallmentAmount;
	}

	public boolean isDefaultPlan() {
		return defaultPlan;
	}

	public void setDefaultPlan(boolean defaultPlan) {
		this.defaultPlan = defaultPlan;
	}
	
	public String getReconciliationMethod() {
		return reconciliationMethod;
	}

	public void setReconciliationMethod(String reconciliationMethod) {
		this.reconciliationMethod = reconciliationMethod;
	}
	
	public Status getPaymentPlanStatus() {
		return paymentPlanStatus;
	}

	public void setPaymentPlanStatus(Status paymentPlanStatus) {
		this.paymentPlanStatus = paymentPlanStatus;
	}
	
	public LocalDate getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(LocalDate creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public String getReminderFlag() {
		return reminderFlag;
	}

	public void setReminderFlag(String reminderFlag) {
		this.reminderFlag = reminderFlag;
	}

	public BigDecimal getOriginalBalance() {
		return originalBalance;
	}

	public void setOriginalBalance(BigDecimal originalBalance) {
		this.originalBalance = originalBalance;
	}

	public BigDecimal getBudgetPlanBalance() {
		return budgetPlanBalance;
	}

	public void setBudgetPlanBalance(BigDecimal budgetPlanBalance) {
		this.budgetPlanBalance = budgetPlanBalance;
	}

	public BigDecimal getBudgetPlanPayAmount() {
		return budgetPlanPayAmount;
	}

	public void setBudgetPlanPayAmount(BigDecimal budgetPlanPayAmount) {
		this.budgetPlanPayAmount = budgetPlanPayAmount;
	}

	public BigDecimal getInstallmentAmount() {
		return installmentAmount;
	}

	public void setInstallmentAmount(BigDecimal installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	public String getConditionalFlag() {
		return conditionalFlag;
	}

	public void setConditionalFlag(String conditionalFlag) {
		this.conditionalFlag = conditionalFlag;
	}

	public BigDecimal getPlanPayAmt() {
		return planPayAmt;
	}

	public void setPlanPayAmt(BigDecimal planPayAmt) {
		this.planPayAmt = planPayAmt;
	}
	
	public String getCashOnlyFlag() {
		return cashOnlyFlag;
	}

	public void setCashOnlyFlag(String cashOnlyFlag) {
		this.cashOnlyFlag = cashOnlyFlag;
	}
	

	public String getApplyInterestFlag() {
		return applyInterestFlag;
	}

	public void setApplyInterestFlag(String applyInterestFlag) {
		this.applyInterestFlag = applyInterestFlag;
	}

	public String getReminderFlg() {
		return reminderFlg;
	}

	public void setReminderFlg(String reminderFlg) {
		this.reminderFlg = reminderFlg;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		PaymentPlan plan = (PaymentPlan) o;

		return new EqualsBuilder()
				.append(facilityCode, plan.facilityCode)
				.append(scheduleFreqCode, plan.scheduleFreqCode)
				.append(planNumber, plan.planNumber)
				.append(accountNumber, plan.accountNumber)
				.append(employeeNumber, plan.employeeNumber)
				.append(suggestIndicator, plan.suggestIndicator)
				.append(planType, plan.planType)
				.append(budgetType, plan.budgetType)
				.append(paymentNumberExpected, plan.paymentNumberExpected)
				.append(nextInstallmentDate, plan.nextInstallmentDate)
				.append(nextReconciliationDate, plan.nextReconciliationDate)
				.append(installmentNumber, plan.installmentNumber)
				.append(totalBudgetAmount, plan.totalBudgetAmount)
				.append(overflowInstanceNumber, plan.overflowInstanceNumber)
				.append(schedule, plan.schedule)
				.append(paymentDay, plan.paymentDay)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(facilityCode)
				.append(scheduleFreqCode)
				.append(planNumber)
				.append(accountNumber)
				.append(employeeNumber)
				.append(suggestIndicator)
				.append(planType)
				.append(budgetType)
				.append(paymentNumberExpected)
				.append(nextInstallmentDate)
				.append(nextReconciliationDate)
				.append(installmentNumber)
				.append(totalBudgetAmount)
				.append(overflowInstanceNumber)
				.append(schedule)
				.append(paymentDay)
				.toHashCode();
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this)
				.append("facilityCode",facilityCode)
				.append("scheduleFreqCode",scheduleFreqCode)
				.append("planNumber", planNumber)
				.append("accountNumber", accountNumber)
				.append("employeeNumber", employeeNumber)
				.append("suggestIndicator", suggestIndicator)
				.append("planType", planType)
				.append("budgetType", budgetType)
				.append("paymentNumberExpected", paymentNumberExpected)
				.append("nextInstallmentDate", nextInstallmentDate)
				.append("nextReconciliationDate", nextReconciliationDate)
				.append("installmentNumber", installmentNumber)
				.append("totalBudgetAmount", totalBudgetAmount)
				.append("overflowInstanceNumber", overflowInstanceNumber)
				.append("schedule", schedule)
				.append("paymentDay", paymentDay)
				.toString();
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public enum Status {
        A, I, L, P, T
    }

	public enum PlanType {
		ARREARS, DEPOSIT, MERCHANDISE, NONE, THIRD_PARTY
	}

	public enum BudgetType {
		COMBINATION, EQUALIZED, NONE, PPC, UNMEASURED
	}
}
