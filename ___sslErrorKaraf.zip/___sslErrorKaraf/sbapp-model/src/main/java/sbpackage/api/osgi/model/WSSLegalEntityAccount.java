package sbpackage.api.osgi.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement(name = "WSSLegalEntityAccount")
@XmlAccessorType(XmlAccessType.FIELD)
public class WSSLegalEntityAccount  implements Serializable {

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "legalEntityId")
    private String legalEntityId;
    
    @XmlElement(name = "favourite")
    private boolean favourite;

    @XmlElement(name = "defaultAccount")
    private boolean defaultAccount;
    
    @XmlElement(name = "account")
    private Account account;
    
    @XmlElement(name = "brand")
    private AccountBrand brand;

    public WSSLegalEntityAccount() {
    }

    public WSSLegalEntityAccount(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    //these don't really belong here, but remain for expedency
    @XmlElement
    boolean smartBillsSpecialCondition;
    
    @XmlElement
    boolean salaryDeduBillsSpecialCondition;

    @XmlElement
    boolean welshSpecialCondition;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntityId() {
		return legalEntityId;
	}

	public void setLegalEntityId(String legalEntityId) {
		this.legalEntityId = legalEntityId;
	}
    
    public boolean isFavourite() {
        return favourite;
    }

    public void setFavourite(boolean favourite) {
        this.favourite = favourite;
    }

    public boolean isDefaultAccount() {
		return defaultAccount;
	}

	public void setDefaultAccount(boolean defaultAccount) {
		this.defaultAccount = defaultAccount;
	}

	public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public boolean isSmartBillsSpecialCondition() {
        return smartBillsSpecialCondition;
    }

    public void setSmartBillsSpecialCondition(boolean smartBillsSpecialCondition) {
        this.smartBillsSpecialCondition = smartBillsSpecialCondition;
    }
    
    public boolean isSalaryDeduBillsSpecialCondition() {
        return salaryDeduBillsSpecialCondition;
    }

    public void setSalaryDeduBillsSpecialCondition(boolean salaryDeduBillsSpecialCondition) {
        this.salaryDeduBillsSpecialCondition = salaryDeduBillsSpecialCondition;
    }

    public boolean isWelshSpecialCondition() {
        return welshSpecialCondition;
    }

    public void setWelshSpecialCondition(boolean welshSpecialCondition) {
        this.welshSpecialCondition = welshSpecialCondition;
    }

    public AccountBrand getBrand() {
        return brand;
    }

    public void setBrand(AccountBrand brand) {
        this.brand = brand;
    }
    
}
