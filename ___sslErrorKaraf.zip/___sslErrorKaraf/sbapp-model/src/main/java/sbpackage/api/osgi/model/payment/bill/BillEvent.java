package sbpackage.api.osgi.model.payment.bill;

import java.time.LocalDate;

public class BillEvent {

	private Long serviceProvisionNum;

	private String serviceDescription;

	private Float serProvBilledAmount;

	private Float avgDailySpendAmount;

	private Long propertyId;

	private LocalDate subPeriodStartDate;

	private LocalDate subPeriodEndDate;

	private Long subPeriodDays;

	public Long getServiceProvisionNum() {
		return serviceProvisionNum;
	}

	public void setServiceProvisionNum(Long serviceProvisionNum) {
		this.serviceProvisionNum = serviceProvisionNum;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public Float getSerProvBilledAmount() {
		return serProvBilledAmount;
	}

	public void setSerProvBilledAmount(Float serProvBilledAmount) {
		this.serProvBilledAmount = serProvBilledAmount;
	}

	public Float getAvgDailySpendAmount() {
		return avgDailySpendAmount;
	}

	public void setAvgDailySpendAmount(Float avgDailySpendAmount) {
		this.avgDailySpendAmount = avgDailySpendAmount;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public LocalDate getSubPeriodStartDate() {
		return subPeriodStartDate;
	}

	public void setSubPeriodStartDate(LocalDate subPeriodStartDate) {
		this.subPeriodStartDate = subPeriodStartDate;
	}

	public LocalDate getSubPeriodEndDate() {
		return subPeriodEndDate;
	}

	public void setSubPeriodEndDate(LocalDate subPeriodEndDate) {
		this.subPeriodEndDate = subPeriodEndDate;
	}

	public Long getSubPeriodDays() {
		return subPeriodDays;
	}

	public void setSubPeriodDays(Long subPeriodDays) {
		this.subPeriodDays = subPeriodDays;
	}

}
