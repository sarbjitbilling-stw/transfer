package sbpackage.api.osgi.model.payment;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class PaymentPlanResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    public PaymentPlanResponse() {
        warnings = new ArrayList<>();
    }

    @XmlElement
    private List<PaymentPlanWarningDTO> warnings;

    public List<PaymentPlanWarningDTO> getWarnings() {
        return warnings;
    }

    public void setWarnings(final List<PaymentPlanWarningDTO> warnings) {
        this.warnings = warnings;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("warnings", warnings)
                .toString();
    }
}