package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PeopleInBuilding {

    private int peopleInBuilding;

    public int getPeopleInBuilding() {
        return peopleInBuilding;
    }

    public void setPeopleInBuilding(int peopleInBuilding) {
        this.peopleInBuilding = peopleInBuilding;
    }
}
