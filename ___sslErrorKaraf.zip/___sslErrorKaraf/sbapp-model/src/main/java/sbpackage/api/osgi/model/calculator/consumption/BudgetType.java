package sbpackage.api.osgi.model.calculator.consumption;

public enum BudgetType {
    LOW, AVERAGE, HIGH
}
