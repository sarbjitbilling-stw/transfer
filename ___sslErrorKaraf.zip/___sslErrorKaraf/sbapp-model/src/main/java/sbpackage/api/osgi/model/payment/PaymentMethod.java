package sbpackage.api.osgi.model.payment;

import java.io.Serializable;
import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

/**
 * 
 * @author zali
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentMethod implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8122599492912157911L;

	private Integer eligible;

	private String eligibleText;
	/**
	 * 
	 */
	private String paymentFrequencyCode;
	/**
	 * 
	 */
	private String paymentMethodCode;
	/**
	 * 
	 */
	private String paymentMethodText;
	/**
	 * 
	 */
	private String paymentFrequencyText;
	/**
	 * 
	 */
	private boolean plan;
	/**
	 * 
	 */
	private boolean defaultPaymentType;

	private String facilityCode;

	private String scheduleFreqCode;

	private String dayType;

	private Integer paymentMethodOrder;

	private Integer paymentFrequencyOrder;

	private String hoverOverText;

	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate earliestStartDate;

	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate latestStartDate;
	
	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate targetDate;

	public String getPaymentMethodCode() {
		return paymentMethodCode;
	}

	public void setPaymentMethodCode(String paymentMethodCode) {
		this.paymentMethodCode = paymentMethodCode;
	}

	/**
	 * @return the paymentMethodText
	 */
	public String getPaymentMethodText() {
		return paymentMethodText;
	}

	/**
	 * @param paymentMethodText
	 *            the paymentMethodText to set
	 */
	public void setPaymentMethodText(String paymentMethodText) {
		this.paymentMethodText = paymentMethodText;
	}

	/**
	 * @return the planable
	 */
	public boolean isPlan() {
		return plan;
	}

	/**
	 * @param planable
	 *            the planable to set
	 */
	public void setPlan(boolean planable) {
		this.plan = planable;
	}

	public boolean isDefaultPaymentType() {
		return defaultPaymentType;
	}

	public void setDefaultPaymentType(boolean defaultPaymentType) {
		this.defaultPaymentType = defaultPaymentType;
	}

	/**
	 * @return the paymentFrequencyCode
	 */
	public String getPaymentFrequencyCode() {
		return paymentFrequencyCode;
	}

	/**
	 * @param paymentFrequencyCode
	 *            the paymentFrequencyCode to set
	 */
	public void setPaymentFrequencyCode(String paymentFrequencyCode) {
		this.paymentFrequencyCode = paymentFrequencyCode;
	}

	/**
	 * @return the paymentFrequencyText
	 */
	public String getPaymentFrequencyText() {
		return paymentFrequencyText;
	}

	/**
	 * @param paymentFrequencyText
	 *            the paymentFrequencyText to set
	 */
	public void setPaymentFrequencyText(String paymentFrequencyText) {
		this.paymentFrequencyText = paymentFrequencyText;
	}

	/**
	 * @return the eligible
	 */
	public Integer getEligible() {
		return eligible;
	}

	/**
	 * @param eligible
	 *            the eligible to set
	 */
	public void setEligible(Integer eligible) {
		this.eligible = eligible;
	}

	/**
	 * @return the eligibleText
	 */
	public String getEligibleText() {
		return eligibleText;
	}

	/**
	 * @param eligibleText
	 *            the eligibleText to set
	 */
	public void setEligibleText(String eligibleText) {
		this.eligibleText = eligibleText;
	}

	public String getFacilityCode() {
		return facilityCode;
	}

	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}

	public String getScheduleFreqCode() {
		return scheduleFreqCode;
	}

	public void setScheduleFreqCode(String scheduleFreqCode) {
		this.scheduleFreqCode = scheduleFreqCode;
	}

	public String getDayType() {
		return dayType;
	}

	public void setDayType(String dayType) {
		this.dayType = dayType;
	}

	public LocalDate getEarliestStartDate() {
		return earliestStartDate;
	}

	public void setEarliestStartDate(LocalDate earliestStartDate) {
		this.earliestStartDate = earliestStartDate;
	}

	public LocalDate getLatestStartDate() {
		return latestStartDate;
	}

	public void setLatestStartDate(LocalDate latestStartDate) {
		this.latestStartDate = latestStartDate;
	}

	public LocalDate getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(LocalDate targetDate) {
		this.targetDate = targetDate;
	}

	public Integer getPaymentMethodOrder() {
		return paymentMethodOrder;
	}

	public void setPaymentMethodOrder(Integer paymentMethodOrder) {
		this.paymentMethodOrder = paymentMethodOrder;
	}

	public Integer getPaymentFrequencyOrder() {
		return paymentFrequencyOrder;
	}

	public void setPaymentFrequencyOrder(Integer paymentFrequencyOrder) {
		this.paymentFrequencyOrder = paymentFrequencyOrder;
	}

	public String getHoverOverText() {
		return hoverOverText;
	}

	public void setHoverOverText(String hoverOverText) {
		this.hoverOverText = hoverOverText;
	}

}
