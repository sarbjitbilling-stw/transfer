package sbpackage.api.osgi.model;

/**
 * Created by ppahwa on 28/04/2017.
 */
public enum ContactTypes {

    WEB645,
    WEB619,
    WEB642,
    WEB644,
    WEB620,
    WEB627,
    WEB678,
    WEB695,
    WEB643,
    WEB701,

    // CHOR contacts
    WEB700,
    WEB705,
    //New Contract added (WEB707, WEB708, WEB709 for Splitting the Chor+Sim and Payment plan
    WEB707,
    WEB708,
    WEB709,
    WEB714,
    WEB668,
    WEB665,
    WEB649,
    WEB650,
    WEB667,
    WEB675,
    WEB659,
    WEB656,
    WEB661,
    WEB652,
    WEB677,
    WEB651,
    WEB671,
    WEB655,
    WEB657,
    WEB658,
    WEB669,
    WEB694,
    WEB663,
    WEB670,
    WEB679,
    WEB662,

    WEB601,  //WaterCard success
    WEB633,  //WaterCard failure
    WEB618,  //Papercopy Bill Request success
    WEB628,  //Papercopy Bill Request failure

    WEB623,
    WEB626,
    WEB715   //Paperless removal

}
