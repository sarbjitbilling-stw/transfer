package sbpackage.api.osgi.model.calculator.offers;

public enum PayPlanType {
    ARREARS("A"),
    THIRD_PARTY("T"),
    NONE("N");

    private final String payPlanType;

    PayPlanType(final String payPlanType) {
        this.payPlanType = payPlanType;
    }

    public String getPayPlanType() {
        return payPlanType;
    }
}
