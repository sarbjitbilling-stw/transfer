package sbpackage.api.osgi.model.constants;

public class WebContactConstants {
	
	public static final String QUERY_DETAILS_KEY = "Query Details: ";
	public static final String ITEM = "Item";
	public static final String FROM = "From";
	public static final String TO = "To";
	public static final String TITLE = "Title";
	public static final String FIRST_NAME = "First Name";
	public static final String LAST_NAME = "Last Name";
	public static final String EMAIL = "Email";
	public static final String DATE_OF_BIRTH = "Date of Birth";
	public static final String MOBILE_PHONE = "Mobile telephone";
	public static final String WORK_PHONE = "Work telephone";
	public static final String HOME_PHONE = "Home telephone";
	public static final String PREFERRED_CONTACT = "Preferred contact";
	public static final String BANK_ACCOUNT = "Bank account";
	public static final String EMPLOYMENT = "Employment";
	public static final String HOME_OWNERSHIP = "Home ownership";
	public static final String MARKETING_CONSENT = "Marketing consent";

}
