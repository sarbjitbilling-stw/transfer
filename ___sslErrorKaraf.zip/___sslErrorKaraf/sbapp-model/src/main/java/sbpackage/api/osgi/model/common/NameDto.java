package sbpackage.api.osgi.model.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by rtai on 05/06/2017.
 */
@XmlType(name = "name")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NameDto {
	
	private static final String EMPTY_STRING = "";

	private static final String SPACE = " ";

    @XmlElement(name = "title")
    private String title;

    @XmlElement(name = "firstName")
    private String firstName;

    @XmlElement(name = "middleName")
    private String middleName;

    @XmlElement(name = "lastName")
    private String lastName;

    public NameDto(String title, String firstName, String middleName, String lastName) {
        if(title == null) title = "";
        this.title = title;
        if(firstName == null) firstName = "";
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
    }

    public String getTitle() {
        return this.title;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }
    
    public String buildFullName() {
    	StringBuilder fullName = new StringBuilder(EMPTY_STRING);
		if(getTitle() != null && StringUtils.isNotEmpty(getTitle())){
			fullName.append(getTitle()).append(SPACE);
		}
		fullName.append(getFirstName()).append(SPACE);
		if(StringUtils.isNotEmpty(getMiddleName())) {
			fullName.append(getMiddleName()).append(SPACE);
		}
		fullName.append(getLastName());
		return fullName.toString();
    }
}
