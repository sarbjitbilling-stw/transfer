package sbpackage.api.osgi.model.rechor;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.ProcessOutcomeList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

@XmlRootElement(name = "ReChorChainDTO")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ReChorChainDTO implements Serializable {
    private ReChorChainRequest reChorChainRequest;
    private List<ChainOperation> chainOperations;
    private ProcessOutcomeList outcome;

    public ReChorChainRequest getReChorChainRequest() {
        return reChorChainRequest;
    }

    public void setReChorChainRequest(final ReChorChainRequest reChorChainRequest) {
        this.reChorChainRequest = reChorChainRequest;
    }

    public List<ChainOperation> getChainOperations() {
        return chainOperations;
    }

    public void setChainOperations(final List<ChainOperation> chainOperations) {
        this.chainOperations = chainOperations;
    }

    public ProcessOutcomeList getOutcome() {
        return outcome;
    }

    public void setOutcome(final ProcessOutcomeList outcome) {
        this.outcome = outcome;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("reChorChainRequest", reChorChainRequest)
                .append("chainOperations", chainOperations)
                .append("outcome", outcome)
                .toString();
    }
}
