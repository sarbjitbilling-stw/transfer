package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class NumberOfPropertiesByPlotArea {

    private List<PropertiesByPlotArea> properties;

    public List<PropertiesByPlotArea> getProperties() {
        return properties;
    }

    public void setProperties(List<PropertiesByPlotArea> properties) {
        this.properties = properties;
    }
}
