package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

/**
 * Created by .
 */
@XmlRootElement(name = "SearchDocInfoResponse")
@XmlAccessorType(XmlAccessType.FIELD)

public class SearchDocInfoResponse {

    String documentIdentifier;
    String invoiceIssueDate;
    String amount;
    String invoiceNumber;
    TargetAccountNumber accountNumber;

    public String getDocumentIdentifier() {
        return documentIdentifier;
    }

    public void setDocumentIdentifier(String documentIdentifier) {
        this.documentIdentifier = documentIdentifier;
    }

    public String getInvoiceIssueDate() {
        return invoiceIssueDate;
    }

    public void setInvoiceIssueDate(String invoiceIssueDate) {
        this.invoiceIssueDate = invoiceIssueDate;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }
}
