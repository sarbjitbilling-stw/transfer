package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ContactDetails {

    private IdentifyingApplicant identifyingApplicant;
    private ContactDetailsInfo contactDetails;
    private AdditionalContacts additionalContacts;

    public IdentifyingApplicant getIdentifyingApplicant() {
        return identifyingApplicant;
    }

    public void setIdentifyingApplicant(IdentifyingApplicant identifyingApplicant) {
        this.identifyingApplicant = identifyingApplicant;
    }

    public ContactDetailsInfo getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(ContactDetailsInfo contactDetails) {
        this.contactDetails = contactDetails;
    }

    public AdditionalContacts getAdditionalContacts() {
        return additionalContacts;
    }

    public void setAdditionalContacts(AdditionalContacts additionalContacts) {
        this.additionalContacts = additionalContacts;
    }
}
