package sbpackage.api.osgi.model.payment.directdebit;

import sbpackage.api.osgi.model.payment.PaymentPlanWarning;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum DirectDebitTargetWarning {

    TARGET_ACCOUNT_WILL_NOT_SUPPORT_DIRECT_CREDIT_TRANSACTIONS("604070",
            "Account will not support direct debit transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_WILL_NOT_SUPPORT_CLAIMS_FOR_UNPAID_CHEQUE_TRANSACTIONS("604170",
            "Account will not support claims for unpaid cheque transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_WILL_NOT_SUPPORT_LIFE_ASSURANCE_PREMIUMS_TRANSACTIONS("604270",
            "Account will not support life assurance premiums transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_WILL_NOT_SUPPORT_BUILDING_SOCIETY_CREDIT_TRANSACTIONS("604370",
            "Account will support building society credit transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_WILL_NOT_SUPPORT_DIVIDEND_INTEREST_PAYMENT_TRANSACTIONS("604470",
            "Account will not support dividend interest payment transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_WILL_NOT_SUPPORT_AUDDIS_TRANSACTIONS_("604570", "Account will not support " +
            "auddis transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_BANK_OR_ACCOUNT_WILL_NOT_SUPPORT_DD_TRANSACTIONS("605670",
            "Bank or account will not support demand direct transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_NEEDS_A_REFERENCE_OR_ROLL_NUMBER_OR_IS_FOREIGN_CURRENCY_ONLY("605770",
            "Account needs a reference or roll number or is foreign currency only",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_BRANCH_OR_ACCOUNT_WILL_NOT_SUPPORT_AUDDIS_TRANSACTIONS("605870",
            "Branch or account will support auddis transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_BRANCH_IS_DUE_TO_CLOSE_A_NEW_SORT_CODE_WILL_BE_REQUIRED_("605970",
            "Branch is due to close, therefore new sort code will be required",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THERE_ARE_WARNINGS_BUT_CONTINUE_WITH_SETUP_WARNINGS_HAVE_BEEN_LOGGED("606070",
            "There are warnings, but continue with setup",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_OUR_LICENCE_TO_USE_BANK_WIZARD_WILL_EXPIRE_IN_LESS_THAN_30_DAYS("602570",
            "Our license to use bank wizard will expire in less than 30 days",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_IS_A_FOREIGN_CURRENCY_ACCOUNT_("602670",
            "Account is a foreign currency account", PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_MODULUS_CHECKING_CANNOT_BE_APPLIED_TO_THESE_DETAILS("602770",
            "Modulus checking cannot be applied to these details",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_DIRECT_DEBIT_TRANSACTIONS("602870",
            "This branch will not support direct debit transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_ACCOUNT_DETAILS_ARE_NOT_IN_STANDARD_FORM_AND_NEED_TO_BE_TRANSPOSED("602970",
            "Account details are not in standard form and need to be transposed",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_COLLECTION_ACCOUNT_REQUIRES_A_REFERENCE_OR_ROLL_ACCOUNT_NUMBER("603070",
            "This collection account requires a reference or roll account number",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_DIRECT_CREDIT_TRANSACTIONS("603170",
            "This branch will support direct debit transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_AUDDIS_TRANSACTIONS("603270",
            "This branch will not support auddis transactions ",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_CLAIMS_FOR_UNPAID_CHEQUE_TRANSACTIONS("603570",
            "This branch will support claims for unpaid cheque transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_LIFE_ASSURANCE_PREMIUMS_TRANSACTIONS_("603670",
            "This branch will not support life assurance premiums transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_BUILDING_SOCIETY_CREDIT_TRANSACTIONS_("603770",
            "This branch will not support building society credit transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_BRANCH_WILL_NOT_SUPPORT_DIVIDEND_INTEREST_PAYMENT_TRANSACTIONS("603870",
            "This branch will not support dividend interest payment transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    TARGET_THIS_ACCOUNT_WILL_NOT_SUPPORT_DIRECT_DEBIT_TRANSACTIONS("603970",
            "This account will not support direct debit transactions",
            PaymentPlanWarning.DIRECT_DEBIT_WARNING),
    ;

    private static final Map<String, DirectDebitTargetWarning> targetCodeIndex =
            buildTargetCodeIndex();
    private final String targetCode;
    private final String description;
    private final PaymentPlanWarning category;

    DirectDebitTargetWarning(String targetCode, String description,
                             PaymentPlanWarning category) {
        this.targetCode = targetCode;
        this.category = category;
        this.description = description;
    }

    private static final Map<String, DirectDebitTargetWarning> buildTargetCodeIndex() {
        Map<String, DirectDebitTargetWarning> index = new HashMap<>();
        for (DirectDebitTargetWarning directDebitTargetWarning : DirectDebitTargetWarning.values()) {
            index.put(directDebitTargetWarning.targetCode.toUpperCase(), directDebitTargetWarning);
        }
        return Collections.unmodifiableMap(index);

    }

    static public boolean isValid(String targetCode) {
        String standardisedTargetCode = targetCode != null ? targetCode.trim().toUpperCase() : targetCode;
        return targetCodeIndex.get(standardisedTargetCode) != null;
    }

    static public String getDescription(String targetCode) {
        String standardisedTargetCode = targetCode != null ? targetCode.trim().toUpperCase() : targetCode;
        DirectDebitTargetWarning directDebitTargetWarning = targetCodeIndex.get(standardisedTargetCode);
        return directDebitTargetWarning != null ? directDebitTargetWarning.getDescription() : "";
    }

    public String getTargetCode() {
        return targetCode;
    }

    public PaymentPlanWarning getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }
}