package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;
import sbpackage.api.osgi.model.referencedata.RefData;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceProvision implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement
    private RefData measuredIndicator;

    @XmlElement
    private RefData serviceIndicator;

    @XmlElement
    private RefData serviceType;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate serviceStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate tariffStartDate;

    //tricky as 'Active' is passed when Null from IIB.
  /*  @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private String tariffEndDate;*/

    @XmlElement
    private Long serviceProvisionNum;

    @XmlElement
    private String propertyAndServiceProvisionNum;

    @XmlElement
    private String serviceProvisionCode;

    @XmlElement
    private String serviceProvisionDes;

    @XmlElement
    private String tariffCode;

    @XmlElement
    private String tariffDescription;

    @XmlElement
    private boolean isActive;

    @XmlElement
    private BigDecimal total = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal days = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal averageDailyCharge = BigDecimal.ZERO;

    @XmlElement
    private boolean foundInvoiceLine;

    @XmlElement
    private List<ServiceProvisionBudget> serviceProvisionBudgetFromBills;

    @XmlElement
    private List<ServiceProvisionBudget> serviceProvisionBudgetFromCalcs;

    public RefData getMeasuredIndicator() {
        return measuredIndicator;
    }

    public void setMeasuredIndicator(RefData measuredIndicator) {
        this.measuredIndicator = measuredIndicator;
    }

    public RefData getServiceIndicator() {
        return serviceIndicator;
    }

    public void setServiceIndicator(RefData serviceIndicator) {
        this.serviceIndicator = serviceIndicator;
    }

    public RefData getServiceType() {
        return serviceType;
    }

    public void setServiceType(RefData serviceType) {
        this.serviceType = serviceType;
    }

    public LocalDate getServiceStartDate() {
        return serviceStartDate;
    }

    public void setServiceStartDate(LocalDate serviceStartDate) {
        this.serviceStartDate = serviceStartDate;
    }

    public LocalDate getTariffStartDate() {
        return tariffStartDate;
    }

    public void setTariffStartDate(LocalDate tariffStartDate) {
        this.tariffStartDate = tariffStartDate;
    }

    public Long getServiceProvisionNum() {
        return serviceProvisionNum;
    }

    public void setServiceProvisionNum(Long serviceProvisionNum) {
        this.serviceProvisionNum = serviceProvisionNum;
    }

    public String getServiceProvisionCode() {
        return serviceProvisionCode;
    }

    public void setServiceProvisionCode(String serviceProvisionCode) {
        this.serviceProvisionCode = serviceProvisionCode;
    }

    public String getServiceProvisionDes() {
        return serviceProvisionDes;
    }

    public void setServiceProvisionDes(String serviceProvisionDes) {
        this.serviceProvisionDes = serviceProvisionDes;
    }

    public String getTariffCode() {
        return tariffCode;
    }

    public void setTariffCode(String tariffCode) {
        this.tariffCode = tariffCode;
    }

    public String getTariffDescription() {
        return tariffDescription;
    }

    public void setTariffDescription(String tariffDescription) {
        this.tariffDescription = tariffDescription;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getDays() {
        return days;
    }

    public void setDays(BigDecimal days) {
        this.days = days;
    }

    public BigDecimal getAverageDailyCharge() {
        return averageDailyCharge;
    }

    public void setAverageDailyCharge(BigDecimal averageDailyCharge) {
        this.averageDailyCharge = averageDailyCharge;
    }

    public String getPropertyAndServiceProvisionNum() {
        return propertyAndServiceProvisionNum;
    }

    public void setPropertyAndServiceProvisionNum(String propertyAndServiceProvisionNum) {
        this.propertyAndServiceProvisionNum = propertyAndServiceProvisionNum;
    }

    public boolean isFoundInvoiceLine() {
        return foundInvoiceLine;
    }

    public void setFoundInvoiceLine(final boolean foundInvoiceLine) {
        this.foundInvoiceLine = foundInvoiceLine;
    }

    public List<ServiceProvisionBudget> getServiceProvisionBudgetFromBills() {
        return serviceProvisionBudgetFromBills;
    }

    public void setServiceProvisionBudgetFromBills(final List<ServiceProvisionBudget> serviceProvisionBudgetFromBills) {
        this.serviceProvisionBudgetFromBills = serviceProvisionBudgetFromBills;
    }

    public List<ServiceProvisionBudget> getServiceProvisionBudgetFromCalcs() {
        return serviceProvisionBudgetFromCalcs;
    }

    public void setServiceProvisionBudgetFromCalcs(final List<ServiceProvisionBudget> serviceProvisionBudgetFromCalcs) {
        this.serviceProvisionBudgetFromCalcs = serviceProvisionBudgetFromCalcs;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("measuredIndicator", measuredIndicator)
                .append("serviceIndicator", serviceIndicator)
                .append("serviceType", serviceType)
                .append("serviceStartDate", serviceStartDate)
                .append("tariffStartDate", tariffStartDate)
                .append("serviceProvisionNum", serviceProvisionNum)
                .append("propertyAndServiceProvisionNum", propertyAndServiceProvisionNum)
                .append("serviceProvisionCode", serviceProvisionCode)
                .append("serviceProvisionDes", serviceProvisionDes)
                .append("tariffCode", tariffCode)
                .append("tariffDescription", tariffDescription)
                .append("isActive", isActive)
                .append("total", total)
                .append("days", days)
                .append("averageDailyCharge", averageDailyCharge)
                .append("foundInvoiceLine", foundInvoiceLine)
                .append("serviceProvisionBudgetFromBills", serviceProvisionBudgetFromBills)
                .append("serviceProvisionBudgetFromCalcs", serviceProvisionBudgetFromCalcs)
                .toString();
    }
}
