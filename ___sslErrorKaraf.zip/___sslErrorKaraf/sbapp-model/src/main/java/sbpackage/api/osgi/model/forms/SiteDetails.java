package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SiteDetails {

    private SiteLocation siteLocation;
    private SiteAddress siteAddress;
    private SiteGreenfieldHistory siteGreenfieldHistory;
    private SiteApplicationsHistory siteApplicationsHistory;
    private SiteAdjacentProposal siteAdjacentProposal;
    private DevelopmentTypeAndSize developmentTypeAndSize;

    private PreviousUseOfLand previousUseOfLand;
    private PropertiesPreviouslyOnSite propertiesPreviouslyOnSite;
    private FurtherDetailsOfProperties furtherDetailsOfProperties;
    private HasPreviousPropertyFittings hasPreviousPropertyFittings;
    private Fittings previousPropertyFittings;

    public SiteLocation getSiteLocation() {
        return siteLocation;
    }

    public void setSiteLocation(SiteLocation siteLocation) {
        this.siteLocation = siteLocation;
    }

    public SiteAddress getSiteAddress() {
        return siteAddress;
    }

    public void setSiteAddress(SiteAddress siteAddress) {
        this.siteAddress = siteAddress;
    }

    public SiteGreenfieldHistory getSiteGreenfieldHistory() {
        return siteGreenfieldHistory;
    }

    public void setSiteGreenfieldHistory(SiteGreenfieldHistory siteGreenfieldHistory) {
        this.siteGreenfieldHistory = siteGreenfieldHistory;
    }

    public SiteApplicationsHistory getSiteApplicationsHistory() {
        return siteApplicationsHistory;
    }

    public void setSiteApplicationsHistory(SiteApplicationsHistory siteApplicationsHistory) {
        this.siteApplicationsHistory = siteApplicationsHistory;
    }

    public SiteAdjacentProposal getSiteAdjacentProposal() {
        return siteAdjacentProposal;
    }

    public void setSiteAdjacentProposal(SiteAdjacentProposal siteAdjacentProposal) {
        this.siteAdjacentProposal = siteAdjacentProposal;
    }

    public DevelopmentTypeAndSize getDevelopmentTypeAndSize() {
        return developmentTypeAndSize;
    }

    public void setDevelopmentTypeAndSize(DevelopmentTypeAndSize developmentTypeAndSize) {
        this.developmentTypeAndSize = developmentTypeAndSize;
    }

    public PreviousUseOfLand getPreviousUseOfLand() {
        return previousUseOfLand;
    }

    public void setPreviousUseOfLand(PreviousUseOfLand previousUseOfLand) {
        this.previousUseOfLand = previousUseOfLand;
    }

    public PropertiesPreviouslyOnSite getPropertiesPreviouslyOnSite() {
        return propertiesPreviouslyOnSite;
    }

    public void setPropertiesPreviouslyOnSite(PropertiesPreviouslyOnSite propertiesPreviouslyOnSite) {
        this.propertiesPreviouslyOnSite = propertiesPreviouslyOnSite;
    }

    public FurtherDetailsOfProperties getFurtherDetailsOfProperties() {
        return furtherDetailsOfProperties;
    }

    public void setFurtherDetailsOfProperties(FurtherDetailsOfProperties furtherDetailsOfProperties) {
        this.furtherDetailsOfProperties = furtherDetailsOfProperties;
    }

    public HasPreviousPropertyFittings getHasPreviousPropertyFittings() {
        return hasPreviousPropertyFittings;
    }

    public void setHasPreviousPropertyFittings(HasPreviousPropertyFittings hasPreviousPropertyFittings) {
        this.hasPreviousPropertyFittings = hasPreviousPropertyFittings;
    }

    public Fittings getPreviousPropertyFittings() {
        return previousPropertyFittings;
    }

    public void setPreviousPropertyFittings(Fittings previousPropertyFittings) {
        this.previousPropertyFittings = previousPropertyFittings;
    }
}
