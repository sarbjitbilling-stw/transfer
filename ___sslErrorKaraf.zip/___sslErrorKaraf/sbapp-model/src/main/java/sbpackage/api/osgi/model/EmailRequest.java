package sbpackage.api.osgi.model;


import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Map;

@XmlRootElement(name = "EmailRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailRequest extends SendEmailRequest{


    @XmlElement(name = "linkId")
    private String linkId;

    @XmlElement(name = "token")
    private String token;

    @XmlElement(name = "journeyName")
    private JourneyType journeyName;

    @XmlElement(name = "emailLinkPrefix")
    private String emailLinkPrefix;

    @XmlElement(name = "hoursBeforeLinkExpires")
    private int hoursBeforeLinkExpires;

    @XmlElement(name = "subject")
    private String subject;

    @XmlElement(name = "fieldData")
    private Map<String, String> fieldData;

    @XmlElement(name = "username")
    private String username;

    public JourneyType getJourneyName() {
        return journeyName;
    }

    public void setJourneyName(JourneyType journeyName) {
        this.journeyName = journeyName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Map<String, String> getFieldData() {
        return fieldData;
    }

    public void setFieldData(Map<String, String> fieldData) {
        this.fieldData = fieldData;
    }

    public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getEmailLinkPrefix() {
        return emailLinkPrefix;
    }

    public void setEmailLinkPrefix(String emailLinkPrefix) {
        this.emailLinkPrefix = emailLinkPrefix;
    }

    public int getHoursBeforeLinkExpires() {
        return hoursBeforeLinkExpires;
    }

    public void setHoursBeforeLinkExpires(int hoursBeforeLinkExpires) {
        this.hoursBeforeLinkExpires = hoursBeforeLinkExpires;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
