package sbpackage.api.osgi.model;

import java.util.Arrays;

public class DownloadBillsResponse {
    private byte documentBytes[];
    private String fileName;

    public byte[] getDocumentBytes() {
        return documentBytes;
    }

    public void setDocumentBytes(byte[] documentBytes) {
        this.documentBytes = documentBytes;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DownloadBillsResponse that = (DownloadBillsResponse) o;

        if (!Arrays.equals(documentBytes, that.documentBytes)) return false;
        return fileName != null ? fileName.equals(that.fileName) : that.fileName == null;
    }

    @Override
    public int hashCode() {
        int result = Arrays.hashCode(documentBytes);
        result = 31 * result + (fileName != null ? fileName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "DownloadBillsResponse{" +
                "documentBytes=" + Arrays.toString(documentBytes) +
                ", fileName='" + fileName + '\'' +
                '}';
    }
}
