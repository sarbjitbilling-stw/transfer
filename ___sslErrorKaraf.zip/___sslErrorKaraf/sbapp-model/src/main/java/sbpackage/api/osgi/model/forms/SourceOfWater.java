package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import sbpackage.api.osgi.model.util.ISODateTimeToInstantAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.Instant;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SourceOfWater {

    @XmlJavaTypeAdapter(ISODateTimeToInstantAdapter.class)
    private Instant sourceOfWaterDate;
    private boolean dateUnknown;

    public Instant getSourceOfWaterDate() {
        return sourceOfWaterDate;
    }

    public void setSourceOfWaterDate(Instant sourceOfWaterDate) {
        this.sourceOfWaterDate = sourceOfWaterDate;
    }
    
    public boolean isDateUnknown() {
        return dateUnknown;
    }

    public void setDateUnknown(boolean dateUnknown) {
        this.dateUnknown = dateUnknown;
    }

}
