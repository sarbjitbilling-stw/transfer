package sbpackage.api.osgi.model.waterservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * Created by rtai on 24/07/2017.
 */
@XmlType(name="ProvisionTypeEnum")
@XmlEnum(String.class)
public enum ServiceType {

	@XmlEnumValue("FRESH_WATER") FRESH_WATER("F", "W"),
	@XmlEnumValue("WASTE_WATER") WASTE_WATER("W", "S"),
	@XmlEnumValue("SURFACE_WATER") SURFACE_WATER_DRAINAGE("D", "MSWD"),
	@XmlEnumValue("UNMEASURED_SEWERAGE") UNMEASURED_WASTE_WATER("B", "US"),
  @XmlEnumValue("HIGHWAY_DRAINAGE") HIGHWAY_DRAINAGE("H", "HIGHD");
	
	private String indicator;

	private String provisionCode;

	ServiceType(String indicator, String provisionCode) {
		this.indicator = indicator;
		this.provisionCode = provisionCode;
	}

	public String getIndicator() {
		return this.indicator;
	}

	public String getProvisionCode() {
		return this.provisionCode;
	}

	public static ServiceType fromIndicatorValue(String indicator) {
		for (ServiceType st : ServiceType.values()) {
			if (st.getIndicator().equalsIgnoreCase(indicator)) {
				return st;
			}
		}
		return null;
	}
}
