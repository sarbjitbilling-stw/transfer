package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Arrears implements Serializable {

    private static final long serialVersionUID = 1L;

    public Arrears() {
    }

    public Arrears(BigDecimal accountArrears, BigDecimal thirdPartyCharges) {
        this.accountArrears = accountArrears;
        this.thirdPartyCharges = thirdPartyCharges;
    }

    @XmlElement
    private BigDecimal accountArrears = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal thirdPartyCharges = BigDecimal.ZERO;

    public BigDecimal getTotalArrears() {
        return accountArrears.add(thirdPartyCharges);
    }

    public BigDecimal getAccountArrears() {
        return accountArrears;
    }

    public void setAccountArrears(BigDecimal accountArrears) {
        this.accountArrears = accountArrears;
    }

    public BigDecimal getThirdPartyCharges() {
        return thirdPartyCharges;
    }

    public void setThirdPartyCharges(BigDecimal thirdPartyCharges) {
        this.thirdPartyCharges = thirdPartyCharges;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountArrears", accountArrears)
                .append("thirdPartyCharges", thirdPartyCharges)
                .toString();
    }
}
