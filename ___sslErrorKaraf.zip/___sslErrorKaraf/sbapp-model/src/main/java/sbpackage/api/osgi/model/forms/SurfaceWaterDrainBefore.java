package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SurfaceWaterDrainBefore {

    private Float surfaceWaterDrainBefore;
    private boolean noSurfaceWaterDrainBefore;

    public boolean isNoSurfaceWaterDrainBefore() {
        return noSurfaceWaterDrainBefore;
    }

    public void setNoSurfaceWaterDrainBefore(boolean noSurfaceWaterDrainBefore) {
        this.noSurfaceWaterDrainBefore = noSurfaceWaterDrainBefore;
    }

    public Float getSurfaceWaterDrainBefore() {
        return surfaceWaterDrainBefore;
    }

    public void setSurfaceWaterDrainBefore(Float surfaceWaterDrainBefore) {
        this.surfaceWaterDrainBefore = surfaceWaterDrainBefore;
    }
}
