package sbpackage.api.osgi.model.transaction;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.DateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactRecord {

    @JsonProperty("contactInitiatedBy")
    @XmlElement(name = "contactInitiatedBy")
    private RefData contactInitiatedBy;

    @JsonProperty("contactMethod")
    @XmlElement(name = "contactMethod")
    private RefData contactMethod;
    
    @JsonProperty("contactType")
    @XmlElement(name = "contactType")
    private RefData contactType;
    
    @JsonProperty("contactSubType")
    @XmlElement(name = "contactSubType")
    private String contactSubType;
    
    @JsonProperty("contactSubTypeDes")
    @XmlElement(name = "contactSubTypeDes")
    private String contactSubTypeDes;
    
    @JsonProperty("defaultFlag")
    @XmlElement(name = "defaultFlag")
    private String defaultFlag;

    @JsonProperty("complaintReceivedFlag")
    @XmlElement(name = "complaintReceivedFlag")
    private String complaintReceivedFlag;
    
    @JsonProperty("substituteRespFlag")
    @XmlElement(name = "substituteRespFlag")
    private String substituteRespFlag;
    
    @JsonProperty("substituteRespFlagUpdate")
    @XmlElement(name = "substituteRespFlagUpdate")
    private String substituteRespFlagUpdate;
    
    @JsonProperty("subResdate")
    @XmlElement(name = "subResdate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate subResdate;
    
    @JsonProperty("resolution")
    @XmlElement(name = "resolution")
    private RefData resolution;
    
    @JsonProperty("repeatReqFlag")
    @XmlElement(name = "repeatReqFlag")
    private String repeatReqFlag;
    
    @JsonProperty("attachmentLocation")
    @XmlElement(name = "attachmentLocation")
    private String attachmentLocation; 
    
    @JsonProperty("actQueueSourceCode")
    @XmlElement(name = "actQueueSourceCode")
    private RefData actQueueSourceCode;
    
    @JsonProperty("actTypeCode")
    @XmlElement(name = "actTypeCode")
    private String actTypeCode; 
    
    @JsonProperty("orgNum")
    @XmlElement(name = "orgNum")
    private Long orgNum;
    
    @JsonProperty("orgUnit")
    @XmlElement(name = "orgUnit")
    private String orgUnit; 
    
    @JsonProperty("empNum")
    @XmlElement(name = "empNum")
    private String empNum;
    
    @JsonProperty("actPriority")
    @XmlElement(name = "actPriority")
    private RefData actPriority;
    
    @JsonProperty("actSubType")
    @XmlElement(name = "actSubType")
    private String actSubType; 
    
    @JsonProperty("dueDate")
    @XmlElement(name = "dueDate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate dueDate;
    
    @JsonProperty("contactPackageId")
    @XmlElement(name = "contactPackageId")
    private Long contactPackageId;
    
    @JsonProperty("contactResolvedDate")
    @XmlElement(name = "contactResolvedDate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate contactResolvedDate;
    
    @JsonProperty("resolvedEmpName")
    @XmlElement(name = "resolvedEmpName")
    private String resolvedEmpName; 
    
    @JsonProperty("subResEmpName")
    @XmlElement(name = "subResEmpName")
    private String subResEmpName;
    
    @JsonProperty("actId")
    @XmlElement(name = "actId")
    private Long actId;
    
    @JsonProperty("actQueueAssignedDate")
    @XmlElement(name = "actQueueAssignedDate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate actQueueAssignedDate;
    
    @JsonProperty("createdEmpName")
    @XmlElement(name = "createdEmpName")
    private String createdEmpName;
    
    @JsonProperty("hisChangeFlag")
    @XmlElement(name = "hisChangeFlag")
    private String hisChangeFlag;
    
    @JsonProperty("notesType")
    @XmlElement(name = "notesType")
    private RefData notesType;
    
    @JsonProperty("notesDescription")
    @XmlElement(name = "notesDescription")
    private String notesDescription;
    
    @JsonProperty("actType")
    @XmlElement(name = "actType")
    private String actType;
    
    @JsonProperty("assignedDate")
    @XmlElement(name = "assignedDate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate assignedDate;
    
    @JsonProperty("orgName")
    @XmlElement(name = "orgName")
    private String orgName;
    
    @JsonProperty("empName")
    @XmlElement(name = "empName")
    private String empName;
    
    @JsonProperty("actDescription")
    @XmlElement(name = "actDescription")
    private String actDescription;

	public RefData getContactInitiatedBy() {
		return contactInitiatedBy;
	}

	public void setContactInitiatedBy(RefData contactInitiatedBy) {
		this.contactInitiatedBy = contactInitiatedBy;
	}

	public RefData getContactMethod() {
		return contactMethod;
	}

	public void setContactMethod(RefData contactMethod) {
		this.contactMethod = contactMethod;
	}

	public RefData getContactType() {
		return contactType;
	}

	public void setContactType(RefData contactType) {
		this.contactType = contactType;
	}

	public String getContactSubType() {
		return contactSubType;
	}

	public void setContactSubType(String contactSubType) {
		this.contactSubType = contactSubType;
	}

	public String getContactSubTypeDes() {
		return contactSubTypeDes;
	}

	public void setContactSubTypeDes(String contactSubTypeDes) {
		this.contactSubTypeDes = contactSubTypeDes;
	}

	public String getDefaultFlag() {
		return defaultFlag;
	}

	public void setDefaultFlag(String defaultFlag) {
		this.defaultFlag = defaultFlag;
	}

	public String getComplaintReceivedFlag() {
		return complaintReceivedFlag;
	}

	public void setComplaintReceivedFlag(String complaintReceivedFlag) {
		this.complaintReceivedFlag = complaintReceivedFlag;
	}

	public String getSubstituteRespFlag() {
		return substituteRespFlag;
	}

	public void setSubstituteRespFlag(String substituteRespFlag) {
		this.substituteRespFlag = substituteRespFlag;
	}

	public String getSubstituteRespFlagUpdate() {
		return substituteRespFlagUpdate;
	}

	public void setSubstituteRespFlagUpdate(String substituteRespFlagUpdate) {
		this.substituteRespFlagUpdate = substituteRespFlagUpdate;
	}

	public LocalDate getSubResdate() {
		return subResdate;
	}

	public void setSubResdate(LocalDate subResdate) {
		this.subResdate = subResdate;
	}

	public RefData getResolution() {
		return resolution;
	}

	public void setResolution(RefData resolution) {
		this.resolution = resolution;
	}

	public String getRepeatReqFlag() {
		return repeatReqFlag;
	}

	public void setRepeatReqFlag(String repeatReqFlag) {
		this.repeatReqFlag = repeatReqFlag;
	}

	public String getAttachmentLocation() {
		return attachmentLocation;
	}

	public void setAttachmentLocation(String attachmentLocation) {
		this.attachmentLocation = attachmentLocation;
	}

	public RefData getActQueueSourceCode() {
		return actQueueSourceCode;
	}

	public void setActQueueSourceCode(RefData actQueueSourceCode) {
		this.actQueueSourceCode = actQueueSourceCode;
	}

	public String getActTypeCode() {
		return actTypeCode;
	}

	public void setActTypeCode(String actTypeCode) {
		this.actTypeCode = actTypeCode;
	}

	public Long getOrgNum() {
		return orgNum;
	}

	public void setOrgNum(Long orgNum) {
		this.orgNum = orgNum;
	}

	public String getOrgUnit() {
		return orgUnit;
	}

	public void setOrgUnit(String orgUnit) {
		this.orgUnit = orgUnit;
	}

	public String getEmpNum() {
		return empNum;
	}

	public void setEmpNum(String empNum) {
		this.empNum = empNum;
	}

	public RefData getActPriority() {
		return actPriority;
	}

	public void setActPriority(RefData actPriority) {
		this.actPriority = actPriority;
	}

	public String getActSubType() {
		return actSubType;
	}

	public void setActSubType(String actSubType) {
		this.actSubType = actSubType;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public Long getContactPackageId() {
		return contactPackageId;
	}

	public void setContactPackageId(Long contactPackageId) {
		this.contactPackageId = contactPackageId;
	}

	public LocalDate getContactResolvedDate() {
		return contactResolvedDate;
	}

	public void setContactResolvedDate(LocalDate contactResolvedDate) {
		this.contactResolvedDate = contactResolvedDate;
	}

	public String getResolvedEmpName() {
		return resolvedEmpName;
	}

	public void setResolvedEmpName(String resolvedEmpName) {
		this.resolvedEmpName = resolvedEmpName;
	}

	public String getSubResEmpName() {
		return subResEmpName;
	}

	public void setSubResEmpName(String subResEmpName) {
		this.subResEmpName = subResEmpName;
	}

	public Long getActId() {
		return actId;
	}

	public void setActId(Long actId) {
		this.actId = actId;
	}

	public LocalDate getActQueueAssignedDate() {
		return actQueueAssignedDate;
	}

	public void setActQueueAssignedDate(LocalDate actQueueAssignedDate) {
		this.actQueueAssignedDate = actQueueAssignedDate;
	}

	public String getCreatedEmpName() {
		return createdEmpName;
	}

	public void setCreatedEmpName(String createdEmpName) {
		this.createdEmpName = createdEmpName;
	}

	public String getHisChangeFlag() {
		return hisChangeFlag;
	}

	public void setHisChangeFlag(String hisChangeFlag) {
		this.hisChangeFlag = hisChangeFlag;
	}

	public RefData getNotesType() {
		return notesType;
	}

	public void setNotesType(RefData notesType) {
		this.notesType = notesType;
	}

	public String getNotesDescription() {
		return notesDescription;
	}

	public void setNotesDescription(String notesDescription) {
		this.notesDescription = notesDescription;
	}

	public String getActType() {
		return actType;
	}

	public void setActType(String actType) {
		this.actType = actType;
	}

	public LocalDate getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(LocalDate assignedDate) {
		this.assignedDate = assignedDate;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getActDescription() {
		return actDescription;
	}

	public void setActDescription(String actDescription) {
		this.actDescription = actDescription;
	}    
   
}
