package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ConnectionPhase {

    private PropertyTotals propertyTotalsPhased;
    private TotalUnitArea totalUnitArea;
    private ProcessWater processWaterPhased;
    private CommercialFittings commercialFittingsPhased;
    private RequireFittings requireFittings;

    public PropertyTotals getPropertyTotalsPhased() {
        return propertyTotalsPhased;
    }

    public void setPropertyTotalsPhased(PropertyTotals propertyTotalsPhased) {
        this.propertyTotalsPhased = propertyTotalsPhased;
    }

    public TotalUnitArea getTotalUnitArea() {
        return totalUnitArea;
    }

    public void setTotalUnitArea(TotalUnitArea totalUnitArea) {
        this.totalUnitArea = totalUnitArea;
    }

    public ProcessWater getProcessWaterPhased() {
        return processWaterPhased;
    }

    public void setProcessWaterPhased(ProcessWater processWaterPhased) {
        this.processWaterPhased = processWaterPhased;
    }

    public int getPropertyCount() {
        return propertyTotalsPhased != null ? propertyTotalsPhased.getPropertyCount() : 0;
    }

    public boolean isAtLeastOnePropertyCommercial() {
        return propertyTotalsPhased != null && propertyTotalsPhased.isAtLeastOnePropertyCommercial();
    }

    public CommercialFittings getCommercialFittingsPhased() {
        return commercialFittingsPhased;
    }

    public CommercialFittings getAllCommercialFittingsPhased() {
        if(commercialFittingsPhased==null && this.propertyTotalsPhased.getCommercialTotal()>0) {
            return new CommercialFittings();
        }
        return commercialFittingsPhased;
    }

    public void setCommercialFittingsPhased(CommercialFittings commercialFittingsPhased) {
        this.commercialFittingsPhased = commercialFittingsPhased;
    }

    public RequireFittings getRequireFittings() {
        return requireFittings;
    }

    public void setRequireFittings(RequireFittings requireFittings) {
        this.requireFittings = requireFittings;
    }
}
