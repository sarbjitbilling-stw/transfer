package sbpackage.api.osgi.model.calculator.offers;

public enum AccountEventStatus {
    UNPAID("UNPAID"),
    PAID("PAID"),
    PART_PAID("PART PAID"),
    CANCELLED("CANCELLED");

    private final String status;

    AccountEventStatus(String status){
        this.status = status;
    }

    public String getStatus()
    {
        return this.status;
    }

}
