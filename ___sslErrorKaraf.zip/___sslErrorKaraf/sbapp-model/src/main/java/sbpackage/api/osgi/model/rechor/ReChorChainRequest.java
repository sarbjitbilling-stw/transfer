package sbpackage.api.osgi.model.rechor;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

@XmlRootElement(name = "ReChorChainRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ReChorChainRequest implements Serializable {

    @XmlElement

    private List<AccountChainRequest> accountChainRequests;

    @XmlElement
    private TargetAccountNumber callerAccountNumber;

    public List<AccountChainRequest> getAccountChainRequests() {
        return accountChainRequests;
    }

    public void setAccountChainRequests(final List<AccountChainRequest> accountChainRequests) {
        this.accountChainRequests = accountChainRequests;
    }

    public TargetAccountNumber getCallerAccountNumber() {
        return callerAccountNumber;
    }

    public void setCallerAccountNumber(final TargetAccountNumber callerAccountNumber) {
        this.callerAccountNumber = callerAccountNumber;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountChainRequests", accountChainRequests)
                .append("callerAccountNumber", callerAccountNumber)
                .toString();
    }
}