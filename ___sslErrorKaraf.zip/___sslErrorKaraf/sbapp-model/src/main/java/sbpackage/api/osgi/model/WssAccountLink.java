package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "WssAccountLink")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WssAccountLink implements Serializable{

	@JsonProperty("selectedAccountNumber")
	@XmlElement(name = "selectedAccountNumber")
	private TargetAccountNumber selectedAccountNumber;

	@JsonProperty("selectedLeNumber")
	@XmlElement(name = "selectedLeNumber")
	private String selectedLeNumber;

	@JsonProperty("accountNumber")
	@XmlElement(name = "accountNumber")
	private TargetAccountNumber accountNumber;

	@JsonProperty("postcode")
	@XmlElement(name = "postcode")
	private String postcode;

	@JsonProperty("leNumber")
	@XmlElement(name = "leNumber")
	private String leNumber;

	public WssAccountLink() {
	}

	public WssAccountLink(TargetAccountNumber selectedAccountNumber, String selectedLeeNumber, TargetAccountNumber newAccountNumber, String newLeNumber, String postcode) {
		this.selectedAccountNumber = selectedAccountNumber;
		this.selectedLeNumber = selectedLeeNumber;
		this.accountNumber = newAccountNumber;
		this.postcode = postcode;
		this.leNumber = newLeNumber;
	}

	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getLeNumber() {
		return leNumber;
	}

	public void setLeNumber(String leNumber) {
		this.leNumber = leNumber;
	}

	public TargetAccountNumber getSelectedAccountNumber() {
		return selectedAccountNumber;
	}

	public void setSelectedAccountNumber(TargetAccountNumber selectedAccountNumber) {
		this.selectedAccountNumber = selectedAccountNumber;
	}

	public String getSelectedLeNumber() {
		return selectedLeNumber;
	}

	public void setSelectedLeNumber(String selectedLeNumber) {
		this.selectedLeNumber = selectedLeNumber;
	}

	/**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private static String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    } 
    
}
