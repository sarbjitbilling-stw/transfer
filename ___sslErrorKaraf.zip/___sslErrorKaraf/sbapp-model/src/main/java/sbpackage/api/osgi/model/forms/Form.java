package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.util.LocalDateTimeAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static sbpackage.api.osgi.model.forms.FormCategory.WATER_MAIN_REQUISITION;
import static sbpackage.api.osgi.model.forms.FormPaymentDetails.SUCCESS;

@XmlRootElement(name = "Form")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Form {

    public static final String CONFIG_FILE_UPLOAD_MAX_SIZE = "maxSize";
    public static final String CONFIG_FILE_UPLOAD_ALLOWED_EXTENSIONS = "allowedExtensions";
    public static final String CONFIG_FILE_UPLOAD = "fileUpload";
    public static final String CONFIG_FILE_UPLOAD_MAX_FILES_PER_SECTION = "maxFilesPerSection";

    @JsonIgnore
    private Long id;
    private String reference;
    private Applicant applicantId = new Applicant();
    private FormData formData;

    @JsonProperty("completed")
    @XmlElement(name = "completed")
    private Boolean submitted;

    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime createdDate;

    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime lastUpdateDate;

    private String analyticsId;
    private FormType formType;
    private Set<FormAttachment> formAttachments = new HashSet<>();

    @JsonIgnore
    private Set<FormPaymentDetails> formPaymentDetailsHistory = new HashSet<>();

    private FormPaymentDetails formPaymentDetails;
    private Map<String, Object> config = new HashMap<>();
    private int modelVersion;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return applicantId.getCustomerName();
    }

    public void setCustomerName(String customerName) {
        this.applicantId.setCustomerName(customerName);
    }

    public String getEmailAddress() {
        return applicantId.getEmailAddress();
    }

    public void setEmailAddress(String emailAddress) {
        applicantId.setEmailAddress(emailAddress);
    }

    public String getPhoneNumber() {
        return applicantId.getPhoneNumber();
    }

    public void setPhoneNumber(String phoneNumber) {
        applicantId.setPhoneNumber(phoneNumber);
    }

    public Boolean getSubmitted() {
        return submitted;
    }

    public void setSubmitted(Boolean submitted) {
        this.submitted = submitted;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(LocalDateTime lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAnalyticsId() {
        return analyticsId;
    }

    public void setAnalyticsId(String analyticsId) {
        this.analyticsId = analyticsId;
    }

    public FormType getFormType() {
        return formType;
    }

    public void setFormType(FormType formType) {
        this.formType = formType;
    }

    public Set<FormAttachment> getFormAttachments() {
        return formAttachments;
    }

    public void setFormAttachments(Set<FormAttachment> formAttachments) {
        this.formAttachments = formAttachments;
    }

    public FormData getFormData() {
        return formData;
    }

    public void setFormData(FormData formData) {
        this.formData = formData;
    }

    public Applicant getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(Applicant applicantId) {
        this.applicantId = applicantId;
    }

    public String getPostcode() {
        return applicantId.getPostcode();
    }

    public void setPostcode(String postcode) {
        applicantId.setPostcode(postcode);
    }

    public FormCategory getFormCategory() {
        return formType != null ? FormCategory.lookupByType(getFormType()) : null;
    }

    public String getFormCategoryDescription() {
        FormCategory formCategory = getFormCategory();
        if(WATER_MAIN_REQUISITION == formCategory && getFormData().getWaterMainRequisitionDetails() != null) {
            return getFormData().getWaterMainRequisitionDetails().getCategoryDescription();
        } else {
            return formCategory.toString();
        }
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Set<FormPaymentDetails> getFormPaymentDetailsHistory() {
        return formPaymentDetailsHistory;
    }

    public void setFormPaymentDetailsHistory(Set<FormPaymentDetails> formPaymentDetailsHistory) {
        this.formPaymentDetailsHistory = formPaymentDetailsHistory;
    }

    public FormPaymentDetails getFormPaymentDetails() {
        return formPaymentDetails;
    }

    public void setFormPaymentDetails(FormPaymentDetails formPaymentDetails) {
        this.formPaymentDetails = formPaymentDetails;
    }

    public Map<String, Object> getConfig() {
        return config;
    }

    public boolean hasCompletedCardPayment() {
        return Boolean.TRUE.equals(submitted) &&
                formPaymentDetailsHistory.stream().anyMatch(paymentDetails -> SUCCESS.equals(paymentDetails.getOutcome()));
    }

    public int getModelVersion() {
        return modelVersion;
    }

    public void setModelVersion(int modelVersion) {
        this.modelVersion = modelVersion;
    }

    public void setFileUploadConfig(long maxSize, int maxFilesPerSection, List<String> allowedExtensions){
        Map<String, Object> fileUploadConfig = new HashMap<>();
        fileUploadConfig.put(CONFIG_FILE_UPLOAD_MAX_SIZE, maxSize);
        fileUploadConfig.put(CONFIG_FILE_UPLOAD_MAX_FILES_PER_SECTION, maxFilesPerSection);
        fileUploadConfig.put(CONFIG_FILE_UPLOAD_ALLOWED_EXTENSIONS, allowedExtensions);
        config.put(CONFIG_FILE_UPLOAD, fileUploadConfig);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("reference", reference)
                .append("applicantId", applicantId)
                .append("formData", formData)
                .append("submitted", submitted)
                .append("createdDate", createdDate)
                .append("lastUpdateDate", lastUpdateDate)
                .append("analyticsId", analyticsId)
                .append("formType", formType)
                .append("formAttachments", formAttachments)
                .append("formPaymentDetailsHistory", formPaymentDetailsHistory)
                .append("formPaymentDetails", formPaymentDetails)
                .append("config", config)
                .append("modelVersion", modelVersion)
                .toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Form form = (Form) o;

        return new EqualsBuilder()
                .append(id, form.id)
                .append(reference, form.reference)
                .append(applicantId, form.applicantId)
                .append(formData, form.formData)
                .append(submitted, form.submitted)
                .append(createdDate, form.createdDate)
                .append(lastUpdateDate, form.lastUpdateDate)
                .append(analyticsId, form.analyticsId)
                .append(formType, form.formType)
                .append(formAttachments, form.formAttachments)
                .append(formPaymentDetailsHistory, form.formPaymentDetailsHistory)
                .append(formPaymentDetails, form.formPaymentDetails)
                .append(modelVersion, form.modelVersion)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(reference)
                .append(applicantId)
                .append(formData)
                .append(submitted)
                .append(createdDate)
                .append(lastUpdateDate)
                .append(analyticsId)
                .append(formType)
                .append(formAttachments)
                .append(formPaymentDetailsHistory)
                .append(formPaymentDetails)
                .append(modelVersion)
                .toHashCode();
    }

}
