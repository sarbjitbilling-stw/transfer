package sbpackage.api.osgi.model;

/**
 * Created by ppahwa on 28/04/2017.
 */
public enum RoleType {

    PRIMARY("P"),
    CO_PRIMARY("C"),
    P_COL_PRE_CLM("O"),
    P_COL_POST_JDG("U"),
    NOMINEE("N"),
    CUSTOMER_REP("4"),
    THIRD_PARTY("3"),
    EXTERNAL_AGENCY("E");

    private String value;

    RoleType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
