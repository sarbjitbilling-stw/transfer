package sbpackage.api.osgi.model.transaction;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.DateAdapter;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactEvent {

    @JsonProperty("legalEntityName")
    @XmlElement(name = "legalEntityName")
    private String legalEntityName;

    @JsonProperty("address")
    @XmlElement(name = "address")
    private String address;

    @JsonProperty("contactTime")
    @XmlElement(name = "contactTime")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate contactTime;

    @JsonProperty("contactTypeDes")
    @XmlElement(name = "contactTypeDes")
    private String contactTypeDes;

    @JsonProperty("contactSubTypeDes")
    @XmlElement(name = "contactSubTypeDes")
    private String contactSubTypeDes;

    @JsonProperty("contactMethod")
    @XmlElement(name = "contactMethod")
    private String contactMethod;

    @JsonProperty("contactResolvedTime")
    @XmlElement(name = "contactResolvedTime")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate contactResolvedTime;

    @JsonProperty("pointOfContactResolved")
    @XmlElement(name = "pointOfContactResolved")
    private String pointOfContactResolved;

    @JsonProperty("contactPrintedFlag")
    @XmlElement(name = "contactPrintedFlag")
    private String contactPrintedFlag;

    @JsonProperty("attachmentTypeInd")
    @XmlElement(name = "attachmentTypeInd")
    private String attachmentTypeInd;

    @JsonProperty("userName")
    @XmlElement(name = "userName")
    private String userName;

    @JsonProperty("workStartedFlag")
    @XmlElement(name = "workStartedFlag")
    private String workStartedFlag;

    @JsonProperty("dueDate")
    @XmlElement(name = "dueDate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate dueDate;

    @JsonProperty("priorityStatus")
    @XmlElement(name = "priorityStatus")
    private RefData priorityStatus;

    @JsonProperty("numOfDays")
    @XmlElement(name = "numOfDays")
    private Long numOfDays;

    @JsonProperty("linkedFlag")
    @XmlElement(name = "linkedFlag")
    private String linkedFlag;

    @JsonProperty("attachmentLocation")
    @XmlElement(name = "attachmentLocation")
    private String attachmentLocation;

    @JsonProperty("contactId")
    @XmlElement(name = "contactId")
    private Long contactId;

    @JsonProperty("contactPackageId")
    @XmlElement(name = "contactPackageId")
    private Long contactPackageId;

    @JsonProperty("activityQueueItemId")
    @XmlElement(name = "activityQueueItemId")
    private Long activityQueueItemId;

    @JsonProperty("cyclicCheckNum")
    @XmlElement(name = "cyclicCheckNum")
    private Long cyclicCheckNum;

    @JsonProperty("contactSequenceNum")
    @XmlElement(name = "contactSequenceNum")
    private Long contactSequenceNum;

    @JsonProperty("nextEscalationDate")
    @XmlElement(name = "nextEscalationDate")
    private String nextEscalationDate;

    @JsonProperty("organisationNum")
    @XmlElement(name = "organisationNum")
    private Long organisationNum;

    @JsonProperty("empNum")
    @XmlElement(name = "empNum")
    private Long empNum;

    @JsonProperty("contactType")
    @XmlElement(name = "contactType")
    private RefData contactType;

    @JsonProperty("contactSubType")
    @XmlElement(name = "contactSubType")
    private RefData contactSubType;

    @JsonProperty("contactAssignedTime")
    @XmlElement(name = "contactAssignedTime")
    private String contactAssignedTime;

    @JsonProperty("activityAssignmentComments")
    @XmlElement(name = "activityAssignmentComments")
    private String activityAssignmentComments;

    @JsonProperty("actionType")
    @XmlElement(name = "actionType")
    private String actionType;

    @JsonProperty("contactOutstandingFlag")
    @XmlElement(name = "contactOutstandingFlag")
    private String contactOutstandingFlag;

    @JsonProperty("changeHistoryFlag")
    @XmlElement(name = "changeHistoryFlag")
    private String changeHistoryFlag;

    @JsonProperty("notesType")
    @XmlElement(name = "notesType")
    private RefData notesType;

    @JsonProperty("notesDescription")
    @XmlElement(name = "notesDescription")
    private String notesDescription;

    @JsonProperty("propertyId")
    @XmlElement(name = "propertyId")
    private Long propertyId;

    @JsonProperty("accountId")
    @XmlElement(name = "accountId")
    private Long accountId;

    @JsonProperty("legalEntityNo")
    @XmlElement(name = "legalEntityNo")
    private Long legalEntityNo;
    
	@JsonProperty("contactRecords")
    @XmlElement(name = "contactRecords")
    private ContactRecord contactRecords;
    
    @JsonProperty("transactionType")
    @XmlElement(name = "transactionType")
    private String transactionType;

    public ContactRecord getContactRecords() {
		return contactRecords;
	}

	public void setContactRecords(ContactRecord contactRecords) {
		this.contactRecords = contactRecords;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

    public String getLegalEntityName() {
        return legalEntityName;
    }

    public void setLegalEntityName(String legalEntityName) {
        this.legalEntityName = legalEntityName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDate getContactTime() {
        return contactTime;
    }

    public void setContactTime(LocalDate contactTime) {
        this.contactTime = contactTime;
    }

    public String getContactTypeDes() {
        return contactTypeDes;
    }

    public void setContactTypeDes(String contactTypeDes) {
        this.contactTypeDes = contactTypeDes;
    }

    public String getContactSubTypeDes() {
        return contactSubTypeDes;
    }

    public void setContactSubTypeDes(String contactSubTypeDes) {
        this.contactSubTypeDes = contactSubTypeDes;
    }

    public String getContactMethod() {
        return contactMethod;
    }

    public void setContactMethod(String contactMethod) {
        this.contactMethod = contactMethod;
    }

    public LocalDate getContactResolvedTime() {
        return contactResolvedTime;
    }

    public void setContactResolvedTime(LocalDate contactResolvedTime) {
        this.contactResolvedTime = contactResolvedTime;
    }

    public String getPointOfContactResolved() {
        return pointOfContactResolved;
    }

    public void setPointOfContactResolved(String pointOfContactResolved) {
        this.pointOfContactResolved = pointOfContactResolved;
    }

    public String getContactPrintedFlag() {
        return contactPrintedFlag;
    }

    public void setContactPrintedFlag(String contactPrintedFlag) {
        this.contactPrintedFlag = contactPrintedFlag;
    }

    public String getAttachmentTypeInd() {
        return attachmentTypeInd;
    }

    public void setAttachmentTypeInd(String attachmentTypeInd) {
        this.attachmentTypeInd = attachmentTypeInd;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getWorkStartedFlag() {
        return workStartedFlag;
    }

    public void setWorkStartedFlag(String workStartedFlag) {
        this.workStartedFlag = workStartedFlag;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public RefData getPriorityStatus() {
        return priorityStatus;
    }

    public void setPriorityStatus(RefData priorityStatus) {
        this.priorityStatus = priorityStatus;
    }

    public Long getNumOfDays() {
        return numOfDays;
    }

    public void setNumOfDays(Long numOfDays) {
        this.numOfDays = numOfDays;
    }

    public String getLinkedFlag() {
        return linkedFlag;
    }

    public void setLinkedFlag(String linkedFlag) {
        this.linkedFlag = linkedFlag;
    }

    public String getAttachmentLocation() {
        return attachmentLocation;
    }

    public void setAttachmentLocation(String attachmentLocation) {
        this.attachmentLocation = attachmentLocation;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public Long getContactPackageId() {
        return contactPackageId;
    }

    public void setContactPackageId(Long contactPackageId) {
        this.contactPackageId = contactPackageId;
    }

    public Long getActivityQueueItemId() {
        return activityQueueItemId;
    }

    public void setActivityQueueItemId(Long activityQueueItemId) {
        this.activityQueueItemId = activityQueueItemId;
    }

    public Long getCyclicCheckNum() {
        return cyclicCheckNum;
    }

    public void setCyclicCheckNum(Long cyclicCheckNum) {
        this.cyclicCheckNum = cyclicCheckNum;
    }

    public Long getContactSequenceNum() {
        return contactSequenceNum;
    }

    public void setContactSequenceNum(Long contactSequenceNum) {
        this.contactSequenceNum = contactSequenceNum;
    }

    public String getNextEscalationDate() {
        return nextEscalationDate;
    }

    public void setNextEscalationDate(String nextEscalationDate) {
        this.nextEscalationDate = nextEscalationDate;
    }

    public Long getOrganisationNum() {
        return organisationNum;
    }

    public void setOrganisationNum(Long organisationNum) {
        this.organisationNum = organisationNum;
    }

    public Long getEmpNum() {
        return empNum;
    }

    public void setEmpNum(Long empNum) {
        this.empNum = empNum;
    }

    public RefData getContactType() {
        return contactType;
    }

    public void setContactType(RefData contactType) {
        this.contactType = contactType;
    }

    public RefData getContactSubType() {
        return contactSubType;
    }

    public void setContactSubType(RefData contactSubType) {
        this.contactSubType = contactSubType;
    }

    public String getContactAssignedTime() {
        return contactAssignedTime;
    }

    public void setContactAssignedTime(String contactAssignedTime) {
        this.contactAssignedTime = contactAssignedTime;
    }

    public String getActivityAssignmentComments() {
        return activityAssignmentComments;
    }

    public void setActivityAssignmentComments(String activityAssignmentComments) {
        this.activityAssignmentComments = activityAssignmentComments;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getContactOutstandingFlag() {
        return contactOutstandingFlag;
    }

    public void setContactOutstandingFlag(String contactOutstandingFlag) {
        this.contactOutstandingFlag = contactOutstandingFlag;
    }

    public String getChangeHistoryFlag() {
        return changeHistoryFlag;
    }

    public void setChangeHistoryFlag(String changeHistoryFlag) {
        this.changeHistoryFlag = changeHistoryFlag;
    }

    public RefData getNotesType() {
        return notesType;
    }

    public void setNotesType(RefData notesType) {
        this.notesType = notesType;
    }

    public String getNotesDescription() {
        return notesDescription;
    }

    public void setNotesDescription(String notesDescription) {
        this.notesDescription = notesDescription;
    }

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Long propertyId) {
        this.propertyId = propertyId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getLegalEntityNo() {
        return legalEntityNo;
    }

    public void setLegalEntityNo(Long legalEntityNo) {
        this.legalEntityNo = legalEntityNo;
    }
}
