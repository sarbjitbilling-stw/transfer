package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import java.io.Serializable;

/**
 *
 * @author Ibai Ramos Astola on 28/06/2017
 *
 */
@XmlRootElement(name = "WSSLERegistrationData")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WSSLERegistrationData  implements Serializable{
	
	@JsonProperty("wssRegFlagTmstmp")
	@XmlElement(name = "wssRegFlagTmstmp")
	private XMLGregorianCalendar wssRegFlagTmstmp;

	@JsonProperty("wssRegFlag")
	@XmlElement(name = "wssRegFlag")
	private boolean wssRegFlag;

	@JsonProperty("wssPaperlessBillFlag")
	@XmlElement(name = "wssPaperlessBillFlag")
	private boolean wssPaperlessBillFlag;
	
	@JsonProperty("wssPaperlessBillFlagTmstmp")
	@XmlElement(name = "wssPaperlessBillFlagTmstmp")
	private XMLGregorianCalendar wssPaperlessBillFlagTmstmp;

	public XMLGregorianCalendar getWssRegFlagTmstmp() {
		return wssRegFlagTmstmp;
	}

	public void setWssRegFlagTmstmp(XMLGregorianCalendar wssRegFlagTmstmp) {
		this.wssRegFlagTmstmp = wssRegFlagTmstmp;
	}

	public boolean getWssRegFlag() {
		return wssRegFlag;
	}

	public void setWssRegFlag(boolean wssRegFlag) {
		this.wssRegFlag = wssRegFlag;
	}

	public boolean getWssPaperlessBillFlag() {
		return wssPaperlessBillFlag;
	}

	public void setWssPaperlessBillFlag(boolean wssPaperlessBillFlag) {
		this.wssPaperlessBillFlag = wssPaperlessBillFlag;
	}

	public XMLGregorianCalendar getWssPaperlessBillFlagTmstmp() {
		return wssPaperlessBillFlagTmstmp;
	}

	public void setWssPaperlessBillFlagTmstmp(XMLGregorianCalendar wssPaperlessBillFlagTmstmp) {
		this.wssPaperlessBillFlagTmstmp = wssPaperlessBillFlagTmstmp;
	}

}
