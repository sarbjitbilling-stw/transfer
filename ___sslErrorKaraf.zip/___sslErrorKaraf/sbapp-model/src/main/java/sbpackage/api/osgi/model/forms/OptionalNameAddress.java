package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OptionalNameAddress extends Details {
    private boolean addressUnknown;

    public boolean isAddressUnknown() {
        return addressUnknown;
    }

    public void setAddressUnknown(boolean addressUnknown) {
        this.addressUnknown = addressUnknown;
    }
}
