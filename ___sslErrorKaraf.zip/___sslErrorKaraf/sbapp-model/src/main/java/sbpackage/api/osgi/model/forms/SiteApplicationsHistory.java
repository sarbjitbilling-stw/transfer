package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SiteApplicationsHistory {

    private List<String> previousApplications;

    public List<String> getPreviousApplications() {
        return previousApplications;
    }

    public void setPreviousApplications(List<String> previousApplications) {
        this.previousApplications = previousApplications;
    }
}
