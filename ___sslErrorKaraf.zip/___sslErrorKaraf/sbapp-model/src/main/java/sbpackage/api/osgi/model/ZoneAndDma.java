package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlElement;

public class ZoneAndDma {

    @JsonProperty("dma")
    @XmlElement(name = "dma")
    private String dma;

    @JsonProperty("zone")
    @XmlElement(name = "zone")
    private String zone;
    
    @JsonProperty("controlGroup")
    @XmlElement(name = "controlGroup")
    private String controlGroup;

    public String getDma() {
        return dma;
    }

    public void setDma(String dma) {
        this.dma = dma;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }   

	public String getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("dma", dma)
                .append("zone", zone)
                .append("controlGroup", controlGroup)
                .toString();
    }
}
