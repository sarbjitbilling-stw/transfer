package sbpackage.api.osgi.model.sms;

public class SendSmsResponse {
    private SmsContent renderedSmsContent;
    private SendSmsStatus status;
    private String failureReason;

    public SmsContent getRenderedSmsContent() {
        return renderedSmsContent;
    }

    public void setRenderedSmsContent(SmsContent renderedSmsContent) {
        this.renderedSmsContent = renderedSmsContent;
    }

    public SendSmsStatus getStatus() {
        return status;
    }

    public void setStatus(SendSmsStatus status) {
        this.status = status;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }

}
