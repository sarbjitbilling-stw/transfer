package sbpackage.api.osgi.model.payment.directdebit;

import sbpackage.api.osgi.model.payment.PaymentPlanWarningDTO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DirectDebitWarningDTO extends PaymentPlanWarningDTO {

}
