package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DeveloperEnquiryAndPocWaterDetails extends DeveloperEnquiryAndPocDetails {

    private CommercialFittings commercialFittingsDevelopment;
    private RequireFittings requireFittings;


    public CommercialFittings getCommercialFittingsDevelopment() {
        return commercialFittingsDevelopment;
    }

    public void setCommercialFittingsDevelopment(CommercialFittings commercialFittingsDevelopment) {
        this.commercialFittingsDevelopment = commercialFittingsDevelopment;
    }

    public RequireFittings getRequireFittings() {
        return requireFittings;
    }

    public void setRequireFittings(RequireFittings requireFittings) {
        this.requireFittings = requireFittings;
    }

}
