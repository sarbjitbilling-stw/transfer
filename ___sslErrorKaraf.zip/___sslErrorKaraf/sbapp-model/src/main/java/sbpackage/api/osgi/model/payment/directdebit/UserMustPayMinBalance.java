package sbpackage.api.osgi.model.payment.directdebit;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

/**
 * Created by DA on 13/12/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserMustPayMinBalance {

    @XmlElement(name = "payMinimiumBalance")
    private Boolean payMinimiumBalance;

    @XmlElement(name = "displayMessage")
    private String displayMessage;

    @XmlElement(name = "minBalanceToPay")
    private BigDecimal minBalanceToPay;

    @XmlElement(name = "maxBalanceToPay")
    private BigDecimal maxBalanceToPay;

    public Boolean getPayMinimiumBalance() {
        return payMinimiumBalance;
    }

    public void setPayMinimiumBalance(Boolean payMinimiumBalance) {
        this.payMinimiumBalance = payMinimiumBalance;
    }

    public String getDisplayMessage() {
        return displayMessage;
    }

    public void setDisplayMessage(String displayMessage) {
        this.displayMessage = displayMessage;
    }

    public BigDecimal getMinBalanceToPay() {
        return minBalanceToPay;
    }

    public void setMinBalanceToPay(BigDecimal minBalanceToPay) {
        this.minBalanceToPay = minBalanceToPay;
    }

    public BigDecimal getMaxBalanceToPay() {
        return maxBalanceToPay;
    }

    public void setMaxBalanceToPay(BigDecimal maxBalanceToPay) {
        this.maxBalanceToPay = maxBalanceToPay;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        UserMustPayMinBalance that = (UserMustPayMinBalance) o;

        return new EqualsBuilder()
                .append(payMinimiumBalance, that.payMinimiumBalance)
                .append(displayMessage, that.displayMessage)
                .append(minBalanceToPay, that.minBalanceToPay)
                .append(displayMessage, that.displayMessage)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(payMinimiumBalance)
                .append(displayMessage)
                .append(minBalanceToPay)
                .append(displayMessage)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("payMinimiumBalance", payMinimiumBalance)
                .append("displayMessage", displayMessage)
                .append("minBalanceToPay", minBalanceToPay)
                .append("displayMessage", displayMessage)
                .toString();
    }
}
