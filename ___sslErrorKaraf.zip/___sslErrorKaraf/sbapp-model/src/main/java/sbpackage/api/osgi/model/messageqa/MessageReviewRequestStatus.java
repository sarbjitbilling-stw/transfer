package sbpackage.api.osgi.model.messageqa;

public enum MessageReviewRequestStatus {
    PENDING, APPROVED, REJECTED
}