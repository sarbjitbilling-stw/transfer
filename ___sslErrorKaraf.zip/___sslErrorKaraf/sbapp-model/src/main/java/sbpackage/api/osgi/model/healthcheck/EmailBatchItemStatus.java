package sbpackage.api.osgi.model.healthcheck;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Map;

@XmlRootElement(name = "EmailBatchItemStatus")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class EmailBatchItemStatus {

    @XmlElement(name = "statusCount")
    private Map<String, Long> statusCount;
    @XmlElement(name = "longStandingLocked")
    private long longStandingLocked;
    @XmlElement(name = "checkSuccessful")
    private boolean checkSuccessful;
}
