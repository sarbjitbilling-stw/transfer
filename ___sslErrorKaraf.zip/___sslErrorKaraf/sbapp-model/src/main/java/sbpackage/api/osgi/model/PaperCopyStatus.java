package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

public class PaperCopyStatus {	
	
	@JsonProperty("billOrdered")
	private boolean billOrdered;
	
	@JsonProperty("invoiceNumber")
    private Long invoiceNumber;

	public boolean isBillOrdered() {
		return billOrdered;
	}

	public void setBillOrdered(boolean billOrdered) {
		this.billOrdered = billOrdered;
	}

	public Long getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(Long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}


}