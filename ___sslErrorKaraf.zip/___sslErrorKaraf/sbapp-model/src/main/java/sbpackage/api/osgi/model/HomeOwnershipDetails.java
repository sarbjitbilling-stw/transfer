package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "homeOwnershipDetails", propOrder
              = {"additionalDataItemType","additionalDataItemTypeSeq","additionalDataItemKey","status","cyclicNum"
        })

//@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlRootElement(name = "homeOwnershipDetails")  
public class HomeOwnershipDetails  implements Serializable{

	@XmlElement(name = "additionalDataItemType")
	//@JsonProperty(value = "additionalDataItemType")
    private String additionalDataItemType = null;


	
	public String getAdditionalDataItemType() {
		return additionalDataItemType;
	}

	public void setAdditionalDataItemType(String additionalDataItemType) {
		this.additionalDataItemType = additionalDataItemType;
	}

	public Long getAdditionalDataItemTypeSeq() {
		return additionalDataItemTypeSeq;
	}

	public void setAdditionalDataItemTypeSeq(Long additionalDataItemTypeSeq) {
		this.additionalDataItemTypeSeq = additionalDataItemTypeSeq;
	}

	public Long getAdditionalDataItemKey() {
		return additionalDataItemKey;
	}

	public void setAdditionalDataItemKey(Long additionalDataItemKey) {
		this.additionalDataItemKey = additionalDataItemKey;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getCyclicNum() {
		return cyclicNum;
	}

	public void setCyclicNum(Long cyclicNum) {
		this.cyclicNum = cyclicNum;
	}

	@XmlElement(name = "additionalDataItemTypeSeq")
	//@JsonProperty(value = "additionalDataItemTypeSeq")
    private Long additionalDataItemTypeSeq = null;

    
	@XmlElement(name = "additionalDataItemKey")
	//@JsonProperty(value =  "additionalDataItemKey")
    private Long additionalDataItemKey = null;

    @XmlElement(name = "status")
	//@JsonProperty(value =  "status")
    private String status = null;

    @XmlElement(name = "cyclicNum")
	//@JsonProperty(value = "cyclicNum")  
    private Long cyclicNum = null;

        
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class DatashareIndicatorDetails {\n");

        sb.append("    additionalDataItemType: ").append(toIndentedString(additionalDataItemType)).append("\n");
        sb.append("    additionalDataItemTypeSeq: ").append(toIndentedString(additionalDataItemTypeSeq)).append("\n");
        sb.append("    additionalDataItemKey: ").append(toIndentedString(additionalDataItemKey)).append("\n");
        sb.append("    status: ").append(toIndentedString(status)).append("\n");
        sb.append("    cyclicNum: ").append(toIndentedString(cyclicNum)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private static String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}
