package sbpackage.api.osgi.model.transaction;


import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.DateAdapter;
import sbpackage.api.osgi.model.util.LocalDateAdapter;
import sbpackage.api.osgi.model.util.LocalDateTimeAdapter;


@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountEvent {

	@JsonProperty("createdTime")
	@XmlElement(name = "createdTime")
	@XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
	private LocalDateTime createdTime;
	
	
	/**
	 *  swagger model defines this field as Date & Time, the above createdTime will truncate the time as is defined as LocalDate
	 *  Reverse Bill requirements needs Date & Time, therefore and not to make changes every where, defined a new field and made it XmlTransient.
	 *  These field may need merging in the future
	 */
	@JsonIgnore
	@XmlTransient
	private LocalDateTime createdDateTime;
	

	@JsonProperty("eventAmount")
	@XmlElement(name = "eventAmount")
	private Float eventAmount;

	@JsonProperty("dateOfIssue")
	@XmlElement(name = "dateOfIssue")
	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate dateOfIssue;

	@JsonProperty("accountEventType")
	@XmlElement(name = "accountEventType")
	private RefData accountEventType;

	@JsonProperty("balanceAmount")
	@XmlElement(name = "balanceAmount")
	private Float balanceAmount;

	@JsonProperty("invoiceNum")
	@XmlElement(name = "invoiceNum")
	private Long invoiceNum;

	@JsonProperty("accountStatus")
	@XmlElement(name = "accountStatus")
	private String accountStatus;

	@JsonProperty("billStartDate")
	@XmlElement(name = "billStartDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate billStartDate;

	@JsonProperty("billEndDate")
	@XmlElement(name = "billEndDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate billEndDate;

	@JsonProperty("billDaysNum")
	@XmlElement(name = "billDaysNum")
	private Long billDaysNum;

	@JsonProperty("outstandingAmount")
	@XmlElement(name = "outstandingAmount")
	private Float outstandingAmount;

	@JsonProperty("cancelledAmount")
	@XmlElement(name = "cancelledAmount")
	private Float cancelledAmount;

	@JsonProperty("attachmentLocation")
	@XmlElement(name = "attachmentLocation")
	private String attachmentLocation;

	@JsonProperty("billCancelDate")
	@XmlElement(name = "billCancelDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate billCancelDate;

	@JsonProperty("billCancelReason")
	@XmlElement(name = "billCancelReason")
	private RefData billCancelReason;

	@JsonProperty("thirdPartyStatus")
	@XmlElement(name = "thirdPartyStatus")
	private RefData thirdPartyStatus;

	@JsonProperty("disputeFlag")
	@XmlElement(name = "disputeFlag")
	private String disputeFlag;

	@JsonProperty("consumptionAdjustFlag")
	@XmlElement(name = "consumptionAdjustFlag")
	private String consumptionAdjustFlag;

	@JsonProperty("transactionType")
	@XmlElement(name = "transactionType")
	private String transactionType;

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

	public LocalDate getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(LocalDate dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public RefData getAccountEventType() {
		return accountEventType;
	}

	public void setAccountEventType(RefData accountEventType) {
		this.accountEventType = accountEventType;
	}

	public Long getInvoiceNum() {
		return invoiceNum;
	}

	public void setInvoiceNum(Long invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public LocalDate getBillStartDate() {
		return billStartDate;
	}

	public void setBillStartDate(LocalDate billStartDate) {
		this.billStartDate = billStartDate;
	}

	public LocalDate getBillEndDate() {
		return billEndDate;
	}

	public void setBillEndDate(LocalDate billEndDate) {
		this.billEndDate = billEndDate;
	}

	public Long getBillDaysNum() {
		return billDaysNum;
	}

	public void setBillDaysNum(Long billDaysNum) {
		this.billDaysNum = billDaysNum;
	}

	public String getAttachmentLocation() {
		return attachmentLocation;
	}

	public void setAttachmentLocation(String attachmentLocation) {
		this.attachmentLocation = attachmentLocation;
	}

	public LocalDate getBillCancelDate() {
		return billCancelDate;
	}

	public void setBillCancelDate(LocalDate billCancelDate) {
		this.billCancelDate = billCancelDate;
	}

	public RefData getBillCancelReason() {
		return billCancelReason;
	}

	public void setBillCancelReason(RefData billCancelReason) {
		this.billCancelReason = billCancelReason;
	}

	public RefData getThirdPartyStatus() {
		return thirdPartyStatus;
	}

	public void setThirdPartyStatus(RefData thirdPartyStatus) {
		this.thirdPartyStatus = thirdPartyStatus;
	}

	public String getDisputeFlag() {
		return disputeFlag;
	}

	public void setDisputeFlag(String disputeFlag) {
		this.disputeFlag = disputeFlag;
	}

	public String getConsumptionAdjustFlag() {
		return consumptionAdjustFlag;
	}

	public void setConsumptionAdjustFlag(String consumptionAdjustFlag) {
		this.consumptionAdjustFlag = consumptionAdjustFlag;
	}

	public Float getEventAmount() {
		return eventAmount;
	}

	public void setEventAmount(Float eventAmount) {
		this.eventAmount = eventAmount;
	}

	public Float getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public Float getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(Float outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public Float getCancelledAmount() {
		return cancelledAmount;
	}

	public void setCancelledAmount(Float cancelledAmount) {
		this.cancelledAmount = cancelledAmount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(LocalDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	
	
}
