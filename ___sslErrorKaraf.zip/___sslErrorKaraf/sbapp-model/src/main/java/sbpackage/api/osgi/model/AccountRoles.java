package sbpackage.api.osgi.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlAccessorType(XmlAccessType.FIELD)

@XmlType(name = "AccountRoles", propOrder
        = {"displaySeqNum", "custAccountRoleNum", "custAccountRoleType", "leNum", "startDate", "debtActivityType", "responsibilityCeaseDate",
            "billCopiesNum", "acceptInsertsFlag", "printRole", "cyclicConcurrencyCheckNum", "leResponsibilityRoleNum",
            "priorityRequiredFlag", "confirmationDocRefNum", "requestorRelation", "docReceivedDate", "addressCode", "addressIndicator", "oneLineAddress", "leTitleCode",
            "leTitleDesc", "leFirstName", "leMiddleIntials", "leSurname", "leIndicator", "preferredName", "accountNumber", "leType", "dob", "telNumWork", "telNumHome", "telNumMobile", "prefTelNumInd",
            "employmStat", "bankAccountInd", "homeOwnStat", "leEmail", "leDobDay", "leDobMonth", "leDobYear", "leBankStatus", "dataShareIndicator"
        })
@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlRootElement(name = "AccountRoles")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountRoles implements Serializable {

    @JsonProperty("displaySeqNum")
    @XmlElement(name = "displaySeqNum")
    private long displaySeqNum;

    @JsonProperty("custAccountRoleNum")
    @XmlElement(name = "custAccountRoleNum")
    private long custAccountRoleNum;

    @JsonProperty("custAccountRoleType")
    @XmlElement(name = "custAccountRoleType")
    private String custAccountRoleType;

    @JsonProperty("leNum")
    @XmlElement(name = "leNum")
    private long leNum;

    @JsonProperty("startDate")
    @XmlElement(name = "startDate")
    private Date startDate;

    @JsonProperty("debtActivityType")
    @XmlElement(name = "debtActivityType")
    private String debtActivityType;

    @JsonProperty("responsibilityCeaseDate")
    @XmlElement(name = "responsibilityCeaseDate")
    private Date responsibilityCeaseDate;

    @JsonProperty("billCopiesNum")
    @XmlElement(name = "billCopiesNum")
    private long billCopiesNum;

    @JsonProperty("acceptInsertsFlag")
    @XmlElement(name = "acceptInsertsFlag")
    private String acceptInsertsFlag;

    @JsonProperty("printRole")
    @XmlElement(name = "printRole")
    private String printRole;

    @JsonProperty("cyclicConcurrencyCheckNum")
    @XmlElement(name = "cyclicConcurrencyCheckNum")
    private long cyclicConcurrencyCheckNum;

    @JsonProperty("leResponsibilityRoleNum")
    @XmlElement(name = "leResponsibilityRoleNum")
    private Long leResponsibilityRoleNum;

    @JsonProperty("priorityRequiredFlag")
    @XmlElement(name = "priorityRequiredFlag")
    private String priorityRequiredFlag;

    @JsonProperty("confirmationDocRefNum")
    @XmlElement(name = "confirmationDocRefNum")
    private String confirmationDocRefNum;

    @JsonProperty("requestorRelation")
    @XmlElement(name = "requestorRelation")
    private String requestorRelation;

    @JsonProperty("docReceivedDate")
    @XmlElement(name = "docReceivedDate")
    private Date docReceivedDate;

    @JsonProperty("addressCode")
    @XmlElement(name = "addressCode")
    private Long addressCode;

    @JsonProperty("addressIndicator")
    @XmlElement(name = "addressIndicator")
    private String addressIndicator;

    @JsonProperty("oneLineAddress")
    @XmlElement(name = "oneLineAddress")
    private String oneLineAddress;

    @JsonProperty("leTitleCode")
    @XmlElement(name = "leTitleCode")
    private String leTitleCode;

    @JsonProperty("leTitleDesc")
    @XmlElement(name = "leTitleDesc")
    private String leTitleDesc;

    @JsonProperty("leFirstName")
    @XmlElement(name = "leFirstName")
    private String leFirstName;

    @JsonProperty("leMiddleIntials")
    @XmlElement(name = "leMiddleIntials")
    private String leMiddleIntials;

    @JsonProperty("leSurname")
    @XmlElement(name = "leSurname")
    private String leSurname;

    @JsonProperty("leIndicator")
    @XmlElement(name = "leIndicator")
    private String leIndicator;

    @JsonProperty("preferredName")
    @XmlElement(name = "preferredName")
    private String preferredName;

    @JsonProperty("accountNumber")
    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @JsonProperty("leType")
    @XmlElement(name = "leType")
    private String leType;

    @JsonProperty("dob")
    @XmlElement(name = "dob")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate dob;

    @JsonProperty("telNumWork")
    @XmlElement(name = "telNumWork")
    private String telNumWork;

    @JsonProperty("telNumHome")
    @XmlElement(name = "telNumHome")
    private String telNumHome;

    @JsonProperty("telNumMobile")
    @XmlElement(name = "telNumMobile")
    private String telNumMobile;

    @JsonProperty("prefTelNumInd")
    @XmlElement(name = "prefTelNumInd")
    private String prefTelNumInd;

    @JsonProperty("employmStat")
    @XmlElement(name = "employmStat")
    private String employmStat;

    @JsonProperty("bankAccountInd")
    @XmlElement(name = "bankAccountInd")
    private String bankAccountInd;

    @JsonProperty("homeOwnStat")
    @XmlElement(name = "homeOwnStat")
    private String homeOwnStat;

    @JsonProperty("leEmail")
    @XmlElement(name = "leEmail")
    private String leEmail;

    @JsonProperty("leDobDay")
    @XmlElement(name = "leDobDay")
    private String leDobDay;

    @JsonProperty("leDobMonth")
    @XmlElement(name = "leDobMonth")
    private String leDobMonth;

    @JsonProperty("leDobYear")
    @XmlElement(name = "leDobYear")
    private String leDobYear;

    @JsonProperty("leBankStatus")
    @XmlElement(name = "leBankStatus")
    private String leBankStatus;

    @JsonProperty("leDataShare")
    @XmlElement(name = "leDataShare")
    private Boolean dataShareIndicator;
    
    @JsonProperty("customer")
    @XmlElement(name = "customer")
    private Customer customer;

    public long getDisplaySeqNum() {
        return displaySeqNum;
    }

    public void setDisplaySeqNum(long displaySeqNum) {
        this.displaySeqNum = displaySeqNum;
    }

    public long getCustAccountRoleNum() {
        return custAccountRoleNum;
    }

    public void setCustAccountRoleNum(long custAccountRoleNum) {
        this.custAccountRoleNum = custAccountRoleNum;
    }

    public String getCustAccountRoleType() {
        return custAccountRoleType;
    }

    public void setCustAccountRoleType(String custAccountRoleType) {
        this.custAccountRoleType = custAccountRoleType;
    }

    public long getLeNum() {
        return leNum;
    }

    public void setLeNum(long leNum) {
        this.leNum = leNum;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getDebtActivityType() {
        return debtActivityType;
    }

    public void setDebtActivityType(String debtActivityType) {
        this.debtActivityType = debtActivityType;
    }

    public Date getResponsibilityCeaseDate() {
        return responsibilityCeaseDate;
    }

    public void setResponsibilityCeaseDate(Date responsibilityCeaseDate) {
        this.responsibilityCeaseDate = responsibilityCeaseDate;
    }

    public long getBillCopiesNum() {
        return billCopiesNum;
    }

    public void setBillCopiesNum(long billCopiesNum) {
        this.billCopiesNum = billCopiesNum;
    }

    public String getAcceptInsertsFlag() {
        return acceptInsertsFlag;
    }

    public void setAcceptInsertsFlag(String acceptInsertsFlag) {
        this.acceptInsertsFlag = acceptInsertsFlag;
    }

    public String getPrintRole() {
        return printRole;
    }

    public void setPrintRole(String printRole) {
        this.printRole = printRole;
    }

    public long getCyclicConcurrencyCheckNum() {
        return cyclicConcurrencyCheckNum;
    }

    public void setCyclicConcurrencyCheckNum(long cyclicConcurrencyCheckNum) {
        this.cyclicConcurrencyCheckNum = cyclicConcurrencyCheckNum;
    }

    public Long getLeResponsibilityRoleNum() {
        return leResponsibilityRoleNum;
    }

    public void setLeResponsibilityRoleNum(Long leResponsibilityRoleNum) {
        this.leResponsibilityRoleNum = leResponsibilityRoleNum;
    }

    public String getPriorityRequiredFlag() {
        return priorityRequiredFlag;
    }

    public void setPriorityRequiredFlag(String priorityRequiredFlag) {
        this.priorityRequiredFlag = priorityRequiredFlag;
    }

    public String getConfirmationDocRefNum() {
        return confirmationDocRefNum;
    }

    public void setConfirmationDocRefNum(String confirmationDocRefNum) {
        this.confirmationDocRefNum = confirmationDocRefNum;
    }

    public String getRequestorRelation() {
        return requestorRelation;
    }

    public void setRequestorRelation(String requestorRelation) {
        this.requestorRelation = requestorRelation;
    }

    public Date getDocReceivedDate() {
        return docReceivedDate;
    }

    public void setDocReceivedDate(Date docReceivedDate) {
        this.docReceivedDate = docReceivedDate;
    }

    public Long getAddressCode() {
        return addressCode;
    }

    public void setAddressCode(Long addressCode) {
        this.addressCode = addressCode;
    }

    public String getAddressIndicator() {
        return addressIndicator;
    }

    public void setAddressIndicator(String addressIndicator) {
        this.addressIndicator = addressIndicator;
    }

    public String getOneLineAddress() {
        return oneLineAddress;
    }

    public void setOneLineAddress(String oneLineAddress) {
        this.oneLineAddress = oneLineAddress;
    }

    public String getLeTitleCode() {
        return leTitleCode;
    }

    public void setLeTitleCode(String leTitleCode) {
        this.leTitleCode = leTitleCode;
    }

    public String getLeTitleDesc() {
        return leTitleDesc;
    }

    public void setLeTitleDesc(String leTitleDesc) {
        this.leTitleDesc = leTitleDesc;
    }

    public String getLeFirstName() {
        return leFirstName;
    }

    public void setLeFirstName(String leFirstName) {
        this.leFirstName = leFirstName;
    }

    public String getLeMiddleIntials() {
        return leMiddleIntials;
    }

    public void setLeMiddleIntials(String leMiddleIntials) {
        this.leMiddleIntials = leMiddleIntials;
    }

    public String getLeSurname() {
        return leSurname;
    }

    public void setLeSurname(String leSurname) {
        this.leSurname = leSurname;
    }

    public String getLeIndicator() {
        return leIndicator;
    }

    public void setLeIndicator(String leIndicator) {
        this.leIndicator = leIndicator;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }
//--	

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLeType() {
        return leType;
    }

    public void setLeType(String leType) {
        this.leType = leType;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getTelNumWork() {
        return telNumWork;
    }

    public void setTelNumWork(String telNumWork) {
        this.telNumWork = telNumWork;
    }

    public String getTelNumHome() {
        return telNumHome;
    }

    public void setTelNumHome(String telNumHome) {
        this.telNumHome = telNumHome;
    }

    public String getTelNumMobile() {
        return telNumMobile;
    }

    public void setTelNumMobile(String telNumMobile) {
        this.telNumMobile = telNumMobile;
    }

    public String getPrefTelNumInd() {
        return prefTelNumInd;
    }

    public void setPrefTelNumInd(String prefTelNumInd) {
        this.prefTelNumInd = prefTelNumInd;
    }

    public String getEmploymStat() {
        return employmStat;
    }

    public void setEmploymStat(String employmStat) {
        this.employmStat = employmStat;
    }

    public String getBankAccountInd() {
        return bankAccountInd;
    }

    public void setBankAccountInd(String bankAccountInd) {
        this.bankAccountInd = bankAccountInd;
    }

    public String getHomeOwnStat() {
        return homeOwnStat;
    }

    public void setHomeOwnStat(String homeOwnStat) {
        this.homeOwnStat = homeOwnStat;
    }

    public String getLeEmail() {
        return leEmail;
    }

    public void setLeEmail(String leEmail) {
        this.leEmail = leEmail;
    }

    public String getLeDobDay() {
        return leDobDay;
    }

    public void setLeDobDay(String leDobDay) {
        this.leDobDay = leDobDay;
    }

    public String getLeDobMonth() {
        return leDobMonth;
    }

    public void setLeDobMonth(String leDobMonth) {
        this.leDobMonth = leDobMonth;
    }

    public String getLeDobYear() {
        return leDobYear;
    }

    public void setLeDobYear(String leDobYear) {
        this.leDobYear = leDobYear;
    }

    public String getLeBankStatus() {
        return leBankStatus;
    }

    public void setLeBankStatus(String leBankStatus) {
        this.leBankStatus = leBankStatus;
    }

    public Boolean getDataShareIndicator() {
        return dataShareIndicator;
    }

    public void setDataShareIndicator(Boolean dataShareIndicator) {
        this.dataShareIndicator = dataShareIndicator;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class AccountRoles {\n");
        sb.append("    displaySeqNum: ").append(toIndentedString(displaySeqNum)).append("\n");
        sb.append("    custAccountRoleNum: ").append(toIndentedString(custAccountRoleNum)).append("\n");
        sb.append("    custAccountRoleType: ").append(toIndentedString(custAccountRoleType)).append("\n");
        sb.append("    leNum: ").append(toIndentedString(leNum)).append("\n");
        sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
        sb.append("    debtActivityType: ").append(toIndentedString(debtActivityType)).append("\n");
        sb.append("    responsibilityCeaseDate: ").append(toIndentedString(responsibilityCeaseDate)).append("\n");
        sb.append("    billCopiesNum: ").append(toIndentedString(billCopiesNum)).append("\n");
        sb.append("    acceptInsertsFlag: ").append(toIndentedString(acceptInsertsFlag)).append("\n");
        sb.append("    printRole: ").append(toIndentedString(printRole)).append("\n");
        sb.append("    cyclicConcurrencyCheckNum: ").append(toIndentedString(cyclicConcurrencyCheckNum)).append("\n");
        sb.append("    leResponsibilityRoleNum: ").append(toIndentedString(leResponsibilityRoleNum)).append("\n");
        sb.append("    priorityRequiredFlag: ").append(toIndentedString(priorityRequiredFlag)).append("\n");
        sb.append("    confirmationDocRefNum: ").append(toIndentedString(confirmationDocRefNum)).append("\n");
        sb.append("    requestorRelation: ").append(toIndentedString(requestorRelation)).append("\n");
        sb.append("    docReceivedDate: ").append(toIndentedString(docReceivedDate)).append("\n");
        sb.append("    addressCode: ").append(toIndentedString(addressCode)).append("\n");
        sb.append("    addressIndicator: ").append(toIndentedString(addressIndicator)).append("\n");
        sb.append("    oneLineAddress: ").append(toIndentedString(oneLineAddress)).append("\n");
        sb.append("    leTitleCode: ").append(toIndentedString(leTitleCode)).append("\n");
        sb.append("    leTitleDesc: ").append(toIndentedString(leTitleDesc)).append("\n");
        sb.append("    leFirstName: ").append(toIndentedString(leFirstName)).append("\n");
        sb.append("    leMiddleIntials: ").append(toIndentedString(leMiddleIntials)).append("\n");
        sb.append("    leSurname: ").append(toIndentedString(leSurname)).append("\n");
        sb.append("    leIndicator: ").append(toIndentedString(leIndicator)).append("\n");
        sb.append("    preferredName: ").append(toIndentedString(preferredName)).append("\n");

        sb.append("    leEmail: ").append(toIndentedString(leEmail)).append("\n");
        sb.append("    leDobDay: ").append(toIndentedString(leDobDay)).append("\n");
        sb.append("    leDobMonth: ").append(toIndentedString(leDobMonth)).append("\n");
        sb.append("    leDobYear: ").append(toIndentedString(leDobYear)).append("\n");
        sb.append("    leBankStatus: ").append(toIndentedString(leBankStatus)).append("\n");

        sb.append("    accountNumber: ").append(toIndentedString(accountNumber)).append("\n");
        sb.append("    leType: ").append(toIndentedString(leType)).append("\n");
        sb.append("    dob: ").append(toIndentedString(dob)).append("\n");
        sb.append("    telNumWork: ").append(toIndentedString(telNumWork)).append("\n");
        sb.append("    telNumHome: ").append(toIndentedString(telNumHome)).append("\n");
        sb.append("    telNumMobile: ").append(toIndentedString(telNumMobile)).append("\n");
        sb.append("    prefTelNumInd: ").append(toIndentedString(prefTelNumInd)).append("\n");
        sb.append("    employmStat: ").append(toIndentedString(employmStat)).append("\n");
        sb.append("    bankAccountInd: ").append(toIndentedString(bankAccountInd)).append("\n");
        sb.append("    homeOwnStat: ").append(toIndentedString(homeOwnStat)).append("\n");
        sb.append("    preferredName: ").append(toIndentedString(preferredName)).append("\n");
        sb.append("    dataShareIndicator: ").append(toIndentedString(dataShareIndicator)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private static String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    public String getFullName() {
        StringBuilder fullName = new StringBuilder("");
        if (getLeTitleDesc() != null && !getLeTitleDesc().trim().equals("")) {
            fullName.append(getLeTitleDesc() + " ");
        }
        if (getLeFirstName() != null) {
            fullName.append(getLeFirstName() + " ");
        }
        if (getLeMiddleIntials() != null && !getLeMiddleIntials().trim().equals("")) {
            fullName.append(getLeMiddleIntials() + " ");
        }
        if (getLeSurname() != null) {
            fullName.append(getLeSurname());
        }
        return fullName.toString();
    }

}
