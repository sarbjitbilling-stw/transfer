package sbpackage.api.osgi.model.calculator.offers;

public enum PaymentPlanVariant {
    DEFALT(null),
    FLEX0("FLEX0"),//Will be used when preferred payment Standard offer is modified, then 0% Flex will be renamed as Flex0.
    FLEX1("FLEX1"),
    FLEX2("FLEX2"),
    FLEX3("FLEX3"),
    FLEX4("FLEX4"),
    FLEX5("FLEX5"),
    FLEX6("FLEX6"),
    FLEX_LONG("LONG"),
    FLEX_SHORT("SHORT"),
    PPC1("PPC1"),
    PPC2("PPC2"),
    PPC3("PPC3"),
    PPC4("PPC4"),
    PPC5("PPC5"),
    PPC6("PPC6"),
    PPC7("PPC7"),
    PPC8("PPC8");

    private final String planVariant;

    PaymentPlanVariant(String planVariant) {
        this.planVariant = planVariant;
    }

    public String getPlanVariant() {
        return planVariant;
    }
}
