package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SurfaceConnectionsList {

    private int domesticConnections;
    private int commercialConnections;

    public int getDomesticConnections() {
        return domesticConnections;
    }

    public void setDomesticConnections(int domesticConnections) {
        this.domesticConnections = domesticConnections;
    }

    public int getCommercialConnections() {
        return commercialConnections;
    }

    public void setCommercialConnections(int commercialConnections) {
        this.commercialConnections = commercialConnections;
    }

    public int getTotalConnections() {
        return domesticConnections + commercialConnections;
    }
}
