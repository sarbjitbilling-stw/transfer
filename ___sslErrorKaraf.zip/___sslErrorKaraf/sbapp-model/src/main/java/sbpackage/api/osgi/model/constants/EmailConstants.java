package sbpackage.api.osgi.model.constants;

public class EmailConstants {
	
	// JSON template fields
	public static final String JSON_RECIPIENT_ADDRESS = "recipientAddress";
	public static final String JSON_FROM_ADDRESS = "fromAddress";
	public static final String JSON_TEMPLATE_SUBJECT = "subject";
	public static final String JSON_TEMPLATE_BODY = "body";
	public static final String JSON_TEMPLATE_JSON = "templateJson";
	public static final String JSON_FIELD_DATA = "fieldData";
	public static final String JSON_FIELD_DATA_ENTRY = "entry";
	public static final String JSON_SEND_EMAIL_REQUEST = "SendEmailRequest";

}
