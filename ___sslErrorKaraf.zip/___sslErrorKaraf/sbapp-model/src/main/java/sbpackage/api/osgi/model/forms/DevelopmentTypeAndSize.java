package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DevelopmentTypeAndSize {

    private int developmentSize;
    private int houseHold;
    private int nonHouseHold;

    public int getDevelopmentSize() {
        return developmentSize;
    }

    public void setDevelopmentSize(int developmentSize) {
        this.developmentSize = developmentSize;
    }

    public int getHouseHold() {
        return houseHold;
    }

    public void setHouseHold(int houseHold) {
        this.houseHold = houseHold;
    }

    public int getNonHouseHold() {
        return nonHouseHold;
    }

    public void setNonHouseHold(int nonHouseHold) {
        this.nonHouseHold = nonHouseHold;
    }
}
