package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ApplicationForDischargeOfWaste extends Selection {
    private String referenceNumber;
    private String whoIsManagingThisApplicationOption;
    private String whoIsManagingThisApplicationDisplayValue;

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getWhoIsManagingThisApplicationOption() {
        return whoIsManagingThisApplicationOption;
    }

    public void setWhoIsManagingThisApplicationOption(String whoIsManagingThisApplicationOption) {
        this.whoIsManagingThisApplicationOption = whoIsManagingThisApplicationOption;
    }

    public String getWhoIsManagingThisApplicationDisplayValue() {
        return whoIsManagingThisApplicationDisplayValue;
    }

    public void setWhoIsManagingThisApplicationDisplayValue(String whoIsManagingThisApplicationDisplayValue) {
        this.whoIsManagingThisApplicationDisplayValue = whoIsManagingThisApplicationDisplayValue;
    }
}
