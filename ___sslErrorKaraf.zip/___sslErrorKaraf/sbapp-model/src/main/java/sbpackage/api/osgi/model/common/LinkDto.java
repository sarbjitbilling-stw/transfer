package sbpackage.api.osgi.model.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlRootElement(name = "link")
@XmlAccessorType(XmlAccessType.FIELD)
public class LinkDto {

    @XmlAttribute(name = "href")
    private String href;

    @XmlAttribute(name = "rel")
    private String rel;

    public LinkDto(String href, String rel) {
        this.href = href;
        this.rel = rel;
    }

    public LinkDto() {
    }

    public String getHref() {
        return this.href;
    }

    public String getRel() {
        return this.rel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LinkDto linkDto = (LinkDto) o;

        if (href != null ? !href.equals(linkDto.href) : linkDto.href != null) return false;
        return rel != null ? rel.equals(linkDto.rel) : linkDto.rel == null;
    }

    @Override
    public int hashCode() {
        int result = href != null ? href.hashCode() : 0;
        result = 31 * result + (rel != null ? rel.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("LinkDto{");
        sb.append("href='").append(href).append('\'');
        sb.append(", rel='").append(rel).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
