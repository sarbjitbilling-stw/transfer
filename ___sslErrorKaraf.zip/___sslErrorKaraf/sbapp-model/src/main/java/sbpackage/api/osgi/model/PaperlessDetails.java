package sbpackage.api.osgi.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.util.LocalDateTimeAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDateTime;

@XmlRootElement(name = "PaperlessDetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class PaperlessDetails {

    @XmlElement
    private Boolean isRegistered;

    @XmlElement
    private Boolean isPaperless;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateTimeAdapter.class)
    private LocalDateTime registrationStatusDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateTimeAdapter.class)
    private LocalDateTime paperlessStatusDate;

    @XmlElement
    private Long version;

    public Boolean getRegistered() {
        return isRegistered;
    }

    public void setRegistered(final Boolean registered) {
        isRegistered = registered;
    }

    public Boolean getPaperless() {
        return isPaperless;
    }

    public void setPaperless(final Boolean paperless) {
        isPaperless = paperless;
    }

    public LocalDateTime getRegistrationStatusDate() {
        return registrationStatusDate;
    }

    public void setRegistrationStatusDate(final LocalDateTime registrationStatusDate) {
        this.registrationStatusDate = registrationStatusDate;
    }

    public LocalDateTime getPaperlessStatusDate() {
        return paperlessStatusDate;
    }

    public void setPaperlessStatusDate(final LocalDateTime paperlessStatusDate) {
        this.paperlessStatusDate = paperlessStatusDate;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
