package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlType(name = "QuestionConfirm")
@XmlEnum
public enum QuestionConfirm implements SurveyQuestion {

    @XmlEnumValue(value = "NO")
    NO(1),
    @XmlEnumValue(value = "YES")
    YES(2);

    private int confirm;

    QuestionConfirm(int confirm) {
        this.confirm = confirm;
    }

    @Override
    public int getValue() {
        return confirm;
    }

    public static QuestionConfirm fromValue(int value) {
        return values()[value - 1];
    }

}
