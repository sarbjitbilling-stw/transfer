package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class PaymentDetails {

    private Selection paymentMethod;
    private PaymentAmount cardPayment;
    private PaymentAmount bankTransfer;
    private CardEmail cardEmail;

    private static final String BACS_PAYMENT_METHOD = "bacs";
    private static final String CARD_PAYMENT_METHOD = "card";

    public boolean isPaymentMethodBacs() {
        return paymentMethod != null && BACS_PAYMENT_METHOD.equals(paymentMethod.getSelectedOption());
    }

    public boolean isPaymentMethodCard() {
        return paymentMethod != null && CARD_PAYMENT_METHOD.equals(paymentMethod.getSelectedOption());
    }

    public Selection getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(Selection paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public PaymentAmount getCardPayment() {
        return cardPayment;
    }

    public void setCardPayment(PaymentAmount cardPayment) {
        this.cardPayment = cardPayment;
    }

    public PaymentAmount getBankTransfer() {
        return bankTransfer;
    }

    public void setBankTransfer(PaymentAmount bankTransfer) {
        this.bankTransfer = bankTransfer;
    }

    public String getCardEmail() {
        return cardEmail != null ? cardEmail.getCardEmail() : null;
    }
}
