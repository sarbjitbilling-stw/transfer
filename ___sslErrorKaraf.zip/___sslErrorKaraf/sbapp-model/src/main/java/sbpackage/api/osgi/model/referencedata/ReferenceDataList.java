package sbpackage.api.osgi.model.referencedata;

import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by rtai on 25/07/2017.
 */
@XmlRootElement(name = "referenceDataList")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReferenceDataList {

    @XmlElement(name = "attributeName")
    RefDataType attributeName;

    @XmlElement(name = "refDataList")
    List<RefData> refDataList;

    ReferenceDataList() {}

    public ReferenceDataList(RefDataType refDataType, List<RefData> refDataList){
        this.attributeName = refDataType;
        this.refDataList = refDataList;
    }

    public RefDataType getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(RefDataType attributeName) {
        this.attributeName = attributeName;
    }

    public List<RefData> getRefDataList() {
        return refDataList;
    }

    public void setRefDataList(List<RefData> refDataList) {
        this.refDataList = refDataList;
    }
}
