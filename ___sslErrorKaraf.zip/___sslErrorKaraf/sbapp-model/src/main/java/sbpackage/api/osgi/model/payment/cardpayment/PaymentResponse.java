package sbpackage.api.osgi.model.payment.cardpayment;

import lombok.Data;

@Data
public class PaymentResponse {

    public static final String SUCCESS_STATUS = "SUCCESS";

    private String sessionId;
    private String redirectUrl;
    private String status;
    private String reasonCode;
    private String reasonMessage;

    public boolean isSuccess() {
        return SUCCESS_STATUS.equals(status);
    }

}
