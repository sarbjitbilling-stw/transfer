package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PropertyTotals {

    private int commercialTotal;
    private int detachedTotal;
    private int flatTotal;
    private int semiDetachedTotal;
    private int terracedTotal;

    public int getCommercialTotal() {
        return commercialTotal;
    }

    public void setCommercialTotal(int commercialTotal) {
        this.commercialTotal = commercialTotal;
    }

    public int getDetachedTotal() {
        return detachedTotal;
    }

    public void setDetachedTotal(int detachedTotal) {
        this.detachedTotal = detachedTotal;
    }

    public int getFlatTotal() {
        return flatTotal;
    }

    public void setFlatTotal(int flatTotal) {
        this.flatTotal = flatTotal;
    }

    public int getSemiDetachedTotal() {
        return semiDetachedTotal;
    }

    public void setSemiDetachedTotal(int semiDetachedTotal) {
        this.semiDetachedTotal = semiDetachedTotal;
    }

    public int getTerracedTotal() {
        return terracedTotal;
    }

    public void setTerracedTotal(int terracedTotal) {
        this.terracedTotal = terracedTotal;
    }

    public int getPropertyCount() {
        return commercialTotal + detachedTotal + flatTotal + semiDetachedTotal + terracedTotal;
    }

    public boolean isAtLeastOnePropertyCommercial() {
        return commercialTotal > 0;
    }
}
