package sbpackage.api.osgi.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by rtai on 24/02/2017.
 */
@XmlRootElement(name = "WSSAccount")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WSSAccount implements Serializable{
    
    @XmlElement(name = "id")
    private String id;

    @XmlElement(name = "surname")
    private String surname;

    @XmlElement(name = "firstname")
    private String firstname;

    @XmlElement(name = "email")
    private String email;
   
    @XmlElement(name = "wssPassword")
    private String wssPassword;

    @XmlElement(name = "passwordHash")
    private String passwordHash;

    @XmlElement(name = "telephone")
    private String telephone;

    @XmlElement(name = "wssUsername")
    private String wssUsername;

    @XmlElement(name = "createdDate")
    private LocalDate createdDate;
    
    @XmlElement(name = "updatedDate")
    private LocalDate updatedDate;
   
    @XmlElement(name = "passwordResetRequired")
    private boolean passwordResetRequired;
    
    @XmlElement(name = "isLockedOut")
    private boolean isLockedOut;

    @XmlElement(name = "lockoutCount")
    private Integer lockoutCount;

    @XmlElement(name = "lockoutDate")
    private LocalDate lockoutDate;

    @XmlElement(name = "idvLockoutCount")
    private Integer idvLockoutCount;

    @XmlElement(name = "loginType")
    private LoginType loginType;

    @XmlElement(name = "idvLockoutDate")
    private String idvLockoutDate;

    @XmlElement(name = "registrationType")
    private String registrationType;

    @XmlElement(name = "logonWithEmail")
    private boolean logonWithEmail;
    
    @XmlElement(name = "wssLegalEntities")
    private List<WSSLegalEntity> wssLegalEntities;
    
    @XmlElement(name = "wssLegalEntityAccounts")
    private List<WSSLegalEntityAccount> wssLegalEntityAccounts;
    
    @XmlElement(name = "leToAccountMap")
    private Map<String, List<String>>leToAccountMap;
    
    @XmlElement(name = "accountToAnalyticsIdMap")
    private Map<String, Map<String, AnalyticsId>>analyticsIdMap;

    @XmlElement(name = "partialRegistration")
    private boolean partialRegistration;

    @XmlElement(name = "guestButPreviouslyRegistered")
    private boolean guestButPreviouslyRegistered;

    @XmlElement(name = "contactInterceptRequired")
    private boolean contactInterceptRequired;

    @XmlElement(name = "paperlessInterceptRequiredMap")
    private Map<String, Boolean> paperlessInterceptRequiredMap;
    
    @XmlElement(name = "business")
    private boolean business;
    
    @XmlElement(name = "site")
    private WSSSite site;

    @XmlElement(name = "socialAuth")
    private SocialAuth socialAuth;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email.toLowerCase();
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getWssUsername() {
        return wssUsername;
    }

    public void setWssUsername(String wssUsername) {
        this.wssUsername = wssUsername;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDate getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDate updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Integer getLockoutCount() {
        return lockoutCount;
    }

    public void setLockoutCount(Integer lockoutCount) {
        this.lockoutCount = lockoutCount;
    }

    public LocalDate getLockoutDate() {
        return lockoutDate;
    }

    public void setLockoutDate(LocalDate lockoutDate) {
        this.lockoutDate = lockoutDate;
    }


    public Integer getIdvLockoutCount() {
		return idvLockoutCount;
	}

	public void setIdvLockoutCount(Integer idvLockoutCount) {
		this.idvLockoutCount = idvLockoutCount;
	}

	public String getIdvLockoutDate() {
        return idvLockoutDate;
    }

    public void setIdvLockoutDate(String idvLockoutDate) {
        this.idvLockoutDate = idvLockoutDate;
    }

    public String getRegistrationType() {
        return registrationType;
    }

    public void setRegistrationType(String registrationType) {
        this.registrationType = registrationType;
    }

    public boolean isLogonWithEmail() {
        return logonWithEmail;
    }

    public void setLogonWithEmail(boolean logonWithEmail) {
        this.logonWithEmail = logonWithEmail;
    }

    public boolean isPasswordResetRequired() {
        return passwordResetRequired;
    }

    public void setPasswordResetRequired(boolean passwordResetRequired) {
        this.passwordResetRequired = passwordResetRequired;
    }

    public boolean isIsLockedOut() {
        return isLockedOut;
    }

    public void setIsLockedOut(boolean isLockedOut) {
        this.isLockedOut = isLockedOut;
    }
    
    public List<WSSLegalEntity> getWssLegalEntities() {
        return wssLegalEntities;
    }

    public void setWssLegalEntities(List<WSSLegalEntity> wssLegalEntities) {
        this.wssLegalEntities = wssLegalEntities;
    }
    
    public void addWssLegalEntities(WSSLegalEntity wssLegalEntities) {
        if(this.wssLegalEntities == null){
            this.wssLegalEntities = new ArrayList<>();
        }
        this.wssLegalEntities.add(wssLegalEntities);
    }

    public List<WSSLegalEntityAccount> getWssLegalEntityAccounts() {
        return wssLegalEntityAccounts;
    }
   
    public void setWssLegalEntityAccounts(List<WSSLegalEntityAccount> wssLegalEntityAccounts) {
        this.wssLegalEntityAccounts = wssLegalEntityAccounts;
    }
    
    public void addWssLegalEntityAccounts(WSSLegalEntityAccount wssLegalEntityAccounts) {
        if (this.wssLegalEntityAccounts == null) {
            this.wssLegalEntityAccounts = new ArrayList<>();
        }
        this.wssLegalEntityAccounts.add(wssLegalEntityAccounts);
    }   
    

    public String getWssPassword() {
        return wssPassword;
    }

    public void setWssPassword(String wssPassword) {
        this.wssPassword = wssPassword;
    }
    
    public LoginType getLoginType() {
        return loginType;
    }

    public void setLoginType(LoginType loginType) {
        this.loginType = loginType;
    }

    public Map<String, List<String>> getLeToAccountMap() {
        return leToAccountMap;
    }

    public void setLeToAccountMap(Map<String, List<String>> leToAccountMap) {
        this.leToAccountMap = leToAccountMap;
    }
    
    public Map<String, Map<String, AnalyticsId>> getAnalyticsIdMap() {
        return analyticsIdMap;
    }

    public void setAnalyticsIdMap(Map<String, Map<String, AnalyticsId>> analyticsIdMap) {
        this.analyticsIdMap = analyticsIdMap;
    }

    /**
     * Convenience method to add an LE to Account mapping
     * @param leId - le list is being added for
     * @param accountIdList - list of Account IDs
     */
    public void addLeToAccountMapping(String leId, List<String> accountIdList){
        if(leToAccountMap == null) leToAccountMap = new HashMap<>();
        leToAccountMap.put(leId, accountIdList);
    }
    
    /**
     * Convenience method to return account id list for given le id - will return ane
     * @param leId - le id to look for
     * @return list of Account IDs - will return empty list if non found
     */
    public List<String> getAccountIdList(String leId){
        if(leToAccountMap == null) return Collections.EMPTY_LIST;
        ArrayList<String> returnList = new ArrayList<String>();
        returnList.addAll(leToAccountMap.get(leId));
        return returnList;
    }
    
    /**
     * Convenience method to add an entry to AnalyticsId mapping
     * @param leId customers Target legal entity id
     * @param accountId customers Target account number
     * @param analyticsId for the leId account number combination
     */
    public void addAccountToAnalyticsIdMap(String leId, String accountId, AnalyticsId analyticsId){
        if(analyticsIdMap == null) analyticsIdMap = new HashMap<String, Map<String, AnalyticsId>>();
        
        Map<String, AnalyticsId> accountMap = analyticsIdMap.getOrDefault(leId, new HashMap<String, AnalyticsId>());
        analyticsIdMap.putIfAbsent(leId, accountMap);
        accountMap.put(accountId, analyticsId);
     }

    public boolean isGuestButPreviouslyRegistered() {
        return guestButPreviouslyRegistered;
    }

    public void setGuestButPreviouslyRegistered(boolean guestButPreviouslyRegistered) {
        this.guestButPreviouslyRegistered = guestButPreviouslyRegistered;
    }

    public boolean isPartialRegistration() {
        return partialRegistration;
    }

    public void setPartialRegistration(boolean partialRegistration) {
        this.partialRegistration = partialRegistration;
    }
    public boolean isContactInterceptRequired() {
        return contactInterceptRequired;
    }

    public void setContactInterceptRequired(boolean contactInterceptRequired) {
        this.contactInterceptRequired = contactInterceptRequired;
    }

    public Map<String, Boolean> getPaperlessInterceptRequiredMap() {
        return paperlessInterceptRequiredMap;
    }

    public void setPaperlessInterceptRequiredMap(Map<String, Boolean> paperlessInterceptRequiredMap) {
        this.paperlessInterceptRequiredMap = paperlessInterceptRequiredMap;
    }

    public boolean isBusiness() {
        return business;
    }

    public void setBusiness(boolean business) {
        this.business = business;
    }

    public WSSSite getSite() {
        return site;
    }

    public void setSite(WSSSite site) {
        this.site = site;
    }

    public SocialAuth getSocialAuth() {
        return socialAuth;
    }

    public void setSocialAuth(SocialAuth socialAuth) {
        this.socialAuth = socialAuth;
    }
}
