package sbpackage.api.osgi.model.payment.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Created by rtai on 28/06/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScheduledPayment {

    @XmlElement
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate date;

    private BigDecimal paymentAmount;

    @XmlElement
    private BigDecimal totalAmount;

    ScheduledPayment() {}

    public ScheduledPayment(LocalDate date, BigDecimal paymentAmount, BigDecimal totalAmount) {
        this.date = date;
        this.paymentAmount = paymentAmount;
        this.totalAmount = totalAmount;
    }

    public LocalDate getDate() {
        return date;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public BigDecimal getTotalAmount() { return totalAmount; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        ScheduledPayment that = (ScheduledPayment) o;

        return new EqualsBuilder()
                .append(date, that.date)
                .append(paymentAmount, that.paymentAmount)
                .append(totalAmount, that.totalAmount)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(date)
                .append(paymentAmount)
                .append(totalAmount)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("date", date)
                .append("paymentAmount", paymentAmount)
                .append("totalAmount",totalAmount)
                .toString();
    }
}
