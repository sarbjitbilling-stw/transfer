package sbpackage.api.osgi.model.account;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

public class TargetAccountNumber {

    private final String accountNumber;
    private char checkDigit;
    private final String accountNumberWithCheckDigit;

    /**
     * Constructor for TargetAccountNumber with String parameter for account number
     * @param accountNumber must provide the 9 digit version
     * @param checkDigit must provide if known else send null and it will be calculated for you
     */
    public TargetAccountNumber(String accountNumber, Character checkDigit) {
            super();
            this.accountNumber =  StringUtils.leftPad( accountNumber, 9, '0');
            setCheckDigit(checkDigit);
            StringBuilder sb = new StringBuilder();
            this.accountNumberWithCheckDigit = sb.append(this.accountNumber).append(this.checkDigit).toString();
    }

    /**
     * Constructor for TargetAccountNumber with String parameter for account number
     * @param accountNumberWithCheckDigit must provide the 10 digit version
     */
    public TargetAccountNumber(String accountNumberWithCheckDigit) {
            super();
            this.accountNumber = StringUtils.leftPad( accountNumberWithCheckDigit.substring(0, accountNumberWithCheckDigit.length()-1), 9, '0');
            setCheckDigit(accountNumberWithCheckDigit.charAt(accountNumberWithCheckDigit.length()-1));
            StringBuilder sb = new StringBuilder();
            this.accountNumberWithCheckDigit = sb.append(this.accountNumber).append(this.checkDigit).toString();
    }

    /**
     * Constructor for TargetAccountNumber with Long parameter for account number
     * @param accountNumber must provide the 10 digit version
     */
    public TargetAccountNumber(long accountNumber) {
            String accountId = String.valueOf(accountNumber);
            accountId = StringUtils.leftPad(accountId, 10, '0');
            this.accountNumber = accountId.substring(0, accountId.length()-1);
            setCheckDigit(accountId.charAt(accountId.length()-1));
            StringBuilder sb = new StringBuilder();
            this.accountNumberWithCheckDigit = sb.append(this.accountNumber).append(this.checkDigit).toString();
    }

    /**
     * Constructor for TargetAccountNumber with Long parameter for account number
     * @param accountNumber must provide the 9 digit version
     * @param checkDigit must provide if known else send null and it will be calculated for you
     */
    public TargetAccountNumber(long accountNumber, Character checkDigit) {
            String accountId = String.valueOf(accountNumber);
            accountId = StringUtils.leftPad(accountId, 9, '0');
            this.accountNumber = accountId; 
            setCheckDigit(checkDigit);
            StringBuilder sb = new StringBuilder();
            this.accountNumberWithCheckDigit = sb.append(this.accountNumber).append(this.checkDigit).toString();
    }

    private void setCheckDigit(Character checkDigit1) throws NumberFormatException, IllegalArgumentException {
        this.checkDigit = calculateCheckDigit();
        if (checkDigit1 != null) {
            if (!checkDigit1.equals(this.checkDigit)) {
                String msg = String.format("The provided check digit does not match the expected value for the account expected '%1$s' got '%2$s'", this.checkDigit, checkDigit1);
                throw new IllegalArgumentException(msg);
            }
        }
    }

    public String getAccountNumberWithCheckDigit() {
        return StringUtils.leftPad(this.accountNumberWithCheckDigit, 10, '0');
    }

    public String getAccountNumber() {
        return StringUtils.leftPad(this.accountNumber, 9, '0');
    }

    public long getAccountNumberAsLong() {
        return Long.parseLong(this.accountNumber);
    }

    public long getAccountNumberWithCheckDigitAsLong() {
        return Long.parseLong(this.accountNumberWithCheckDigit);
    }

    public String getCheckDigit() {
        return String.valueOf(this.checkDigit);
    }

    public String get4DigitAccountNumber() {
        String accountNumberStr = getAccountNumberWithCheckDigit();
        return StringUtils.right(accountNumberStr, 4);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.accountNumber);
        hash = 83 * hash + this.checkDigit;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TargetAccountNumber other = (TargetAccountNumber) obj;
        if (this.checkDigit != other.checkDigit) {
            return false;
        }
        if (!Objects.equals(this.accountNumber, other.accountNumber)) {
            return false;
        }
        return true;
    }


    public static boolean isSameAccount(TargetAccountNumber firstAccountNumber, TargetAccountNumber secondAccountNumber ){
        return firstAccountNumber.equals(secondAccountNumber);
    }
       
    public static boolean isSameAccount(TargetAccountNumber firstAccountNumber, String secondAccountNumber ){
       return firstAccountNumber.equals(new TargetAccountNumber(secondAccountNumber));
    }
  
    public static boolean isSameAccount(String firstAccountNumber, TargetAccountNumber secondAccountNumber ){
        return secondAccountNumber.equals(new TargetAccountNumber(firstAccountNumber));
    }

    @Override
    public String toString() {
        return getAccountNumberWithCheckDigit();
    }

    private char calculateCheckDigit() throws NumberFormatException {
        char checkDigit = '0';
        try {
            int total = 0;
            int i = this.accountNumber.length();
            int accountNumeric = Integer.parseInt(this.accountNumber);
            while (accountNumeric > 0 && i >= 0) {
                // Goes from right to left
                int digitVal = accountNumeric % 10;
                if (i % 2 == 0) {
                    if (digitVal < 5) {
                        total += digitVal * 2;
                    } else {
                        total += digitVal * 2 - 9;
                    }
                } else {
                    total += digitVal;
                }
                // We update for the next iteration
                accountNumeric = accountNumeric / 10;
                i--;
            }
            checkDigit = String.valueOf(9 * total % 10).charAt(0);
        } catch (NumberFormatException e) {
            throw e;
        }
        return checkDigit;
    }
       
}


