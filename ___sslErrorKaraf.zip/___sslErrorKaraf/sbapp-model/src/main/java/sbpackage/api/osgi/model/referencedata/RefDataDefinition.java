package sbpackage.api.osgi.model.referencedata;

public enum RefDataDefinition {
    DATA_SHARE_INDICATOR_NO("NO", "N", "828"),
    DATA_SHARE_INDICATOR_YES("YES", "Y", "828"),
    PRIMARY_ROLE("Primary", "P", "0"),
    CO_PRIMARY_ROLE("Co-Primary", "C", "0"),
    EXECUTOR_TEL_LOCATION("Executor", "X", "9"),
    VOICE_TELEPHONE_TYPE("Voice", "V", "10"),
    DATA_SHARE_SOURCE_BLANK("", "", "829"),
    DATA_SHARE_SOURCE_INFORMATION_REQUESTS("Information Requests", "IR", "829"),
    DATA_SHARE_SOURCE_TEL_CUSTOMER_RELATIONS("Telephone Customer Relations", "CR", "829");

    private final String value;
    private final String code;
    private final String valueSet;

    RefDataDefinition(final String value, final String code, final String valueSet) {
        this.value = value;
        this.code = code;
        this.valueSet = valueSet;
    }

    public String getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }

    public String getValueSet() {
        return valueSet;
    }
}
