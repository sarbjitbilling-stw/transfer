package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
public class Attachment {

    private long id;
    private String name;
    private FormAttachment.Status status;

    public boolean hasErrorStatus() {
        return status == FormAttachment.Status.INFECTED || status == FormAttachment.Status.FAILED;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(FormAttachment.Status status) {
        this.status = status;
    }

    public FormAttachment.Status getStatus() {
        return status;
    }
}
