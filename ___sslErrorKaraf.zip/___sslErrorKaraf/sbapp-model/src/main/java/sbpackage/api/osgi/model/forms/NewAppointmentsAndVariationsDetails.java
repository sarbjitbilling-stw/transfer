package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class NewAppointmentsAndVariationsDetails {

    private SupplyDetails waterSupplyDetails;
    private SupplyTerm waterSupplyTerm;
    private SupplyDetailsByYear waterSupplyDetailsByYear;

    private SupplyDetails wasteSupplyDetails;
    private SupplyTerm wasteSupplyTerm;
    private WasteEffluent wasteEffluent;
    private SupplyDetailsByYear wasteSupplyDetailsByYear;

    private String currentStep;

    public SupplyDetails getWaterSupplyDetails() {
        return waterSupplyDetails;
    }

    public void setWaterSupplyDetails(SupplyDetails waterSupplyDetails) {
        this.waterSupplyDetails = waterSupplyDetails;
    }

    public SupplyTerm getWaterSupplyTerm() {
        return waterSupplyTerm;
    }

    public void setWaterSupplyTerm(SupplyTerm waterSupplyTerm) {
        this.waterSupplyTerm = waterSupplyTerm;
    }

    public SupplyDetailsByYear getWaterSupplyDetailsByYear() {
        return waterSupplyDetailsByYear;
    }

    public void setWaterSupplyDetailsByYear(SupplyDetailsByYear waterSupplyDetailsByYear) {
        this.waterSupplyDetailsByYear = waterSupplyDetailsByYear;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public SupplyDetails getWasteSupplyDetails() {
        return wasteSupplyDetails;
    }

    public void setWasteSupplyDetails(SupplyDetails wasteSupplyDetails) {
        this.wasteSupplyDetails = wasteSupplyDetails;
    }

    public SupplyTerm getWasteSupplyTerm() {
        return wasteSupplyTerm;
    }

    public void setWasteSupplyTerm(SupplyTerm wasteSupplyTerm) {
        this.wasteSupplyTerm = wasteSupplyTerm;
    }

    public SupplyDetailsByYear getWasteSupplyDetailsByYear() {
        return wasteSupplyDetailsByYear;
    }

    public void setWasteSupplyDetailsByYear(SupplyDetailsByYear wasteSupplyDetailsByYear) {
        this.wasteSupplyDetailsByYear = wasteSupplyDetailsByYear;
    }

    public WasteEffluent getWasteEffluent() {
        return wasteEffluent;
    }

    public void setWasteEffluent(WasteEffluent wasteEffluent) {
        this.wasteEffluent = wasteEffluent;
    }
}
