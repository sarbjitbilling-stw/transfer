package sbpackage.api.osgi.model;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

@XmlRootElement(name = "ClientReverseBillRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClientReverseBillRequest {

	private Long accountId;
	private Long propertyId;
	
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate moveDate;

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public LocalDate getMoveDate() {
		return moveDate;
	}

	public void setMoveDate(LocalDate moveDate) {
		this.moveDate = moveDate;
	}
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Account Id :[");
		builder.append(accountId);
		builder.append( "], Property Id :[");
		builder.append(propertyId);
		builder.append("], Move Date");
		builder.append(moveDate);
		return builder.toString() ;
		
	}
	
}
