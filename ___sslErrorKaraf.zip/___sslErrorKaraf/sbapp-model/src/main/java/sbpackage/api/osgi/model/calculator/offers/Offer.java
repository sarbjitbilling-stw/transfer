package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.ToStringBuilder;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Offer implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement
    private int group;

    @XmlElement
    private int displayOrder;

    @XmlElement
    private int lengthInMonths;

    private BigDecimal proximityToPreferredPayment = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal avgInstallmentExcludingFirstPymt = BigDecimal.ZERO;

    @XmlElement
    private String offerId;

    @XmlElement
    private String offerDetail;

    @XmlElement
    private boolean isValid = Boolean.TRUE;

    @XmlElement
    private boolean isUnmeasuredFutureStart = false;

    // TP_PAY_PLAN
    // private String payPlanType;

    @XmlElement
    private String accountId;

    @XmlElement
    private ReconciliationMethod reconciliationMethod;

    // private FacilityCode facilityCode;

    // TP_BUDGET_PLAN_176
    private BudgetPlanType budgetPlanType;

    @XmlElement
    private String payPlanType;

    @XmlElement
    private String payPlanComments;

    @XmlElement
    private String paymentMethod;

    @XmlElement
    private String paymentFrequency;

    @XmlElement
    private String planVariant;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate startDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate endDate;

    @XmlElement
    private int preferredPayDay;

    // AM-ORIG-BALANCE
    // private double originalBalAmount;

    // AM-DOWN-PAYMENT
    // private double downPaymentAmount;

    @XmlElement
    private BigDecimal numOfInstallments = BigDecimal.ZERO;

    // private double totalBudgetAmount;

    // private double thirdPartyAmount;

    @XmlElement
    // AM-INSTALLMENT
    private BigDecimal installmentAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal installmentArrearsAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal installmentForecastAmount = BigDecimal.ZERO;

    // private double origTotalBudgetAmount;

    @XmlElement
    private Arrears arrears;

    @XmlElement
    private Arrears baseArrears;

    @XmlElement
    private Arrears originalArrears;

    @XmlElement
    private BigDecimal forecast = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal baseForecast = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal originalForecast = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal accrued = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal baseAccrued = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal originalAccrued = BigDecimal.ZERO;

    @XmlElement
    private boolean conditionalFlag;

    @XmlElement
    private BigDecimal planAmount = BigDecimal.ZERO;

    @XmlElement
    private int month;

    @XmlElement
    private String monthName;

    @XmlElement
    private BigDecimal variantAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal potentialUnderPayment = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal upliftedAccruedPercent = BigDecimal.ZERO;

    @XmlElement
    private List<Installment> installments;

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }

    public int getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(int displayOrder) {
        this.displayOrder = displayOrder;
    }

    public int getLengthInMonths() {
        return lengthInMonths;
    }

    public void setLengthInMonths(int lengthInMonths) {
        this.lengthInMonths = lengthInMonths;
    }

    public BigDecimal getProximityToPreferredPayment() {
        return proximityToPreferredPayment;
    }

    public void setProximityToPreferredPayment(BigDecimal proximityToPreferredPayment) {
        this.proximityToPreferredPayment = proximityToPreferredPayment;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getOfferDetail() {
        return offerDetail;
    }

    public void setOfferDetail(String offerDetail) {
        this.offerDetail = offerDetail;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public ReconciliationMethod getReconciliationMethod() {
        return reconciliationMethod;
    }

    public void setReconciliationMethod(ReconciliationMethod reconciliationMethod) {
        this.reconciliationMethod = reconciliationMethod;
    }

    public BudgetPlanType getBudgetPlanType() {
        return budgetPlanType;
    }

    public void setBudgetPlanType(BudgetPlanType budgetPlanType) {
        this.budgetPlanType = budgetPlanType;
    }

    public String getPayPlanComments() {
        return payPlanComments;
    }

    public void setPayPlanComments(String payPlanComments) {
        this.payPlanComments = payPlanComments;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public String getPlanVariant() {
        return planVariant;
    }

    public void setPlanVariant(String planVariant) {
        this.planVariant = planVariant;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public int getPreferredPayDay() {
        return preferredPayDay;
    }

    public void setPreferredPayDay(int preferredPayDay) {
        this.preferredPayDay = preferredPayDay;
    }

    public BigDecimal getNumOfInstallments() {
        return numOfInstallments;
    }

    public void setNumOfInstallments(BigDecimal numOfInstallments) {
        this.numOfInstallments = numOfInstallments;
    }

    public BigDecimal getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(BigDecimal installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

    public BigDecimal getInstallmentArrearsAmount() {
        return installmentArrearsAmount;
    }

    public void setInstallmentArrearsAmount(BigDecimal installmentArrearsAmount) {
        this.installmentArrearsAmount = installmentArrearsAmount;
    }

    public BigDecimal getInstallmentForecastAmount() {
        return installmentForecastAmount;
    }

    public void setInstallmentForecastAmount(BigDecimal installmentForecastAmount) {
        this.installmentForecastAmount = installmentForecastAmount;
    }

    public Arrears getArrears() {
        return arrears;
    }

    public void setArrears(Arrears arrears) {
        this.arrears = arrears;
    }

    public Arrears getBaseArrears() {
        return baseArrears;
    }

    public void setBaseArrears(Arrears baseArrears) {
        this.baseArrears = baseArrears;
    }

    public BigDecimal getForecast() {
        return forecast;
    }

    public void setForecast(BigDecimal forecast) {
        this.forecast = forecast;
    }

    public BigDecimal getBaseForecast() {
        return baseForecast;
    }

    public void setBaseForecast(BigDecimal baseForecast) {
        this.baseForecast = baseForecast;
    }

    public BigDecimal getAccrued() {
        return accrued;
    }

    public void setAccrued(BigDecimal accrued) {
        this.accrued = accrued;
    }

    public BigDecimal getBaseAccrued() {
        return baseAccrued;
    }

    public void setBaseAccrued(BigDecimal baseAccrued) {
        this.baseAccrued = baseAccrued;
    }

    public boolean isConditionalFlag() {
        return conditionalFlag;
    }

    public void setConditionalFlag(boolean conditionalFlag) {
        this.conditionalFlag = conditionalFlag;
    }

    public BigDecimal getPlanAmount() {
        return planAmount;
    }

    public void setPlanAmount(BigDecimal planAmount) {
        this.planAmount = planAmount;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

    public BigDecimal getVariantAmount() {
        return variantAmount;
    }

    public void setVariantAmount(BigDecimal variantAmount) {
        this.variantAmount = variantAmount;
    }

    public BigDecimal getPotentialUnderPayment() {
        return potentialUnderPayment;
    }

    public void setPotentialUnderPayment(BigDecimal potentialUnderPayment) {
        this.potentialUnderPayment = potentialUnderPayment;
    }

    public List<Installment> getInstallments() {
        return installments;
    }

    public void setInstallments(List<Installment> installments) {
        this.installments = installments;
    }

    public Arrears getOriginalArrears() {
        return originalArrears;
    }

    public void setOriginalArrears(Arrears originalArrears) {
        this.originalArrears = originalArrears;
    }

    public BigDecimal getOriginalForecast() {
        return originalForecast;
    }

    public void setOriginalForecast(BigDecimal originalForecast) {
        this.originalForecast = originalForecast;
    }

    public BigDecimal getOriginalAccrued() {
        return originalAccrued;
    }

    public void setOriginalAccrued(BigDecimal originalAccrued) {
        this.originalAccrued = originalAccrued;
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean valid) {
        isValid = valid;
    }

    public boolean isUnmeasuredFutureStart() {
        return isUnmeasuredFutureStart;
    }

    public void setUnmeasuredFutureStart(boolean isUnmeasuredFutureStart) {
        this.isUnmeasuredFutureStart = isUnmeasuredFutureStart;
    }

    public BigDecimal getAvgInstallmentExcludingFirstPymt() {
        return avgInstallmentExcludingFirstPymt;
    }

    public void setAvgInstallmentExcludingFirstPymt(final BigDecimal avgInstallmentExcludingFirstPymt) {
        this.avgInstallmentExcludingFirstPymt = avgInstallmentExcludingFirstPymt;
    }

    public BigDecimal getUpliftedAccruedPercent() {
        return upliftedAccruedPercent;
    }

    public void setUpliftedAccruedPercent(final BigDecimal upliftedAccruedPercent) {
        this.upliftedAccruedPercent = upliftedAccruedPercent;
    }

    public String getPayPlanType() {
        return payPlanType;
    }

    public void setPayPlanType(final String payPlanType) {
        this.payPlanType = payPlanType;
    }

    /**
     * Zero values in payment plan, similar to how the target client would do it for
     * a future start payment plan. This method needs to be used before sending a
     * future start payment plan to target to be created.
     * 
     * @param offer payment plan offer that is to be zeroed
     */
    public void zeroAmountsForFutureStartPlan() {
        this.getInstallments().stream().forEach(this::zeroInstallmentAmounts);

        // zero header amounts
        this.setInstallmentAmount(BigDecimal.ZERO);
        this.setBaseForecast(BigDecimal.ZERO);
        this.setAccrued(BigDecimal.ZERO);
        this.setOriginalAccrued(BigDecimal.ZERO);
        if (arrears != null) {
            arrears.setAccountArrears(BigDecimal.ZERO);
            arrears.setThirdPartyCharges(BigDecimal.ZERO);
        }
        this.setInstallmentArrearsAmount(BigDecimal.ZERO);
        this.setForecast(BigDecimal.ZERO);
        this.setInstallmentForecastAmount(BigDecimal.ZERO);
        this.setPlanAmount(BigDecimal.ZERO);
        this.setOriginalForecast(BigDecimal.ZERO);
    }

    private void zeroInstallmentAmounts(Installment installment) {
        installment.setInstallmentAmount(BigDecimal.ZERO);
        installment.setInstallmentArrearsAmount(BigDecimal.ZERO);
        installment.setInstallmentForecastAmount(BigDecimal.ZERO);
        installment.setExpectedPaymentDate(null);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("group", group)
                .append("displayOrder", displayOrder)
                .append("lengthInMonths", lengthInMonths)
                .append("proximityToPreferredPayment", proximityToPreferredPayment)
                .append("avgInstallmentExcludingFirstPymt", avgInstallmentExcludingFirstPymt)
                .append("offerId", offerId)
                .append("offerDetail", offerDetail)
                .append("isValid", isValid)
                .append("accountId", accountId)
                .append("reconciliationMethod", reconciliationMethod)
                .append("budgetPlanType", budgetPlanType)
                .append("payPlanType", payPlanType)
                .append("payPlanComments", payPlanComments)
                .append("paymentMethod", paymentMethod)
                .append("paymentFrequency", paymentFrequency)
                .append("planVariant", planVariant)
                .append("startDate", startDate)
                .append("endDate", endDate)
                .append("preferredPayDay", preferredPayDay)
                .append("numOfInstallments", numOfInstallments)
                .append("installmentAmount", installmentAmount)
                .append("installmentArrearsAmount", installmentArrearsAmount)
                .append("installmentForecastAmount", installmentForecastAmount)
                .append("arrears", arrears)
                .append("baseArrears", baseArrears)
                .append("originalArrears", originalArrears)
                .append("forecast", forecast)
                .append("baseForecast", baseForecast)
                .append("originalForecast", originalForecast)
                .append("accrued", accrued)
                .append("baseAccrued", baseAccrued)
                .append("originalAccrued", originalAccrued)
                .append("conditionalFlag", conditionalFlag)
                .append("planAmount", planAmount)
                .append("month", month)
                .append("monthName", monthName)
                .append("variantAmount", variantAmount)
                .append("potentialUnderPayment", potentialUnderPayment)
                .append("upliftedAccruedPercent", upliftedAccruedPercent)
                .append("installments", installments)
                .toString();
    }
}
