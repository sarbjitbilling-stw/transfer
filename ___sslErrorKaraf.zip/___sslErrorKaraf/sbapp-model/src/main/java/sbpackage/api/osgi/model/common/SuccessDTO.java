package sbpackage.api.osgi.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SuccessDTO {

    @JsonProperty("code")
    private String code;

    @JsonProperty("fieldData")
    private Map<String, String> fieldData;

    public SuccessDTO(){}

    public SuccessDTO(String code){
        this.code = code;
    }

    public SuccessDTO(String code, Map<String, String> fieldData){
        this(code);
        this.fieldData = fieldData;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Map<String, String> getFieldData() {
        return fieldData;
    }

    public void putFieldData(String key, String value) {
        if(fieldData == null) {
            fieldData = new HashMap<>();
        }
        fieldData.put(key, value);
    }

    public void setFieldData(Map<String, String> fieldData) {
        this.fieldData = fieldData;
    }

	@Override
	public String toString() {
		return "SuccessDTO [code=" + code + ", fieldData=" + fieldData + "]";
	}
}
