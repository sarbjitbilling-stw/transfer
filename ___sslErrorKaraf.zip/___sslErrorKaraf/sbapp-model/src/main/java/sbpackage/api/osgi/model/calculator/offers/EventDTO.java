package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

public class EventDTO {
    private List<Invoice> invoiceList;
    private List<InvoiceLine> invoiceLineList;
    private List<ServiceProvision> serviceProvisionList;
    private String paginationKey;

    public List<Invoice> getInvoiceList() {
        return invoiceList;
    }

    public void setInvoiceList(List<Invoice> invoiceList) {
        this.invoiceList = invoiceList;
    }

    public List<InvoiceLine> getInvoiceLineList() {
        return invoiceLineList;
    }

    public void setInvoiceLineList(List<InvoiceLine> invoiceLineList) {
        this.invoiceLineList = invoiceLineList;
    }

    public String getPaginationKey() {
        return paginationKey;
    }

    public void setPaginationKey(String paginationKey) {
        this.paginationKey = paginationKey;
    }

    public List<ServiceProvision> getServiceProvisionList() {
        return serviceProvisionList;
    }

    public void setServiceProvisionList(List<ServiceProvision> serviceProvisionList) {
        this.serviceProvisionList = serviceProvisionList;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("invoiceList", invoiceList)
                .append("invoiceLineList", invoiceLineList)
                .append("serviceProvisionList", serviceProvisionList)
                .append("paginationKey", paginationKey)
                .toString();
    }
}
