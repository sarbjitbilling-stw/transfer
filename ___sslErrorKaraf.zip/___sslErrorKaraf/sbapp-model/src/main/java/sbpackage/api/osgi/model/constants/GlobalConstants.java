package sbpackage.api.osgi.model.constants;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

public interface GlobalConstants {

	// Generic constants
	String DATE_PATTERN_WITHOUT_TIME = "yyyy-MM-dd";
	String UNKNOWN_POSTCODE = " ";
	TargetAccountNumber UNKNOWN_ACCOUNT_NUMBER = new TargetAccountNumber(999999999l, null);
	TargetAccountNumber UNKNOWN_ACCOUNT_NUMBER_FOR_CONTACT = new TargetAccountNumber(0l, null);
	
	// Data obfuscation constants
	String FULL_ACCOUNT_OBFUSCATION = "**********";
	String ACCOUNT_OBFUSCATION = "******";
	
	// Email related constants
	String MAIL_SUBJECT_TEMPLATE = "Severn Trent - ";
	String DONT_REPLY_EMAIL = "donotreply@myaccounttestmail.stwater.co.uk";
	String MAIL_SUBJECT_DETAILS_UPDATED = "Account Details Updated";
	String ADD_ROLE_REASON = "Add customer to account";
	String DELETE_ROLE_REASON = "Remove customer from account";
	String UPDATE_ROLE_REASON = "Update account customer";
	
	// Constants for special condition checks
	String LEVEL_1_CHECK_SUFFIX = "_check1";
	String LEVEL_2_CHECK_SUFFIX = "_check2";
	String LEVEL_3_CHECK_SUFFIX = "_check3";

	String APPLICATION_PDF = "application/pdf";
}
