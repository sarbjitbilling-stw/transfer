package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ContactDetailsInfo {

    private Details agentDetails;
    private Details applicantDetails;
    private String userCorrespondenceChoice;
    private String userCorrespondenceChoiceDisplayValue;

    public Details getAgentDetails() {
        return agentDetails;
    }

    public void setAgentDetails(Details agentDetails) {
        this.agentDetails = agentDetails;
    }

    public Details getApplicantDetails() {
        return applicantDetails;
    }

    public void setApplicantDetails(Details applicantDetails) {
        this.applicantDetails = applicantDetails;
    }

    public String getUserCorrespondenceChoice() {
        return userCorrespondenceChoice;
    }

    public void setUserCorrespondenceChoice(String userCorrespondenceChoice) {
        this.userCorrespondenceChoice = userCorrespondenceChoice;
    }

    public String getUserCorrespondenceChoiceDisplayValue() {
        return userCorrespondenceChoiceDisplayValue;
    }

    public void setUserCorrespondenceChoiceDisplayValue(String userCorrespondenceChoiceDisplayValue) {
        this.userCorrespondenceChoiceDisplayValue = userCorrespondenceChoiceDisplayValue;
    }
}
