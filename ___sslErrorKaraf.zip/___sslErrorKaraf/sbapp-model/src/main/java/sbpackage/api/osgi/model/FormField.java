
package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Mark
 */
@XmlRootElement(name = "FormField")
@XmlAccessorType(XmlAccessType.FIELD)
public class FormField {

    @XmlElement(name = "value")
    private String value;
    
    @XmlElement(name = "encrypted")
    private boolean encrypted;
    
    @XmlElement(name = "fieldName")
    private String fieldName;
    
    public FormField() {
        value = StringUtils.EMPTY;
        encrypted = false;
        fieldName = StringUtils.EMPTY;
    }

    public FormField(String value, boolean encrypted) {
        this.value = value;
        this.encrypted = encrypted;
        fieldName = StringUtils.EMPTY;
    }

    public FormField(String value, boolean encrypted, String fieldName) {
        this.value = value;
        this.encrypted = encrypted;
        this.fieldName = fieldName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public boolean isEncrypted() {
        return encrypted;
    }

    public void setEncrypted(boolean encrypted) {
        this.encrypted = encrypted;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }
    
    
}
