package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BdsOfferRequestDetails implements Serializable {
    private static final long serialVersionUID = 7377461035769902795L;

    @XmlElement(required = true)
    private Integer numberOfMonths;

    @XmlElement(required = true)
    private BigDecimal monthlyTariffAmount;

    @XmlElement(required = true)
    private BigDecimal monthlyArrearsAmount;

    public Integer getNumberOfMonths() {
        return numberOfMonths;
    }

    public void setNumberOfMonths(Integer numberOfMonths) {
        this.numberOfMonths = numberOfMonths;
    }

    public BigDecimal getMonthlyTariffAmount() {
        return monthlyTariffAmount;
    }

    public void setMonthlyTariffAmount(BigDecimal monthlyTariffAmount) {
        this.monthlyTariffAmount = monthlyTariffAmount;
    }

    public BigDecimal getMontlyArrearsAmount() {
        return monthlyArrearsAmount;
    }

    public void setMonthlyArrearsAmount(BigDecimal monthlyArrearsAmount) {
        this.monthlyArrearsAmount = monthlyArrearsAmount;
    }

    public BigDecimal getTotalTariffAmount() {
        return monthlyTariffAmount.multiply(new BigDecimal(numberOfMonths));
    }

    public BigDecimal getTotalArrearsAmount() {
        return monthlyArrearsAmount.multiply(new BigDecimal(numberOfMonths));
    }

    public boolean hasOffersInformation() {
        return numberOfMonths != null && monthlyTariffAmount != null && monthlyArrearsAmount != null;
    }
}
