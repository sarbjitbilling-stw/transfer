package sbpackage.api.osgi.model.rechor;

import java.util.Arrays;

public enum ReChorOperation {
    REVERSE_MOVE_IN("RMI", "Reverse Move-in", "move-in"),
    REVERSE_MOVE_OUT("RMO", "Reverse Move-out", "move-out"),
    CREATE_MOVE_IN("CMI", "Create Move-in", "move-in"),
    CREATE_MOVE_OUT("CMO", "Create Move-out", "move-out"),
    CHANGE_MOVE_OUT_DATE("CMOD", "Change Move-out date", "move-out"),
    CHANGE_MOVE_IN_DATE("CMID", "Change Move-in date", "move-in");

    private final String code;
    private final String description;
    private final String basicOperation;

    ReChorOperation(final String code, final String description, final String basicOperation) {
        this.code = code;
        this.description = description;
        this.basicOperation = basicOperation;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public String getBasicOperation() {
        return basicOperation;
    }

    public static ReChorOperation findByCode(final String code) {
        return Arrays.stream(ReChorOperation.values()).filter(item -> item.code.equalsIgnoreCase(code)).findFirst().orElse(null);
    }
}
