package sbpackage.api.osgi.model.calculator.offers;

public enum PaymentPlanOfferLevel {
    STANDARD(1),
    UNMEASURED_FLEX_SHORT(2),
    UNMEASURED_FLEX_LONG(3),
    FLEX(3),
    PPC(4);

    private final int offerLevel;

    PaymentPlanOfferLevel(int offerLevel) {
        this.offerLevel = offerLevel;
    }

    public int getOfferLevel() {
        return offerLevel;
    }
}
