package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({"waterCloset", "automaticFlushingCistern", "basinsHousehold", "basinsElsewhere", "bathsLessThan20mm", "bathsMoreThan20mm", "showers",
        "sinksTapSizeLessThan15mm", "sinksTapsSizeGreaterThan15mm", "sinksCleaners", "singleSprayTap", "bidets", "appliancesDomestic", "appliancesCommercial",
        "drinksVendingMachines", "hoseBibTap15mm", "hoseBibTap22mm", "hoseBibTap25mm", "otherFittings"})
public class FittingsList {

    private int appliancesDomestic;
    private int appliancesCommercial;
    private int automaticFlushingCistern;
    private int basinsHousehold;
    private int basinsElsewhere;
    private int bathsLessThan20mm;
    private int bathsMoreThan20mm;
    private int bidets;
    private int drinksVendingMachines;
    private int hoseBibTap15mm;
    private int hoseBibTap22mm;
    private int hoseBibTap25mm;
    private int showers;
    private int singleSprayTap;
    private int sinksCleaners;
    private int sinksTapSizeLessThan15mm;
    private int sinksTapsSizeGreaterThan15mm;
    private int waterCloset;
    private int otherFittings;

    @JsonIgnore
    Logger log = LoggerFactory.getLogger(this.getClass());

    public void merge(FittingsList fittingsList) {
        try {
            Map<String, Object> existingFittingsPropertyMap = PropertyUtils.describe(this);
            Map<String, Object> newFittingsPropertyMap = PropertyUtils.describe(fittingsList);
            for(Map.Entry<String, Object> field : newFittingsPropertyMap.entrySet()) {
                if (field.getValue() instanceof Integer) {
                    int newValue = (int)field.getValue();
                    if(newValue > 0) {
                        int existingValue = existingFittingsPropertyMap.get(field.getKey()) != null ? (int) existingFittingsPropertyMap.get(field.getKey()) : 0;
                        existingValue += newValue;
                        PropertyUtils.setProperty(this, field.getKey(), existingValue);
                    }
                }
            }
        } catch(Exception e) {
            log.error("Unable to merge fittings {} into {}", fittingsList, this, e);
            throw new RuntimeException(e);
        }
    }

    public int getAppliancesDomestic() {
        return appliancesDomestic;
    }

    public void setAppliancesDomestic(int appliancesDomestic) {
        this.appliancesDomestic = appliancesDomestic;
    }

    public int getAppliancesCommercial() {
        return appliancesCommercial;
    }

    public void setAppliancesCommercial(int appliancesCommercial) {
        this.appliancesCommercial = appliancesCommercial;
    }

    public int getAutomaticFlushingCistern() {
        return automaticFlushingCistern;
    }

    public void setAutomaticFlushingCistern(int automaticFlushingCistern) {
        this.automaticFlushingCistern = automaticFlushingCistern;
    }

    public int getBasinsHousehold() {
        return basinsHousehold;
    }

    public void setBasinsHousehold(int basinsHousehold) {
        this.basinsHousehold = basinsHousehold;
    }

    public int getBasinsElsewhere() {
        return basinsElsewhere;
    }

    public void setBasinsElsewhere(int basinsElsewhere) {
        this.basinsElsewhere = basinsElsewhere;
    }

    public int getBathsLessThan20mm() {
        return bathsLessThan20mm;
    }

    public void setBathsLessThan20mm(int bathsLessThan20mm) {
        this.bathsLessThan20mm = bathsLessThan20mm;
    }

    public int getBathsMoreThan20mm() {
        return bathsMoreThan20mm;
    }

    public void setBathsMoreThan20mm(int bathsMoreThan20mm) {
        this.bathsMoreThan20mm = bathsMoreThan20mm;
    }

    public int getBidets() {
        return bidets;
    }

    public void setBidets(int bidets) {
        this.bidets = bidets;
    }

    public int getDrinksVendingMachines() {
        return drinksVendingMachines;
    }

    public void setDrinksVendingMachines(int drinksVendingMachines) {
        this.drinksVendingMachines = drinksVendingMachines;
    }

    public int getHoseBibTap15mm() {
        return hoseBibTap15mm;
    }

    public void setHoseBibTap15mm(int hoseBibTap15mm) {
        this.hoseBibTap15mm = hoseBibTap15mm;
    }

    public int getHoseBibTap22mm() {
        return hoseBibTap22mm;
    }

    public void setHoseBibTap22mm(int hoseBibTap22mm) {
        this.hoseBibTap22mm = hoseBibTap22mm;
    }

    public int getHoseBibTap25mm() {
        return hoseBibTap25mm;
    }

    public void setHoseBibTap25mm(int hoseBibTap25mm) {
        this.hoseBibTap25mm = hoseBibTap25mm;
    }

    public int getShowers() {
        return showers;
    }

    public void setShowers(int showers) {
        this.showers = showers;
    }

    public int getSingleSprayTap() {
        return singleSprayTap;
    }

    public void setSingleSprayTap(int singleSprayTap) {
        this.singleSprayTap = singleSprayTap;
    }

    public int getSinksCleaners() {
        return sinksCleaners;
    }

    public void setSinksCleaners(int sinksCleaners) {
        this.sinksCleaners = sinksCleaners;
    }

    public int getSinksTapSizeLessThan15mm() {
        return sinksTapSizeLessThan15mm;
    }

    public void setSinksTapSizeLessThan15mm(int sinksTapSizeLessThan15mm) {
        this.sinksTapSizeLessThan15mm = sinksTapSizeLessThan15mm;
    }

    public int getSinksTapsSizeGreaterThan15mm() {
        return sinksTapsSizeGreaterThan15mm;
    }

    public void setSinksTapsSizeGreaterThan15mm(int sinksTapsSizeGreaterThan15mm) {
        this.sinksTapsSizeGreaterThan15mm = sinksTapsSizeGreaterThan15mm;
    }

    public int getWaterCloset() {
        return waterCloset;
    }

    public void setWaterCloset(int waterCloset) {
        this.waterCloset = waterCloset;
    }

    public int getOtherFittings() {
        return otherFittings;
    }

    public void setOtherFittings(int otherFittings) {
        this.otherFittings = otherFittings;
    }
}
