package sbpackage.api.osgi.model.payment.bill;

import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.ProcessOutcomeList;
import sbpackage.api.osgi.model.ProcessOutcome;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlType()
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Bill {

	private String accountNumber;

	private String propertyId;

	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate endDate;

	private Float currentBalAmount;
	
	private Float finalBalAmount;
	
	private Float billedRunAmount;
	
	private LocalDate billStartDate;
	
	private LocalDate billEndDate;
	
	private Long numOfDays;
	
	private Long combinedNum;
	
	private List<BillEvent> billEvents;
	
	private ProcessOutcome processOutcome;
	
	private ProcessOutcomeList processOutcomeList;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Float getCurrentBalAmount() {
		return currentBalAmount;
	}

	public void setCurrentBalAmount(Float currentBalAmount) {
		this.currentBalAmount = currentBalAmount;
	}
	
	public Float getFinalBalAmount() {
		return finalBalAmount;
	}

	public void setFinalBalAmount(Float finalBalAmount) {
		this.finalBalAmount = finalBalAmount;
	}
	
	public Float getBilledRunAmount() {
		return billedRunAmount;
	}

	public void setBilledRunAmount(Float billedRunAmount) {
		this.billedRunAmount = billedRunAmount;
	}
	
	public LocalDate getBillStartDate() {
		return billStartDate;
	}

	public void setBillStartDate(LocalDate billStartDate) {
		this.billStartDate = billStartDate;
	}

	public LocalDate getBillEndDate() {
		return billEndDate;
	}

	public void setBillEndDate(LocalDate billEndDate) {
		this.billEndDate = billEndDate;
	}

	public Long getNumOfDays() {
		return numOfDays;
	}

	public void setNumOfDays(Long numOfDays) {
		this.numOfDays = numOfDays;
	}

	public Long getCombinedNum() {
		return combinedNum;
	}

	public void setCombinedNum(Long combinedNum) {
		this.combinedNum = combinedNum;
	}

	public List<BillEvent> getBillEvents() {
		return billEvents;
	}

	public void setBillEvents(List<BillEvent> billEvents) {
		this.billEvents = billEvents;
	}

	public ProcessOutcome getProcessOutcome() {
		return processOutcome;
	}

	public void setProcessOutcome(ProcessOutcome processOutcome) {
		this.processOutcome = processOutcome;
	}

	public ProcessOutcomeList getProcessOutcomeList() {
		return processOutcomeList;
	}

	public void setProcessOutcomeList(ProcessOutcomeList processOutcomeList) {
		this.processOutcomeList = processOutcomeList;
	}
	
}