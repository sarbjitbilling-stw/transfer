package sbpackage.api.osgi.model.calculator.offers;

public enum ServiceProvisionConstants {
    TARIFF_END_DATE_ACTIVE("ACTIVE");

    private final String name;

    ServiceProvisionConstants(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
