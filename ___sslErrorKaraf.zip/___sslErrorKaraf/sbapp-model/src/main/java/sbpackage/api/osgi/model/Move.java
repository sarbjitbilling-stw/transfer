package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Move")
@XmlAccessorType(XmlAccessType.FIELD)
public class Move {

	private MoveDetails incomingMoveDetails;

	private MoveDetails outgoingMoveDetails;

	private Property property;

    private boolean movingOutsideServicedArea;

	public MoveDetails getIncomingMoveDetails() {
		return incomingMoveDetails;
	}

	public void setIncomingMoveDetails(MoveDetails incomingMoveDetails) {
		this.incomingMoveDetails = incomingMoveDetails;
	}

	public MoveDetails getOutgoingMoveDetails() {
		return outgoingMoveDetails;
	}

	public void setOutgoingMoveDetails(MoveDetails outgoingMoveDetails) {
		this.outgoingMoveDetails = outgoingMoveDetails;
	}

	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

    public boolean isMovingOutsideServicedArea() {
        return movingOutsideServicedArea;
    }

    public void setMovingOutsideServicedArea(boolean movingOutsideServicedArea) {
        this.movingOutsideServicedArea = movingOutsideServicedArea;
    }

	@Override
	public String toString() {
		return "Move [incomingMoveDetails=" + incomingMoveDetails + ", outgoingMoveDetails=" + outgoingMoveDetails
				+ ", property=" + property + "]";
	}
	
	

}
