package sbpackage.api.osgi.model.metering;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterReadType")
@XmlRootElement(name = "MeterReadType")
public class MeterReadType {

    @XmlElement(name = "readingType")
    private String readingType;
    @XmlElement(name = "readingPolicyIndicator")
    private String readingPolicyIndicator;
    @XmlElement(name = "readingTypeDescription")
    private String readingTypeDescription;
    @XmlElement(name = "cyclicConcurrencyCheck")
    private long cyclicConcurrencyCheck;
    @XmlElement(name = "activeIndicator")
    private String activeIndicator;
    @XmlElement(name = "defaultFlag")
    private String defaultFlag;

    public MeterReadType() {
    }

    public MeterReadType(MeterReadType readType) {
        readingType = readType.getReadingType();
        readingPolicyIndicator = readType.getReadingPolicyIndicator();
        readingTypeDescription = readType.getReadingTypeDescription();
        cyclicConcurrencyCheck = readType.getCyclicConcurrencyCheck();
        activeIndicator = readType.getActiveIndicator();
        defaultFlag = readType.getDefaultFlag();
    }

    public String getReadingType() {
        return readingType;
    }

    public void setReadingType(String readingType) {
        this.readingType = readingType;
    }

    public String getReadingPolicyIndicator() {
        return readingPolicyIndicator;
    }

    public void setReadingPolicyIndicator(String readingPolicyIndicator) {
        this.readingPolicyIndicator = readingPolicyIndicator;
    }

    public String getReadingTypeDescription() {
        return readingTypeDescription;
    }

    public void setReadingTypeDescription(String readingTypeDescription) {
        this.readingTypeDescription = readingTypeDescription;
    }

    public long getCyclicConcurrencyCheck() {
        return cyclicConcurrencyCheck;
    }

    public void setCyclicConcurrencyCheck(long cyclicConcurrencyCheck) {
        this.cyclicConcurrencyCheck = cyclicConcurrencyCheck;
    }

    public String getActiveIndicator() {
        return activeIndicator;
    }

    public void setActiveIndicator(String activeIndicator) {
        this.activeIndicator = activeIndicator;
    }

    public String getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(String defaultFlag) {
        this.defaultFlag = defaultFlag;
    }

}
