package sbpackage.api.osgi.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Username implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("generatedUsername")
	private String generatedUsername;

	public String getGeneratedUsername() {
		return generatedUsername;
	}

	public void setGeneratedUsername(String generatedUsername) {
		this.generatedUsername = generatedUsername;
	}

}
