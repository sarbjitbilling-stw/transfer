package sbpackage.api.osgi.model.rechor;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.time.LocalDate;

@XmlRootElement(name = "AccountChainRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class AccountChainRequest implements Serializable {

    @XmlElement
    private TargetAccountNumber accountNumber;

    @XmlElement
    private String legalEntityId;

    @XmlElement
    private Long propertyId;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate moveInDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate moveOutDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate newMoveOutDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate newMoveInDate;

    private boolean isMoveInEndOfChain;
    private boolean isMoveOutEndOfChain;

    private boolean actionRequiredOnMoveInReverse;
    private boolean actionRequiredOnMoveInCreate;
    private boolean actionRequiredOnMoveOutReverse;
    private boolean actionRequiredOnMoveOutCreate;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(final TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntityId() {
        return legalEntityId;
    }

    public void setLegalEntityId(final String legalEntityId) {
        this.legalEntityId = legalEntityId;
    }

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(final Long propertyId) {
        this.propertyId = propertyId;
    }

    public LocalDate getMoveInDate() {
        return moveInDate;
    }

    public void setMoveInDate(final LocalDate moveInDate) {
        this.moveInDate = moveInDate;
    }

    public LocalDate getMoveOutDate() {
        return moveOutDate;
    }

    public void setMoveOutDate(final LocalDate moveOutDate) {
        this.moveOutDate = moveOutDate;
    }

    public LocalDate getNewMoveOutDate() {
        return newMoveOutDate;
    }

    public void setNewMoveOutDate(final LocalDate newMoveOutDate) {
        this.newMoveOutDate = newMoveOutDate;
    }

    public LocalDate getNewMoveInDate() {
        return newMoveInDate;
    }

    public void setNewMoveInDate(final LocalDate newMoveInDate) {
        this.newMoveInDate = newMoveInDate;
    }

    public boolean isMoveInEndOfChain() {
        return isMoveInEndOfChain;
    }

    public void setMoveInEndOfChain(final boolean moveInEndOfChain) {
        isMoveInEndOfChain = moveInEndOfChain;
    }

    public boolean isMoveOutEndOfChain() {
        return isMoveOutEndOfChain;
    }

    public void setMoveOutEndOfChain(final boolean moveOutEndOfChain) {
        isMoveOutEndOfChain = moveOutEndOfChain;
    }

    public boolean isActionRequiredOnMoveOutReverse() {
        return actionRequiredOnMoveOutReverse;
    }

    public void setActionRequiredOnMoveOutReverse(final boolean actionRequiredOnMoveOutReverse) {
        this.actionRequiredOnMoveOutReverse = actionRequiredOnMoveOutReverse;
    }

    public boolean isActionRequiredOnMoveOutCreate() {
        return actionRequiredOnMoveOutCreate;
    }

    public void setActionRequiredOnMoveOutCreate(final boolean actionRequiredOnMoveOutCreate) {
        this.actionRequiredOnMoveOutCreate = actionRequiredOnMoveOutCreate;
    }

    public boolean isActionRequiredOnMoveInReverse() {
        return actionRequiredOnMoveInReverse;
    }

    public void setActionRequiredOnMoveInReverse(final boolean actionRequiredOnMoveInReverse) {
        this.actionRequiredOnMoveInReverse = actionRequiredOnMoveInReverse;
    }

    public boolean isActionRequiredOnMoveInCreate() {
        return actionRequiredOnMoveInCreate;
    }

    public void setActionRequiredOnMoveInCreate(final boolean actionRequiredOnMoveInCreate) {
        this.actionRequiredOnMoveInCreate = actionRequiredOnMoveInCreate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountNumber", accountNumber)
                .append("legalEntityId", legalEntityId)
                .append("propertyId", propertyId)
                .append("moveInDate", moveInDate)
                .append("moveOutDate", moveOutDate)
                .append("newMoveOutDate", newMoveOutDate)
                .append("newMoveInDate", newMoveInDate)
                .append("isMoveInEndOfChain", isMoveInEndOfChain)
                .append("isMoveOutEndOfChain", isMoveOutEndOfChain)
                .append("actionRequiredOnMoveInReverse", actionRequiredOnMoveInReverse)
                .append("actionRequiredOnMoveInCreate", actionRequiredOnMoveInCreate)
                .append("actionRequiredOnMoveOutReverse", actionRequiredOnMoveOutReverse)
                .append("actionRequiredOnMoveOutCreate", actionRequiredOnMoveOutCreate)
                .toString();
    }
}