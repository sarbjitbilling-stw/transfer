package sbpackage.api.osgi.model.bill.simulate;


import java.util.Arrays;
import java.util.Optional;

public enum SimulateBillTargetWarning {

    NO_ACTIVE_SERVICES_TO_BILL("502020", SimulateBillWarning.SIMULATE_BILL_WARNING);

    private final String targetCode;
    private final SimulateBillWarning category;

    SimulateBillTargetWarning(final String targetCode, final SimulateBillWarning category) {
        this.targetCode = targetCode;
        this.category = category;
    }

    public String getTargetCode() {
        return targetCode;
    }

    public SimulateBillWarning getCategory() {
        return category;
    }

    static public boolean isValid(String targetCode) {
        return Arrays.stream(SimulateBillTargetWarning.values()).anyMatch(item -> item.getTargetCode().equalsIgnoreCase(targetCode));
    }

    static public Optional<SimulateBillTargetWarning> find(String targetCode) {
        return Arrays.stream(SimulateBillTargetWarning.values())
                .filter(item -> item.getTargetCode().equalsIgnoreCase(targetCode)).findFirst();
    }

}