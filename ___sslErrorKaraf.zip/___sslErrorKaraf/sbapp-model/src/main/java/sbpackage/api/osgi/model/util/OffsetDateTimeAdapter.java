package sbpackage.api.osgi.model.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class OffsetDateTimeAdapter extends XmlAdapter<String, OffsetDateTime> {

    public OffsetDateTime unmarshal(String input) {
		return OffsetDateTime.parse(input, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    public String marshal(OffsetDateTime input) {
    	return input.format(DateTimeFormatter.ISO_DATE_TIME);
    }
}