package sbpackage.api.osgi.model.healthcheck;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;


@XmlRootElement(name = "HealthCheckStatus")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class HealthCheckStatus {

    @XmlElement(name = "version")
    private String version;

    @XmlElement(name = "overallStatus")
    private String overallStatus;

    @XmlElement(name = "totalInactiveBundles")
    private int totalInactiveBundles;

    @XmlElement(name = "bundleStatus")
    private Map<String, String> bundleStatus;

    @XmlElement(name = "integrationHealthChecks")
    private Map<String, HealthCheck> integrationHealthChecks;

    @XmlElement(name = "schedulerStatus")
    private SchedulersStatus schedulersStatus;

    @XmlElement(name = "emailBatchItemStatus")
    private EmailBatchItemStatus emailBatchItemStatus;

    public void putStatus(String bundleName, String status) {
        if (bundleStatus == null) {
            bundleStatus = new HashMap<>();
        }
        bundleStatus.put(bundleName, status);
    }
}
