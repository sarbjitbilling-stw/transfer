package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IDVStatus", propOrder =

/*{ "successStatus", "errorStatus", "inProgressStatus", "alreadyRegisteredStatus", "noLeFoundStatus" }) */
{ "status" })

@XmlRootElement(name = "IDVStatus")
public class IDVStatus {
	
	@XmlElement(name = "status")
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	} 
}
