package sbpackage.api.osgi.model.calculator.consumption;

public enum ServiceType{
    WATER, SURFACE_WATER, USED_WATER, HIGHWAYS_DRAINAGE
}

