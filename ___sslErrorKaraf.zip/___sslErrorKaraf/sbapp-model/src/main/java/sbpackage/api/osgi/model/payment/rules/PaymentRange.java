package sbpackage.api.osgi.model.payment.rules;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by rtai on 17/04/2017.
 */
@XmlType(name = "PaymentRange")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentRange {

    public static final class Options {

        public static final String NONE = "none";

        public static final String AMOUNT_DUE = "amountDue";

        public static final String ACCOUNT_BALANCE = "accountBalance";

        public static final String OTHER_AMOUNT = "otherAmount";

        public static final String[] NO_OPTIONS = {};

        public static final String[] AMOUNT_DUE_OTHER_OPTIONS = {AMOUNT_DUE, OTHER_AMOUNT};

        public static final String[] ACCOUNT_BALANCE_OTHER_OPTIONS = {ACCOUNT_BALANCE, OTHER_AMOUNT};

        public static final String[] ACCOUNT_BALANCE_AMOUNT_DUE_OPTIONS = {AMOUNT_DUE, ACCOUNT_BALANCE};

        public static final String[] ALL_OPTIONS = {AMOUNT_DUE, ACCOUNT_BALANCE, OTHER_AMOUNT};

        public static final String[] ACCOUNT_BALANCE_OPTION = {ACCOUNT_BALANCE};

        public static final String[] OTHER_AMOUNT_OPTION = {OTHER_AMOUNT};
    }

    @XmlElement(name = "minimum")
    private BigDecimal minimum;

    @XmlElement(name = "maximum")
    private BigDecimal maximum;

    @XmlElement(name = "selectionOptions")
    private String[] selectionOptions;

    @XmlElement(name = "defaultSelection")
    private String defaultSelection;

    public PaymentRange() {}

    public PaymentRange(BigDecimal minimum, BigDecimal maximum) {
        this(minimum, maximum, Options.ALL_OPTIONS, Options.AMOUNT_DUE);
    }

    public PaymentRange(BigDecimal minimum, BigDecimal maximum, String[] selectionOptions, String defaultSelection) {
        this.minimum = minimum.setScale(2);
        this.maximum = maximum.setScale(2);
        this.selectionOptions = selectionOptions;
        this.defaultSelection = defaultSelection;
    }

    public String getDefaultSelection() {
        return defaultSelection;
    }

    public String[] getSelectionOptions() {
        return selectionOptions;
    }

    public BigDecimal getMinimum() {
        return minimum;
    }

    public BigDecimal getMaximum() {
        return maximum;
    }

    public boolean isWithinRange(BigDecimal value) {
        if(value != null) {
            return ((minimum.compareTo(value) <= 0) && value.compareTo(maximum) <= 0);
        } else {
            return false;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PaymentRange that = (PaymentRange) o;

        return new EqualsBuilder()
                .append(minimum, that.minimum)
                .append(maximum, that.maximum)
                .append(selectionOptions, that.selectionOptions)
                .append(defaultSelection, that.defaultSelection)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(minimum)
                .append(maximum)
                .append(selectionOptions)
                .append(defaultSelection)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("minimum", minimum)
                .append("maximum", maximum)
                .append("selectionOptions", selectionOptions)
                .append("defaultSelection", defaultSelection)
                .toString();
    }
}
