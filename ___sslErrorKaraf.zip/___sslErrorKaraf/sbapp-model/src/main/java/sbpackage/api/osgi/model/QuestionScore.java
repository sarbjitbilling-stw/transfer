package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlType(name = "QuestionScore")
@XmlEnum
public enum QuestionScore implements SurveyQuestion {

    @XmlEnumValue(value = "VERY_UNHAPPY")
    VERY_UNHAPPY(1),
    @XmlEnumValue(value = "UNHAPPY")
    UNHAPPY(2),
    @XmlEnumValue(value = "SATISFIED")
    SATISFIED(3),
    @XmlEnumValue(value = "HAPPY")
    HAPPY(4),
    @XmlEnumValue(value = "VERY_HAPPY")
    VERY_HAPPY(5);

    private int score;

    QuestionScore(int score) {
        this.score = score;
    }

    @Override
    public int getValue() {
        return this.score;
    }

    public static QuestionScore fromValue(int value) {
        for (QuestionScore qs : values()) {
            if (qs.getValue()==value) {
                return qs;
            }
        }
        return null;
    }

}
