package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class WaterWasteConnection {

    private List<Integer> connectedToWasteOptions;

    public List<Integer> getConnectedToWasteOptions() {
        return connectedToWasteOptions;
    }

    public void setConnectedToWasteOptions(List<Integer> connectedToWasteOptions) {
        this.connectedToWasteOptions = connectedToWasteOptions;
    }
}
