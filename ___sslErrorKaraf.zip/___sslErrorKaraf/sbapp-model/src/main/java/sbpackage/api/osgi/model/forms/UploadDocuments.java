package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class UploadDocuments {

    private List<Attachment> sitePlan = new ArrayList<>();
    private List<Attachment> sitePlanAutoCad = new ArrayList<>();
    private List<Attachment> sitePlanWithDrawing = new ArrayList<>();
    private List<Attachment> sitePlanWithDiversion = new ArrayList<>();
    private List<Attachment> soilAnalysis = new ArrayList<>();
    private List<Attachment> partGComplianceReport = new ArrayList<>();
    private List<Attachment> drainageLayoutPlan = new ArrayList<>();
    private List<Attachment> riskAssessmentStatement = new ArrayList<>();
    private List<Attachment> soakAwayEvidence = new ArrayList<>();
    private List<Attachment> pumpSpecification = new ArrayList<>();
    private List<Attachment> existingDrainage = new ArrayList<>();
    private List<Attachment> additionalDocuments = new ArrayList<>();
    private List<Attachment> longitudinalSectionOfSewers = new ArrayList<>();
    private List<Attachment> validPlanningPermission = new ArrayList<>();
    private List<Attachment> cctvOfTheSewer = new ArrayList<>();
    private List<Attachment> ordnancePlan = new ArrayList<>();
    private List<Attachment> proofOfOwnerShip = new ArrayList<>();
    private List<Attachment> layoutPlan = new ArrayList<>();
    private List<Attachment> manHoleDetailDrawing = new ArrayList<>();
    private List<Attachment> designCalculations = new ArrayList<>();
    private List<Attachment> drainageAreaPlan = new ArrayList<>();
    private List<Attachment> floodRouteDetails = new ArrayList<>();
    private List<Attachment> flowControlDetailDrawing = new ArrayList<>();
    private List<Attachment> headWallDetailDrawing = new ArrayList<>();
    private List<Attachment> approvalForTheDischargeToWaterCourse = new ArrayList<>();
    private List<Attachment> consentForConstructionOfHeadWallStructure = new ArrayList<>();
    private List<Attachment> sudsDrawing = new ArrayList<>();
    private List<Attachment> layoutPlanOfCompound = new ArrayList<>();
    private List<Attachment> sectionsAndDetailsOfWetWellChambers = new ArrayList<>();
    private List<Attachment> longitudinalSectionsRisingMain = new ArrayList<>();
    private List<Attachment> hydraulicCalculation = new ArrayList<>();
    private List<Attachment> generalArrangementDrawing = new ArrayList<>();
    private List<Attachment> detailsOfDepthConstruction = new ArrayList<>();
    private List<Attachment> subSurfaceStudy = new ArrayList<>();
    private List<Attachment> chainageOfSectionalDrawings = new ArrayList<>();
    private List<Attachment> topographicalLevelsDrawing = new ArrayList<>();
    private List<Attachment> ordnanceSurveyBenchmark = new ArrayList<>();
    private List<Attachment> cumulativeVolumeCalculations = new ArrayList<>();
    private List<Attachment> tradeEffluentFlows = new ArrayList<>();
    private List<Attachment> peakSurfaceWaterCalculations = new ArrayList<>();
    private List<Attachment> surfaceWaterDischargeCalculations = new ArrayList<>();
    private List<Attachment> soilInvestigationReport = new ArrayList<>();
    private List<Attachment> pipeSchedule = new ArrayList<>();
    private List<Attachment> microdrainageHydraulicModels = new ArrayList<>();

    private boolean hasProtectivePipework;

    public List<Attachment> getSitePlan() {
        return sitePlan;
    }

    public void setSitePlan(List<Attachment> sitePlan) {
        this.sitePlan = sitePlan;
    }

    public List<Attachment> getSitePlanAutoCad() {
        return sitePlanAutoCad;
    }

    public void setSitePlanAutoCad(List<Attachment> sitePlanAutoCad) {
        this.sitePlanAutoCad = sitePlanAutoCad;
    }

    public List<Attachment> getSitePlanWithDrawing() {
        return sitePlanWithDrawing;
    }

    public void setSitePlanWithDrawing(List<Attachment> sitePlanWithDrawing) {
        this.sitePlanWithDrawing = sitePlanWithDrawing;
    }

    public List<Attachment> getSoilAnalysis() {
        return soilAnalysis;
    }

    public void setSoilAnalysis(List<Attachment> soilAnalysis) {
        this.soilAnalysis = soilAnalysis;
    }

    public List<Attachment> getPartGComplianceReport() {
        return partGComplianceReport;
    }

    public void setPartGComplianceReport(List<Attachment> partGComplianceReport) {
        this.partGComplianceReport = partGComplianceReport;
    }

    public List<Attachment> getAdditionalDocuments() {
        return additionalDocuments;
    }

    public void setAdditionalDocuments(List<Attachment> additionalDocuments) {
        this.additionalDocuments = additionalDocuments;
    }

    public List<Attachment> getDrainageLayoutPlan() {
        return drainageLayoutPlan;
    }

    public void setDrainageLayoutPlan(List<Attachment> drainageLayoutPlan) {
        this.drainageLayoutPlan = drainageLayoutPlan;
    }

    public List<Attachment> getRiskAssessmentStatement() {
        return riskAssessmentStatement;
    }

    public void setRiskAssessmentStatement(List<Attachment> riskAssessmentStatement) {
        this.riskAssessmentStatement = riskAssessmentStatement;
    }

    public List<Attachment> getSoakAwayEvidence() {
        return soakAwayEvidence;
    }

    public void setSoakAwayEvidence(List<Attachment> soakAwayEvidence) {
        this.soakAwayEvidence = soakAwayEvidence;
    }

    public List<Attachment> getPumpSpecification() {
        return pumpSpecification;
    }

    public void setPumpSpecification(List<Attachment> pumpSpecification) {
        this.pumpSpecification = pumpSpecification;
    }

    public List<Attachment> getExistingDrainage() {
        return existingDrainage;
    }

    public void setExistingDrainage(List<Attachment> existingDrainage) {
        this.existingDrainage = existingDrainage;
    }

    public boolean getHasProtectivePipework() {
        return hasProtectivePipework;
    }

    public void setHasProtectivePipework(boolean hasProtectivePipework) {
        this.hasProtectivePipework = hasProtectivePipework;
    }

    public List<Attachment> getSitePlanWithDiversion() {
        return sitePlanWithDiversion;
    }

    public void setSitePlanWithDiversion(List<Attachment> sitePlanWithDiversion) {
        this.sitePlanWithDiversion = sitePlanWithDiversion;
    }

    public List<Attachment> getLongitudinalSectionOfSewers() {
        return longitudinalSectionOfSewers;
    }

    public void setLongitudinalSectionOfSewers(List<Attachment> longitudinalSectionOfSewers) {
        this.longitudinalSectionOfSewers = longitudinalSectionOfSewers;
    }

    public List<Attachment> getValidPlanningPermission() {
        return validPlanningPermission;
    }

    public void setValidPlanningPermission(List<Attachment> validPlanningPermission) {
        this.validPlanningPermission = validPlanningPermission;
    }

    public List<Attachment> getCctvOfTheSewer() {
        return cctvOfTheSewer;
    }

    public void setCctvOfTheSewer(List<Attachment> cctvOfTheSewer) {
        this.cctvOfTheSewer = cctvOfTheSewer;
    }

    public List<Attachment> getOrdnancePlan() {
        return ordnancePlan;
    }

    public void setOrdnancePlan(List<Attachment> ordnancePlan) {
        this.ordnancePlan = ordnancePlan;
    }

    public List<Attachment> getProofOfOwnerShip() {
        return proofOfOwnerShip;
    }

    public void setProofOfOwnerShip(List<Attachment> proofOfOwnerShip) {
        this.proofOfOwnerShip = proofOfOwnerShip;
    }

    public List<Attachment> getLayoutPlan() {
        return layoutPlan;
    }

    public void setLayoutPlan(List<Attachment> layoutPlan) {
        this.layoutPlan = layoutPlan;
    }

    public List<Attachment> getManHoleDetailDrawing() {
        return manHoleDetailDrawing;
    }

    public void setManHoleDetailDrawing(List<Attachment> manHoleDetailDrawing) {
        this.manHoleDetailDrawing = manHoleDetailDrawing;
    }

    public List<Attachment> getDesignCalculations() {
        return designCalculations;
    }

    public void setDesignCalculations(List<Attachment> designCalculations) {
        this.designCalculations = designCalculations;
    }

    public List<Attachment> getDrainageAreaPlan() {
        return drainageAreaPlan;
    }

    public void setDrainageAreaPlan(List<Attachment> drainageAreaPlan) {
        this.drainageAreaPlan = drainageAreaPlan;
    }

    public List<Attachment> getFloodRouteDetails() {
        return floodRouteDetails;
    }

    public void setFloodRouteDetails(List<Attachment> floodRouteDetails) {
        this.floodRouteDetails = floodRouteDetails;
    }

    public List<Attachment> getFlowControlDetailDrawing() {
        return flowControlDetailDrawing;
    }

    public void setFlowControlDetailDrawing(List<Attachment> flowControlDetailDrawing) {
        this.flowControlDetailDrawing = flowControlDetailDrawing;
    }

    public List<Attachment> getHeadWallDetailDrawing() {
        return headWallDetailDrawing;
    }

    public void setHeadWallDetailDrawing(List<Attachment> headWallDetailDrawing) {
        this.headWallDetailDrawing = headWallDetailDrawing;
    }

    public List<Attachment> getApprovalForTheDischargeToWaterCourse() {
        return approvalForTheDischargeToWaterCourse;
    }

    public void setApprovalForTheDischargeToWaterCourse(List<Attachment> approvalForTheDischargeToWaterCourse) {
        this.approvalForTheDischargeToWaterCourse = approvalForTheDischargeToWaterCourse;
    }

    public List<Attachment> getConsentForConstructionOfHeadWallStructure() {
        return consentForConstructionOfHeadWallStructure;
    }

    public void setConsentForConstructionOfHeadWallStructure(List<Attachment> consentForConstructionOfHeadWallStructure) {
        this.consentForConstructionOfHeadWallStructure = consentForConstructionOfHeadWallStructure;
    }

    public List<Attachment> getSudsDrawing() {
        return sudsDrawing;
    }

    public void setSudsDrawing(List<Attachment> sudsDrawing) {
        this.sudsDrawing = sudsDrawing;
    }

    public List<Attachment> getLayoutPlanOfCompound() {
        return layoutPlanOfCompound;
    }

    public void setLayoutPlanOfCompound(List<Attachment> layoutPlanOfCompound) {
        this.layoutPlanOfCompound = layoutPlanOfCompound;
    }

    public List<Attachment> getSectionsAndDetailsOfWetWellChambers() {
        return sectionsAndDetailsOfWetWellChambers;
    }

    public void setSectionsAndDetailsOfWetWellChambers(List<Attachment> sectionsAndDetailsOfWetWellChambers) {
        this.sectionsAndDetailsOfWetWellChambers = sectionsAndDetailsOfWetWellChambers;
    }

    public List<Attachment> getLongitudinalSectionsRisingMain() {
        return longitudinalSectionsRisingMain;
    }

    public void setLongitudinalSectionsRisingMain(List<Attachment> longitudinalSectionsRisingMain) {
        this.longitudinalSectionsRisingMain = longitudinalSectionsRisingMain;
    }

    public List<Attachment> getHydraulicCalculation() {
        return hydraulicCalculation;
    }

    public void setHydraulicCalculation(List<Attachment> hydraulicCalculation) {
        this.hydraulicCalculation = hydraulicCalculation;
    }

    public boolean isHasProtectivePipework() {
        return hasProtectivePipework;
    }

	public List<Attachment> getGeneralArrangementDrawing() {
		return generalArrangementDrawing;
	}

	public void setGeneralArrangementDrawing(List<Attachment> generalArrangementDrawing) {
		this.generalArrangementDrawing = generalArrangementDrawing;
	}

	public List<Attachment> getDetailsOfDepthConstruction() {
		return detailsOfDepthConstruction;
	}

	public void setDetailsOfDepthConstruction(List<Attachment> detailsOfDepthConstruction) {
		this.detailsOfDepthConstruction = detailsOfDepthConstruction;
	}

	public List<Attachment> getSubSurfaceStudy() {
		return subSurfaceStudy;
	}

	public void setSubSurfaceStudy(List<Attachment> subSurfaceStudy) {
		this.subSurfaceStudy = subSurfaceStudy;
	}

	public List<Attachment> getChainageSectionalDrawings() {
		return chainageOfSectionalDrawings;
	}

	public void setChainageOfSectionalDrawings(List<Attachment> chainageOfSectionalDrawings) {
		this.chainageOfSectionalDrawings = chainageOfSectionalDrawings;
	}

	public List<Attachment> getTopographicalLevelsDrawing() {
		return topographicalLevelsDrawing;
	}

	public void setTopographicalLevelsDrawing(List<Attachment> topographicalLevelsDrawing) {
		this.topographicalLevelsDrawing = topographicalLevelsDrawing;
	}


    public List<Attachment> getOrdnanceSurveyBenchmark() {
        return ordnanceSurveyBenchmark;
    }

    public void setOrdnanceSurveyBenchmark(List<Attachment> ordnanceSurveyBenchmark) {
        this.ordnanceSurveyBenchmark = ordnanceSurveyBenchmark;
    }

    public List<Attachment> getCumulativeVolumeCalculations() {
        return cumulativeVolumeCalculations;
    }

    public void setCumulativeVolumeCalculations(List<Attachment> cumulativeVolumeCalculations) {
        this.cumulativeVolumeCalculations = cumulativeVolumeCalculations;
    }

    public List<Attachment> getTradeEffluentFlows() {
        return tradeEffluentFlows;
    }

    public void setTradeEffluentFlows(List<Attachment> tradeEffluentFlows) {
        this.tradeEffluentFlows = tradeEffluentFlows;
    }

    public List<Attachment> getPeakSurfaceWaterCalculations() {
        return peakSurfaceWaterCalculations;
    }

    public void setPeakSurfaceWaterCalculations(List<Attachment> peakSurfaceWaterCalculations) {
        this.peakSurfaceWaterCalculations = peakSurfaceWaterCalculations;
    }

    public List<Attachment> getSurfaceWaterDischargeCalculations() {
        return surfaceWaterDischargeCalculations;
    }

    public void setSurfaceWaterDischargeCalculations(List<Attachment> surfaceWaterDischargeCalculations) {
        this.surfaceWaterDischargeCalculations = surfaceWaterDischargeCalculations;
    }

    public List<Attachment> getSoilInvestigationReport() {
        return soilInvestigationReport;
    }

    public void setSoilInvestigationReport(List<Attachment> soilInvestigationReport) {
        this.soilInvestigationReport = soilInvestigationReport;
    }

    public List<Attachment> getPipeSchedule() {
        return pipeSchedule;
    }

    public void setPipeSchedule(List<Attachment> pipeSchedule) {
        this.pipeSchedule = pipeSchedule;
    }

    public List<Attachment> getMicrodrainageHydraulicModels() {
        return microdrainageHydraulicModels;
    }

    public void setMicrodrainageHydraulicModels(List<Attachment> microdrainageHydraulicModels) {
        this.microdrainageHydraulicModels = microdrainageHydraulicModels;
    }
}
