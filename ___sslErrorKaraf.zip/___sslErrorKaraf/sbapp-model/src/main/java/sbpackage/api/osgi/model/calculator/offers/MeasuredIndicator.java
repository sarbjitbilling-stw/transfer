package sbpackage.api.osgi.model.calculator.offers;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * This is now representing the payment plan journey.
 * viz: Measured Journey, Unmeasured Journey, Assessed Journey, Arrears Payment Plan Journey.
 */
public enum MeasuredIndicator {

    MEASURED("M", "Measured"), //Measured Journey : Target returns "M" for Measured, PaymentPlan DB has "Measured"
    UNMEASURED("U", "Unmeasured"), //Unmeasured Journey: Target returns "U" for Unmeasured, PaymentPlan DB has "Unmeasured"
    ASSESSED("A", "Assessed"), //Assessed Journey: This is not a measured Indicator. (Target do not have a Assessed Indicator)
    ARREARS("ARREARS", "Arrears"); //Arrears Plan Journey: Note: This is not a measured Indicator.

    private static final Map<String, MeasuredIndicator> targetCodeIndex = buildTargetCodeIndex();

    private static final Map<String, MeasuredIndicator> buildTargetCodeIndex() {
        Map<String, MeasuredIndicator> index = new HashMap<>();
        for (MeasuredIndicator measureIndicator : MeasuredIndicator.values()) {
            index.put(measureIndicator.getTargetCode().toUpperCase(), measureIndicator);
        }
        return Collections.unmodifiableMap(index);
    }

    private final String targetCode;
    private final String dbValue;

    MeasuredIndicator(String targetCode, String dbValue) {
        this.targetCode = targetCode;
        this.dbValue = dbValue;
    }

    public String getDbValue() {
        return this.dbValue;
    }

    public String getTargetCode() {
        return this.targetCode;
    }

    public static Optional<MeasuredIndicator> fromTargetCode(String targetCode) {
        String standardisedTargetCode = targetCode != null ? targetCode.toUpperCase() : targetCode;

        return Optional.ofNullable(targetCodeIndex.get(standardisedTargetCode));
    }
}
