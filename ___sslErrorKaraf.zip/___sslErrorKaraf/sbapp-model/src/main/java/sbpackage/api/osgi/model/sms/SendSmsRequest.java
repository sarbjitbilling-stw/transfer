package sbpackage.api.osgi.model.sms;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import sbpackage.api.osgi.model.WSSSite;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

public class SendSmsRequest {
    static final String SITE_OR_ACCOUNT_DETAILS_ERROR = "Either site or both accountNumber and legalEntityId fields are required";
    static final String TEMPLATE_CONTENT_OR_REFERENCE_ERROR = "Either templateContent or both templateGroup and reference fields are required";

    private TargetAccountNumber accountNumber;
    private String legalEntityId;
    // account number is used to work out which site to use but it is not always
    // known so give option to specify site directly
    private WSSSite site;
    private String recipientNumber;

    /**
     * {@link SmsContent} object containing template used to build the SMS content.
     * This parameter is optional (and normally used for testing purposes) if not
     * specified will use the reference to obtain template.
     */
    private SmsContent templateContent;

    /**
     * Group that the template belongs to (e.g. cmp).
     */
    private SmsTemplateGroup templateGroup;

    /**
     * Reference of that template that will be used to build the SMS content.
     */
    private String reference;

    /**
     * Used by SMS templates for more advanced formatting, such as conditionals and
     * loops.
     */
    private Map<String, Object> dynamicFieldData;

    // used by Jackson to validate the JSON
    @JsonCreator
    public SendSmsRequest(@JsonProperty(value = "accountNumber") TargetAccountNumber accountNumber,
            @JsonProperty(value = "legalEntityId") String legalEntityId, @JsonProperty(value = "site") WSSSite site,
            @JsonProperty(value = "recipientNumber", required = true) String recipientNumber,
            @JsonProperty(value = "templateContent") SmsContent templateContent,
            @JsonProperty(value = "templateGroup") SmsTemplateGroup templateGroup,
            @JsonProperty(value = "reference") String reference,
            @JsonProperty(value = "dynamicFieldData", required = true) Map<String, Object> dynamicFieldData) {
        if (site == null && (accountNumber == null || StringUtils.isBlank(legalEntityId))) {
            throw new IllegalArgumentException(SITE_OR_ACCOUNT_DETAILS_ERROR);
        }
        this.accountNumber = accountNumber;
        this.legalEntityId = legalEntityId;
        this.site = site;

        if (StringUtils.isBlank(recipientNumber)) {
            throw new IllegalArgumentException("recipientNumber field is blank");
        }
        this.recipientNumber = recipientNumber;

        validateTemplateParameters(templateContent, templateGroup, reference);
        this.templateContent = templateContent;
        this.templateGroup = templateGroup;
        this.reference = reference;

        if (dynamicFieldData == null) {
            throw new IllegalArgumentException("dynamicFieldData field is null");
        }
        this.dynamicFieldData = dynamicFieldData;
    }

    private void validateTemplateParameters(SmsContent templateContent, SmsTemplateGroup templateGroup,
            String reference) {
        if (templateContent == null && (templateGroup == null || StringUtils.isBlank(reference))) {
            throw new IllegalArgumentException(TEMPLATE_CONTENT_OR_REFERENCE_ERROR);
        }

        if (templateContent != null) {
            // if a client supplies a templateContent then it should have a body but all
            // other fields should not be specified (e.g. reference)
            if (StringUtils.isBlank(templateContent.getBody())) {
                throw new IllegalArgumentException("templateContent body is blank");
            }
            if (templateContent.getTemplateGroup() != null) {
                throw new IllegalArgumentException("templateContent.templateGroup is not null");
            }
            if (templateContent.getReference() != null) {
                throw new IllegalArgumentException("templateContent.reference is not null");
            }
        }
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntityId() {
        return legalEntityId;
    }

    public void setLegalEntityId(String legalEntityId) {
        this.legalEntityId = legalEntityId;
    }

    public WSSSite getSite() {
        return site;
    }

    public void setSite(WSSSite site) {
        this.site = site;
    }

    public String getRecipientNumber() {
        return recipientNumber;
    }

    public void setRecipientNumber(String recipientNumber) {
        this.recipientNumber = recipientNumber;
    }

    public SmsContent getTemplateContent() {
        return templateContent;
    }

    public void setTemplateContent(SmsContent templateContent) {
        this.templateContent = templateContent;
    }

    public SmsTemplateGroup getTemplateGroup() {
        return templateGroup;
    }

    public void setTemplateGroup(SmsTemplateGroup templateGroup) {
        this.templateGroup = templateGroup;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Map<String, Object> getDynamicFieldData() {
        return dynamicFieldData;
    }

    public void setDynamicFieldData(Map<String, Object> dynamicFieldData) {
        this.dynamicFieldData = dynamicFieldData;
    }

}