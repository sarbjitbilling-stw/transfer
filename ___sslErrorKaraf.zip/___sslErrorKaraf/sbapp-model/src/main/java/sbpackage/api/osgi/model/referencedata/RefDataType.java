package sbpackage.api.osgi.model.referencedata;

/**
 * RefDataType encapsulates the ref data value sets from Target. <br/>
 * <br/>
 * Created by rtai on 20/06/2017.
 */
public enum RefDataType {

    ACCOUNT_ROLE("10001"), TITLE("134"), TELEPHONE_LOCATION("9"),

    BUDGET_PLAN_TYPE("176"),

    AUTO_PAY_ARRANGEMENT_TYPE("240"), AUTO_PAY_ARRANGEMENT_STATUS("87"), CANCEL_REASON("99996"), ACCOUNT_EVENT_TYPE(
            "135"),

    CARE_OF("4"),

    CONTACT_INITIATED_BY("15"), CONTACT_METHOD("16"), CONTACT_TYPE("251"), CONTACT_ROOT_CAUSE_TYPE(
            "379"), CONTACT_RESOLUTION("252"), CONTACT_NOTES_TYPE("400"),

    CUSTOMER_ACCOUNT_STATUS("63"),

    FACILITY_CODE("36"),

    ACT_QUEUE_SOURCE_CODE("138"), ACT_PRIORITY("140"),

    TRANSACTION_TYPE("135"), BILL_TYPE("167"),

    SIC_CODE("10005"), MEASURED_INDICATOR("20001"), STATUS("20002"),

    BANK_ACCOUNT_STATUS("801"), EMPLOYMENT_STATUS("802"),

    TERMINATION_REASON("999"),

    REFUND_REASON("81"),

    SERVICE_CENTRE("385"),

    SCHEDULED_FREQUENCY_CODE("10007"), HOME_OWNERSHIP_STATUS("803"), THIRD_PARTY_STATUS("88"), PREFERRED_CONTACT_TIME(
            "99999"),

    METER_READ_TYPE("98");

    private String value;

    RefDataType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public static RefDataType fromValue(String value) {
        for (RefDataType refDataType : values()) {
            if (refDataType.value.equalsIgnoreCase(value)) {
                return refDataType;
            }
        }
        throw new IllegalArgumentException(String.format("No RefDataType found for %s", value));
    }

    @Override
    public String toString() {
        return fromValue(value).name();
    }
}
