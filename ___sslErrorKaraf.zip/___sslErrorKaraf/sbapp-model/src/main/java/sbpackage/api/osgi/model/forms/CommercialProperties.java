package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CommercialProperties {
    private List<CommercialPropertiesConnection> connections;

    public List<CommercialPropertiesConnection> getConnections() {
        return connections;
    }

    public void setConnections(List<CommercialPropertiesConnection> connections) {
        this.connections = connections;
    }
}
