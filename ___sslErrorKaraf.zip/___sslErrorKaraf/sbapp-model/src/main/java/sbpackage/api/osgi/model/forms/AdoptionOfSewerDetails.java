package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AdoptionOfSewerDetails {

    private PlanningConsent planningConsent;
    private Assets assetsToBeAdopted;
    private Selection sustainableUrbanDrainageSystem;
    private TotalLengthOfFoulSewers totalLengthOfFoulSewers;
    private TotalLengthOfSurfaceWaterSewers totalLengthOfSurfaceWaterSewers;
    private PropertiesOnTheSite propertiesOnTheSite;
    private Details principalContractorDetails;
    private String currentStep;

    public PlanningConsent getPlanningConsent() {
        return planningConsent;
    }

    public void setPlanningConsent(PlanningConsent planningConsent) {
        this.planningConsent = planningConsent;
    }

    public Assets getAssetsToBeAdopted() {
        return assetsToBeAdopted;
    }

    public void setAssetsToBeAdopted(Assets assetsToBeAdopted) {
        this.assetsToBeAdopted = assetsToBeAdopted;
    }

    public Selection getSustainableUrbanDrainageSystem() {
        return sustainableUrbanDrainageSystem;
    }

    public void setSustainableUrbanDrainageSystem(Selection sustainableUrbanDrainageSystem) {
        this.sustainableUrbanDrainageSystem = sustainableUrbanDrainageSystem;
    }

    public TotalLengthOfFoulSewers getTotalLengthOfFoulSewers() {
        return totalLengthOfFoulSewers;
    }

    public void setTotalLengthOfFoulSewers(TotalLengthOfFoulSewers totalLengthOfFoulSewers) {
        this.totalLengthOfFoulSewers = totalLengthOfFoulSewers;
    }

    public TotalLengthOfSurfaceWaterSewers getTotalLengthOfSurfaceWaterSewers() {
        return totalLengthOfSurfaceWaterSewers;
    }

    public void setTotalLengthOfSurfaceWaterSewers(TotalLengthOfSurfaceWaterSewers totalLengthOfSurfaceWaterSewers) {
        this.totalLengthOfSurfaceWaterSewers = totalLengthOfSurfaceWaterSewers;
    }

    public PropertiesOnTheSite getPropertiesOnTheSite() {
        return propertiesOnTheSite;
    }

    public void setPropertiesOnTheSite(PropertiesOnTheSite propertiesOnTheSite) {
        this.propertiesOnTheSite = propertiesOnTheSite;
    }

    public Details getPrincipalContractorDetails() {
        return principalContractorDetails;
    }

    public void setPrincipalContractorDetails(Details principalContractorDetails) {
        this.principalContractorDetails = principalContractorDetails;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }
}
