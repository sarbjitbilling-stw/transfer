package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateTimeAdapter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Budget implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@XmlElement
	List<Invoice> invoices;

    @XmlElement
    Invoice latestInvoice;

	@XmlElement
	BasePeriodCalculation basePeriodCalculation;

	@XmlElement
	BudgetCalculation budgetCalculation;

	@XmlElement
	private String id;



	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateTimeAdapter.class)
	private LocalDateTime createdTime;

	@XmlElement
	private String combinedNum;

	@XmlElement
	private long invoiceNum;

	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate billPeriodStartDate;

	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate billPeriodEndDate;

	@XmlElement
	private BigDecimal subPeriodChargeAmount = BigDecimal.ZERO;

	@XmlElement
	private BigDecimal numOfDaysAccrued = BigDecimal.ZERO;

	@XmlElement
	private BigDecimal upliftedAccruedPercent = BigDecimal.ZERO;

    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    public BasePeriodCalculation getBasePeriodCalculation() {
        return basePeriodCalculation;
    }

    public void setBasePeriodCalculation(BasePeriodCalculation basePeriodCalculation) {
        this.basePeriodCalculation = basePeriodCalculation;
    }

    public BudgetCalculation getBudgetCalculation() {
        return budgetCalculation;
    }

    public void setBudgetCalculation(BudgetCalculation budgetCalculation) {
        this.budgetCalculation = budgetCalculation;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDateTime getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(LocalDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public String getCombinedNum() {
        return combinedNum;
    }

    public void setCombinedNum(String combinedNum) {
        this.combinedNum = combinedNum;
    }

    public long getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(long invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public LocalDate getBillPeriodStartDate() {
        return billPeriodStartDate;
    }

    public void setBillPeriodStartDate(LocalDate billPeriodStartDate) {
        this.billPeriodStartDate = billPeriodStartDate;
    }

    public LocalDate getBillPeriodEndDate() {
        return billPeriodEndDate;
    }

    public void setBillPeriodEndDate(LocalDate billPeriodEndDate) {
        this.billPeriodEndDate = billPeriodEndDate;
    }

    public BigDecimal getSubPeriodChargeAmount() {
        return subPeriodChargeAmount;
    }

    public void setSubPeriodChargeAmount(BigDecimal subPeriodChargeAmount) {
        this.subPeriodChargeAmount = subPeriodChargeAmount;
    }

    public BigDecimal getNumOfDaysAccrued() {
        return numOfDaysAccrued;
    }

    public void setNumOfDaysAccrued(BigDecimal numOfDaysAccrued) {
        this.numOfDaysAccrued = numOfDaysAccrued;
    }

    public BigDecimal getUpliftedAccruedPercent() {
        return upliftedAccruedPercent;
    }

    public void setUpliftedAccruedPercent(BigDecimal upliftedAccruedPercent) {
        this.upliftedAccruedPercent = upliftedAccruedPercent;
    }

    public Invoice getLatestInvoice() {
        return latestInvoice;
    }

    public void setLatestInvoice(Invoice latestInvoice) {
        this.latestInvoice = latestInvoice;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("invoices", invoices)
                .append("latestInvoice", latestInvoice)
                .append("basePeriodCalculation", basePeriodCalculation)
                .append("budgetCalculation", budgetCalculation)
                .append("id", id)
                .append("createdTime", createdTime)
                .append("combinedNum", combinedNum)
                .append("invoiceNum", invoiceNum)
                .append("billPeriodStartDate", billPeriodStartDate)
                .append("billPeriodEndDate", billPeriodEndDate)
                .append("subPeriodChargeAmount", subPeriodChargeAmount)
                .append("numOfDaysAccrued", numOfDaysAccrued)
                .append("upliftedAccruedPercent", upliftedAccruedPercent)
                .toString();
    }
}
