package sbpackage.api.osgi.model.calculator.offers;

public enum AccountEventType {
	ACRAP,	//Apply Deposit Accrual
	ACRRF,	//Refund Deposit Accrual
	ADJST,	//Adjustments
	BBFWD,	//Conversion Balance Bfwd
	BILLI,	//Tariff Charges
	CANCL,	//Cancelled Tariff Charges
	CAPAP,	///Apply Capital Credit
	CNOTE,	//Sales Order Credit
	DEPAP,	//Apply Deposit to Account
	DEPOS,	//Deposit
	DEPRF,	//Refund Deposit
	INTAP,	//Apply Deposit Interest
	INTRF,	//Refund Deposit Interest
	MEMAP,	//Apply Membership Fee
	MEMRF,	//Refund Membership Fee
	NTRST,	//Payplan Interest
	PAYIN,	//Payment Transfer In
	PAYOT,	//Payment Transfer Out
	REBIL,	//Re-Billed Tariff Charges
	SALES,	//Sales Order
	SBFWD,	//Summons Balance Bfwd
	TRNIN,	//Transfer In
	TRNOT	//Transfer Out

}
