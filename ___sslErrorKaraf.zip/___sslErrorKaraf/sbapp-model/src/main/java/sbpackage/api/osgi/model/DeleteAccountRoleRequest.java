
package sbpackage.api.osgi.model;

		import javax.xml.bind.annotation.XmlAccessType;
		import javax.xml.bind.annotation.XmlAccessorType;
		import javax.xml.bind.annotation.XmlElement;
		import javax.xml.bind.annotation.XmlRootElement;
		import javax.xml.bind.annotation.XmlType;
		import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
	    import com.fasterxml.jackson.annotation.JsonInclude;
        import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deleteAccountRole", propOrder
		= {"leRemoveUser","accountNumber","custAccountRoleNum","leNum" })

@XmlRootElement(name = "deleteAccountRole")
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeleteAccountRoleRequest {


    @JsonProperty("leRemoveUser")
	@XmlElement(name = "leRemoveUser")
	private String leRemoveUser;

	@JsonProperty("accountNumber")
	@XmlElement(name = "accountNumber")
	private TargetAccountNumber accountNumber;

	@JsonProperty("customerAccountRoleNumber")
	@XmlElement(name = "customerAccountRoleNumber")
	private String custAccountRoleNum;

	@JsonProperty("leNum")
	@XmlElement(name = "leNum")
	private String leNum;


	public String getLeRemoveUser() {
		return leRemoveUser;
	}

	public void setLeRemoveUser(String leRemoveUser) {
		this.leRemoveUser = leRemoveUser;
	}

	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustAccountRoleNum() {
		return custAccountRoleNum;
	}

	public void setCustAccountRoleNum(String custAccountRoleNum) {
		this.custAccountRoleNum = custAccountRoleNum;
	}

	public String getLeNum() {
		return leNum;
	}

	public void setLeNum(String leNum) {
		this.leNum = leNum;
	}

	@Override
	public String toString() {
		return "DeleteAccountRoleRequest{" +
				"leRemoveUser='" + leRemoveUser + '\'' +
				", accountNumber='" + accountNumber + '\'' +
				", custAccountRoleNum='" + custAccountRoleNum + '\'' +
				", leNum ='" + leNum + '\'' +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		DeleteAccountRoleRequest that = (DeleteAccountRoleRequest) o;

		if (leRemoveUser != null ? !leRemoveUser.equals(that.leRemoveUser) : that.leRemoveUser != null) return false;
		if (accountNumber != null ? !accountNumber.equals(that.accountNumber) : that.accountNumber != null)
			return false;
		if (custAccountRoleNum != null ? !custAccountRoleNum.equals(that.custAccountRoleNum) : that.custAccountRoleNum != null)
			return false;
		return leNum != null ? leNum.equals(that.leNum) : that.leNum == null;
	}

	@Override
	public int hashCode() {
		int result = leRemoveUser != null ? leRemoveUser.hashCode() : 0;
		result = 31 * result + (accountNumber != null ? accountNumber.hashCode() : 0);
		result = 31 * result + (custAccountRoleNum != null ? custAccountRoleNum.hashCode() : 0);
		result = 31 * result + (leNum != null ? leNum.hashCode() : 0);
		return result;
	}
}
