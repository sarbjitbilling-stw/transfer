package sbpackage.api.osgi.model.payment;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlType()
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankAccount {

	private String sortCode;
	private String accountHolder;
	private String branch;
	private String actionCode;
	private Long sequenceNum;
	private Long accountId;
	private Long businessNum;

	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate startDate;
	private String docRefId;
	private Long maxPreAuthAmount;
	private String accountCardName;
	private String bankAccountNum;
	private boolean isAuthReceived;
	private RefData autoPayArrangementType;
	private Long versionNum;
	private String bankName;
	private String bankAddress;
	private String voicePhone;
	private String faxPhone;
	private Long creditCardVersionNum;

	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)

	private LocalDate creditCardExpiryDate;
	private String creditCardNum;
	private String creditCardDes;
	@XmlElement
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate creditCardStartDate;
	private boolean isOnPaymentPlan;
	private boolean isOnDemandDirectDebit;
	private String payPlanType;
	private String budgetPlanType;
	public String getSortCode() {
		return sortCode;
	}

	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public Long getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(Long sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public Long getBusinessNum() {
		return businessNum;
	}

	public void setBusinessNum(Long businessNum) {
		this.businessNum = businessNum;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public String getDocRefId() {
		return docRefId;
	}

	public void setDocRefId(String docRefId) {
		this.docRefId = docRefId;
	}

	public Long getMaxPreAuthAmount() {
		return maxPreAuthAmount;
	}

	public void setMaxPreAuthAmount(Long maxPreAuthAmount) {
		this.maxPreAuthAmount = maxPreAuthAmount;
	}

	public String getAccountCardName() {
		return accountCardName;
	}

	public void setAccountCardName(String accountCardName) {
		this.accountCardName = accountCardName;
	}

	public String getBankAccountNum() {
		return bankAccountNum;
	}

	public void setBankAccountNum(String bankAccountNum) {
		this.bankAccountNum = bankAccountNum;
	}

	public boolean getIsAuthReceived() {
		return isAuthReceived;
	}

	public void setIsAuthReceived(boolean isAuthReceived) {
		this.isAuthReceived = isAuthReceived;
	}

	public RefData getAutoPayArrangementType() {
		return autoPayArrangementType;
	}

	public void setAutoPayArrangementType(RefData autoPayArrangementType) {
		this.autoPayArrangementType = autoPayArrangementType;
	}

	public Long getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(Long versionNum) {
		this.versionNum = versionNum;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getVoicePhone() {
		return voicePhone;
	}

	public void setVoicePhone(String voicePhone) {
		this.voicePhone = voicePhone;
	}

	public String getFaxPhone() {
		return faxPhone;
	}

	public void setFaxPhone(String faxPhone) {
		this.faxPhone = faxPhone;
	}

	public Long getCreditCardVersionNum() {
		return creditCardVersionNum;
	}

	public void setCreditCardVersionNum(Long creditCardVersionNum) {
		this.creditCardVersionNum = creditCardVersionNum;
	}

	public LocalDate getCreditCardExpiryDate() {
		return creditCardExpiryDate;
	}

	public void setCreditCardExpiryDate(LocalDate creditCardExpiryDate) {
		this.creditCardExpiryDate = creditCardExpiryDate;
	}

	public String getCreditCardNum() {
		return creditCardNum;
	}

	public void setCreditCardNum(String creditCardNum) {
		this.creditCardNum = creditCardNum;
	}

	public String getCreditCardDes() {
		return creditCardDes;
	}

	public void setCreditCardDes(String creditCardDes) {
		this.creditCardDes = creditCardDes;
	}

	public LocalDate getCreditCardStartDate() {
		return creditCardStartDate;
	}

	public void setCreditCardStartDate(LocalDate creditCardStartDate) {
		this.creditCardStartDate = creditCardStartDate;
	}

	public boolean getIsOnPaymentPlan() {
		return isOnPaymentPlan;
	}

	public void setIsOnPaymentPlan(boolean isOnPaymentPlan) {
		this.isOnPaymentPlan = isOnPaymentPlan;
	}

	public boolean getIsOnDemandDirectDebit() {
		return isOnDemandDirectDebit;
	}

	public void setIsOnDemandDirectDebit(boolean isOnDemandDirectDebit) {
		this.isOnDemandDirectDebit = isOnDemandDirectDebit;
	}

	public String getPayPlanType() {
		return payPlanType;
	}

	public void setPayPlanType(String payPlanType) {
		this.payPlanType = payPlanType;
	}

	public String getBudgetPlanType() {
		return budgetPlanType;
	}

	public void setBudgetPlanType(String budgetPlanType) {
		this.budgetPlanType = budgetPlanType;
	}

}
