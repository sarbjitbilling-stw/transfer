package sbpackage.api.osgi.model;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountRole {

	private TargetAccountNumber accountNumber;

	private Long legalEntityId;

	private Long accountRoleId;

	private Customer customer;

	private RefData role;

	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate startDate;

	public Long getLegalEntityId() {
		return legalEntityId;
	}

	public void setLegalEntityId(Long legalEntityId) {
		this.legalEntityId = legalEntityId;
	}

	public RefData getRole() {
		return role;
	}

	public void setRole(RefData role) {
		this.role = role;
	}

	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountId) {
		this.accountNumber = accountId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public Long getAccountRoleId() {
		return accountRoleId;
	}

	public void setAccountRoleId(Long accountRoleId) {
		this.accountRoleId = accountRoleId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "AccountRole [accountNumber=" + accountNumber + ", legalEntityId=" + legalEntityId + ", accountRoleId="
				+ accountRoleId + ", customer=" + customer + ", role=" + role + ", startDate=" + startDate + "]";
	}

}
