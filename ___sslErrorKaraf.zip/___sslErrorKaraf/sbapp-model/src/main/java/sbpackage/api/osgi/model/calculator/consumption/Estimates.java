package sbpackage.api.osgi.model.calculator.consumption;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Estimates {
	@XmlElement
    public int numberOfDays;

	@XmlElement
	public List<UsageBand> usageBands = new ArrayList<>();

    public List<UsageBand> getUsageBands() {
        return usageBands;
    }

    public void setUsageBands(List<UsageBand> usageBands) {
        this.usageBands = usageBands;
    }

    public int getNumberOfDays() {
        return numberOfDays;
    }

    public void setNumberOfDays(int numberOfDays) {
        this.numberOfDays = numberOfDays;
    }
    
    public String toString() {
    	StringBuilder strBuilder = new StringBuilder();
    	strBuilder.append("[Number of Days=");
    	strBuilder.append(numberOfDays);
    	strBuilder.append(", ");
    	usageBands.forEach(usage->strBuilder.append(usage));
    	
    	return strBuilder.toString();
    }
}
