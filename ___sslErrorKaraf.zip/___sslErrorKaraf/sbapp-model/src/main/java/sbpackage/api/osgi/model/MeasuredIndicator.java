/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author admzphili1
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeasuredIndicator", propOrder = { "value","code","valueSet" })

@XmlRootElement(name="MeasuredIndicator")
public class MeasuredIndicator {
    
    @XmlElement(name="value")
    private String value =null;
    
    @XmlElement(name="code")
    private String code = null;
    
    @XmlElement(name="valueSet")
    private String valueSet = null;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValueSet() {
        return valueSet;
    }

    public void setValueSet(String valueSet) {
        this.valueSet = valueSet;
    }
    
    
}
