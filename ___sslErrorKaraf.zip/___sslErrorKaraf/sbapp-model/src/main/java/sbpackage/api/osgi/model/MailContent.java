package sbpackage.api.osgi.model;

/**
 * Class used for encapsulating the email content.
 *
 * @author DarieComan
 */
public class MailContent
{
    private String subject;
    private String body;
    private String reference;

    public MailContent(){

    }

    public MailContent(String subject, String body, String reference) {
        this.subject = subject;
        this.body = body;
        this.reference = reference;
    }

    public MailContent(MailContent mailContent){
        this.setReference(mailContent.getReference());
        this.setBody(mailContent.getBody());
        this.setSubject(mailContent.getSubject());
    }

    public String getSubject()
    {
        return this.subject;
    }

    public void setSubject(final String subject)
    {
        this.subject = subject;
    }

    public String getBody()
    {
        return this.body;
    }

    public void setBody(final String body)
    {
        this.body = body;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((body == null) ? 0 : body.hashCode());
        result = prime * result + ((reference == null) ? 0 : reference.hashCode());
        result = prime * result + ((subject == null) ? 0 : subject.hashCode());
        return result;
    }

    // added for SendEmailRequest equals method
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MailContent other = (MailContent) obj;
        if (body == null) {
            if (other.body != null)
                return false;
        } else if (!body.equals(other.body))
            return false;
        if (reference == null) {
            if (other.reference != null)
                return false;
        } else if (!reference.equals(other.reference))
            return false;
        if (subject == null) {
            if (other.subject != null)
                return false;
        } else if (!subject.equals(other.subject))
            return false;
        return true;
    }
}
