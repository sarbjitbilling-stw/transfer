package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SelectionWithFlowRate {

    private float flowRate;
    private String selectedOption;
    private String selectedOptionDisplayValue;

    public float getFlowRate() {
        return flowRate;
    }

    public void setFlowRate(float flowRate) {
        this.flowRate = flowRate;
    }

    public String getSelectedOption() {
        return selectedOption;
    }

    public void setSelectedOption(String selectedOption) {
        this.selectedOption = selectedOption;
    }

    public String getSelectedOptionDisplayValue() {
        return selectedOptionDisplayValue;
    }

    public void setSelectedOptionDisplayValue(String selectedOptionDisplayValue) {
        this.selectedOptionDisplayValue = selectedOptionDisplayValue;
    }
}
