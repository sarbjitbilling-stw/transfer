package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import sbpackage.api.osgi.model.util.ISODateTimeToInstantAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.Instant;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SupplyDetails {

    @XmlJavaTypeAdapter(ISODateTimeToInstantAdapter.class)
    private Instant developmentStartDate;

    @XmlJavaTypeAdapter(ISODateTimeToInstantAdapter.class)
    private Instant firstOccupancyDate;

    public Instant getDevelopmentStartDate() {
        return developmentStartDate;
    }

    public void setDevelopmentStartDate(Instant developmentStartDate) {
        this.developmentStartDate = developmentStartDate;
    }

    public Instant getFirstOccupancyDate() {
        return firstOccupancyDate;
    }

    public void setFirstOccupancyDate(Instant firstOccupancyDate) {
        this.firstOccupancyDate = firstOccupancyDate;
    }
}
