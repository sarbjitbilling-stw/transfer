package sbpackage.api.osgi.model;


import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.email.FileAttachment;

@XmlRootElement(name = "SendEmailRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SendEmailRequest {

    @XmlElement(name = "mailContent")
    private MailContent mailContent;

    @XmlElement(name = "emailReference")
    private String emailReference;

    /**
     * Used in email templates for string replacements. 
     */
    @XmlElement(name = "fieldData")
    private Map<String, String> fieldData;
    
    /**
     * Used by email templates for more advanced formatting, such as conditionals and loops.
     */
    @XmlElement(name = "dynamicFieldData")
    private Map<String, Object> dynamicFieldData;

    /**
     * Used by message QA process to make it easier for CMP UI to reload data.
     */
    @XmlElement(name = "dynamicFieldDataUnformatted")
    private Map<String, Object> dynamicFieldDataUnformatted;

	@XmlElement(name = "fromAddress")
    private String fromAddress;

    @XmlElement(name = "bounceAddress")
    private String bounceAddress;

    @XmlElement(name = "recipientAddress")
    private String recipientAddress;

    @XmlElement(name = "recipientAddressEncrypted")
    private boolean recipientAddressEncrypted;

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "legalEntityId")
    private String legalEntityId;
    
    @XmlElement(name = "extendedFieldData")
    private Map<String, FormField> extendedFieldData;
    
    @XmlElement(name = "persist")
    private boolean persist;

    @XmlElement(name = "attachments")
    private List<FileAttachment> attachments;

    @XmlElement(name = "site")
    private WSSSite site;

    public String getRecipientAddress() {
        return recipientAddress;
    }

    public void setRecipientAddress(String recipientAddress) {
        this.recipientAddress = recipientAddress;
    }
    
    public Map<String, String> getFieldData() {
        return fieldData;
    }

    public void setFieldData(Map<String, String> fieldData) {
        this.fieldData = fieldData;
    }
    
    public Map<String, Object> getDynamicFieldData() {
        return dynamicFieldData;
    }

    public void setDynamicFieldData(Map<String, Object> dynamicFieldData) {
        this.dynamicFieldData = dynamicFieldData;
    }

    public Map<String, Object> getDynamicFieldDataUnformatted() {
        return dynamicFieldDataUnformatted;
    }

    public void setDynamicFieldDataUnformatted(Map<String, Object> dynamicFieldDataUnformatted) {
        this.dynamicFieldDataUnformatted = dynamicFieldDataUnformatted;
    }

    public MailContent getMailContent() {
        return mailContent;
    }

    public void setMailContent(MailContent mailContent) {
        this.mailContent = mailContent;
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }

    public String getBounceAddress() {
        return bounceAddress;
    }

    public void setBounceAddress(String bounceAddress) {
        this.bounceAddress = bounceAddress;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntityId() {
        return legalEntityId;
    }

    public void setLegalEntityId(String legalEntityId) {
        this.legalEntityId = legalEntityId;
    }

    public String getEmailReference() {
        return emailReference;
    }

    public void setEmailReference(String emailReference) {
        this.emailReference = emailReference;
    }

    public Map<String, FormField> getExtendedFieldData() {
        return extendedFieldData;
    }

    public void setExtendedFieldData(Map<String, FormField> extendedFieldData) {
        this.extendedFieldData = extendedFieldData;
    }

    public boolean isPersist() {
        return persist;
    }

    public void setPersist(boolean persist) {
        this.persist = persist;
    }

    public List<FileAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<FileAttachment> attachments) {
        this.attachments = attachments;
    }

    public WSSSite getSite() {
        return site;
    }

    public void setSite(WSSSite site) {
        this.site = site;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("mailContent", mailContent)
                .append("emailReference", emailReference)
                .append("fieldData", fieldData)
                .append("dynamicFieldData", dynamicFieldData)
                .append("fromAddress", fromAddress)
                .append("bounceAddress", bounceAddress)
                .append("recipientAddress", recipientAddress)
                .append("accountNumber", accountNumber)
                .append("legalEntityId", legalEntityId)
                .append("persist", persist)
                .append("attachments", attachments)
                .append("site", site)
                .toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
        result = prime * result + ((attachments == null) ? 0 : attachments.hashCode());
        result = prime * result + ((bounceAddress == null) ? 0 : bounceAddress.hashCode());
        result = prime * result + ((dynamicFieldData == null) ? 0 : dynamicFieldData.hashCode());
        result = prime * result + ((dynamicFieldDataUnformatted == null) ? 0 : dynamicFieldDataUnformatted.hashCode());
        result = prime * result + ((emailReference == null) ? 0 : emailReference.hashCode());
        result = prime * result + ((extendedFieldData == null) ? 0 : extendedFieldData.hashCode());
        result = prime * result + ((fieldData == null) ? 0 : fieldData.hashCode());
        result = prime * result + ((fromAddress == null) ? 0 : fromAddress.hashCode());
        result = prime * result + ((legalEntityId == null) ? 0 : legalEntityId.hashCode());
        result = prime * result + ((mailContent == null) ? 0 : mailContent.hashCode());
        result = prime * result + (persist ? 1231 : 1237);
        result = prime * result + ((recipientAddress == null) ? 0 : recipientAddress.hashCode());
        result = prime * result + ((site == null) ? 0 : site.hashCode());
        return result;
    }

    // added to fix bug where a select from EmailReviewRequest would also result in
    // calling update for each entity on flush (equals method is used by hibernate
    // to check if an entity need updating or not)
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SendEmailRequest other = (SendEmailRequest) obj;
        if (accountNumber == null) {
            if (other.accountNumber != null)
                return false;
        } else if (!accountNumber.equals(other.accountNumber))
            return false;
        if (attachments == null) {
            if (other.attachments != null)
                return false;
        } else if (!attachments.equals(other.attachments))
            return false;
        if (bounceAddress == null) {
            if (other.bounceAddress != null)
                return false;
        } else if (!bounceAddress.equals(other.bounceAddress))
            return false;
        if (dynamicFieldData == null) {
            if (other.dynamicFieldData != null)
                return false;
        } else if (!dynamicFieldData.equals(other.dynamicFieldData))
            return false;
        if (dynamicFieldDataUnformatted == null) {
            if (other.dynamicFieldDataUnformatted != null)
                return false;
        } else if (!dynamicFieldDataUnformatted.equals(other.dynamicFieldDataUnformatted))
            return false;
        if (emailReference == null) {
            if (other.emailReference != null)
                return false;
        } else if (!emailReference.equals(other.emailReference))
            return false;
        if (extendedFieldData == null) {
            if (other.extendedFieldData != null)
                return false;
        } else if (!extendedFieldData.equals(other.extendedFieldData))
            return false;
        if (fieldData == null) {
            if (other.fieldData != null)
                return false;
        } else if (!fieldData.equals(other.fieldData))
            return false;
        if (fromAddress == null) {
            if (other.fromAddress != null)
                return false;
        } else if (!fromAddress.equals(other.fromAddress))
            return false;
        if (legalEntityId == null) {
            if (other.legalEntityId != null)
                return false;
        } else if (!legalEntityId.equals(other.legalEntityId))
            return false;
        if (mailContent == null) {
            if (other.mailContent != null)
                return false;
        } else if (!mailContent.equals(other.mailContent))
            return false;
        if (persist != other.persist)
            return false;
        if (recipientAddress == null) {
            if (other.recipientAddress != null)
                return false;
        } else if (!recipientAddress.equals(other.recipientAddress))
            return false;
        if (site != other.site)
            return false;
        return true;
    }

    public boolean isRecipientAddressEncrypted() {
        return recipientAddressEncrypted;
    }

    public void setRecipientAddressEncrypted(boolean recipientAddressEncrypted) {
        this.recipientAddressEncrypted = recipientAddressEncrypted;
    }
}
