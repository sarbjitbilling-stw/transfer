package sbpackage.api.osgi.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "IncidentsContent")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncidentsContent implements Serializable {

	@JsonProperty("lastModified")
	@XmlElement(name = "lastModified")
	private String lastModified;

	@JsonProperty("title")
	@XmlElement(name = "title")
	private String title;

	@JsonProperty("postcodes")
	@XmlElement(name = "postcodes")
	private String postcodes;

	@JsonProperty("status")
	@XmlElement(name = "status")
	private String status;

	@JsonProperty("icon")
	@XmlElement(name = "icon")
	private String icon;

	@JsonProperty("updateTile")
	@XmlElement(name = "updateTile")
	private String updateTile;

	@JsonProperty("copy")
	@XmlElement(name = "copy")
	private String copy;

	@JsonProperty("pageUrl")
	@XmlElement(name = "pageUrl")
	private String pageUrl;

	public String getLastModified() {
		return lastModified;
	}

	public String getTitle() {
		return title;
	}

	public String getPostcodes() {
		return postcodes;
	}

	public String getStatus() {
		return status;
	}

	public String getIcon() {
		return icon;
	}

	public String getUpdateTile() {
		return updateTile;
	}

	public String getCopy() {
		return copy;
	}

	public String getPageUrl() {
		return pageUrl;
	}

}
