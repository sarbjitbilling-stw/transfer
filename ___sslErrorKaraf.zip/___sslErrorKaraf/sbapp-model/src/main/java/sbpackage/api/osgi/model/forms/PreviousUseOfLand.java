package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PreviousUseOfLand {


    private boolean siteIsGreenfield;
    private String previousUseOfPropertyKey;
    private String siteIsGreenfieldDisplayValue;

    public boolean isSiteIsGreenfield() {
        return siteIsGreenfield;
    }

    public void setSiteIsGreenfield(boolean siteIsGreenfield) {
        this.siteIsGreenfield = siteIsGreenfield;
    }

    public String getPreviousUseOfPropertyKey() {
        return previousUseOfPropertyKey;
    }

    public void setPreviousUseOfPropertyKey(String previousUseOfPropertyKey) {
        this.previousUseOfPropertyKey = previousUseOfPropertyKey;
    }

    public String getSiteIsGreenfieldDisplayValue() {
        return siteIsGreenfieldDisplayValue;
    }

    public void setSiteIsGreenfieldDisplayValue(String siteIsGreenfieldDisplayValue) {
        this.siteIsGreenfieldDisplayValue = siteIsGreenfieldDisplayValue;
    }
}
