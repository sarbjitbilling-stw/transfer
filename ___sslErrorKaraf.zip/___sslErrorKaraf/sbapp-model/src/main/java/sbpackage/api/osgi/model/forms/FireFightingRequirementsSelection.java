package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FireFightingRequirementsSelection extends Selection {

    private List<String> fireFightingRequirements;
    private List<String> fireFightingRequirementsDisplayValue;
    private float hydrantFlowRate;
    private float sprinklerFlowrate;
    private int sprinklerTankCapacity;
    private String sprinklerType;
    private String sprinklerTypeDisplayValue;

    public float getHydrantFlowRate() {
        return hydrantFlowRate;
    }

    public void setHydrantFlowRate(float hydrantFlowRate) {
        this.hydrantFlowRate = hydrantFlowRate;
    }

    public String getSprinklerType() {
        return sprinklerType;
    }

    public void setSprinklerType(String sprinklerType) {
        this.sprinklerType = sprinklerType;
    }

    public String getSprinklerTypeDisplayValue() {
        return sprinklerTypeDisplayValue;
    }

    public void setSprinklerTypeDisplayValue(String sprinklerTypeDisplayValue) {
        this.sprinklerTypeDisplayValue = sprinklerTypeDisplayValue;
    }

    public float getSprinklerFlowrate() {
        return sprinklerFlowrate;
    }

    public void setSprinklerFlowrate(float sprinklerFlowrate) {
        this.sprinklerFlowrate = sprinklerFlowrate;
    }

    public int getSprinklerTankCapacity() {
        return sprinklerTankCapacity;
    }

    public void setSprinklerTankCapacity(int sprinklerTankCapacity) {
        this.sprinklerTankCapacity = sprinklerTankCapacity;
    }

    public List<String> getFireFightingRequirementsDisplayValue() {
        return fireFightingRequirementsDisplayValue;
    }

    public void setFireFightingRequirementsDisplayValue(List<String> fireFightingRequirementsDisplayValue) {
        this.fireFightingRequirementsDisplayValue = fireFightingRequirementsDisplayValue;
    }

    public List<String> getFireFightingRequirements() {
        return fireFightingRequirements;
    }

    public void setFireFightingRequirements(List<String> fireFightingRequirements) {
        this.fireFightingRequirements = fireFightingRequirements;
    }
}
