package sbpackage.api.osgi.model.payment.cardpayment;

import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

/**
 * Created by rtai on 29/03/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardFee {

    private BigDecimal flatRateFee;
    private BigDecimal feePercentage;
    private BigDecimal fee;
    private BigDecimal totalDue;
    private BigDecimal netDue;

    private boolean feeApplied = true;

    public CardFee(BigDecimal netDue, BigDecimal flatRateFee, BigDecimal feePercentage, BigDecimal fee, BigDecimal totalDue) {
        this();
        if(netDue!=null) this.netDue = netDue.setScale(2);
        if(flatRateFee!=null) this.flatRateFee = flatRateFee.setScale(2);
        if(feePercentage!=null) this.feePercentage = feePercentage.setScale(2);
        if(fee!=null) this.fee = fee.setScale(2);
        if(totalDue!=null) this.totalDue = totalDue.setScale(2);
    }

    public CardFee(){
        flatRateFee = new BigDecimal(0);
        feePercentage = new BigDecimal(0);
        fee = new BigDecimal(0);
        totalDue = new BigDecimal(0);
        netDue = new BigDecimal(0);
    }

    public BigDecimal getFlatRateFee() {
        return flatRateFee;
    }

    public BigDecimal getFeePercentage() {
        return feePercentage;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public BigDecimal getTotalDue() {
        return totalDue;
    }

    public BigDecimal getNetDue() {
        return netDue;
    }

    public boolean isFeeApplied() {
        return feeApplied;
    }
}
