package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
public class VehiclesMachineryCrossing extends Selection {

    private String typeOfVehicle;
    private Long maximumWeightInTons;
    
	public String getTypeOfVehicle() {
		return typeOfVehicle;
	}
	public void setTypeOfVehicle(String typeOfVehicle) {
		this.typeOfVehicle = typeOfVehicle;
	}
	public Long getMaximumWeightInTons() {
		return maximumWeightInTons;
	}
	public void setMaximumWeightInTons(Long maximumWeightInTons) {
		this.maximumWeightInTons = maximumWeightInTons;
	}
}
