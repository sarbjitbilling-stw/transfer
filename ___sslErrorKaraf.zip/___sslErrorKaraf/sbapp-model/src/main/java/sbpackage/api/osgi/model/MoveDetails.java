package sbpackage.api.osgi.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlRootElement(name = "MoveDetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class MoveDetails implements Serializable {

    private static final long serialVersionUID = -1925840935093053548L;

    private List<AccountRole> legalEntityList;

    private List<ServiceProvisionTariff> serviceProvisionTariffs;

    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate moveDate;

    private Address correspondenceAddress;

    private boolean canSkipCorrespondenceAddressSave;

    private String correspondenceCombinedAddress;

    private LocalDate correspondenceAddressStartDate;

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate meterReadDate;

    private Integer meterReading;

    private String meterReadingType;

    private boolean payPlanCancelTooLateFlag;

    private boolean payPlanCancelFlag;

    private LocalDate nextBillEndDate;

    private RefData unmeasuredBillType;

    private String primaryAccountBrand;

    private String propertyBrand;

    private List<Object> blockingSpecialConditions;

    public List<AccountRole> getLegalEntityList() {
        return legalEntityList;
    }

    public void setLegalEntityList(List<AccountRole> outgoing) {
        this.legalEntityList = outgoing;
    }

    public LocalDate getMoveDate() {
        return moveDate;
    }

    public void setMoveDate(LocalDate moveDate) {
        this.moveDate = moveDate;
    }

    public Address getCorrespondenceAddress() {
        return correspondenceAddress;
    }

    public void setCorrespondenceAddress(Address correspondenceAddress) {
        this.correspondenceAddress = correspondenceAddress;
    }

    public LocalDate getMeterReadDate() {
        return meterReadDate;
    }

    public void setMeterReadDate(LocalDate meterReadDate) {
        this.meterReadDate = meterReadDate;
    }

    public Integer getMeterReading() {
        return meterReading;
    }

    public void setMeterReading(Integer meterReading) {
        this.meterReading = meterReading;
    }

    public LocalDate getCorrespondenceAddressStartDate() {
        return correspondenceAddressStartDate;
    }

    public void setCorrespondenceAddressStartDate(LocalDate correspondenceAddressStartDate) {
        this.correspondenceAddressStartDate = correspondenceAddressStartDate;
    }

    public boolean isPayPlanCancelFlag() {
        return payPlanCancelFlag;
    }

    public void setPayPlanCancelFlag(boolean payPlanCancelFlag) {
        this.payPlanCancelFlag = payPlanCancelFlag;
    }

    public LocalDate getNextBillEndDate() {
        return nextBillEndDate;
    }

    public void setNextBillEndDate(LocalDate nextBillEndDate) {
        this.nextBillEndDate = nextBillEndDate;
    }

    public RefData getUnmeasuredBillType() {
        return unmeasuredBillType;
    }

    public void setUnmeasuredBillType(RefData unmeasuredBillType) {
        this.unmeasuredBillType = unmeasuredBillType;
    }

    public String getCorrespondenceCombinedAddress() {
        return correspondenceCombinedAddress;
    }

    public void setCorrespondenceCombinedAddress(String correspondenceCombinedAddress) {
        this.correspondenceCombinedAddress = correspondenceCombinedAddress;
    }

    public String getMeterReadingType() {
        return meterReadingType;
    }

    public void setMeterReadingType(String meterReadingType) {
        this.meterReadingType = meterReadingType;
    }

    public boolean isCanSkipCorrespondenceAddressSave() {
        return canSkipCorrespondenceAddressSave;
    }

    public void setCanSkipCorrespondenceAddressSave(final boolean canSkipCorrespondenceAddressSave) {
        this.canSkipCorrespondenceAddressSave = canSkipCorrespondenceAddressSave;
    }

    public boolean getPayPlanCancelTooLateFlag() {
        return payPlanCancelTooLateFlag;
    }

    public void setPayPlanCancelTooLateFlag(final boolean payPlanCancelTooLateFlag) {
        this.payPlanCancelTooLateFlag = payPlanCancelTooLateFlag;
    }

    public String getPrimaryAccountBrand() {
        return primaryAccountBrand;
    }

    public void setPrimaryAccountBrand(final String primaryAccountBrand) {
        this.primaryAccountBrand = primaryAccountBrand;
    }

    public String getPropertyBrand() {
        return propertyBrand;
    }

    public void setPropertyBrand(final String propertyBrand) {
        this.propertyBrand = propertyBrand;
    }

    public List<ServiceProvisionTariff> getServiceProvisionTariffs() {
        return serviceProvisionTariffs;
    }

    public void setServiceProvisionTariffs(final List<ServiceProvisionTariff> serviceProvisionTariffs) {
        this.serviceProvisionTariffs = serviceProvisionTariffs;
    }

    public List<Object> getBlockingSpecialConditions() {
        return blockingSpecialConditions;
    }

    public void setBlockingSpecialConditions(List<Object> blockingSpecialConditions) {
        this.blockingSpecialConditions = blockingSpecialConditions;
    }

    public boolean isBlockedBySpecialCondition() {
        return CollectionUtils.isNotEmpty(blockingSpecialConditions);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("legalEntityList", legalEntityList)
                .append("serviceProvisionTariffs", serviceProvisionTariffs)
                .append("moveDate", moveDate)
                .append("correspondenceAddress", correspondenceAddress)
                .append("canSkipCorrespondenceAddressSave", canSkipCorrespondenceAddressSave)
                .append("correspondenceCombinedAddress", correspondenceCombinedAddress)
                .append("correspondenceAddressStartDate", correspondenceAddressStartDate)
                .append("meterReadDate", meterReadDate)
                .append("meterReading", meterReading)
                .append("meterReadingType", meterReadingType)
                .append("payPlanCancelTooLateFlag", payPlanCancelTooLateFlag)
                .append("payPlanCancelFlag", payPlanCancelFlag)
                .append("nextBillEndDate", nextBillEndDate)
                .append("unmeasuredBillType", unmeasuredBillType)
                .append("primaryAccountBrand", primaryAccountBrand)
                .append("propertyBrand", propertyBrand)
                .toString();
    }
}
