package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "WSSUserDetail")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Interception {

	@XmlElement(name = "accountNumber")
	@JsonProperty("accountNumber")
	private TargetAccountNumber accountNumber;

	@XmlElement(name = "legalEntityId")
	@JsonProperty("legalEntityId")
	private String legalEntityId;

	@XmlElement(name = "interceptType")
	@JsonProperty("interceptType")
	private InterceptType interceptType;

	public Interception() {
	}

	public Interception(InterceptType interceptType) {
		this.interceptType = interceptType;
	}

	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getLegalEntityId() {
		return legalEntityId;
	}

	public void setLegalEntityId(String legalEntityId) {
		this.legalEntityId = legalEntityId;
	}

	public InterceptType getInterceptType() {
		return interceptType;
	}

	public void setInterceptType(InterceptType interceptType) {
		this.interceptType = interceptType;
	}
}
