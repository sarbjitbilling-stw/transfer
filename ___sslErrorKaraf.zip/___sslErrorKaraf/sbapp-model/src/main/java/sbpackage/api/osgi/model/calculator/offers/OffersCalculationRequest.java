package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.ToStringBuilder;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class OffersCalculationRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(required = true)
    private TargetAccountNumber accountNumber;

    @XmlElement
    private BigDecimal upfrontPaymentAmount = BigDecimal.ZERO;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate preferredPaymentDate;

    @XmlElement
    private BigDecimal firstInstallmentAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal forecast = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal planAmount = BigDecimal.ZERO;

    @XmlElement
    private String paymentMethod;

    @XmlElement
    private String paymentFrequency;

    @XmlElement
    private String legalEntityNo;

    @XmlElement
    private int preferredPaymentDay;

    @XmlElement
    private boolean getAllPPCOffers;

    @XmlElement
    private boolean userHasIOCRole;

    @XmlElement
    private String accountBrand;

    @XmlElement
    private boolean isHomeMoveJourney;

    @XmlElement
    private BigDecimal preferredPaymentStandard = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal preferredPaymentFlex = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal preferredPaymentPPC = BigDecimal.ZERO;

    @XmlElement
    private BdsOfferRequestDetails bds;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BigDecimal getUpfrontPaymentAmount() {
        return upfrontPaymentAmount;
    }

    public void setUpfrontPaymentAmount(BigDecimal upfrontPaymentAmount) {
        this.upfrontPaymentAmount = upfrontPaymentAmount;
    }

    public LocalDate getPreferredPaymentDate() {
        return preferredPaymentDate;
    }

    public void setPreferredPaymentDate(LocalDate preferredPaymentDate) {
        this.preferredPaymentDate = preferredPaymentDate;
    }

    public BigDecimal getFirstInstallmentAmount() {
        return firstInstallmentAmount;
    }

    public void setFirstInstallmentAmount(BigDecimal firstInstallmentAmount) {
        this.firstInstallmentAmount = firstInstallmentAmount;
    }

    public BigDecimal getForecast() {
        return forecast;
    }

    public void setForecast(BigDecimal forecast) {
        this.forecast = forecast;
    }

    public BigDecimal getPlanAmount() {
        return planAmount;
    }

    public void setPlanAmount(BigDecimal planAmount) {
        this.planAmount = planAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public String getLegalEntityNo() {
        return legalEntityNo;
    }

    public void setLegalEntityNo(String legalEntityNo) {
        this.legalEntityNo = legalEntityNo;
    }

    public int getPreferredPaymentDay() {
        return preferredPaymentDay;
    }

    public void setPreferredPaymentDay(int preferredPaymentDay) {
        this.preferredPaymentDay = preferredPaymentDay;
    }

    public boolean isGetAllPPCOffers() {
        return getAllPPCOffers;
    }

    public void setGetAllPPCOffers(boolean getAllPPCOffers) {
        this.getAllPPCOffers = getAllPPCOffers;
    }

    public BigDecimal getPreferredPaymentStandard() {
        return preferredPaymentStandard;
    }

    public void setPreferredPaymentStandard(BigDecimal preferredPaymentStandard) {
        this.preferredPaymentStandard = preferredPaymentStandard;
    }

    public BigDecimal getPreferredPaymentFlex() {
        return preferredPaymentFlex;
    }

    public void setPreferredPaymentFlex(BigDecimal preferredPaymentFlex) {
        this.preferredPaymentFlex = preferredPaymentFlex;
    }

    public BigDecimal getPreferredPaymentPPC() {
        return preferredPaymentPPC;
    }

    public void setPreferredPaymentPPC(BigDecimal preferredPaymentPPC) {
        this.preferredPaymentPPC = preferredPaymentPPC;
    }

    public boolean isUserHasIOCRole() {
        return userHasIOCRole;
    }

    public void setUserHasIOCRole(final boolean userHasIOCRole) {
        this.userHasIOCRole = userHasIOCRole;
    }

    public boolean isHomeMoveJourney() {
        return isHomeMoveJourney;
    }

    public void setHomeMoveJourney(final boolean homeMoveJourney) {
        isHomeMoveJourney = homeMoveJourney;
    }

    public String getAccountBrand() {
        return accountBrand;
    }

    public void setAccountBrand(final String accountBrand) {
        this.accountBrand = accountBrand;
    }

    public BdsOfferRequestDetails getBds() {
        return bds;
    }

    public void setBds(BdsOfferRequestDetails bds) {
        this.bds = bds;
    }

    public boolean isBds() {
        return bds != null;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountNumber", accountNumber)
                .append("upfrontPaymentAmount", upfrontPaymentAmount)
                .append("preferredPaymentDate", preferredPaymentDate)
                .append("firstInstallmentAmount", firstInstallmentAmount)
                .append("forecast", forecast)
                .append("planAmount", planAmount)
                .append("paymentMethod", paymentMethod)
                .append("paymentFrequency", paymentFrequency)
                .append("legalEntityNo", legalEntityNo)
                .append("preferredPaymentDay", preferredPaymentDay)
                .append("getAllPPCOffers", getAllPPCOffers)
                .append("userHasIOCRole", userHasIOCRole)
                .append("accountBrand", accountBrand)
                .append("isHomeMoveJourney", isHomeMoveJourney)
                .append("preferredPaymentStandard", preferredPaymentStandard)
                .append("preferredPaymentFlex", preferredPaymentFlex)
                .append("preferredPaymentPPC", preferredPaymentPPC)
                .toString();
    }
}