package sbpackage.api.osgi.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by tellis3 on 22/08/2017.
 */
@XmlRootElement(name = "response")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Deprecated
public class ResponseDto {

    /**
     * The response code.
     */
    @XmlElement
    private String code;

    /**
     * The textual description of the response (default message).
     */
    @XmlElement
    private String description;

    /**
     * The category of the response
     */
    @XmlElement
    private Category category;

    /**
     * Additional details.
     */
    @XmlElement(type = HashMap.class)
    @JsonProperty
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private Map<String,Object> details;

    public ResponseDto() {}

    public ResponseDto(int code, String description) {
        init(Category.STW_SERVICES, String.valueOf(code), description);
    }
    public ResponseDto(String code,String description) {
        init(Category.STW_SERVICES, code, description);
    }

    public ResponseDto(Category category, int code, String description) {
        init(category, String.valueOf(code), description);
    }
    public ResponseDto(Category category, String code, String description) {
        init(category, code, description);
    }

    void init(Category category, String code, String description) {
        this.category = category;
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public Map<String,Object> getDetails() {
        return details;
    }

    public void setDetails(Map<String,Object> details) {
        this.details = details;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ResponseDto that = (ResponseDto) o;

        if (code != null ? !code.equals(that.code) : that.code != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (category != that.category) return false;
        return details != null ? details.equals(that.details) : that.details == null;
    }

    @Override
    public int hashCode() {
        int result = code != null ? code.hashCode() : 0;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (category != null ? category.hashCode() : 0);
        result = 31 * result + (details != null ? details.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResponseDto{");
        sb.append("code='").append(code).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", category=").append(category);
        sb.append(", details=").append(details);
        sb.append('}');
        return sb.toString();
    }

    @XmlEnum
    @XmlType(name = "category")
    public enum Category {
        STW_SERVICES,
        TARGET,
        ACCOUNT_SERVICES,
        AUTH_SERVICES,
        CHOR_SERVICES,
        CUSTOMER_SERVICES,
        ELIGIBILITY_SERVICES,
        EMAIL_SERVICES,
        LOCATION_SERVICES,
        METERING_SERVICES,
        PAYMENT_SERVICES,
        PROPERTY_SERVICES,
        REFERENCE_DATA_SERVICES,
        REGISTRATION_SERVICES,
        SPECIAL_CONDITIONS,
        SYSTEM_POLICY_SERVICES,
        USERDB_PROVIDER,
        BILLCOPY_SERVICES,
        OFFERS_CALCULATOR_SERVICES
    }
}
