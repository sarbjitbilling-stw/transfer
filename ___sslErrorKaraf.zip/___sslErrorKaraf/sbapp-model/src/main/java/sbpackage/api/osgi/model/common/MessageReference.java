package sbpackage.api.osgi.model.common;

import javax.xml.bind.annotation.*;

/**
 * Message references as defined in WTP R2 Content Catalogue.
 * Created by rtai on 30/05/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
public class MessageReference {

    @XmlElement
    private String messageKey;

    @XmlElement
    private String defaultMessage;

    @XmlTransient
    public static final String NONE = "none";

    //no-arg constructor
    private MessageReference() {}

    public MessageReference(String messageKey, String defaultMessage) {
        this.messageKey = messageKey;
        this.defaultMessage = defaultMessage;
    }

    public String getMessageKey() {
        return messageKey;
    }

    public String getDefaultMessage() {
        return defaultMessage;
    }
}
