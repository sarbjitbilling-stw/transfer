package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;
import sbpackage.api.osgi.model.referencedata.RefData;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class InvoiceLine implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement
    private String address;

    @XmlElement
    private String cancelDisputeInd;

    @XmlElement
    private String serviceProvisionCode;

    @XmlElement
    private String serviceProvisionDes;

    @XmlElement
    private String alternateId;

    @XmlElement
    private String tariffCode;

    @XmlElement
    private String unitOfMeasureCode;

    @XmlElement
    private String regSpecDes;

    @XmlElement
    private String measuredFlag;

    @XmlElement
    private String adjustedFlag;


    @XmlElement
    private RefData billEventStatus;


    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billPeriodStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billSubPeriodStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billPeriodEndDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate applicableBillPeriodEndDate;

    //Long
    @XmlElement
    private Long addressCode;

    @XmlElement
    private Long propertyId;

    @XmlElement
    private Long serviceProvisionNum;

    @XmlElement
    private String propertyAndServiceProvisionNum;

    @XmlElement
    private Long levelNum;

    @XmlElement
    private Long combinedNum;

    @XmlElement
    private Long versionNum;

    @XmlElement
    private Long tariffVersion;


    @XmlElement
    private BigDecimal avgDailyConsumAmount;

    @XmlElement
    private BigDecimal subPeriodChargeAmount;

    @XmlElement
    private BigDecimal amountUsage;

    @XmlElement
    private Long invoiceNum;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCancelDisputeInd() {
        return cancelDisputeInd;
    }

    public void setCancelDisputeInd(String cancelDisputeInd) {
        this.cancelDisputeInd = cancelDisputeInd;
    }

    public String getServiceProvisionCode() {
        return serviceProvisionCode;
    }

    public void setServiceProvisionCode(String serviceProvisionCode) {
        this.serviceProvisionCode = serviceProvisionCode;
    }

    public String getServiceProvisionDes() {
        return serviceProvisionDes;
    }

    public void setServiceProvisionDes(String serviceProvisionDes) {
        this.serviceProvisionDes = serviceProvisionDes;
    }

    public String getAlternateId() {
        return alternateId;
    }

    public void setAlternateId(String alternateId) {
        this.alternateId = alternateId;
    }

    public String getTariffCode() {
        return tariffCode;
    }

    public void setTariffCode(String tariffCode) {
        this.tariffCode = tariffCode;
    }

    public String getUnitOfMeasureCode() {
        return unitOfMeasureCode;
    }

    public void setUnitOfMeasureCode(String unitOfMeasureCode) {
        this.unitOfMeasureCode = unitOfMeasureCode;
    }

    public String getRegSpecDes() {
        return regSpecDes;
    }

    public void setRegSpecDes(String regSpecDes) {
        this.regSpecDes = regSpecDes;
    }

    public String getMeasuredFlag() {
        return measuredFlag;
    }

    public void setMeasuredFlag(String measuredFlag) {
        this.measuredFlag = measuredFlag;
    }

    public String getAdjustedFlag() {
        return adjustedFlag;
    }

    public void setAdjustedFlag(String adjustedFlag) {
        this.adjustedFlag = adjustedFlag;
    }

    public RefData getBillEventStatus() {
        return billEventStatus;
    }

    public void setBillEventStatus(RefData billEventStatus) {
        this.billEventStatus = billEventStatus;
    }

    public LocalDate getBillPeriodStartDate() {
        return billPeriodStartDate;
    }

    public void setBillPeriodStartDate(LocalDate billPeriodStartDate) {
        this.billPeriodStartDate = billPeriodStartDate;
    }

    public LocalDate getBillSubPeriodStartDate() {
        return billSubPeriodStartDate;
    }

    public void setBillSubPeriodStartDate(LocalDate billSubPeriodStartDate) {
        this.billSubPeriodStartDate = billSubPeriodStartDate;
    }

    public LocalDate getBillPeriodEndDate() {
        return billPeriodEndDate;
    }

    public void setBillPeriodEndDate(LocalDate billPeriodEndDate) {
        this.billPeriodEndDate = billPeriodEndDate;
    }

    public Long getAddressCode() {
        return addressCode;
    }

    public void setAddressCode(Long addressCode) {
        this.addressCode = addressCode;
    }

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Long propertyId) {
        this.propertyId = propertyId;
    }

    public Long getServiceProvisionNum() {
        return serviceProvisionNum;
    }

    public void setServiceProvisionNum(Long serviceProvisionNum) {
        this.serviceProvisionNum = serviceProvisionNum;
    }

    public Long getLevelNum() {
        return levelNum;
    }

    public void setLevelNum(Long levelNum) {
        this.levelNum = levelNum;
    }

    public Long getCombinedNum() {
        return combinedNum;
    }

    public void setCombinedNum(Long combinedNum) {
        this.combinedNum = combinedNum;
    }

    public Long getVersionNum() {
        return versionNum;
    }

    public void setVersionNum(Long versionNum) {
        this.versionNum = versionNum;
    }

    public Long getTariffVersion() {
        return tariffVersion;
    }

    public void setTariffVersion(Long tariffVersion) {
        this.tariffVersion = tariffVersion;
    }

    public BigDecimal getAvgDailyConsumAmount() {
        return avgDailyConsumAmount;
    }

    public void setAvgDailyConsumAmount(BigDecimal avgDailyConsumAmount) {
        this.avgDailyConsumAmount = avgDailyConsumAmount;
    }

    public BigDecimal getSubPeriodChargeAmount() {
        return subPeriodChargeAmount;
    }

    public void setSubPeriodChargeAmount(BigDecimal subPeriodChargeAmount) {
        this.subPeriodChargeAmount = subPeriodChargeAmount;
    }

    public BigDecimal getAmountUsage() {
        return amountUsage;
    }

    public void setAmountUsage(BigDecimal amountUsage) {
        this.amountUsage = amountUsage;
    }

    public LocalDate getApplicableBillPeriodEndDate() {
        return applicableBillPeriodEndDate;
    }

    public void setApplicableBillPeriodEndDate(LocalDate applicableBillPeriodEndDate) {
        this.applicableBillPeriodEndDate = applicableBillPeriodEndDate;
    }

    public String getPropertyAndServiceProvisionNum() {
        return propertyAndServiceProvisionNum;
    }

    public void setPropertyAndServiceProvisionNum(String propertyAndServiceProvisionNum) {
        this.propertyAndServiceProvisionNum = propertyAndServiceProvisionNum;
    }

    public Long getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(Long invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("address", address)
                .append("cancelDisputeInd", cancelDisputeInd)
                .append("serviceProvisionCode", serviceProvisionCode)
                .append("serviceProvisionDes", serviceProvisionDes)
                .append("alternateId", alternateId)
                .append("tariffCode", tariffCode)
                .append("unitOfMeasureCode", unitOfMeasureCode)
                .append("regSpecDes", regSpecDes)
                .append("measuredFlag", measuredFlag)
                .append("adjustedFlag", adjustedFlag)
                .append("billEventStatus", billEventStatus)
                .append("billPeriodStartDate", billPeriodStartDate)
                .append("billSubPeriodStartDate", billSubPeriodStartDate)
                .append("billPeriodEndDate", billPeriodEndDate)
                .append("applicableBillPeriodEndDate", applicableBillPeriodEndDate)
                .append("addressCode", addressCode)
                .append("propertyId", propertyId)
                .append("serviceProvisionNum", serviceProvisionNum)
                .append("propertyAndServiceProvisionNum", propertyAndServiceProvisionNum)
                .append("levelNum", levelNum)
                .append("combinedNum", combinedNum)
                .append("versionNum", versionNum)
                .append("tariffVersion", tariffVersion)
                .append("avgDailyConsumAmount", avgDailyConsumAmount)
                .append("subPeriodChargeAmount", subPeriodChargeAmount)
                .append("amountUsage", amountUsage)
                .append("invoiceNum", invoiceNum)
                .toString();
    }
}
