package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class WarningDTO {
    @XmlElement
    private String code;

    @XmlElement
    private String description;

    @XmlElement
    private WarningCategory category;

    public WarningDTO() {
    }

    public WarningDTO(final String code, final String description, final WarningCategory category) {
        this.code = code;
        this.description = description;
        this.category = category;
    }

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public WarningCategory getCategory() {
        return category;
    }

    public void setCategory(final WarningCategory category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("code", code)
                .append("description", description)
                .append("category", category)
                .toString();
    }

    @XmlEnum
    @XmlType(name = "category")
    public enum WarningCategory {
        NO_HISTORY,
        LESS_THAN_ONE_YEAR_HISTORY,
        LESS_THAN_MINIMUM_HISTORY,
        NO_ACTIVE_SERVICE_PROVISIONS_FOUND
    }

}
