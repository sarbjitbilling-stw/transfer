package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class NameAddress {

    public static final String BLANK = "-";
    private String name;
    private String companyName;
    private String email;
    private String phone;
    private String address;
    private String addressLineOne;
    private String addressLineTwo;
    private String addressCity;
    private String postcode;
    private boolean addressUnknown;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompanyName() {
        return StringUtils.defaultIfBlank(companyName, BLANK);
    }

    public boolean hasCompanyName() {
        return StringUtils.isNotEmpty(companyName);
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        String compositeAddress = this.address == null ? StringUtils.EMPTY : this.address.trim();
        return StringUtils.defaultIfBlank(compositeAddress.length() != 0 ? compositeAddress : buildAddress(), BLANK);
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddressLineOne() {
        return addressLineOne;
    }

    public void setAddressLineOne(String addressLineOne) {
        this.addressLineOne = addressLineOne;
    }

    public String getAddressLineTwo() {
        return addressLineTwo;
    }

    public void setAddressLineTwo(String addressLineTwo) {
        this.addressLineTwo = addressLineTwo;
    }

    public String getAddressCity() {
        return addressCity;
    }

    public void setAddressCity(String addressCity) {
        this.addressCity = addressCity;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    private String buildAddress() {
        List<String> addressLines = Arrays.asList(
                getAddressLineOne(),
                getAddressLineTwo(),
                StringUtils.upperCase(getPostcode()),
                getAddressCity());

        return addressLines.stream()
                .filter(StringUtils::isNotEmpty)
                .collect(Collectors.joining(", "));
    }

    public boolean isAddressUnknown() {
        return addressUnknown;
    }

    public void setAddressUnknown(boolean addressUnknown) {
        this.addressUnknown = addressUnknown;
    }
}
