package sbpackage.api.osgi.model.metering;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "UsageMetricStatus")
@XmlEnum
public enum UsageMetricStatus {

    @XmlEnumValue("SELF_CERTIFIED")
    SELF_CERTIFIED,
    @XmlEnumValue("COMPANY_ESTIMATED")
    COMPANY_ESTIMATED,
    @XmlEnumValue("CONFIRMED")
    CONFIRMED


}
