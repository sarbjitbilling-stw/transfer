package sbpackage.api.osgi.model.rechor;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.ProcessOutcomeList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement(name = "ReChorDTO")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ReChorDTO implements Serializable {
    private ReChorRequest reChorRequest;
    private ProcessOutcomeList outcome;

    public ReChorRequest getReChorRequest() {
        return reChorRequest;
    }

    public void setReChorRequest(final ReChorRequest reChorRequest) {
        this.reChorRequest = reChorRequest;
    }

    public ProcessOutcomeList getOutcome() {
        return outcome;
    }

    public void setOutcome(final ProcessOutcomeList outcome) {
        this.outcome = outcome;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("reChorRequest", reChorRequest)
                .append("outcome", outcome)
                .toString();
    }
}
