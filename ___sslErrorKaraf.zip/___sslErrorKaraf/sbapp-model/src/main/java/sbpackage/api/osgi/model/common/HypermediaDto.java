package sbpackage.api.osgi.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class HypermediaDto implements Serializable {

    @XmlElement(name = "links")
    private final List<LinkDto> links = new ArrayList();

    @XmlAttribute(name = "href")
    private String href;

    public HypermediaDto() {
    }

    public List<LinkDto> getLinks() {
        return this.links;
    }

    public void addLink(LinkDto link) {
        this.links.add(link);
    }

    public String getHref() {
        return this.href;
    }

    public void setHref(String href) {
        this.href = href;
    }
}
