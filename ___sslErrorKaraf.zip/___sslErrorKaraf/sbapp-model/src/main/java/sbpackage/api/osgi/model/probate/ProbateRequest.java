package sbpackage.api.osgi.model.probate;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.AccountRole;
import sbpackage.api.osgi.model.BillAddress;
import sbpackage.api.osgi.model.Move;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.time.LocalDate;

@XmlRootElement(name = "ProbateRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ProbateRequest implements Serializable {

    @XmlElement
    private TargetAccountNumber accountNumber;

    @XmlElement
    private AccountRole deceasedCustomer;

    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate deceasedDate;

    @XmlElement
    private AccountRole caller;

    @XmlElement
    private RefData callerRole;

    @XmlElement
    private String callerType;

    @XmlElement
    private String executorPhoneNumber;

    @XmlElement
    private String executorCombinedName;

    @XmlElement
    private BillAddress billAddress;

    @XmlElement
    private RefData homeOwnerStatus;

    @XmlElement
    private boolean isCallerLivingAndResponsible;

    @XmlElement
    private boolean isPropertyEmpty;

    @XmlElement
    private Move homeMove;

    public boolean isCallerExecutor() {
        return this.executorCombinedName != null;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public AccountRole getDeceasedCustomer() {
        return deceasedCustomer;
    }

    public void setDeceasedCustomer(AccountRole deceasedCustomer) {
        this.deceasedCustomer = deceasedCustomer;
    }

    public LocalDate getDeceasedDate() {
        return deceasedDate;
    }

    public void setDeceasedDate(LocalDate deceasedDate) {
        this.deceasedDate = deceasedDate;
    }

    public AccountRole getCaller() {
        return caller;
    }

    public void setCaller(AccountRole caller) {
        this.caller = caller;
    }

    public RefData getCallerRole() {
        return callerRole;
    }

    public void setCallerRole(RefData callerRole) {
        this.callerRole = callerRole;
    }

    public String getCallerType() {
        return callerType;
    }

    public void setCallerType(String callerType) {
        this.callerType = callerType;
    }

    public String getExecutorPhoneNumber() {
        return executorPhoneNumber;
    }

    public void setExecutorPhoneNumber(String executorPhoneNumber) {
        this.executorPhoneNumber = executorPhoneNumber;
    }

    public String getExecutorCombinedName() {
        return executorCombinedName;
    }

    public void setExecutorCombinedName(String executorCombinedName) {
        this.executorCombinedName = executorCombinedName;
    }

    public BillAddress getBillAddress() {
        return billAddress;
    }

    public void setBillAddress(BillAddress billAddress) {
        this.billAddress = billAddress;
    }

    public RefData getHomeOwnerStatus() {
        return homeOwnerStatus;
    }

    public void setHomeOwnerStatus(RefData homeOwnerStatus) {
        this.homeOwnerStatus = homeOwnerStatus;
    }

    public boolean isCallerLivingAndResponsible() {
        return isCallerLivingAndResponsible;
    }

    public void setCallerLivingAndResponsible(boolean callerLivingAndResponsible) {
        isCallerLivingAndResponsible = callerLivingAndResponsible;
    }

    public boolean isPropertyEmpty() {
        return isPropertyEmpty;
    }

    public void setPropertyEmpty(boolean propertyEmpty) {
        isPropertyEmpty = propertyEmpty;
    }

    public Move getHomeMove() {
        return homeMove;
    }

    public void setHomeMove(Move homeMove) {
        this.homeMove = homeMove;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountNumber", accountNumber)
                .append("deceasedCustomer", deceasedCustomer)
                .append("deceasedDate", deceasedDate)
                .append("caller", caller)
                .append("callerRole", callerRole)
                .append("callerType", callerType)
                .append("executorPhoneNumber", executorPhoneNumber)
                .append("executorCombinedName", executorCombinedName)
                .append("billAddress", billAddress)
                .append("homeOwnerStatus", homeOwnerStatus)
                .append("isCallerLivingAndResponsible", isCallerLivingAndResponsible)
                .append("isPropertyEmpty", isPropertyEmpty)
                .append("homeMove", homeMove)
                .toString();
    }
}