package sbpackage.api.osgi.model.inmyarea;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.time.OffsetDateTime;

@Data
public class Appointment {

    @JsonProperty(value = "WorkOrderId")
    private String workOrderId;
    @JsonProperty(value = "WorkOrderOperationId")
    private String workOrderOperationId;
    @JsonProperty(value = "Counter")
    private Long counter;
    @JsonProperty(value = "OutsideSla")
    private Boolean outsideSla;
    @JsonProperty(value = "Weekend")
    private Boolean weekend;
    @JsonProperty(value = "AmPm")
    private Boolean amPm;
    @JsonProperty(value = "TwoHours")
    private Boolean twoHours;
    @JsonProperty(value = "EarliestStartDate")
    @JsonDeserialize(using = OffsetDateTimeDeserialiser.class)
    private OffsetDateTime earliestStartDate;
    @JsonProperty(value = "LatestStartDate")
    @JsonDeserialize(using = OffsetDateTimeDeserialiser.class)
    private OffsetDateTime latestStartDate;
}
