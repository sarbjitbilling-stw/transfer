package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SelectionArray {

    private List<String> selectedOption;
    private List<String> selectedOptionDisplayValue;
    private List<String> selectedOptions;
    private List<String> selectedOptionsDisplayValue;
    private List<String> subOptionValues;

    public void setSelectedOption(List<String> selectedOption) {
        this.selectedOption = selectedOption;
    }

    public void setSelectedOptionDisplayValue(List<String> selectedOptionDisplayValue) {
        this.selectedOptionDisplayValue = selectedOptionDisplayValue;
    }

    public List<String> getSubOptionValues() {
        return subOptionValues;
    }

    public void setSubOptionValues(List<String> subOptionValues) {
        this.subOptionValues = subOptionValues;
    }

    public void setSelectedOptions(List<String> selectedOptions) {
        this.selectedOptions = selectedOptions;
    }

    public void setSelectedOptionsDisplayValue(List<String> selectedOptionsDisplayValue) {
        this.selectedOptionsDisplayValue = selectedOptionsDisplayValue;
    }

    public List<String> getOptions() {
        return selectedOption != null ? selectedOption : selectedOptions;
    }

    public List<String> getDisplayOptions() {
        return selectedOptionDisplayValue != null ? selectedOptionDisplayValue : selectedOptionsDisplayValue;
    }
}
