package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FormData {

    private SiteDetails siteDetails;
    private ContactDetails contactDetails;
    private ConnectionDetails waterConnectionDetails;
    private ConnectionDetails wasteConnectionDetails;
    private WasteInstallationDetails wasteInstallationDetails;
    private DeveloperEnquiryWasteDetails developerEnquiryWasteDetails;
    private DeveloperEnquiryAndPocWaterDetails developerEnquiryWaterDetails;
    private DeveloperEnquiryAndPocWaterDetails pointOfConnectionDetails;
    private DeveloperEnquiryCombinedDetails developerEnquiryCombinedDetails;
    private WaterMainRequisitionDetails waterMainRequisitionDetails;
    private AdoptionOfSewerDetails adoptionOfSewerDetails;
    private DiversionOfWasteDetails diversionOfWasteDetails;
    private DiversionOfWaterDetails diversionOfWaterDetails;
    private SewerRequisitionDetails sewerRequisitionDetails;
    private NewAppointmentsAndVariationsDetails newAppointmentsAndVariationsWaterDetails;
    private NewAppointmentsAndVariationsDetails newAppointmentsAndVariationsWasteDetails;
    private UploadDocuments uploadDocuments;
    private TermsAndConditions termsAndConditions;
    private PaymentDetails paymentDetails;
    private String currentStep;

    public SiteDetails getSiteDetails() {
        return siteDetails;
    }

    public void setSiteDetails(SiteDetails siteDetails) {
        this.siteDetails = siteDetails;
    }

    public ContactDetails getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(ContactDetails contactDetails) {
        this.contactDetails = contactDetails;
    }

    public ConnectionDetails getWaterConnectionDetails() {
        return waterConnectionDetails;
    }

    public void setWaterConnectionDetails(ConnectionDetails waterConnectionDetails) {
        this.waterConnectionDetails = waterConnectionDetails;
    }

    public UploadDocuments getUploadDocuments() {
        return uploadDocuments;
    }

    public void setUploadDocuments(UploadDocuments uploadDocuments) {
        this.uploadDocuments = uploadDocuments;
    }

    public WasteInstallationDetails getWasteInstallationDetails() {
        return wasteInstallationDetails;
    }

    public void setWasteInstallationDetails(WasteInstallationDetails wasteInstallationDetails) {
        this.wasteInstallationDetails = wasteInstallationDetails;
    }

    public ConnectionDetails getWasteConnectionDetails() {
        return wasteConnectionDetails;
    }

    public void setWasteConnectionDetails(ConnectionDetails wasteConnectionDetails) {
        this.wasteConnectionDetails = wasteConnectionDetails;
    }

    public DeveloperEnquiryWasteDetails getDeveloperEnquiryWasteDetails() {
        return developerEnquiryWasteDetails;
    }

    public void setDeveloperEnquiryWasteDetails(DeveloperEnquiryWasteDetails developerEnquiryWasteDetails) {
        this.developerEnquiryWasteDetails = developerEnquiryWasteDetails;
    }

    public DeveloperEnquiryCombinedDetails getDeveloperEnquiryCombinedDetails() {
        return developerEnquiryCombinedDetails;
    }

    public void setDeveloperEnquiryCombinedDetails(DeveloperEnquiryCombinedDetails developerEnquiryCombinedDetails) {
        this.developerEnquiryCombinedDetails = developerEnquiryCombinedDetails;
    }

    public WaterMainRequisitionDetails getWaterMainRequisitionDetails() {
        return waterMainRequisitionDetails;
    }

    public void setWaterMainRequisitionDetails(WaterMainRequisitionDetails waterMainRequisitionDetails) {
        this.waterMainRequisitionDetails = waterMainRequisitionDetails;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public DeveloperEnquiryAndPocWaterDetails getDeveloperEnquiryWaterDetails() {
        return developerEnquiryWaterDetails;
    }

    public void setDeveloperEnquiryWaterDetails(DeveloperEnquiryAndPocWaterDetails developerEnquiryWaterDetails) {
        this.developerEnquiryWaterDetails = developerEnquiryWaterDetails;
    }

    public TermsAndConditions getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(TermsAndConditions termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public PaymentDetails getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(PaymentDetails paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

    public DeveloperEnquiryAndPocWaterDetails getPointOfConnectionDetails() {
        return pointOfConnectionDetails;
    }

    public void setPointOfConnectionDetails(DeveloperEnquiryAndPocWaterDetails pointOfConnectionDetails) {
        this.pointOfConnectionDetails = pointOfConnectionDetails;
    }

    public AdoptionOfSewerDetails getAdoptionOfSewerDetails() {
        return adoptionOfSewerDetails;
    }

    public void setAdoptionOfSewerDetails(AdoptionOfSewerDetails adoptionOfSewerDetails) {
        this.adoptionOfSewerDetails = adoptionOfSewerDetails;
    }

    public DiversionOfWasteDetails getDiversionOfWasteDetails() {
        return diversionOfWasteDetails;
    }

    public void setDiversionOfWasteDetails(DiversionOfWasteDetails diversionOfWasteDetails) {
        this.diversionOfWasteDetails = diversionOfWasteDetails;
    }
    
    public DiversionOfWaterDetails getDiversionOfWaterDetails() {
        return diversionOfWaterDetails;
    }

	public void setDiversionOfWaterDetails(DiversionOfWaterDetails diversionOfWaterDetails) {
		this.diversionOfWaterDetails = diversionOfWaterDetails;
	}

    public SewerRequisitionDetails getSewerRequisitionDetails() {
        return sewerRequisitionDetails;
    }

    public void setSewerRequisitionDetails(SewerRequisitionDetails sewerRequisitionDetails) {
        this.sewerRequisitionDetails = sewerRequisitionDetails;
    }

    public NewAppointmentsAndVariationsDetails getNewAppointmentsAndVariationsWaterDetails() {
        return newAppointmentsAndVariationsWaterDetails;
    }

    public void setNewAppointmentsAndVariationsWaterDetails(NewAppointmentsAndVariationsDetails newAppointmentsAndVariationsWaterDetails) {
        this.newAppointmentsAndVariationsWaterDetails = newAppointmentsAndVariationsWaterDetails;
    }

	public NewAppointmentsAndVariationsDetails getNewAppointmentsAndVariationsWasteDetails() {
		return newAppointmentsAndVariationsWasteDetails;
	}

	public void setNewAppointmentsAndVariationsWasteDetails(
			NewAppointmentsAndVariationsDetails newAppointmentsAndVariationsWasteDetails) {
		this.newAppointmentsAndVariationsWasteDetails = newAppointmentsAndVariationsWasteDetails;
	}

    public String getCardEmail() {
        return paymentDetails != null ? paymentDetails.getCardEmail() : null;
    }
}
