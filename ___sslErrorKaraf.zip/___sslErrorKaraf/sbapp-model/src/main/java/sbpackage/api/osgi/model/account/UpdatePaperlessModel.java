package sbpackage.api.osgi.model.account;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;

@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdatePaperlessModel {
	
	private String journey;
	private boolean goPaperless = false;
	
	public String getJourney() {
		return journey;
	}

	public void setJourney(String journey) {
		this.journey = journey;
	}

	public boolean isGoPaperless() {
		return goPaperless;
	}

	public void setGoPaperless(boolean goPaperless) {
		this.goPaperless = goPaperless;
	}

}
