package sbpackage.api.osgi.model.payment.directdebit;

import sbpackage.api.osgi.model.payment.PaymentPlanResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DirectDebitResponse extends PaymentPlanResponse {

}