package sbpackage.api.osgi.model.payment.directdebit;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.calculator.consumption.ConsumptionCalculator;
import sbpackage.api.osgi.model.common.HypermediaDto;

/**
 * Created by rtai on 28/06/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DirectDebit extends HypermediaDto {

    @XmlElement(name = "id")
    private String id;

    @XmlElement(name = "accountInfo")
    private AccountInfo accountInfo;

    @XmlElement(name = "paymentInfo")
    private PaymentInfo paymentInfo;

    @XmlElement(name = "bankDetails")
    private BankDetails bankDetails;

    @XmlElement(name = "signature")
    private String signature;

    @XmlElement(name = "action")
    private Action action;

    @XmlElement(name = "consumptionCalculator")
    private ConsumptionCalculator consumptionCalculator;

    @XmlElement(name = "numberOfDefaultedPlans")
    private Integer numberOfDefaultedPlans;

    @XmlElement(name = "dmCode")
    private String dmCode;

    @XmlElement(name = "isPaymentPlanCancelled")
    private Boolean isPaymentPlanCancelled;

    @XmlElement(name = "paymentPlanPermissions")
    private PaymentPlanPermissions paymentPlanPermissions;

    @XmlElement(name = "userCanCreateDirectDebitPlan")
    private UserCanCreateDirectDebitPlan userCanCreateDirectDebitPlan;

    @XmlElement(name = "conditionalPaymentPlan")
    private ConditionalPaymentPlan conditionalPaymentPlan;

    @XmlElement(name = "userMustPayMinBalance")
    private UserMustPayMinBalance userMustPayMinBalance;

    @XmlElement(name = "accountCondition")
    private AccountCondition accountCondition;

    @XmlElement(name = "specialConditions")
    private SpecialConditions specialConditions;

    @XmlElement(name = "PaymentDetails")
    private PaymentDetails paymentDetails;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public AccountInfo getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

    public PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public BankDetails getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(BankDetails bankDetails) {
        this.bankDetails = bankDetails;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public ConsumptionCalculator getConsumptionCalculator() {
        return consumptionCalculator;
    }

    public void setConsumptionCalculator(ConsumptionCalculator consumptionCalculator) {
        this.consumptionCalculator = consumptionCalculator;
    }

    public Integer getNumberOfDefaultedPlans() {
        return numberOfDefaultedPlans;
    }

    public void setNumberOfDefaultedPlans(Integer numberOfDefaultedPlans) {
        this.numberOfDefaultedPlans = numberOfDefaultedPlans;
    }

    public Boolean getPaymentPlanCancelled() {
        return isPaymentPlanCancelled;
    }

    public void setPaymentPlanCancelled(Boolean paymentPlanCancelled) {
        isPaymentPlanCancelled = paymentPlanCancelled;
    }

    public String getDmCode() {
        return dmCode;
    }

    public void setDmCode(String dmCode) {
        this.dmCode = dmCode;
    }

    public PaymentPlanPermissions getPaymentPlanPermissions() {
        return paymentPlanPermissions;
    }

    public void setPaymentPlanPermissions(PaymentPlanPermissions paymentPlanPermissions) {
        this.paymentPlanPermissions = paymentPlanPermissions;
    }

    public UserCanCreateDirectDebitPlan getUserCanCreateDirectDebitPlan() {
        return userCanCreateDirectDebitPlan;
    }

    public void setUserCanCreateDirectDebitPlan(UserCanCreateDirectDebitPlan userCanCreateDirectDebitPlan) {
        this.userCanCreateDirectDebitPlan = userCanCreateDirectDebitPlan;
    }

    public ConditionalPaymentPlan getConditionalPaymentPlan() {
        return conditionalPaymentPlan;
    }

    public void setConditionalPaymentPlan(ConditionalPaymentPlan conditionalPaymentPlan) {
        this.conditionalPaymentPlan = conditionalPaymentPlan;
    }

    public UserMustPayMinBalance getUserMustPayMinBalance() {
        return userMustPayMinBalance;
    }

    public void setUserMustPayMinBalance(UserMustPayMinBalance userMustPayMinBalance) {
        this.userMustPayMinBalance = userMustPayMinBalance;
    }

    public AccountCondition getAccountCondition() {
        return accountCondition;
    }

    public void setAccountCondition(AccountCondition accountCondition) {
        this.accountCondition = accountCondition;
    }

    public SpecialConditions getSpecialConditions() {
        return specialConditions;
    }

    public void setSpecialConditions(SpecialConditions specialConditions) {
        this.specialConditions = specialConditions;
    }

    public PaymentDetails getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(PaymentDetails paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DirectDebit that = (DirectDebit) o;

        return new EqualsBuilder()
                .append(id, that.id)
                .append(action, that.action)
                .append(accountInfo, that.accountInfo)
                .append(consumptionCalculator, that.consumptionCalculator)
                .append(paymentInfo, that.paymentInfo)
                .append(bankDetails, that.bankDetails)
                .append(signature, that.signature)
                .append (numberOfDefaultedPlans, that.numberOfDefaultedPlans)
                .append (isPaymentPlanCancelled, that.isPaymentPlanCancelled)
                .append (dmCode, that.dmCode)
                .append (paymentPlanPermissions, that.paymentPlanPermissions)
                .append (userCanCreateDirectDebitPlan, that.userCanCreateDirectDebitPlan)
                .append (conditionalPaymentPlan, that.conditionalPaymentPlan)
                .append (userMustPayMinBalance, that.userMustPayMinBalance)
                .append (accountCondition, that.accountCondition)
                .append (specialConditions, that.specialConditions)
                .append (paymentDetails, that.paymentDetails)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(action)
                .append(accountInfo)
                .append(consumptionCalculator)
                .append(paymentInfo)
                .append(bankDetails)
                .append(signature)
                .append (numberOfDefaultedPlans)
                .append (isPaymentPlanCancelled)
                .append (dmCode)
                .append (paymentPlanPermissions)
                .append (userCanCreateDirectDebitPlan)
                .append (conditionalPaymentPlan)
                .append (userMustPayMinBalance)
                .append (accountCondition)
                .append (specialConditions)
                .append (paymentDetails)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("action", action)
                .append("accountInfo", accountInfo)
                .append("consumptionCalculator", consumptionCalculator)
                .append("paymentInfo", paymentInfo)
                .append("bankDetails", bankDetails)
                .append("signature", signature)
                .append ("numberOfDefaultedPlans", numberOfDefaultedPlans)
                .append ("isPaymentPlanCancelled", isPaymentPlanCancelled)
                .append ("dmCode", dmCode)
                .append ("paymentPlanPermissions", paymentPlanPermissions)
                .append ("userCanCreateDirectDebitPlan", userCanCreateDirectDebitPlan)
                .append ("conditionalPaymentPlan", conditionalPaymentPlan)
                .append ("userMustPayMinBalance", userMustPayMinBalance)
                .append ("accountCondition", accountCondition)
                .append ("specialConditions", specialConditions)
                .append ("paymentDetails", paymentDetails)
                .toString();
    }

	public enum Action {
		CREATE, AMEND, CANCEL, UPDATEBD, UPDATEAMOUNT, UPDATEDATE, UPDATEMETHOD;

		public static Action of(String actionCode) {
			for (Action action : Action.values()) {
                if (actionCode.equals(action.toString())) {
					return action;
				}

			}
			return null;
		}
	}
    

    public boolean hasContactDetails() {
		return this.getAccountInfo() != null && this.getAccountInfo().getContactDto() != null;
	}

}
