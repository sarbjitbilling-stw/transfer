package sbpackage.api.osgi.model.payment.directdebit;

import com.fasterxml.jackson.annotation.JsonInclude;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.Address;
import sbpackage.api.osgi.model.common.ContactDto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by rtai on 28/06/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountInfo implements sbpackage.api.osgi.model.payment.common.AccountInfo, Serializable {

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "legalEntityNumber")
    private String legalEntityNumber;

    @XmlElement(name = "address")
    private Address address;

    @XmlElement(name = "oneLineAddress")
    private String oneLineAddress;

    @XmlElement(name = "propertyId")
    private Long propertyId;

    @XmlElement(name = "hasWaterCard")
    private boolean hasWaterCard;

    @XmlElement(name = "replaceWaterCard")
    private boolean replaceWaterCard;

    @XmlElement(name = "paymentOnPlan")
    private boolean paymentOnPlan;

    @XmlElement(name = "paymentOnDemand")
    private boolean paymentOnDemand;

    @XmlElement(name = "accountBalance")
    private BigDecimal accountBalance;

    @XmlElement(name = "minimumAmountDue")
    private BigDecimal minimumAmountDue;

    @XmlElement(name = "promptForPayment")
    private boolean promptForPayment;

    @XmlElement(name = "contact")
    private ContactDto contactDto;
    
    private boolean futureStartPlan;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getOneLineAddress() {
        return oneLineAddress;
    }

    public void setOneLineAddress(String oneLineAddress) {
        this.oneLineAddress = oneLineAddress;
    }

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Long propertyId) {
        this.propertyId = propertyId;
    }

    public boolean isHasWaterCard() {
        return hasWaterCard;
    }

    public void setHasWaterCard(boolean hasWaterCard) {
        this.hasWaterCard = hasWaterCard;
    }

    public boolean isReplaceWaterCard() {
        return replaceWaterCard;
    }

    public void setReplaceWaterCard(boolean replaceWaterCard) {
        this.replaceWaterCard = replaceWaterCard;
    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }

    public String getLegalEntityNumber() {
        return legalEntityNumber;
    }

    public void setLegalEntityNumber(String legalEntityNumber) {
        this.legalEntityNumber = legalEntityNumber;
    }

    public ContactDto getContactDto() {
        return contactDto;
    }

    public void setContactDto(ContactDto contactDto) {
        this.contactDto = contactDto;
    }

    public boolean isPaymentOnPlan() {
        return paymentOnPlan;
    }

    public void setPaymentOnPlan(boolean paymentOnPlan) {
        this.paymentOnPlan = paymentOnPlan;
    }

    public boolean isPaymentOnDemand() {
        return paymentOnDemand;
    }

    public void setPaymentOnDemand(boolean paymentOnDemand) {
        this.paymentOnDemand = paymentOnDemand;
    }

    public BigDecimal getMinimumAmountDue() {
        return minimumAmountDue;
    }

    public void setMinimumAmountDue(BigDecimal minimumAmountDue) {
        this.minimumAmountDue = minimumAmountDue;
    }

    public boolean isPromptForPayment() {
        return promptForPayment;
    }

    public void setPromptForPayment(boolean promptForPayment) {
        this.promptForPayment = promptForPayment;
    }
    
    @Override
    public boolean isFutureStartPlan() {
		return futureStartPlan;
	}
    
 	public void setFutureStartPlan(boolean futureStartPlan) {
		this.futureStartPlan = futureStartPlan;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        AccountInfo that = (AccountInfo) o;

        return new EqualsBuilder()
                .append(hasWaterCard, that.hasWaterCard)
                .append(replaceWaterCard, that.replaceWaterCard)
                .append(paymentOnPlan, that.paymentOnPlan)
                .append(paymentOnDemand, that.paymentOnDemand)
                .append(accountNumber, that.accountNumber)
                .append(legalEntityNumber, that.legalEntityNumber)
                .append(contactDto, that.contactDto)
                .append(accountBalance, that.accountBalance)
                .append(address, that.address)
                .append(oneLineAddress, that.oneLineAddress)
                .append(propertyId, that.propertyId)
                .append(minimumAmountDue, that.minimumAmountDue)
                .append(promptForPayment, that.promptForPayment)
                .append(futureStartPlan, that.futureStartPlan)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(accountNumber)
                .append(legalEntityNumber)
                .append(contactDto)
                .append(accountBalance)
                .append(address)
                .append(oneLineAddress)
                .append(propertyId)
                .append(hasWaterCard)
                .append(replaceWaterCard)
                .append(paymentOnPlan)
                .append(paymentOnDemand)
                .append(minimumAmountDue)
                .append(promptForPayment)
                .append(futureStartPlan)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountNumber", accountNumber)
                .append("legalEntityNumber", legalEntityNumber)
                .append("contact", contactDto)
                .append("accountBalance", accountBalance)
                .append("address", address)
                .append("oneLineAddress", oneLineAddress)
                .append("propertyId", propertyId)
                .append("hasWaterCard", hasWaterCard)
                .append("replaceWaterCard", replaceWaterCard)
                .append("paymentOnPlan", paymentOnPlan)
                .append("paymentOnDemand", paymentOnDemand)
                .append("minimumAmountDue",minimumAmountDue)
                .append("promptForPayment", promptForPayment)
                .append("futureStartPlan", futureStartPlan)
                .toString();
    }
}
