package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class OffersCalculation implements Serializable {

    private static final long serialVersionUID = 1L;

    public OffersCalculation() {
        warnings = new ArrayList<>();
    }

    @XmlElement
    private OffersCalculationRequest offersCalculationRequest;

    @XmlElement
    private TargetAccountNumber accountNumber;

    @XmlElement
    private String measuredIndicator;

    @XmlElement
    private boolean isMeasured;

    @XmlElement
    private boolean isUnmeasured;

    @XmlElement
    private boolean isAssessed;

    @XmlElement
    private boolean isArrearsPlan;

    @XmlElement
    private boolean isMainBillingCompleted;

    @XmlElement
    private Arrears originalArrears;

    @XmlElement
    private Arrears baseArrears;

    @XmlElement
    private BigDecimal averageDailyCost = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal originalForecast = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal baseForecast = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal originalAccrued = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal baseAccrued = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal originalForecastForPPC = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal baseForecastForPPC = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal originalAccruedForPPC = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal baseAccruedForPPC = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal planAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal accountBalance = BigDecimal.ZERO;

    @XmlElement
    private List<Offer> offers;

    @XmlElement
    private List<ServiceProvision> serviceProvisions;

    @XmlElement
    private Budget budget;

    @XmlElement
    private String targetAccountSummary;

    @XmlElement
    private List<WarningDTO> warnings;

    @XmlElement
    private String offersVersion;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate targetDate;

    @XmlElement
    private List<BudgetUplift> budgetUplifts;

    public OffersCalculationRequest getOffersCalculationRequest() {
        return offersCalculationRequest;
    }

    public void setOffersCalculationRequest(OffersCalculationRequest offersCalculationRequest) {
        this.offersCalculationRequest = offersCalculationRequest;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getMeasuredIndicator() {
        return measuredIndicator;
    }

    public void setMeasuredIndicator(String measuredIndicator) {
        this.measuredIndicator = measuredIndicator;
    }

    public boolean isMeasured() {
        return isMeasured;
    }

    public void setMeasured(boolean measured) {
        isMeasured = measured;
    }

    public boolean isUnmeasured() {
        return isUnmeasured;
    }

    public void setUnmeasured(boolean unmeasured) {
        isUnmeasured = unmeasured;
    }

    public boolean isAssessed() {
        return isAssessed;
    }

    public void setAssessed(boolean assessed) {
        isAssessed = assessed;
    }

    public Arrears getOriginalArrears() {
        return originalArrears;
    }

    public void setOriginalArrears(Arrears originalArrears) {
        this.originalArrears = originalArrears;
    }

    public Arrears getBaseArrears() {
        return baseArrears;
    }

    public void setBaseArrears(Arrears baseArrears) {
        this.baseArrears = baseArrears;
    }

    public BigDecimal getAverageDailyCost() {
        return averageDailyCost;
    }

    public void setAverageDailyCost(BigDecimal averageDailyCost) {
        this.averageDailyCost = averageDailyCost;
    }

    public BigDecimal getOriginalForecast() {
        return originalForecast;
    }

    public void setOriginalForecast(BigDecimal originalForecast) {
        this.originalForecast = originalForecast;
    }

    public BigDecimal getBaseForecast() {
        return baseForecast;
    }

    public void setBaseForecast(BigDecimal baseForecast) {
        this.baseForecast = baseForecast;
    }

    public BigDecimal getOriginalAccrued() {
        return originalAccrued;
    }

    public void setOriginalAccrued(BigDecimal originalAccrued) {
        this.originalAccrued = originalAccrued;
    }

    public BigDecimal getBaseAccrued() {
        return baseAccrued;
    }

    public void setBaseAccrued(BigDecimal baseAccrued) {
        this.baseAccrued = baseAccrued;
    }

    public BigDecimal getPlanAmount() {
        return planAmount;
    }

    public void setPlanAmount(BigDecimal planAmount) {
        this.planAmount = planAmount;
    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }

    public List<Offer> getOffers() {
        return offers;
    }

    public void setOffers(List<Offer> offers) {
        this.offers = offers;
    }

    public List<ServiceProvision> getServiceProvisions() {
        return serviceProvisions;
    }

    public void setServiceProvisions(List<ServiceProvision> serviceProvisions) {
        this.serviceProvisions = serviceProvisions;
    }

    public Budget getBudget() {
        return budget;
    }

    public void setBudget(Budget budget) {
        this.budget = budget;
    }

    public String getTargetAccountSummary() {
        return targetAccountSummary;
    }

    public void setTargetAccountSummary(String targetAccountSummary) {
        this.targetAccountSummary = targetAccountSummary;
    }

    public String getOffersVersion() {
        return offersVersion;
    }

    public void setOffersVersion(String offersVersion) {
        this.offersVersion = offersVersion;
    }

    public LocalDate getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(LocalDate targetDate) {
        this.targetDate = targetDate;
    }

    public List<WarningDTO> getWarnings() {
        return warnings;
    }

    public void setWarnings(final List<WarningDTO> warnings) {
        this.warnings = warnings;
    }

    public List<BudgetUplift> getBudgetUplifts() {
        return budgetUplifts;
    }

    public void setBudgetUplifts(final List<BudgetUplift> budgetUplifts) {
        this.budgetUplifts = budgetUplifts;
    }

    public BigDecimal getOriginalForecastForPPC() {
        return originalForecastForPPC;
    }

    public void setOriginalForecastForPPC(final BigDecimal originalForecastForPPC) {
        this.originalForecastForPPC = originalForecastForPPC;
    }

    public BigDecimal getBaseForecastForPPC() {
        return baseForecastForPPC;
    }

    public void setBaseForecastForPPC(final BigDecimal baseForecastForPPC) {
        this.baseForecastForPPC = baseForecastForPPC;
    }

    public BigDecimal getOriginalAccruedForPPC() {
        return originalAccruedForPPC;
    }

    public void setOriginalAccruedForPPC(final BigDecimal originalAccruedForPPC) {
        this.originalAccruedForPPC = originalAccruedForPPC;
    }

    public BigDecimal getBaseAccruedForPPC() {
        return baseAccruedForPPC;
    }

    public void setBaseAccruedForPPC(final BigDecimal baseAccruedForPPC) {
        this.baseAccruedForPPC = baseAccruedForPPC;
    }

    public boolean isArrearsPlan() {
        return isArrearsPlan;
    }

    public void setArrearsPlan(final boolean arrearsPlan) {
        isArrearsPlan = arrearsPlan;
    }

    public boolean isMainBillingCompleted() {
        return isMainBillingCompleted;
    }

    public void setMainBillingCompleted(final boolean mainBillingCompleted) {
        isMainBillingCompleted = mainBillingCompleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("offersCalculationRequest", offersCalculationRequest)
                .append("accountNumber", accountNumber)
                .append("measuredIndicator", measuredIndicator)
                .append("isMeasured", isMeasured)
                .append("isUnmeasured", isUnmeasured)
                .append("isAssessed", isAssessed)
                .append("isArrearsPlan", isArrearsPlan)
                .append("isMainBillingCompleted", isMainBillingCompleted)
                .append("originalArrears", originalArrears)
                .append("baseArrears", baseArrears)
                .append("averageDailyCost", averageDailyCost)
                .append("originalForecast", originalForecast)
                .append("baseForecast", baseForecast)
                .append("originalAccrued", originalAccrued)
                .append("baseAccrued", baseAccrued)
                .append("originalForecastForPPC", originalForecastForPPC)
                .append("baseForecastForPPC", baseForecastForPPC)
                .append("originalAccruedForPPC", originalAccruedForPPC)
                .append("baseAccruedForPPC", baseAccruedForPPC)
                .append("planAmount", planAmount)
                .append("accountBalance", accountBalance)
                .append("offers", offers)
                .append("serviceProvisions", serviceProvisions)
                .append("budget", budget)
                .append("targetAccountSummary", targetAccountSummary)
                .append("warnings", warnings)
                .append("offersVersion", offersVersion)
                .append("targetDate", targetDate)
                .append("budgetUplifts", budgetUplifts)
                .toString();
    }
}