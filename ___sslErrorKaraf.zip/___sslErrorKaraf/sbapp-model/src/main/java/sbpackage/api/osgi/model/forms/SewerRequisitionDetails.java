package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@XmlAccessorType(XmlAccessType.FIELD)
public class SewerRequisitionDetails {

    private PlanningConsent planningConsent;
    private SewerAssets assetsToBeRequested;
    private SewerPremises premisesFoulRequirements;
    private SewerPremises premisesWaterRequirements;
    private String currentStep;

    public PlanningConsent getPlanningConsent() {
        return planningConsent;
    }

    public void setPlanningConsent(PlanningConsent planningConsent) {
        this.planningConsent = planningConsent;
    }

    public SewerAssets getAssetsToBeRequested() {
        return assetsToBeRequested;
    }

    public void setAssetsToBeRequested(SewerAssets assetsToBeRequested) {
        this.assetsToBeRequested = assetsToBeRequested;
    }

    public SewerPremises getPremisesFoulRequirements() {
        return premisesFoulRequirements;
    }

    public void setPremisesFoulRequirements(SewerPremises premisesFoulRequirements) {
        this.premisesFoulRequirements = premisesFoulRequirements;
    }

    public SewerPremises getPremisesWaterRequirements() {
        return premisesWaterRequirements;
    }

    public void setPremisesWaterRequirements(SewerPremises premisesWaterRequirements) {
        this.premisesWaterRequirements = premisesWaterRequirements;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }
}
