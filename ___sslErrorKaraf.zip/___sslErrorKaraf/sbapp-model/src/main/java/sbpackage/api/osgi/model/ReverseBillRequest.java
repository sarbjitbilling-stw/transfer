package sbpackage.api.osgi.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

import sbpackage.api.osgi.model.util.BooleanAdapter;
import sbpackage.api.osgi.model.util.LocalDateTimeAdapter;

@XmlRootElement(name = "ReverseBillRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class ReverseBillRequest {

	private TargetAccountNumber accountId;
	private Long propertyId;
	private ReverseBillReason billCancelReason;
	
	@XmlJavaTypeAdapter(value = LocalDateTimeAdapter.class)
	private LocalDateTime createdTime;
	private Long serviceProvisionNum;
	@XmlJavaTypeAdapter(value = BooleanAdapter.class)
	private Boolean showOnBill = null;
	@XmlJavaTypeAdapter(value = BooleanAdapter.class)
	private Boolean isCancelAllReads = null;
	@XmlJavaTypeAdapter(value = BooleanAdapter.class)
	private Boolean checkMultiSPFlag = null;
	@XmlJavaTypeAdapter(value = BooleanAdapter.class)
	private Boolean printAdjustNoteFlag = null;
	@XmlJavaTypeAdapter(value = BooleanAdapter.class)
	private Boolean rebillFlag = null;
	
	@XmlJavaTypeAdapter(value = LocalDateTimeAdapter.class)
	private LocalDateTime dateOfIssue;
	
	public TargetAccountNumber getAccountId() {
		return accountId;
	}
	public void setAccountId(TargetAccountNumber accountId) {
		this.accountId = accountId;
	}
	public Long getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public LocalDateTime getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}
	public Long getServiceProvisionNum() {
		return serviceProvisionNum;
	}
	public void setServiceProvisionNum(Long serviceProvisionNum) {
		this.serviceProvisionNum = serviceProvisionNum;
	}
	public Boolean getShowOnBill() {
		return showOnBill;
	}
	public void setShowOnBill(Boolean showOnBill) {
		this.showOnBill = showOnBill;
	}
	public Boolean getIsCancelAllReads() {
		return isCancelAllReads;
	}
	public void setIsCancelAllReads(Boolean isCancelAllReads) {
		this.isCancelAllReads = isCancelAllReads;
	}
	public Boolean getCheckMultiSPFlag() {
		return checkMultiSPFlag;
	}
	public void setCheckMultiSPFlag(Boolean checkMultiSPFlag) {
		this.checkMultiSPFlag = checkMultiSPFlag;
	}
	public Boolean getPrintAdjustNoteFlag() {
		return printAdjustNoteFlag;
	}
	public void setPrintAdjustNoteFlag(Boolean printAdjustNoteFlag) {
		this.printAdjustNoteFlag = printAdjustNoteFlag;
	}
	public Boolean getRebillFlag() {
		return rebillFlag;
	}
	public void setRebillFlag(Boolean rebillFlag) {
		this.rebillFlag = rebillFlag;
	}
	public LocalDateTime getDateOfIssue() {
		return dateOfIssue;
	}
	public void setDateOfIssue(LocalDateTime dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	public ReverseBillReason getBillCancelReason() {
		return billCancelReason;
	}
	public void setBillCancelReason(ReverseBillReason billCancelReason) {
		this.billCancelReason = billCancelReason;
	}
	
	
}
