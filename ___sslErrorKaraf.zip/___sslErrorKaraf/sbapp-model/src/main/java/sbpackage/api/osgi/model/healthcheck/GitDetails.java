package sbpackage.api.osgi.model.healthcheck;

import lombok.Data;

@Data
public class GitDetails {
    private String branch;
    private String commitId;
    private String commitTime;
    private String commitUserEmail;
    private String commitMessageShort;
}
