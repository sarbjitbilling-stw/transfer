//this applies the SanitisedTextAdaptor to all text fields in this package during marshalling/unmarshalling
@XmlJavaTypeAdapter(value=SanitisedTextAdaptor.class, type=String.class)
package sbpackage.api.osgi.model.forms;

import sbpackage.api.osgi.model.util.SanitisedTextAdaptor;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;