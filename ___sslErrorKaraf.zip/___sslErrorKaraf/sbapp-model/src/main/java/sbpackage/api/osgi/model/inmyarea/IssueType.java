package sbpackage.api.osgi.model.inmyarea;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static sbpackage.api.osgi.model.inmyarea.WorkType.BCEL;
import static sbpackage.api.osgi.model.inmyarea.WorkType.BLOC;
import static sbpackage.api.osgi.model.inmyarea.WorkType.BLOP;
import static sbpackage.api.osgi.model.inmyarea.WorkType.BLOT;
import static sbpackage.api.osgi.model.inmyarea.WorkType.BLPF;
import static sbpackage.api.osgi.model.inmyarea.WorkType.MAIN;
import static sbpackage.api.osgi.model.inmyarea.WorkType.PRIF;
import static sbpackage.api.osgi.model.inmyarea.WorkType.SMEL;
import static sbpackage.api.osgi.model.inmyarea.WorkType.TGUL;

public enum IssueType {

    BLOCKAGES(PRIF, BLOT, BCEL, BLOP, TGUL, BLOC, MAIN, SMEL, BLPF);

    private Set<WorkType> workTypes;

    IssueType(WorkType... workTypes) {
        this.workTypes = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(workTypes)));
    }

    public Set<WorkType> getWorkTypes() {
        return workTypes;
    }
}
