package sbpackage.api.osgi.model.metering;

public enum MeterReadingType {

    METER_CHANGE_REMOVAL("1"),
    METER_CHANGE_INSTALL("2"),
    CONFIG_CHANGE_BEFORE("3"),
    CONFIG_CHANGE_AFTER("4"),
    RATE_CHANGE_FINAL("5"),
    RATE_CHANGE_INITIAL("6"),
    METER_RESET_BEFORE("7"),
    METER_RESET_AFTER("8"),
    SUBSTITUED_READING("9"),
    CHANGE_OF_SUPPLIER_READ_ACTUAL("A"),
    BATTERY_REPLACED_READ("B"),
    CHECK_READING("C"),
    ESTIMATED_READING("E"),
    TURN_OFF("F"),
    METER_INSTALLATION("I"),
    ACTUAL("M"),
    TURN_ON("N"),
    PRORATED_READING("P"),
    METER_REMOVAL("R"),
    OTHER_SO("S"),
    METER_TEST("T"),
    CHOR_READING("Z");

    private final String code;

    public String getCode() {
        return code;
    }

    MeterReadingType(final String code) {
        this.code = code;
    }
}
