package sbpackage.api.osgi.model.inmyarea;

@lombok.Data
public class Data {

    private String question;
    private String answer;

    public Data() {

    }

    public Data(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    @Override
    public String toString() {
        return String.format("%s: %s", question, answer);
    }
}
