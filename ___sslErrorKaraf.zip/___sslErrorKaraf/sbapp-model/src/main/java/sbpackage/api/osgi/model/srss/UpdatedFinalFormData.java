package sbpackage.api.osgi.model.srss;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdatedFinalFormData {
    
    public UpdatedFinalFormData() {}
    
    @JsonProperty("Id")
    private String Id;
    
    @JsonProperty("Json")
    private String Json;

    public String getJson() {
        return Json;
    }
    
    public UpdatedFinalFormData(String Json) {
        this.Json = "\"["+Json+"]\"";
    }
    
    public UpdatedFinalFormData(String Json, String Id) {
        this.Json = "\"["+Json+"]\"";;
        this.Id = Id;
    }

    public void setJson(String Json) {
        this.Json = Json;
    }
    public String getId() {
        return Id;
    }
    public void setId(String Id) {
        this.Id = Id;
    }

    @Override
    public String toString() {
        return "{\"" +"Id"+"\"" +":"+ "\""+Id + "\""+ "\n"+","+"\"Json\""+":" + Json + "}";
    }

    
}
