package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement(name = "WSSUserDetail")
@XmlAccessorType(XmlAccessType.FIELD)
public class WSSUserDetail {

	@XmlElement(name = "createdDate")
	private String createdDate;

	@XmlElement(name = "lockoutCount")
	private Integer lockoutCount;

	@XmlElement(name = "lockoutDate")
	private Date lockoutDate;

	@XmlElement(name = "idvLockoutCount")
	private String idvLockoutCount;

	@XmlElement(name = "idvLockoutDate")
	private String idvLockoutDate;

	@XmlElement(name = "registrationType")
	private String registrationType;

	@XmlElement(name = "wssPassword")
	private String wssPassword;

	@XmlElement(name = "logonWithEmail")
	private String logonWithEmail;

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getLockoutCount() {
		return lockoutCount;
	}

	public void setLockoutCount(Integer lockoutCount) {
		this.lockoutCount = lockoutCount;
	}

	public Date getLockoutDate() {
		return lockoutDate;
	}

	public void setLockoutDate(Date lockoutDate) {
		this.lockoutDate = lockoutDate;
	}

	public String getIdvLockoutCount() {
		return idvLockoutCount;
	}

	public void setIdvLockoutCount(String idvLockoutCount) {
		this.idvLockoutCount = idvLockoutCount;
	}

	public String getIdvLockoutDate() {
		return idvLockoutDate;
	}

	public void setIdvLockoutDate(String idvLockoutDate) {
		this.idvLockoutDate = idvLockoutDate;
	}

	public String getRegistrationType() {
		return registrationType;
	}

	public void setRegistrationType(String registrationType) {
		this.registrationType = registrationType;
	}

	public String getWssPassword() {
		return wssPassword;
	}

	public void setWssPassword(String wssPassword) {
		this.wssPassword = wssPassword;
	}

	public String getLogonWithEmail() {
		return logonWithEmail;
	}

	public void setLogonWithEmail(String logonWithEmail) {
		this.logonWithEmail = logonWithEmail;
	}
}
