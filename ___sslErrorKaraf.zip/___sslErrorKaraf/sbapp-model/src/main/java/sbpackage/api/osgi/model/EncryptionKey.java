package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;
import java.io.Serializable;

public class EncryptionKey implements Serializable{

    @JsonProperty("key")
    @XmlElement(name = "key")
    private String key;

    public EncryptionKey(String key){
        this.key = key;
    }

    public EncryptionKey(){

    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
