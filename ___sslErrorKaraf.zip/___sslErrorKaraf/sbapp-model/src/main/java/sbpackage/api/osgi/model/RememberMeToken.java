package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Base64;

/**
 * Created by mbeer on 16/08/2017.
 */
@XmlRootElement(name = "RememberMeToken")
public class RememberMeToken implements Serializable {
    private static final String VALUE_TEMPLATE = "%3$s:%1$s:%2$s";

    public static String getTokenFromEncodedValue(String enCodedValue){        
        return decode(enCodedValue).split(":")[2];
    }

    public static String getSeriesFromEncodedValue(String enCodedValue){
        return decode(enCodedValue).split(":")[1];
    }
    
    public static String getUsernameFromEncodedValue(String enCodedValue){
        return decode(enCodedValue).split(":")[0];
    }
    
    private static String decode(String enCodedValue) {
        return new String(Base64.getDecoder().decode(enCodedValue));
    }
        	
    public RememberMeToken() {
    }

    public RememberMeToken(String series, String token, String username) {
        this.value = Base64.getEncoder().encodeToString(String.format(VALUE_TEMPLATE, series, token, username).getBytes());
    }

    @XmlElement(name = "value")
    private String value;

    public RememberMeToken(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
