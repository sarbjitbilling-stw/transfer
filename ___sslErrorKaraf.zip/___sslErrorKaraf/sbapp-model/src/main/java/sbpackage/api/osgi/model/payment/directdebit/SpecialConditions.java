package sbpackage.api.osgi.model.payment.directdebit;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Created by DA on 13/12/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SpecialConditions {

    @XmlElement(name = "demandDirectDebitMessage")
    private String demandDirectDebitMessage;

    @XmlElement(name = "regularPaymentPlansMessage")
    private String regularPaymentPlansMessage;

    public String getDemandDirectDebitMessage() {
        return demandDirectDebitMessage;
    }

    public void setDemandDirectDebitMessage(String demandDirectDebitMessage) {
        this.demandDirectDebitMessage = demandDirectDebitMessage;
    }

    public String getRegularPaymentPlansMessage() {
        return regularPaymentPlansMessage;
    }

    public void setRegularPaymentPlansMessage(String regularPaymentPlansMessage) {
        this.regularPaymentPlansMessage = regularPaymentPlansMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        SpecialConditions that = (SpecialConditions) o;

        return new EqualsBuilder()
                .append(demandDirectDebitMessage, that.demandDirectDebitMessage)
                .append(regularPaymentPlansMessage, that.regularPaymentPlansMessage)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(demandDirectDebitMessage)
                .append(regularPaymentPlansMessage)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("demandDirectDebitMessage", demandDirectDebitMessage)
                .append("regularPaymentPlansMessage", regularPaymentPlansMessage)
                .toString();
    }
}
