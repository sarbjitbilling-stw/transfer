package sbpackage.api.osgi.model.forms;

import sbpackage.api.osgi.model.util.ISODateTimeToInstantAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.Instant;

@XmlAccessorType(XmlAccessType.FIELD)
public class ProgrammeOfWorks {

    @XmlJavaTypeAdapter(ISODateTimeToInstantAdapter.class)
    private Instant plannedStartDate;

    @XmlJavaTypeAdapter(ISODateTimeToInstantAdapter.class)
    private Instant diversionStartDate;

    private boolean datesUnknown;

    public Instant getPlannedStartDate() {
        return plannedStartDate;
    }

    public void setPlannedStartDate(Instant plannedStartDate) {
        this.plannedStartDate = plannedStartDate;
    }

    public Instant getDiversionStartDate() {
        return diversionStartDate;
    }

    public void setDiversionStartDate(Instant diversionStartDate) {
        this.diversionStartDate = diversionStartDate;
    }

    public boolean isDatesUnknown() {
        return datesUnknown;
    }

    public void setDatesUnknown(boolean datesUnknown) {
        this.datesUnknown = datesUnknown;
    }
}
