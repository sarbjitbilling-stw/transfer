package sbpackage.api.osgi.model.forms;

public class ChangeToGroundLevel {

	private int increase;
	private int decrease;
	private Selection selectedOption;


	public int getIncrease() {
		return increase;
	}

	public void setIncrease(int increase) {
		this.increase = increase;
	}

	public int getDecrease() {
		return decrease;
	}

	public void setDecrease(int decrease) {
		this.decrease = decrease;
	}

	public Selection getSelectedOption() {
		return selectedOption;
	}

	public void setSelectedOption(Selection selectedOption) {
		this.selectedOption = selectedOption;
	}
}
