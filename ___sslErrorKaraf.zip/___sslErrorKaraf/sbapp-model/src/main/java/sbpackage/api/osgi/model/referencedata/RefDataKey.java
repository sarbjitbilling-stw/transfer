package sbpackage.api.osgi.model.referencedata;

/**
 * RefDataType encapsulates the ref data value sets from Target. <br/>
 * <br/>
 */
public enum RefDataKey {

    LANGUAGE("1"), PROPERTY_ROLES("7"), PHONE_TYPE_LOCATION("9"), CONTACT_INITIATED_BY("15"), CONTACT_METHOD("16"), FACILITY_CODE("36"),
    RECONCILIATION_METHOD("38"), SERVICE_TYPE("40"), METER_LOCATION("41"), SPECIAL_ATTENTION("51"), BILL_TYPE("56"),
    BILL_PRINT_MEDIUM("57"), ACCOUNT_STATUS("63"), REFUND_REASONS("81"), BILL_CANCEL_REASON("88"), METER_SOURCE("98"),
    GREEN_NOTE_TYPE("113"), TITLE("134"), ACT_QUEUE("138"), ACTPRIORITY("140"), PAY_PLAN_STATUS("147"),
    METER_REVSTATUS("150"), BILL_TYPE_FINANCIALS("167"), METER_STATE("168"), METER_BILLED("169"),
    DMA_TO_GEOGRAPHICAL_AREA("175"), BUDGET_PLAN("176"), CONTACT_TYPE("251"), CONTACT_RESOLUTION("252"),
    METER_READ_METHOD("330"), CONTACT_REASON("379"), BENEFIT_TYPE("438"), SERVICE_INDICATOR("457"),
    VULNERABLE_AFFECTS("473"), VULNERABLE_TERM("474"), VULNERABLE_SUPPLY("475"), CAPTURE_SYSTEM("476"),
    CAPTURE_SOURCE("477"), VULNERABLE_OUT_OF_HOURS_CONTACT("479"), EVACUATION_PLAN("480"), LANGUAGE_LINE("481"),
    VOICE_TEXT_SERVICE("482"), EMPLOYMENT_STATUS("802"), HOME_OWNER("803"), DATA_SHARE_INDICATOR("828"),
    DATA_SHARE_SOURCE("829"), HOME_SERVE("878"), VULNERABLE_TYPE("881"), ACCOUNT_ROLES("10001"), METER_TYPE("10002"),
    AQ_TYPES("10003"), STREET_SUFFIX("10004"), SIC_CODE("10005"), TERMINATION_REASON("10006"),
    SCHEDULE_FREQ("10007"), ORG_UNITS("10008"), PROPERTIES_SERVICE_PROVISION("20001"), PROPERTIES_STATUS("20002");

    private String value;

    RefDataKey(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public static RefDataKey fromValue(String value) {
        for (RefDataKey refDataType : values()) {
            if (refDataType.value.equalsIgnoreCase(value)) {
                return refDataType;
            }
        }
        throw new IllegalArgumentException(String.format("No RefDataType found for %s", value));
    }

    @Override
    public String toString() {
        return fromValue(value).name();
    }
}
