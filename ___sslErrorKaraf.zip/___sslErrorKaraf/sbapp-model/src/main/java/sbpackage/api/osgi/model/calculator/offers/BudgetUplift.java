package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BudgetUplift implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement
    private String payPlanType;

    @XmlElement
    private String budgetPlanType;

    @XmlElement
    private String budgetPlanTypeTargetCode;

    @XmlElement
    private String paymentFrequencyTargetCode;

    @XmlElement
    private String paymentFrequency;


    @XmlElement
    private BigDecimal uplift;

    @XmlElement
    private BigDecimal percentageUplift;

    public String getPayPlanType() {
        return payPlanType;
    }

    public void setPayPlanType(final String payPlanType) {
        this.payPlanType = payPlanType;
    }

    public String getBudgetPlanType() {
        return budgetPlanType;
    }

    public void setBudgetPlanType(final String budgetPlanType) {
        this.budgetPlanType = budgetPlanType;
    }

    public String getPaymentFrequencyTargetCode() {
        return paymentFrequencyTargetCode;
    }

    public void setPaymentFrequencyTargetCode(final String paymentFrequencyTargetCode) {
        this.paymentFrequencyTargetCode = paymentFrequencyTargetCode;
    }

    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(final String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public BigDecimal getUplift() {
        return uplift;
    }

    public void setUplift(final BigDecimal uplift) {
        this.uplift = uplift;
    }

    public BigDecimal getPercentageUplift() {
        return percentageUplift;
    }

    public void setPercentageUplift(final BigDecimal percentageUplift) {
        this.percentageUplift = percentageUplift;
    }

    public String getBudgetPlanTypeTargetCode() {
        return budgetPlanTypeTargetCode;
    }

    public void setBudgetPlanTypeTargetCode(final String budgetPlanTypeTargetCode) {
        this.budgetPlanTypeTargetCode = budgetPlanTypeTargetCode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("payPlanType", payPlanType)
                .append("budgetPlanType", budgetPlanType)
                .append("budgetPlanTypeTargetCode", budgetPlanTypeTargetCode)
                .append("paymentFrequencyTargetCode", paymentFrequencyTargetCode)
                .append("paymentFrequency", paymentFrequency)
                .append("uplift", uplift)
                .append("percentageUplift", percentageUplift)
                .toString();
    }
}