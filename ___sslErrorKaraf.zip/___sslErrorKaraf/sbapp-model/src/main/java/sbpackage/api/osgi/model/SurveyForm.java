package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Arrays;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlRootElement(name = "SurveyForm")
@XmlAccessorType(XmlAccessType.FIELD)
public class SurveyForm {

    @XmlElement
    private SurveyType surveyType;

    @XmlElement
    private QuestionScore[] scoreAnswers;

    @XmlElement
    private QuestionConfirm[] confirmAnswers;

    @XmlElement
    private String comment;

    @XmlElement
    private TargetAccountNumber accountNumber;

    @XmlElement
    private String legalEntityId;

    @XmlElement
    private String authenticationMethod;

    public SurveyType getSurveyType() {
        return surveyType;
    }

    public void setSurveyType(SurveyType surveyType) {
        this.surveyType = surveyType;
    }

    public QuestionScore[] getScoreAnswers() {
        return scoreAnswers;
    }

    public void setScoreAnswers(QuestionScore[] scoreAnswers) {
        this.scoreAnswers = scoreAnswers;
    }

    public QuestionConfirm[] getConfirmAnswers() {
        return confirmAnswers;
    }

    public void setConfirmAnswers(QuestionConfirm[] confirmAnswers) {
        this.confirmAnswers = confirmAnswers;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntityId() { return legalEntityId; }

    public void setLegalEntityId(String legalEntityId) { this.legalEntityId = legalEntityId; }

    public String getAuthenticationMethod() {
        return authenticationMethod;
    }

    public void setAuthenticationMethod(String authenticationMethod) {
        this.authenticationMethod = authenticationMethod;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        SurveyForm that = (SurveyForm) o;

        return new EqualsBuilder()
                .append(surveyType, that.surveyType)
                .append(scoreAnswers, that.scoreAnswers)
                .append(confirmAnswers, that.confirmAnswers)
                .append(comment, that.comment)
                .append(accountNumber, that.accountNumber)
                .append(legalEntityId, that.legalEntityId)
                .append(authenticationMethod, that.authenticationMethod)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(surveyType)
                .append(scoreAnswers)
                .append(confirmAnswers)
                .append(comment)
                .append(accountNumber)
                .append(legalEntityId)
                .append(authenticationMethod)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("surveyType", surveyType)
                .append("scoreAnswers", scoreAnswers)
                .append("confirmAnswers", confirmAnswers)
                .append("comment", comment)
                .append("accountNumber", accountNumber)
                .append("legalEntityId", legalEntityId)
                .append("authenticationMethod", authenticationMethod)
                .toString();
    }
}

