package sbpackage.api.osgi.model.calculator.consumption;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Set;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UsageBand implements Serializable {

    private static final long serialVersionUID = -1049695669158359691L;

    private BudgetType type;

    private double totalConsumption;

    private double dailyConsumption;

    private double total;

    private Set<CalculationValue> calculation;

    public BudgetType getType() {
        return type;
    }

    public void setType(BudgetType type) {
        this.type = type;
    }

    public double getTotalConsumption() {
        return totalConsumption;
    }

    public void setTotalConsumption(double totalConsumption) {
        this.totalConsumption = totalConsumption;
    }

    public double getDailyConsumption() {
        return dailyConsumption;
    }

    public void setDailyConsumption(double dailyConsumption) {
        this.dailyConsumption = dailyConsumption;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Set<CalculationValue> getCalculation() {
        return calculation;
    }

    public void setCalculation(Set<CalculationValue> calculation) {
        this.calculation = calculation;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("UsageBand [");
		builder.append("type=");
		builder.append(type);
		builder.append(", totalConsumption=");
		builder.append(totalConsumption);
		builder.append(", dailyConsumption=");
		builder.append(dailyConsumption);
		builder.append(", total=");
		builder.append(total);
		builder.append(", ");
		calculation.forEach(calcvalue->builder.append(calcvalue));
		builder.append("]");
		return builder.toString();
	}
    
    
    
}
