package sbpackage.api.osgi.model.sms;

public class SmsContent {
    private SmsTemplateGroup templateGroup;
    private String reference;
    private String body;

    public SmsContent() {
    }

    public SmsContent(SmsTemplateGroup templateGroup, String reference, String body) {
        this.templateGroup = templateGroup;
        this.reference = reference;
        this.body = body;
    }

    public SmsContent(SmsContent smsContent) {
        this.templateGroup = smsContent.getTemplateGroup();
        this.reference = smsContent.getReference();
        this.body = smsContent.getBody();
    }

    public SmsTemplateGroup getTemplateGroup() {
        return templateGroup;
    }

    public void setTemplateGroup(SmsTemplateGroup templateGroup) {
        this.templateGroup = templateGroup;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

}