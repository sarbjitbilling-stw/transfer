package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LegalEntityCheckResponse")
@XmlRootElement(name="LegalEntityCheckResponse")
public class LegalEntityReuseResponse {
	@XmlAttribute(required=true)
	private Boolean reuseLE = Boolean.FALSE;

	/**
	 * only ever populated when reuseLE is set to false.
	 */
	@XmlAttribute(required=false)
	private Long accountId;

	public Boolean getReuseLE() {
		return reuseLE;
	}

	public void setReuseLE(Boolean reuseLE) {
		this.reuseLE = reuseLE;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
}
