package sbpackage.api.osgi.model.bill.simulate;

public enum SimulateBillWarning {
    SIMULATE_BILL_WARNING,
    GENERAL_TARGET_WARNING;

    SimulateBillWarning() {
    }
}
