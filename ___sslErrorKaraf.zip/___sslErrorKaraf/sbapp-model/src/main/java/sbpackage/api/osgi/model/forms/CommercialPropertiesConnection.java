package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CommercialPropertiesConnection {

    private PurposeOfTheProperty purposeOfTheProperty;
    private SelectionWithFlowRate requireFittings;
    private FittingsWrapper waterRequisitionFittings;
    private ProcessWater processWater;
    private SelectionWithFlowRate requireFireFighting;
    private FireFightingRequirementsSelection fireFightingRequirements;

    public PurposeOfTheProperty getPurposeOfTheProperty() {
        return purposeOfTheProperty;
    }

    public void setPurposeOfTheProperty(PurposeOfTheProperty purposeOfTheProperty) {
        this.purposeOfTheProperty = purposeOfTheProperty;
    }

    public SelectionWithFlowRate getRequireFittings() {
        return requireFittings;
    }

    public void setRequireFittings(SelectionWithFlowRate requireFittings) {
        this.requireFittings = requireFittings;
    }

    public FittingsWrapper getWaterRequisitionFittings() {
        return waterRequisitionFittings;
    }

    public void setWaterRequisitionFittings(FittingsWrapper waterRequisitionFittings) {
        this.waterRequisitionFittings = waterRequisitionFittings;
    }

    public ProcessWater getProcessWater() {
        return processWater;
    }

    public void setProcessWater(ProcessWater processWater) {
        this.processWater = processWater;
    }

    public SelectionWithFlowRate getRequireFireFighting() {
        return requireFireFighting;
    }

    public void setRequireFireFighting(SelectionWithFlowRate requireFireFighting) {
        this.requireFireFighting = requireFireFighting;
    }

    public FireFightingRequirementsSelection getFireFightingRequirements() {
        return fireFightingRequirements;
    }

    public void setFireFightingRequirements(FireFightingRequirementsSelection fireFightingRequirements) {
        this.fireFightingRequirements = fireFightingRequirements;
    }
}
