package sbpackage.api.osgi.model.forms;

public enum FormCategory {
    SERVICE_CONNECTION,
    DEVELOPER_ENQUIRIES,
    POINT_OF_CONNECTION,
    WATER_MAIN_REQUISITION,
    ADOPTION_OF_SEWER,
    DVWASTE,
    DVWATER,
    SEWER_REQUISITION,
    NEW_APPOINTMENTS_AND_VARIATIONS;

    public static FormCategory lookupByType(FormType type) {
        switch(type) {
            case SCWASTE:
            case SCWATER:
            case SCCOMBINED:
                return SERVICE_CONNECTION;

            case DEWASTE:
            case DEWATER:
            case DECOMBINED:
                return DEVELOPER_ENQUIRIES;

            case DVWASTE:
            	return DVWASTE;
            case DVWATER:
                return DVWATER;
                
            case POC:
                return POINT_OF_CONNECTION;

            case WATER_MAIN_REQUISITION:
                return WATER_MAIN_REQUISITION;

            case ADOPTION_OF_NEW_SEWER:
            case ADOPTION_OF_EXISTING_SEWER:
                return ADOPTION_OF_SEWER;

            case SEWER_REQUISITION:
                return SEWER_REQUISITION;

            case NAVWATER:
            case NAVWASTE:
            case NAVCOMBINED:
                return NEW_APPOINTMENTS_AND_VARIATIONS;

            default:
                throw new RuntimeException("Could not identify form category from type " + type);
        }
    }
}
