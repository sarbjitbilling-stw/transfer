package sbpackage.api.osgi.model.healthcheck;

public class HealthCheck {

    private Status status;
    private String message;

    private HealthCheck(Status status, String message) {
        this.status = status;
        this.message = message;
    }

    private HealthCheck(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public static HealthCheck success() {
        return new HealthCheck(Status.SUCCESS);
    }

    public static HealthCheck failed(String message) {
        return new HealthCheck(Status.FAILURE, message);
    }
}
