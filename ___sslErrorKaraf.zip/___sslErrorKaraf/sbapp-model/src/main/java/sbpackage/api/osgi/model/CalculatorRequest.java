package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CalculatorRequest {

    private static final long serialVersionUID = 8639651743142351396L;

    @XmlElement
    private boolean waterService;
    
    @XmlElement
    private boolean sewerageService;
    
    @XmlElement
    private boolean surfaceWaterService;
    
    @XmlElement
    private boolean usedWaterService;
    
    @XmlElement
    private boolean highwaysDrainageService;
    
    @XmlElement
    private String waterSupplier;
    
    @XmlElement
    private String usedWaterSupplier;
    
    @XmlElement
    private String surfaceWaterSupplier;

    @XmlElement
    private String highwayDrainageSupplier;
    
    @XmlElement
    private String sewerageSupplier;

    public boolean isWaterService() {
        return waterService;
    }

    public void setWaterService(boolean waterService) {
        this.waterService = waterService;
    }

    public boolean isSewerageService() {
        return sewerageService;
    }

    public void setSewerageService(boolean sewerageService) {
        this.sewerageService = sewerageService;
    }

    public boolean isSurfaceWaterService() {
        return surfaceWaterService;
    }

    public void setSurfaceWaterService(boolean surfaceWaterService) {
        this.surfaceWaterService = surfaceWaterService;
    }

    public boolean isUsedWaterService() {
        return usedWaterService;
    }

    public void setUsedWaterService(boolean usedWaterService) {
        this.usedWaterService = usedWaterService;
    }

    public boolean isHighwaysDrainageService() {
        return highwaysDrainageService;
    }

    public void setHighwaysDrainageService(boolean highwaysDrainageService) {
        this.highwaysDrainageService = highwaysDrainageService;
    }

    public String getWaterSupplier() {
        return waterSupplier;
    }

    public void setWaterSupplier(String waterSupplier) {
        this.waterSupplier = waterSupplier;
    }

    public String getUsedWaterSupplier() {
        return usedWaterSupplier;
    }

    public void setUsedWaterSupplier(String usedWaterSupplier) {
        this.usedWaterSupplier = usedWaterSupplier;
    }

    public String getSurfaceWaterSupplier() {
        return surfaceWaterSupplier;
    }

    public void setSurfaceWaterSupplier(String surfaceWaterSupplier) {
        this.surfaceWaterSupplier = surfaceWaterSupplier;
    }

    public String getHighwayDrainageSupplier() {
        return highwayDrainageSupplier;
    }

    public void setHighwayDrainageSupplier(String highwayDrainageSupplier) {
        this.highwayDrainageSupplier = highwayDrainageSupplier;
    }

    public String getSewerageSupplier() {
        return sewerageSupplier;
    }

    public void setSewerageSupplier(String sewerageSupplier) {
        this.sewerageSupplier = sewerageSupplier;
    }
}
