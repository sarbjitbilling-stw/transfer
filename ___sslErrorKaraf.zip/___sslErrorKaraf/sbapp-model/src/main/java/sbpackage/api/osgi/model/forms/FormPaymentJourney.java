package sbpackage.api.osgi.model.forms;

public enum FormPaymentJourney {
    CARD_PAYMENT, PROFORMA, NON_CHARGEABLE;
}
