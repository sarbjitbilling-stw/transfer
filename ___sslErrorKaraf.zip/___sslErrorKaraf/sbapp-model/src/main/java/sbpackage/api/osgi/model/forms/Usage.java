package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Usage {

    private float annualDemand;
    private float averageDailyUsage;
    private float peakFlowRate;

    private float foulDischargeRate;
    private float foulPeakDailyDischarge;
    private float annualDischarge;
    private float surfaceWaterDischargeRate;

    public float getAnnualDemand() {
        return annualDemand;
    }

    public void setAnnualDemand(float annualDemand) {
        this.annualDemand = annualDemand;
    }

    public float getAverageDailyUsage() {
        return averageDailyUsage;
    }

    public void setAverageDailyUsage(float averageDailyUsage) {
        this.averageDailyUsage = averageDailyUsage;
    }

    public float getPeakFlowRate() {
        return peakFlowRate;
    }

    public void setPeakFlowRate(float peakFlowRate) {
        this.peakFlowRate = peakFlowRate;
    }

    public float getFoulDischargeRate() {
        return foulDischargeRate;
    }

    public void setFoulDischargeRate(float foulDischargeRate) {
        this.foulDischargeRate = foulDischargeRate;
    }

    public float getFoulPeakDailyDischarge() {
        return foulPeakDailyDischarge;
    }

    public void setFoulPeakDailyDischarge(float foulPeakDailyDischarge) {
        this.foulPeakDailyDischarge = foulPeakDailyDischarge;
    }

    public float getAnnualDischarge() {
        return annualDischarge;
    }

    public void setAnnualDischarge(float annualDischarge) {
        this.annualDischarge = annualDischarge;
    }

    public float getSurfaceWaterDischargeRate() {
        return surfaceWaterDischargeRate;
    }

    public void setSurfaceWaterDischargeRate(float surfaceWaterDischargeRate) {
        this.surfaceWaterDischargeRate = surfaceWaterDischargeRate;
    }
}
