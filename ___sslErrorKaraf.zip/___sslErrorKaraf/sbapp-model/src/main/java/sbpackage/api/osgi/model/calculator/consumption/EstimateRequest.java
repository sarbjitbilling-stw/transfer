package sbpackage.api.osgi.model.calculator.consumption;

import java.io.Serializable;
import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import sbpackage.api.osgi.model.CalculatorRequest;
import sbpackage.api.osgi.model.calculator.PropertyType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class EstimateRequest extends CalculatorRequest implements Serializable {

    private static final long serialVersionUID = 6367306176118721091L;
    @XmlElement(required=true)
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate startDate;

    @XmlElement(required=true)
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate endDate;


    @XmlElement(required=true)
    private int numberOfAdultOccupants;
    @XmlElement(required=true)
    private int numberOfChildrenOccupants;
    @XmlElement(required=true)
    private PropertyType propertyType;

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public int getNumberOfAdultOccupants() {
        return numberOfAdultOccupants;
    }

    public void setNumberOfAdultOccupants(int numberOfAdultOccupants) {
        this.numberOfAdultOccupants = numberOfAdultOccupants;
    }

    public int getNumberOfChildrenOccupants() {
        return numberOfChildrenOccupants;
    }

    public void setNumberOfChildrenOccupants(int numberOfChildrenOccupants) {
        this.numberOfChildrenOccupants = numberOfChildrenOccupants;
    }

    public PropertyType getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(PropertyType propertyType) {
        this.propertyType = propertyType;
    }
}

class LocalDateAdapter extends XmlAdapter<String, LocalDate> {
    public LocalDate unmarshal(String v) throws Exception {
        return LocalDate.parse(v);
    }

    public String marshal(LocalDate v) throws Exception {
        return v.toString();
    }
}
