package sbpackage.api.osgi.model.metering;

public enum RefDataDefinition {
    BILLABLE_READ_STATUS("Billable", "B", "168"),
    NOT_BILLABLE_READ_STATUS("Not Billable", "N", "168"),
    INFORMATION_ONLY_READ_STATUS("Information Only", "I", "168");

    private final String value;
    private final String code;
    private final String valueSet;

    RefDataDefinition(final String value, final String code, final String valueSet) {
        this.value = value;
        this.code = code;
        this.valueSet = valueSet;
    }

    public String getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }

    public String getValueSet() {
        return valueSet;
    }
}
