package sbpackage.api.osgi.model.chor;

import com.fasterxml.jackson.annotation.JsonInclude;
import sbpackage.api.osgi.model.Address;
import sbpackage.api.osgi.model.Customer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement(name = "ChorRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChorRequest {

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "customer")
    private Customer customer;

    @XmlElement(name = "movingOutDetails")
    private MoveRequestDetail movingOutDetails;

    @XmlElement(name = "movingInDetails")
    private MoveRequestDetail movingInDetails;

    @XmlElement(name = "billPayerAtMovingInAddress")
    private boolean billPayerAtMovingInAddress;

    @XmlElement(name = "newResponsibilities")
    private List<Customer> newResponsibilities;

    @XmlElement(name = "newAddressPreviousCustomer")
    private Address newAddressPreviousCustomer;

    @XmlElement(name = "emailAddress")
    private String emailAddress;

    @XmlElement(name = "contactNumber")
    private String contactNumber;

    @XmlElement(name = "daysInFutureChorAllowedFor")
    private int daysInFutureChorAllowedFor;

    @XmlElement(name = "daysAfterEndDateMeterReadAllowedFor")
    private int daysAfterEndDateMeterReadAllowedFor;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public MoveRequestDetail getMovingOutDetails() {
        return movingOutDetails;
    }

    public void setMovingOutDetails(MoveRequestDetail movingOutDetails) {
        this.movingOutDetails = movingOutDetails;
    }

    public MoveRequestDetail getMovingInDetails() {
        return movingInDetails;
    }

    public void setMovingInDetails(MoveRequestDetail movingInDetails) {
        this.movingInDetails = movingInDetails;
    }

    public boolean isBillPayerAtMovingInAddess() {
        return billPayerAtMovingInAddress;
    }

    public void setBillPayerAtMovingInAddess(boolean billPayerAtMovingInAddess) {
        this.billPayerAtMovingInAddress = billPayerAtMovingInAddess;
    }

    public List<Customer> getNewResponsibilities() {
        return newResponsibilities;
    }

    public void setNewResponsibilities(List<Customer> newResponsibilities) {
        this.newResponsibilities = newResponsibilities;
    }

    public Address getNewAddressPreviousCustomer() {
        return newAddressPreviousCustomer;
    }

    public void setNewAddressPreviousCustomer(Address newAddressPreviousCustomer) {
        this.newAddressPreviousCustomer = newAddressPreviousCustomer;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "ChorRequest{" +
                "accountNumber='" + accountNumber + '\'' +
                ", customer=" + customer +
                ", movingOutDetails=" + movingOutDetails +
                ", movingInDetails=" + movingInDetails +
                ", billPayerAtMovingInAddress=" + billPayerAtMovingInAddress +
                ", newResponsibilities=" + newResponsibilities +
                ", newAddressPreviousCustomer=" + newAddressPreviousCustomer +
                ", emailAddress='" + emailAddress + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                '}';
    }

    public int getDaysInFutureChorAllowedFor() {
        return daysInFutureChorAllowedFor;
    }

    public void setDaysInFutureChorAllowedFor(int daysInFutureChorAllowedFor) {
        this.daysInFutureChorAllowedFor = daysInFutureChorAllowedFor;
    }

    public int getDaysAfterEndDateMeterReadAllowedFor() {
        return daysAfterEndDateMeterReadAllowedFor;
    }

    public void setDaysAfterEndDateMeterReadAllowedFor(int daysAfterEndDateMeterReadAllowedFor) {
        this.daysAfterEndDateMeterReadAllowedFor = daysAfterEndDateMeterReadAllowedFor;
    }
}
