package sbpackage.api.osgi.model.metering;

public enum MeterReadStatus {

    B("B", "BILLABLE"),
    N("N", "NOT BILLABLE"),
    I("I", "INFORMATION ONLY");

    private final String code;
    private final String description;

    MeterReadStatus(final String code, final String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}

