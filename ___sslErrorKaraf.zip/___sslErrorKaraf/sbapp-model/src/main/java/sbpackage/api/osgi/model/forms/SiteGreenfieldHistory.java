package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SiteGreenfieldHistory {

    private boolean siteIsGreenfield;
    private String siteIsGreenfieldDisplayValue;
    private String previousUseOfPropertyKey;
    private int commercialPropertyCount;
    private int domesticPropertyCount;
    private boolean dontKnowPreviousProperties;
    private String dontKnowPreviousPropertiesDisplayValue;
    private boolean completed;

    public boolean isSiteIsGreenfield() {
        return siteIsGreenfield;
    }

    public void setSiteIsGreenfield(boolean siteIsGreenfield) {
        this.siteIsGreenfield = siteIsGreenfield;
    }

    public String getSiteIsGreenfieldDisplayValue() {
        return siteIsGreenfieldDisplayValue;
    }

    public void setSiteIsGreenfieldDisplayValue(String siteIsGreenfieldDisplayValue) {
        this.siteIsGreenfieldDisplayValue = siteIsGreenfieldDisplayValue;
    }

    public int getCommercialPropertyCount() {
        return commercialPropertyCount;
    }

    public void setCommercialPropertyCount(int commercialPropertyCount) {
        this.commercialPropertyCount = commercialPropertyCount;
    }

    public int getDomesticPropertyCount() {
        return domesticPropertyCount;
    }

    public void setDomesticPropertyCount(int domesticPropertyCount) {
        this.domesticPropertyCount = domesticPropertyCount;
    }

    public boolean dontKnowPreviousProperties() {
        return dontKnowPreviousProperties;
    }

    public void setDontKnowPreviousProperties(boolean dontKnowPreviousProperties) {
        this.dontKnowPreviousProperties = dontKnowPreviousProperties;
    }

    public String getDontKnowPreviousPropertiesDisplayValue() {
        return dontKnowPreviousPropertiesDisplayValue;
    }

    public void setDontKnowPreviousPropertiesDisplayValue(String dontKnowPreviousPropertiesDisplayValue) {
        this.dontKnowPreviousPropertiesDisplayValue = dontKnowPreviousPropertiesDisplayValue;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String getPreviousUseOfPropertyKey() {
        return previousUseOfPropertyKey;
    }

    public void setPreviousUseOfPropertyKey(String previousUseOfPropertyKey) {
        this.previousUseOfPropertyKey = previousUseOfPropertyKey;
    }
}
