package sbpackage.api.osgi.model.payment;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.calculator.offers.Budget;
import sbpackage.api.osgi.model.calculator.offers.Offer;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlan {

    private Long planId;

    private String payPlanStatus;

    private String cardType;

    private TargetAccountNumber accountNumber;

    private String paymentMethod;

    private String paymentFrequency;

    private String terminationReasonCode;

    private boolean createPlan;

    private boolean sendWaterCard;

    private boolean cancelRebill;

    private Offer planDetails;

    private Budget budget;

    private BankAccount bankAccount;

    private boolean suppressPrint;

    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate expectedPaymentDate;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentType) {
        this.paymentMethod = paymentType;
    }

    public boolean isCreatePlan() {
        return createPlan;
    }

    public void setCreatePlan(boolean createPlan) {
        this.createPlan = createPlan;
    }

    public boolean isSendWaterCard() {
        return sendWaterCard;
    }

    public void setSendWaterCard(boolean sendWaterCard) {
        this.sendWaterCard = sendWaterCard;
    }

    public Offer getPlanDetails() {
        return planDetails;
    }

    public void setPlanDetails(Offer planDetails) {
        this.planDetails = planDetails;
    }

    public Budget getBudget() {
        return budget;
    }

    public void setBudget(Budget budget) {
        this.budget = budget;
    }

    public BankAccount getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(BankAccount bankDetails) {
        this.bankAccount = bankDetails;
    }

    public Long getPlanId() {
        return planId;
    }

    public void setPlanId(Long planId) {
        this.planId = planId;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getPayPlanStatus() {
        return payPlanStatus;
    }

    public void setPayPlanStatus(String payPlanStatus) {
        this.payPlanStatus = payPlanStatus;
    }

    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public boolean isCancelRebill() {
        return cancelRebill;
    }

    public void setCancelRebill(boolean cancelRebill) {
        this.cancelRebill = cancelRebill;
    }

    public String getTerminationReasonCode() {
        return terminationReasonCode;
    }

    public void setTerminationReasonCode(String terminationReasonCode) {
        this.terminationReasonCode = terminationReasonCode;
    }

    public boolean isSuppressPrint() {
        return suppressPrint;
    }

    public void setSuppressPrint(boolean suppressPrint) {
        this.suppressPrint = suppressPrint;
    }

    public LocalDate getExpectedPaymentDate() {
        return expectedPaymentDate;
    }

    public void setExpectedPaymentDate(LocalDate expectedPaymentDate) {
        this.expectedPaymentDate = expectedPaymentDate;
    }
}
