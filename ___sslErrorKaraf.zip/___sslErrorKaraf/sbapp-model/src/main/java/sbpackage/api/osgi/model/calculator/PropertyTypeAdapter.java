package sbpackage.api.osgi.model.calculator;

import java.util.Objects;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class PropertyTypeAdapter extends XmlAdapter<String, PropertyType> {
    @Override
    public PropertyType unmarshal(String value) {
        return PropertyType.getPropertyTypeFromValue(value);
    }

    @Override
    public String marshal(PropertyType value) {
        return Objects.toString(value, null);
    }
}