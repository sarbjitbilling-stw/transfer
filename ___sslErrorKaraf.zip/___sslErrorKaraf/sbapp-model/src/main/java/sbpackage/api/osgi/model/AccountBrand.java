package sbpackage.api.osgi.model;

import java.util.Arrays;

public enum AccountBrand {
	// Need to add site to the ENUM for validation in Email service
	SEVERN_TRENT("1", "ST", "STW"), HD_HOUSE_HOLD("2", "HD_HH", "HD"), HD_NON_HOUSE_HOLD("3", "HD_NHH", "HD"),
	// This value (N) will be passed by the IIB Service if no brand is linked to the
	// account.
	// ie: brand new Account with no properties.
	NONE("N", "NONE", "NONE");

	private final String accountBrand;
	private final String description;
	private final String site;

	AccountBrand(final String accountBrand, final String description, final String site) {
		this.accountBrand = accountBrand;
		this.description = description;
		this.site = site;
	}

	public String getAccountBrand() {
		return accountBrand;
	}

	public String getDescription() {
		return description;
	}

	public boolean isSiteEqual(String site) {
		return this.site.equals(site);
	}

	public String getSite() {
		return this.site;
	}

	public WSSSite getWssSite() {
		return WSSSite.valueOf(site);
	}

	static public boolean isValidEnum(String accountBrand) {
		return Arrays.stream(AccountBrand.values()).anyMatch(item -> item.accountBrand.equalsIgnoreCase(accountBrand));
	}

	static public boolean isValidBrand(String accountBrand) {
		return isValidEnum(accountBrand) && !accountBrand.equalsIgnoreCase(NONE.accountBrand);
	}

	public static AccountBrand resolveByAccountBrand(final String accountBrand) {
		AccountBrand resolved = null;
		for (AccountBrand brand : AccountBrand.values()) {
			if (brand.getAccountBrand().equals(accountBrand)) {
				resolved = brand;
				break;
			}
		}
		return resolved;
	}

	public static AccountBrand resolveBySite(String site) {
		for(AccountBrand accountBrand : AccountBrand.values()) {
			if(accountBrand.isSiteEqual(site)) {
				return accountBrand;
			}
		}
		return AccountBrand.SEVERN_TRENT;
	}
}