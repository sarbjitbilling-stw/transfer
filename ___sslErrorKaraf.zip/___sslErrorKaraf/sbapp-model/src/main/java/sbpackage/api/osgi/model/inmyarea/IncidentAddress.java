package sbpackage.api.osgi.model.inmyarea;

import lombok.Data;
import sbpackage.api.osgi.model.Address;

@Data
public class IncidentAddress {

    private AddressType selectedOption;
    private String postcode;
    private String flocId;
    private Address selectedAddress;
    private String xcoor;
    private String ycoor;

    public enum AddressType {
        locationSearch, accountAddress, mapLocation
    }
}
