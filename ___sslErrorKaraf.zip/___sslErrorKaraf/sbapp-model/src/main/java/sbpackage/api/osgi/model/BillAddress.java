package sbpackage.api.osgi.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.referencedata.RefData;

import javax.xml.bind.annotation.*;
import java.time.LocalDate;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillAddress", propOrder =
        {"id", "name1", "name2", "line1", "line2", "line3", "line4", "startDate", "careOfName", "careOfPrefixCode"
        })

@XmlRootElement(name = "BillAddress")
public class BillAddress {


    @XmlElement(name = "id")
    private Long id = null;

    @XmlElement(name = "name1")
    private String name1 = null;

    @XmlElement(name = "name2")
    private String name2 = null;

    @XmlElement(name = "line1")
    private String line1 = null;

    @XmlElement(name = "line2")
    private String line2 = null;

    @XmlElement(name = "line3")
    private String line3 = null;

    @XmlElement(name = "line4")
    private String line4 = null;

    @XmlElement(name = "startDate")
    private LocalDate startDate = null;

    @XmlElement(name = "careOfName")
    private String careOfName = null;

    @XmlElement(name = "careOfPrefixCode")
    private RefData careOfPrefixCode = null;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getLine3() {
        return line3;
    }

    public void setLine3(String line3) {
        this.line3 = line3;
    }

    public String getLine4() {
        return line4;
    }

    public void setLine4(String line4) {
        this.line4 = line4;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public String getCareOfName() {
        return careOfName;
    }

    public void setCareOfName(String careOfName) {
        this.careOfName = careOfName;
    }

    public RefData getCareOfPrefixCode() {
        return careOfPrefixCode;
    }

    public void setCareOfPrefixCode(RefData careOfPrefixCode) {
        this.careOfPrefixCode = careOfPrefixCode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("name1", name1)
                .append("name2", name2)
                .append("line1", line1)
                .append("line2", line2)
                .append("line3", line3)
                .append("line4", line4)
                .append("startDate", startDate)
                .append("careOfName", careOfName)
                .append("careOfPrefixCode", careOfPrefixCode)
                .toString();
    }
}

