package sbpackage.api.osgi.model.inmyarea;

public class ActivityQueueContants {
    public static final String CONTACT_TYPE_BILLING = "3";
    public static final String CONTACT_METHOD_WSS = "80";
    public static final String CONTACT_INITIATED_BY_CUSTOMER = "3";
    public static final String CONTACT_SUB_TYPE_FROPT_QUERIES = "126";
    public static final String CONTACT_SUB_TYPE_SOAC_ENQUIRY = "419";
    public static final String CONTACT_SUB_TYPE_CHECK_METER_OPT_IN = "714";
    public static final long ORGANISATION_NUMBER_CAPITA = 2000457;
    public static final String ACTIVITY_TYPE_CODE_FROPT_ASSESSED = "FASCH";
    public static final String ACTIVITY_TYPE_CODE_SOAC = "SOAC";
    public static final String ACTIVITY_TYPE_CODE_CHECK_METER_OPT_IN = "CMOPIN";
    public static final String ACTIVITY_TYPE_CODE_METER_MAINTENANCE_UNABLE_TO_FIT = "UNFIT";
    public static final String ACTIVITY_PRORITY_MEDIUM = "5";
    public static final String ROOT_CAUSE_TYPE_FROPT_ENQUIRY = "R060";
    public static final String ROOT_CAUSE_TYPE_METER_ISSUE = "R120";
    public static final String CONTACT_PACKAGE_ID_FROPT_QUERIES = "130";
    public static final String CONTACT_PACKAGE_ID_SOAC_ENQUIRY = "2000992";
    public static final String CONTACT_PACKAGE_ID_CHECK_METER_OPT_IN = "2002078";
    
    private ActivityQueueContants() {
    }
}
