package sbpackage.api.osgi.model.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

public class LocalDateTimeAdapter extends XmlAdapter<String, LocalDateTime> {

	private static final String DATE_FORMAT_WITH_T = "yyyy-MM-dd'T'HH:mm:ss";
	private static final String DATE_FORMAT_WITHOUT_T = "yyyy-MM-dd HH:mm:ss";
	private static final String OUTPUT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS";

    public LocalDateTime unmarshal(String input) {

		if (input == null) throw new AssertionError("Input cannot be null");
		String dateFormat = input.contains("T") ? DATE_FORMAT_WITH_T : DATE_FORMAT_WITHOUT_T;
		int pos = input.indexOf('.');
		if(pos > 0) {
			// check if milliseconds supplied and how many digits?
			String milliseconds = input.substring(pos + 1);
			dateFormat += "." + String.join("", Collections.nCopies(milliseconds.length(), "S"));
		}
    	
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);

        return LocalDateTime.parse(input, formatter);
    }

    public String marshal(LocalDateTime input) {

		if (input == null) throw new AssertionError("Input cannot be null");
		return input.format(DateTimeFormatter.ofPattern(OUTPUT_DATE_FORMAT));
    }
}