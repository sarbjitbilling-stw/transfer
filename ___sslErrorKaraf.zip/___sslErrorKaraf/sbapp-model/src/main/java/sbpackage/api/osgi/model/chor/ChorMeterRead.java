package sbpackage.api.osgi.model.chor;

/**
 * Created by tellis3 on 15/05/2017.
 */
public class ChorMeterRead {

    private long equipmentNumber;
    private long meterRegisterNumber;
    private String reading;
    private boolean preValidationCheckFailed;
    private boolean overrideValidation;

    public long getEquipmentNumber() {
        return equipmentNumber;
    }

    public void setEquipmentNumber(long equipmentNumber) {
        this.equipmentNumber = equipmentNumber;
    }

    public long getMeterRegisterNumber() {
        return meterRegisterNumber;
    }

    public void setMeterRegisterNumber(long meterRegisterNumber) {
        this.meterRegisterNumber = meterRegisterNumber;
    }

    public String getReading() {
        return reading;
    }

    public void setReading(String reading) {
        this.reading = reading;
    }

    public boolean isPreValidationCheckFailed() {
        return preValidationCheckFailed;
    }

    public void setPreValidationCheckFailed(boolean preValidationCheckFailed) {
        this.preValidationCheckFailed = preValidationCheckFailed;
    }

    public boolean isOverrideValidation() {
        return overrideValidation;
    }

    public void setOverrideValidation(boolean overrideValidation) {
        this.overrideValidation = overrideValidation;
    }
}
