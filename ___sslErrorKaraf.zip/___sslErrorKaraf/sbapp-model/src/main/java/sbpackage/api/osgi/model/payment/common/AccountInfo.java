package sbpackage.api.osgi.model.payment.common;

import sbpackage.api.osgi.model.Address;

import java.math.BigDecimal;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

/**
 * Created by rtai on 23/10/2017.
 */
public interface AccountInfo {

    TargetAccountNumber getAccountNumber();

    BigDecimal getAccountBalance();

    Address getAddress();
    
    boolean isFutureStartPlan();
}
