package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ErrorMessage implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@XmlElement(required=true)
	private final String code;

	@XmlElement(required=true)
	private final String message;
	
	public ErrorMessage() {
		this.code = "default";
		this.message = "default";
	}
	
	public ErrorMessage(String code, String message) {
		this.code = code;
		this.message = message;
	}
	
	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

}
