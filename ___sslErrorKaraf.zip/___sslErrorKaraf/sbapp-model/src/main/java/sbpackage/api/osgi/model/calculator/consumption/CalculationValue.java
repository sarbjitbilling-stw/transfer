package sbpackage.api.osgi.model.calculator.consumption;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties( { "consumption" })
public class CalculationValue implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String service;
	private double value;
    @JsonIgnore
    private double consumption;
    private double costPerUnit;
    private double propertyTypeAddition;

	public CalculationValue() {}
	
	public CalculationValue(String service, double value) {
		this.service = service;
		this.value = value;
	}
	
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}

	@JsonIgnore
    public double getConsumption() {
        return consumption;
    }

    public void setConsumption(double consumption) {
        this.consumption = consumption;
    }

    public double getCostPerUnit() {
        return costPerUnit;
    }

    public void setCostPerUnit(double costPerUnit) {
        this.costPerUnit = costPerUnit;
    }

    public double getPropertyTypeAddition() {
        return propertyTypeAddition;
    }

    public void setPropertyTypeAddition(double propertyTypeAddition) {
        this.propertyTypeAddition = propertyTypeAddition;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("CalculationValue [");
		builder.append("service=");
		builder.append(service);
		builder.append("value=");
		builder.append(value);
		builder.append("consumption=");
		builder.append(consumption);
		builder.append("costPerUnit=");
		builder.append(costPerUnit);
		builder.append("propertyTypeAddition=");
		builder.append(propertyTypeAddition);
		builder.append("]");
		return builder.toString();
	}
    
    
}
