package sbpackage.api.osgi.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Brand")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Brand implements Serializable{

	private static final long serialVersionUID = -2233399527553103960L;
	
	@JsonProperty("accountBrand")
	private AccountBrand accountBrand;

	public AccountBrand getAccountBrand() {
		return accountBrand;
	}

	public void setAccountBrand(AccountBrand brand) {
		this.accountBrand = brand;
	}
	
	public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Brand {\n");
        sb.append("    brand: ").append(toIndentedString(accountBrand)).append("\n");
        return sb.toString();
	}
	
	 /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private static String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}
