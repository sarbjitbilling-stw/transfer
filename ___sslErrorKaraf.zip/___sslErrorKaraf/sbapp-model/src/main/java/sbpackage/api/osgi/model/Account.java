package sbpackage.api.osgi.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import java.time.LocalDate;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import sbpackage.api.osgi.model.util.DateAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Account")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Account implements Serializable {

    public static final String MIGRATED = "M";
    public static final String WRITTEN_OFF = "W";
    public static final String ACTIVE = "A";
    public static final String FINAL_BILLED = "F";
    public static final String TO_BE_FINAL_BILLED = "T";

    @JsonProperty("accountNumber")
    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @JsonProperty("accountStatus")
    @XmlElement(name = "accountStatus")
    private String accountStatus;

    @JsonProperty("accountBalance")
    @XmlElement(name = "accountBalance")
    private BigDecimal accountBalance;

    @JsonProperty("lastInvoiceIssueDate")
    @XmlElement(name = "lastInvoiceIssueDate")
    private Date lastInvoiceIssueDate;

    @JsonProperty("lastInvoiceAmount")
    @XmlElement(name = "lastInvoiceAmount")
    private BigDecimal lastInvoiceAmount;

    @JsonProperty("lastInvoiceDueDate")
    @XmlElement(name = "lastInvoiceDueDate")
    private Date lastInvoiceDueDate;

    @JsonProperty("lastPayDate")
    @XmlElement(name = "lastPayDate")
    private Date lastPayDate;

    @JsonProperty("lastPaymentAmount")
    @XmlElement(name = "lastPaymentAmount")
    private BigDecimal lastPaymentAmount;

    @JsonProperty("currentAmountDue")
    @XmlElement(name = "currentAmountDue")
    private BigDecimal currentAmountDue;

    @JsonProperty("wssPaperlessBillFlag")
    @XmlElement(name = "wssPaperlessBillFlag")
    private String wssPaperlessBillFlag;

    @JsonProperty("hasAmiMeterFlag")
    @XmlElement(name = "hasAmiMeterFlag")
    private boolean hasAmiMeterFlag;

    @JsonProperty("leRegistrationData")
    @XmlElement(name = "leRegistrationData")
    private WSSLERegistrationData leRegistrationData;

    @JsonProperty("payPlanNum")
    @XmlElement(name = "payPlanNum")
    private Long payPlanNum;

    @JsonProperty("payArrOnPlan")
    @XmlElement(name = "payArrOnPlan")
    private String payArrOnPlan;

    @JsonProperty("payArrOnDemand")
    @XmlElement(name = "payArrOnDemand")
    private String payArrOnDemand;

    @XmlElement(name = "paymentPlanIndicator")
    @JsonProperty("paymentPlanIndicator")
    private String paymentPlanIndicator;

    @XmlElement(name = "EquipNum")
    @JsonProperty("equipNum")
    private Long equipNum;

    @JsonProperty("multEquipInd")
    @XmlElement(name = "multEquipInd")
    private String multEquipInd;

    @JsonProperty("leType")
    @XmlElement(name = "leType")
    private String leType;

    @JsonProperty("propertyNum")
    @XmlElement(name = "propertyNum")
    private Long propertyNum;

    @JsonProperty("servAddress")
    @XmlElement(name = "servAddress")
    private String servAddress;

    @JsonProperty("multPropInd")
    @XmlElement(name = "multPropInd")
    private String multPropInd;

    @JsonProperty("custAcctRoleType")
    @XmlElement(name = "custAcctRoleType")
    private String custAcctRoleType;

    @JsonProperty("custAcctRoleDescription")
    @XmlElement(name = "custAcctRoleDescription")
    private String custAcctRoleDescription;

    @JsonProperty("conditionalPayPlanFlag")
    @XmlElement(name = "conditionalPayPlanFlag")
    private String conditionalPayPlanFlag;

    @JsonProperty("specCondAlertFlag")
    @XmlElement(name = "specCondAlertFlag")
    private String specCondAlertFlag;

    @JsonProperty("outstandingAQFlag")
    @XmlElement(name = "outstandingAQFlag")
    private boolean outstandingAQFlag;

    @JsonProperty("outstandingAQOrg")
    @XmlElement(name = "outstandingAQOrg")
    private Long outstandingAQOrg;

    @JsonProperty("networkSpecCondFlag")
    @XmlElement(name = "networkSpecCondFlag")
    private String networkSpecCondFlag;

    @JsonProperty("busDirectSpecCondFlag")
    @XmlElement(name = "busDirectSpecCondFlag")
    private String busDirectSpecCondFlag;

    @JsonProperty("carmsPreClaimFlag")
    @XmlElement(name = "carmsPreClaimFlag")
    private String carmsPreClaimFlag;

    @JsonProperty("carmsPostClaimFlag")
    @XmlElement(name = "carmsPostClaimFlag")
    private String carmsPostClaimFlag;

    @JsonProperty("carmsPostJudgmentFlag")
    @XmlElement(name = "carmsPostJudgmentFlag")
    private String carmsPostJudgmentFlag;

    @JsonProperty("maxDefaultedPlansFlag")
    @XmlElement(name = "maxDefaultedPlansFlag")
    private String maxDefaultedPlansFlag;

    @JsonProperty("billPrintMedium")
    @XmlElement(name = "billPrintMedium")
    private String billPrintMedium;

    @JsonProperty("supplyAddress")
    @XmlElement(name = "supplyAddress")
    private Address supplyAddress;

    @JsonProperty("mailingAddress")
    @XmlElement(name = "mailingAddress")
    private Address mailingAddress;

    @JsonProperty("isBusinessLE")
    @XmlElement(name = "isBusinessLE")
    private boolean isBusinessLE;

    @XmlElement(name = "demandDirectDebit")
    @JsonProperty("demandDirectDebit")
    private boolean demandDirectDebit;

    @JsonProperty("accountRoles")
    @XmlElement(name = "accountRoles")
    private List<AccountRoles> accountRoles;

    @XmlElement
    @JsonProperty("accountStartDate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    private LocalDate accountStartDate;
    
    @XmlElement(name = "supplyStatus")
    @JsonProperty("supplyStatus")
    private Property.SupplyStatus supplyStatus;

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;

    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }

    public Date getLastInvoiceIssueDate() {
        return lastInvoiceIssueDate;
    }

    public void setLastInvoiceIssueDate(Date lastInvoiceIssueDate) {
        this.lastInvoiceIssueDate = lastInvoiceIssueDate;
    }

    public Date getLastInvoiceDueDate() {
        return lastInvoiceDueDate;
    }

    public void setLastInvoiceDueDate(Date lastInvoiceDueDate) {
        this.lastInvoiceDueDate = lastInvoiceDueDate;
    }

    public Date getLastPayDate() {
        return lastPayDate;
    }

    public void setLastPayDate(Date lastPayDate) {
        this.lastPayDate = lastPayDate;
    }

    public String getWssPaperlessBillFlag() {
        return wssPaperlessBillFlag;
    }

    public boolean getHasAmiMeterFlag() {
        return hasAmiMeterFlag;
    }

    public void setHasAmiMeterFlag(boolean hasAmiMeterFlag) {
        this.hasAmiMeterFlag = hasAmiMeterFlag;
    }

    public void setWssPaperlessBillFlag(String wssPaperlessBillFlag) {
        this.wssPaperlessBillFlag = wssPaperlessBillFlag;
    }

    public WSSLERegistrationData getLeRegistrationData() {
        return leRegistrationData;
    }

    public void setLeRegistrationData(WSSLERegistrationData leRegistrationData) {
        this.leRegistrationData = leRegistrationData;
    }

    public Long getPayPlanNum() {
        return payPlanNum;
    }

    public void setPayPlanNum(Long payPlanNum) {
        this.payPlanNum = payPlanNum;
    }

    public String getPayArrOnPlan() {
        return payArrOnPlan;
    }

    public void setPayArrOnPlan(String payArrOnPlan) {
        this.payArrOnPlan = payArrOnPlan;
    }

    public String getPayArrOnDemand() {
        return payArrOnDemand;
    }

    public void setPayArrOnDemand(String payArrOnDemand) {
        this.payArrOnDemand = payArrOnDemand;
    }

    public Long getEquipNum() {
        return equipNum;
    }

    public void setEquipNum(Long equipNum) {
        this.equipNum = equipNum;
    }

    public String getMultEquipInd() {
        return multEquipInd;
    }

    public void setMultEquipInd(String multEquipInd) {
        this.multEquipInd = multEquipInd;
    }

    public String getLeType() {
        return leType;
    }

    public void setLeType(String leType) {
        this.leType = leType;
    }

    public Long getPropertyNum() {
        return propertyNum;
    }

    public void setPropertyNum(Long propertyNum) {
        this.propertyNum = propertyNum;
    }

    public String getServAddress() {
        return servAddress;
    }

    public void setServAddress(String servAddress) {
        this.servAddress = servAddress;
    }

    public String getMultPropInd() {
        return multPropInd;
    }

    public void setMultPropInd(String multPropInd) {
        this.multPropInd = multPropInd;
    }

    public String getCustAcctRoleType() {
        return custAcctRoleType;
    }

    public void setCustAcctRoleType(String custAcctRoleType) {
        this.custAcctRoleType = custAcctRoleType;
    }

    public String getCustAcctRoleDescription() {
        return custAcctRoleDescription;
    }

    public void setCustAcctRoleDescription(String custAcctRoleDescription) {
        this.custAcctRoleDescription = custAcctRoleDescription;
    }

    public String getConditionalPayPlanFlag() {
        return conditionalPayPlanFlag;
    }

    public void setConditionalPayPlanFlag(String conditionalPayPlanFlag) {
        this.conditionalPayPlanFlag = conditionalPayPlanFlag;
    }

    public String getSpecCondAlertFlag() {
        return specCondAlertFlag;
    }

    public void setSpecCondAlertFlag(String specCondAlertFlag) {
        this.specCondAlertFlag = specCondAlertFlag;
    }


    public boolean isOutstandingAQFlag() {
        return outstandingAQFlag;
    }

    public void setOutstandingAQFlag(boolean outstandingAQFlag) {
        this.outstandingAQFlag = outstandingAQFlag;
    }

    public Long getOutstandingAQOrg() {
        return outstandingAQOrg;
    }

    public void setOutstandingAQOrg(Long outstandingAQOrg) {
        this.outstandingAQOrg = outstandingAQOrg;
    }

    public String getNetworkSpecCondFlag() {
        return networkSpecCondFlag;
    }

    public void setNetworkSpecCondFlag(String networkSpecCondFlag) {
        this.networkSpecCondFlag = networkSpecCondFlag;
    }

    public String getBusDirectSpecCondFlag() {
        return busDirectSpecCondFlag;
    }

    public void setBusDirectSpecCondFlag(String busDirectSpecCondFlag) {
        this.busDirectSpecCondFlag = busDirectSpecCondFlag;
    }

    public String getCarmsPreClaimFlag() {
        return carmsPreClaimFlag;
    }

    public void setCarmsPreClaimFlag(String carmsPreClaimFlag) {
        this.carmsPreClaimFlag = carmsPreClaimFlag;
    }

    public boolean getCarmsPostClaimFlag() {
        return Boolean.parseBoolean(carmsPostClaimFlag);
    }

    public void setCarmsPostClaimFlag(String carmsPostClaimFlag) {
        this.carmsPostClaimFlag = carmsPostClaimFlag;
    }

    public boolean getCarmsPostJudgmentFlag() {
        return Boolean.parseBoolean(carmsPostJudgmentFlag);
    }

    public void setCarmsPostJudgmentFlag(String carmsPostJudgmentFlag) {
        this.carmsPostJudgmentFlag = carmsPostJudgmentFlag;
    }

    public String getMaxDefaultedPlansFlag() {
        return maxDefaultedPlansFlag;
    }

    public void setMaxDefaultedPlansFlag(String maxDefaultedPlansFlag) {
        this.maxDefaultedPlansFlag = maxDefaultedPlansFlag;
    }

    public String getBillPrintMedium() {
        return billPrintMedium;
    }

    public void setBillPrintMedium(String billPrintMedium) {
        this.billPrintMedium = billPrintMedium;
    }

    public boolean isBusinessLE() {
        return isBusinessLE;
    }

    public void setBusinessLE(boolean isBusinessLE) {
        this.isBusinessLE = isBusinessLE;
    }

    public String getPaymentPlanIndicator() {
        return paymentPlanIndicator;
    }

    public void setPaymentPlanIndicator(String paymentPlanIndicator) {
        this.paymentPlanIndicator = paymentPlanIndicator;
    }

    public Address getSupplyAddress() {
        return supplyAddress;
    }

    public void setSupplyAddress(Address supplyAddress) {
        this.supplyAddress = supplyAddress;
    }

    public Address getMailingAddress() {
        return mailingAddress;
    }

    public void setMailingAddress(Address mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    public boolean isDemandDirectDebit() {
        return demandDirectDebit;
    }

    public void setDemandDirectDebit(boolean demandDirectDebit) {
        this.demandDirectDebit = demandDirectDebit;
    }

    public BigDecimal getLastInvoiceAmount() {
        return lastInvoiceAmount;
    }

    public void setLastInvoiceAmount(BigDecimal lastInvoiceAmount) {
        this.lastInvoiceAmount = lastInvoiceAmount;
    }

    public BigDecimal getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    public void setLastPaymentAmount(BigDecimal lastPaymentAmount) {
        this.lastPaymentAmount = lastPaymentAmount;
    }

    public BigDecimal getCurrentAmountDue() {
        return currentAmountDue;
    }

    public void setCurrentAmountDue(BigDecimal currentAmountDue) {
        this.currentAmountDue = currentAmountDue;
    }

    public List<AccountRoles> getAccountRoles() {
        return accountRoles;
    }

    public void setAccountRoles(List<AccountRoles> accountRoles) {
        this.accountRoles = accountRoles;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public LocalDate getAccountStartDate() {
        return accountStartDate;
    }

    public void setAccountStartDate(LocalDate accountStartDate) {
        this.accountStartDate = accountStartDate;
    }

    public Property.SupplyStatus getSupplyStatus() {
        return supplyStatus;
    }

    public void setSupplyStatus(Property.SupplyStatus supplyStatus) {
        this.supplyStatus = supplyStatus;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Account {\n");

        sb.append("    accountStatus: ").append(toIndentedString(accountStatus)).append("\n");
        sb.append("    accountBalance: ").append(toIndentedString(accountBalance)).append("\n");
        sb.append("    lastInvoiceIssueDate: ").append(toIndentedString(lastInvoiceIssueDate)).append("\n");
        sb.append("    lastInvoiceAmount: ").append(toIndentedString(lastInvoiceAmount)).append("\n");
        sb.append("    lastInvoiceDueDate: ").append(toIndentedString(lastInvoiceDueDate)).append("\n");
        sb.append("    lastPaymentAmount: ").append(toIndentedString(lastPaymentAmount)).append("\n");
        sb.append("    currentAmountDue: ").append(toIndentedString(currentAmountDue)).append("\n");
        sb.append("    wssPaperlessBillFlag: ").append(toIndentedString(wssPaperlessBillFlag)).append("\n");
        sb.append("    hasAmiMeterFlag: ").append(toIndentedString(hasAmiMeterFlag)).append("\n");
        sb.append("    payPlanNum: ").append(toIndentedString(payPlanNum)).append("\n");
        sb.append("    payArrOnPlan: ").append(toIndentedString(payArrOnPlan)).append("\n");
        sb.append("    payArrOnDemand: ").append(toIndentedString(payArrOnDemand)).append("\n");
        sb.append("    equipNum: ").append(toIndentedString(equipNum)).append("\n");
        sb.append("    multEquipInd: ").append(toIndentedString(multEquipInd)).append("\n");
        sb.append("    leType: ").append(toIndentedString(leType)).append("\n");
        sb.append("    propertyNum: ").append(toIndentedString(propertyNum)).append("\n");
        sb.append("    servAddress: ").append(toIndentedString(servAddress)).append("\n");
        sb.append("    multPropInd: ").append(toIndentedString(multPropInd)).append("\n");
        sb.append("    custAcctRoleType: ").append(toIndentedString(custAcctRoleType)).append("\n");
        sb.append("    custAcctRoleDescription: ").append(toIndentedString(custAcctRoleDescription)).append("\n");
        sb.append("    conditionalPayPlanFlag: ").append(toIndentedString(conditionalPayPlanFlag)).append("\n");
        sb.append("    specCondAlertFlag: ").append(toIndentedString(specCondAlertFlag)).append("\n");
        sb.append("    outstandingAQFlag: ").append(toIndentedString(outstandingAQFlag)).append("\n");
        sb.append("    outstandingAQOrg: ").append(toIndentedString(outstandingAQOrg)).append("\n");
        sb.append("    networkSpecCondFlag: ").append(toIndentedString(networkSpecCondFlag)).append("\n");
        sb.append("    busDirectSpecCondFlag: ").append(toIndentedString(busDirectSpecCondFlag)).append("\n");
        sb.append("    carmsPreClaimFlag: ").append(toIndentedString(carmsPreClaimFlag)).append("\n");
        sb.append("    carmsPostClaimFlag: ").append(toIndentedString(carmsPostClaimFlag)).append("\n");
        sb.append("    carmsPostJudgmentFlag: ").append(toIndentedString(carmsPostJudgmentFlag)).append("\n");
        sb.append("    maxDefaultedPlansFlag: ").append(toIndentedString(maxDefaultedPlansFlag)).append("\n");
        sb.append("    billPrintMedium: ").append(toIndentedString(billPrintMedium)).append("\n");
        sb.append("    paymentPlanIndicator: ").append(toIndentedString(paymentPlanIndicator)).append("\n");
        sb.append("    demandDirectDebit: ").append(toIndentedString(demandDirectDebit)).append("\n");
        sb.append("    accountRoles: ").append(toIndentedString(accountRoles)).append("\n");
        sb.append("    accountStartDate: ").append(toIndentedString(accountStartDate)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private static String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}
