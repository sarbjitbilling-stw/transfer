package sbpackage.api.osgi.model.healthcheck;

import lombok.Data;

@Data
public class VersionDetails {
    private String version;
    private GitDetails git;
}
