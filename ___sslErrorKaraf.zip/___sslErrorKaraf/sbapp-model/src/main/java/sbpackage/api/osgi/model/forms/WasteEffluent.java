package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class WasteEffluent extends Selection {

    private float tradeEffluentVolume;
    private float averageDailyUsage;
    private String effluentComposition;


    public float getTradeEffluentVolume() {
        return tradeEffluentVolume;
    }

    public void setTradeEffluentVolume(float tradeEffluentVolume) {
        this.tradeEffluentVolume = tradeEffluentVolume;
    }

    public float getAverageDailyUsage() {
        return averageDailyUsage;
    }

    public void setAverageDailyUsage(float averageDailyUsage) {
        this.averageDailyUsage = averageDailyUsage;
    }

    public String getEffluentComposition() {
        return effluentComposition;
    }

    public void setEffluentComposition(String effluentComposition) {
        this.effluentComposition = effluentComposition;
    }
}
