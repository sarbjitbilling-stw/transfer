package sbpackage.api.osgi.model.payment.directdebit;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * Created by rtai on 28/06/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankDetails implements Serializable {


    @XmlElement
    private String accountHolderName;

    @XmlElement
    private String bankName;

    @XmlElement
    private String bankAccountNumber;

    @XmlElement
    private String sortCode;

    @XmlElement
    private String branchName;

    @XmlElement
    private String branchAddress;
    
    @XmlElement
    private String bankDetailsPublicKey;

    @XmlElement
    private boolean usePreviousBankDetails;

    @XmlElement
    private String bankNumber;

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public String getSortCode() {
        return sortCode;
    }

    public void setSortCode(String sortCode) {
        this.sortCode = sortCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getBranchAddress() {
        return branchAddress;
    }

    public void setBranchAddress(String branchAddress) {
        this.branchAddress = branchAddress;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber;
    }

    public String getBankDetailsPublicKey() {
        return bankDetailsPublicKey;
    }

    public void setBankDetailsPublicKey(String bankDetailsPublicKey) {
        this.bankDetailsPublicKey = bankDetailsPublicKey;
    }

    public boolean usePreviousBankDetails() {
        return usePreviousBankDetails;
    }

    public void setUsePreviousBankDetails(boolean usePreviousBankDetails) {
        this.usePreviousBankDetails = usePreviousBankDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        BankDetails that = (BankDetails) o;

        return new EqualsBuilder()
                .append(accountHolderName, that.accountHolderName)
                .append(bankName, that.bankName)
                .append(bankAccountNumber, that.bankAccountNumber)
                .append(sortCode, that.sortCode)
                .append(branchName, that.branchName)
                .append(branchAddress, that.branchAddress)
                .append(bankNumber, that.bankNumber)
                .append(bankDetailsPublicKey, that.bankDetailsPublicKey)
                .append(usePreviousBankDetails, that.usePreviousBankDetails)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(accountHolderName)
                .append(bankName)
                .append(bankAccountNumber)
                .append(sortCode)
                .append(branchName)
                .append(branchAddress)
                .append(bankNumber)
                .append(bankDetailsPublicKey)
                .append(usePreviousBankDetails)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountHolderName", accountHolderName)
                .append("bankName", bankName)
                .append("bankAccountNumber", bankAccountNumber)
                .append("sortCode", sortCode)
                .append("branchName", branchName)
                .append("branchAddress", branchAddress)
                .append("bankNumber", bankNumber)
                .append("bankDetailsPublicKey", bankDetailsPublicKey)
                .append("usePreviousBankDetails", usePreviousBankDetails)
                .toString();
    }

}
