package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlRootElement
public interface SurveyQuestion {

    int getValue();
}
