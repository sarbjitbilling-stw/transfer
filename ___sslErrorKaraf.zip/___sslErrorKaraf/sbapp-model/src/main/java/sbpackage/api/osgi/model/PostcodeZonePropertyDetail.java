/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author zphili1
 */
@XmlRootElement(name = "PostcodeZoneProperty")
@XmlAccessorType(XmlAccessType.FIELD)
public class PostcodeZonePropertyDetail {
    @XmlElement(name = "postcode")
    private String postcode;
    @XmlElement(name = "zone")
    private String zone;

    @XmlElement(name = "properties")
    private List<String> properties;

    public PostcodeZonePropertyDetail() {
    }

    public PostcodeZonePropertyDetail(String postcode) {
        this.postcode = postcode;
    }


    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public List<String> getProperties(){
        return properties;
    }

    public void setProperties(List<String> properties){
        this.properties = properties;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.postcode);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PostcodeZonePropertyDetail other = (PostcodeZonePropertyDetail) obj;
        if (!Objects.equals(this.postcode, other.postcode)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "PostcodeZonePropertyDetail{" + "postcode=" + postcode + ", zone=" + zone + '}';
    }
    
 }
