package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SiteAdjacentProposal {

    private boolean siteIsAdjacentProposal;
    private String siteIsAdjacentProposalDetails;
    private String siteIsAdjacentProposalDisplayValue;

    public boolean isSiteIsAdjacentProposal() {
        return siteIsAdjacentProposal;
    }

    public void setSiteIsAdjacentProposal(boolean siteIsAdjacentProposal) {
        this.siteIsAdjacentProposal = siteIsAdjacentProposal;
    }

    public String getSiteIsAdjacentProposalDetails() {
        return siteIsAdjacentProposalDetails;
    }

    public void setSiteIsAdjacentProposalDetails(String siteIsAdjacentProposalDetails) {
        this.siteIsAdjacentProposalDetails = siteIsAdjacentProposalDetails;
    }

    public String getSiteIsAdjacentProposalDisplayValue() {
        return siteIsAdjacentProposalDisplayValue;
    }

    public void setSiteIsAdjacentProposalDisplayValue(String siteIsAdjacentProposalDisplayValue) {
        this.siteIsAdjacentProposalDisplayValue = siteIsAdjacentProposalDisplayValue;
    }
}
