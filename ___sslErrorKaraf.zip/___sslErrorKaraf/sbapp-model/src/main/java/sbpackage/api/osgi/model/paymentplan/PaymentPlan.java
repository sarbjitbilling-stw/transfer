package sbpackage.api.osgi.model.paymentplan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;


@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlan implements Serializable {

	@XmlElement(name = "planNumber")
	@JsonProperty(value = "planNumber")
	private Long planNumber;

	@XmlElement(name = "accountNumber")
	@JsonProperty(value = "accountNumber")
	private Long accountNumber;

	@XmlElement(name = "facility")
	@JsonProperty(value = "facility")
	private Facility facility;

	@XmlElement(name = "employeeNumber")
	@JsonProperty(value = "employeeNumber")
	private Long employeeNumber;

	@XmlElement(name = "planType")
	@JsonProperty(value = "planType")
	private PlanType planType;

	@XmlElement(name = "budgetType")
	@JsonProperty(value = "budgetType")
	private BudgetType budgetType;

	@XmlElement(name = "paymentNumberExpected")
	@JsonProperty(value = "paymentNumberExpected")
	private Long paymentNumberExpected;

	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate nextInstallmentDate;

	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate nextReconciliationDate;

	@XmlElement(name = "installmentNumber")
	@JsonProperty(value = "installmentNumber")
	private Long installmentNumber;

	@XmlElement(name = "totalBudgetAmount")
	@JsonProperty(value = "totalBudgetAmount")
	private BigDecimal totalBudgetAmount;

	@XmlElement(name = "overflowInstanceNumber")
	@JsonProperty(value = "overflowInstanceNumber")
	private Long overflowInstanceNumber;

	@XmlElement(name = "firstPaymentAmount")
	@JsonProperty(value = "firstPaymentAmount")
    private BigDecimal firstPaymentAmount;

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate startDate;

	@XmlElement(name = "normalPaymentAmount")
	@JsonProperty(value = "normalPaymentAmount")
    private BigDecimal normalPaymentAmount;

	@XmlElement(name = "installmentAmount")
	@JsonProperty(value = "installmentAmount")
    private BigDecimal installmentAmount;

	@XmlElement(name = "planItems")
	@JsonProperty(value = "planItems")
	private List<PaymentPlanItem> payPlanItems;

    @XmlElement(name = "schedule")
	@JsonProperty(value = "schedule")
    private List<ScheduledPayment> schedule;

	public Long getPlanNumber() {
		return planNumber;
	}

	public void setPlanNumber(Long planNumber) {
		this.planNumber = planNumber;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Facility getFacility() {
		return facility;
	}

	public void setFacility(Facility facility) {
		this.facility = facility;
	}

	public Long getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Long employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public PlanType getPlanType() {
		return planType;
	}

	public void setPlanType(PlanType planType) {
		this.planType = planType;
	}

	public BudgetType getBudgetType() {
		return budgetType;
	}

	public void setBudgetType(BudgetType budgetType) {
		this.budgetType = budgetType;
	}

	public Long getPaymentNumberExpected() {
		return paymentNumberExpected;
	}

	public void setPaymentNumberExpected(Long paymentNumberExpected) {
		this.paymentNumberExpected = paymentNumberExpected;
	}

	public LocalDate getNextInstallmentDate() {
		return nextInstallmentDate;
	}

	public void setNextInstallmentDate(LocalDate nextInstallmentDate) {
		this.nextInstallmentDate = nextInstallmentDate;
	}

	public LocalDate getNextReconciliationDate() {
		return nextReconciliationDate;
	}

	public void setNextReconciliationDate(LocalDate nextReconciliationDate) {
		this.nextReconciliationDate = nextReconciliationDate;
	}

	public Long getInstallmentNumber() {
		return installmentNumber;
	}

	public void setInstallmentNumber(Long installmentNumber) {
		this.installmentNumber = installmentNumber;
	}

	public BigDecimal getTotalBudgetAmount() {
		return totalBudgetAmount;
	}

	public void setTotalBudgetAmount(BigDecimal totalBudgetAmount) {
		this.totalBudgetAmount = totalBudgetAmount;
	}

	public Long getOverflowInstanceNumber() {
		return overflowInstanceNumber;
	}

	public void setOverflowInstanceNumber(Long overflowInstanceNumber) {
		this.overflowInstanceNumber = overflowInstanceNumber;
	}

	public List<PaymentPlanItem> getPayPlanItems() {
		return payPlanItems;
	}

	public void setPayPlanItems(List<PaymentPlanItem> payPlanItems) {
		this.payPlanItems = payPlanItems;
	}

    public BigDecimal getFirstPaymentAmount() {
        return firstPaymentAmount;
    }

    public void setFirstPaymentAmount(BigDecimal firstPaymentAmount) {
        this.firstPaymentAmount = firstPaymentAmount;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getNormalPaymentAmount() {
        return normalPaymentAmount;
    }

    public void setNormalPaymentAmount(BigDecimal normalPaymentAmount) {
        this.normalPaymentAmount = normalPaymentAmount;
    }

    public BigDecimal getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(BigDecimal installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

    public List<ScheduledPayment> getSchedule() {
        return schedule;
    }

    public void setSchedule(List<ScheduledPayment> schedule) {
        this.schedule = schedule;
    }

    @Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		PaymentPlan plan = (PaymentPlan) o;

		return new EqualsBuilder()
				.append(planNumber, plan.planNumber)
				.append(accountNumber, plan.accountNumber)
				.append(employeeNumber, plan.employeeNumber)
				.append(planType, plan.planType)
				.append(budgetType, plan.budgetType)
				.append(paymentNumberExpected, plan.paymentNumberExpected)
				.append(nextInstallmentDate, plan.nextInstallmentDate)
				.append(nextReconciliationDate, plan.nextReconciliationDate)
				.append(installmentNumber, plan.installmentNumber)
				.append(totalBudgetAmount, plan.totalBudgetAmount)
				.append(overflowInstanceNumber, plan.overflowInstanceNumber)
				.append(payPlanItems, plan.payPlanItems)
                .append(firstPaymentAmount, plan.firstPaymentAmount)
                .append(startDate, plan.startDate)
                .append(normalPaymentAmount, plan.normalPaymentAmount)
                .append(installmentAmount, plan.installmentAmount)
                .append(schedule, plan.schedule)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(planNumber)
				.append(accountNumber)
				.append(employeeNumber)
				.append(planType)
				.append(budgetType)
				.append(paymentNumberExpected)
				.append(nextInstallmentDate)
				.append(nextReconciliationDate)
				.append(installmentNumber)
				.append(totalBudgetAmount)
				.append(overflowInstanceNumber)
				.append(payPlanItems)
                .append(firstPaymentAmount)
                .append(startDate)
                .append(normalPaymentAmount)
                .append(installmentAmount)
                .append(schedule)
				.toHashCode();
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this)
				.append("planNumber", planNumber)
				.append("accountNumber", accountNumber)
				.append("employeeNumber", employeeNumber)
				.append("planType", planType)
				.append("budgetType", budgetType)
				.append("paymentNumberExpected", paymentNumberExpected)
				.append("nextInstallmentDate", nextInstallmentDate)
				.append("nextReconciliationDate", nextReconciliationDate)
				.append("installmentNumber", installmentNumber)
				.append("totalBudgetAmount", totalBudgetAmount)
				.append("overflowInstanceNumber", overflowInstanceNumber)
				.append("payPlanItems", payPlanItems)
                .append("firstPaymentAmount", firstPaymentAmount)
                .append("startDate", startDate)
                .append("normalPaymentAmount", normalPaymentAmount)
                .append("installmentAmount", installmentAmount)
                .append("schedule",schedule)
				.toString();
	}

	public enum Facility {
        BOOKLET_PAYMENT_FACILITY("B"), CASH_PAYMENT_FACILITY("C"), DIRECT_DEBIT_PAYMENT_FACILITY("D"), WATERCARD_PAYMENT_FACILITY("PP"), 
        VIA_BANK_PAYMENT_FACILITY("VB"), RECURRING_CREDIT_DEBIT_CARD_PAYMENT_FACILITY("RC"), PINGIT_PAYMENT_FACILITY("PI"), 
        CREDIT_DEBIT_CARD_PAYMENT_FACILITY("CD");
        private String facility;
        Facility(String facility) {
            this.facility = facility;
        }
        public String getValue() {
            return facility;
        }
        
        public static Facility getByValue(String val){
        	if(val != null){
	        	Facility[] facilities = Facility.values();
	        	for(int i=0; i<facilities.length; i++){
	        		if(facilities[i].getValue().equals(val)){
	        			return facilities[i];
	        		}
	        	}
        	}
        	return null;
        }
    }
	
	public enum PlanType {
		ARREARS, DEPOSIT, MERCHANDISE, NONE, THIRD_PARTY
	}

	public enum BudgetType {
		COMBINATION, EQUALIZED, NONE, PPC, UNMEASURED
	}
}
