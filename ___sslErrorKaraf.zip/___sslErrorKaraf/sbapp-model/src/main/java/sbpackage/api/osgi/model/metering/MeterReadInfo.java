package sbpackage.api.osgi.model.metering;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.common.ContactDto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "MeterReadInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class MeterReadInfo {

    @XmlElement(name = "meter")
    private Meter meter;

    @XmlElement(name = "meterReadDetail")
    private MeterReadDetail meterReadDetail;
    
    @XmlElement(name = "leTitle")
    private String leTitle = null;
    
    @XmlElement(name = "leFirstName")
    private String leFirstName = null;
    
    @XmlElement(name = "leMiddleIntial")
    private String leMiddleIntial = null;
    
    @XmlElement(name = "leSurname")
    private String leSurname = null;
    
    @XmlElement(name = "leIndicator")
    private String leIndicator = null;
    
    @XmlElement(name = "leNum")
    private Long leNum = null;

    @XmlElement(name = "contact")
    private ContactDto contactDto;

    @XmlElement(name = "guest")
    private boolean guest;

    public Meter getMeter() {
        return meter;
    }

    public void setMeter(Meter meter) {
        this.meter = meter;
    }

    public MeterReadDetail getMeterReadDetail() {
        return meterReadDetail;
    }

    public void setMeterReadDetail(MeterReadDetail meterReadDetail) {
        this.meterReadDetail = meterReadDetail;
    }
    
    public String getLeTitle() {
		return leTitle;
	}

	public void setLeTitle(String leTitle) {
		this.leTitle = leTitle;
	}

	public String getLeFirstName() {
		return leFirstName;
	}

	public void setLeFirstName(String leFirstName) {
		this.leFirstName = leFirstName;
	}

	public String getLeMiddleIntial() {
		return leMiddleIntial;
	}

	public void setLeMiddleIntial(String leMiddleIntial) {
		this.leMiddleIntial = leMiddleIntial;
	}

	public String getLeSurname() {
		return leSurname;
	}

	public void setLeSurname(String leSurname) {
		this.leSurname = leSurname;
	}

	public String getLeIndicator() {
		return leIndicator;
	}

	public void setLeIndicator(String leIndicator) {
		this.leIndicator = leIndicator;
	}

	public Long getLeNum() {
		return leNum;
	}

	public void setLeNum(Long leNum) {
		this.leNum = leNum;
	}

    public ContactDto getContactDto() {
        return contactDto;
    }

    public void setContactDto(ContactDto contactDto) {
        this.contactDto = contactDto;
    }

    public boolean isGuest() {
        return guest;
    }

    public void setGuest(boolean guest) {
        this.guest = guest;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("meter", meter)
                .append("meterReadDetail", meterReadDetail)
                .append("leTitle", leTitle)
                .append("leFirstName", leFirstName)
                .append("leMiddleIntial", leMiddleIntial)
                .append("leSurname", leSurname)
                .append("leIndicator", leIndicator)
                .append("leNum", leNum)
                .append("contactDto", contactDto)
                .append("guest", guest)
                .toString();
    }
}
