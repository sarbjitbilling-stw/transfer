package sbpackage.api.osgi.model.payment.directdebit;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Created by DA on 13/12/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserCanCreateDirectDebitPlan {

    @XmlElement(name = "allowDirectDebitPlans")
    private Boolean allowDirectDebitPlans;

    @XmlElement(name = "displayMessage")
    private String displayMessage;

    public Boolean getAllowDirectDebitPlans() {
        return allowDirectDebitPlans;
    }

    public void setAllowDirectDebitPlans(Boolean allowDirectDebitPlans) {
        this.allowDirectDebitPlans = allowDirectDebitPlans;
    }

    public String getDisplayMessage() {
        return displayMessage;
    }

    public void setDisplayMessage(String displayMessage) {
        this.displayMessage = displayMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        UserCanCreateDirectDebitPlan that = (UserCanCreateDirectDebitPlan) o;

        return new EqualsBuilder()
                .append(allowDirectDebitPlans, that.allowDirectDebitPlans)
                .append(displayMessage, that.displayMessage)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(allowDirectDebitPlans)
                .append(displayMessage)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("allowDirectDebitPlans", allowDirectDebitPlans)
                .append("displayMessage", displayMessage)
                .toString();
    }
}
