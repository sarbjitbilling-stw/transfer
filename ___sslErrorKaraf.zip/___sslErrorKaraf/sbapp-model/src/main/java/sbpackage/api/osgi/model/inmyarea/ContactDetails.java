package sbpackage.api.osgi.model.inmyarea;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ContactDetails {

    private String firstName;
    private String lastName;
    private String phone;
    private String email;

}
