package sbpackage.api.osgi.model.payment.directdebit;

import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.payment.common.PaymentPlan;

/**
 * Created by rtai on 28/06/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentInfo {

    @XmlElement(name = "paymentDay")
    private int paymentDay;

    @XmlElement(name = "startDate")
    private LocalDate startDate;

    @XmlElement(name = "paymentMethod")
    private PaymentMethod paymentMethod;

    @XmlElement(name = "paymentFrequency")
    private PaymentFrequency paymentFrequency;

    @XmlElement(name = "paymentPlans")
    private List<PaymentPlan> paymentPlans;
    
    public int getPaymentDay() {
        return paymentDay;
    }

    public void setPaymentDay(int paymentDay) {
        this.paymentDay = paymentDay;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public void setPaymentFrequency(String frequencyCode){
        switch (frequencyCode){
            case "M": this.paymentFrequency = PaymentFrequency.MONTHLY; break;
            case "K": this.paymentFrequency = PaymentFrequency.FORTNIGHTLY; break;
            case "W": this.paymentFrequency = PaymentFrequency.WEEKLY; break;
            case "T": this.paymentFrequency = PaymentFrequency.FOUR_WEEKLY; break;
            default: this.paymentFrequency = PaymentFrequency.MONTHLY;
        }
    }

    public List<PaymentPlan> getPaymentPlans() {
        return paymentPlans;
    }

    public void setPaymentPlans(List<PaymentPlan> paymentPlans) {
        this.paymentPlans = paymentPlans;
    }
    
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        PaymentInfo that = (PaymentInfo) o;

        return new EqualsBuilder()
                .append(paymentDay, that.paymentDay)
                .append(paymentMethod, that.paymentMethod)
                .append(paymentFrequency, that.paymentFrequency)
                .append(paymentPlans, that.paymentPlans)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(paymentDay)
                .append(paymentMethod)
                .append(paymentFrequency)
                .append(paymentPlans)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("paymentDay", paymentDay)
                .append("paymentMethod", paymentMethod)
                .append("paymentFrequency", paymentFrequency)
                .append("paymentPlan", paymentPlans)
                .toString();
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public enum PaymentFrequency {
    	BILLED,
    	FOUR_WEEKLY,
    	FORTNIGHTLY,
        MONTHLY,
        OTHER,
        WEEKLY
    }
    
    public enum PaymentMethod {
    	BOOKLET,
    	CASH,
    	CREDIT_CARD,
    	DIRECT_DEBIT,
    	NONE,
    	PINGIT,
    	VIA_BANK,
    	WATER_CARD
    }
}
