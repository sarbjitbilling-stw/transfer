package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement(name = "PaperCopyBillRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class PaperCopyBillRequest {

    @XmlElement(name="accountNumber")
    private TargetAccountNumber accountNumber;
    @XmlElement(name="leId")
    private String leId;
    @XmlElement(name="invoiceDate")
    private String invoiceDate;
    @XmlElement(name="invoiceNumber")
    private long invoiceNumber;
    @XmlElement(name="email")
    private String email;
    @XmlElement(name="postCode")
    private String postCode;
    @XmlElement(name="messageCode")
    private String messageCode;

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLeId() {
        return leId;
    }

    public void setLeId(String leId) {
        this.leId = leId;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public long getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(long invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(String messageCode) {
        this.messageCode = messageCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PaperCopyBillRequest that = (PaperCopyBillRequest) o;

        if (invoiceNumber != that.invoiceNumber) return false;
        if (accountNumber != null ? !accountNumber.equals(that.accountNumber) : that.accountNumber != null)
            return false;
        if (leId != null ? !leId.equals(that.leId) : that.leId != null) return false;
        if (invoiceDate != null ? !invoiceDate.equals(that.invoiceDate) : that.invoiceDate != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (postCode != null ? !postCode.equals(that.postCode) : that.postCode != null) return false;
        return messageCode != null ? messageCode.equals(that.messageCode) : that.messageCode == null;
    }

    @Override
    public int hashCode() {
        int result = accountNumber != null ? accountNumber.hashCode() : 0;
        result = 31 * result + (leId != null ? leId.hashCode() : 0);
        result = 31 * result + (invoiceDate != null ? invoiceDate.hashCode() : 0);
        result = 31 * result + (int) (invoiceNumber ^ (invoiceNumber >>> 32));
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (postCode != null ? postCode.hashCode() : 0);
        result = 31 * result + (messageCode != null ? messageCode.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PaperCopyBillRequest{" +
                "accountNumber='" + accountNumber + '\'' +
                ", leId='" + leId + '\'' +
                ", invoiceDate='" + invoiceDate + '\'' +
                ", invoiceNumber=" + invoiceNumber +
                ", email='" + email + '\'' +
                ", postCode='" + postCode + '\'' +
                ", messageCode='" + messageCode + '\'' +
                '}';
    }
}
