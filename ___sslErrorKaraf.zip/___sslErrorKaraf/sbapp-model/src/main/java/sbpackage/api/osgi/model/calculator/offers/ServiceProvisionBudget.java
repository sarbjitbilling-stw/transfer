package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceProvisionBudget implements Serializable {
    private static final long serialVersionUID = 1L;

    @XmlElement
    private BigDecimal averageDailyCharge = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal forecastDays = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal forecastNewAnnualCharge = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal forecastWithUplift = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal accruedDays = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal accruedCharge = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal accruedChargeWithUplift = BigDecimal.ZERO;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate accruedStartDate;

    @XmlElement
    private BudgetUplift budgetUplift;

    public BigDecimal getAverageDailyCharge() {
        return averageDailyCharge;
    }

    public void setAverageDailyCharge(BigDecimal averageDailyCharge) {
        this.averageDailyCharge = averageDailyCharge;
    }

    public BigDecimal getForecastDays() {
        return forecastDays;
    }

    public void setForecastDays(BigDecimal forecastDays) {
        this.forecastDays = forecastDays;
    }

    public BigDecimal getForecastNewAnnualCharge() {
        return forecastNewAnnualCharge;
    }

    public void setForecastNewAnnualCharge(BigDecimal forecastNewAnnualCharge) {
        this.forecastNewAnnualCharge = forecastNewAnnualCharge;
    }

    public BigDecimal getForecastWithUplift() {
        return forecastWithUplift;
    }

    public void setForecastWithUplift(BigDecimal forecastWithUplift) {
        this.forecastWithUplift = forecastWithUplift;
    }

    public BigDecimal getAccruedDays() {
        return accruedDays;
    }

    public void setAccruedDays(BigDecimal accruedDays) {
        this.accruedDays = accruedDays;
    }

    public BigDecimal getAccruedCharge() {
        return accruedCharge;
    }

    public void setAccruedCharge(BigDecimal accruedCharge) {
        this.accruedCharge = accruedCharge;
    }

    public BigDecimal getAccruedChargeWithUplift() {
        return accruedChargeWithUplift;
    }

    public void setAccruedChargeWithUplift(BigDecimal accruedChargeWithUplift) {
        this.accruedChargeWithUplift = accruedChargeWithUplift;
    }

    public LocalDate getAccruedStartDate() {
        return accruedStartDate;
    }

    public void setAccruedStartDate(LocalDate accruedStartDate) {
        this.accruedStartDate = accruedStartDate;
    }

    public BudgetUplift getBudgetUplift() {
        return budgetUplift;
    }

    public void setBudgetUplift(final BudgetUplift budgetUplift) {
        this.budgetUplift = budgetUplift;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("averageDailyCharge", averageDailyCharge)
                .append("forecastDays", forecastDays)
                .append("forecastNewAnnualCharge", forecastNewAnnualCharge)
                .append("forecastWithUplift", forecastWithUplift)
                .append("accruedDays", accruedDays)
                .append("accruedCharge", accruedCharge)
                .append("accruedChargeWithUplift", accruedChargeWithUplift)
                .append("accruedStartDate", accruedStartDate)
                .append("budgetUplift", budgetUplift)
                .toString();
    }
}
