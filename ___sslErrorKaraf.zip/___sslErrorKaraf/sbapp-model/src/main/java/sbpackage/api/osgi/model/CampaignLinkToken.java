
package sbpackage.api.osgi.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CampaignLinkToken", propOrder
        = {"customer", "accountNumber", "email"
})

@XmlRootElement(name = "CampaignLinkToken")
public class CampaignLinkToken {

    @XmlElement(name = "accountNumber")
    private String accountNumber;

    @XmlElement(name = "email")
    private String email;

    @XmlElement(name = "customer")
    private Customer customer;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("customer", customer)
                .append("accountNumber", accountNumber)
                .append("email", email)
                .toString();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
