package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SurfaceWaterDrainAfter {

    private Float surfaceWaterDrainAfter;

    public Float getSurfaceWaterDrainAfter() {
        return surfaceWaterDrainAfter;
    }

    public void setSurfaceWaterDrainAfter(Float surfaceWaterDrainAfter) {
        this.surfaceWaterDrainAfter = surfaceWaterDrainAfter;
    }
}
