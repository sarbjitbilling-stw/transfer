package sbpackage.api.osgi.model.email;

import java.io.Serializable;

/**
 * FileAttachment is used to capture the contents of a file attachment as a byte array.
 */
public class FileAttachment implements Serializable {

    private String fileName;
    private byte[] fileData;
    private String contentType;
    private long size;
    private boolean encrypted;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getFileData() {
        return fileData;
    }

    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public boolean isEncrypted() {
        return encrypted;
    }

    public void setEncrypted(boolean encrypted) {
        this.encrypted = encrypted;
    }
}
