package sbpackage.api.osgi.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LegalEntityCheckRequest", propOrder = { "primary","coPrimary"})
@XmlRootElement(name="LegalEntityCheckRequest")
public class LegalEntityReuseRequest {
	@XmlAttribute(required=true)
	private Long primary;
	
	@XmlAttribute(required=true)
	private List<Long> coPrimary = new ArrayList<>();

	public Long getPrimary() {
		return primary;
	}
	public void setPrimary(Long primary) {
		this.primary = primary;
	}
	public List<Long> getCoPrimary() {
		return coPrimary;
	}
	public void setCoPrimary(List<Long> coPrimary) {
		this.coPrimary = coPrimary;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LegalEntityCheckRequest [primary=");
		builder.append(primary);
		builder.append(", coPrimary=");
		builder.append(coPrimary);
		builder.append("]");
		return builder.toString();
	}
}
