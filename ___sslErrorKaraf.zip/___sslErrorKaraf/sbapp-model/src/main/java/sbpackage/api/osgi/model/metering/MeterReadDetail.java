package sbpackage.api.osgi.model.metering;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterReadDetail")
@XmlRootElement(name = "MeterReadDetail")
public class MeterReadDetail {

    @XmlElement(name = "usage")
    private BigDecimal usage;
    @XmlElement(name = "reading")
    private BigDecimal reading;
    @XmlElement(name = "createdDate")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate createdDate;
    @XmlElement(name = "status")
    private UsageMetricStatus status;
    @XmlElement(name = "notes")
    private String notes;
    @XmlElement(name = "addressCode")
    private Long addressCode;
    @XmlElement(name = "averageDailyConsumption")
    private BigDecimal averageDailyConsumption;
    @XmlElement(name = "billTriggerStatus")
    private String billTriggerStatus;
    @XmlElement(name = "billedIndicator")
    private String billedIndicator;
    @XmlElement(name = "billingMultiplierAmount")
    private BigDecimal billingMultiplierAmount;
    @XmlElement(name = "conversionFlag")
    private String conversionFlag;
    @XmlElement(name = "daysSincePreviousRead")
    private long daysSincePreviousRead;
    @XmlElement(name = "dialDigitsNumLeft")
    private long dialDigitsNumLeft;
    @XmlElement(name = "dialDigitsNumRight")
    private long dialDigitsNumRight;
    @XmlElement(name = "highLowFailIndicator")
    private String highLowFailIndicator;
    @XmlElement(name = "invoiceNumber")
    private Long invoiceNumber;
    @XmlElement(name = "measurementType")
    private String measurementType;
    @XmlElement(name = "meterReadingStatus")
    private String meterReadingStatus;
    @XmlElement(name = "meterReadSourceCode")
    private String meterReadSourceCode;
    @XmlElement(name = "readingInvoiceFlag")
    private String readingInvoiceFlag;
    @XmlElement(name = "readingType")
    private String readingType;
    @XmlElement(name = "troubleCodeFlag")
    private String troubleCodeFlag;
    @XmlElement(name = "nextScheduledBillDate")
    private Date nextScheduledBillDate;
    @XmlElement(name = "overrideValidation")
    private Boolean overrideValidation;

    @XmlElement(name = "actionCode")
    private String actionCode;
    @XmlElement(name = "chorDate")
    private Date chorDate;
    @XmlElement(name = "readingSourceInd")
    private String readingSourceInd;
    @XmlElement(name = "meterReadRemarks")
    private String meterReadRemarks;
    @XmlElement(name = "remoteReadingDeviceUsageFlag")
    private String remoteReadingDeviceUsageFlag;
    @XmlElement(name = "employeeNum")
    private Long employeeNum;
    @XmlElement(name = "prorateReadsByBillPeriodFlag")
    private String prorateReadsByBillPeriodFlag;
    @XmlElement(name = "codeForMeterReadSource")
    private String codeForMeterReadSource;
    @XmlElement(name = "serviceStatus")
    private String serviceStatus;
    @XmlElement(name = "cyclicNum")
    private long cyclicNum;
    @XmlElement(name = "utilityEquipmentNum")
    private String utilityEquipmentNum;
    @XmlElement(name = "workOrderCode")
    private Long workOrderCode;
    @XmlElement(name = "meterReadTime")
    private Date meterReadTime;
    @XmlElement(name = "installationRead")
    private String installationRead;
    @XmlElement(name = "billNextRunIndicator")
    private String billNextRunIndicator;
    @XmlElement(name = "acknowledgement")
    private String acknowledgement;
    @XmlElement(name = "sequenceNum")
    private String sequenceNum;
    @XmlElement(name = "preValidationCheckFailed")
    private Boolean preValidationCheckFailed;
    @XmlElement(name = "readType")
    private MeterReadType readType;
    
    @XmlElement(name = "changeInUsage")
	private BigDecimal changeInUsage;

    public BigDecimal getUsage() {
        return usage;
    }

    public void setUsage(BigDecimal usage) {
        this.usage = usage;
    }

    public BigDecimal getReading() {
        return reading;
    }

    public void setReading(BigDecimal reading) {
        this.reading = reading;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    public UsageMetricStatus getStatus() {
        return status;
    }

    public void setStatus(UsageMetricStatus status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Long getAddressCode() {
        return addressCode;
    }

    public void setAddressCode(Long addressCode) {
        this.addressCode = addressCode;
    }

    public BigDecimal getAverageDailyConsumption() {
        return averageDailyConsumption;
    }

    public void setAverageDailyConsumption(BigDecimal averageDailyConsumption) {
        this.averageDailyConsumption = averageDailyConsumption;
    }

    public String getBillTriggerStatus() {
        return billTriggerStatus;
    }

    public void setBillTriggerStatus(String billTriggerStatus) {
        this.billTriggerStatus = billTriggerStatus;
    }

    public String getBilledIndicator() {
        return billedIndicator;
    }

    public void setBilledIndicator(String billedIndicator) {
        this.billedIndicator = billedIndicator;
    }

    public BigDecimal getBillingMultiplierAmount() {
        return billingMultiplierAmount;
    }

    public void setBillingMultiplierAmount(BigDecimal billingMultiplierAmount) {
        this.billingMultiplierAmount = billingMultiplierAmount;
    }

    public String getConversionFlag() {
        return conversionFlag;
    }

    public void setConversionFlag(String conversionFlag) {
        this.conversionFlag = conversionFlag;
    }

    public long getDaysSincePreviousRead() {
        return daysSincePreviousRead;
    }

    public void setDaysSincePreviousRead(long daysSincePreviousRead) {
        this.daysSincePreviousRead = daysSincePreviousRead;
    }

    public long getDialDigitsNumLeft() {
        return dialDigitsNumLeft;
    }

    public void setDialDigitsNumLeft(long dialDigitsNumLeft) {
        this.dialDigitsNumLeft = dialDigitsNumLeft;
    }

    public long getDialDigitsNumRight() {
        return dialDigitsNumRight;
    }

    public void setDialDigitsNumRight(long dialDigitsNumRight) {
        this.dialDigitsNumRight = dialDigitsNumRight;
    }

    public String getHighLowFailIndicator() {
        return highLowFailIndicator;
    }

    public void setHighLowFailIndicator(String highLowFailIndicator) {
        this.highLowFailIndicator = highLowFailIndicator;
    }

    public Long getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(Long invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getMeasurementType() {
        return measurementType;
    }

    public void setMeasurementType(String measurementType) {
        this.measurementType = measurementType;
    }

    public String getMeterReadingStatus() {
        return meterReadingStatus;
    }

    public void setMeterReadingStatus(String meterReadingStatus) {
        this.meterReadingStatus = meterReadingStatus;
    }

    public String getMeterReadSourceCode() {
        return meterReadSourceCode;
    }

    public void setMeterReadSourceCode(String meterReadSourceCode) {
        this.meterReadSourceCode = meterReadSourceCode;
    }

    public String getReadingInvoiceFlag() {
        return readingInvoiceFlag;
    }

    public void setReadingInvoiceFlag(String readingInvoiceFlag) {
        this.readingInvoiceFlag = readingInvoiceFlag;
    }

    public String getReadingType() {
        return readingType;
    }

    public void setReadingType(String readingType) {
        this.readingType = readingType;
    }

    public String getTroubleCodeFlag() {
        return troubleCodeFlag;
    }

    public void setTroubleCodeFlag(String troubleCodeFlag) {
        this.troubleCodeFlag = troubleCodeFlag;
    }

    public Date getNextScheduledBillDate() {
        return nextScheduledBillDate;
    }

    public void setNextScheduledBillDate(Date nextScheduledBillDate) {
        this.nextScheduledBillDate = nextScheduledBillDate;
    }

    public String getActionCode() {
        return actionCode;
    }

    public void setActionCode(String actionCode) {
        this.actionCode = actionCode;
    }

    public Date getChorDate() {
        return chorDate;
    }

    public void setChorDate(Date chorDate) {
        this.chorDate = chorDate;
    }

    public String getReadingSourceInd() {
        return readingSourceInd;
    }

    public void setReadingSourceInd(String readingSourceInd) {
        this.readingSourceInd = readingSourceInd;
    }

    public String getMeterReadRemarks() {
        return meterReadRemarks;
    }

    public void setMeterReadRemarks(String meterReadRemarks) {
        this.meterReadRemarks = meterReadRemarks;
    }

    public String getRemoteReadingDeviceUsageFlag() {
        return remoteReadingDeviceUsageFlag;
    }

    public void setRemoteReadingDeviceUsageFlag(String remoteReadingDeviceUsageFlag) {
        this.remoteReadingDeviceUsageFlag = remoteReadingDeviceUsageFlag;
    }

    public Long getEmployeeNum() {
        return employeeNum;
    }

    public void setEmployeeNum(Long employeeNum) {
        this.employeeNum = employeeNum;
    }

    public String getProrateReadsByBillPeriodFlag() {
        return prorateReadsByBillPeriodFlag;
    }

    public void setProrateReadsByBillPeriodFlag(String prorateReadsByBillPeriodFlag) {
        this.prorateReadsByBillPeriodFlag = prorateReadsByBillPeriodFlag;
    }

    public String getCodeForMeterReadSource() {
        return codeForMeterReadSource;
    }

    public void setCodeForMeterReadSource(String codeForMeterReadSource) {
        this.codeForMeterReadSource = codeForMeterReadSource;
    }

    public String getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(String serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public long getCyclicNum() {
        return cyclicNum;
    }

    public void setCyclicNum(long cyclicNum) {
        this.cyclicNum = cyclicNum;
    }

    public String getUtilityEquipmentNum() {
        return utilityEquipmentNum;
    }

    public void setUtilityEquipmentNum(String utilityEquipmentNum) {
        this.utilityEquipmentNum = utilityEquipmentNum;
    }

    public Long getWorkOrderCode() {
        return workOrderCode;
    }

    public void setWorkOrderCode(Long workOrderCode) {
        this.workOrderCode = workOrderCode;
    }

    public Date getMeterReadTime() {
        return meterReadTime;
    }

    public void setMeterReadTime(Date meterReadTime) {
        this.meterReadTime = meterReadTime;
    }

    public String getInstallationRead() {
        return installationRead;
    }

    public void setInstallationRead(String installationRead) {
        this.installationRead = installationRead;
    }

    public String getBillNextRunIndicator() {
        return billNextRunIndicator;
    }

    public void setBillNextRunIndicator(String billNextRunIndicator) {
        this.billNextRunIndicator = billNextRunIndicator;
    }

    public String getAcknowledgement() {
        return acknowledgement;
    }

    public void setAcknowledgement(String acknowledgement) {
        this.acknowledgement = acknowledgement;
    }

    public String getSequenceNum() {
        return sequenceNum;
    }

    public void setSequenceNum(String sequenceNum) {
        this.sequenceNum = sequenceNum;
    }

    public Boolean getOverrideValidation() {
        return overrideValidation;
    }

    public void setOverrideValidation(Boolean overrideValidation) {
        this.overrideValidation = overrideValidation;
    }

    public Boolean getPreValidationCheckFailed() {
        return preValidationCheckFailed;
    }

    public void setPreValidationCheckFailed(Boolean preValidationCheckFailed) {
        this.preValidationCheckFailed = preValidationCheckFailed;
    }

    public MeterReadType getReadType() {
        return readType;
    }

    public void setReadType(MeterReadType readType) {
        this.readType = readType;
    }
    
    public BigDecimal getChangeInUsage() {
		return changeInUsage;
	}

	public void setChangeInUsage(BigDecimal changeInUsage) {
		this.changeInUsage = changeInUsage;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MeterReadDetail that = (MeterReadDetail) o;

        if (daysSincePreviousRead != that.daysSincePreviousRead) {
            return false;
        }
        if (dialDigitsNumLeft != that.dialDigitsNumLeft) {
            return false;
        }
        if (dialDigitsNumRight != that.dialDigitsNumRight) {
            return false;
        }
        if (overrideValidation != that.overrideValidation) {
            return false;
        }
        if (!usage.equals(that.usage)) {
            return false;
        }
        if (!reading.equals(that.reading)) {
            return false;
        }
        if (!createdDate.equals(that.createdDate)) {
            return false;
        }
        if (status != that.status) {
            return false;
        }
        if (!notes.equals(that.notes)) {
            return false;
        }
        if (!addressCode.equals(that.addressCode)) {
            return false;
        }
        if (!averageDailyConsumption.equals(that.averageDailyConsumption)) {
            return false;
        }
        if (!billTriggerStatus.equals(that.billTriggerStatus)) {
            return false;
        }
        if (!billedIndicator.equals(that.billedIndicator)) {
            return false;
        }
        if (!billingMultiplierAmount.equals(that.billingMultiplierAmount)) {
            return false;
        }
        if (!conversionFlag.equals(that.conversionFlag)) {
            return false;
        }
        if (!highLowFailIndicator.equals(that.highLowFailIndicator)) {
            return false;
        }
        if (!invoiceNumber.equals(that.invoiceNumber)) {
            return false;
        }
        if (!measurementType.equals(that.measurementType)) {
            return false;
        }
        if (!meterReadingStatus.equals(that.meterReadingStatus)) {
            return false;
        }
        if (!meterReadSourceCode.equals(that.meterReadSourceCode)) {
            return false;
        }
        if (!readingInvoiceFlag.equals(that.readingInvoiceFlag)) {
            return false;
        }
        if (!readingType.equals(that.readingType)) {
            return false;
        }
        if (!troubleCodeFlag.equals(that.troubleCodeFlag)) {
            return false;
        }
        if (!preValidationCheckFailed.equals(that.preValidationCheckFailed)) {
            return false;
        }
        
        if (!changeInUsage.equals(that.changeInUsage)) {
            return false;
        }
        return nextScheduledBillDate.equals(that.nextScheduledBillDate);
    }

    @Override
    public int hashCode() {
        int result = (usage != null)?usage.hashCode():0;
        result = 31 * result + reading.hashCode();
        result = 31 * result + createdDate.hashCode();
        result = (status != null)?31 * result + status.hashCode():result;
        result = 31 * result + notes.hashCode();
        result = (addressCode != null)?31 * result + addressCode.hashCode():result;
        result = (averageDailyConsumption != null)?31 * result + averageDailyConsumption.hashCode():result;
        result = (billTriggerStatus != null)?31 * result + billTriggerStatus.hashCode():result;
        result = (billedIndicator != null)?31 * result + billedIndicator.hashCode():result;
        result = (billingMultiplierAmount != null)?31 * result + billingMultiplierAmount.hashCode():result;
        result = (conversionFlag != null)?31 * result + conversionFlag.hashCode():result;
        result = 31 * result + (int) (daysSincePreviousRead ^ (daysSincePreviousRead >>> 32));
        result = 31 * result + (int) (dialDigitsNumLeft ^ (dialDigitsNumLeft >>> 32));
        result = 31 * result + (int) (dialDigitsNumRight ^ (dialDigitsNumRight >>> 32));
        result = (highLowFailIndicator != null)?31 * result + highLowFailIndicator.hashCode():result;
        result = (invoiceNumber != null)?31 * result + invoiceNumber.hashCode():result;
        result = (measurementType != null)?31 * result + measurementType.hashCode():result;
        result = (meterReadingStatus != null)?31 * result + meterReadingStatus.hashCode():result;
        result = (meterReadSourceCode != null)?31 * result + meterReadSourceCode.hashCode():result;
        result = (readingInvoiceFlag != null)?31 * result + readingInvoiceFlag.hashCode():result;
        result = 31 * result + readingType.hashCode();
        result = (troubleCodeFlag != null)?31 * result + troubleCodeFlag.hashCode():result;
        result = (nextScheduledBillDate != null)?31 * result + nextScheduledBillDate.hashCode():result;
        result = 31 * result + (overrideValidation ? 1 : 0);
        result = 31 * result + ((preValidationCheckFailed != null && preValidationCheckFailed)? 1 : 0);
        result = (changeInUsage != null)?31 * result + changeInUsage.hashCode():result;
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"daysSincePreviousRead\":").append("\"").append(daysSincePreviousRead).append("\"");
        sb.append(", \"dialDigitsNumLeft\":").append("\"").append(dialDigitsNumLeft).append("\"");
        sb.append(", \"dialDigitsNumRight\":").append("\"").append(dialDigitsNumRight).append("\"");
        sb.append(", \"overrideValidation\":").append("\"").append(overrideValidation).append("\"");
        sb.append(", \"usage\":").append("\"").append(usage != null ? usage: "null").append("\"");
        sb.append(", \"reading\":").append("\"").append(reading !=null ? reading : "null").append("\"");
        sb.append(", \"createdDate\":").append("\"").append(createdDate != null ? createdDate:"null").append("\"");
        sb.append(", \"status\":").append("\"").append(status != null ? status : "null").append("\"");
        sb.append(", \"notes\":").append("\"").append(notes).append("\"");
        sb.append(", \"addressCode\":").append("\"").append(addressCode != null ? addressCode :"null").append("\"");
        sb.append(", \"averageDailyConsumption\":").append("\"").append(averageDailyConsumption).append("\"");
        sb.append(", \"billTriggerStatus\":").append("\"").append(billTriggerStatus).append("\"");
        sb.append(", \"billedIndicator\":").append("\"").append(billedIndicator).append("\"");
        sb.append(", \"billingMultiplierAmount\":").append("\"").append(billingMultiplierAmount != null ? billingMultiplierAmount: "null").append("\"");
        sb.append(", \"conversionFlag\":").append("\"").append(conversionFlag).append("\"");
        sb.append(", \"highLowFailIndicator\":").append("\"").append(highLowFailIndicator).append("\"");
        sb.append(", \"invoiceNumber\":").append("\"").append(invoiceNumber != null ? invoiceNumber: "null").append("\"");
        sb.append(", \"measurementType\":").append("\"").append(measurementType).append("\"");
        sb.append(", \"meterReadingStatus\":").append("\"").append(meterReadingStatus).append("\"");
        sb.append(", \"meterReadSourceCode\":").append("\"").append(meterReadSourceCode).append("\"");
        sb.append(", \"readingInvoiceFlag\":").append("\"").append(readingInvoiceFlag).append("\"");
        sb.append(", \"readingType\":").append("\"").append(readingType).append("\"");
        sb.append(", \"troubleCodeFlag\":").append("\"").append(troubleCodeFlag).append("\"");
        sb.append(", \"nextScheduledBillDate\":").append("\"").append(nextScheduledBillDate).append("\"");
        sb.append(", \"actionCode\":").append("\"").append(actionCode).append("\"");
        sb.append(", \"readingSourceInd\":").append("\"").append(readingSourceInd).append("\"");
        sb.append(", \"chorDate\":").append("\"").append(chorDate).append("\"");
        sb.append(", \"readingSourceInd\":").append("\"").append(readingSourceInd).append("\"");
        sb.append(", \"meterReadRemarks\":").append("\"").append(meterReadRemarks).append("\"");
        sb.append(", \"meterReadRemarks\":").append("\"").append(meterReadRemarks).append("\"");
        sb.append(", \"remoteReadingDeviceUsageFlag\":").append("\"").append(remoteReadingDeviceUsageFlag).append("\"");
        sb.append(", \"employeeNum\":").append("\"").append(employeeNum).append("\"");
        sb.append(", \"prorateReadsByBillPeroidFlag\":").append("\"").append(prorateReadsByBillPeriodFlag).append("\"");
        sb.append(", \"codeForMeterReadSource\":").append("\"").append(codeForMeterReadSource).append("\"");
        sb.append(", \"serviceStatus\":").append("\"").append(serviceStatus).append("\"");
        sb.append(", \"cyclicNum\":").append("\"").append(cyclicNum).append("\"");
        sb.append(", \"utilityEquipmentNum\":").append("\"").append(utilityEquipmentNum).append("\"");
        sb.append(", \"workOrderCode\":").append("\"").append(workOrderCode).append("\"");
        sb.append(", \"serviceStatus\":").append("\"").append(serviceStatus).append("\"");
        sb.append(", \"meterReadTime\":").append("\"").append(meterReadTime).append("\"");
        sb.append(", \"installationRead\":").append("\"").append(installationRead).append("\"");
        sb.append(", \"billNextRunIndicator\":").append("\"").append(billNextRunIndicator).append("\"");
        sb.append(", \"acknowledgement\":").append("\"").append(acknowledgement).append("\"");
        sb.append(", \"sequenceNum\":").append("\"").append(sequenceNum).append("\"");
        sb.append(", \"preValidationCheck\":").append("\"").append(sequenceNum).append("\"");
        sb.append(", \"changeInUsage\":").append("\"").append(changeInUsage).append("\"");
        sb.append("}");
        return sb.toString();
    }

}
