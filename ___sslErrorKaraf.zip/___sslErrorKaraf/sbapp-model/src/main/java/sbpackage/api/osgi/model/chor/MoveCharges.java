package sbpackage.api.osgi.model.chor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.payment.bill.Bill;
import sbpackage.api.osgi.model.payment.common.PaymentPlan;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.time.LocalDate;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MoveCharges")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MoveCharges {

    @XmlElement(name="openingBalance")
    @JsonProperty("openingBalance")
    private Float openingBalance;

    @XmlElement(name="chargesForPeriod")
    @JsonProperty("chargesForPeriod")
    private Float chargesForPeriod;

    @XmlElement(name="amount")
    @JsonProperty("amount")
    private Float amount;

    @XmlElement(name="from")
    @JsonProperty("from")
    private LocalDate from;

    @XmlElement(name="to")
    @JsonProperty("to")
    private LocalDate to;

    @XmlElement(name="paymentPlan")
    @JsonProperty("paymentPlan")
    private PaymentPlan paymentPlan;

    public Float getAmount() {
        return amount;
    }

    public void setAmount(Float amount) {
        this.amount = amount;
    }

    public LocalDate getFrom() {
        return from;
    }

    public void setFrom(LocalDate from) {
        this.from = from;
    }

    public LocalDate getTo() {
        return to;
    }

    public void setTo(LocalDate to) {
        this.to = to;
    }

    public Float getOpeningBalance() {
        return openingBalance;
    }

    public void setOpeningBalance(Float openingBalance) {
        this.openingBalance = openingBalance;
    }

    public static MoveCharges from(Bill bill){
        MoveCharges moveCharges = new MoveCharges();
        moveCharges.setOpeningBalance(bill.getCurrentBalAmount());
        moveCharges.setAmount(bill.getFinalBalAmount());
        moveCharges.setChargesForPeriod(bill.getBilledRunAmount());
        moveCharges.setFrom(bill.getBillStartDate());
        moveCharges.setTo(bill.getBillEndDate());
        return moveCharges;
    }

    public Float getChargesForPeriod() {
        return chargesForPeriod;
    }

    public void setChargesForPeriod(Float chargesForPeriod) {
        this.chargesForPeriod = chargesForPeriod;
    }

    public PaymentPlan getPaymentPlan() {
        return paymentPlan;
    }

    public void setPaymentPlan(PaymentPlan paymentPlan) {
        this.paymentPlan = paymentPlan;
    }
}