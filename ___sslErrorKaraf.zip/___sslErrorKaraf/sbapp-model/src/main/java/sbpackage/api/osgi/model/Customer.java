package sbpackage.api.osgi.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Customer", propOrder
= { "id", "title", "titleRef", "firstName", "middleInitial", "lastName", "dateOfBirth", "preferredName", "isIndividual",
        "emailAddress", "isWSSRegistered", "niNumber", "niNumberVersion", "version036", "version064", "version696",
        "sicCode", "language", "tradingName", "homeOwnerStatus", "homeOwnerStatusVersion", "employmentStatus",
        "employmentStatusVersion", "bankAccountStatus", "benefitType", "benefitTypeVersion", "waterMarketingValue",
        "waterMarketingVersion", "twitterHandleId", "twitterHandle", "twitterHandleVersion", "facebookHandleId",
        "facebookHandle", "facebookHandleVersion",
            "leNum", "accountNum", "leTitle", "forename", "leName", "leIndicator", "doB", "leNameCyclicNum", "leCyclicNum",
            "preferredTelNumInd", "telNumWork", "preferredTelNumWork", "telNumWorkID", "telNumWorkCyclicNum", "telNumHome", "preferredTelNumHome",
            "telNumHomeID", "telNumHomeCyclicNum", "telNumMobileCyclicNum", "telNumMobile", "preferredTelNumMobile", "telNumMobileID", "dataShareIndicatorDetails",
            "bankAccIndicatorDetails", "homeOwnershipDetails", "empStatusDetails"

        })

@XmlRootElement(name = "Customer")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Customer implements Serializable {

    private static final String EMPTY_STRING = "";

    private static final String SPACE = " ";
    
    private static final String BUSINESS_INDICATOR = "B";

    @XmlElement(name = "id")
    private String id ;

    @XmlElement(name = "title")
    private String title;

    @XmlElement(name = "titleRef")
    private RefData titleRef ;

    @XmlElement(name = "firstName")
    private String firstName ;

    @XmlElement(name = "middleInitial")
    private String middleInitial ;

    @XmlElement(name = "lastName")
    private String lastName ;

    @XmlElement(name = "dateOfBirth")
    private String dateOfBirth ;

    @XmlElement(name = "preferredName")
    private String preferredName ;

    @XmlElement(name = "isIndividual")
    private Boolean isIndividual ;

    @XmlElement(name = "emailAddress")
    private String emailAddress ;

    @XmlElement(name = "isWSSRegistered")
    private Boolean isWSSRegistered ;

    @XmlElement(name = "niNumber")
    private String niNumber ;

    @XmlElement(name = "niNumberVersion")
    private String niNumberVersion ;

    @XmlElement(name = "version036")
    private String version036 ;

    @XmlElement(name = "version064")
    private String version064 ;

    @XmlElement(name = "version696")
    private String version696 ;

    @XmlElement(name = "sicCode")
    private RefData sicCode ;

    @XmlElement(name = "language")
    private RefData language;

    @XmlElement(name = "tradingName")
    private String tradingName ;

    @XmlElement(name = "homeOwnerStatus")
    private RefData homeOwnerStatus ;

    @XmlElement(name = "homeOwnerStatusVersion")
    private String homeOwnerStatusVersion ;

    @XmlElement(name = "employmentStatus")
    private RefData employmentStatus ;

    @XmlElement(name = "bankAccountStatus")
    private RefData bankAccountStatus ;

    @XmlElement(name = "employmentStatusVersion")
    private String employmentStatusVersion ;

    @XmlElement(name = "benefitType")
    private RefData benefitType ;

    @XmlElement(name = "benefitTypeVersion")
    private String benefitTypeVersion ;

    @XmlElement(name = "waterMarketingValue")
    private RefData waterMarketingValue ;
    
    @XmlElement(name = "waterMarketingId")
    private String waterMarketingId;

    @XmlElement(name = "waterMarketingVersion")
    private String waterMarketingVersion ;

    @XmlElement(name = "twitterHandleId")
    private String twitterHandleId ;

    @XmlElement(name = "twitterHandle")
    private String twitterHandle ;

    @XmlElement(name = "twitterHandleVersion")
    private String twitterHandleVersion;

    @XmlElement(name = "facebookHandleId")
    private String facebookHandleId ;

    @XmlElement(name = "facebookHandle")
    private String facebookHandle ;

    @XmlElement(name = "facebookHandleVersion")
    private String facebookHandleVersion ;

    @XmlElement(name = "leNum")
    private Long leNum;

    @XmlElement(name = "accountNum")
    private TargetAccountNumber accountNum;

    @XmlElement(name = "leTitle")
    private String leTitle;

    @XmlElement(name = "forename")
    private String forename;

    @XmlElement(name = "leName")
    private String leName;

    @XmlElement(name = "leIndicator")
    private String leIndicator;

    @XmlElement(name = "doB")
    private XMLGregorianCalendar doB;

    @XmlElement(name = "leNameCyclicNum")
    private String leNameCyclicNum;

    @XmlElement(name = "leCyclicNum")
    private Long leCyclicNum;

    @XmlElement(name = "preferredTelNumInd")
    private String preferredTelNumInd;

    @XmlElement(name = "telNumWork")
    private String telNumWork;

    @XmlElement(name = "preferredTelNumWork")
    private String preferredTelNumWork;

    @XmlElement(name = "telNumWorkID")
    private Long telNumWorkID;

    @XmlElement(name = "telNumWorkCyclicNum")
    private String telNumWorkCyclicNum;

    @XmlElement(name = "telNumHome")
    private String telNumHome;

    @XmlElement(name = "preferredTelNumHome")
    private String preferredTelNumHome;

    @XmlElement(name = "telNumHomeID")
    private Long telNumHomeID;

    @XmlElement(name = "telNumHomeCyclicNum")
    private String telNumHomeCyclicNum;

    @XmlElement(name = "telNumMobileCyclicNum")
    private Long telNumMobileCyclicNum;

    @XmlElement(name = "telNumMobile")
    private String telNumMobile;

    @XmlElement(name = "preferredTelNumMobile")
    private String preferredTelNumMobile;

    @XmlElement(name = "telNumMobileID")
    private Long telNumMobileID;

    @XmlElement(name = "dataShareIndicatorDetails")
    private DatashareIndicatorDetails dataShareIndicatorDetails = null;

    @XmlElement(name = "empStatusDetails")
    private EmpStatusDetails empStatusDetails = null;

    @XmlElement(name = "bankAccIndicatorDetails")
    private BankAccIndicatorDetails bankAccIndicatorDetails = null;
    
    @XmlElement(name = "homeOwnershipDetails")
    private HomeOwnershipDetails homeOwnershipDetails = null;
    
    @XmlElement(name = "sites")
    private List<WSSSite> sites;

    public Long getLeNum() {
        return leNum;
    }

    public void setLeNum(Long leNum) {
        this.leNum = leNum;
    }

    public TargetAccountNumber getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(TargetAccountNumber accountNum) {
        this.accountNum = accountNum;
    }

    public String getLeTitle() {
        return leTitle;
    }

    public void setLeTitle(String leTitle) {
        this.leTitle = leTitle;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public String getLeName() {
        return leName;
    }

    public void setLeName(String leName) {
        this.leName = leName;
    }

    public String getLeIndicator() {
        return leIndicator;
    }

    public void setLeIndicator(String leIndicator) {
        this.leIndicator = leIndicator;
    }

    public XMLGregorianCalendar getDoB() {
        return doB;
    }

    public void setDoB(XMLGregorianCalendar doB) {
        this.doB = doB;
    }

    public String getLeNameCyclicNum() {
        return leNameCyclicNum;
    }

    public void setLeNameCyclicNum(String leNameCyclicNum) {
        this.leNameCyclicNum = leNameCyclicNum;
    }

    public Long getLeCyclicNum() {
        return leCyclicNum;
    }

    public void setLeCyclicNum(Long leCyclicNum) {
        this.leCyclicNum = leCyclicNum;
    }

    public String getPreferredTelNumInd() {
        return preferredTelNumInd;
    }

    public void setPreferredTelNumInd(String preferredTelNumInd) {
        this.preferredTelNumInd = preferredTelNumInd;
    }

    public String getTelNumWork() {
        return telNumWork;
    }

    public void setTelNumWork(String telNumWork) {
        this.telNumWork = telNumWork;
    }

    public String getPreferredTelNumWork() {
        return preferredTelNumWork;
    }

    public void setPreferredTelNumWork(String preferredTelNumWork) {
        this.preferredTelNumWork = preferredTelNumWork;
    }

    public Long getTelNumWorkID() {
        return telNumWorkID;
    }

    public void setTelNumWorkID(Long telNumWorkID) {
        this.telNumWorkID = telNumWorkID;
    }

    public String getTelNumWorkCyclicNum() {
        return telNumWorkCyclicNum;
    }

    public void setTelNumWorkCyclicNum(String telNumWorkCyclicNum) {
        this.telNumWorkCyclicNum = telNumWorkCyclicNum;
    }

    public String getTelNumHome() {
        return telNumHome;
    }

    public void setTelNumHome(String telNumHome) {
        this.telNumHome = telNumHome;
    }

    public String getPreferredTelNumHome() {
        return preferredTelNumHome;
    }

    public void setPreferredTelNumHome(String preferredTelNumHome) {
        this.preferredTelNumHome = preferredTelNumHome;
    }

    public Long getTelNumHomeID() {
        return telNumHomeID;
    }

    public void setTelNumHomeID(Long telNumHomeID) {
        this.telNumHomeID = telNumHomeID;
    }

    public String getTelNumHomeCyclicNum() {
        return telNumHomeCyclicNum;
    }

    public void setTelNumHomeCyclicNum(String telNumHomeCyclicNum) {
        this.telNumHomeCyclicNum = telNumHomeCyclicNum;
    }

    public Long getTelNumMobileCyclicNum() {
        return telNumMobileCyclicNum;
    }

    public void setTelNumMobileCyclicNum(Long telNumMobileCyclicNum) {
        this.telNumMobileCyclicNum = telNumMobileCyclicNum;
    }

    public String getTelNumMobile() {
        return telNumMobile;
    }

    public void setTelNumMobile(String telNumMobile) {
        this.telNumMobile = telNumMobile;
    }

    public String getPreferredTelNumMobile() {
        return preferredTelNumMobile;
    }

    public void setPreferredTelNumMobile(String preferredTelNumMobile) {
        this.preferredTelNumMobile = preferredTelNumMobile;
    }

    public Long getTelNumMobileID() {
        return telNumMobileID;
    }

    public void setTelNumMobileID(Long telNumMobileID) {
        this.telNumMobileID = telNumMobileID;
    }

    public DatashareIndicatorDetails getDataShareIndicatorDetails() {
        return dataShareIndicatorDetails;
    }

    public void setDataShareIndicatorDetails(DatashareIndicatorDetails dataShareIndicatorDetails) {
        this.dataShareIndicatorDetails = dataShareIndicatorDetails;
    }

    public EmpStatusDetails getEmpStatusDetails() {
        return empStatusDetails;
    }

    public void setEmpStatusDetails(EmpStatusDetails empStatusDetails) {
        this.empStatusDetails = empStatusDetails;
    }

    public BankAccIndicatorDetails getBankAccIndicatorDetails() {
        return bankAccIndicatorDetails;
    }

    public void setBankAccIndicatorDetails(BankAccIndicatorDetails bankAccIndicatorDetails) {
        this.bankAccIndicatorDetails = bankAccIndicatorDetails;
    }

    public HomeOwnershipDetails getHomeOwnershipDetails() {
        return homeOwnershipDetails;
    }

    public void setHomeOwnershipDetails(HomeOwnershipDetails homeOwnershipDetails) {
        this.homeOwnershipDetails = homeOwnershipDetails;
    }

    /**
     *
     */
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     */
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * First name of customer : Target field AR750201_NM_FOR_INDIVIDUAL
     *
     */
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Middle initaal of customer : Target field AR750201_NM_MIDDLE_INITIAL
     *
     */
    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    /**
     * Last name of customer or oganisation name : Target field
     * AR750201_NM_LEGAL_ENTITY
     *
     */
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Date of birty of the customer in yyyy-mm-dd format : Target field
     * AR750201_DT_OF_BIRTH
     *
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Preferred name of the customer as shown on bill : Target field
     * AR750201_NM_PREFERRED
     *
     */
    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    /**
     * Legal entity type indicator is Individual or Business : Target field
     * AR750201_IND_LEGAL_ENTITY
     *
     */
    public void setIsIndividual(Boolean isIndividual) {
        this.isIndividual = isIndividual;
    }

    public Boolean getIsIndividual() {
        return isIndividual;
    }

    /**
     * Email address of customer : Target field AR750201_AD_EMAIL
     *
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * flag for mention about WSS registration of the Customer
     *
     */
    public Boolean getIsWSSRegistered() {
        return isWSSRegistered;
    }

    public void setIsWSSRegistered(Boolean isWSSRegistered) {
        this.isWSSRegistered = isWSSRegistered;
    }

    /**
     * National insurance number of customer : Target additional data field
     * AR750201_CD_EXT_REF when AR750201_NO_EXT_REFERENCE = 114
     *
     */
    public String getNiNumber() {
        return niNumber;
    }

    public void setNiNumber(String niNumber) {
        this.niNumber = niNumber;
    }

    /**
     * National insurance number update version numner : Target additional data
     * field AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 114
     *
     */
    public String getNiNumberVersion() {
        return niNumberVersion;
    }

    public void setNiNumberVersion(String niNumberVersion) {
        this.niNumberVersion = niNumberVersion;
    }

    /**
     * Data version : Target filed AR750201_NO_CYCLIC_036
     *
     */
    public String getVersion036() {
        return version036;
    }

    public void setVersion036(String version036) {
        this.version036 = version036;
    }

    /**
     * Data version : Target filed AR750201_NO_CYCLIC_064
     *
     */
    public String getVersion064() {
        return version064;
    }

    public void setVersion064(String version064) {
        this.version064 = version064;
    }

    /**
     * Data version : Target filed AR750201_NO_CYCLIC_696
     *
     */
    public String getVersion696() {
        return version696;
    }

    public void setVersion696(String version696) {
        this.version696 = version696;
    }

    /**
     * SIC Code for Commercial Customer
     *
     */
    public RefData getSicCode() {
        return sicCode;
    }

    public void setSicCode(RefData sicCode) {
        this.sicCode = sicCode;
    }

    public RefData getLanguage() {
        return language;
    }

    public void setLanguage(RefData language) {
        this.language = language;
    }

    /**
     * Trading name for Commercial Customer
     *
     */
    public String getTradingName() {
        return tradingName;
    }

    public void setTradingName(String tradingName) {
        this.tradingName = tradingName;
    }

    /**
     *
     */
    public RefData getHomeOwnerStatus() {
        return homeOwnerStatus;
    }

    public void setHomeOwnerStatus(RefData homeOwnerStatus) {
        this.homeOwnerStatus = homeOwnerStatus;
    }

    /**
     * Home owner status version numner : Target additional data field
     * AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 8
     *
     */
    public String getHomeOwnerStatusVersion() {
        return homeOwnerStatusVersion;
    }

    public void setHomeOwnerStatusVersion(String homeOwnerStatusVersion) {
        this.homeOwnerStatusVersion = homeOwnerStatusVersion;
    }

    /**
     *
     */
    public RefData getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(RefData employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    /**
     * Employment status version numner : Target additional data field
     * AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 7
     *
     */
    public String getEmploymentStatusVersion() {
        return employmentStatusVersion;
    }

    public void setEmploymentStatusVersion(String employmentStatusVersion) {
        this.employmentStatusVersion = employmentStatusVersion;
    }

    /**
     *
     */
    public RefData getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(RefData benefitType) {
        this.benefitType = benefitType;
    }

    /**
     * Benefit Type version numner : Target additional data field
     * AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 237
     *
     */
    public String getBenefitTypeVersion() {
        return benefitTypeVersion;
    }

    public void setBenefitTypeVersion(String benefitTypeVersion) {
        this.benefitTypeVersion = benefitTypeVersion;
    }

    /**
     *
     */
    public RefData getWaterMarketingValue() {
        return waterMarketingValue;
    }

    public void setWaterMarketingValue(RefData waterMarketingValue) {
        this.waterMarketingValue = waterMarketingValue;
    }

    /**
     * Water Marketing Customer Status version numner : Target additional data
     * field AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 143
     *
     */
    public String getWaterMarketingVersion() {
        return waterMarketingVersion;
    }

    public void setWaterMarketingVersion(String waterMarketingVersion) {
        this.waterMarketingVersion = waterMarketingVersion;
    }

    /**
     * Twitter Handle Id for customer : Target additional data field
     * AR750201_NO_EXT_REF_DEBT when AR750201_NO_EXT_REFERENCE = 242
     *
     */
    public String getTwitterHandleId() {
        return twitterHandleId;
    }

    public void setTwitterHandleId(String twitterHandleId) {
        this.twitterHandleId = twitterHandleId;
    }

    /**
     * Twitter Handle for customer : Target additional data field
     * AR750201_CD_EXT_REF when AR750201_NO_EXT_REFERENCE = 242
     *
     */
    public String getTwitterHandle() {
        return twitterHandle;
    }

    public void setTwitterHandle(String twitterHandle) {
        this.twitterHandle = twitterHandle;
    }

    /**
     * Twitter Handle version numner : Target additional data field
     * AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 242
     *
     */
    public String getTwitterHandleVersion() {
        return twitterHandleVersion;
    }

    public void setTwitterHandleVersion(String twitterHandleVersion) {
        this.twitterHandleVersion = twitterHandleVersion;
    }

    /**
     * Facebook Handle Id for customer : Target additional data field
     * AR750201_NO_EXT_REF_DEBT when AR750201_NO_EXT_REFERENCE = 243
     *
     */
    public String getFacebookHandleId() {
        return facebookHandleId;
    }

    public void setFacebookHandleId(String facebookHandleId) {
        this.facebookHandleId = facebookHandleId;
    }

    /**
     * Facebook Handle for customer : Target additional data field
     * AR750201_CD_EXT_REF when AR750201_NO_EXT_REFERENCE = 243
     *
     */
    public String getFacebookHandle() {
        return facebookHandle;
    }

    public void setFacebookHandle(String facebookHandle) {
        this.facebookHandle = facebookHandle;
    }

    public RefData getTitleRef() {
        return titleRef;
    }

    public void setTitleRef(RefData titleRef) {
        this.titleRef = titleRef;
    }

    public RefData getBankAccountStatus() {
        return bankAccountStatus;
    }

    public void setBankAccountStatus(RefData bankAccountStatus) {
        this.bankAccountStatus = bankAccountStatus;
    }

    /**
     * Facebook Handle version numner : Target additional data field
     * AR750201_NO_CYCLIC_703 when AR750201_NO_EXT_REFERENCE = 243
     *
     */
    public String getFacebookHandleVersion() {
        return facebookHandleVersion;
    }

    public void setFacebookHandleVersion(String facebookHandleVersion) {
        this.facebookHandleVersion = facebookHandleVersion;
    }
    
    

    public String getWaterMarketingId() {
		return waterMarketingId;
	}

    public void setWaterMarketingId(String waterMarketingId) {
            this.waterMarketingId = waterMarketingId;
    }

    public List<WSSSite> getSites() {
        return sites;
    }

    public void setSites(List<WSSSite> sites) {
        this.sites = sites;
    }
    
	@Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Customer {\n");

        sb.append("    id: ").append(toIndentedString(id)).append("\n");
        sb.append("    title: ").append(toIndentedString(title)).append("\n");
        sb.append("    titleRef: ").append(toIndentedString(titleRef)).append("\n");
        sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
        sb.append("    middleInitial: ").append(toIndentedString(middleInitial)).append("\n");
        sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
        sb.append("    dateOfBirth: ").append(toIndentedString(dateOfBirth)).append("\n");
        sb.append("    preferredName: ").append(toIndentedString(preferredName)).append("\n");
        sb.append("    isIndividual: ").append(toIndentedString(isIndividual)).append("\n");
        sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
        sb.append("    isWSSRegistered: ").append(toIndentedString(isWSSRegistered)).append("\n");
        sb.append("    niNumber: ").append(toIndentedString(niNumber)).append("\n");
        sb.append("    niNumberVersion: ").append(toIndentedString(niNumberVersion)).append("\n");
        sb.append("    version036: ").append(toIndentedString(version036)).append("\n");
        sb.append("    version064: ").append(toIndentedString(version064)).append("\n");
        sb.append("    version696: ").append(toIndentedString(version696)).append("\n");
        sb.append("    sicCode: ").append(toIndentedString(sicCode)).append("\n");
        sb.append("    language: ").append(toIndentedString(language)).append("\n");
        sb.append("    tradingName: ").append(toIndentedString(tradingName)).append("\n");
        sb.append("    homeOwnerStatus: ").append(toIndentedString(homeOwnerStatus)).append("\n");
        sb.append("    homeOwnerStatusVersion: ").append(toIndentedString(homeOwnerStatusVersion)).append("\n");
        sb.append("    employmentStatus: ").append(toIndentedString(employmentStatus)).append("\n");
        sb.append("    employmentStatusVersion: ").append(toIndentedString(employmentStatusVersion)).append("\n");
        sb.append("    benefitType: ").append(toIndentedString(benefitType)).append("\n");
        sb.append("    benefitTypeVersion: ").append(toIndentedString(benefitTypeVersion)).append("\n");
        sb.append("    waterMarketingValue: ").append(toIndentedString(waterMarketingValue)).append("\n");
        sb.append("    waterMarketingVersion: ").append(toIndentedString(waterMarketingVersion)).append("\n");
        sb.append("    twitterHandleId: ").append(toIndentedString(twitterHandleId)).append("\n");
        sb.append("    twitterHandle: ").append(toIndentedString(twitterHandle)).append("\n");
        sb.append("    twitterHandleVersion: ").append(toIndentedString(twitterHandleVersion)).append("\n");
        sb.append("    facebookHandleId: ").append(toIndentedString(facebookHandleId)).append("\n");
        sb.append("    facebookHandle: ").append(toIndentedString(facebookHandle)).append("\n");
        sb.append("    facebookHandleVersion: ").append(toIndentedString(facebookHandleVersion)).append("\n");

        sb.append("    leNum: ").append(toIndentedString(leNum)).append("\n");
        sb.append("    accountNum: ").append(toIndentedString(accountNum)).append("\n");
        sb.append("    leTitle: ").append(toIndentedString(leTitle)).append("\n");
        sb.append("    forename: ").append(toIndentedString(forename)).append("\n");
        sb.append("    leName: ").append(toIndentedString(leName)).append("\n");
        sb.append("    leIndicator: ").append(toIndentedString(leIndicator)).append("\n");
        sb.append("    doB: ").append(toIndentedString(doB)).append("\n");
        sb.append("    leNameCyclicNum: ").append(toIndentedString(leNameCyclicNum)).append("\n");
        sb.append("    leCyclicNum: ").append(toIndentedString(leCyclicNum)).append("\n");
        sb.append("    telNumWork: ").append(toIndentedString(telNumWork)).append("\n");
        sb.append("    preferredTelNumWork: ").append(toIndentedString(preferredTelNumWork)).append("\n");
        sb.append("    telNumWorkID: ").append(toIndentedString(telNumWorkID)).append("\n");
        sb.append("    telNumWorkCyclicNum: ").append(toIndentedString(telNumWorkCyclicNum)).append("\n");
        sb.append("    telNumHome: ").append(toIndentedString(telNumHome)).append("\n");
        sb.append("    preferredTelNumHome: ").append(toIndentedString(preferredTelNumHome)).append("\n");
        sb.append("    telNumHomeID: ").append(toIndentedString(telNumHomeID)).append("\n");
        sb.append("    telNumMobileCyclicNum: ").append(toIndentedString(telNumMobileCyclicNum)).append("\n");
        sb.append("    telNumMobile: ").append(toIndentedString(telNumMobile)).append("\n");
        sb.append("    preferredTelNumMobile: ").append(toIndentedString(preferredTelNumMobile)).append("\n");
        sb.append("    telNumMobileID: ").append(toIndentedString(telNumMobileID)).append("\n");

        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private static String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(title)
                .append(firstName)
                .append(lastName)
                .append(preferredName)
                .toHashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Customer cust = (Customer) o;

        return new EqualsBuilder()
                .append(id, cust.id)
                .append(title, cust.title)
                .append(firstName, cust.firstName)
                .append(lastName, cust.lastName)
                .append(preferredName, cust.preferredName)
                .isEquals();
    }

    public String getFullForeName() {
        StringBuilder fullName = new StringBuilder(EMPTY_STRING);
        if (getTitleRef() != null && StringUtils.isNotEmpty(getTitleRef().getValue())) {
            fullName.append(getTitleRef().getValue()).append(SPACE);
        }
        if (StringUtils.isNotEmpty(getForename())) {
            fullName.append(getForename()).append(SPACE);
        }

        if (StringUtils.isNotEmpty(getMiddleInitial())) {
            fullName.append(getMiddleInitial()).append(SPACE);
        }

        if (StringUtils.isNotEmpty(getLastName())) {
            fullName.append(getLastName());
        }

        return fullName.toString();
    }
    
    public String getFullName() {
        StringBuilder fullName = new StringBuilder(EMPTY_STRING);
        
		if ((StringUtils.isNotEmpty(getLeIndicator()) && !getLeIndicator().equalsIgnoreCase(BUSINESS_INDICATOR))
				|| getIsIndividual()) {
			if (getTitleRef() != null && StringUtils.isNotEmpty(getTitleRef().getValue())) {
				fullName.append(getTitleRef().getValue()).append(SPACE);
			}
			if (StringUtils.isNotEmpty(getFirstName())) {
				fullName.append(getFirstName()).append(SPACE);
			}

			if (StringUtils.isNotEmpty(getMiddleInitial())) {
				fullName.append(getMiddleInitial()).append(SPACE);
			}
			
			if (StringUtils.isNotEmpty(getLastName())) {
				fullName.append(getLastName());
			}
			
		} else {
			if (StringUtils.isNotEmpty(getLastName())) {
				fullName.append(getLastName());
			}
		}

        return fullName.toString();
    }

}
