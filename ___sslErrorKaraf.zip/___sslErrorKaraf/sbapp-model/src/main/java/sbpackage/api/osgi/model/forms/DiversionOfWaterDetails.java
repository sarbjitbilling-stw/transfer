package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DiversionOfWaterDetails {

    private static final String SELECTED_OPTION_SELF_LAY_PROVIDER = "self_lay";

    private static final String SELECTED_OPTION_ASSESSMENT_TYPE_FULL_COST = "full_cost";
    
    private Assets assetsToBeDiverted;
    private ReasonForDiversion reasonForDiversion;
    private PlanningConsent planningConsent;
    private Details principalContractorDetails;
    private Selection selfLayProvider;
    private OptionalNameAddress selfLayProviderDetails;
    private Selection typeOfAssessment;
    private SelectionArray diversionChecklist;
    private Selection excavatingAndBackfill;
    private Selection provideOwnDesign;
    private VehiclesMachineryCrossing vehiclesMachineryCrossing;
    private ProgrammeOfWorks programmeOfWorks;
    private ChangeToGroundLevel changeToGroundLevel;
    private String currentStep;

    public Assets getAssetsToBeDiverted() {
        return assetsToBeDiverted;
    }

    public void setAssetsToBeDiverted(Assets assetsToBeDiverted) {
        this.assetsToBeDiverted = assetsToBeDiverted;
    }

    public ReasonForDiversion getReasonForDiversion() {
        return reasonForDiversion;
    }

    public void setReasonForDiversion(ReasonForDiversion reasonForDiversion) {
        this.reasonForDiversion = reasonForDiversion;
    }

    public PlanningConsent getPlanningConsent() {
        return planningConsent;
    }

    public void setPlanningConsent(PlanningConsent planningConsent) {
        this.planningConsent = planningConsent;
    }

    public Details getPrincipalContractorDetails() {
        return principalContractorDetails;
    }

    public void setPrincipalContractorDetails(Details principalContractorDetails) {
        this.principalContractorDetails = principalContractorDetails;
    }

    public boolean isDiversionWaterLaidBySelfLayProvider() {
        return selfLayProvider.getSelectedOption().equals(SELECTED_OPTION_SELF_LAY_PROVIDER);
    }

    public OptionalNameAddress getSelfLayProviderDetails() {
        return selfLayProviderDetails;
    }

    public void setSelfLayProviderDetails(OptionalNameAddress selfLayProviderDetails) {
        this.selfLayProviderDetails = selfLayProviderDetails;
    }

    public Selection getSelfLayProvider() {
        return selfLayProvider;
    }

    public void setSelfLayProvider(Selection selfLayProvider) {
        this.selfLayProvider = selfLayProvider;
    }

    public Selection getTypeOfAssessment() {
        return typeOfAssessment;
    }

    public void setTypeOfAssessment(Selection typeOfAssessment) {
        this.typeOfAssessment = typeOfAssessment;
    }

    public SelectionArray getDiversionChecklist() {
        return diversionChecklist;
    }

    public void setDiversionChecklist(SelectionArray diversionChecklist) {
        this.diversionChecklist = diversionChecklist;
    }

    public Selection getProvideOwnDesign() {
        return provideOwnDesign;
    }

    public void setProvideOwnDesign(Selection provideOwnDesign) {
        this.provideOwnDesign = provideOwnDesign;
    }

    public VehiclesMachineryCrossing getVehiclesMachineryCrossing() {
        return vehiclesMachineryCrossing;
    }

    public void setVehiclesMachineryCrossing(VehiclesMachineryCrossing vehiclesMachineryCrossing) {
        this.vehiclesMachineryCrossing = vehiclesMachineryCrossing;
    }

    public ProgrammeOfWorks getProgrammeOfWorks() {
        return programmeOfWorks;
    }

    public void setProgrammeOfWorks(ProgrammeOfWorks programmeOfWorks) {
        this.programmeOfWorks = programmeOfWorks;
    }

    public ChangeToGroundLevel getChangeToGroundLevel() {
        return changeToGroundLevel;
    }
    
    public boolean isFullCostAssessment() {
        return this.typeOfAssessment.getSelectedOption().equals(SELECTED_OPTION_ASSESSMENT_TYPE_FULL_COST);
    }

    public void setChangeToGroundLevel(ChangeToGroundLevel changeToGroundLevel) {
        this.changeToGroundLevel = changeToGroundLevel;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public Selection getExcavatingAndBackfill() {
        return excavatingAndBackfill;
    }

    public void setExcavatingAndBackfill(Selection excavatingAndBackfill) {
        this.excavatingAndBackfill = excavatingAndBackfill;
    }
}