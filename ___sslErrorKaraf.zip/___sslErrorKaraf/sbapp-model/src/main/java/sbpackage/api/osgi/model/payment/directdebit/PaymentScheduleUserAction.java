package sbpackage.api.osgi.model.payment.directdebit;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by zphilip on 12/12/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentScheduleUserAction implements Serializable {

    @XmlElement(name = "isAllowed")
    private boolean isAllowed;

    @XmlElement(name = "displayMessage")
    private String displayMessage;

    @XmlElement(name = "date")
    private String date;
    
    public boolean isAllowed() {
        return isAllowed;
    }

    public void setAllowed(boolean allowed) {
        isAllowed = allowed;
    }

    public void setDisplayMessage(String displayMessage) {
        this.displayMessage = displayMessage;
    }

    public String getDisplayMessage(){
      return displayMessage;
    }
    public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("isAllowed", isAllowed)
                .append("displayMessage", displayMessage)
                .append("date", date)
                .toString();
    }


}
