package sbpackage.api.osgi.model.memo;

/**
 * These values may change if the contact package type changes but are required
 * for the initial create contact patch request.
 */
public enum RefDataDefinition {
    RESOLUTION("Information Only", "11", "252"),
    ROOT_CAUSE_TYPE("Change of Occupier", "R030", "379"),
    NOTES_TYPE("Initial Comments", "INIT", "400"),
    CONTACT_TYPE("Billing Contact", "3", "251"),
    CONTACT_SUB_TYPE("Front Office Charging Query", "126", null),
    CONTACT_METHOD("Memo", "5", "16"),
    CONTACT_INIT("STW", "33", "15");

    private final String value;
    private final String code;
    private final String valueSet;

    RefDataDefinition(final String value, final String code, final String valueSet) {
        this.value = value;
        this.code = code;
        this.valueSet = valueSet;
    }

    public String getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }

    public String getValueSet() {
        return valueSet;
    }
}