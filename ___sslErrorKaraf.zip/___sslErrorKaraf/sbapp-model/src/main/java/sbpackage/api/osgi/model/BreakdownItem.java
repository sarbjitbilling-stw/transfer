package sbpackage.api.osgi.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.math.BigDecimal;
import java.math.RoundingMode;

@XmlAccessorType(XmlAccessType.FIELD)
public class BreakdownItem {

    private static final int SCALE = 2;
    private static final RoundingMode ROUNDING_MODE = RoundingMode.HALF_UP;

    public enum BreakdownType {
        SCWASTEPUBLIC,
        SCWASTEPRIVATE,
        SCWASTEINDIRECT,
        SCWATERLARGE,
        SCWATERSTANDARD,
        DEWATERSTANDARD,
        DEWASTESTANDARD,
        DECOMBINEDSTANDARD,
        POC,
        WATERMAINREQUISITION,
        DVWASTE,
        DVWATER,
        SEWERREQUISITION,
        NAVWATER,
        NAVWASTE,
        NAVCOMBINED;
    }

    private BreakdownType key;

    private BigDecimal amount;

    private BigDecimal vatRate;

    public BreakdownItem() {

    }

    public BreakdownItem(BreakdownType key, BigDecimal amount, BigDecimal vatRate) {
        this.setKey(key);
        this.setAmount(amount);
        this.vatRate = vatRate;
    }

    public BreakdownType getKey() {
        return key;
    }

    public void setKey(BreakdownType key) {
        this.key = key;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getNet() {
        BigDecimal vatFraction = vatRate.divide(new BigDecimal(100), SCALE, ROUNDING_MODE).add(BigDecimal.ONE);
        return amount.divide(vatFraction, SCALE, ROUNDING_MODE);
    }

    public BigDecimal getVat() {
        return amount.subtract(getNet());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        BreakdownItem that = (BreakdownItem) o;

        return new EqualsBuilder()
                .append(key, that.key)
                .append(amount, that.amount)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(key)
                .append(amount)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("key", key)
                .append("amount", amount)
                .toString();
    }
}
