package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;

@XmlAccessorType(XmlAccessType.FIELD)
public class Breakdown {

    private List<BreakdownItem> waste;
    private List<BreakdownItem> water;
    private List<BreakdownItem> combined;
    @JsonIgnore
    private BigDecimal total;

    public List<BreakdownItem> getWaste() {
        return waste;
    }

    public void setWaste(List<BreakdownItem> waste) {
        this.waste = waste;
    }

    public List<BreakdownItem> getWater() {
        return water;
    }

    public void setWater(List<BreakdownItem> water) {
        this.water = water;
    }

    @XmlElement
    public BigDecimal getTotal() {
        return total != null ? total : getWasteTotal().add(getWaterTotal()).add(getCombinedTotal());
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public List<BreakdownItem> getCombined() {
        return combined;
    }

    public void setCombined(List<BreakdownItem> combined) {
        this.combined = combined;
    }

    @XmlElement
    public BigDecimal getVat() {
        return sum(water, BreakdownItem::getVat)
                .add(sum(waste, BreakdownItem::getVat))
                .add(sum(combined, BreakdownItem::getVat));
    }

    public BigDecimal getWasteTotal() {
        return sum(waste, BreakdownItem::getAmount);
    }

    public BigDecimal getWasteNet() {
        return sum(waste, BreakdownItem::getNet);
    }

    public BigDecimal getWaterTotal() {
        return sum(water, BreakdownItem::getAmount);
    }

    public BigDecimal getWaterNet() {
        return sum(water, BreakdownItem::getNet);
    }

    public BigDecimal getCombinedTotal() {
        return sum(combined, BreakdownItem::getAmount);
    }

    public BigDecimal getCombinedNet() {
        return sum(combined, BreakdownItem::getNet);
    }

    @XmlElement
    public BigDecimal getNet() {
        return getTotal().subtract(getVat());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Breakdown breakdown = (Breakdown) o;

        return new EqualsBuilder()
                .append(waste, breakdown.waste)
                .append(water, breakdown.water)
                .append(total, breakdown.total)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(waste)
                .append(water)
                .append(total)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("waste", waste)
                .append("water", water)
                .append("total", total)
                .toString();
    }

    private BigDecimal sum(List<BreakdownItem> items, Function<BreakdownItem, BigDecimal> function) {
        return items == null ? BigDecimal.ZERO : items.stream().map(function).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
