package sbpackage.api.osgi.model.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class BooleanAdapter extends XmlAdapter<String, Boolean> {

	@Override
	public String marshal(Boolean v) throws Exception {

		return v ? "Y" : "N";
	}

	@Override
	public Boolean unmarshal(String v) throws Exception {
		switch (v.toLowerCase().trim()) {
		case "true":
		case "yes":
		case "y":
		case "1":
			return true;
		case "false":
		case "no":
		case "n":
		case "0":
			return false;
		}
		return false;
	}
}
