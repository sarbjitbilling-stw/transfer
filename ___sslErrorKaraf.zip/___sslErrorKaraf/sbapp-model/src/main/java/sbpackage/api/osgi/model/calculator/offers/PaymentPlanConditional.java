package sbpackage.api.osgi.model.calculator.offers;

public enum PaymentPlanConditional {
    YES("Y"),
    NO("N");

    private final String condition;

    PaymentPlanConditional(String condition){
        this.condition = condition;
    }

    public String getCondition() {
        return condition;
    }
}
