package sbpackage.api.osgi.model.paymentplan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlanItem implements Serializable{

    @XmlElement(name = "arrearsAmount")
    @JsonProperty(value = "arrearsAmount")
    private BigDecimal arrearsAmount;

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate creationTime;

    @XmlElement(name = "cyclicConcurrencyCheckNum")
    @JsonProperty(value = "cyclicConcurrencyCheckNum")
    private Long cyclicConcurrencyCheckNum;

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate expectedPaymentDate;

    @XmlElement(name = "forecastAmount")
    @JsonProperty(value = "forecastAmount")
    private BigDecimal forecastAmount;

    @XmlElement(name = "instalmentNum")
    @JsonProperty(value = "instalmentNum")
    private Long instalmentNum;

    @XmlElement(name = "interestAmount")
    @JsonProperty(value = "interestAmount")
    private BigDecimal interestAmount;

    @XmlElement(name = "outstandingAmount")
    @JsonProperty(value = "outstandingAmount")
    private BigDecimal outstandingAmount;

    @XmlElement(name = "paymentAmount")
    @JsonProperty(value = "paymentAmount")
    private BigDecimal paymentAmount;

    @XmlElement(name = "payPlanNum")
    @JsonProperty(value = "payPlanNum")
    private Long payPlanNum;

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate requestDate;

    @XmlElement(name = "summonsAmount")
    @JsonProperty(value = "summonsAmount")
    private BigDecimal summonsAmount;

    @XmlElement(name = "totalAmount")
    @JsonProperty(value = "totalAmount")
    private BigDecimal totalAmount;

    public BigDecimal getArrearsAmount() {
        return arrearsAmount;
    }

    public void setArrearsAmount(BigDecimal arrearsAmount) {
        this.arrearsAmount = arrearsAmount;
    }

    public LocalDate getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(LocalDate creationTime) {
        this.creationTime = creationTime;
    }

    public Long getCyclicConcurrencyCheckNum() {
        return cyclicConcurrencyCheckNum;
    }

    public void setCyclicConcurrencyCheckNum(Long cyclicConcurrencyCheckNum) {
        this.cyclicConcurrencyCheckNum = cyclicConcurrencyCheckNum;
    }

    public LocalDate getExpectedPaymentDate() {
        return expectedPaymentDate;
    }

    public void setExpectedPaymentDate(LocalDate expectedPaymentDate) {
        this.expectedPaymentDate = expectedPaymentDate;
    }

    public BigDecimal getForecastAmount() {
        return forecastAmount;
    }

    public void setForecastAmount(BigDecimal forecastAmount) {
        this.forecastAmount = forecastAmount;
    }

    public Long getInstalmentNum() {
        return instalmentNum;
    }

    public void setInstalmentNum(Long instalmentNum) {
        this.instalmentNum = instalmentNum;
    }

    public BigDecimal getInterestAmount() {
        return interestAmount;
    }

    public void setInterestAmount(BigDecimal interestAmount) {
        this.interestAmount = interestAmount;
    }

    public BigDecimal getOutstandingAmount() {
        return outstandingAmount;
    }

    public void setOutstandingAmount(BigDecimal outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public Long getPayPlanNum() {
        return payPlanNum;
    }

    public void setPayPlanNum(Long payPlanNum) {
        this.payPlanNum = payPlanNum;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    public BigDecimal getSummonsAmount() {
        return summonsAmount;
    }

    public void setSummonsAmount(BigDecimal summonsAmount) {
        this.summonsAmount = summonsAmount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}
