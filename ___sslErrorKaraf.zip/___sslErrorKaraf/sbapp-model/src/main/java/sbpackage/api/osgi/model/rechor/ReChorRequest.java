package sbpackage.api.osgi.model.rechor;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.time.LocalDate;

@XmlRootElement(name = "ReChorRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ReChorRequest implements Serializable {

    @XmlElement
    private String operation;

    @XmlElement
    private TargetAccountNumber accountNumber;

    @XmlElement
    private TargetAccountNumber callerAccountNumber;

    @XmlElement
    private String legalEntityId;

    @XmlElement
    private Long propertyId;

    @XmlElement
    private boolean isUpdate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate moveOutDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate moveInDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate newMoveOutDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate newMoveInDate;

    @XmlElement
    private boolean isChaining;

    public String getOperation() {
        return operation;
    }

    public void setOperation(final String operation) {
        this.operation = operation;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(final TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntityId() {
        return legalEntityId;
    }

    public void setLegalEntityId(final String legalEntityId) {
        this.legalEntityId = legalEntityId;
    }

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(final Long propertyId) {
        this.propertyId = propertyId;
    }

    public boolean isUpdate() {
        return isUpdate;
    }

    public void setUpdate(final boolean update) {
        isUpdate = update;
    }

    public LocalDate getMoveOutDate() {
        return moveOutDate;
    }

    public void setMoveOutDate(final LocalDate moveOutDate) {
        this.moveOutDate = moveOutDate;
    }

    public LocalDate getMoveInDate() {
        return moveInDate;
    }

    public void setMoveInDate(final LocalDate moveInDate) {
        this.moveInDate = moveInDate;
    }

    public LocalDate getNewMoveOutDate() {
        return newMoveOutDate;
    }

    public void setNewMoveOutDate(final LocalDate newMoveOutDate) {
        this.newMoveOutDate = newMoveOutDate;
    }

    public LocalDate getNewMoveInDate() {
        return newMoveInDate;
    }

    public void setNewMoveInDate(final LocalDate newMoveInDate) {
        this.newMoveInDate = newMoveInDate;
    }

    public TargetAccountNumber getCallerAccountNumber() {
        return callerAccountNumber;
    }

    public void setCallerAccountNumber(final TargetAccountNumber callerAccountNumber) {
        this.callerAccountNumber = callerAccountNumber;
    }

    public boolean isChaining() {
        return isChaining;
    }

    public void setChaining(final boolean chaining) {
        isChaining = chaining;
    }

    public boolean isCaller() {
        return accountNumber.getAccountNumber().equalsIgnoreCase(callerAccountNumber.getAccountNumber());
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("operation", operation)
                .append("accountNumber", accountNumber)
                .append("callerAccountNumber", callerAccountNumber)
                .append("legalEntityId", legalEntityId)
                .append("propertyId", propertyId)
                .append("isUpdate", isUpdate)
                .append("moveOutDate", moveOutDate)
                .append("moveInDate", moveInDate)
                .append("newMoveOutDate", newMoveOutDate)
                .append("newMoveInDate", newMoveInDate)
                .append("isChaining", isChaining)
                .toString();
    }
}