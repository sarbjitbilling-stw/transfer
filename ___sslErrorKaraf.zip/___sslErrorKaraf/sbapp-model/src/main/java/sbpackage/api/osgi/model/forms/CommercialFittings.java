package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CommercialFittings {

    private FittingsList fittings;
    private float fireSprinklerFlowRate;
    private float processWaterFlowRate;


    public FittingsList getFittings() {
        return fittings;
    }

    public void setFittings(FittingsList fittings) {
        this.fittings = fittings;
    }

    public float getFireSprinklerFlowRate() {
        return fireSprinklerFlowRate;
    }

    public void setFireSprinklerFlowRate(float fireSprinklerFlowRate) {
        this.fireSprinklerFlowRate = fireSprinklerFlowRate;
    }

    public float getProcessWaterFlowRate() {
        return processWaterFlowRate;
    }

    public void setProcessWaterFlowRate(float processWaterFlowRate) {
        this.processWaterFlowRate = processWaterFlowRate;
    }
}
