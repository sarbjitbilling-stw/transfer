/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.model.account;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.Objects;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mark
 */

@XmlRootElement(name = "WSSIdentity")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WSSIdentity implements Serializable{

    @XmlElement(name = "id")
    private Long id;

    @XmlElement(name = "wssUsername")
    private String wssUsername;
    
    @XmlElement(name = "wssUserEmail")
    private String wssUserEmail;
    
    @XmlElement(name = "site")
    private String site;

    public WSSIdentity() {
    }

    public WSSIdentity(Long id, String wssUsername, String wssUserEmail) {
        this.id = id;
        this.wssUsername = wssUsername;
        this.wssUserEmail = wssUserEmail;
    }
    
    public WSSIdentity(Long id, String wssUsername, String wssUserEmail, String site) {
        this.id = id;
        this.wssUsername = wssUsername;
        this.wssUserEmail = wssUserEmail;
        this.site = site;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWssUsername() {
        return wssUsername;
    }

    public void setWssUsername(String wssUsername) {
        this.wssUsername = wssUsername;
    }

    public String getWssUserEmail() {
        return wssUserEmail;
    }

    public void setWssUserEmail(String wssUserEmail) {
        this.wssUserEmail = wssUserEmail;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.id);
        hash = 89 * hash + Objects.hashCode(this.wssUsername);
        hash = 89 * hash + Objects.hashCode(this.wssUserEmail);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final WSSIdentity other = (WSSIdentity) obj;
        if (!Objects.equals(this.wssUsername, other.wssUsername)) {
            return false;
        }
        if (!Objects.equals(this.wssUserEmail, other.wssUserEmail)) {
            return false;
        }
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "WSSIdentity{" + "id=" + id + ", wssUsername=" + wssUsername + ", wssUserEmail=" + wssUserEmail + '}';
    }
    
    
    
    

}
