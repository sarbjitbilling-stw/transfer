package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SupplyTerm {

    private int numberOfYears;
    private boolean severnTrentProposal;

    public int getNumberOfYears() {
        return numberOfYears;
    }

    public void setNumberOfYears(int numberOfYears) {
        this.numberOfYears = numberOfYears;
    }

    public boolean isSevernTrentProposal() {
        return severnTrentProposal;
    }

    public void setSevernTrentProposal(boolean severnTrentProposal) {
        this.severnTrentProposal = severnTrentProposal;
    }
}
