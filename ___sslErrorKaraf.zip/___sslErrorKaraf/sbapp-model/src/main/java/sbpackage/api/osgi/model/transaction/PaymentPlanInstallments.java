package sbpackage.api.osgi.model.transaction;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.DateAdapter;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlanInstallments {

	@JsonProperty("numOfInstallments")
	@XmlElement(name = "numOfInstallments")
	private Long numOfInstallments;

	@JsonProperty("expectedPaymentDate")
	@XmlElement(name = "expectedPaymentDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate expectedPaymentDate;

	@JsonProperty("installmentAmount")
	@XmlElement(name = "installmentAmount")
	private Float installmentAmount;

	@JsonProperty("installmentArrearsAmount")
	@XmlElement(name = "installmentArrearsAmount")
	private Float installmentArrearsAmount;

	@JsonProperty("installmentForecastAmount")
	@XmlElement(name = "installmentForecastAmount")
	private Float installmentForecastAmount;

	@JsonProperty("paidAmount")
	@XmlElement(name = "paidAmount")
	private Float paidAmount;

	@JsonProperty("balanceAmount")
	@XmlElement(name = "balanceAmount")
	private Float balanceAmount;

	@JsonProperty("paymentStatusDes")
	@XmlElement(name = "paymentStatusDes")
	private String paymentStatusDes;

	@JsonProperty("paidDate")
	@XmlElement(name = "paidDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate paidDate;

	public Long getNumOfInstallments() {
		return numOfInstallments;
	}

	public void setNumOfInstallments(Long numOfInstallments) {
		this.numOfInstallments = numOfInstallments;
	}

	public LocalDate getExpectedPaymentDate() {
		return expectedPaymentDate;
	}

	public void setExpectedPaymentDate(LocalDate expectedPaymentDate) {
		this.expectedPaymentDate = expectedPaymentDate;
	}

	public Float getInstallmentAmount() {
		return installmentAmount;
	}

	public void setInstallmentAmount(Float installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	public Float getInstallmentArrearsAmount() {
		return installmentArrearsAmount;
	}

	public void setInstallmentArrearsAmount(Float installmentArrearsAmount) {
		this.installmentArrearsAmount = installmentArrearsAmount;
	}

	public Float getInstallmentForecastAmount() {
		return installmentForecastAmount;
	}

	public void setInstallmentForecastAmount(Float installmentForecastAmount) {
		this.installmentForecastAmount = installmentForecastAmount;
	}

	public Float getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Float paidAmount) {
		this.paidAmount = paidAmount;
	}

	public Float getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public String getPaymentStatusDes() {
		return paymentStatusDes;
	}

	public void setPaymentStatusDes(String paymentStatusDes) {
		this.paymentStatusDes = paymentStatusDes;
	}

	public LocalDate getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(LocalDate paidDate) {
		this.paidDate = paidDate;
	}	
}
