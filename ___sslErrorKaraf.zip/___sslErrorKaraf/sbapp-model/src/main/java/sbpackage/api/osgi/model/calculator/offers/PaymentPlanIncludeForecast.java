package sbpackage.api.osgi.model.calculator.offers;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum PaymentPlanIncludeForecast {
    YES("Y"), NO("N"), RULE("R");

    private static final Map<String, PaymentPlanIncludeForecast> forecastIdentifierIndex = buildForecastIdentifierIndex();

    private static final Map<String, PaymentPlanIncludeForecast> buildForecastIdentifierIndex() {
        Map<String, PaymentPlanIncludeForecast> index = new HashMap<>();
        for (PaymentPlanIncludeForecast feature : PaymentPlanIncludeForecast.values()) {
            index.put(feature.getIncludeForecast().toUpperCase(), feature);
        }
        return Collections.unmodifiableMap(index);
    }

    private final String includeForecast;

    PaymentPlanIncludeForecast(String includeForecast) {
        this.includeForecast = includeForecast;
    }

    public String getIncludeForecast() {
        return includeForecast;
    }

    public static Optional<PaymentPlanIncludeForecast> fromIdentifier(String identifier) {
        String standardisedIdentifier = identifier != null ? identifier.trim().toUpperCase() : identifier;

        return Optional.ofNullable(forecastIdentifierIndex.get(standardisedIdentifier));
    }
}
