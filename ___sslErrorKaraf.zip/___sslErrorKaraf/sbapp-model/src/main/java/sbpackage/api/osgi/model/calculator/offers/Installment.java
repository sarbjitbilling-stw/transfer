package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

/**
 * Represents a payment plan installment. NB Installment with two Ls was chosen
 * for consistency with existing code, even though it's the wrong spelling for
 * the UK!
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Installment implements Serializable {

    private static final long serialVersionUID = 1L;
    private BigDecimal numOfInstallments = BigDecimal.ZERO;
    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate expectedPaymentDate;
    //AM-OUTSTANDING
    private BigDecimal installmentAmount = BigDecimal.ZERO;
    //AM-ARREARS
    private BigDecimal installmentArrearsAmount = BigDecimal.ZERO;
    //AM-FORECAST
    private BigDecimal installmentForecastAmount = BigDecimal.ZERO;
    private BigDecimal paidAmount = BigDecimal.ZERO;
    //AM-BALANCE
    private BigDecimal balanceAmount = BigDecimal.ZERO;
    private String paymentStatusDes;
    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate paidDate;

    public BigDecimal getNumOfInstallments() {
        return numOfInstallments;
    }

    public void setNumOfInstallments(BigDecimal numOfInstallments) {
        this.numOfInstallments = numOfInstallments;
    }

    public LocalDate getExpectedPaymentDate() {
        return expectedPaymentDate;
    }

    public void setExpectedPaymentDate(LocalDate expectedPaymentDate) {
        this.expectedPaymentDate = expectedPaymentDate;
    }

    public BigDecimal getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(BigDecimal installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

    public BigDecimal getInstallmentArrearsAmount() {
        return installmentArrearsAmount;
    }

    public void setInstallmentArrearsAmount(BigDecimal installmentArrearsAmount) {
        this.installmentArrearsAmount = installmentArrearsAmount;
    }

    public BigDecimal getInstallmentForecastAmount() {
        return installmentForecastAmount;
    }

    public void setInstallmentForecastAmount(BigDecimal installmentForecastAmount) {
        this.installmentForecastAmount = installmentForecastAmount;
    }

    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    public BigDecimal getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(BigDecimal balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public String getPaymentStatusDes() {
        return paymentStatusDes;
    }

    public void setPaymentStatusDes(String paymentStatusDes) {
        this.paymentStatusDes = paymentStatusDes;
    }

    public LocalDate getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(LocalDate paidDate) {
        this.paidDate = paidDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("numOfInstallments", numOfInstallments)
                .append("expectedPaymentDate", expectedPaymentDate)
                .append("installmentAmount", installmentAmount)
                .append("installmentArrearsAmount", installmentArrearsAmount)
                .append("installmentForecastAmount", installmentForecastAmount)
                .append("paidAmount", paidAmount)
                .append("balanceAmount", balanceAmount)
                .append("paymentStatusDes", paymentStatusDes)
                .append("paidDate", paidDate)
                .toString();
    }
}