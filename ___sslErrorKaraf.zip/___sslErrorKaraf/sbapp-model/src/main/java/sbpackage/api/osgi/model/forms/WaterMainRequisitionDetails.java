package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class WaterMainRequisitionDetails {

    private static final String SELECTED_OPTION_SELF_LAY_PROVIDER = "self_lay";
    private static final String YES = "yes";

    private PlanningConsent planningConsent;
    private Selection planningPermissionApplied;
    private Selection selfLayProvider;
    private Selection excavationAndBackfill;
    private OptionalNameAddress selfLayProviderDetails;
    private Selection provideOwnDesign;
    private Selection carryOutLineConnections;
    private Selection whoIsLayingServiceConnections;
    private Selection whoIsLayingServiceConnectionsSelfLay;
    private SelectionArray surfaceWaterDrainageOptions;
    private ApplicationForDischargeOfWaste applicationForDischargeOfWaste;
    private NumberOfProperties approximateNumberOfProperties;
    private SourceOfWater sourceOfWater;
    private Selection partGRegulations;
    private CommercialProperties commercialProperties;
    private PropertyTotals propertyTotals;
    private PropertyTotals propertyTotalsPhased;
    private Selection phasingDevelopment;
    private String currentStep;


    public PlanningConsent getPlanningConsent() {
        return planningConsent;
    }

    public void setPlanningConsent(PlanningConsent planningConsent) {
        this.planningConsent = planningConsent;
    }

    public Selection getPlanningPermissionApplied() {
        return planningPermissionApplied;
    }

    public void setPlanningPermissionApplied(Selection planningPermissionApplied) {
        this.planningPermissionApplied = planningPermissionApplied;
    }

    public Selection getSelfLayProvider() {
        return selfLayProvider;
    }

    public void setSelfLayProvider(Selection selfLayProvider) {
        this.selfLayProvider = selfLayProvider;
    }

    public boolean isWaterMainLayedBySelfLayProvider() {
        return selfLayProvider.getSelectedOption().equals(SELECTED_OPTION_SELF_LAY_PROVIDER);
    }

    public Selection getExcavationAndBackfill() {
        return excavationAndBackfill;
    }

    public void setExcavationAndBackfill(Selection excavationAndBackfill) {
        this.excavationAndBackfill = excavationAndBackfill;
    }

    public OptionalNameAddress getSelfLayProviderDetails() {
        return selfLayProviderDetails;
    }

    public void setSelfLayProviderDetails(OptionalNameAddress selfLayProviderDetails) {
        this.selfLayProviderDetails = selfLayProviderDetails;
    }

    public Selection getProvideOwnDesign() {
        return provideOwnDesign;
    }

    public boolean isProvideOwnDesign() {
        return provideOwnDesign != null && YES.equalsIgnoreCase(provideOwnDesign.getSelectedOption());
    }

    public void setProvideOwnDesign(Selection provideOwnDesign) {
        this.provideOwnDesign = provideOwnDesign;
    }

    public Selection getCarryOutLineConnections() {
        return carryOutLineConnections;
    }

    public void setCarryOutLineConnections(Selection carryOutLineConnections) {
        this.carryOutLineConnections = carryOutLineConnections;
    }

    public Selection getWhoIsLayingServiceConnections() {
        return whoIsLayingServiceConnections;
    }

    public void setWhoIsLayingServiceConnections(Selection whoIsLayingServiceConnections) {
        this.whoIsLayingServiceConnections = whoIsLayingServiceConnections;
    }

    public Selection getWhoIsLayingServiceConnectionsSelfLay() {
        return whoIsLayingServiceConnectionsSelfLay;
    }

    public void setWhoIsLayingServiceConnectionsSelfLay(Selection whoIsLayingServiceConnectionsSelfLay) {
        this.whoIsLayingServiceConnectionsSelfLay = whoIsLayingServiceConnectionsSelfLay;
    }

    public SelectionArray getSurfaceWaterDrainageOptions() {
        return surfaceWaterDrainageOptions;
    }

    public void setSurfaceWaterDrainageOptions(SelectionArray surfaceWaterDrainageOptions) {
        this.surfaceWaterDrainageOptions = surfaceWaterDrainageOptions;
    }

    public ApplicationForDischargeOfWaste getApplicationForDischargeOfWaste() {
        return applicationForDischargeOfWaste;
    }

    public void setApplicationForDischargeOfWaste(ApplicationForDischargeOfWaste applicationForDischargeOfWaste) {
        this.applicationForDischargeOfWaste = applicationForDischargeOfWaste;
    }

    public NumberOfProperties getApproximateNumberOfProperties() {
        return approximateNumberOfProperties;
    }

    public void setApproximateNumberOfProperties(NumberOfProperties approximateNumberOfProperties) {
        this.approximateNumberOfProperties = approximateNumberOfProperties;
    }

    public Selection getPartGRegulations() {
        return partGRegulations;
    }

    public void setPartGRegulations(Selection partGRegulations) {
        this.partGRegulations = partGRegulations;
    }

    public CommercialProperties getCommercialProperties() {
        return commercialProperties;
    }

    public void setCommercialProperties(CommercialProperties commercialProperties) {
        this.commercialProperties = commercialProperties;
    }

    public PropertyTotals getPropertyTotals() {
        return propertyTotals;
    }

    public void setPropertyTotals(PropertyTotals propertyTotals) {
        this.propertyTotals = propertyTotals;
    }

    public PropertyTotals getPropertyTotalsPhased() {
        return propertyTotalsPhased;
    }

    public void setPropertyTotalsPhased(PropertyTotals propertyTotalsPhased) {
        this.propertyTotalsPhased = propertyTotalsPhased;
    }

    public Selection getPhasingDevelopment() {
        return phasingDevelopment;
    }

    public void setPhasingDevelopment(Selection phasingDevelopment) {
        this.phasingDevelopment = phasingDevelopment;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public SourceOfWater getSourceOfWater() {
        return sourceOfWater;
    }

    public void setSourceOfWater(SourceOfWater sourceOfWater) {
        this.sourceOfWater = sourceOfWater;
    }

    public String getCategoryDescription() {
        return isWaterMainLayedBySelfLayProvider() ? "Water main SLP" : "Water main STW lay";
    }
}
