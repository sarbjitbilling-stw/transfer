package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DeveloperEnquiryWasteDetails extends DeveloperEnquiryAndPocDetails {

    private DrainageConditions drainageConditions;
    private PlanningConsent planningConsent;
    private Selection previousPropertiesWasteConnections;
    private Selection siteCouncilPlan;
    private SurfaceWaterDrainAfter surfaceWaterDrainAfter;
    private SurfaceWaterDrainBefore surfaceWaterDrainBefore;
    private SelectionArray surfaceWaterOptions;
    private Selection wasteContent;
    private ProcessWater processWaterSingle;

    public DrainageConditions getDrainageConditions() {
        return drainageConditions;
    }

    public void setDrainageConditions(DrainageConditions drainageConditions) {
        this.drainageConditions = drainageConditions;
    }

    public PlanningConsent getPlanningConsent() {
        return planningConsent;
    }

    public void setPlanningConsent(PlanningConsent planningConsent) {
        this.planningConsent = planningConsent;
    }

    public Selection getPreviousPropertiesWasteConnections() {
        return previousPropertiesWasteConnections;
    }

    public void setPreviousPropertiesWasteConnections(Selection previousPropertiesWasteConnections) {
        this.previousPropertiesWasteConnections = previousPropertiesWasteConnections;
    }

    public Selection getSiteCouncilPlan() {
        return siteCouncilPlan;
    }

    public void setSiteCouncilPlan(Selection siteCouncilPlan) {
        this.siteCouncilPlan = siteCouncilPlan;
    }

    public SurfaceWaterDrainAfter getSurfaceWaterDrainAfter() {
        return surfaceWaterDrainAfter;
    }

    public void setSurfaceWaterDrainAfter(SurfaceWaterDrainAfter surfaceWaterDrainAfter) {
        this.surfaceWaterDrainAfter = surfaceWaterDrainAfter;
    }

    public SurfaceWaterDrainBefore getSurfaceWaterDrainBefore() {
        return surfaceWaterDrainBefore;
    }

    public void setSurfaceWaterDrainBefore(SurfaceWaterDrainBefore surfaceWaterDrainBefore) {
        this.surfaceWaterDrainBefore = surfaceWaterDrainBefore;
    }

    public SelectionArray getSurfaceWaterOptions() {
        return surfaceWaterOptions;
    }

    public void setSurfaceWaterOptions(SelectionArray surfaceWaterOptions) {
        this.surfaceWaterOptions = surfaceWaterOptions;
    }

    public Selection getWasteContent() {
        return wasteContent;
    }

    public void setWasteContent(Selection wasteContent) {
        this.wasteContent = wasteContent;
    }

    public ProcessWater getProcessWaterSingle() {
        return processWaterSingle;
    }

    public void setProcessWaterSingle(ProcessWater processWaterSingle) {
        this.processWaterSingle = processWaterSingle;
    }
}
