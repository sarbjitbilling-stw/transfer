package sbpackage.api.osgi.model.util;

import org.jsoup.Jsoup;
import org.jsoup.safety.Cleaner;
import org.jsoup.safety.Whitelist;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class SanitisedTextAdaptor extends XmlAdapter<String, String> {

    @Override
    public String unmarshal(String v) {
        return new Cleaner(Whitelist.none()).clean(Jsoup.parse(v)).body().text();
    }

    @Override
    public String marshal(String v) {
        return v;
    }
}
