package sbpackage.api.osgi.model.payment.rules;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.payment.cardpayment.AccountInfo;
import sbpackage.api.osgi.model.payment.rules.PaymentRange;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;

/**
 * Fact-class to be used by rules engine for payments.
 * Created by rtai on 19/04/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentFact {

    @XmlElement(name = "accountInfo")
    private AccountInfo accountInfo;

    @XmlElement(name = "paymentAmount")
    private BigDecimal paymentAmount;

    @XmlElement(name = "paymentRange")
    private PaymentRange paymentRange;

    public PaymentFact() {}

    public AccountInfo getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public PaymentRange getPaymentRange() {
        return paymentRange;
    }

    public void setPaymentRange(PaymentRange paymentRange) {
        this.paymentRange = paymentRange;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        PaymentFact that = (PaymentFact) o;

        return new EqualsBuilder()
                .append(accountInfo, that.accountInfo)
                .append(paymentAmount, that.paymentAmount)
                .append(paymentRange, that.paymentRange)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(accountInfo)
                .append(paymentAmount)
                .append(paymentRange)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountInfo", accountInfo)
                .append("paymentAmount", paymentAmount)
                .append("paymentRange", paymentRange)
                .toString();
    }
}
