package sbpackage.api.osgi.model.inmyarea;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.CALLBACK;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.CALLBACK_VDST_IN_HOURS_NON_URGENT;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.CALLBACK_VDST_IN_HOURS_URGENT;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.ESCALATION;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.ESCALATION_OOH;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.INTERACTION;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.NOTIFICATION;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.NOTIFICATION_COMPLETED;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.PROACTIVE;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.PROACTIVE_OOH;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.REACTIVE;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.VIRTUAL_DST_CALLBACK_FORCED;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.VIRTUAL_DST_CALLBACK_NON_URGENT;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.VIRTUAL_DST_CALLBACK_URGENT;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.WORK_ORDER;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.WORK_ORDER_LINKED;
import static sbpackage.api.osgi.model.inmyarea.WorkType.Attribute.WORK_ORDER_OOH;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.APP001;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.APP004;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.APP005;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.APP006;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.APP007;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP001;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP002;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP003;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP004;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP005;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP006;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP007;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP008;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP009;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP010;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP011;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP012;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP013;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP014;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP015;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP016;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP017;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP018;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP019;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP021;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP022;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP023;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP024;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP025;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP026;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP027;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP028;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP029;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP030;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP031;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP032;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP033;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP034;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP035;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP036;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP037;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP038;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP039;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP040;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP041;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP042;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP044;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP045;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP046;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP047;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP048;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP049;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP050;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP051;
import static sbpackage.api.osgi.model.inmyarea.WorkType.EmailReference.REP060;

public enum WorkType {
    WWN1(REP001, "DM60", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER_LINKED, VIRTUAL_DST_CALLBACK_URGENT, ESCALATION, REACTIVE),
    WWN2(REP002, "DM70", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER_LINKED, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WWN3(REP003, "DM61", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER_LINKED, VIRTUAL_DST_CALLBACK_URGENT, ESCALATION, REACTIVE),
    WWN4(REP004, "DM72", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER_LINKED, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WWN4_Completed(REP050, "DM72", "DM66", INTERACTION, NOTIFICATION_COMPLETED),
    WWCO(REP005, "DM73", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, VIRTUAL_DST_CALLBACK_URGENT, ESCALATION, REACTIVE),
    WWPR(REP006, null, "DM66", INTERACTION, NOTIFICATION),
    NCML(REP007, "DM67", "DM67", INTERACTION, NOTIFICATION, PROACTIVE),
    CCML(REP008, "DM68", "DM68", INTERACTION, NOTIFICATION, PROACTIVE),
    WWPI(REP009, APP005, "DM62", "DM66", INTERACTION, NOTIFICATION, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WSPP(REP010, null, null, INTERACTION, NOTIFICATION),
    WSEI(REP011, "DM74", null, INTERACTION, NOTIFICATION, WORK_ORDER_OOH, CALLBACK_VDST_IN_HOURS_URGENT, ESCALATION_OOH, PROACTIVE_OOH, REACTIVE),
    WSIS(REP012, APP001, "DM75", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER),
    WSPS(REP013, "DM65", "DM65", INTERACTION, NOTIFICATION, CALLBACK),
    WSNS(REP014, "DM76", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER_LINKED, ESCALATION, REACTIVE),
    WSHP(REP015, "DM77", "DM65", INTERACTION, NOTIFICATION, CALLBACK),
    WSDA(REP016, "DM78", "DM66", INTERACTION, NOTIFICATION, ESCALATION, REACTIVE),
    WSNP(REP017, APP004, "DM79", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER),
    WSCS(REP018, "DM80", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, REACTIVE),
    WSCN(REP019, "DM71", "DM66", INTERACTION, NOTIFICATION, ESCALATION, REACTIVE),
    PRIF(REP021, "DM81", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    BLOT(REP022, "DM82", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    BCEL(REP023, "DM83", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    BLOP(REP024, "DM84", "DM89", INTERACTION, NOTIFICATION_COMPLETED),
    TGUL(REP028, "DM85", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    BLOC(REP025, "DM86", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    MAIN(REP026, "DM87", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    SMEL(REP027, "DM88", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    BLPF(null, null, null),
    // Water apparatus
    WACO(REP036, "DM90", "DM66", INTERACTION, NOTIFICATION, PROACTIVE_OOH),
    WA81(REP037, "DM91", "DM66", INTERACTION, NOTIFICATION, VIRTUAL_DST_CALLBACK_FORCED, VIRTUAL_DST_CALLBACK_NON_URGENT, PROACTIVE_OOH),
    WANY(REP038, "DM92", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, VIRTUAL_DST_CALLBACK_FORCED, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WA8D(REP039, "DM93", "DM66", INTERACTION, NOTIFICATION, ESCALATION, PROACTIVE_OOH),
    WACD(REP040, "DM94", "DM66", INTERACTION, NOTIFICATION, ESCALATION, PROACTIVE_OOH),
    WACN(REP041, "DM95", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, VIRTUAL_DST_CALLBACK_FORCED, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WADT(REP042, "DM96", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, VIRTUAL_DST_CALLBACK_FORCED, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WAFH(REP044, "DM98", "DM66", INTERACTION, NOTIFICATION),
    WATM(REP045, APP006, "DM99", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER),
    WATT(REP046, "DM100", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, VIRTUAL_DST_CALLBACK_FORCED, VIRTUAL_DST_CALLBACK_NON_URGENT),
    WATT_BURIED(REP060, APP007, "DM118", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER),
    WASM(REP048, "DM109", "DM66", INTERACTION, NOTIFICATION, WORK_ORDER, VIRTUAL_DST_CALLBACK_FORCED, VIRTUAL_DST_CALLBACK_URGENT),
    WAIP(REP049, null, null, INTERACTION, NOTIFICATION),
    // Waste apparatus
    MHDD(REP029, "DM101", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    MH8D(REP030, "DM102", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    MHDM(REP031, "DM103", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    MH81(REP032, "DM104", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    MHNY(REP033, "DM105", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    MHPP(REP051, null, null, INTERACTION, NOTIFICATION),
    DSIO(REP047, "DM108", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    DEFD(REP034, "DM106", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER),
    DEFS(REP035, "DM107", "DM89", INTERACTION, NOTIFICATION, WORK_ORDER);

    private Set<Attribute> attributes;
    private EmailReference emailReference;
    private EmailReference appointmentEmailReference;
    private String dmCodeSap;
    private String dmCodeOoh;

    WorkType(EmailReference emailReference, EmailReference appointmentEmailReference, String dmCodeSap, String dmCodeOoh, Attribute... attributes) {
        this(emailReference, dmCodeSap, dmCodeOoh, attributes);
        this.appointmentEmailReference = appointmentEmailReference;
    }

    WorkType(EmailReference emailReference, String dmCodeSap, String dmCodeOoh, Attribute... attributes) {
        this.attributes = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(attributes)));
        this.emailReference = emailReference;
        this.dmCodeSap = dmCodeSap;
        this.dmCodeOoh = dmCodeOoh;
    }

    public boolean hasOneOf(Attribute... attributes) {
        Set<Attribute> intersection = new HashSet<>(Arrays.asList(attributes));
        intersection.retainAll(this.attributes);
        return !intersection.isEmpty();
    }

    public boolean hasVirtualDstCallBack() {
        return hasOneOf(VIRTUAL_DST_CALLBACK_URGENT, VIRTUAL_DST_CALLBACK_NON_URGENT);
    }

    public boolean hasVirtualDstCallBackInOpeningHours() {
        return hasOneOf(CALLBACK_VDST_IN_HOURS_URGENT, CALLBACK_VDST_IN_HOURS_NON_URGENT);
    }

    public boolean hasUrgentVirtualDstSla() {
        return hasOneOf(VIRTUAL_DST_CALLBACK_URGENT, CALLBACK_VDST_IN_HOURS_URGENT);
    }

    public boolean isOneOf(WorkType... workTypes) {
        return new HashSet<>(Arrays.asList(workTypes)).contains(this);
    }

    public String getDmCodeSap() {
        return dmCodeSap;
    }

    public String getDmCodeOoh() {
        return dmCodeOoh;
    }

    public Set<Attribute> getAttributes() {
        return attributes;
    }

    public EmailReference getEmailReference() {
        return this.emailReference;
    }

    public Optional<EmailReference> getAppointmentEmailReference() {
        return Optional.ofNullable(this.appointmentEmailReference);
    }
    
    public enum Attribute {
        INTERACTION,
        NOTIFICATION,
        NOTIFICATION_COMPLETED,
        WORK_ORDER,
        WORK_ORDER_LINKED,
        WORK_ORDER_OOH,
        /** Virtual DST callback is always required it is not up to the customer. */
        VIRTUAL_DST_CALLBACK_FORCED,
        VIRTUAL_DST_CALLBACK_URGENT,
        VIRTUAL_DST_CALLBACK_NON_URGENT,
        REACTIVE,
        CALLBACK,
        CALLBACK_VDST_IN_HOURS_URGENT,
        CALLBACK_VDST_IN_HOURS_NON_URGENT,
        ESCALATION,
        ESCALATION_OOH,
        PROACTIVE,
        PROACTIVE_OOH
    }

    public enum EmailReference {
        REP001, REP002, REP003, REP004, REP005, REP006, REP007, REP008, REP009, REP010, REP011,
        REP012, REP013, REP014, REP015, REP016, REP017, REP018, REP019, REP021, REP022, REP023,
        REP024, REP025, REP026, REP027, REP028, REP029, REP030, REP031, REP032, REP033, REP034, 
        REP035, REP036, REP037, REP038, REP039, REP040, REP041, REP042, REP043, REP044, REP045, 
        REP046, REP047, REP048, REP049, REP050, REP051, REP060, APP001, APP004, APP005, APP006,
        APP007
    }
}
