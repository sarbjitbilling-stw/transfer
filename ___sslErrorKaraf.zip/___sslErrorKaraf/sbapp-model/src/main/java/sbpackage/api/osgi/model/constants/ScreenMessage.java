package sbpackage.api.osgi.model.constants;

public interface ScreenMessage {

	public static final String DM1_9 = "Sorry, you are unable to complete this transaction at this time.  Please contact us on @@websupportTelephoneNumber@@ and we will help you.";
	public static final String DM6_1 = "The email address you have provided does not match our record. Please select change details to update your email address.";
	public static final String DM6_3 = "Paperless billing service has now successfully been added to this account. Bills will no longer be sent via post. We will notify you by email when your bill is available to view on-line.";
	public static final String DM15_1 = "Thanks for the update. We'll pass the information on to our Customer Care Team, who will deal with your request within the next 5 working days.";
	public static final String DM15_2 = "Thanks for the update. All future letters and bills will be addressed to all persons responsible for payment of the account.";
	
}
