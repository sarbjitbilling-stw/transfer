package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PropertiesPreviouslyOnSite {

    private int domesticPropertyCount;
    private int commercialPropertyCount;
    private boolean dontKnowPreviousProperties;


    public int getDomesticPropertyCount() {
        return domesticPropertyCount;
    }

    public void setDomesticPropertyCount(int domesticPropertyCount) {
        this.domesticPropertyCount = domesticPropertyCount;
    }

    public int getCommercialPropertyCount() {
        return commercialPropertyCount;
    }

    public void setCommercialPropertyCount(int commercialPropertyCount) {
        this.commercialPropertyCount = commercialPropertyCount;
    }

    public boolean isDontKnowPreviousProperties() {
        return dontKnowPreviousProperties;
    }

    public void setDontKnowPreviousProperties(boolean dontKnowPreviousProperties) {
        this.dontKnowPreviousProperties = dontKnowPreviousProperties;
    }
}
