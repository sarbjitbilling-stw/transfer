package sbpackage.api.osgi.model.calculator.offers;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BudgetCalculation implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate budgetStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate budgetEndDate;

    @XmlElement
    private double upliftPercent;

    @XmlElement
    private int forecastDays;

    @XmlElement
    private double forecastValue;

    @XmlElement
    private double forecastUpliftValue;

    @XmlElement
    private int accruedDays;

    @XmlElement
    private double accruedValue;

    @XmlElement
    private double accruedUpliftValue;

    public LocalDate getBudgetStartDate() {
        return budgetStartDate;
    }

    public void setBudgetStartDate(LocalDate budgetStartDate) {
        this.budgetStartDate = budgetStartDate;
    }

    public LocalDate getBudgetEndDate() {
        return budgetEndDate;
    }

    public void setBudgetEndDate(LocalDate budgetEndDate) {
        this.budgetEndDate = budgetEndDate;
    }

    public double getUpliftPercent() {
        return upliftPercent;
    }

    public void setUpliftPercent(double upliftPercent) {
        this.upliftPercent = upliftPercent;
    }

    public int getForecastDays() {
        return forecastDays;
    }

    public void setForecastDays(int forecastDays) {
        this.forecastDays = forecastDays;
    }

    public double getForecastValue() {
        return forecastValue;
    }

    public void setForecastValue(double forecastValue) {
        this.forecastValue = forecastValue;
    }

    public double getForecastUpliftValue() {
        return forecastUpliftValue;
    }

    public void setForecastUpliftValue(double forecastUpliftValue) {
        this.forecastUpliftValue = forecastUpliftValue;
    }

    public int getAccruedDays() {
        return accruedDays;
    }

    public void setAccruedDays(int accruedDays) {
        this.accruedDays = accruedDays;
    }

    public double getAccruedValue() {
        return accruedValue;
    }

    public void setAccruedValue(double accruedValue) {
        this.accruedValue = accruedValue;
    }

    public double getAccruedUpliftValue() {
        return accruedUpliftValue;
    }

    public void setAccruedUpliftValue(double accruedUpliftValue) {
        this.accruedUpliftValue = accruedUpliftValue;
    }

}
