package sbpackage.api.osgi.model.payment.cardpayment;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Pay360Session {

    private String sessionId;
    private String merchantRef;
    private String redirectUrl;
}
