package sbpackage.api.osgi.model;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

import java.io.Serializable;
import java.time.LocalDate;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "WSSLegalEntity")
@XmlAccessorType(XmlAccessType.FIELD)
public class WSSLegalEntity  implements Serializable{

    
    @XmlElement(name = "legalEntityId")
    private String legalEntityId;

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlElement(name = "leAddedDate")
    private LocalDate leAddedDate;
    
    @XmlElement(name = "customer")
    private Customer customer;

    public WSSLegalEntity() {
    }
    
    public WSSLegalEntity(String legalEntityId) {
        this.legalEntityId = legalEntityId;
    }

    public WSSLegalEntity(String legalEntityId, LocalDate leAddedDate) {
        this.legalEntityId = legalEntityId;
        this.leAddedDate = leAddedDate;
    }
    
    public String getLegalEntityId() {
        return legalEntityId;
    }

    public void setLegalEntityId(String legalEntityId) {
        this.legalEntityId = legalEntityId;
    }

    public LocalDate getLeAddedDate() {
        return leAddedDate;
    }

    public void setLeAddedDate(LocalDate leAddedDate) {
        this.leAddedDate = leAddedDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }



}
