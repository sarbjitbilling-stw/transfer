package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BasePeriodCalculation implements Serializable {

//From the Payment Plans design doc:
//			budgetType – How the forecast was derived. This is a description text such as:
//				12 Month Bill History
//				< 12 Month Bill History
//				Manual provided Forecast
//			numberOfDaysinBasePeriod – The number of days covered by the invoices located
//			numberOfInvoices – The number of invoices considered in the forecast
//			billPeriodStartDate – The start date of the earliest bill used
//			billPeriodEndDate – The end date of the latest bill used
//			totalInvoiceAmount – the total amount of all invoices used
//			averageDailyCharge – The average daily cost
//			planStartDate – Start date of the plan
//			planEndDate – End date of the plan

    private static final long serialVersionUID = 1L;

    @XmlElement
    private String budgetType;

    @XmlElement
    private BigDecimal numberOfDaysinBasePeriod = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal numberOfInvoices = BigDecimal.ZERO;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billPeriodStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billPeriodEndDate;

    @XmlElement
    private BigDecimal totalInvoiceAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal averageDailyCharge = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal averageDailyChargeServiceProvisionLevel = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal averageDailyChargeInvoiceLevel = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal totalInvoiceDays = BigDecimal.ZERO;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate planStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate planEndDate;

    public String getBudgetType() {
        return budgetType;
    }

    public void setBudgetType(String budgetType) {
        this.budgetType = budgetType;
    }

    public BigDecimal getNumberOfDaysinBasePeriod() {
        return numberOfDaysinBasePeriod;
    }

    public void setNumberOfDaysinBasePeriod(BigDecimal numberOfDaysinBasePeriod) {
        this.numberOfDaysinBasePeriod = numberOfDaysinBasePeriod;
    }

    public BigDecimal getNumberOfInvoices() {
        return numberOfInvoices;
    }

    public void setNumberOfInvoices(BigDecimal numberOfInvoices) {
        this.numberOfInvoices = numberOfInvoices;
    }

    public LocalDate getBillPeriodStartDate() {
        return billPeriodStartDate;
    }

    public void setBillPeriodStartDate(LocalDate billPeriodStartDate) {
        this.billPeriodStartDate = billPeriodStartDate;
    }

    public LocalDate getBillPeriodEndDate() {
        return billPeriodEndDate;
    }

    public void setBillPeriodEndDate(LocalDate billPeriodEndDate) {
        this.billPeriodEndDate = billPeriodEndDate;
    }

    public BigDecimal getTotalInvoiceAmount() {
        return totalInvoiceAmount;
    }

    public void setTotalInvoiceAmount(BigDecimal totalInvoiceAmount) {
        this.totalInvoiceAmount = totalInvoiceAmount;
    }

    public BigDecimal getAverageDailyCharge() {
        return averageDailyCharge;
    }

    public void setAverageDailyCharge(BigDecimal averageDailyCharge) {
        this.averageDailyCharge = averageDailyCharge;
    }

    public LocalDate getPlanStartDate() {
        return planStartDate;
    }

    public void setPlanStartDate(LocalDate planStartDate) {
        this.planStartDate = planStartDate;
    }

    public LocalDate getPlanEndDate() {
        return planEndDate;
    }

    public void setPlanEndDate(LocalDate planEndDate) {
        this.planEndDate = planEndDate;
    }

    public BigDecimal getTotalInvoiceDays() {
        return totalInvoiceDays;
    }

    public void setTotalInvoiceDays(BigDecimal totalInvoiceDays) {
        this.totalInvoiceDays = totalInvoiceDays;
    }

    public BigDecimal getAverageDailyChargeServiceProvisionLevel() {
        return averageDailyChargeServiceProvisionLevel;
    }

    public void setAverageDailyChargeServiceProvisionLevel(BigDecimal averageDailyChargeServiceProvisionLevel) {
        this.averageDailyChargeServiceProvisionLevel = averageDailyChargeServiceProvisionLevel;
    }

    public BigDecimal getAverageDailyChargeInvoiceLevel() {
        return averageDailyChargeInvoiceLevel;
    }

    public void setAverageDailyChargeInvoiceLevel(BigDecimal averageDailyChargeInvoiceLevel) {
        this.averageDailyChargeInvoiceLevel = averageDailyChargeInvoiceLevel;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("budgetType", budgetType)
                .append("numberOfDaysinBasePeriod", numberOfDaysinBasePeriod)
                .append("numberOfInvoices", numberOfInvoices)
                .append("billPeriodStartDate", billPeriodStartDate)
                .append("billPeriodEndDate", billPeriodEndDate)
                .append("totalInvoiceAmount", totalInvoiceAmount)
                .append("averageDailyCharge", averageDailyCharge)
                .append("averageDailyChargeServiceProvisionLevel", averageDailyChargeServiceProvisionLevel)
                .append("averageDailyChargeInvoiceLevel", averageDailyChargeInvoiceLevel)
                .append("totalInvoiceDays", totalInvoiceDays)
                .append("planStartDate", planStartDate)
                .append("planEndDate", planEndDate)
                .toString();
    }
}
