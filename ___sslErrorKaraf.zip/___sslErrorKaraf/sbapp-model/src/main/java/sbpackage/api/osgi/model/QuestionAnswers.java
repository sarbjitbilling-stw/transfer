/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.model;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

/**
 *
 * @author admzphili1
 */
@XmlRootElement(name = "QuestionAnswers")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "hasMobileNumber", "mobileNumber", "hasHomeTelephone", "homeTelephoneNumber",
		"dateOfBirth", "hasActivePaymentPlan", "bankAccountNumber", "bankSortCode", "lastPaymentAmount",
		"lastPaymentDate", "previousAddress", "previousAddresses","accountNumber","postcode","legalEntity"})
public class QuestionAnswers {
	
	public QuestionAnswers() {
	}

	public QuestionAnswers(boolean hasMobileNumber, String mobileNumber, boolean hasHomeTelephone,
			String homeTelephoneNumber, Date dateOfBirth, boolean hasActivePaymentPlan, String bankAccountNumber,
			String bankSortCode, Double lastPaymentAmount, Date lastPaymentDate, Property previousAddress,
			List<Property> previousAddresses,String postcode, String legalEntity) {
		this.hasMobileNumber = hasMobileNumber;
		this.mobileNumber = mobileNumber;
		this.hasHomeTelephone = hasHomeTelephone;
		this.homeTelephoneNumber = homeTelephoneNumber;
		this.dateOfBirth = dateOfBirth;
		this.hasActivePaymentPlan = hasActivePaymentPlan;
		this.bankAccountNumber = bankAccountNumber;
		this.bankSortCode = bankSortCode;
		this.lastPaymentAmount = lastPaymentAmount;
		this.lastPaymentDate = lastPaymentDate;
		this.previousAddress = previousAddress;
		this.previousAddresses = previousAddresses;
		this.postcode = postcode;
		this.legalEntity = legalEntity;

	}

	
	@XmlElement
	private boolean hasMobileNumber = false;

	@XmlElement
	private String mobileNumber = null;

	@XmlElement
	private boolean hasHomeTelephone = false;

	@XmlElement
	private String homeTelephoneNumber = null;

	@XmlElement
	private Date dateOfBirth = null;

	@XmlElement
	private Boolean hasActivePaymentPlan = null;

	@XmlElement
	private String bankAccountNumber = null;

	@XmlElement
	private String bankSortCode = null;

	@XmlElement
	private Double lastPaymentAmount = null;

	@XmlElement
	private Date lastPaymentDate = null;

	@XmlElement
	private Property previousAddress = null;

	@XmlElement
	private List<Property> previousAddresses = null;
	
	
	@XmlElement
	private String postcode = null;
	
	@XmlElement
	private String legalEntity;
	
	@XmlElement
	private TargetAccountNumber accountNumber = null;
	

	public Boolean hasMobileNumber() {
		return hasMobileNumber;
	}

	public void setHasMobileNumber(Boolean hasMobileNumber) {
		this.hasMobileNumber = hasMobileNumber;
	}

	
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setHasMobileNumber(boolean hasMobileNumber) {
		this.hasMobileNumber = hasMobileNumber;
	}

	public void setHasHomeTelephone(boolean hasHomeTelephone) {
		this.hasHomeTelephone = hasHomeTelephone;
	}

	public Boolean hasHomeTelephone() {
		return hasHomeTelephone;
	}

	public void setHasHomeTelephone(Boolean hasHomeTelephone) {
		this.hasHomeTelephone = hasHomeTelephone;
	}

	public String getHomeTelephoneNumber() {
		return homeTelephoneNumber;
	}

	public void setHomeTelephoneNumber(String homeTelephoneNumber) {
		this.homeTelephoneNumber = homeTelephoneNumber;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Boolean hasActivePaymentPlan() {
		return hasActivePaymentPlan;
	}

	public void setHasActivePaymentPlan(Boolean hasActivePaymentPlan) {
		this.hasActivePaymentPlan = hasActivePaymentPlan;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankSortCode() {
		return bankSortCode;
	}

	public void setBankSortCode(String bankSortCode) {
		this.bankSortCode = bankSortCode;
	}

	public Double getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	public void setLastPaymentAmount(Double lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}

	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public List<Property> getPreviousAddresses() {
		return previousAddresses;
	}

	public void setPreviousAddresses(List<Property> previousAddresses) {
		this.previousAddresses = previousAddresses;
	}

	public Property getPreviousAddress() {
		return previousAddress;
	}

	public void setPreviousAddress(Property previousAddress) {
		this.previousAddress = previousAddress;
	}

	public Boolean getHasMobileNumber() {
		return hasMobileNumber;
	}

	public Boolean getHasHomeTelephone() {
		return hasHomeTelephone;
	}

	public Boolean getHasActivePaymentPlan() {
		return hasActivePaymentPlan;
	}

	

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getLegalEntity() {
		return legalEntity;
	}

	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	

	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	  public boolean equals(java.lang.Object o) {
	    if (this == o) {
	      return true;
	    }
	    if (o == null || getClass() != o.getClass()) {
	      return false;
	    }
	    QuestionAnswers questionAnswers = (QuestionAnswers) o;
	    return Objects.equals(this.hasMobileNumber, questionAnswers.hasMobileNumber) &&
	        Objects.equals(this.mobileNumber,  questionAnswers.mobileNumber) &&
	        Objects.equals(this.hasHomeTelephone, questionAnswers.hasHomeTelephone) &&
	        Objects.equals(this.homeTelephoneNumber, questionAnswers.homeTelephoneNumber) &&
	        Objects.equals(this.dateOfBirth, questionAnswers.dateOfBirth) &&
	        Objects.equals(this.hasActivePaymentPlan, questionAnswers.hasActivePaymentPlan) &&
	        Objects.equals(this.bankAccountNumber, questionAnswers.bankAccountNumber) &&
	        Objects.equals(this.bankSortCode, questionAnswers.bankSortCode)&&
	        Objects.equals(this.lastPaymentAmount, questionAnswers.lastPaymentAmount)&&
	        Objects.equals(this.lastPaymentDate, questionAnswers.lastPaymentDate)&&
	        Objects.equals(this.previousAddress, questionAnswers.previousAddress)&&
	        Objects.equals(this.previousAddresses, questionAnswers.previousAddresses)&&
	        Objects.equals(this.accountNumber, questionAnswers.accountNumber)&&
	        Objects.equals(this.postcode, questionAnswers.postcode)&&
	        Objects.equals(this.legalEntity, questionAnswers.legalEntity);
	  }

	  @Override
	public int hashCode() {

		return Objects.hash(hasMobileNumber, mobileNumber, hasHomeTelephone, homeTelephoneNumber, dateOfBirth,
				hasActivePaymentPlan, bankAccountNumber, bankSortCode, lastPaymentAmount, lastPaymentDate,
				previousAddress, previousAddresses,accountNumber,postcode,legalEntity);
	}


	  @Override
	  public String toString() {
	    final StringBuilder sb = new StringBuilder("{\"QuestionAnswers\":{");
	    sb.append("\"hasMobileNumber\":").append("\"").append(hasMobileNumber).append("\"");
        sb.append(", \"mobileNumber\":").append("\"").append(mobileNumber).append("\"");
        sb.append(", \"hasHomeTelephone\":").append("\"").append(hasHomeTelephone).append("\"");
        sb.append(", \"homeTelephoneNumber\":").append("\"").append(homeTelephoneNumber).append("\"");
        sb.append(", \"dateOfBirth\":").append("\"").append(dateOfBirth).append("\"");
        sb.append(", \"hasActivePaymentPlan\":").append("\"").append(hasActivePaymentPlan).append("\"");
        sb.append(", \"bankAccountNumber\":").append("\"").append(bankAccountNumber).append("\"");
        sb.append(", \"bankSortCode\":").append("\"").append(bankSortCode).append("\"");
        sb.append(", \"lastPaymentAmount\":").append("\"").append(lastPaymentAmount).append("\"");
        sb.append(", \"lastPaymentDate\":").append("\"").append(lastPaymentDate).append("\"");
        sb.append(", \"previousAddress\":").append(previousAddress);
        sb.append(", \"previousAddresses\":").append("\"").append(previousAddresses).append("\"");
        sb.append(", \"accountNumber\":").append("\"").append(accountNumber).append("\"");
        sb.append(", \"postcode\":").append("\"").append(postcode).append("\"");
        sb.append(", \"legalEntity\":").append("\"").append(legalEntity).append("\"");
        sb.append("}");
        sb.append("}");
        return sb.toString();
	  }
}