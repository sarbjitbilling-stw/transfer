package sbpackage.api.osgi.model.sms;

import org.apache.commons.lang3.StringUtils;

/**
 * Enum used to represent a subset of the SMS templates.
 * 
 * <p>
 * Allows templates to be separated by application (e.g. CMP) as well as finer
 * grain control too.
 */
public enum SmsTemplateGroup {
    CMP("cmp");

    private final String templateDirectoryPath;

    SmsTemplateGroup(String childDirectoryPath) {
        if (StringUtils.isBlank(childDirectoryPath)) {
            throw new IllegalArgumentException("Child directory path is blank");
        }

        templateDirectoryPath = String.format("/templates/sms/%s", childDirectoryPath);
    }

    public String getTemplateDirectoryPath() {
        return this.templateDirectoryPath;
    }

}
