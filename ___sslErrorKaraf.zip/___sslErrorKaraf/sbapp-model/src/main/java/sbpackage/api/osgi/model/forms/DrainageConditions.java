package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DrainageConditions {

    private String drainageConditions;
    private boolean noDrainageConditions;

    public String getDrainageConditions() {
        return drainageConditions;
    }

    public void setDrainageConditions(String drainageConditions) {
        this.drainageConditions = drainageConditions;
    }

    public boolean isNoDrainageConditions() {
        return noDrainageConditions;
    }

    public void setNoDrainageConditions(boolean noDrainageConditions) {
        this.noDrainageConditions = noDrainageConditions;
    }
}
