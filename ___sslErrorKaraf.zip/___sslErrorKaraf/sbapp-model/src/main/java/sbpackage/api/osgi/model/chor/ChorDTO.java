package sbpackage.api.osgi.model.chor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.Move;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.payment.common.PaymentPlan;

import javax.xml.bind.annotation.*;

/**
 * Created by tellis3 on 18/05/2017.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChorDTO", propOrder = {"newAccountNumber", "newLegalEntityId", "errorMessage", "emailAlreadyExists"})
@XmlRootElement(name = "chor")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChorDTO {

    @XmlElement(name = "newAccountNumber")
    @JsonProperty("newAccountNumber")
    private TargetAccountNumber newAccountNumber;
    @XmlElement(name = "newLegalEntityId")
    @JsonProperty("newLegalEntityId")
    private Long newLegalEntityId;
    @XmlElement(name= "errorMessage")
    @JsonProperty("errorMessage")
    private String errorMessage;
    @XmlElement(name= "emailAlreadyExists")
    @JsonProperty("emailAlreadyExists")
    private Boolean emailAlreadyExists;
    @XmlElement(name = "monthLimitRequiringDocumentation")
    @JsonProperty("monthLimitRequiringDocumentation")
    private Integer monthLimitRequiringDocumentation;
    @XmlElement(name="finalBalanceAmount")
    @JsonProperty("finalBalanceAmount")
    private Float finalBalanceAmount;
    @XmlElement(name="moveInCharges")
    @JsonProperty("moveInCharges")
    private MoveCharges moveInCharges;
    @XmlElement(name="moveOutCharges")
    @JsonProperty("moveOutCharges")
    private MoveCharges moveOutCharges;
    @XmlElement(name= "meterReadRequired")
    @JsonProperty("meterReadRequired")
    private Boolean meterReadRequired;
    @XmlElement(name= "chorSuccess")
    @JsonProperty("chorSuccess")
    private Boolean chorSuccess;
    @XmlElement(name= "planCreationFailed")
    @JsonProperty("planCreationFailed")
    private Boolean planCreationFailed;
    @XmlElement(name= "havePaymentPlan")
    @JsonProperty("havePaymentPlan")
    private boolean havePaymentPlan;
    
    @XmlElement(name= "paymentPlan")
    @JsonProperty("paymentPlan")
    private PaymentPlan paymentPlan;
    
    @XmlElement(name= "supplyType")
    @JsonProperty("supplyType")
    private String supplyType;
    
    private ChorRequest chorRequest;
    
    public String getSupplyType() {
		return supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public TargetAccountNumber getNewAccountNumber() {
        return newAccountNumber;
    }

    public void setNewAccountNumber(TargetAccountNumber newAccountNumber) {
        this.newAccountNumber = newAccountNumber;
    }

    public Long getNewLegalEntityId() {
        return newLegalEntityId;
    }

    public void setNewLegalEntityId(Long newLegalEntityId) {
        this.newLegalEntityId = newLegalEntityId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "ChorDTO{" +
                ", newAccountNumber=" + newAccountNumber +
                ", newLegalEntityId=" + newLegalEntityId +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }

    public Boolean getEmailAlreadyExists() {
        return emailAlreadyExists;
    }

    public void setEmailAlreadyExists(Boolean emailAlreadyExists) {
        this.emailAlreadyExists = emailAlreadyExists;
    }

    public Integer getMonthLimitRequiringDocumentation() {
        return monthLimitRequiringDocumentation;
    }

    public void setMonthLimitRequiringDocumentation(Integer monthLimitRequiringDocumentation) {
        this.monthLimitRequiringDocumentation = monthLimitRequiringDocumentation;
    }

    public Float getFinalBalanceAmount() {
        return finalBalanceAmount;
    }

    public void setFinalBalanceAmount(Float finalBalanceAmount) {
        this.finalBalanceAmount = finalBalanceAmount;
    }

    public MoveCharges getMoveInCharges() {
        return moveInCharges;
    }

    public void setMoveInCharges(MoveCharges moveInCharges) {
        this.moveInCharges = moveInCharges;
    }

    public Boolean getMeterReadRequired() {
        return meterReadRequired;
    }

    public void setMeterReadRequired(Boolean meterReadRequired) {
        this.meterReadRequired = meterReadRequired;
    }

    public MoveCharges getMoveOutCharges() {
        return moveOutCharges;
    }

    public void setMoveOutCharges(MoveCharges moveOutCharges) {
        this.moveOutCharges = moveOutCharges;
    }

    public Boolean isChorSuccess() {
        return chorSuccess;
    }

    public void setChorSuccess(Boolean chorSuccess) {
        this.chorSuccess = chorSuccess;
    }

    public Boolean getPlanCreationFailed() {
        return planCreationFailed;
    }

    public void setPlanCreationFailed(Boolean planCreationFailed) {
        this.planCreationFailed = planCreationFailed;
    }

	public PaymentPlan getPaymentPlan() {
		return paymentPlan;
	}

	public void setPaymentPlan(PaymentPlan paymentPlan) {
		this.paymentPlan = paymentPlan;
	}

	public boolean isHavePaymentPlan() {
		return havePaymentPlan;
	}

	public void setHavePaymentPlan(boolean havePaymentPlan) {
		this.havePaymentPlan = havePaymentPlan;
	}

    public ChorRequest getChorRequest() {
        return chorRequest;
    }

    public void setChorRequest(ChorRequest chorRequest) {
        this.chorRequest = chorRequest;
    }

}
