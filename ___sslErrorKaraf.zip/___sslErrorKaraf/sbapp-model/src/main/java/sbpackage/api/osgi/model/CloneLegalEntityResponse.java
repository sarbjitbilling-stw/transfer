package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CloneLegalEntityResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class CloneLegalEntityResponse {
	
	private String cloneLegalEnityId;

	public String getCloneLegalEnityId() {
		return cloneLegalEnityId;
	}

	public void setCloneLegalEnityId(String cloneLegalEnityId) {
		this.cloneLegalEnityId = cloneLegalEnityId;
	}

}
