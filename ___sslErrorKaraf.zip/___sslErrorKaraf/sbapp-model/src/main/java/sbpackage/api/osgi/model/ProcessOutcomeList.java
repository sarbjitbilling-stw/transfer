package sbpackage.api.osgi.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlRootElement(name = "outcome")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProcessOutcomeList {
    private static final Logger LOG = LoggerFactory.getLogger(ProcessOutcomeList.class);

    private List<ProcessOutcome> items = new ArrayList<>();

    public List<ProcessOutcome> getItems() {
        return items;
    }

    public void addOutcome(ProcessOutcome outcome) {
        if (outcome != null && StringUtils.isNotEmpty(outcome.getStepId())) {
            items.add(outcome);
        } else {
            LOG.warn("Process outcome has empty step id so not added to list");
        }
    }

    public boolean isProcessOutcomePresent(final String stepId) {
        List<ProcessOutcome> processOutcomes = getItems();
        return !CollectionUtils.isEmpty(processOutcomes) && processOutcomes.stream()
                .anyMatch(processOutcome -> processOutcome.getStepId().equalsIgnoreCase(stepId));

    }

    public void addOutcomes(List<ProcessOutcome> outcomes) {
        for (ProcessOutcome processOutcome : outcomes) {
            addOutcome(processOutcome);
        }
    }

    public void setItems(List<ProcessOutcome> outcomeList) {
        this.items = outcomeList;
    }

    @JsonProperty
    public boolean hasErrors() {
        List<ProcessOutcome> processOutcomes = getItems();
        return !CollectionUtils.isEmpty(processOutcomes) && processOutcomes.stream()
                .anyMatch(processOutcome -> processOutcome.getErrorDescription() != null);

    }

    @JsonProperty
    public boolean hasWarnings() {
        List<ProcessOutcome> processOutcomes = getItems();
        return !CollectionUtils.isEmpty(processOutcomes) && processOutcomes.stream()
                .anyMatch(processOutcome -> processOutcome.getWarningDescription() != null);

    }

}
