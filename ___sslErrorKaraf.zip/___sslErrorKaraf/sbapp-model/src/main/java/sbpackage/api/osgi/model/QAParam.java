package sbpackage.api.osgi.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement(name = "QAParam")
public class QAParam implements Serializable {

    private static final long serialVersionUID = 2020348964458395958L;

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "postcode")
    private String postcode;

    @XmlElement(name = "legalEntity")
    private String legalEntity;

    public QAParam() {
    }

    public QAParam(TargetAccountNumber accountNumber, String postcode, String legalEntity) {
        this.accountNumber = accountNumber;
        this.postcode = postcode;
        this.legalEntity = legalEntity;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public String getPostcode() {
        return postcode;
    }

    public String getLegalEntity() {
        return legalEntity;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"accountNumber\":\"").append(accountNumber).append('\"');
        sb.append(", \"postcode\":\"").append(postcode).append('\"');
        sb.append(", \"legalEntity\":\"").append(legalEntity).append('\"');
        sb.append('}');
        return sb.toString();
    }

}
