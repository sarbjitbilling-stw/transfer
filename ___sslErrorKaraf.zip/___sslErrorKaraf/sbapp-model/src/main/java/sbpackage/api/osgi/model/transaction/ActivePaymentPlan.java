package sbpackage.api.osgi.model.transaction;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;
import sbpackage.api.osgi.model.referencedata.RefData;
import sbpackage.api.osgi.model.util.DateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ActivePaymentPlan {

	@JsonProperty("payPlanNum")
	@XmlElement(name = "payPlanNum")
	private Long payPlanNum;

	@JsonProperty("payPlanType")
	@XmlElement(name = "payPlanType")
	private String payPlanType;

	@JsonProperty("accountId")
	@XmlElement(name = "accountId")
	private Long accountId;

	@JsonProperty("terminationReasonCode")
	@XmlElement(name = "terminationReasonCode")
	private RefData terminationReasonCode;

	@JsonProperty("reconciliationMethodCode")
	@XmlElement(name = "reconciliationMethodCode")
	private String reconciliationMethodCode;

	@JsonProperty("facilityCode")
	@XmlElement(name = "facilityCode")
	private RefData facilityCode;

	@JsonProperty("scheduleFreqCode")
	@XmlElement(name = "scheduleFreqCode")
	private RefData scheduleFreqCode;

	@JsonProperty("empNum")
	@XmlElement(name = "empNum")
	private Long empNum;

	@JsonProperty("payPlanComments")
	@XmlElement(name = "payPlanComments")
	private String payPlanComments;

	@JsonProperty("expectedPaymentDate")
	@XmlElement(name = "expectedPaymentDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate expectedPaymentDate;

	@JsonProperty("combinedNum")
	@XmlElement(name = "combinedNum")
	private Long combinedNum;

	@JsonProperty("invoiceNum")
	@XmlElement(name = "invoiceNum")
	private Long invoiceNum;

	@JsonProperty("interestRate")
	@XmlElement(name = "interestRate")
	private Float interestRate;

	@JsonProperty("startDate")
	@XmlElement(name = "startDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate startDate;

	@JsonProperty("scheduleBillDate")
	@XmlElement(name = "scheduleBillDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate scheduleBillDate;

	@JsonProperty("payPlanStatus")
	@XmlElement(name = "payPlanStatus")
	private RefData payPlanStatus;

	@JsonProperty("numOfExpectedPayments")
	@XmlElement(name = "numOfExpectedPayments")
	private Long numOfExpectedPayments;

	@JsonProperty("cashOnlyFlag")
	@XmlElement(name = "cashOnlyFlag")
	private String cashOnlyFlag;

	@JsonProperty("completionDate")
	@XmlElement(name = "completionDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate completionDate;

	@JsonProperty("creationTime")
	@XmlElement(name = "creationTime")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate creationTime;

	@JsonProperty("yearEndMonth")
	@XmlElement(name = "yearEndMonth")
	private Long yearEndMonth;

	@JsonProperty("preferredPayDay")
	@XmlElement(name = "preferredPayDay")
	private Long preferredPayDay;

	@JsonProperty("inceptionDate")
	@XmlElement(name = "inceptionDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate inceptionDate;

	@JsonProperty("numOfActualPayments")
	@XmlElement(name = "numOfActualPayments")
	private Long numOfActualPayments;

	@JsonProperty("nextReconciliationDate")
	@XmlElement(name = "nextReconciliationDate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate nextReconciliationDate;

	@JsonProperty("balanceAmount")
	@XmlElement(name = "balanceAmount")
	private Float balanceAmount;

	@JsonProperty("applyInterestFlag")
	@XmlElement(name = "applyInterestFlag")
	private String applyInterestFlag;

	@JsonProperty("versionNum")
	@XmlElement(name = "versionNum")
	private Long versionNum;

	@JsonProperty("reminderFlag")
	@XmlElement(name = "reminderFlag")
	private String reminderFlag;

	@JsonProperty("downPaymentAmount")
	@XmlElement(name = "downPaymentAmount")
	private Float downPaymentAmount;

	@JsonProperty("originalBalAmount")
	@XmlElement(name = "originalBalAmount")
	private Float originalBalAmount;

	@JsonProperty("budgetBalAmount")
	@XmlElement(name = "budgetBalAmount")
	private Float budgetBalAmount;

	@JsonProperty("budgetPayAmount")
	@XmlElement(name = "budgetPayAmount")
	private Float budgetPayAmount;

	@JsonProperty("planPayAmount")
	@XmlElement(name = "planPayAmount")
	private Float planPayAmount;

	@JsonProperty("orgNum")
	@XmlElement(name = "orgNum")
	private Long orgNum;

	@JsonProperty("budgetPlanType")
	@XmlElement(name = "budgetPlanType")
	private RefData budgetPlanType;

	@JsonProperty("numOfInstallments")
	@XmlElement(name = "numOfInstallments")
	private Long numOfInstallments;

	@JsonProperty("totalBudgetAmount")
	@XmlElement(name = "totalBudgetAmount")
	private Float totalBudgetAmount;

	@JsonProperty("thirdPartyAmount")
	@XmlElement(name = "thirdPartyAmount")
	private Float thirdPartyAmount;

	@JsonProperty("installmentAmount")
	@XmlElement(name = "installmentAmount")
	private Float installmentAmount;

	@JsonProperty("origTotalBudgetAmount")
	@XmlElement(name = "origTotalBudgetAmount")
	private Float origTotalBudgetAmount;

	@JsonProperty("conditionalFlag")
	@XmlElement(name = "conditionalFlag")
	private boolean conditionalFlag;

	@JsonProperty("combinedName")
	@XmlElement(name = "combinedName")
	private String combinedName;  

	@JsonProperty("transactionType")
	@XmlElement(name = "transactionType")
	private String transactionType;

	@JsonProperty("paymentPlanDetails")
	@XmlElement(name = "paymentPlanDetails")
	private PaymentPlanDetails paymentPlanDetails;

	@JsonProperty("paymentPlanInstallmentsList")
	@XmlElement(name = "paymentPlanInstallmentsList")
	private List<PaymentPlanInstallments> paymentPlanInstallmentsList;

	public Long getPayPlanNum() {
		return payPlanNum;
	}

	public void setPayPlanNum(Long payPlanNum) {
		this.payPlanNum = payPlanNum;
	}

	public String getPayPlanType() {
		return payPlanType;
	}

	public void setPayPlanType(String payPlanType) {
		this.payPlanType = payPlanType;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public RefData getTerminationReasonCode() {
		return terminationReasonCode;
	}

	public void setTerminationReasonCode(RefData terminationReasonCode) {
		this.terminationReasonCode = terminationReasonCode;
	}

	public String getReconciliationMethodCode() {
		return reconciliationMethodCode;
	}

	public void setReconciliationMethodCode(String reconciliationMethodCode) {
		this.reconciliationMethodCode = reconciliationMethodCode;
	}

	public RefData getFacilityCode() {
		return facilityCode;
	}

	public void setFacilityCode(RefData facilityCode) {
		this.facilityCode = facilityCode;
	}

	public RefData getScheduleFreqCode() {
		return scheduleFreqCode;
	}

	public void setScheduleFreqCode(RefData scheduleFreqCode) {
		this.scheduleFreqCode = scheduleFreqCode;
	}

	public Long getEmpNum() {
		return empNum;
	}

	public void setEmpNum(Long empNum) {
		this.empNum = empNum;
	}

	public String getPayPlanComments() {
		return payPlanComments;
	}

	public void setPayPlanComments(String payPlanComments) {
		this.payPlanComments = payPlanComments;
	}

	public LocalDate getExpectedPaymentDate() {
		return expectedPaymentDate;
	}

	public void setExpectedPaymentDate(LocalDate expectedPaymentDate) {
		this.expectedPaymentDate = expectedPaymentDate;
	}

	public Long getCombinedNum() {
		return combinedNum;
	}

	public void setCombinedNum(Long combinedNum) {
		this.combinedNum = combinedNum;
	}

	public Long getInvoiceNum() {
		return invoiceNum;
	}

	public void setInvoiceNum(Long invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public Float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Float interestRate) {
		this.interestRate = interestRate;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getScheduleBillDate() {
		return scheduleBillDate;
	}

	public void setScheduleBillDate(LocalDate scheduleBillDate) {
		this.scheduleBillDate = scheduleBillDate;
	}

	public RefData getPayPlanStatus() {
		return payPlanStatus;
	}

	public void setPayPlanStatus(RefData payPlanStatus) {
		this.payPlanStatus = payPlanStatus;
	}

	public Long getNumOfExpectedPayments() {
		return numOfExpectedPayments;
	}

	public void setNumOfExpectedPayments(Long numOfExpectedPayments) {
		this.numOfExpectedPayments = numOfExpectedPayments;
	}

	public String getCashOnlyFlag() {
		return cashOnlyFlag;
	}

	public void setCashOnlyFlag(String cashOnlyFlag) {
		this.cashOnlyFlag = cashOnlyFlag;
	}

	public LocalDate getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(LocalDate completionDate) {
		this.completionDate = completionDate;
	}

	public LocalDate getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(LocalDate creationTime) {
		this.creationTime = creationTime;
	}

	public Long getYearEndMonth() {
		return yearEndMonth;
	}

	public void setYearEndMonth(Long yearEndMonth) {
		this.yearEndMonth = yearEndMonth;
	}

	public Long getPreferredPayDay() {
		return preferredPayDay;
	}

	public void setPreferredPayDay(Long preferredPayDay) {
		this.preferredPayDay = preferredPayDay;
	}

	public LocalDate getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(LocalDate inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public Long getNumOfActualPayments() {
		return numOfActualPayments;
	}

	public void setNumOfActualPayments(Long numOfActualPayments) {
		this.numOfActualPayments = numOfActualPayments;
	}

	public LocalDate getNextReconciliationDate() {
		return nextReconciliationDate;
	}

	public void setNextReconciliationDate(LocalDate nextReconciliationDate) {
		this.nextReconciliationDate = nextReconciliationDate;
	}

	public Float getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public String getApplyInterestFlag() {
		return applyInterestFlag;
	}

	public void setApplyInterestFlag(String applyInterestFlag) {
		this.applyInterestFlag = applyInterestFlag;
	}

	public Long getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(Long versionNum) {
		this.versionNum = versionNum;
	}

	public String getReminderFlag() {
		return reminderFlag;
	}

	public void setReminderFlag(String reminderFlag) {
		this.reminderFlag = reminderFlag;
	}

	public Float getDownPaymentAmount() {
		return downPaymentAmount;
	}

	public void setDownPaymentAmount(Float downPaymentAmount) {
		this.downPaymentAmount = downPaymentAmount;
	}

	public Float getOriginalBalAmount() {
		return originalBalAmount;
	}

	public void setOriginalBalAmount(Float originalBalAmount) {
		this.originalBalAmount = originalBalAmount;
	}

	public Float getBudgetBalAmount() {
		return budgetBalAmount;
	}

	public void setBudgetBalAmount(Float budgetBalAmount) {
		this.budgetBalAmount = budgetBalAmount;
	}

	public Float getBudgetPayAmount() {
		return budgetPayAmount;
	}

	public void setBudgetPayAmount(Float budgetPayAmount) {
		this.budgetPayAmount = budgetPayAmount;
	}

	public Float getPlanPayAmount() {
		return planPayAmount;
	}

	public void setPlanPayAmount(Float planPayAmount) {
		this.planPayAmount = planPayAmount;
	}

	public Long getOrgNum() {
		return orgNum;
	}

	public void setOrgNum(Long orgNum) {
		this.orgNum = orgNum;
	}

	public RefData getBudgetPlanType() {
		return budgetPlanType;
	}

	public void setBudgetPlanType(RefData budgetPlanType) {
		this.budgetPlanType = budgetPlanType;
	}

	public Long getNumOfInstallments() {
		return numOfInstallments;
	}

	public void setNumOfInstallments(Long numOfInstallments) {
		this.numOfInstallments = numOfInstallments;
	}

	public Float getTotalBudgetAmount() {
		return totalBudgetAmount;
	}

	public void setTotalBudgetAmount(Float totalBudgetAmount) {
		this.totalBudgetAmount = totalBudgetAmount;
	}

	public Float getThirdPartyAmount() {
		return thirdPartyAmount;
	}

	public void setThirdPartyAmount(Float thirdPartyAmount) {
		this.thirdPartyAmount = thirdPartyAmount;
	}

	public Float getInstallmentAmount() {
		return installmentAmount;
	}

	public void setInstallmentAmount(Float installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	public Float getOrigTotalBudgetAmount() {
		return origTotalBudgetAmount;
	}

	public void setOrigTotalBudgetAmount(Float origTotalBudgetAmount) {
		this.origTotalBudgetAmount = origTotalBudgetAmount;
	}

	public boolean getConditionalFlag() {
		return conditionalFlag;
	}

	public void setConditionalFlag(boolean conditionalFlag) {
		this.conditionalFlag = conditionalFlag;
	}

	public String getCombinedName() {
		return combinedName;
	}

	public void setCombinedName(String combinedName) {
		this.combinedName = combinedName;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public PaymentPlanDetails getPaymentPlanDetails() {
		return paymentPlanDetails;
	}

	public void setPaymentPlanDetails(PaymentPlanDetails paymentPlanDetails) {
		this.paymentPlanDetails = paymentPlanDetails;
	}	

	public List<PaymentPlanInstallments> getPaymentPlanInstallmentsList() {
		return paymentPlanInstallmentsList;
	}

	public void setPaymentPlanInstallmentsList(List<PaymentPlanInstallments> paymentPlanInstallmentsList) {
		this.paymentPlanInstallmentsList = paymentPlanInstallmentsList;
	}

}
