package sbpackage.api.osgi.model.payment.directdebit;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
/**
 * Created by zphilip on 12/12/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlanPermissions implements Serializable {

    @XmlElement(name = "canUserCreate")
    private  PaymentScheduleUserAction canUserCreate;

    @XmlElement(name = "canUserAmend")
    private  PaymentScheduleUserAction canUserAmend;

    @XmlElement(name = "canUserCancel")
    private  PaymentScheduleUserAction canUserCancel;

    @XmlElement(name = "canUserView")
    private  PaymentScheduleUserAction canUserView;
    
    @XmlElement(name = "canUserChangeBankDetail")
    private PaymentScheduleUserAction canUserChangeBankDetail;
	
	@XmlElement(name = "canUserChangePaymentDate")
    private PaymentScheduleUserAction canUserChangePaymentDate;
	
	@XmlElement(name = "canUserChangePaymentAmount")
    private PaymentScheduleUserAction canUserChangePaymentAmount;
	
	@XmlElement(name = "canUserChangePaymentMethod")
    private PaymentScheduleUserAction canUserChangePaymentMethod;

    public PaymentScheduleUserAction getCanUserCreate() {
        return canUserCreate;
    }

    public void setCanUserCreate(PaymentScheduleUserAction canUserCreate) {
        this.canUserCreate = canUserCreate;
    }

    public PaymentScheduleUserAction getCanUserAmend() {
        return canUserAmend;
    }

    public void setCanUserAmend(PaymentScheduleUserAction canUserAmend) {
        this.canUserAmend = canUserAmend;
    }

    public PaymentScheduleUserAction getCanUserCancel() {
        return canUserCancel;
    }

    public void setCanUserCancel(PaymentScheduleUserAction canUserCancel) {
        this.canUserCancel = canUserCancel;
    }

    public PaymentScheduleUserAction getCanUserView() {
        return canUserView;
    }

    public void setCanUserView(PaymentScheduleUserAction canUserView) {
        this.canUserView = canUserView;
    }
    
    
    public PaymentScheduleUserAction getCanUserChangeBankDetail() {
		return canUserChangeBankDetail;
	}

	public void setCanUserChangeBankDetail(PaymentScheduleUserAction canUserChangeBankDetail) {
		this.canUserChangeBankDetail = canUserChangeBankDetail;
	}

	public PaymentScheduleUserAction getCanUserChangePaymentDate() {
		return canUserChangePaymentDate;
	}

	public void setCanUserChangePaymentDate(PaymentScheduleUserAction canUserChangePaymentDate) {
		this.canUserChangePaymentDate = canUserChangePaymentDate;
	}

	public PaymentScheduleUserAction getCanUserChangePaymentAmount() {
		return canUserChangePaymentAmount;
	}

	public void setCanUserChangePaymentAmount(PaymentScheduleUserAction canUserChangePaymentAmount) {
		this.canUserChangePaymentAmount = canUserChangePaymentAmount;
	}

	public PaymentScheduleUserAction getCanUserChangePaymentMethod() {
		return canUserChangePaymentMethod;
	}

	public void setCanUserChangePaymentMethod(PaymentScheduleUserAction canUserChangePaymentMethod) {
		this.canUserChangePaymentMethod = canUserChangePaymentMethod;
	}
	
	
    @Override
    public String toString() {
        return new ToStringBuilder(this)
            .append("canUserCreate", canUserCreate)
            .append("canUserAmend", canUserAmend)
            .append("canUserCancel", canUserCancel)
            .append("canUserView", canUserView)
            .append("canUserChangeBankDetail", canUserChangeBankDetail)
            .append("canUserChangPaymentDate", canUserChangePaymentDate)
            .append("canUserChangPaymentAmount", canUserChangePaymentAmount)
            .append("canUserChangPaymentMethod", canUserChangePaymentMethod)    
            .toString();
    }


}
