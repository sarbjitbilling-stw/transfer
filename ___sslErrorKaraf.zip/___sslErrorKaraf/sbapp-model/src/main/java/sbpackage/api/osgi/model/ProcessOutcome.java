package sbpackage.api.osgi.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

@XmlRootElement(name = "item")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProcessOutcome implements Serializable {
    private String stepId;
    private String description;
    private String errorDescription;
    private String warningDescription;
    private String path;
    private String exceptionMessage;
    private String targetReturnCode;
    private String targetReasonText;

    public String getStepId() {
        return stepId;
    }

    public void setStepId(String stepId) {
        this.stepId = stepId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    @JsonIgnore
    public boolean hasError() {
        return StringUtils.isNotEmpty(errorDescription) || StringUtils.isNotEmpty(exceptionMessage);
    }

    public String getWarningDescription() {
        return warningDescription;
    }

    public void setWarningDescription(final String warningDescription) {
        this.warningDescription = warningDescription;
    }

    @JsonIgnore
    public boolean hasWarning() {
        return StringUtils.isNotEmpty(warningDescription);
    }

    public String getTargetReturnCode() {
        return targetReturnCode;
    }

    public void setTargetReturnCode(String targetReturnCode) {
        this.targetReturnCode = targetReturnCode;
    }

    public String getTargetReasonText() {
        return targetReasonText;
    }

    public void setTargetReasonText(String targetReasonText) {
        this.targetReasonText = targetReasonText;
    }
}
