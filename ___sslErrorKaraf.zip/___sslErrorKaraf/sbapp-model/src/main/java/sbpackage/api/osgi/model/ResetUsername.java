package sbpackage.api.osgi.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import sbpackage.api.osgi.model.common.HypermediaDto;

/**
 * Created by .
 */
@XmlRootElement(name = "ResetUsername")
@XmlAccessorType(XmlAccessType.FIELD)
public class ResetUsername extends HypermediaDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResetUsername() {
    }

    public ResetUsername(String email, boolean emailAddressLocated) {
        this.email = email;
        this.emailAddressLocated = emailAddressLocated;
    }

    public ResetUsername(String email, boolean emailAddressLocated, Message message) {
		this.email = email;
		this.emailAddressLocated = emailAddressLocated;
		this.message = message;
	}
    
    public ResetUsername(String email,boolean loginWithEmail,boolean emailAddressLocated, Message message) {
        this.email = email;
        this.loginWithEmail = loginWithEmail;
        this.emailAddressLocated = emailAddressLocated;
        this.message = message;
    }

    @XmlElement
    private String email;
 
    @XmlElement
    private boolean emailAddressLocated;
    
    @XmlElement
    public List<String> usernames;

    @XmlElement
    private Message message;

    @XmlElement
    private String code;
    
    @XmlElement
    private boolean loginWithEmail;

    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isEmailAddressLocated() {
		return emailAddressLocated;
	}

	public void setEmailAddressLocated(boolean emailAddressLocated) {
		this.emailAddressLocated = emailAddressLocated;
	}
	

	public List<String> getUsernames() {
		return usernames;
	}

	public void setUsernames(List<String> usernames) {
		this.usernames = usernames;
	}


	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
    public boolean isLoginWithEmail() {
        return loginWithEmail;
    }

    public void setLoginWithEmail(boolean loginWithEmail) {
        this.loginWithEmail = loginWithEmail;
    }
    

	@Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ResetUsername{");
        sb.append(", email='").append(email).append('\'');
        sb.append(", loginWithEmail='").append(loginWithEmail).append('\'');
        sb.append(", emailAddressLocated='").append(emailAddressLocated).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append(", code='").append(code).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + (emailAddressLocated ? 1231 : 1237);
		result = prime * result + (loginWithEmail ? 1231 : 1237);
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResetUsername other = (ResetUsername) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (emailAddressLocated != other.emailAddressLocated)
			return false;
	    if (loginWithEmail != other.loginWithEmail)
	            return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		return true;
	}
}
