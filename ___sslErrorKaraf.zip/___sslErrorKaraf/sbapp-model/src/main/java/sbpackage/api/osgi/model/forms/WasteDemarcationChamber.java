package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class WasteDemarcationChamber {

    private int demarcationChamberSize;
    private String demarcationChamberMaterial;

    public int getDemarcationChamberSize() {
        return demarcationChamberSize;
    }

    public void setDemarcationChamberSize(int demarcationChamberSize) {
        this.demarcationChamberSize = demarcationChamberSize;
    }

    public String getDemarcationChamberMaterial() {
        return demarcationChamberMaterial;
    }

    public void setDemarcationChamberMaterial(String demarcationChamberMaterial) {
        this.demarcationChamberMaterial = demarcationChamberMaterial;
    }
}
