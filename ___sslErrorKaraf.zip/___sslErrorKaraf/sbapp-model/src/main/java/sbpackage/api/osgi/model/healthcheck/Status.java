package sbpackage.api.osgi.model.healthcheck;

public enum Status {
    SUCCESS, FAILURE
}
