package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SupplyDetailsByYearDetails {

    private PropertyCount numberOfProperties;
    private Selection processWater;
    private YearSelect yearSelect;
    private Usage domesticDetailsEntry;
    private Usage commercialDetailsEntry;
    private Usage processWaterDetailsEntry;

    public Selection getProcessWater() {
        return processWater;
    }

    public void setProcessWater(Selection processWater) {
        this.processWater = processWater;
    }

    public YearSelect getYearSelect() {
        return yearSelect;
    }

    public void setYearSelect(YearSelect yearSelect) {
        this.yearSelect = yearSelect;
    }

    public Usage getDomesticDetailsEntry() {
        return domesticDetailsEntry;
    }

    public void setDomesticDetailsEntry(Usage domesticDetailsEntry) {
        this.domesticDetailsEntry = domesticDetailsEntry;
    }

    public Usage getCommercialDetailsEntry() {
        return commercialDetailsEntry;
    }

    public void setCommercialDetailsEntry(Usage commercialDetailsEntry) {
        this.commercialDetailsEntry = commercialDetailsEntry;
    }

    public String getProcessWaterDisplayValue() {
        return processWater.getSelectedOptionDisplayValue();
    }

    public Usage getProcessWaterDetailsEntry() {
        return processWaterDetailsEntry;
    }

    public void setProcessWaterDetailsEntry(Usage processWaterDetailsEntry) {
        this.processWaterDetailsEntry = processWaterDetailsEntry;
    }

    public PropertyCount getNumberOfProperties() {
        return numberOfProperties;
    }

    public void setNumberOfProperties(PropertyCount numberOfProperties) {
        this.numberOfProperties = numberOfProperties;
    }
}
