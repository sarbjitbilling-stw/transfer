package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EstimatedWaterUsage {

    private String estimatedUsagePeriod;
    private String estimatedUsagePeriodDisplayValue;
    private String otherUsagePeriod;

    public String getEstimatedUsagePeriod() {
        return estimatedUsagePeriod;
    }

    public void setEstimatedUsagePeriod(String estimatedUsagePeriod) {
        this.estimatedUsagePeriod = estimatedUsagePeriod;
    }

    public String getEstimatedUsagePeriodDisplayValue() {
        return estimatedUsagePeriodDisplayValue;
    }

    public void setEstimatedUsagePeriodDisplayValue(String estimatedUsagePeriodDisplayValue) {
        this.estimatedUsagePeriodDisplayValue = estimatedUsagePeriodDisplayValue;
    }

    public String getOtherUsagePeriod() {
        return otherUsagePeriod;
    }

    public void setOtherUsagePeriod(String otherUsagePeriod) {
        this.otherUsagePeriod = otherUsagePeriod;
    }
}
