package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Possible codes:
 * P PPC
 * U Unmeasured
 * C Combination (Measured with Arrears)
 * E Equalized (Measured without Arrears)
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BudgetPlanType implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String VALUESET = "176";
	
	public BudgetPlanType() {}
	
	public BudgetPlanType(String value, String code) {
		this.value = value;
		this.code = code;
		this.valueSet = VALUESET;
	}

	@XmlElement
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String value;

	@XmlElement
	private String code;
	
	@XmlElement
	private String valueSet;
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getValueSet() {
		return valueSet;
	}
	public void setValueSet(String valueSet) {
		this.valueSet = valueSet;
	}
	
}
