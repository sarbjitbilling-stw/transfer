package sbpackage.api.osgi.model.metering;

import java.io.Serializable;

public class MeterReadTypeRefData implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String VALUESET = "98";

    public MeterReadTypeRefData() {
    }

    public MeterReadTypeRefData(String value, String code) {
        this.value = value;
        this.code = code;
        this.valueSet = VALUESET;
    }

    private String value;
    private String code;
    private String valueSet;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValueSet() {
        return valueSet;
    }

    public void setValueSet(String valueSet) {
        this.valueSet = valueSet;
    }

}
