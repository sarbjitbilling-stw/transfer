package sbpackage.api.osgi.model.common;

import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlRootElement(name = "error")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorDto {

    /**
     * The transaction Id that may be used to trace the request in the logs.
     */
    @XmlElement
    private String transactionId;

    /**
     * The error code.
     */
    @XmlElement
    private String code;

    /**
     * The textual description of the error.
     */
    @XmlElement
    private String description;

    /**
     * The category of the error
     */
    @XmlElement
    private ErrorCategory category;

    /**
     * Additional details of the error.
     */
    private Map<String, Object> details;

    @XmlTransient
    private static final String UNKNOWN = "UNKNOWN";

    public static final String MESSAGE_KEY = "messageKey";

    private static final String GLOBAL_MESSAGE = "An error occurred";

    ErrorDto() {
    }

    public ErrorDto(int code, String description) {
        init(ErrorCategory.STW_SERVICES, String.valueOf(code), description);
    }

    public ErrorDto(String code, String description) {
        init(ErrorCategory.STW_SERVICES, code, description);
    }

    public ErrorDto(ErrorCategory category, int code, String description) {
        init(category, String.valueOf(code), description);
    }

    public ErrorDto(ErrorCategory category, String code, String description) {
        init(category, code, description);
    }

    private void init(ErrorCategory category, String code, String description) {
        this.category = category;
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public ErrorCategory getCategory() {
        return category;
    }

    public Map<String, Object> getDetails() {
        return details;
    }

    public void setDetails(Map<String, Object> details) {
        this.details = details;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ErrorDto errorDto = (ErrorDto) o;

        return new EqualsBuilder()
                .append(transactionId, errorDto.transactionId)
                .append(code, errorDto.code)
                .append(description, errorDto.description)
                .append(category, errorDto.category)
                .append(details, errorDto.details)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(transactionId)
                .append(code)
                .append(description)
                .append(category)
                .append(details)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("transactionId", transactionId)
                .append("code", code)
                .append("description", description)
                .append("category", category)
                .append("details", details)
                .toString();
    }

    @XmlEnum
    @XmlType(name = "category")
    public enum ErrorCategory {
        // @formatter:off
        STW_SERVICES,
        TARGET,
        ACCOUNT_SERVICES,
        ANALYTICS_SERVICES,
        AUTH_SERVICES,
        AUDIT_SERVICES,
        CHOR_SERVICES,
        RE_CHOR_SERVICES,
        CUSTOMER_SERVICES,
        ELIGIBILITY_SERVICES,
        EMAIL_SERVICES,
        LOCATION_SERVICES,
        METERING_SERVICES,
        PAYMENT_SERVICES,
        PROPERTY_SERVICES,
        REFERENCE_DATA_SERVICES,
        REGISTRATION_SERVICES,
        SPECIAL_CONDITIONS,
        SYSTEM_POLICY_SERVICES,
        USERDB_PROVIDER,
        BILLCOPY_SERVICES,
        BILL_SERVICES,
        OFFERS_CALCULATOR_SERVICES,
        RV_CALCULATOR,
        INCIDENTS_NEARME_SERVICES,
        PAYMENT_METHOD_SERVICES,
        INCIDENT_LIST_SERVICES,
        PROBATE_SERVICES,
        TEMPLATE_SERVICES,
        SMS_SERVICES,
        SAP_PI_CLIENT,
        SAP_GATEWAY_CLIENT,
        MESSAGE_QA_SERVICES,
        WATERDIRECT_CALCULATOR,
        PAYMENT_INFO_SERVICES,
        BATCH_SERVICES,
        BDS_CALCULATOR,
        CALCULATOR_SERVICES,
        JOB_BOOKING,
        MEASURED_CALCULATOR,
        WATER_EFFICIENCY,
        CALL_WRAP,
        USER_PREFERENCE,
        SOCIAL_LOGIN
        // @formatter:on
    }
}
