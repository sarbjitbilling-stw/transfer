package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * Created by rtai on 09/02/2017.
 */
@XmlRootElement(name = "UsernamePasswordToken")
public class UsernamePasswordToken implements Serializable {
    @XmlElement(name = "loginType")
    private LoginType loginType;

    @XmlElement(name = "username")
    private String username;

    @XmlElement(name = "password")
    private String password;

    @XmlElement(name = "socialProvider")
    private SocialProviderType socialProvider;

    @XmlElement(name = "socialId")
    private String socialId;

    @XmlElement(name = "site")
    private String site;

    public UsernamePasswordToken() {
        // Default constructor necessary.
    }

    public UsernamePasswordToken(String username, String password, LoginType loginType, String site) {
        this.username = username;
        this.password = password;
        this.loginType = loginType;
        this.site = site;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public SocialProviderType getSocialProvider() {
        return this.socialProvider;
    }

    public String getSocialId() {
        return this.socialId;
    }

    public LoginType getLoginType() {
        return loginType;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }
}
