package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public abstract class DeveloperEnquiryAndPocDetails {

    public static final String PHASING_DEVELOPMENT_PHASED = "no";
    public static final String PHASING_DEVELOPMENT_SINGLE = "yes";
    private PropertyTotals propertyTotals;
    private DeveloperPhases developerPhases;
    private Selection phasingDevelopment;
    private String currentStep;

    public DeveloperPhases getDeveloperPhases() {
        return developerPhases;
    }

    public void setDeveloperPhases(DeveloperPhases developerPhases) {
        this.developerPhases = developerPhases;
    }

    public PropertyTotals getPropertyTotals() {
        return propertyTotals;
    }

    public void setPropertyTotals(PropertyTotals propertyTotals) {
        this.propertyTotals = propertyTotals;
    }

    public Selection getPhasingDevelopment() {
        return phasingDevelopment;
    }

    public void setPhasingDevelopment(Selection phasingDevelopment) {
        this.phasingDevelopment = phasingDevelopment;
    }

    public int getPropertyCount() {
        if(isPhased()) {
            return developerPhases.getPropertyCount();
        } else if(propertyTotals != null) {
            return propertyTotals.getPropertyCount();
        } else {
            return 0;
        }
    }

    public boolean isAtLeastOnePropertyCommercial() {
        if(isPhased()) {
            return developerPhases.isAtLeastOnePropertyCommercial();
        } else if(propertyTotals != null) {
            return propertyTotals.isAtLeastOnePropertyCommercial();
        } else return false;
    }

    public boolean isPhased() {
        return PHASING_DEVELOPMENT_PHASED.equals(phasingDevelopment.getSelectedOption()) ;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }
}
