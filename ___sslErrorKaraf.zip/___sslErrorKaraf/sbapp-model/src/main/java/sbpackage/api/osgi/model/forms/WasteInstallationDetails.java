package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
public class WasteInstallationDetails {

    private Details principalContractorDetails;
    private Selection privatePumping;
    private SurfaceConnectionsList surfaceConnectionsOnlyOne;
    private String currentStep;

    public Details getPrincipalContractorDetails() {
        return principalContractorDetails;
    }

    public void setPrincipalContractorDetails(Details principalContractorDetails) {
        this.principalContractorDetails = principalContractorDetails;
    }

    public Selection getPrivatePumping() {
        return privatePumping;
    }

    public void setPrivatePumping(Selection privatePumping) {
        this.privatePumping = privatePumping;
    }

    public SurfaceConnectionsList getSurfaceConnectionsOnlyOne() {
        return surfaceConnectionsOnlyOne;
    }

    public void setSurfaceConnectionsOnlyOne(SurfaceConnectionsList surfaceConnectionsOnlyOne) {
        this.surfaceConnectionsOnlyOne = surfaceConnectionsOnlyOne;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }
}
