package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.ToStringBuilder;

@XmlRootElement(name = "ServiceProvisionTariff")
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceProvisionTariff {

    @XmlElement
    private int serviceProvisionNum;

    @XmlElement
    private String tariffCode;

    @XmlElement
    private String revenueClassCode;

    public int getServiceProvisionNum() {
        return serviceProvisionNum;
    }

    public void setServiceProvisionNum(final int serviceProvisionNum) {
        this.serviceProvisionNum = serviceProvisionNum;
    }

    public String getTariffCode() {
        return tariffCode;
    }

    public void setTariffCode(final String tariffCode) {
        this.tariffCode = tariffCode;
    }

    public String getRevenueClassCode() {
        return revenueClassCode;
    }

    public void setRevenueClassCode(String revenueClassCode) {
        this.revenueClassCode = revenueClassCode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("serviceProvisionNum", serviceProvisionNum)
                .append("tariffCode", tariffCode)
                .toString();
    }
}
