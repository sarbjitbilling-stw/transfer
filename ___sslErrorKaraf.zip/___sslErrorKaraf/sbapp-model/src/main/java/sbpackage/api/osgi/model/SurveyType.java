package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlList;

/**
 * Created by rtai on 14/02/2017.
 */
@XmlEnum
public enum SurveyType {
    @XmlEnumValue("REGISTER")
    REGISTER,
    @XmlEnumValue("NEW_CUSTOMER")
    NEW_CUSTOMER,
    @XmlEnumValue("MOVING_HOUSE")
    MOVING_HOUSE,
    @XmlEnumValue("ENTER_METER_READING")
    ENTER_METER_READING,
    @XmlEnumValue("ENTER_METER_READING_ESTIMATED_CHOR")
    ENTER_METER_READING_ESTIMATED_CHOR,
    @XmlEnumValue("MAKE_PAYMENT")
    MAKE_PAYMENT,
    @XmlEnumValue("MANAGE_WATERCARD")
    MANAGE_WATERCARD,
    @XmlEnumValue("REGULAR_PAYMENT_DD")
    REGULAR_PAYMENT_DD,
    @XmlEnumValue("REGULAR_PAYMENT_WC")
    REGULAR_PAYMENT_WC,
    @XmlEnumValue("REGULAR_PAYMENT_DEMAND")
    REGULAR_PAYMENT_DEMAND,
    @XmlEnumValue("AMEND_NAMES")
    AMEND_NAMES,
    @XmlEnumValue("AMEND_ACCOUNTS")
    AMEND_ACCOUNTS,
    @XmlEnumValue("APPLY_WATER_METER")
    APPLY_WATER_METER,
    @XmlEnumValue("GENERIC_SURVEY")
    GENERIC_SURVEY,
    @XmlEnumValue("PAPERLESS_REQUEST")
    PAPERLESS_REQUEST,
    @XmlEnumValue("PAPER_BILL_REQUEST")
    PAPER_BILL_REQUEST,
    @XmlEnumValue("AMEND_BANK")
    AMEND_BANK,
    @XmlEnumValue("REPORT_A_PROBLEM")
    REPORT_A_PROBLEM
}
