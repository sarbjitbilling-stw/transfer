package sbpackage.api.osgi.model.calculator.offers;

public enum OfferPaymentFrequency {

    MONTHLY("M", "M"),
    FORTNIGHTLY("F", "K"),
    WEEKLY("W", "W"),
    FOUR_WEEKLY("4", "T");

    private final String code;
    private final String targetCode;

    OfferPaymentFrequency(final String code, final String targetCode) {
        this.code = code;
        this.targetCode = targetCode;
    }

    public String getCode() {
        return code;
    }

    public String getTargetCode() {
        return targetCode;
    }
}
