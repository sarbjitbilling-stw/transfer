package sbpackage.api.osgi.model.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

/**
 * Typically ContactDto instance exists so that other objects can use it to pass data required for common functions such as
 * contact-creation notes and sending emails.
 * <br/><br/>
 * Created by rtai on 02/06/2017.
 */
@XmlType(name = "contact")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("contact")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactDto implements Serializable {

    @XmlElement(name = "email")
    private String email;

    @XmlElement(name = "phone")
    private String phone;

    @XmlElement(name = "fullName")
    private String fullName;

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "leId")
    private String leId;

    public ContactDto() {
    }

    public ContactDto(String email,String phone,String fullName,TargetAccountNumber accountNumber,String leId ) {
        this.email = email;
        this.phone = phone;
        this.fullName = fullName;
        this.accountNumber = accountNumber;
        this.leId = leId;
    }
    
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLeId() {
        return leId;
    }

    public void setLeId(String leId) {
        this.leId = leId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ContactDto that = (ContactDto) o;

        if (!email.equals(that.email)) return false;
        if (!phone.equals(that.phone)) return false;
        if (!fullName.equals(that.fullName)) return false;
        if (!accountNumber.equals(that.accountNumber)) return false;
        return leId.equals(that.leId);
    }

    @Override
    public int hashCode() {
         return new HashCodeBuilder(57, 97)
                .append(email)
                .append(phone)
                .append(fullName)
                .append(accountNumber)
                .append(leId)
                .toHashCode();
    }
    
     @Override
    public String toString() {
        return "ContactDto{" +
                "email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", fullName='" + fullName + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", leId='" + leId + '\'' +
                '}';
    }
}
