package sbpackage.api.osgi.model.payment.directdebit;

import java.io.Serializable;
import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.referencedata.RefData;

/**
 * Created by DA on 21/12/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentDetails implements Serializable {

    @XmlElement(name = "facilityCode")
    private RefData facilityCode;

    @XmlElement(name = "scheduleFreqCode")
    private RefData scheduleFreqCode;
    
    private LocalDate nextPaymentDate;

    public RefData getFacilityCode() {
        return facilityCode;
    }

    public void setFacilityCode(RefData facilityCode) {
        this.facilityCode = facilityCode;
    }

    public RefData getScheduleFreqCode() {
        return scheduleFreqCode;
    }

    public void setScheduleFreqCode(RefData scheduleFreqCode) {
        this.scheduleFreqCode = scheduleFreqCode;
    }
    

    public LocalDate getNextPaymentDate() {
		return nextPaymentDate;
	}

	public void setNextPaymentDate(LocalDate nextPaymentDate) {
		this.nextPaymentDate = nextPaymentDate;
	}

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("facilityCode", facilityCode)
                .append("scheduleFreqCode", scheduleFreqCode)
                .append("nextPaymentDate", nextPaymentDate)
                .toString();
    }

}

