package sbpackage.api.osgi.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Mark
 */
@XmlRootElement(name = "SpecialCondition")
@XmlAccessorType(XmlAccessType.FIELD)
public class SpecialConditionRestriction extends SpecialCondition {
    @XmlElement(name = "messageId")
    private String messageId;
    @XmlElement(name = "defaultMessage")
    private String defaultMessage;
   
    public SpecialConditionRestriction() {
    }

    public SpecialConditionRestriction(SpecialCondition specialCondition) {
        super(specialCondition);
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getDefaultMessage() {
        return defaultMessage;
    }

    public void setDefaultMessage(String defaultMessage) {
        this.defaultMessage = defaultMessage;
    }
    
    


}
