package sbpackage.api.osgi.model.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class PaymentPlanWarningDTO {

    @XmlElement
    private String code;

    @XmlElement
    private String description;

    @XmlElement
    private String category;

    @XmlElement
    private String targetReturnCode;

    @XmlElement
    private String targetUri;

    @XmlElement
    private String targetReasonText;

    public PaymentPlanWarningDTO() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getTargetReturnCode() {
        return targetReturnCode;
    }

    public void setTargetReturnCode(final String targetReturnCode) {
        this.targetReturnCode = targetReturnCode;
    }

    public String getTargetUri() {
        return targetUri;
    }

    public void setTargetUri(final String targetUri) {
        this.targetUri = targetUri;
    }

    public String getTargetReasonText() {
        return targetReasonText;
    }

    public void setTargetReasonText(final String targetReasonText) {
        this.targetReasonText = targetReasonText;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(final String category) {
        this.category = category;
    }
}
