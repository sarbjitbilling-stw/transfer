package sbpackage.api.osgi.model;

public enum InterceptType {
    CONTACT, PAPERLESS
}
