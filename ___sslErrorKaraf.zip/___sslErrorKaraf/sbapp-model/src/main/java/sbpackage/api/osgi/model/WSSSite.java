package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 *
 * @author Mark
 */
@XmlEnum
public enum WSSSite {
    @XmlEnumValue(value = "STW")
    STW,
    @XmlEnumValue(value = "HD")
    HD;
}
