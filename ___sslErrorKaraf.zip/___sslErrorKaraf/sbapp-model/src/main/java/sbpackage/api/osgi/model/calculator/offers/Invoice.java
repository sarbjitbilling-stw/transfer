package sbpackage.api.osgi.model.calculator.offers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateAdapter;
import sbpackage.api.osgi.model.calculator.offers.adapters.LocalDateTimeAdapter;
import sbpackage.api.osgi.model.referencedata.RefData;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Invoice implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement
    private String attachmentLocation;

    @XmlElement
    private String calculationStatus;

    @XmlElement
    private String accountStatus;

    @XmlElement
    private RefData thirdPartyStatus;

    @XmlElement
    private RefData accountEventType;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateTimeAdapter.class)
    private LocalDateTime createdTime;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billStartDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate billEndDate;

    @XmlElement
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate dateOfIssue;

    @XmlElement
    private BigDecimal eventAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal outstandingAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal cancelledAmount = BigDecimal.ZERO;

    @XmlElement
    private BigDecimal balanceAmount = BigDecimal.ZERO;

    @XmlElement
    private Long invoiceNum;

    @XmlElement
    private BigDecimal billDaysNum = BigDecimal.ZERO;

    @XmlElement
    private List<InvoiceLine> invoiceLines;

    public String getAttachmentLocation() {
        return attachmentLocation;
    }

    public void setAttachmentLocation(String attachmentLocation) {
        this.attachmentLocation = attachmentLocation;
    }

    public String getCalculationStatus() {
        return calculationStatus;
    }

    public void setCalculationStatus(String calculationStatus) {
        this.calculationStatus = calculationStatus;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public RefData getThirdPartyStatus() {
        return thirdPartyStatus;
    }

    public void setThirdPartyStatus(RefData thirdPartyStatus) {
        this.thirdPartyStatus = thirdPartyStatus;
    }

    public RefData getAccountEventType() {
        return accountEventType;
    }

    public void setAccountEventType(RefData accountEventType) {
        this.accountEventType = accountEventType;
    }

    public LocalDateTime getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(LocalDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public LocalDate getBillStartDate() {
        return billStartDate;
    }

    public void setBillStartDate(LocalDate billStartDate) {
        this.billStartDate = billStartDate;
    }

    public LocalDate getBillEndDate() {
        return billEndDate;
    }

    public void setBillEndDate(LocalDate billEndDate) {
        this.billEndDate = billEndDate;
    }

    public LocalDate getDateOfIssue() {
        return dateOfIssue;
    }

    public void setDateOfIssue(LocalDate dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

    public BigDecimal getEventAmount() {
        return eventAmount;
    }

    public void setEventAmount(BigDecimal eventAmount) {
        this.eventAmount = eventAmount;
    }

    public BigDecimal getOutstandingAmount() {
        return outstandingAmount;
    }

    public void setOutstandingAmount(BigDecimal outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    public BigDecimal getCancelledAmount() {
        return cancelledAmount;
    }

    public void setCancelledAmount(BigDecimal cancelledAmount) {
        this.cancelledAmount = cancelledAmount;
    }

    public BigDecimal getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(BigDecimal balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public Long getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(Long invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public BigDecimal getBillDaysNum() {
        return billDaysNum;
    }

    public void setBillDaysNum(BigDecimal billDaysNum) {
        this.billDaysNum = billDaysNum;
    }

    public List<InvoiceLine> getInvoiceLines() {
        return invoiceLines;
    }

    public void setInvoiceLines(List<InvoiceLine> invoiceLines) {
        this.invoiceLines = invoiceLines;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("attachmentLocation", attachmentLocation)
                .append("calculationStatus", calculationStatus)
                .append("accountStatus", accountStatus)
                .append("thirdPartyStatus", thirdPartyStatus)
                .append("accountEventType", accountEventType)
                .append("createdTime", createdTime)
                .append("billStartDate", billStartDate)
                .append("billEndDate", billEndDate)
                .append("dateOfIssue", dateOfIssue)
                .append("eventAmount", eventAmount)
                .append("outstandingAmount", outstandingAmount)
                .append("cancelledAmount", cancelledAmount)
                .append("balanceAmount", balanceAmount)
                .append("invoiceNum", invoiceNum)
                .append("billDaysNum", billDaysNum)
                .append("invoiceLines", invoiceLines)
                .toString();
    }
}
