package sbpackage.api.osgi.model.calculator.offers;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountEvent implements Serializable {

	private static final long serialVersionUID = 1L;

	@XmlElement
	private float outstandingAmount;

	public float getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(float outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	@Override
	public String toString() {
		return "AccountEvent [outstandingAmount=" + outstandingAmount + "]";
	}

}
