package sbpackage.api.osgi.model.inmyarea;

import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.ACTIVITY_PRORITY_MEDIUM;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_INITIATED_BY_CUSTOMER;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_METHOD_WSS;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_PACKAGE_ID_CHECK_METER_OPT_IN;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_PACKAGE_ID_FROPT_QUERIES;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_PACKAGE_ID_SOAC_ENQUIRY;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_SUB_TYPE_CHECK_METER_OPT_IN;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_SUB_TYPE_FROPT_QUERIES;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_SUB_TYPE_SOAC_ENQUIRY;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.CONTACT_TYPE_BILLING;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.ORGANISATION_NUMBER_CAPITA;
import static sbpackage.api.osgi.model.inmyarea.ActivityQueueContants.ROOT_CAUSE_TYPE_FROPT_ENQUIRY;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityQueueType {

    // @formatter:off
    FROPT_TARIFF_SWITCH_ASSESSED(CONTACT_SUB_TYPE_FROPT_QUERIES, CONTACT_PACKAGE_ID_FROPT_QUERIES, "FASCH", "DM203"), 
    FROPT_TARIFF_SWITCH_SOAC(CONTACT_SUB_TYPE_SOAC_ENQUIRY, CONTACT_PACKAGE_ID_SOAC_ENQUIRY, "SOAC", "DM202"), 
    METER_EXCHANGE_TARIFF_SWITCH_ASSESSED(CONTACT_SUB_TYPE_CHECK_METER_OPT_IN, CONTACT_PACKAGE_ID_CHECK_METER_OPT_IN, "CMOPIN", "DM209"),
    METER_EXCHANGE_TARIFF_SWITCH_SOAC(CONTACT_SUB_TYPE_SOAC_ENQUIRY, CONTACT_PACKAGE_ID_SOAC_ENQUIRY, "UNFIT", "DM208");
    // @formatter:on

    private final String contactType;
    private final String contactMethod;
    private final String contactInitiatedBy;
    private final String contactSubType;
    private final long organisationNumber;
    private final String activityQueueCode;
    private final String priority;
    private final String rootCauseType;
    private final String contactPackageId;
    private final String successDmCode;

    ActivityQueueType(String contactSubType, String contactPackageId, String activityQueueCode, String successDmCode) {
        this(CONTACT_TYPE_BILLING, CONTACT_METHOD_WSS, CONTACT_INITIATED_BY_CUSTOMER, contactSubType,
                ORGANISATION_NUMBER_CAPITA, activityQueueCode, ACTIVITY_PRORITY_MEDIUM, ROOT_CAUSE_TYPE_FROPT_ENQUIRY,
                contactPackageId, successDmCode);
    }

}
