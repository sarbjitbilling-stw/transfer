package sbpackage.api.osgi.model.waterefficiency;

public enum Status {

    INITIAL, FINAL;
}
