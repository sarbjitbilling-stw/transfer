package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum JourneyType {

    @XmlEnumValue(value = "RESET_PASSWORD_EMAIL")
    RESET_PASSWORD_EMAIL,
    @XmlEnumValue(value = "VIEW_BILL_EMAIL")
    VIEW_BILL_EMAIL,
    @XmlEnumValue(value = "DIRECT_DEBIT")
    DIRECT_DEBIT,
    @XmlEnumValue(value = "OFFER_PAPERLESS")
    OFFER_PAPERLESS,
    @XmlEnumValue(value = "CONTACT_PHONE_UPDATE")
    CONTACT_PHONE_UPDATE,
    @XmlEnumValue(value = "ACCOUNT_ROLES_UPDATE")
    ACCOUNT_ROLES_UPDATE,
    @XmlEnumValue(value = "UPDATE_METER")
    METER_READING,
    @XmlEnumValue(value = "VIEW_REMINDER_EMAIL")
    VIEW_REMINDER_EMAIL
}
