package sbpackage.api.osgi.model.waterservice;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.util.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;

/**
 * Created by rtai on 24/07/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WaterService {

	@XmlElement
	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate startDate;

	@XmlElement
	@XmlJavaTypeAdapter(LocalDateAdapter.class)
	private LocalDate endDate;

	@XmlElement
	private ServiceType serviceType;

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public ServiceType getServiceType() {
		return serviceType;
	}

	public void setServiceType(ServiceType serviceType) {
		this.serviceType = serviceType;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		WaterService that = (WaterService) o;

		return new EqualsBuilder()
				.append(startDate, that.startDate)
				.append(endDate, that.endDate)
				.append(serviceType, that.serviceType)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(startDate)
				.append(endDate)
				.append(serviceType)
				.toHashCode();
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this)
				.append("startDate", startDate)
				.append("endDate", endDate)
				.append("serviceType", serviceType)
				.toString();
	}
}
