package sbpackage.api.osgi.model.inmyarea;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@lombok.Data
public class ReportedIncident {

    private WorkType workType;
    private IssueType issueType;
    private IncidentAddress address;
    private List<Data> data;
    private ContactDetails contactDetails;
    private boolean callBack;
    private String workOrderId;
    private List<Sla> slas;
    private Appointment selectedAppointment;
    private String reference;

    public Map<String, Integer> getSlaMap() {
        return slas == null ? Collections.emptyMap() : slas.stream().collect(Collectors.toMap(Sla::getWorkCentreNumber, Sla::getSlaHours));
    }
}
