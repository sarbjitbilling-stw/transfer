package sbpackage.api.osgi.model.metering;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class MeterMetadata {

	private String manufacturer;

	private String meterModel;

	private String numberOfDials;

	private String iconName;

	public static boolean isNotEmpty(CharSequence cs) {
		return !(cs == null || cs.length() == 0);
	}

	public MeterMetadata(Meter meter) {
		super();
		if (meter != null) {
			this.meterModel = meter.getMeterModelCode();
			this.manufacturer = meter.getMeterManufacturerName();
			this.numberOfDials = meter.getDialDigitsLeft();
		}
	}

	public MeterMetadata(String manufacturer, String numberOfDials) {
		super();
		this.manufacturer = manufacturer;
		this.numberOfDials = numberOfDials;
	}

	public MeterMetadata() {
		super();
	}

	public MeterMetadata(String manufacturer, String meterModel, String numberOfDials, String iconName) {
		super();
		this.manufacturer = manufacturer;
		this.meterModel = meterModel;
		this.numberOfDials = numberOfDials;
		this.iconName = iconName;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getMeterModel() {
		return meterModel;
	}

	public void setMeterModel(String meterModel) {
		this.meterModel = meterModel;
	}

	public String getNumberOfDials() {
		return numberOfDials;
	}

	public void setNumberOfDials(String numberOfDials) {
		this.numberOfDials = numberOfDials;
	}

	public String getIconName() {
		return iconName;
	}

	public void setIconName(String iconName) {
		this.iconName = iconName;
	}

    @Override
	public String toString() {
		return new ToStringBuilder(this).append("manufacturer", manufacturer).append("meterModel", meterModel)
				.append("numberOfDials", numberOfDials).append("iconName", iconName).toString();
	}

}
