package sbpackage.api.osgi.model.rechor;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sbpackage.api.osgi.model.ProcessOutcomeList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement(name = "ChainOperation")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ChainOperation implements Serializable {

    @XmlElement
    private long sequence;

    @XmlElement
    private String operation;

    @XmlElement
    private ReChorRequest reChorRequest;

    @XmlElement
    private ProcessOutcomeList outcome;

    public long getSequence() {
        return sequence;
    }

    public void setSequence(final long sequence) {
        this.sequence = sequence;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(final String operation) {
        this.operation = operation;
    }

    public ReChorRequest getReChorRequest() {
        return reChorRequest;
    }

    public void setReChorRequest(final ReChorRequest reChorRequest) {
        this.reChorRequest = reChorRequest;
    }

    public ProcessOutcomeList getOutcome() {
        return outcome;
    }

    public void setOutcome(final ProcessOutcomeList outcome) {
        this.outcome = outcome;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("sequence", sequence)
                .append("operation", operation)
                .append("reChorRequest", reChorRequest)
                .append("outcome", outcome)
                .toString();
    }
}