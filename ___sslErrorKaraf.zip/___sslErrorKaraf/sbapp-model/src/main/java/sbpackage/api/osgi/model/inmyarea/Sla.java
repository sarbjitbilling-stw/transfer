package sbpackage.api.osgi.model.inmyarea;

import com.fasterxml.jackson.annotation.JsonProperty;

@lombok.Data
public class Sla {

    private String workCentreNumber;
    @JsonProperty("sla")
    private int slaHours;

}
