/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.model;

import java.time.LocalDate;
import java.util.Objects;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mark
 */
@XmlRootElement(name = "SpecialCondition")
@XmlAccessorType(XmlAccessType.FIELD)
public class SpecialCondition {
    @XmlElement(name = "typeName")
    private String typeName;
    @XmlElement(name = "description")
    private String description;
    @XmlElement(name = "startDate")
    private LocalDate startDate;
    @XmlElement(name = "endDate")
    private LocalDate endDate;

    public SpecialCondition() {
    }

    public SpecialCondition(SpecialCondition specialCondition) {
        this.typeName = specialCondition.getTypeName();
        this.description = specialCondition.getDescription();
        this.startDate = specialCondition.getStartDate();
        this.endDate = specialCondition.getEndDate();
    }

    public SpecialCondition(String typeName, String description) {
        this.typeName = typeName;
        this.description = description;
    }

    public SpecialCondition(String typeName) {
        this(typeName, null);
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.typeName);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SpecialCondition other = (SpecialCondition) obj;
        if (!Objects.equals(this.typeName, other.typeName)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return String.format("SpecialCondition{typeName=%s, description=%s, startDate=%s, endDate=%s}", typeName,
                description, startDate, endDate);
    }
    
}
