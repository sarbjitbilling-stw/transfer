package sbpackage.api.osgi.model.calculator.offers;

public enum BudgetPlanTypes {
    PPC("PPC", "P"),
    EQUALIZED("Equalized", "E"),//(Measured without Arrears)
    COMBINATION("Combination", "C"),//(Measured with Arrears)
    UNMEASURED("Unmeasured", "U"),
    NONE("None", "N");

    private final String code;
    private final String targetCode;

    BudgetPlanTypes(final String code, final String targetCode) {
        this.code = code;
        this.targetCode = targetCode;
    }

    public String getCode() {
        return code;
    }

    public String getTargetCode() {
        return targetCode;
    }
}