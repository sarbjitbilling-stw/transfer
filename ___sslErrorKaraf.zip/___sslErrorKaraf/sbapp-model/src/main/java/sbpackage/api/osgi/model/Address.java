package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import sbpackage.api.osgi.model.util.LocalDateAdapter;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Created by rtai on 23/03/2017.
 */
@XmlRootElement(name = "address")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Address implements Serializable{

    @XmlEnum
    public enum AddressType {
        @XmlEnumValue("BILLING")
        BILLING,
        @XmlEnumValue("SERVICE")
        SERVICE
    }

    @XmlEnum
    public enum AddressStatus {
        @XmlEnumValue("MIGRATED")
        MIGRATED,
        @XmlEnumValue("IN_AREA")
        IN_AREA,
        @XmlEnumValue("OUT_AREA")
        OUT_AREA
    }

    @XmlElement(name = "id")
    @JsonProperty(value = "id")
    private String id;

    @XmlElement(name = "streetName")
    @JsonProperty(value = "streetName")
    private String streetName;

    @XmlElement(name = "line1")
    @JsonProperty(value = "line1")
    private String line1;

    @XmlElement(name = "line2")
    @JsonProperty(value = "line2")
    private String line2;

    @XmlElement(name = "line3")
    @JsonProperty(value = "line3")
    private String line3;

    @XmlElement(name = "city")
    @JsonProperty(value = "city")
    private String city;

    @XmlElement(name = "county")
    @JsonProperty(value = "county")
    private String county;

    @XmlElement(name = "country")
    @JsonProperty(value = "country")
    private String country;

    @XmlElement(name = "postcode")
    @JsonProperty(value = "postcode")
    private String postcode;

    @XmlElement(name = "addressType")
    @JsonProperty(value = "addressType")
    private AddressType addressType;

    @XmlElement(name = "propertyNum")
    @JsonProperty(value = "propertyNum")
    private Long propertyNum;

    @XmlElement(name = "addressDescription")
    @JsonProperty(value = "addressDescription")
    private String addressDescription;

    @XmlElement(name = "addressCode")
    @JsonProperty(value = "addressCode")
    private long addressCode;

    @XmlElement(name = "addressStatus")
    @JsonProperty(value = "addressStatus")
    private AddressStatus addressStatus;
    
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate startDate;
    
    @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
    private LocalDate endDate;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getLine3() {
        return line3;
    }

    public void setLine3(String line3) {
        this.line3 = line3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public AddressType getAddressType() {
        return addressType;
    }

    public void setAddressType(AddressType addressType) {
        this.addressType = addressType;
    }

    public Long getPropertyNum() {
        return propertyNum;
    }

    public void setPropertyNum(Long propertyNum) {
        this.propertyNum = propertyNum;
    }

    public String getAddressDescription() {
        return addressDescription;
    }

    public void setAddressDescription(String addressDescription) {
        this.addressDescription = addressDescription;
    }

    public long getAddressCode() {
        return addressCode;
    }

    public void setAddressCode(long addressCode) {
        this.addressCode = addressCode;
    }

    public AddressStatus getAddressStatus() {
        return addressStatus;
    }

    public void setAddressStatus(AddressStatus addressStatus) {
        this.addressStatus = addressStatus;
    }
    
    

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Address address = (Address) o;

        return new EqualsBuilder()
                .append(id, address.id)
                .append(streetName, address.streetName)
                .append(line1, address.line1)
                .append(line2, address.line2)
                .append(line3, address.line3)
                .append(city, address.city)
                .append(county, address.county)
                .append(country, address.country)
                .append(postcode, address.postcode)
                .append(addressType, address.addressType)
                .append(propertyNum, address.propertyNum)
                .append(addressDescription, address.addressDescription)
                .append(addressCode, address.addressCode)
                .append(addressStatus, address.addressStatus)

                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(streetName)
                .append(line1)
                .append(line2)
                .append(line3)
                .append(city)
                .append(county)
                .append(country)
                .append(postcode)
                .append(addressType)
                .append(propertyNum)
                .append(addressDescription)
                .append(addressCode)
                .append(addressStatus)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("streetName", streetName)
                .append("line1", line1)
                .append("line2", line2)
                .append("line3", line3)
                .append("city", city)
                .append("county", county)
                .append("country", country)
                .append("postcode", postcode)
                .append("addressType", addressType)
                .append("propertyNum",propertyNum)
                .append("addressDescription",addressDescription)
                .append("addressCode",addressCode)
                .append("addressStatus",addressStatus)
                .toString();
    }
}
