package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DeveloperPhases {

    private List<ConnectionPhase> connections;

    public List<ConnectionPhase> getConnections() {
        return connections;
    }

    public void setConnections(List<ConnectionPhase> connections) {
        this.connections = connections;
    }

    public int getPropertyCount() {
        return connections != null ? connections.stream().mapToInt(ConnectionPhase::getPropertyCount).sum() : 0;
    }

    public boolean isAtLeastOnePropertyCommercial() {
        return connections != null && connections.stream().anyMatch(ConnectionPhase::isAtLeastOnePropertyCommercial);
    }
}
