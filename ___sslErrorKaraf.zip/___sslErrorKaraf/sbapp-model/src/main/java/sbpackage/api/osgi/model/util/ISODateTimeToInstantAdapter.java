package sbpackage.api.osgi.model.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

public class ISODateTimeToInstantAdapter extends XmlAdapter<String,Instant> {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_INSTANT;

    @Override
    public Instant unmarshal(String v) {
        return Instant.from(formatter.parse(v));
    }

    @Override
    public String marshal(Instant v) {
        return formatter.format(v);
    }
}
