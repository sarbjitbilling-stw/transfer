package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Details extends NameAddress {

    private String selectedDeveloper;
    private String selectedDeveloperRegion;
    private String developer;
    private String region;

    private static final String COMPANY_NAME_FORMAT = "%s - %s";
    private static final String OTHER = "other";

    private boolean preferredContact;

    public boolean isPreferredContact() {
        return preferredContact;
    }

    private String buildCompanyName() {
        return StringUtils.isEmpty(getRegion()) ?
                getDeveloper() :
                String.format(COMPANY_NAME_FORMAT, getDeveloper(), getRegion());
    }

    @Override
    public boolean hasCompanyName() {
        return super.hasCompanyName() || StringUtils.isNotEmpty(selectedDeveloper) || StringUtils.isNotEmpty(developer);
    }

    @Override
    public String getCompanyName() {
        return StringUtils.isNotEmpty(selectedDeveloper) ? buildCompanyName() : super.getCompanyName();
    }

    public String getDeveloper() {
        return OTHER.equalsIgnoreCase(selectedDeveloper) ? developer : selectedDeveloper;
    }

    public String getRegion() {
        return OTHER.equalsIgnoreCase(selectedDeveloperRegion) ? region : selectedDeveloperRegion;
    }

    public void setPreferredContact(boolean preferredContact) {
        this.preferredContact = preferredContact;
    }

}
