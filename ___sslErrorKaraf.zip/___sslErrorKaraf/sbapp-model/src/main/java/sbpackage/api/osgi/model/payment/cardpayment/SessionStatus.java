package sbpackage.api.osgi.model.payment.cardpayment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

@Data
@JsonIgnoreProperties(ignoreUnknown=true)
@NoArgsConstructor
public class SessionStatus {

    private String status;
    private HostedSessionStatus hostedSessionStatus;

    public SessionStatus(String transactionId) {
        hostedSessionStatus = new HostedSessionStatus(transactionId);
    }

    public Optional<String> getTransactionId() {
        return hostedSessionStatus != null ? hostedSessionStatus.getTransactionId() : Optional.empty();
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown=true)
    @NoArgsConstructor
    @SuppressWarnings("java:S2972")
    private class HostedSessionStatus {

        private String sessionId;
        private String context;
        private String sessionState;
        private TransactionState transactionState;

        public HostedSessionStatus(String transactionId) {
            transactionState = new TransactionState(transactionId);
        }

        public Optional<String> getTransactionId() {
            return transactionState != null ? Optional.ofNullable(transactionState.getId()) : Optional.empty();
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown=true)
        @NoArgsConstructor
        private class TransactionState {
            private String id;
            @SuppressWarnings("java:S1700")
            private String transactionState;

            public TransactionState(String transactionId) {
                this.id = transactionId;
            }
        }
    }
}
