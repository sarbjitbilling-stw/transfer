package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SewerAssets extends SelectionArray {

    private Sewer foulSewer;
    private Sewer surfaceWaterSewer;

    public Sewer getFoulSewer() {
        return foulSewer;
    }

    public void setFoulSewer(Sewer foulSewer) {
        this.foulSewer = foulSewer;
    }

    public Sewer getSurfaceWaterSewer() {
        return surfaceWaterSewer;
    }

    public void setSurfaceWaterSewer(Sewer surfaceWaterSewer) {
        this.surfaceWaterSewer = surfaceWaterSewer;
    }
}
