package sbpackage.api.osgi.model.sms;

public enum SendSmsStatus {
    PROCESSING, SENT, FAILED
}
