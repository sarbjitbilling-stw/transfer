package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement(name = "ReverseBillResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class ReverseBillResponse {
	private Long propertyId = null;
	private Long serviceProvisionNum = null;
	private String alternateId = null;
	private String propertyAddress = null;
	private String serviceProvisionDes = null;
	private TargetAccountNumber accountId = null;

	public Long getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public void setAccountId(TargetAccountNumber accountId) {
		this.accountId = accountId;
	}
	public TargetAccountNumber getAccountId() {
		return accountId;
	}
	public Long getServiceProvisionNum() {
		return serviceProvisionNum;
	}
	public void setServiceProvisionNum(Long serviceProvisionNum) {
		this.serviceProvisionNum = serviceProvisionNum;
	}
	public String getAlternateId() {
		return alternateId;
	}
	public void setAlternateId(String alternateId) {
		this.alternateId = alternateId;
	}
	public String getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public String getServiceProvisionDes() {
		return serviceProvisionDes;
	}
	public void setServiceProvisionDes(String serviceProvisionDes) {
		this.serviceProvisionDes = serviceProvisionDes;
	}
}
