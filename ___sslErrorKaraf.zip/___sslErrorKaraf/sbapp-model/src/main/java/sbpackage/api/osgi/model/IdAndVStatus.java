package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Created by admzphili1 on 14/02/2017.
 */
@XmlEnum
public enum IdAndVStatus {
    @XmlEnumValue("SUCCESS")
    SUCCESS,
    @XmlEnumValue("ERROR")
    ERROR,
    @XmlEnumValue("IN_PROGRESS")
    IN_PROGRESS,
    @XmlEnumValue("ALREADY_REGISTERED")
    ALREADY_REGISTERED,
    @XmlEnumValue("NO_LE_FOUND")
    NO_LE_FOUND

}
