package sbpackage.api.osgi.model.payment.cardpayment;

import lombok.Getter;

@Getter
public enum CardType {

    ELECTRON("40VEL", "Visa Electron", "Electron"),
    MAESTRO("80MAE", "Maestro", "Maestro"),
    MC_DEBIT("70MCD", "MasterCard Debit", "Debit Master Card"),
    MC_CREDIT("60MCC", "MasterCard Credit", "Master Card"),
    VISA_DEBIT("10VDB", "Visa Debit", "Delta"),
    VISA_CREDIT("50VCR", "Visa Credit", "Visa");

    private String code;
    private String description;
    private String providerCode;

    CardType(String code, String description, String providerCode) {
        this.code = code;
        this.description = description;
        this.providerCode = providerCode;
    }

    @SuppressWarnings("java:S1142")
    public static CardType fromString(String cardType) {
        switch(cardType) {
            case "ELECTRON": return ELECTRON;
            case "MAESTRO": return MAESTRO;
            case "MC_DEBIT":
            case "SWITCH":
            case "SOLO": return MC_DEBIT;
            case "MC_CREDIT": return MC_CREDIT;
            case "VISA_CREDIT": return VISA_CREDIT;
            default: return VISA_DEBIT;
        }
    }
}
