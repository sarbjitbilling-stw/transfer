package sbpackage.api.osgi.model.calculator.consumption;

import java.io.Serializable;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import sbpackage.api.osgi.model.calculator.PropertyType;
import sbpackage.api.osgi.model.calculator.PropertyTypeAdapter;

/**
 * Created by rtai on 18/07/2017.
 */
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"numAdults","numChildren","propertyType","charges","selectedCharge"})
@Data
public class ConsumptionCalculator implements Serializable {

	@XmlElement
	private int numAdults;

	@XmlElement
	private int numChildren;

	@XmlElement
    @XmlJavaTypeAdapter(PropertyTypeAdapter.class)
    private PropertyType propertyType;

	@XmlElement(name = "charges")
	@JsonProperty(value = "charges")
	private Set<UsageCharge> usageCharges;

	@XmlElement(name = "selectedCharge")
	@JsonProperty(value = "selectedCharge")
	private UsageCharge selectedCharge;

}
