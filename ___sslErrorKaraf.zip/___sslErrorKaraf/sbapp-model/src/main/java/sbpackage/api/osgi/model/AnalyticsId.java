/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

/**
 *
 * @author Mark
 */
public class AnalyticsId implements Serializable{

    @JsonProperty("id")
    @XmlElement(name = "id")
    private Long id;

    @JsonProperty("wssUsername")
    @XmlElement(name = "wssUsername")
    private String wssUsername;

    @JsonProperty("wssEmail")
    @XmlElement(name = "wssEmail")
    private String wssEmail;

    @JsonProperty("accountId")
    @XmlElement(name = "accountId")
    private String accountId;

    @JsonProperty("externalLeId")
    @XmlElement(name = "externalLeId")
    private String externalLeId;

    @JsonProperty("analyticsId")
    @XmlElement(name = "analyticsId")
    private String analyticsId;

    @JsonProperty("dateGenerated")
    @XmlElement(name = "dateGenerated")
    private LocalDate dateGenerated;

    public AnalyticsId() {
    }

    public AnalyticsId(Long id, String wssUsername, String wssEmail, String accountId, String externalLeId, String analyticsId, LocalDate dateGenerated) {
        this.id = id;
        this.wssUsername = wssUsername;
        this.wssEmail = wssEmail;
        this.accountId = accountId;
        this.externalLeId = externalLeId;
        this.analyticsId = analyticsId;
        this.dateGenerated = dateGenerated;
    }
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWssUsername() {
        return wssUsername;
    }

    public void setWssUsername(String wssUsername) {
        this.wssUsername = wssUsername;
    }

    public String getWssEmail() {
        return wssEmail;
    }

    public void setWssEmail(String wssEmail) {
        this.wssEmail = wssEmail;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getExternalLeId() {
        return externalLeId;
    }

    public void setExternalLeId(String externalLeId) {
        this.externalLeId = externalLeId;
    }

    public String getAnalyticsId() {
        return analyticsId;
    }

    public void setAnalyticsId(String analyticsId) {
        this.analyticsId = analyticsId;
    }


    public LocalDate getDateGenerated() {
        return dateGenerated;
    }

    public void setDateGenerated(LocalDate dateGenerated) {
        this.dateGenerated = dateGenerated;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + Objects.hashCode(this.id);
        hash = 19 * hash + Objects.hashCode(this.wssUsername);
        hash = 19 * hash + Objects.hashCode(this.wssEmail);
        hash = 19 * hash + Objects.hashCode(this.accountId);
        hash = 19 * hash + Objects.hashCode(this.externalLeId);
        hash = 19 * hash + Objects.hashCode(this.analyticsId);
        hash = 19 * hash + Objects.hashCode(this.dateGenerated);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AnalyticsId other = (AnalyticsId) obj;
        if (!Objects.equals(this.wssUsername, other.wssUsername)) {
            return false;
        }
        if (!Objects.equals(this.wssEmail, other.wssEmail)) {
            return false;
        }
        if (!Objects.equals(this.accountId, other.accountId)) {
            return false;
        }
        if (!Objects.equals(this.externalLeId, other.externalLeId)) {
            return false;
        }
        if (!Objects.equals(this.analyticsId, other.analyticsId)) {
            return false;
        }
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        if (!Objects.equals(this.dateGenerated, other.dateGenerated)) {
            return false;
        }
        return true;
    }
    
    

}
