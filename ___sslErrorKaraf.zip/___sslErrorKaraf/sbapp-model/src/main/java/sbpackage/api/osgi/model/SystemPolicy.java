package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SystemPolicy", propOrder =

{ "systempolicy" })

@XmlRootElement(name = "SystemPolicy")


public class SystemPolicy {

	@XmlElement(name = "systempolicy")
    private String systempolicy;

	public String getSystempolicy() {
		return systempolicy;
	}

	public void setSystempolicy(String systempolicy) {
		this.systempolicy = systempolicy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((systempolicy == null) ? 0 : systempolicy.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SystemPolicy other = (SystemPolicy) obj;
		if (systempolicy == null) {
			if (other.systempolicy != null)
				return false;
		} else if (!systempolicy.equals(other.systempolicy))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SystemPolicy [systempolicy=" + systempolicy + "]";
	}   
}

