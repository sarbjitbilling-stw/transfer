package sbpackage.api.osgi.model.forms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonIgnoreProperties(ignoreUnknown=true)
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Fittings {

    private FittingsList fittings;
    private float storageTankCapacity;
    private float flowRate;
    private float tankCapacity;
    private boolean requiresLargePipe;

    private String processWaterForIndustrialPurposes;
    private float processWaterFlowRate;
    private String storageTankForProcessedWater;
    private int storageTankForProcessedWaterTankCapacity;
    private float storageTankForProcessedWaterFillRate;

    public FittingsList getFittings() {
        return fittings;
    }

    public void setFittings(FittingsList fittings) {
        this.fittings = fittings;
    }

    public float getFlowRate() {
        return flowRate;
    }

    public void setFlowRate(float flowRate) {
        this.flowRate = flowRate;
    }

    public float getTankCapacity() {
        return tankCapacity;
    }

    public void setTankCapacity(float tankCapacity) {
        this.tankCapacity = tankCapacity;
    }

    public void merge(Fittings fittings) {
        if(fittings != null) {
            flowRate += fittings.getFlowRate();
            tankCapacity += fittings.getTankCapacity();
            this.fittings.merge(fittings.getFittings());
        }
    }

    public boolean isRequiresLargePipe() {
        return requiresLargePipe;
    }

    public void setRequiresLargePipe(boolean requiresLargePipe) {
        this.requiresLargePipe = requiresLargePipe;
    }

	public float getStorageTankCapacity() {
		return storageTankCapacity;
	}

	public void setStorageTankCapacity(float storageTankCapacity) {
		this.storageTankCapacity = storageTankCapacity;
	}

    public float getProcessWaterFlowRate() {
        return processWaterFlowRate;
    }

    public String getStorageTankForProcessedWater() {
        return storageTankForProcessedWater;
    }

    public String getProcessWaterForIndustrialPurposes() {
        return processWaterForIndustrialPurposes;
    }

    public int getStorageTankForProcessedWaterTankCapacity() {
        return storageTankForProcessedWaterTankCapacity;
    }

    public float getStorageTankForProcessedWaterFillRate() {
        return storageTankForProcessedWaterFillRate;
    }
}
