package sbpackage.api.osgi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "emailTemplate")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailTemplate {

    @JsonProperty("link")
    @XmlElement(name = "link")
    private String link;

    @JsonProperty("emailReference")
    @XmlElement(name = "emailReference")
    private String emailReference;

    @JsonProperty("subject")
    @XmlElement(name = "subject")
    private String subject;

    public String getEmailReference() {
      return emailReference;
    }

    public void setEmailReference(String emailReference) {
      this.emailReference = emailReference;
    }

    public String getSubject() {
      return subject;
    }

    public void setSubject(String subject) {
      this.subject = subject;
    }


    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
