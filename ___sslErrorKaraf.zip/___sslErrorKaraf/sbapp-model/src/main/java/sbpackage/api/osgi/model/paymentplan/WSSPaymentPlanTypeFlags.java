package sbpackage.api.osgi.model.paymentplan;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;

@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WSSPaymentPlanTypeFlags {
	
	private boolean isPaymentPlanBooklet;

	public boolean isPaymentPlanBooklet() {
		return isPaymentPlanBooklet;
	}

	public void setPaymentPlanBooklet(boolean isPaymentPlanBooklet) {
		this.isPaymentPlanBooklet = isPaymentPlanBooklet;
	}
	
	
}
