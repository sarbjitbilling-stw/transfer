package sbpackage.api.osgi.model.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;

public class UnixTimeAdaptor extends XmlAdapter<String,LocalDateTime> {

    @Override
    public LocalDateTime unmarshal(String v) {
        return Instant.ofEpochSecond(Long.parseLong(v)).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    @Override
    public String marshal(LocalDateTime v) {
        return String.valueOf(v.toEpochSecond(OffsetDateTime.now().getOffset()));
    }
}
