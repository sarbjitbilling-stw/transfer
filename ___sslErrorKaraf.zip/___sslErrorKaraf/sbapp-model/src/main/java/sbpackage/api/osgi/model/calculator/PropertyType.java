package sbpackage.api.osgi.model.calculator;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum PropertyType {
	FLAT, TERRACED, SEMI, DETACHED;

    @JsonCreator
    public static PropertyType getPropertyTypeFromValue(String value) {
        if (value == null) {
            return null;
        }

        // @formatter:off
        return Arrays.stream(PropertyType.values())
                .filter(propertyType -> propertyType.toString().equalsIgnoreCase(value))
                .findFirst()
                .orElseGet(() -> {
                    log.warn("Property type not found for value={}", value);
                    return null;
                });
        // @formatter:on
    }
}
