package sbpackage.api.osgi.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

@XmlRootElement(name = "OneClickRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneClickRequest {

    @XmlElement(name = "accountNumber")
    private TargetAccountNumber accountNumber;

    @XmlElement(name = "legalEntity")
    private String legalEntity;

    @XmlElement(name = "email")
    private String email;

    @XmlElement(name = "agentId")
    private String agentId;

    @XmlElement(name = "telephone")
    private String telephone;

    public OneClickRequest() {
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLegalEntity() {
        return legalEntity;
    }

    public void setLegalEntity(String legalEntity) {
        this.legalEntity = legalEntity;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email.toLowerCase();
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
    @Override
    public String toString() {
    	StringBuilder builder = new StringBuilder();
    	builder.append("OnecClickRequest[");
    	builder.append(accountNumber);
    	builder.append(", legalEntity:");
    	builder.append(legalEntity);
    	builder.append(", email");
    	builder.append(email);
    	builder.append(", agentId");
    	builder.append(agentId);
    	builder.append(", telephone");
    	builder.append(telephone);
    	builder.append("]");
    	return builder.toString();
    	
    }
}
