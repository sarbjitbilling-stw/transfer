Karaf Configuration File Framework
==================================
_Steve Leach, October 2017_

Overview
--------
This module contains a framework for managing the various configuration 
files required for the wss-osgi application to function correctly on Karaf
in each of the different environments.

There are currently two sets of configuration files...

`src/main/resources/env` contains the "old", manually-maintained config
files. These should _not_ be updated, going forward, and will eventually
be deleted once the config deployment mechanism is using the new files.

`src/main/resources/env2` contains the new framework, which is explained 
below.

New Configuration Framework
---------------------------
The configuration files required by wss-osgi contain hundreds of different 
values, but most of them are the same in all environments.

In order to minimise the effort needed to maintain them all, and also to
minimise the risk of mistakes, the new framework builds all the individual 
configuration files from templates, replacing any environment-specific
values with values from a single environment-specifid properties file.

The `src/main/resources/env2` folder contains three subfolders...

1.  The `templates` folder contains configuration file templates that 
    are used as the basis for the environment-specific versions.
     
    There is one template for each different configuration file.
    
    Templates can contain placeholders such as `${var.name}` and the
    placeholders are replaced with real values as necessary.
    
2.  The `envconfig` folder contains properties files that specify
    the values to use for the different placeholders in each environment.
    
    Up to four properties files are used for each environment...
    
    `default.properties` contains values that are used in all environments
    unless overridden by another properties file.
    
    Each environment (DEV,SIT,UAT, etc.) has a properties file named
    after the environment. These files are where most of the environment-
    specific properties should be set.
    
    There is then a properties file per _channel_ ("CMP" or "WSS"),
    with the properties file name starting with an underscore. These 
    files contain properties that apply to instances in that channel
    in _all_ environments.
    
    Finally there may then be another channel-specific properties file for each
    environment, where the channels are "CMP" and "WSS". The names of
    these are built from the environment name and the channel name.
    Properties should only be specified in these files if they are
    different in the two channels.
    
3.  The `overrides` folder contains override files, that entirely 
    replace any files generated from the templates. These override
    files should only be used where the changes required to a template
    are too significant to be worth it. In general, only local
    development configuration should be different enough from the 
    config of managed environments to be worth an override file.
    
Generated Configuration Files
-----------------------------
The new framework writes the generated configuration files for each
environment into the `target/config/managed` folder.
   
From here they can be deployed directly into the appropriate
environment.


The `target/config/legacy` folder contains a copy of the orgiginal
configuration files in scr/resources/env, purely for comparing the managed versions to. This
folder will eventually be removed.

To add a new configuration entry :

1. Add the new entr in the env2/template
2. Same entry must be added in each corresponding file for each environment  

Build and Test Process
----------------------
The new configuration files are generated during the Maven 
"process-classes" phase by the ConfigurationBuilder class (executed
by the exec-maven-plugin).

Once this is done, the test phase starts and ConfigBuilderTest (which 
is a standard Java unit test) compares the files created by
ConfigurationBuilder with the manually managed "legacy" configuration
files.