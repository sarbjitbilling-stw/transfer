package sbpackage.api.config;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.apache.commons.io.FilenameUtils;

/**
 * Creates environment specific configuration files from templates and environment-specific properties files.
 *
 * @author Steve Leach
 */
public class ConfigurationBuilder {

    static String[] envs = new String[] { "DEV", "SIT", "UAT", "PREPROD", "PRODUCTION", "SUPPORT", "local-dev"};
    static String[] channels = new String[]{"CMP", "WSS", "CMP-KUBERNETES", "WSS-KUBERNETES"};
    private static final String WSS_OSGI_APPLICATION_FEATURE = "sbapp-application";
    private static final String WSS_OSGI_BUNDLES_FEATURE = "sbapp-application-bundles";
    private static final String CONFIG_FEATURES_ELEMENT = "configFeatures";
    private static final String CONFIG_ELEMENT = "config";
    private static final String VERSION_ATTRIBUTE = "version";
    private static final String NAME_ATTRIBUTE = "name";
    private static final String FEATURE_ELEMENT = "feature";
    private static final String XML_CONFIG_FILE = "config.xml";

    private final String baseDir;
    private final String projectVersion;

    public ConfigurationBuilder(String baseDir, String projectVersion) {
        this.baseDir = baseDir;
        this.projectVersion = projectVersion;
    }

    public static void main(String[] args) throws IOException, XMLStreamException {
        String baseDir = args[0];
        String projectVersion =  args[1];
        ConfigurationBuilder configurationBuilder = new ConfigurationBuilder(baseDir, projectVersion);
        configurationBuilder.createConfigurationFiles();
        configurationBuilder.createXMLConfigurationFile();
    }

    private void createXMLConfigurationFile() throws IOException, XMLStreamException {
        output("Generating xml config file...");
        Files.createDirectories(targetRoot());
        Path path = targetRoot().resolve(XML_CONFIG_FILE); 
        try (OutputStream os = Files.newOutputStream(path)) {

            XMLOutputFactory outputFactory = XMLOutputFactory.newFactory();
            XMLStreamWriter writer = outputFactory.createXMLStreamWriter(os, StandardCharsets.UTF_8.name());

            writer.writeStartDocument(StandardCharsets.UTF_8.name(), "1.0");
            writer.writeStartElement(CONFIG_FEATURES_ELEMENT);// <configFeatures>

            for (String env : envs) {
                for (String channel : channels) {
                    if (env.equals("PRODUCTION") && channel.contains("KUBERNETES")) {
                        continue;
                    }
                    // <feature ...
                    writer.writeStartElement(FEATURE_ELEMENT);
                    writer.writeAttribute(NAME_ATTRIBUTE, 
                            String.format(WSS_OSGI_APPLICATION_FEATURE +"-%1$s-%2$s", env.toLowerCase(), channel.toLowerCase()));
                    writer.writeAttribute(VERSION_ATTRIBUTE, projectVersion);
                    writer.writeAttribute("install", "manual");

                    try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(targetRootNew().resolve(env).resolve(channel))) {
                        for (Path template : directoryStream) {
                            if (template.getFileName().toString().equalsIgnoreCase("org.apache.karaf.features.cfg")) {
                                continue;
                            }
                            // <config ...
                            writer.writeStartElement(CONFIG_ELEMENT);
                            writer.writeAttribute(NAME_ATTRIBUTE, FilenameUtils.removeExtension(template.getFileName().toString()));
                            //add content of config file
                            writer.writeCharacters(System.lineSeparator());
                            for (String line : Files.readAllLines(template)) {
                                writer.writeCharacters(line);
                                writer.writeCharacters(System.lineSeparator());
                            }
                            writer.writeEndElement();// </config>
                        }
                    }
                    //Add the main application sub feature with version e.g. <feature version="">sbapp-application-bundles</feature>
                    writer.writeStartElement(FEATURE_ELEMENT);
                    writer.writeAttribute(VERSION_ATTRIBUTE, projectVersion);
                    writer.writeCharacters(WSS_OSGI_BUNDLES_FEATURE);
                    writer.writeEndElement();

                    writer.writeEndElement();// </feature>
                }
            }
            writer.writeEndElement();// </configFeatures>
            writer.writeEndDocument();
            writer.close();
        }
        output("XML Configuration file created");
    }
    
    private void createConfigurationFiles() throws IOException {
        output("Generating config files...");

        Files.createDirectories(targetRootNew());

        output("Config Module root = " + configModuleRoot());

        for (String env : envs) {
            for (String channel : channels) {
                if (env.equals("PRODUCTION") && channel.contains("KUBERNETES")) {
                    continue;
                }
                createNewConfigFiles(env,channel);
            }
        }

        output("Configuration files created");
    }

    Path configModuleRoot() {
        return Paths.get(baseDir).toAbsolutePath();
    }

    Path sourceRoot() {
        return configModuleRoot().resolve("target/classes");
    }

    Path sourceRootNew() {
        return sourceRoot().resolve("env2");
    }

    Path targetRoot() {
        return configModuleRoot().resolve("target/config");
    }

    Path targetRootNew() {
        return targetRoot().resolve("managed");
    }

    Path templatePath() {
        return sourceRootNew().resolve("templates");
    }

    private void createNewConfigFiles(String env, String channel) throws IOException {
        Path destinationPath = targetRootNew().resolve(env);
        destinationPath = destinationPath.resolve(channel);

        Properties properties = loadEnvironmentProperties(env, channel);

        Files.createDirectories(destinationPath);

        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(templatePath())) {
            for (Path sourcePath : directoryStream) {
                copyAndReplaceTokens(sourcePath, destinationPath.resolve(sourcePath.getFileName()), properties);
            }
        }

        copyOverrides(env, destinationPath, properties);
        copyOverrides(channel, destinationPath, properties);
    }

    private void copyOverrides(String sourcePath, Path destinationPath, Properties properties) throws IOException {
        Path overridePath = sourceRootNew().resolve("overrides").resolve(sourcePath);
        if (Files.exists(overridePath)) {
            try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(overridePath)) {
                for (Path source : directoryStream) {
                    copyAndReplaceTokens(source, destinationPath.resolve(source.getFileName()), properties);
                }
            }
        }
    }

    private Properties loadEnvironmentProperties(String env, String channel) throws IOException {
        Properties properties = new Properties();
        properties.setProperty("env.id", env);
        channel = channel.contains("-") ? channel.substring(0, channel.indexOf("-")) : channel;
        properties.setProperty("env.channel", channel);

        Path configPath = sourceRootNew().resolve("envconfig");

        mergeProperties(properties, configPath.resolve("default.properties"));

        mergeProperties(properties, configPath.resolve(env+".properties"));

        mergeProperties(properties, configPath.resolve("_"+channel+".properties"));

        mergeProperties(properties, configPath.resolve(env + "-" + channel + ".properties"));

        return properties;
    }

    /**
     * Merges properties from a file into a properties object, if the file exists.
     */
    private void mergeProperties(Properties properties, Path propertiesFile) throws IOException {
        if (Files.exists(propertiesFile)) {
            try (InputStream stream = Files.newInputStream(propertiesFile)) {
                properties.load(stream);
            }
        }
    }

    /**
     * Copy a file, replacing marker tokens with property values when found.
     */
    private void copyAndReplaceTokens(Path sourcePath, Path destinationPath, Properties properties) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(destinationPath)) {
            for (String line : Files.readAllLines(sourcePath)) {
                line = replaceProperties(line, properties);
                writer.write(line);
                writer.write("\n");
            }
        }
        output("Created " + destinationPath);
    }

    private String replaceProperties(String line, Properties envProps) {
        for (Object prop : envProps.keySet()) {
            String propName = (String)prop;
            String propMarker = "${"+propName+"}";
            if (line.contains(propMarker)) {
                line = line.replace(propMarker, envProps.getProperty(propName));
            }
        }
        return line;
    }

    static void output(String message, String... args) {
        System.out.println(String.format(message,args));
    }

}
