package sbpackage.api.osgi.util.logging;

public enum LogChannel {

    BATCH("services.batch"),
    WATER_EFFICIENCY("services.waterefficiency");

    private String name;

    LogChannel(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

}
