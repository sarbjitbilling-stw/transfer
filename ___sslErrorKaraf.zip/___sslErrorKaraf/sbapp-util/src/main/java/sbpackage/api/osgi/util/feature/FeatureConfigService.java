package sbpackage.api.osgi.util.feature;

import java.util.Set;

public interface FeatureConfigService {
    Set<Feature> getActiveFeatures();
}
