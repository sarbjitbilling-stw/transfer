package sbpackage.api.osgi.util.logging;

import org.slf4j.Logger;

public class LoggerFactory {

    public static Logger getLogger(LogChannel logChannel, Class<?> clazz) {
        return org.slf4j.LoggerFactory.getLogger(logChannel.getName().concat(".").concat(clazz.getName()));
    }

}
