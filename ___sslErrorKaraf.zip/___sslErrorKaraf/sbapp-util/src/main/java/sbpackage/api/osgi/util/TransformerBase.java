/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.util;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author Mark
 */
public class TransformerBase {
        
    /**
     * Copies properties with matching name and type from the source to the target object.
     * @param from source object.
     * @param to target object.
     * @param <T>
     * @return the target object.
     */
    public static final <T> T copy(Object from, T to) {
        try {
            BeanUtils.copyProperties(to, from);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return to;
    }
    
    /**
     * Copies properties with matching name and type from the source to the target object.
     * @param from source object.
     * @param to target object.
     * @param <T>
     * @return the target object.
     */
    public static final <T> List<T> copy(List<Object> from, List<T> to) {
        try {
            BeanUtils.copyProperties(to, from);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return to;
    }
}
