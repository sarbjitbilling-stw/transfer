package sbpackage.api.osgi.util;

public class Preconditions {
    public static void checkArgument(boolean predicate, Object reason) {
        if (!predicate) {
            throw new IllegalArgumentException(reason.toString());
        }
    }

    public static void checkArgument(boolean predicate, String reason, Object... reasonArgs) {
        if (!predicate) {
            throw new IllegalArgumentException(String.format(reason, reasonArgs));
        }
    }

    public static <T> T checkNotNull(T t, Object reason) {
        if (t == null) {
            throw new NullPointerException(reason.toString());
        }

        return t;
    }

    public static <T> T checkNotNull(T t, String reason, Object... reasonArgs) {
        if (t == null) {
            throw new NullPointerException(String.format(reason, reasonArgs));
        }

        return t;
    }

    public static void checkState(boolean predicate, Object reason) {
        if (!predicate) {
            throw new IllegalStateException(reason.toString());
        }
    }

    public static void checkState(boolean predicate, String reason, Object... reasonArgs) {
        if (!predicate) {
            throw new IllegalStateException(String.format(reason, reasonArgs));
        }
    }
}
