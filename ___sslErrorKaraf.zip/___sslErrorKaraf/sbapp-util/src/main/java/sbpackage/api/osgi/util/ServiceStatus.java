package sbpackage.api.osgi.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.TreeMap;

import static sbpackage.api.osgi.util.ServiceStatus.Summary.ERROR;
import static sbpackage.api.osgi.util.ServiceStatus.Summary.OK;


/**
 * Represents the status of a service or component.
 *
 * @author Steve Leach
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "ServiceStatus")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceStatus {

    @XmlEnum
    public enum Summary {
        OK, ERROR
    }

    @XmlType
    @XmlAccessorType(XmlAccessType.PROPERTY)
    public static class DependencyStatus {
        private String dependency;
        private Summary status;

        public DependencyStatus(String dependency, Summary status) {
            this.dependency = dependency;
            this.status = status;
        }

        @XmlElement
        public String getDependency() {
            return dependency;
        }

        @XmlElement
        public Summary getStatus() {
            return status;
        }
    }

    public static final ServiceStatus ALL_OK = new ServiceStatus(OK);

    // The base status of the resource, before accounting for dependency failures.
    private Summary baseStatus;

    // Store as a map, even though it is accessed as a list, as can only have one status per dependency
    private Map<String,Summary> dependencyStatus = new TreeMap<>();

    private final String timestamp;

    public ServiceStatus() {
        this(OK);
    }

    public ServiceStatus(Summary baseStatus) {
        this.baseStatus = baseStatus;
        this.timestamp = LocalDateTime.now().toString();
    }

    @JsonProperty("summary")
    @XmlElement(name = "summary")
    public Summary getSummary() {
        // If the base status is not OK, report that
        if (baseStatus != OK) {
            return baseStatus;
        }
        // If any dependency is not OK, report an error
        for (Summary depStatus : dependencyStatus.values()) {
            if (depStatus != OK) {
                return ERROR;
            }
        }
        // Otherwise report everything is OK
        return OK;
    }

    @JsonProperty("dependencies")
    @XmlElement(name = "dependencies")
    public DependencyStatus[] getDependencyStatuses() {
        DependencyStatus[] result = new DependencyStatus[dependencyStatus.size()];
        int index = 0;
        for (String dependency : dependencyStatus.keySet()) {
            result[index++] = new DependencyStatus(dependency, dependencyStatus.get(dependency));
        }
        return result;
    }

    public void setDependencyStatus(String dependency, Summary status) {
        dependencyStatus.put(dependency, status);
    }

    public void addDependencyStatus(String dependencyName, boolean isAvailable) {
        setDependencyStatus(dependencyName, isAvailable  ? OK : ERROR);
    }

    @XmlElement
    public String getTimestamp() {
        return timestamp;
    }
}
