package sbpackage.api.osgi.util.identity;

/**
 * User Identity value object.
 *
 * @author Steve Leach
 */
public class UserIdentity {
    private String username = null;
    private String emailAddress = null;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public boolean hasUsername() {
        return (username != null) && (username.trim().length() > 0);
    }

    @Override
    public String toString() {
        return String.format("UserIdentity: %s (%s)", username, hashCode());
    }
}
