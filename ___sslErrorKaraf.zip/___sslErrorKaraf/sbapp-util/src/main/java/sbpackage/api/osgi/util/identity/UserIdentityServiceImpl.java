package sbpackage.api.osgi.util.identity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Named;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.Base64;
import java.util.Enumeration;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import sbpackage.api.osgi.util.GeneralConfigurationService;
import sbpackage.api.osgi.util.STWTechnicalException;

/**
 * The UserIdentityService is responsible for identifying the current user.
 *
 * It uses a variety of methods to find the identity...
 *
 * 1. A basic auth header
 * 2. An NTLM header
 * 3. A cookie called stw-sso containing a copy of the NTLM header
 * 4. A configured default user identity
 *
 * The configured identity is provided in the etc/wss.osgi.util.cfg file, and can be empty. It is
 * also possible to configure the service to throw an exception if no user identity is available.
 *
 * @author Steve Leach
 */
@Named
@Component(service = {UserIdentityService.class})
public class UserIdentityServiceImpl implements UserIdentityService {
    Logger log = LoggerFactory.getLogger(this.getClass());

    private final Base64.Decoder base64 = Base64.getDecoder();

    private GeneralConfigurationService configurationService;
        
    @Reference
    public void setConfigurationService(GeneralConfigurationService configurationService) {
        this.configurationService = configurationService;
    }

    /**
     * Tries to find a user identity in the http request.
     */
    @Override
    public UserIdentity getUserIdentity(HttpServletRequest request) {
        UserIdentity identity = new UserIdentity();

        log.debug("getUserIdentity v8 start");

        if (!identity.hasUsername()) {
            getIdentityFromAuthHeader(request, identity);
        }

        if (!identity.hasUsername()) {
            getIdentityFromCookie(request, identity);
        }

        if (!identity.hasUsername()) {
            getDefaultIdentityFromConfiguration(identity);
        }

        if (!identity.hasUsername()) {
            log.warn("Unable to determine user identity for request {}", request.getRequestURI());
        }

        if (identityRequired() && !identity.hasUsername()) {
            throw new STWTechnicalException("Unable to identify user", Response.Status.UNAUTHORIZED);
        }
        
        log.debug("getUserIdentity v8 end");
        return identity;
    }
    
    private boolean identityRequired() {
        return configurationService.requiresIdentity();
    }

    private boolean basicAuthAllowed() {
        return configurationService.allowBasicAuth();
    }
    
    private void getDefaultIdentityFromConfiguration(UserIdentity identity) {
        log.trace("Looking for configured default user name");

        log.trace("Injected config service hashcode {}", configurationService.configurationInstanceId());

        String username = configurationService.getDefaultUserIdenitity();

        log.trace("Configured default username: {}", username);

        if ((username != null) && (username.trim().length() > 0)) {
            log.debug("  Using configured default user name: {}", username);
            identity.setUsername(username);
        } else {
            log.info("  No default username configured");
        }
    }

    void getIdentityFromCookie(HttpServletRequest request, UserIdentity identity) {
        log.debug("Looking for identity in stw-sso cookie");
        if ((request == null) || (request.getCookies() == null)) {
            return;
        }
        for (Cookie cookie : request.getCookies()) {
            log.trace("  Cookie: {}", cookie.getName());
            if (cookie.getName().startsWith("stw-sso")) {
                identity.setUsername(getNtlmIdentity(cookie.getValue()));
                log.debug("  Found identity in {} cookie: {}", cookie.getName(), identity.getUsername());
                return;
            }
        }
    }

    void getIdentityFromAuthHeader(HttpServletRequest request, UserIdentity identity) {
        log.debug("Looking for identity in header");
        logHeaders(request);

        String authHeader = request.getHeader("Authorization");

        if (authHeader == null) {
            log.info("  No auth header found");
            return;
        }

        log.debug("  Auth header: {}", authHeader);

        if (authHeader.startsWith("Basic ")) {
            if (basicAuthAllowed()) {
                identity.setUsername(getBasicAuthIdentity(authHeader));
                log.debug("  Found identity basic auth header: {}", identity.getUsername());
            }
        } else if (isNtlmOrNegotiate(authHeader)) {
            identity.setUsername(getNtlmIdentity(authHeader));
            log.debug("  Found identity basic NTLM header: {}", identity.getUsername());
        }
    }

    private boolean isNtlmOrNegotiate(String authHeader) {
        return authHeader.startsWith("NTLM ") || authHeader.startsWith("Negotiate ");
    }

    private void logHeaders(HttpServletRequest request) {
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement().toString();
            String value = request.getHeader(headerName);
            log.trace("  Header {} = {}", headerName, value);
        }

    }

    String getNtlmIdentity(String auth) {
        log.trace("Handling NTLM header: {}", auth);

        int spacePos = auth.indexOf(' ');

        byte[] msg = base64.decode(auth.substring(spacePos+1));

        int off = 30;

        int length = msg[off + 9] * 256 + msg[off + 8];
        int offset = msg[off + 11] * 256 + msg[off + 10];
        String s = new String(msg, offset, length);

        s = getEveryOtherCharacter(s);

        log.trace("  NTLM identity={}", s);

        return s;
    }

    private String getEveryOtherCharacter(String s) {
        StringBuilder sb = new StringBuilder();
        for (int index = 0; index < s.length(); index += 2) {
            sb.append(s.charAt(index));
        }
        s = sb.toString();
        return s;
    }

    String getBasicAuthIdentity(String auth) {
        log.trace("  Handling Basic Auth header");

        auth = auth.substring(6);
        auth = new String(base64.decode(auth));
        auth = auth.split(":")[0];

        log.trace("  Basic auth identity={}", auth);

        return auth;
    }

}
