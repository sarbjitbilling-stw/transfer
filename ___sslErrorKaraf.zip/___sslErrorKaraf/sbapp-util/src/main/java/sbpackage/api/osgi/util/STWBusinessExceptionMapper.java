package sbpackage.api.osgi.util;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sbpackage.api.osgi.model.common.ErrorDto;

/**
 * Created by rtai on 07/06/2017.
 */
public class STWBusinessExceptionMapper implements ExceptionMapper<STWBusinessException> {

    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String TXN_REFERENCE_NUMBER = "TransactionReferenceNumber";

    private static final String CAUSE = "Cause";

    @Context
    private UriInfo uri;

    @Context
    private Request request;

    @Override
    public Response toResponse(STWBusinessException exception) {
        log.warn("Business error processing request={} {}", request.getMethod(), uri.getRequestUri(), exception);
        String errorDescription = exception.getDescription();
        if (StringUtils.isBlank(errorDescription)) {
            errorDescription = exception.getMessage();
        }
        ErrorDto errorDto = new ErrorDto(getErrorCategory(exception), exception.getErrorCode(),
                errorDescription);
        Map<String,Object> details = new HashMap<>();
        if(exception.getTransactionReference()!=null){
        	details.put(TXN_REFERENCE_NUMBER,exception.getTransactionReference());
        }
        if(exception.getCause() != null) {
            // converting to String to make response JSON easier to read
            details.put(CAUSE, exception.getCause().toString());
        }
        errorDto.setDetails(details);
        return Response.status(exception.getHttpStatusCode())
                .header(HttpHeaders.CONTENT_TYPE, "application/json").entity(errorDto).build();
    }

    private static ErrorDto.ErrorCategory getErrorCategory(STWBusinessException exception) {
        try {
            return ErrorDto.ErrorCategory.valueOf(exception.getErrorCategory());
        } catch (Exception ex) {
            return ErrorDto.ErrorCategory.TARGET;
        }
    }
}