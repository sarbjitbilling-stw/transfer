package sbpackage.api.osgi.util;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ExceptionMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonMappingException;

import sbpackage.api.osgi.model.common.ErrorDto;
import sbpackage.api.osgi.model.common.ErrorDto.ErrorCategory;

public class JsonMappingExceptionMapper implements ExceptionMapper<JsonMappingException> {
    private static final Logger LOG = LoggerFactory.getLogger(JsonMappingExceptionMapper.class);

    @Context
    private UriInfo uri;

    @Context
    private Request request;

    @Context
    private HttpHeaders headers;

    @Override
    public Response toResponse(JsonMappingException e) {
        LOG.warn("JsonMappingException when processing request={} {}", request.getMethod(), uri.getBaseUri(), e);
        ErrorDto errorDto = new ErrorDto(ErrorCategory.STW_SERVICES, "JSON_MAPPING_001", e.getMessage());

        // to allow for XML as well as JSON
        String requestContentType = headers.getHeaderString(HttpHeaders.CONTENT_TYPE);
        // @formatter:off
        return Response.status(Response.Status.BAD_REQUEST)
                .header(HttpHeaders.CONTENT_TYPE, requestContentType)
                .entity(errorDto)
                .build();
        // @formatter:on
    }
}
