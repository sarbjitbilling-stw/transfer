package sbpackage.api.osgi.util;

import org.apache.commons.lang3.StringUtils;

public class STWLeUtil {

	public STWLeUtil() {
        super();
    }
	
	public static String leftPadLEIfNeeded(final String str, final int size, char charToPad) {
		return StringUtils.leftPad(str, size, charToPad);
	}
	
	public static String leftPadLEIfNeeded(final String leId) {
		return StringUtils.leftPad(leId,9,'0');
	}
	
	public static String leftPadLEIfNeeded(final Long leId) {
		if (leId != null) {
			return StringUtils.leftPad(String.valueOf(leId), 9, '0');
		}
		return StringUtils.EMPTY;
	}

}