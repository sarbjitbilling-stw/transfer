package sbpackage.api.osgi.util.identity;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by sleach on 31/08/2017.
 */
public interface UserIdentityService {
    UserIdentity getUserIdentity(HttpServletRequest request);
}
