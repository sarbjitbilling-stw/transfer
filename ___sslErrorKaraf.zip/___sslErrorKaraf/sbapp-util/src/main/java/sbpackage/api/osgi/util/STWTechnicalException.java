/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.util;

import javax.ws.rs.core.Response;

/**
 *
 * @author Mark
 */
public class STWTechnicalException extends STWBaseException {

    /**
     * Creates a new instance of <code>STWTechnicalException</code> without
     * detail message.
     */
    public STWTechnicalException() {
    }

    /**
     * Constructs an instance of <code>STWTechnicalException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public STWTechnicalException(String msg) {
        super(msg);
    }

    public STWTechnicalException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public STWTechnicalException(String msg, Response.Status httpStatusCode) {
        super(msg,httpStatusCode);
    }
}
