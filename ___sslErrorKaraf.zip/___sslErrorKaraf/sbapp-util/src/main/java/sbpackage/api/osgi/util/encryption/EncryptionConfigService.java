package sbpackage.api.osgi.util.encryption;

/**
 * Created by DA on 17/01/2018.
 */
public interface EncryptionConfigService {
    String PID = "wss.osgi.util.encryption";
    String getKeystoreKey();
    String getKeystorePass();
    String getPrivateKeyAlias();
    String getTruststoreKey();
    String getTruststorePass();
    String getPublicKeyAlias();
    String getKeypass();
}
