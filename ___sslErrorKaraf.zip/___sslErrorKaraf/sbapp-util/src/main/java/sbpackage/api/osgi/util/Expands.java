package sbpackage.api.osgi.util;

public enum Expands implements Expandable {
	roledetail, customer, account, readingHistory, meterAddress, readType, latestBillableRead, summary, property, detail, registration, roles, basicInfo;
}
