package sbpackage.api.osgi.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * CXF interceptor to facilitate logging of client session ID.
 *
 * Extracts the value of a custom http header and writes it into the
 * SLF4J MDC so that it is available to Log4J appenders.
 *
 * To include the client session ID in log files, add the following to
 * the Log4J appender pattern...
 *
 *      %-20X{wss-client-session-id}
 *
 * @author Steve Leach
 */
public class ClientSessionIdInterceptor extends AbstractPhaseInterceptor {

    private static final String ANALYTICS_STATUS_ENDPOINT = "/cxf/analytics/status";
    private static final String HEALTH_CHECK_ENDPOINT = "/cxf/health-checks";
	public static final String HTTP_HEADER_NAME = "wss-client-session-id";
    public static final String MDC_KEY = "wss-client-session-id";

    Logger log = LoggerFactory.getLogger(this.getClass());

    public ClientSessionIdInterceptor() {
        super(Phase.READ);
    }

    public ClientSessionIdInterceptor(String phase) {
        super(phase);
    }

    @Override
    public void handleMessage(Message message) throws Fault {
        MDC.put(MDC_KEY,"");
        HttpServletRequest request = (HttpServletRequest) message.get("HTTP.REQUEST");
        log.trace("Handling message: {}", request.getRequestURI());
        String sessionID = request.getHeader(HTTP_HEADER_NAME);
        if (sessionID != null && sessionID.trim().length() > 0) {
            log.debug("Found client session ID {} in call to {}", sessionID, request.getRequestURI());
            MDC.put(MDC_KEY, sessionID);
		} else {
			if (StringUtils.isNotEmpty(request.getRequestURI())
                    && !request.getRequestURI().contains(ANALYTICS_STATUS_ENDPOINT)
                    && !request.getRequestURI().contains(HEALTH_CHECK_ENDPOINT)) {
				log.warn("No session ID found in call from {} to {}", request.getRemoteAddr(), request.getRequestURI());
			}
		}

        log.trace("Message handled");
    }
}
