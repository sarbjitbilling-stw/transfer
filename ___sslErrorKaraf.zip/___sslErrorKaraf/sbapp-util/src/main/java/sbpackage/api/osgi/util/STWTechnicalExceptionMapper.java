package sbpackage.api.osgi.util;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ExceptionMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sbpackage.api.osgi.model.common.ErrorDto;

/**
 * Created by rtai on 14/06/2017.
 */
public class STWTechnicalExceptionMapper implements ExceptionMapper<STWTechnicalException> {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Context
    private UriInfo uri;

    @Context
    private Request request;

    @Override
    public Response toResponse(STWTechnicalException exception) {
        log.error("Technical error processing request={} {}", request.getMethod(), uri.getRequestUri(), exception);

        ErrorDto errorDto;
        if (exception.httpStatusCode.equals(Response.Status.UNAUTHORIZED)) {
            errorDto = new ErrorDto(ErrorDto.ErrorCategory.STW_SERVICES,"101",exception.getMessage());
        } else {
            errorDto = new ErrorDto(ErrorDto.ErrorCategory.TARGET, "503", exception.getMessage());
        }

        return Response.status(exception.getHttpStatusCode()).header("Content-Type", "application/json").entity(errorDto).build();
    }
}
