package sbpackage.api.osgi.util;

import sbpackage.api.osgi.util.STWBusinessException;

public class NotFoundException extends STWBusinessException {

    public NotFoundException(String msg) {
        super(msg);
    }

}
