package sbpackage.api.osgi.util;

import org.osgi.service.cm.ConfigurationException;

import java.util.Dictionary;
import java.util.Map;

public class ConfigServiceUtil {
    private ConfigServiceUtil() {
    }

    public static String getValueFromProperties(Dictionary<String, ?> properties, String propertyName)
            throws ConfigurationException {
        Object propertyValue = properties.get(propertyName);

        if (propertyValue == null) {
            throw new ConfigurationException(propertyName, "Cannot be null");
        }

        if (!(propertyValue instanceof String)) {
            // should never happen
            throw new ConfigurationException(propertyName, "Must be a String");
        }

        return (String) propertyValue;
    }

    public static void updateConfig(Map<String, String> config, Dictionary<String, ?> properties,
                                    String... propertyNames)
            throws ConfigurationException {
        for (String propertyName : propertyNames) {
            String propertyValue = getValueFromProperties(properties, propertyName);
            config.put(propertyName, propertyValue);
        }
    }
}
