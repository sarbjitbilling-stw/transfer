/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.util;

import javax.ws.rs.core.Response;

/**
 *
 * @author Mark
 */
public class STWBaseException extends RuntimeException {

	protected Response.Status httpStatusCode = Response.Status.INTERNAL_SERVER_ERROR;

	protected static final String DEFAULT_ERROR_CODE = "100";

	/**
	 * Creates a new instance of <code>STWBaseException</code> without detail
	 * message.
	 */
	public STWBaseException() {
	}

	/**
	 * Constructs an instance of <code>STWBaseException</code> with the
	 * specified detail message.
	 *
	 * @param msg
	 *            the detail message.
	 */
	public STWBaseException(String msg) {
		super(msg);
	}

	public STWBaseException(String msg, Throwable t) {
		super(msg, t);
	}

	public STWBaseException(String msg, Response.Status httpStatusCode) {
		super(msg);
		this.httpStatusCode = httpStatusCode;
	}

	public Response.Status getHttpStatusCode() {
		return this.httpStatusCode;
	}
}
