package sbpackage.api.osgi.util;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HEAD;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import sbpackage.api.osgi.model.common.ContactDto;
import sbpackage.api.osgi.util.identity.UserIdentity;
import sbpackage.api.osgi.util.identity.UserIdentityService;

/**
 * Created by sleach on 07/08/2017.
 */
public abstract class AbstractResource {

    protected static final String CONTACT_INFO_HEADER = "X-ContactInfo";
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AbstractResource.class);
    private static ObjectMapper objectMapper = new ObjectMapper();
    protected static final String HEADER_DM = "DM";
    public static final String HEADER_STW_AGENT_ID = "STW-Agent-ID";

    @Context
    private HttpHeaders headers;


    @Context
    protected HttpServletRequest httpServletRequest;

    @Inject
    @OsgiService
    UserIdentityService userIdentityService;

    protected UserIdentity getUserIdentity() {
        if (userIdentityService != null) {
            return userIdentityService.getUserIdentity(httpServletRequest);
        } else {
            return new UserIdentity();
        }
    }
    
    protected Optional<UserIdentity> getOptionalUserIdentity() {
        if (userIdentityService != null) {
            UserIdentity userIdentity = userIdentityService.getUserIdentity(httpServletRequest);
            return userIdentity.hasUsername() ? Optional.of(userIdentity):Optional.empty();
        } else {
            return Optional.empty();
        }
    }
    
    protected Optional<String> getOptionalUsername() {
       UserIdentity identity = getUserIdentity();
       return identity.hasUsername()?Optional.ofNullable(identity.getUsername()):Optional.empty();
    }
    
    @GET
    @Produces({ "application/json" })
    @Path("/status")
    public final Response status() {
        return Response.ok().entity(getServiceStatus()).build();
    }

    protected ServiceStatus getServiceStatus() {
        return ServiceStatus.ALL_OK;
    }

    @HEAD
    public Response head(@Context HttpHeaders headers) {
        if (getServiceStatus().getSummary().equals(ServiceStatus.Summary.OK)) {
            String ping = headers.getHeaderString("ping");
            return Response.notModified().header("ping-response", ping).build();
        } else {
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).build();
        }
    }

    protected Optional<ContactDto> getContactDto(){
    	List<String> contactInfoProps = getRequestHeaders(CONTACT_INFO_HEADER);
    	if(contactInfoProps == null || contactInfoProps.isEmpty()){return Optional.empty();}
        String contactDtoStr = contactInfoProps.get(0);
        if(StringUtils.isEmpty(contactDtoStr)){ return Optional.empty();}
        try {
            return Optional.of(objectMapper.readValue(contactDtoStr, ContactDto.class));
        } catch (IOException ex) {
            LOGGER.error("Unable to deserialise ContactDto from header \"X-ContactInfo\"", ex);
        }
        return Optional.empty();
    }

    protected ContactDto getContactDtoOrElseThrow() {
        return getContactDto()
                .orElseThrow(() -> new STWBusinessException("Unable to get ContactDto from X-ContactInfo header"));
    }

    protected List<String> getRequestHeaders(String contactInfoHeader) {
        return headers.getRequestHeader(contactInfoHeader);
    }

    protected String getHeaderString(String name) {
        return headers.getHeaderString(name);
    }
}
