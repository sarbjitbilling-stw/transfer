package sbpackage.api.osgi.util.logging;

import org.slf4j.Logger;
import org.slf4j.Marker;

import java.util.LinkedList;
import java.util.List;

/**
 * A simple implementation of the SLF4J Logger interface that outputs to the console and records logged messages.
 */
public class DebugLogger implements Logger {

    private List<String> messages = new LinkedList<>();

    public void log(String message, Object... args) {
        String loggedMessage = message;

        int nextArg = 0;
        while (loggedMessage.contains("{}")) {
            //System.out.println(loggedMessage);
            loggedMessage = loggedMessage.replaceFirst("\\{\\}", args[nextArg++].toString());
        }

        System.out.println(loggedMessage);
        messages.add(loggedMessage);
    }

    public List<String> getLoggedMessages() {
        return messages;
    }

    public boolean logsContain(String text) {
        for (String message : messages) {
            if (message.contains(text)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String getName() {
        return "DebugLogger";
    }

    @Override
    public boolean isTraceEnabled() {
        return true;
    }

    @Override
    public void trace(String s) {
        log(s);
    }

    @Override
    public void trace(String s, Object o) {
        log(s,o);
    }

    @Override
    public void trace(String s, Object o, Object o1) {
        log(s,o,o);
    }

    @Override
    public void trace(String s, Object... objects) {
        log(s,objects);
    }

    @Override
    public void trace(String s, Throwable throwable) {
        log(s);
    }

    @Override
    public boolean isTraceEnabled(Marker marker) {
        return isTraceEnabled();
    }

    @Override
    public void trace(Marker marker, String s) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void trace(Marker marker, String s, Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void trace(Marker marker, String s, Object o, Object o1) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void trace(Marker marker, String s, Object... objects) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void trace(Marker marker, String s, Throwable throwable) {
        throw new UnsupportedOperationException();

    }

    @Override
    public boolean isDebugEnabled() {
        return true;
    }

    @Override
    public void debug(String s) {
        log(s);
    }

    @Override
    public void debug(String s, Object o) {
        log(s, o);
    }

    @Override
    public void debug(String s, Object o, Object o1) {
        log(s, o, o);
    }

    @Override
    public void debug(String s, Object... objects) {
        log(s, objects);
    }

    @Override
    public void debug(String s, Throwable throwable) {
        log(s);
    }

    @Override
    public boolean isDebugEnabled(Marker marker) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void debug(Marker marker, String s) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void debug(Marker marker, String s, Object o) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void debug(Marker marker, String s, Object o, Object o1) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void debug(Marker marker, String s, Object... objects) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void debug(Marker marker, String s, Throwable throwable) {
        throw new UnsupportedOperationException();

    }

    @Override
    public boolean isInfoEnabled() {
        return true;
    }

    @Override
    public void info(String s) {
        log(s);
    }

    @Override
    public void info(String s, Object o) {
        log(s,o);
    }

    @Override
    public void info(String s, Object o, Object o1) {
        log(s,o,o1);
    }

    @Override
    public void info(String s, Object... objects) {
        log(s,objects);
    }

    @Override
    public void info(String s, Throwable throwable) {
        log(s);
    }

    @Override
    public boolean isInfoEnabled(Marker marker) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void info(Marker marker, String s) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void info(Marker marker, String s, Object o) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void info(Marker marker, String s, Object o, Object o1) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void info(Marker marker, String s, Object... objects) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void info(Marker marker, String s, Throwable throwable) {
        throw new UnsupportedOperationException();

    }

    @Override
    public boolean isWarnEnabled() {
        return true;
    }

    @Override
    public void warn(String s) {
        log(s);
    }

    @Override
    public void warn(String s, Object o) {
        log(s,o);
    }

    @Override
    public void warn(String s, Object... objects) {
        log(s,objects);
    }

    @Override
    public void warn(String s, Object o, Object o1) {
        log(s,o,o1);
    }

    @Override
    public void warn(String s, Throwable throwable) {
        log(s);
    }

    @Override
    public boolean isWarnEnabled(Marker marker) {
        return false;
    }

    @Override
    public void warn(Marker marker, String s) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void warn(Marker marker, String s, Object o) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void warn(Marker marker, String s, Object o, Object o1) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void warn(Marker marker, String s, Object... objects) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void warn(Marker marker, String s, Throwable throwable) {
        throw new UnsupportedOperationException();

    }

    @Override
    public boolean isErrorEnabled() {
        return true;
    }

    @Override
    public void error(String s) {
        log(s);
    }

    @Override
    public void error(String s, Object o) {
        log(s,o);
    }

    @Override
    public void error(String s, Object o, Object o1) {
        log(s,o,o1);
    }

    @Override
    public void error(String s, Object... objects) {
        log(s,objects);
    }

    @Override
    public void error(String s, Throwable throwable) {
        log(s);
    }

    @Override
    public boolean isErrorEnabled(Marker marker) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void error(Marker marker, String s) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void error(Marker marker, String s, Object o) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void error(Marker marker, String s, Object o, Object o1) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void error(Marker marker, String s, Object... objects) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void error(Marker marker, String s, Throwable throwable) {
        throw new UnsupportedOperationException();

    }
}
