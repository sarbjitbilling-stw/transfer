package sbpackage.api.osgi.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import static java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME;

/**
 * Created by rtai on 13/06/2017.
 */
@Provider
public class JacksonContextResolver implements ContextResolver<ObjectMapper> {

    // Custom OffsetDateTime serializer/deserializer are used instead of disabling
    // Jackson features SerializationFeature.WRITE_DATES_AS_TIMESTAMPS and
    // DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE.
    // This is done to avoid introducing issues that might be caused by the changes
    // in how other date time objects would be serialized/deserialized.

    private static final JsonSerializer<OffsetDateTime> OFFSET_DATE_TIME_SERIALIZER = new JsonSerializer<OffsetDateTime>() {
        @Override
        public void serialize(OffsetDateTime offsetDateTime, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
            jsonGenerator.writeString(ISO_OFFSET_DATE_TIME.format(offsetDateTime));
        }
    };

    private static final JsonDeserializer<OffsetDateTime> OFFSET_DATE_TIME_DESERIALIZER = new JsonDeserializer<OffsetDateTime>() {
        @Override
        public OffsetDateTime deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
            return OffsetDateTime.parse(jsonParser.getText(), ISO_OFFSET_DATE_TIME);
        }
    };

    private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;

    private SerializationManager serializationManager;

    public JacksonContextResolver() {
        this(DEFAULT_FORMATTER);
    }

    public JacksonContextResolver(DateTimeFormatter dateTimeFormatter) {
        serializationManager = new SerializationManager.Config()
                .with(LocalDate.class,
                        new LocalDateSerializer(dateTimeFormatter),
                        new LocalDateDeserializer(dateTimeFormatter))
                .with(OffsetDateTime.class, OFFSET_DATE_TIME_SERIALIZER, OFFSET_DATE_TIME_DESERIALIZER)
                .configure();
    }

    @Override
    public ObjectMapper getContext(Class<?> arg0) {
        return serializationManager.getObjectMapper();
    }

}
