package sbpackage.api.osgi.util.encryption;

import java.io.FileInputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sbpackage.api.osgi.util.STWTechnicalException;

/**
 * Created by DA on 11/01/2018.
 */
@Named
@OsgiServiceProvider(classes = {EncryptionService.class})
public class EncryptionServiceImpl implements EncryptionService {

    @Inject
    private EncryptionConfigService encryptionConfigService;

    private final String ALGORITHM = "RSA";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public String encrypt(String text) {
        logger.debug("encrypt start");
        try {
            final PublicKey publicKey = extractPublicKeyFromKeystore();
            byte[] cipherText = encrypt(text, publicKey);
            logger.debug("encrypt end");
            return Base64.getEncoder().encodeToString(cipherText);
        } catch (Exception e) {
            logger.warn("encrypt failed:{}", e.getMessage());
            throw new STWTechnicalException("encrypt failed", e);
        }
    }

    @Override
    public String decrypt(String cipherText) {
        logger.debug("decrypt start");
        try {
            final PrivateKey privateKey = extractPrivateKeyFromKeystore();
            String plainText = decrypt(Base64.getDecoder().decode(cipherText), privateKey);
            logger.debug("decrypt end");
            return plainText;
        } catch (Exception e) {
            logger.warn("decrypt failed:{}", e.getMessage());
            throw new STWTechnicalException("decrypt failed", e);
        }
    }

    @Override
    public String getPublicKey() {
        logger.debug("getPublicKey start");
        try {
            final PublicKey publicKey = extractPublicKeyFromKeystore();
            String encodedPublicKey = Base64.getEncoder().encodeToString(publicKey.getEncoded());
            logger.debug("getPublicKey end");
            return encodedPublicKey;
        } catch (Exception e) {
            logger.warn("getPublicKey failed Keystore: {} and alias: {}:{}", encryptionConfigService.getTruststoreKey(), encryptionConfigService.getPublicKeyAlias(), e.getMessage());
            throw new STWTechnicalException("getPublicKey failed", e);
        }
    }

    @Override
    public byte[] symmetricDecrypt(byte[] encryptedIvTextBytes, byte[] key) {
        try {
            int ivSize = 16;

            // Extract IV.
            byte[] iv = new byte[ivSize];
            System.arraycopy(encryptedIvTextBytes, 0, iv, 0, iv.length);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

            // Extract encrypted part.
            int encryptedSize = encryptedIvTextBytes.length - ivSize;
            byte[] encryptedBytes = new byte[encryptedSize];
            System.arraycopy(encryptedIvTextBytes, ivSize, encryptedBytes, 0, encryptedSize);

            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");

            // Decrypt.
            Cipher cipherDecrypt = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipherDecrypt.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);
            byte[] decrypted = cipherDecrypt.doFinal(encryptedBytes);

            return decrypted;

        } catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException ex) {
            throw new STWTechnicalException("decrytion failed", ex);
        }
    }

    @Override
    public byte[] symmetricEncrypt(String text, String key) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    private PublicKey extractPublicKeyFromKeystore() {
        logger.debug("extractPublicKeyFromKeystore Keystore: {}, and alias: {} start", encryptionConfigService.getTruststoreKey(), encryptionConfigService.getPublicKeyAlias());
        try (FileInputStream publicKeyFile = new FileInputStream(encryptionConfigService.getTruststoreKey())) {
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            keystore.load(publicKeyFile, encryptionConfigService.getTruststorePass().toCharArray());
            Certificate cert = keystore.getCertificate(encryptionConfigService.getPublicKeyAlias());
            logger.debug("extractPublicKeyFromKeystore Keystore: {} and alias: {} end", encryptionConfigService.getTruststoreKey(), encryptionConfigService.getPublicKeyAlias());
            return cert.getPublicKey();
        } catch (Exception e) {
            logger.warn("extractPublicKeyFromKeystore failed Keystore: {} and alias: {}:{}", encryptionConfigService.getTruststoreKey(), encryptionConfigService.getPublicKeyAlias(), e.getMessage());
            throw new STWTechnicalException("extractPublicKeyFromKeystore failed", e);
        }
    }

    private PrivateKey extractPrivateKeyFromKeystore() {
        logger.debug("extractPrivateKeyFromKeystore Keystore: {} and alias: {} start", encryptionConfigService.getKeystoreKey(), encryptionConfigService.getPrivateKeyAlias());
        PrivateKey privateKey = null;
        try (FileInputStream privateKeyFile = new FileInputStream(encryptionConfigService.getKeystoreKey())) {
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            keystore.load(privateKeyFile, encryptionConfigService.getKeystorePass().toCharArray());
            String alias = encryptionConfigService.getPrivateKeyAlias();
            Key key = keystore.getKey(alias, encryptionConfigService.getKeypass().toCharArray());
            if (key instanceof PrivateKey) {
                Certificate cert = keystore.getCertificate(alias);
                PublicKey publicKey = cert.getPublicKey();
                KeyPair keypair = new KeyPair(publicKey, (PrivateKey) key);
                privateKey = keypair.getPrivate();
            }
            logger.debug("extractPrivateKeyFromKeystore keystore: {} and alias: {} end", encryptionConfigService.getKeystoreKey(), encryptionConfigService.getPrivateKeyAlias());
            return privateKey;
        } catch (Exception e) {
            logger.warn("extractPrivateKeyFromKeystore failed keystore: {} and alias: {} end:{}", encryptionConfigService.getKeystoreKey(), encryptionConfigService.getPrivateKeyAlias(), e.getMessage());
            throw new STWTechnicalException("extractPrivateKeyFromKeystore failed", e);
        }
    }

    private byte[] encrypt(String text, PublicKey key) {
        logger.debug("encrypt start");
        try {
            final Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] cipherText = cipher.doFinal(text.getBytes());
            logger.debug("encrypt end");
            return cipherText;
        } catch (Exception e) {
            logger.warn("encrypt failed:{}", e.getMessage());
            throw new STWTechnicalException("encrypt failed", e);
        }
    }

    private String decrypt(byte[] text, PrivateKey key) {
        logger.debug("decrypt start");
        try {
            final Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedText = cipher.doFinal(text);
            logger.debug("decrypt end");
            return new String(decryptedText);
        } catch (Exception e) {
            logger.warn("decrypt failed:{}", e.getMessage());
            throw new STWTechnicalException("decrypt failed", e);
        }
    }
}
