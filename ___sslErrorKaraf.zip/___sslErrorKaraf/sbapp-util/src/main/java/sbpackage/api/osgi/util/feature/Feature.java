package sbpackage.api.osgi.util.feature;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum Feature {
    BDS_PAYMENT_PLAN("BdsPaymentPlan");

    private static final Map<String, Feature> featureNameIndex = buildFeatureNameIndex();

    private final String name;

    Feature(String name) {
        this.name = name;
    }

    private static final Map<String, Feature> buildFeatureNameIndex() {
        Map<String, Feature> index = new HashMap<>();
        for (Feature feature : Feature.values()) {
            index.put(feature.getName().toUpperCase(), feature);
        }
        return Collections.unmodifiableMap(index);
    }

    public String getName() {
        return this.name;
    }

    public static Optional<Feature> fromName(String name) {
        String standardisedFeatureName = name != null ? name.trim().toUpperCase() : name;

        return Optional.ofNullable(featureNameIndex.get(standardisedFeatureName));
    }
}
