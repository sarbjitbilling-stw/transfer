package sbpackage.api.osgi.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Named;
import javax.inject.Singleton;

import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by sleach on 31/08/2017.
 */
@Named
@Singleton
@Component(service = {GeneralConfigurationService.class}, configurationPid = "wss.osgi.util")
public class GeneralConfigurationServiceImpl implements GeneralConfigurationService {
    Logger log = LoggerFactory.getLogger(this.getClass());

    public static final String PID = "wss.osgi.util";
    static final String CACHE_METHOD = PID + ".cache.method.";
    static final String CACHE_ENABLED = PID + ".cache.enabled";
    static final String VERSION_PROPERTY = PID + ".version";
    static final String GIT_BRANCH = PID + ".git.branch";
    static final String GIT_COMMIT_ID = PID + ".git.commit.id";
    static final String GIT_COMMIT_TIME = PID + ".git.commit.time";
    static final String GIT_COMMIT_USER_EMAIL = PID + ".git.commit.user.email";
    static final String GIT_COMMIT_MESSAGE_SHORT = PID + ".git.commit.message.short";

    private String defaultUserIdenitity = null;
    private boolean requireIdentity = false;
    private boolean allowBasicAuth = true;
    private boolean enableCacheService = true;
    private String version;
    private String gitBranch;
    private String gitCommitId;
    private String gitCommitTime;
    private String gitCommitUserEmail;
    private String gitCommitMessageShort;
    
    /*map  of method names and cache timeouut values
      the class name / method name is in the following format :- 
      ListSpecialConditionsClientImpl.getSpecialConditions(..) 
    */
    private Map<String, Long> cacheMethodTimeout = new HashMap<>();

    @Activate
    @Modified
    public synchronized void updated(Map<String, String> config) throws ConfigurationException {
        log.info("Loading configuration into instance {} : {}", this.hashCode(), config);

        if (config != null) {
            this.defaultUserIdenitity = config.get(PID + ".defaultUser");
            this.requireIdentity = ConfigurationUtil.getConfiguredBoolean(config, PID + ".requireIdentity", false);
            this.allowBasicAuth = ConfigurationUtil.getConfiguredBoolean(config, PID + ".allowBasicAuth", true);
            this.enableCacheService = ConfigurationUtil.getConfiguredBoolean(config, CACHE_ENABLED, true);
            this.version = config.get(VERSION_PROPERTY);

            this.gitBranch = config.get(GIT_BRANCH);
            this.gitCommitId = config.get(GIT_COMMIT_ID);
            this.gitCommitTime = config.get(GIT_COMMIT_TIME);
            this.gitCommitUserEmail = config.get(GIT_COMMIT_USER_EMAIL);
            this.gitCommitMessageShort = config.get(GIT_COMMIT_MESSAGE_SHORT);
       
            this.cacheMethodTimeout = config.keySet().stream()
                    .filter(key -> key.startsWith(CACHE_METHOD) && config.get(key)!=null)
                    .collect(Collectors.toMap( key->key.split(CACHE_METHOD)[1], 
                                               key->Long.parseLong(config.get(key).toString())));
        }
        log.info("Loaded default user identity = {}", this.defaultUserIdenitity);
    }

    @Override
    public String getDefaultUserIdenitity() {
        return defaultUserIdenitity;
    }

    @Override
    public String configurationInstanceId() {
        return this.getClass().getName() + "#" + this.hashCode();
    }

    @Override
    public boolean requiresIdentity() {
        return this.requireIdentity;
    }

    @Override
    public boolean allowBasicAuth() {
        return this.allowBasicAuth;
    }

    @Override
    public Optional<Long> getMethodCacheDuration(String methodName) {
        return Optional.ofNullable(cacheMethodTimeout.get(methodName));
    }

    @Override
    public boolean isCacheServiceEnable() {
        return enableCacheService;
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public String getGitBranch() {
        return gitBranch;
    }

    @Override
    public String getGitCommitId() {
        return gitCommitId;
    }

    @Override
    public String getGitCommitTime() {
        return gitCommitTime;
    }

    @Override
    public String getGitCommitUserEmail() {
        return gitCommitUserEmail;
    }

    @Override
    public String getGitCommitMessageShort() {
        return gitCommitMessageShort;
    }

}
