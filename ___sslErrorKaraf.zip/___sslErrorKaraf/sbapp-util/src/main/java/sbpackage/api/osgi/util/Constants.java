package sbpackage.api.osgi.util;

public class Constants {

	public static final String STW = "STW";
	public static final String HD = "HD";
	public static final String WSS_SITE = "wss-site";
	public static final String STWATER = "stwater";
	public static final String HDCYMRU = "hdcymru";

}
