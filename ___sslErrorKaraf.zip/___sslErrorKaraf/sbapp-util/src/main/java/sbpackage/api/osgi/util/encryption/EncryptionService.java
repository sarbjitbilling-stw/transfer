package sbpackage.api.osgi.util.encryption;

/**
 * Created by abhange on 13/01/2018.
 */
public interface EncryptionService {
    String encrypt(String text);
    String decrypt(String cipherText);
    String getPublicKey();
    
    byte[] symmetricEncrypt(String text, String key);
    byte[] symmetricDecrypt(byte[] cipherText, byte[] Key);
}
