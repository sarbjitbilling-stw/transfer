package sbpackage.api.osgi.util;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

public class TargetAccountNumberNoCheckDigitSerializer extends JsonSerializer<TargetAccountNumber> {

    @Override
    public void serialize(TargetAccountNumber value, JsonGenerator jsonGenerator, SerializerProvider serializers)
            throws IOException {
        jsonGenerator.writeString(value.getAccountNumber());
    }

}
