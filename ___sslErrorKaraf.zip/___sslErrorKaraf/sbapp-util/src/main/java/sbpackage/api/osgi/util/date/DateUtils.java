package sbpackage.api.osgi.util.date;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class DateUtils {

	public static LocalDate localDateFromUtilDate(Date theDate) {

		Instant instant = Instant.ofEpochMilli(theDate.getTime());
		LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
		LocalDate localDate = localDateTime.toLocalDate();

		return localDate;

	}

	public static Date getDateInFuture(long days) {
		return Date.from(Instant.now().plus(days, ChronoUnit.DAYS));
	}

}


