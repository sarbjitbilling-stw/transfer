package sbpackage.api.osgi.util;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import sbpackage.api.osgi.model.account.TargetAccountNumber;

public class TargetAccountNumberNoCheckDigitDeserializer extends JsonDeserializer<TargetAccountNumber> {

    @Override
    public TargetAccountNumber deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException {
        String text = jsonParser.getText();
        return StringUtils.isNotBlank(text) ? new TargetAccountNumber(text, null) : null;
    }

}
