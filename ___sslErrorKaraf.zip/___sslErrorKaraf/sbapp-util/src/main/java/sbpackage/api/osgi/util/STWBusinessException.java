/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.util;

import java.lang.reflect.Field;
import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.builder.ToStringBuilder;

import sbpackage.api.osgi.model.common.ErrorDto;

/**
 *
 * @author Mark
 */
public class STWBusinessException extends STWBaseException {

	private static final Response.Status DEFAULT_STATUS = Response.Status.BAD_REQUEST;

	/**
	 * Creates a new instance of <code>STWBusinessException</code> without
	 * detail message.
	 */
	public STWBusinessException() {
		this.httpStatusCode = DEFAULT_STATUS;
	}

	/**
	 * Constructs an instance of <code>STWBusinessException</code> with the
	 * specified detail message.
	 *
	 * @param msg
	 *            the detail message.
	 */
	public STWBusinessException(String msg) {
		super(msg);
		this.httpStatusCode = DEFAULT_STATUS;
	}

	public STWBusinessException(String msg, Throwable t) {
		super(msg, t);
		this.httpStatusCode = DEFAULT_STATUS;
	}

	/**
	 * Constructs an instance of <code>STWBusinessException</code> with the
	 * specified detail message and code.
	 *
	 * @param msg the detail message.
	 * @param httpStatusCode error code.
	 */
	public STWBusinessException(String msg, Response.Status httpStatusCode) {
		super(msg,httpStatusCode);
	}

	/**
	 * Constucts an instance with the specified message, error code and error category.
	 * @param msg the default message
	 * @param errorCode the error code
	 * @param errorCategory the error category
	 */
	public STWBusinessException(String msg, String errorCode, ErrorDto.ErrorCategory errorCategory) {
		super(msg);
        initErrorFields(msg, errorCode, errorCategory);
    }

    public STWBusinessException(String msg, String errorCode, ErrorDto.ErrorCategory errorCategory, Throwable t) {
        super(msg, t);
        initErrorFields(msg, errorCode, errorCategory);
    }

    private void initErrorFields(String msg, String errorCode, ErrorDto.ErrorCategory errorCategory) {
        this.description = msg;
        this.errorCode = errorCode;
        this.errorCategory = errorCategory.name();
        this.httpStatusCode = DEFAULT_STATUS;
	}

	private String errorCode;

	private String errorCategory;

	private String transactionReference;

	private String description;

	public static STWBusinessException fromFaultDetailSTWError(Exception faultDetailSTWError) {
		if (!faultDetailSTWError.getClass().getCanonicalName().endsWith("FaultDetailSTWError")) {
			throw new IllegalArgumentException(String.format("%s is not of expected FaultDetailSTWError type",
					faultDetailSTWError.getClass().getCanonicalName()));
		} else {
			try {
				String errorCode;
				String txnReference;
				String category = "";
				String description = "";
				Field faultInfoField = faultDetailSTWError.getClass().getDeclaredField("faultInfo");
				faultInfoField.setAccessible(true);
				Object faultInfo = faultInfoField.get(faultDetailSTWError);
				if (faultInfo.getClass().getCanonicalName().endsWith("CTypeSTWError")) {
					Class cTypeSTWError = faultInfo.getClass();
					Field errorDescriptionCodeField = cTypeSTWError.getDeclaredField("errorDescriptionCode");
					Field txnReferenceNumberField = cTypeSTWError.getDeclaredField("transactionReferenceNumber");
					Field errorCategoryField = cTypeSTWError.getDeclaredField("errorCategory");
					Field errorDescriptionField = cTypeSTWError.getDeclaredField("errorDescription");

					errorDescriptionCodeField.setAccessible(true);
					txnReferenceNumberField.setAccessible(true);
					errorCategoryField.setAccessible(true);
					errorDescriptionField.setAccessible(true);
					errorCode = (String) errorDescriptionCodeField.get(faultInfo);
					txnReference = (String) txnReferenceNumberField.get(faultInfo);
					Object errorCategory = errorCategoryField.get(faultInfo);
					if (errorCategory.getClass().getCanonicalName().endsWith("STypeErrorCategory")) {
						Field errorCategoryValueField = errorCategory.getClass().getDeclaredField("value");
						errorCategoryValueField.setAccessible(true);
						category = (String) errorCategoryValueField.get(errorCategory);
					}
					Object errorDescription = errorDescriptionField.get(faultInfo);
					if (errorDescription instanceof List) {
						List list = (List) errorDescription;
						for (Object item : list) {
							if (item.getClass().getCanonicalName().endsWith("CTypeErrorDescription")) {
								Field languageCodeField = item.getClass().getDeclaredField("languageCode");
								Field descriptionField = item.getClass().getDeclaredField("description");

								languageCodeField.setAccessible(true);
								descriptionField.setAccessible(true);
								description = (String) descriptionField.get(item);
							}
						}
					}
					STWBusinessException stwBusinessException = new STWBusinessException(description);
					stwBusinessException.description = description;
					stwBusinessException.errorCategory = category;
					stwBusinessException.errorCode = errorCode;
					stwBusinessException.transactionReference = txnReference;
					return stwBusinessException;
				}
			} catch (NoSuchFieldException e) {
				throw new IllegalArgumentException("Failed to construct STWBusinessException", e);
			} catch (IllegalAccessException e) {
				throw new IllegalArgumentException("Failed to construct STWBusinessException", e);
			}
		}
		return new STWBusinessException("Failed to parse FaultDetailSTWError");
	}

        public static void throwIfNotWhitelisted(STWBusinessException stwbe){
            if(!isWhitelisted(stwbe)) throw stwbe;
        }
        
        public static boolean isWhitelisted(STWBusinessException stwbe){
            return stwbe.errorCode.endsWith("70");
        }
        
	public String getTransactionReference() {
		return this.transactionReference;
	}

	public String getErrorCode() {
		return this.errorCode;
	}

	public String getErrorCategory() {
		return this.errorCategory;
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("errorCode", errorCode).append("errorCategory", errorCategory)
                .append("transactionReference", transactionReference).append("description", description)
                .append("message", getMessage()).toString();
	}
}
