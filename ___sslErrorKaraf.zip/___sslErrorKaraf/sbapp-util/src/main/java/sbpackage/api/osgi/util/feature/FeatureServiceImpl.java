package sbpackage.api.osgi.util.feature;

import javax.inject.Named;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * Service for managing features depending on environment config.
 */
@Named
@Component(service = FeatureService.class)
public class FeatureServiceImpl implements FeatureService {

    private FeatureConfigService featureConfigService;

    @Reference
    public void setFeatureConfigService(FeatureConfigService featureConfigService) {
        this.featureConfigService = featureConfigService;
    }

    @Override
    public boolean isActive(Feature feature) {
        return featureConfigService.getActiveFeatures().contains(feature);
    }
}
