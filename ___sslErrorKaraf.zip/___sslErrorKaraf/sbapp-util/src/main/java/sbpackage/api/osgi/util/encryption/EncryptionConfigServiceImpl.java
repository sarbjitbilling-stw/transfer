package sbpackage.api.osgi.util.encryption;

import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Named;
import javax.inject.Singleton;

import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;

/**
 * Created by DA on 17/01/2018.
 */
@Named
@Singleton
public class EncryptionConfigServiceImpl implements ManagedService, EncryptionConfigService {

    private static final Map<String, String> config = new HashMap<>();

    private static final String KEYSTORE_KEY = "wss.osgi.util.encryption.keystore.key";
    private static final String KEYSTORE_PASS = "wss.osgi.util.encryption.keystore.pass";
    private static final String PRIVATE_KEY_ALIAS = "wss.osgi.util.encryption.privatekey.alias";

    private static final String TRUSTSTORE_KEY = "wss.osgi.util.encryption.trustStore.key";
    private static final String TRUSTSTORE_PASS = "wss.osgi.util.encryption.truststore.pass";
    private static final String PUBLIC_KEY_ALIAS = "wss.osgi.util.encryption.publickey.alias";

    private static final String KEYPASS = "wss.osgi.util.encryption.keypass";


    @Override
    public synchronized void updated(Dictionary dctnrIn) throws ConfigurationException {
        Dictionary<String, String> dctnr = dctnrIn;
        config.clear();
        Collections.list(dctnr.keys()).stream().forEach((key) -> config.put(key, dctnr.get(key)));
    }

    @Override
    public String getKeystoreKey() {
        return getConfigValue(KEYSTORE_KEY);
    }
    @Override
    public String getKeystorePass() {
        return getConfigValue(KEYSTORE_PASS);
    }
    @Override
    public String getPrivateKeyAlias() {
        return getConfigValue(PRIVATE_KEY_ALIAS);
    }

    @Override
    public String getTruststoreKey() {
        return getConfigValue(TRUSTSTORE_KEY);
    }
    @Override
    public String getTruststorePass() {
        return getConfigValue(TRUSTSTORE_PASS);
    }
    @Override
    public String getPublicKeyAlias() {
        return getConfigValue(PUBLIC_KEY_ALIAS);
    }

    @Override
    public String getKeypass() {
        return getConfigValue(KEYPASS);
    }

    private String getConfigValue(String configKey){
        return config.get(configKey);
    }
}
