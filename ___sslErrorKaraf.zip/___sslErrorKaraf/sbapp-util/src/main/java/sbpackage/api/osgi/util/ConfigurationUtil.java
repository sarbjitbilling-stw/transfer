package sbpackage.api.osgi.util;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigurationUtil {
    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationUtil.class);

    private ConfigurationUtil() {
    }

    public static boolean getConfiguredBoolean(Map<String, String> config, String key, boolean defaulValue) {
        String configuredValue = config.get(key);
        if (configuredValue == null) {
            return defaulValue;
        }

        return configuredValue.toLowerCase().equalsIgnoreCase("true");
    }

    public static int getConfiguredInteger(Map<String, String> config, String key, int defaultValue) {
        String configuredValue = config.get(key);
        if (StringUtils.isBlank(configuredValue)) {
            return defaultValue;
        }

        try {
            return Integer.parseInt(configuredValue);
        } catch (NumberFormatException e) {
            LOG.error("Configuration value {} for property {} cannot be converted to an integer", configuredValue, key);
            return defaultValue;
        }
    }
}
