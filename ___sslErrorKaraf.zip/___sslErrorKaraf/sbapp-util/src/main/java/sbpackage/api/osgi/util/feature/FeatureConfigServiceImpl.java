package sbpackage.api.osgi.util.feature;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Named;
import javax.inject.Singleton;

import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Named
@Singleton
@Component(service = { FeatureConfigService.class }, configurationPid = FeatureConfigServiceImpl.PID)
public class FeatureConfigServiceImpl implements FeatureConfigService {
    private static final Logger LOG = LoggerFactory.getLogger(FeatureConfigServiceImpl.class);

    public static final String PID = "wss.osgi.util.feature";
    private static final String FEATURE_ACTIVE_PREFIX = PID + ".";

    private Set<Feature> activeFeatures = Collections.emptySet();

    @Activate
    @Modified
    public void updated(Map<String, String> config) {
        if (config != null) {
            this.activeFeatures = getActiveFeaturesFromConfig(config);
        } else {
            LOG.warn("Unable to load properties for {}", PID);
        }
    }

    private Set<Feature> getActiveFeaturesFromConfig(Map<String, String> config) {
        Set<Feature> activeFeatureSet = new HashSet<>();

        // @formatter:off
        List<Map.Entry<String, String>> featurePropertyEntryList = config.entrySet().stream()
                .filter(entry -> entry.getKey().startsWith(FEATURE_ACTIVE_PREFIX))
                .filter(entry -> StringUtils.isNotBlank(entry.getValue()))
                .collect(Collectors.toList());
        // @formatter:on

        for (Map.Entry<String, String> featureEntry : featurePropertyEntryList) {
            // remove property name prefix
            String featureName = featureEntry.getKey().substring(FEATURE_ACTIVE_PREFIX.length());
            Optional<Feature> featureOpt = Feature.fromName(featureName);

            if (!featureOpt.isPresent()) {
                LOG.error("Invalid feature name {}", featureName);
                continue;
            }

            Feature feature = featureOpt.get();
            boolean featureIsActive = Boolean.parseBoolean(featureEntry.getValue());
            if (featureIsActive) {
                LOG.debug("Adding {} to active features list", feature);
                activeFeatureSet.add(feature);
            } else {
                LOG.debug("Feature {} is inactive", feature);
            }
        }

        return Collections.unmodifiableSet(activeFeatureSet);
    }

    @Override
    public Set<Feature> getActiveFeatures() {
        return activeFeatures;
    }

}
