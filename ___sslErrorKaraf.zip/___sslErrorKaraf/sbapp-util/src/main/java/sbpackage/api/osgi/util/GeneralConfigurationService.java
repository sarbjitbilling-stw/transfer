package sbpackage.api.osgi.util;

import java.util.Optional;

/**
 * Created by sleach on 31/08/2017.
 */
public interface GeneralConfigurationService {
    String getDefaultUserIdenitity();
    String configurationInstanceId();
    boolean requiresIdentity();
    boolean allowBasicAuth();
    public boolean isCacheServiceEnable();
    Optional<Long> getMethodCacheDuration(String methodName);

    String getVersion();
    
    String getGitBranch();
    String getGitCommitId();
    String getGitCommitTime();
    String getGitCommitUserEmail();
    String getGitCommitMessageShort();
}
