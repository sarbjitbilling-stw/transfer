package sbpackage.api.osgi.util.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by sleach on 25/09/2017.
 */
public abstract class LogManager {

    /**
     * Returns an SLF4J logger matching the current class.
     */
    public static Logger classLogger() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();

        //for (int n = 0; n < stackTrace.length; n++) {
        //    System.out.print(n);
        //    System.out.print(" = ");
        //    System.out.println(stackTrace[n].getClassName());
        //}

        // Frame 0 is "Thread", Frame 1 is "LogManager" (this class)
        String callingClass = stackTrace[2].getClassName();

        return LoggerFactory.getLogger(callingClass);
    }


}
