package sbpackage.api.osgi.util;

import java.net.ServerSocket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by ppahwa on 29/07/2017.
 */
public class TestUtil {

    static Logger log = LoggerFactory.getLogger(TestUtil.class);

    public synchronized static int getRandomPort() {
        int port = 0;
        try (ServerSocket serverSocket = new ServerSocket(0);) {
            serverSocket.setReuseAddress(true);
            port = serverSocket.getLocalPort();
        } catch (Exception e) {
            log.error("Exception while opening/closing socket:", e);
            for (Throwable t : e.getSuppressed()) {
                log.error("Suppressed Exception while opening/closing socket:", e);
            }
            throw new RuntimeException(e);
        }
        log.debug("Found port: {}", port);
        return port;
    }

    public synchronized static String getUrlWithRandomPort(String url) {
        return String.format(url, getRandomPort());
    }
}
