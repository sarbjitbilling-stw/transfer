package sbpackage.api.osgi.util;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.cm.ManagedService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sbpackage.api.osgi.util.encryption.EncryptionConfigService;
import sbpackage.api.osgi.util.encryption.EncryptionConfigServiceImpl;

import java.util.Dictionary;
import java.util.Hashtable;

/**
 * Created by DA 20/1/2018
 */
public class Activator implements BundleActivator {
    Logger log = LoggerFactory.getLogger(this.getClass());
    ServiceRegistration encryptionConfig;

    public void start(BundleContext context) throws Exception {
        Dictionary encryptionProperties = new Hashtable();
        encryptionProperties.put("service.pid", EncryptionConfigService.PID);
        encryptionConfig = context.registerService(ManagedService.class.getName(),
                new EncryptionConfigServiceImpl(), encryptionProperties);

    }

    public void stop(BundleContext context) throws Exception {
        if(encryptionConfig != null) {
            encryptionConfig.unregister();
            encryptionConfig = null;
        }
    }

}