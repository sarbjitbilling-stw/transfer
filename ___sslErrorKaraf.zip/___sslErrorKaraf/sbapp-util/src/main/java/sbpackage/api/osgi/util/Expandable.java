/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbpackage.api.osgi.util;

import java.lang.reflect.Array;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.EnumUtils;

/**
 *
 * @author Mark
 */
public interface Expandable  {
    
    public static final String EXPAND_PARAM = "expand";
    
    // check that all of the given Expand names (options) are valid and in the journey list passed in 
    public static boolean isValidOptionList(List<String> options, List<Expands> expands) {
        if (options == null) {
            return true;
        }
        return options.stream().allMatch(e -> EnumUtils.isValidEnum(Expands.class, e) && expands.contains(Enum.valueOf(Expands.class, e)));
    }
    
    public static <E extends Enum<E>> boolean hasAny(Class<E> clazz, E[] expands, E... options) {
        return Stream.of(options).filter((t) -> ArrayUtils.contains(expands, t)).findFirst().isPresent();
    }

    // check given Expand is the given List of Exoands
    public static <E extends Enum<E>> boolean hasOption(E[] expands, E option, Class<E> clazz) {
        return ArrayUtils.contains(expands, option);
    }

    public static <E extends Enum<E>> boolean hasOption(List<E> expands, E option, Class<E> clazz) {
        return expands.contains(option);
    }
    
    public static <E extends Enum<E>> boolean hasOptionOrEmptyList(E[] expands, E option, Class<E> clazz) {
        if(expands.length == 0) return true;
        return hasOption(expands, option, clazz);
    }
    
    public static <E extends Enum<E>> boolean hasOptionOrEmptyList(List<E> expands, E option, Class<E> clazz) {
        if(expands == null || expands.isEmpty()) return true;
        return hasOption(expands, option, clazz);
    }

    // convert a list of Expand names into an array of Expands 
    public static <E extends Enum<E>> E[] getExpands(List<String> options, Class<E> clazz) {
        return options.stream()
                .filter((option) -> (EnumUtils.isValidEnum(clazz, option)))
                .map(option -> Enum.valueOf(clazz, option))
                .toArray(size ->  (E[]) Array.newInstance(clazz, size) );
    }

}
