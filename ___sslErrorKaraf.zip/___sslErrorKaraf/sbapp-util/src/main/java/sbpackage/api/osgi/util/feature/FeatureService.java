package sbpackage.api.osgi.util.feature;

public interface FeatureService {
    /**
     * Checks if the specified {@link Feature} is active.
     * 
     * <p>
     * Used to allow for feature related logic to be switch off/on by environment.
     * 
     * @param feature {@code Feature} to check the status of
     * @return true if feature is active otherwise false
     */
    boolean isActive(Feature feature);
}
