package sbpackage.api.osgi.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;
import org.apache.commons.lang3.StringUtils;
import sbpackage.api.osgi.model.account.TargetAccountNumber;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.ext.RuntimeDelegate;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rtai on 17/08/2017.
 */
public class SerializationManager {

    private List<Object> providers;

    private ObjectMapper objectMapper;


    private SerializationManager(SimpleModule simpleModule) {
        this.objectMapper = new ObjectMapper();

        objectMapper.registerModule(simpleModule);
        objectMapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        objectMapper.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.setAnnotationIntrospector(AnnotationIntrospector.pair(new JacksonAnnotationIntrospector(),
                new JaxbAnnotationIntrospector(TypeFactory.defaultInstance())));

        simpleModule.addSerializer(TargetAccountNumber.class, new TargetAccountNumberJsonSerializer());
        simpleModule.addDeserializer(TargetAccountNumber.class, new TargetAccountNumberJsonDeserializer());

        JacksonJaxbJsonProvider jacksonJaxbJsonProvider = new JacksonJaxbJsonProvider();
        jacksonJaxbJsonProvider.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        jacksonJaxbJsonProvider.setMapper(objectMapper);
        providers = new ArrayList<>();
        providers.add(jacksonJaxbJsonProvider);

        System.setProperty(ClientBuilder.JAXRS_DEFAULT_CLIENT_BUILDER_PROPERTY, "org.apache.cxf.jaxrs.client.spec.ClientBuilderImpl");
        System.setProperty(RuntimeDelegate.JAXRS_RUNTIME_DELEGATE_PROPERTY, "org.apache.cxf.jaxrs.impl.RuntimeDelegateImpl");
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public List<Object> getProviders() {
        return providers;
    }

    public static final class Config {
        private SimpleModule simpleModule;

        public Config() {
            this.simpleModule = new JavaTimeModule();
        }

        public <T> Config with(Class<T> clazz, JsonSerializer<T> serializer, JsonDeserializer<T> deserializer) {
            simpleModule.addSerializer(clazz, serializer).addDeserializer(clazz, deserializer);
            return this;
        }

        public SerializationManager configure() {
            return new SerializationManager(simpleModule);
        }
    }


    public static class TargetAccountNumberJsonSerializer extends JsonSerializer<TargetAccountNumber>{
        @Override
        public void serialize(TargetAccountNumber tan, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonProcessingException {
            jgen.writeString(tan.getAccountNumberWithCheckDigit());
        }
    }

    public static class TargetAccountNumberJsonDeserializer extends JsonDeserializer<TargetAccountNumber>{

        @Override
        public TargetAccountNumber deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JsonProcessingException {

            JsonToken currentToken = jsonParser.getCurrentToken();

            if (currentToken.equals(JsonToken.VALUE_STRING)) {
                String accountNumberStr = jsonParser.getText().trim();
                //if empty string return null object
                if(StringUtils.isEmpty(accountNumberStr)) return getNullValue();

                return new TargetAccountNumber(accountNumberStr);

            } else if (currentToken.equals(JsonToken.VALUE_NULL)) {
                return getNullValue();
            }

            throw ctxt.mappingException(TargetAccountNumber.class);
        }

        @Override
        public TargetAccountNumber getNullValue() {
            return null;
        }

        @Override
        public TargetAccountNumber getEmptyValue() {
            return null;
        }
    }
}
