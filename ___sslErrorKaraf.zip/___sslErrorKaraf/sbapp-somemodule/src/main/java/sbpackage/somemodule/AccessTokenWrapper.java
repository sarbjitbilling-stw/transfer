package sbpackage.somemodule;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AccessTokenWrapper {
    private String currentToken;

    private long tokenRefreshes;

    // Some history, could use map, however do not want to use up too much memory.
    private String previousToken;
    private LocalDateTime currentTokenDate;
    private LocalDateTime previousTokenDate;

    public void setToken(String token) {
        previousToken = currentToken;
        previousTokenDate = currentTokenDate;

        currentToken = token;
        currentTokenDate = LocalDateTime.now();

        tokenRefreshes++;
    }

    public boolean hasTokenBeenSet() {
        return currentToken != null;
    }
}