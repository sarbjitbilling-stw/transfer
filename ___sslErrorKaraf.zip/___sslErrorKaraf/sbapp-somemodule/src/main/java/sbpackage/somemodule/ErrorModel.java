package sbpackage.somemodule;

import lombok.Data;

@Data
public class ErrorModel {
    private String message;
}