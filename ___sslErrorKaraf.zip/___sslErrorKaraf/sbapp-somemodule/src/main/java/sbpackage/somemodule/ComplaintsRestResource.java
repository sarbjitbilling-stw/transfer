package sbpackage.somemodule;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sbpackage.api.osgi.util.AbstractResource;
import sbpackage.api.osgi.util.STWTechnicalException;
import sbpackage.api.osgi.util.SerializationManager;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Map;

import static javax.servlet.http.HttpServletResponse.SC_OK;
import static javax.ws.rs.core.Response.Status.Family.familyOf;

@Named("somemoduleRestResource")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ComplaintsRestResource extends AbstractResource {
    private static final int UNAUTHORIZED_ACCESS_TOKEN_INVALID = 401;

    private Logger log = LoggerFactory.getLogger(getClass());
    private SerializationManager serializationManager;
    private AccessTokenWrapper cachedAccessToken;

    @Inject
    private ComplaintsConfigService configService;

    public ComplaintsRestResource() {

        serializationManager = new SerializationManager.Config().configure();
        cachedAccessToken = new AccessTokenWrapper();
    }

    @Path("/accesstoken")
    @GET
    public Response getAccessToken() {
        Form form = new Form();
        form.param("client_id", configService.getClientId());
        form.param("client_secret", configService.getClientSecret());
        form.param("grant_type", "client_credentials");
        form.param("scope", configService.getScope());

        try {
            String responseAsString = "";
            String url = String.format("https://login.microsoftonline.com/%s/oauth2/v2.0/token", configService.getTenantId());

            WebClient webClient = WebClient
                    .create(url, serializationManager.getProviders())
                    .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON);
            Response response = webClient.form(form);
            responseAsString = response.readEntity(String.class);
            AccessTokenModel responseAsToken = serializationManager.getObjectMapper().readValue(responseAsString, AccessTokenModel.class);
            log.debug("New access token is {}", responseAsToken.getAccessToken());

            this.cachedAccessToken.setToken(responseAsToken.getAccessToken());

            return Response.status(response.getStatus()).entity(responseAsString).build();
        } catch (final Exception e) {
            throw new STWTechnicalException("Failed to get access token", e);
        }
    }

    @Path("/{customerNumber}")
    @GET
    public Response getComplaints(@PathParam("customerNumber") String customerNumber) {
        try {
            getInitialAccessTokenIfRequired();

            String url = String.format("%s/%s", configService.getComplaintsEndpoint(), customerNumber);

            Response response = getEntity(url);

            if (getAccessTokenIfExpired(response)) {
                log.debug("Retrying get complaints");
                response = getEntity(url);
            }
            return buildResponse(response.readEntity(String.class));
        } catch (final Exception e) {
            throw new STWTechnicalException("Failed to get complaints" + getExceptionDetailDefensively(e), e);
        }
    }

    @Path("/")
    @POST
    public Response createNfa(Map<String, Object> payload) {
        try {
            getInitialAccessTokenIfRequired();

            Response response = createEntity(payload, configService.getCreateNfaEndpoint());
            if (getAccessTokenIfExpired(response)) {
                log.debug("Retrying create nfa");
                response = createEntity(payload, configService.getCreateNfaEndpoint());
            }

            return buildResponse(response.readEntity(String.class));
        } catch (final Exception e) {
            throw new STWTechnicalException("Failed to create NFA" + getExceptionDetailDefensively(e), e);
        }
    }

    @Path("/escalate")
    @POST
    public Response escalateNfa(Map<String, Object> payload) {
        try {
            getInitialAccessTokenIfRequired();

            Response response = createEntity(payload, configService.getEscalateNfaEndpoint());

            if (getAccessTokenIfExpired(response)) {
                log.debug("Retrying escalate nfa");
                response = createEntity(payload, configService.getEscalateNfaEndpoint());
            }

            return buildResponse(response.readEntity(String.class));
        } catch (final Exception e) {
            throw new STWTechnicalException("Failed to escalate NFA/complaint" + getExceptionDetailDefensively(e), e);
        }
    }

    @Path("/rootcauses/{reportableArea}")
    @GET
    public Response getRootCauses(@PathParam("reportableArea") String reportableArea) {
        try {
            getInitialAccessTokenIfRequired();

            String url = String.format("%s/%s", configService.getRootCausesEndpoint(), reportableArea);

            Response response = getEntity(url);

            if (getAccessTokenIfExpired(response)) {
                log.debug("Retrying get root causes");
                response = getEntity(url);
            }

            return buildResponse(response.readEntity(String.class));
        } catch (final Exception e) {
            throw new STWTechnicalException("Failed to get reportable area" + getExceptionDetailDefensively(e), e);
        }
    }

    @Path("info")
    @GET
    public Response info() {
        log.info("info v1");
        return Response
                .status(SC_OK)
                .entity(cachedAccessToken)
                .build();
    }

    //
    // TODO: TEMP: ncpp-2377: experiment
    //
    @Path("info")
    @POST
    public Response infoPost(String credential) {
        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = new GsonFactory();
        //GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier(transport, jsonFactory);
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(transport, jsonFactory)
                .setAudience(Arrays.asList("157042697689-t79cf89tvs9046lann9gisbugc1aakh4.apps.googleusercontent.com"))
                .build();
        GoogleIdToken idToken;
        try {
            log.info("BEFORE verifier.verify");
            idToken = verifier.verify(credential);
            log.info("AFTER verifier.verify, idToken is " + idToken);
        } catch (GeneralSecurityException | IOException e) {
            throw new STWTechnicalException("Failed to verify google credentials", e);
        }

        return Response
                .status(SC_OK)
                .entity(cachedAccessToken)
                .build();
    }

    private boolean getAccessTokenIfExpired(Response response) {
        int responseStatus = response.getStatus();

        if (responseStatus == UNAUTHORIZED_ACCESS_TOKEN_INVALID) {
            try {
                ResponseModel responseModel = response.readEntity(ResponseModel.class);
                if (responseModel.getStatusCode() == UNAUTHORIZED_ACCESS_TOKEN_INVALID) {
                    log.debug("Getting a new access token");
                    getAccessToken();
                    return true;
                }
            } catch (final Exception e) {
                throw new STWTechnicalException("Failed to refresh access token", e);
            }
        }

        return false;
    }

    protected WebClient getWebClient(String url) {
        return WebClient
                .create(url, serializationManager.getProviders())
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + cachedAccessToken.getCurrentToken())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
    }

    private static Response buildResponse(final String response) {
        return Response
                .status(SC_OK)
                .entity(response)
                .build();
    }

    public Response getEntity(String endpoint) {
        WebClient webClient = getWebClient(endpoint);
        Response response = webClient.get();

        int responseStatus = response.getStatus();

        if (!isExpectedResponse(responseStatus)) {
            throw new STWTechnicalException("Failed to get complaints entity" + getResponseDetailDefensively(response));
        }

        return response;
    }

    public Response createEntity(Map<String, Object> payload, String endpoint) {
        WebClient webClient = getWebClient(endpoint);
        Response response = webClient.post(payload);

        int responseStatus = response.getStatus();

        if (!isExpectedResponse(responseStatus)) {
            throw new STWTechnicalException("Failed to post complaints entity" + getResponseDetailDefensively(response));
        }

        return response;
    }

    /**
     * Parse response for expected error message from logicapp or give up.
     */
    private String getResponseDetailDefensively(Response response) {
        String detail = "";
        try {
            ResponseModel responseModel = response.readEntity(ResponseModel.class);
            if (responseModel.getError() != null && responseModel.getError().getMessage() != null) {
                String message = responseModel.getError().getMessage();
                detail = StringUtils.isNotBlank(message) ? ": " + message : "";
            }
        } catch (Exception e) {
            log.warn("Failed to parse response for error message", e);
        }

        return detail;
    }

    private String getExceptionDetailDefensively(Exception exception) {
        return StringUtils.isNotBlank(exception.getMessage()) ? ": " + exception.getMessage() : "";
    }

    private boolean isExpectedResponse(int responseStatus) {
        Response.Status.Family responseStatusFamily = familyOf(responseStatus);
        return responseStatus == UNAUTHORIZED_ACCESS_TOKEN_INVALID || responseStatusFamily == Response.Status.Family.SUCCESSFUL;
    }

    /**
     * Logicapp endpoints could be called in any order, must get access token on first invocation.
     */
    private void getInitialAccessTokenIfRequired() {
        if (!cachedAccessToken.hasTokenBeenSet()) {
            log.debug("Getting initial access token");
            getAccessToken();
        }
    }
}