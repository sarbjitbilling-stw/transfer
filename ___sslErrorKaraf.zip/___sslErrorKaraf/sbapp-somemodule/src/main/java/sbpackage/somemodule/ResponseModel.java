package sbpackage.somemodule;

import lombok.Data;

@Data
public class ResponseModel {
    private int statusCode;
    private ErrorModel error;
}