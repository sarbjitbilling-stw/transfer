package sbpackage.somemodule;

import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;
import sbpackage.api.osgi.util.ConfigServiceUtil;

import javax.inject.Named;
import javax.inject.Singleton;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

@Named
@Singleton
public class ComplaintsConfigServiceImpl implements ManagedService, ComplaintsConfigService {
    private static final Map<String, String> config = new HashMap<>();

    static final String PID = "wss.osgi.complaints";

    private static final String CLIENT_ID               = PID + ".client-id";
    private static final String CLIENT_SECRET           = PID + ".client-secret";
    private static final String SCOPE                   = PID + ".scope";
    private static final String TENANT_ID               = PID + ".tenant-id";
    private static final String COMPLAINTS_ENDPOINT     = PID + ".complaints-endpoint";
    private static final String ROOT_CAUSES_ENDPOINT    = PID + ".root-causes-endpoint";
    private static final String ESCALATE_NFA_ENDPOINT   = PID + ".escalate-nfa-endpoint";
    private static final String CREATE_NFA_ENDPOINT     = PID + ".create-nfa-endpoint";

    @Override
    public void updated(final Dictionary<String, ?> properties) throws ConfigurationException {
        setConfigFromProperties(properties, CLIENT_ID);
        setConfigFromProperties(properties, CLIENT_SECRET);
        setConfigFromProperties(properties, SCOPE);
        setConfigFromProperties(properties, TENANT_ID);
        setConfigFromProperties(properties, COMPLAINTS_ENDPOINT);
        setConfigFromProperties(properties, ROOT_CAUSES_ENDPOINT);
        setConfigFromProperties(properties, ESCALATE_NFA_ENDPOINT);
        setConfigFromProperties(properties, CREATE_NFA_ENDPOINT);
    }

    private static void setConfigFromProperties(final Dictionary<String, ?> properties, final String propertyName)
            throws ConfigurationException {
        String propertyValueStr = ConfigServiceUtil.getValueFromProperties(properties, propertyName);

        config.put(propertyName, propertyValueStr);
    }

    @Override
    public String getClientId() {
        return config.get(CLIENT_ID);
    }

    @Override
    public String getClientSecret() {
        return config.get(CLIENT_SECRET);
    }

    @Override
    public String getScope() {
        return config.get(SCOPE);
    }

    @Override
    public String getTenantId() {
        return config.get(TENANT_ID);
    }

    @Override
    public String getComplaintsEndpoint() {
        return config.get(COMPLAINTS_ENDPOINT);
    }

    @Override
    public String getRootCausesEndpoint() {
        return config.get(ROOT_CAUSES_ENDPOINT);
    }

    @Override
    public String getEscalateNfaEndpoint() {
        return config.get(ESCALATE_NFA_ENDPOINT);
    }

    @Override
    public String getCreateNfaEndpoint() {
        return config.get(CREATE_NFA_ENDPOINT);
    }
}