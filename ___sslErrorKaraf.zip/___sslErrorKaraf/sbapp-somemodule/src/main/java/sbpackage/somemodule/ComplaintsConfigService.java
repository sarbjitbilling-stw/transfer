package sbpackage.somemodule;

public interface ComplaintsConfigService {
    String getClientId();
    String getClientSecret();
    String getScope();
    String getTenantId();

    String getComplaintsEndpoint();
    String getRootCausesEndpoint();
    String getEscalateNfaEndpoint();
    String getCreateNfaEndpoint();
}