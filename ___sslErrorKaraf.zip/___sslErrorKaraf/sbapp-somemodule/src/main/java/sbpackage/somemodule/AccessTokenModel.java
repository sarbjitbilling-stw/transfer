package sbpackage.somemodule;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AccessTokenModel {
    @JsonProperty(value = "access_token")
    private String accessToken;
}