cd /Users/sb/usertop/customer-----/sociallogin/___apache-karaf-4.2.15/bin
karaf clean debug

cd /Users/sb/usertop/customer-----/sociallogin/___sslErrorKaraf
mvn install -DskipTests

feature:install google-api-client

feature:repo-add mvn:sbpackage.api/sbapp-karaf-features/LATEST/xml
feature:install sbapp-application-dependencies
feature:install sbapp-application-bundles

http://localhost:7181/cxf/somemodule/info

        sbapp-complaints/pom.xml
        ------------------------
        <dependency>
            <groupId>com.google.api-client</groupId>
            <artifactId>google-api-client</artifactId>
        </dependency>


        sbapp-karaf-features/src/main/resources/sbapp-features.xml
        ----------------------------------------------------------
        <feature name="google-api-client" version="1.0.0">
        <bundle>mvn:com.google.api-client/google-api-client/1.34.0</bundle>
        <bundle>mvn:com.google.oauth-client/google-oauth-client/1.33.2</bundle>
        <bundle>wrap:mvn:com.google.http-client/google-http-client-gson/1.41.7</bundle>
        <bundle>wrap:mvn:com.google.http-client/google-http-client/1.41.7</bundle>
        <bundle>mvn:com.google.code.gson/gson/2.9.0</bundle>
        <!-- google-oauth-client requires this version guava -->
        <bundle>mvn:com.google.guava/guava/31.1-jre</bundle>
        <!-- google-http-client requires this version guava -->
        <bundle>mvn:com.google.guava/guava/30.1-jre</bundle>
        <bundle>mvn:com.google.guava/failureaccess/1.0.1</bundle>
        <bundle>wrap:mvn:com.google.guava/listenablefuture/9999.0-empty-to-avoid-conflict-with-guava</bundle>
        <bundle>mvn:org.checkerframework/checker-qual/3.12.0</bundle>
        <bundle>wrap:mvn:com.google.errorprone/error_prone_annotations/2.11.0</bundle>
        <bundle>wrap:mvn:com.google.j2objc/j2objc-annotations/1.3</bundle>
        <bundle>wrap:mvn:com.google.http-client/google-http-client-gson/1.41.7</bundle>
        <bundle>wrap:mvn:com.google.http-client/google-http-client/1.41.7</bundle>
        <bundle>wrap:mvn:com.google.http-client/google-http-client-apache-v2/1.41.7</bundle>
        <bundle>wrap:mvn:org.apache.httpcomponents/httpclient/4.5.13</bundle>
        <bundle>wrap:mvn:org.apache.httpcomponents/httpcore/4.4.15</bundle>
        <bundle>mvn:commons-logging/commons-logging/1.2</bundle>
        <bundle>mvn:commons-codec/commons-codec/1.11</bundle>
        <bundle>wrap:mvn:com.google.http-client/google-http-client/1.41.7</bundle>
        <bundle>wrap:mvn:io.opencensus/opencensus-api/0.31.0</bundle>
        <bundle>wrap:mvn:io.grpc/grpc-context/1.27.2</bundle>
        <bundle>wrap:mvn:io.opencensus/opencensus-contrib-http-util/0.31.0</bundle>
        </feature>

        etc/org.apache.karaf.management.cfg
        -----------------------------------
        rmiServerPort = ${env:ORG_APACHE_KARAF_MANAGEMENT_RMISERVERPORT:-44444}
        rmiServerPort = ${env:ORG_APACHE_KARAF_MANAGEMENT_RMISERVERPORT:-34444}

        etc/org.ops4j.pax.web.cfg
        -------------------------
        org.osgi.service.http.port=8181
        org.osgi.service.http.port=7181
