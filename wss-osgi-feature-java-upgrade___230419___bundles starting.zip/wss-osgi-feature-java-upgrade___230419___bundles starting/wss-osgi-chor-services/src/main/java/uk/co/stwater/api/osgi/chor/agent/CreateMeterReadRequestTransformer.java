package uk.co.stwater.api.osgi.chor.agent;

import javax.inject.Named;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.model.metering.MeterReadDetail;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.meterread.create.IIBCreateMeterReadRequest;

@Named
public class CreateMeterReadRequestTransformer implements Transformer {

	private static final String TRUE = "Y";

	@Override
	public Object transform(Object source) {

		IIBCreateMeterReadRequest request = null;

		if (null == source) {
			throw new STWBusinessException("source is a required parameter");
		}

		if (source instanceof MeterReadDetail) {

			MeterReadDetail read = (MeterReadDetail) source;
			request = new IIBCreateMeterReadRequest();

			request.setAvgDailyConsumption(read.getAverageDailyConsumption().floatValue());
			request.setBillMultiplierAmount(read.getBillingMultiplierAmount().floatValue());

			if (TRUE.equalsIgnoreCase(read.getBillNextRunIndicator())) {
				request.setBillOnNextRun(true);
			} else {
				request.setBillOnNextRun(false);
			}
			// request.setCapturedDate(read.getCreatedDate());

			// request.setCombinedNum(read.getC);
			request.setConversionFlag(read.getConversionFlag());
			// request.setCupsUsageAreaCode(read.getC);
			request.setEmpNum(read.getEmployeeNum());
			// request.setIndBilled(read.getIn);
			// request.setUnitOfMeasureCode(read.get);
			request.setServiceProvCode(read.getServiceStatus());
			request.setTroubleCodeFlag(read.getTroubleCodeFlag());
			request.setUtilEquipNum(read.getUtilityEquipmentNum());

		}

		return request;
	}

}
