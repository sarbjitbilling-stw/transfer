package uk.co.stwater.api.osgi.chor;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;
import java.util.Stack;

import static uk.co.stwater.api.osgi.chor.ChorState.END_STATE;
import static uk.co.stwater.api.osgi.chor.ChorState.MOVE_IN;
import static uk.co.stwater.api.osgi.chor.ChorState.MOVE_IN_SIM_BILL_COMPLETED;
import static uk.co.stwater.api.osgi.chor.ChorState.MOVE_IN_SIM_BILL_FAILED;
import static uk.co.stwater.api.osgi.chor.ChorState.MOVE_OUT;
import static uk.co.stwater.api.osgi.chor.ChorState.MOVE_OUT_SIM_BILL_COMPLETED;
import static uk.co.stwater.api.osgi.chor.ChorState.MOVE_OUT_SIM_BILL_FAILED;

public class ChorStateManager {

    static final String NO_CONTACT = "";

    static final String NO_EMAIL = "";

    private ChorState chorState;

    private Stack<ChorState> history;

    private boolean existingCustomer = false;

    private static ChorState[] END_STATES = new ChorState[]{END_STATE, MOVE_IN_SIM_BILL_COMPLETED, MOVE_IN_SIM_BILL_FAILED,
            MOVE_OUT_SIM_BILL_COMPLETED, MOVE_OUT_SIM_BILL_FAILED};

    private ChorStateManager() {
    }

    public static ChorStateManager newCustomer() {
        return new ChorStateManager(MOVE_IN);
    }

    public static ChorStateManager existingCustomer() {
        return new ChorStateManager(MOVE_OUT);
    }

    private ChorStateManager(ChorState startingState) {
        this.chorState = startingState;
        this.history = new Stack<>();
        this.history.push(chorState);
        if (startingState == MOVE_OUT) {
            this.existingCustomer = true;
        }
    }

    public boolean isExistingCustomer() {
        return this.existingCustomer;
    }

    public boolean isProcessCompleted() {
        return Arrays.stream(END_STATES).anyMatch(endState -> endState == chorState);
    }

    public Iterator<ChorState> getStateIterator() {
        return history.iterator();
    }

    public boolean hasState(ChorState chorState) {
        return history.contains(chorState);
    }

    public boolean hasAnyStates(Set<ChorState> states) {
        return states.stream().anyMatch(stateToCheck -> history.contains(stateToCheck));
    }

    public ChorStateManager moveInChorOn(ChorProgressMonitor.Progress progress) {
        if (!hasState(ChorState.MOVE_IN)) {
            changeChorState(ChorState.MOVE_IN);
        }
        changeChorState(ChorState.MOVE_IN_CHOR_ON);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_IN_CHOR_ON_COMPLETED);
        } else if (progress == ChorProgressMonitor.Progress.FAILED) {
            chorState = chorState.transition(ChorState.MOVE_IN_CHOR_ON_FAILED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_IN_CHOR_ON_NOT_ATTEMPTED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager forcedOutMailingAddress(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.FORCED_OUT_MAILING_ADDRESS);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.FORCED_OUT_MAILING_ADDRESS_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.FORCED_OUT_MAILING_ADDRESS_NOT_ATTEMPTED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveInAddress(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_IN_ADDRESS);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_IN_ADDRESS_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_IN_ADDRESS_NOT_ATTEMPTED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveInRole(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_IN_ADD_ROLE);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_IN_ADD_ROLE_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_IN_ADD_ROLE_FAILED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager forcedOutSimBill(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.FORCED_OUT_SIM_BILL);
        switch (progress) {
            case COMPLETED:
                chorState = chorState.transition(ChorState.FORCED_OUT_SIM_BILL_COMPLETED);
                break;
            case NOT_ATTEMPTED:
                chorState = chorState.transition(ChorState.FORCED_OUT_SIM_BILL_NOT_ATTEMPTED);
                break;
            default:
                chorState = chorState.transition(ChorState.FORCED_OUT_SIM_BILL_FAILED);
        }

        history.push(chorState);
        return this;
    }

    public ChorStateManager moveInSimBill(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_IN_SIM_BILL);
        switch (progress) {
            case COMPLETED:
                chorState = chorState.transition(ChorState.MOVE_IN_SIM_BILL_COMPLETED);
                break;
            case NOT_ATTEMPTED:
                chorState = chorState.transition(ChorState.MOVE_IN_SIM_BILL_NOT_ATTEMPTED);
                break;
            default:
                chorState = chorState.transition(ChorState.MOVE_IN_SIM_BILL_FAILED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveOutChorOff(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_OUT_CHOR_OFF);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_OUT_CHOR_OFF_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_OUT_CHOR_OFF_FAILED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveOutNewAddress(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_OUT_NEW_MAILING_ADDRESS);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_OUT_NEW_MAILING_ADDRESS_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_OUT_NEW_MAILING_ADDRESS_NOT_ATTEMPTED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveOutChorOn(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_OUT_CHOR_ON);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_OUT_CHOR_ON_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_OUT_CHOR_ON_NOT_ATTEMPTED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveOutRole(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_OUT_ADD_ROLE);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.MOVE_OUT_ADD_ROLE_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.MOVE_OUT_ADD_ROLE_NOT_ATTEMPTED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager moveOutSimBill(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.MOVE_OUT_SIM_BILL);
        switch (progress) {
            case NOT_ATTEMPTED:
                chorState = chorState.transition(ChorState.MOVE_OUT_SIM_BILL_NOT_ATTEMPTED);
                break;
            case COMPLETED:
                chorState = chorState.transition(ChorState.MOVE_OUT_SIM_BILL_COMPLETED);
                break;
            default:
                chorState = chorState.transition(ChorState.MOVE_OUT_SIM_BILL_FAILED);
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager cancelPaymentPlan(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.CANCEL_PAYMENT_PLAN);
        if (progress == ChorProgressMonitor.Progress.FAILED) {
            this.chorState = ChorState.CANCEL_PAYMENT_PLAN_FAILED;
        } else if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            this.chorState = ChorState.CANCEL_PAYMENT_PLAN_COMPLETED;
        }
        history.push(chorState);
        return this;
    }

    public ChorStateManager createPaymentPlan(ChorProgressMonitor.Progress progress) {
        changeChorState(ChorState.CREATE_PAYMENT_PLAN);
        if (progress == ChorProgressMonitor.Progress.COMPLETED) {
            chorState = chorState.transition(ChorState.CREATE_PAYMENT_PLAN_COMPLETED);
        } else {
            chorState = chorState.transition(ChorState.CREATE_PAYMENT_PLAN_FAILED);
        }
        history.push(chorState);
        return this;
    }

    private void changeChorState(ChorState newState) {
        chorState = chorState.transition(newState);
        history.push(chorState);
    }

    public ChorState getChorState() {
        return this.chorState;
    }

    public ChorResponse.Status getStatus() {
        switch (chorState) {
            case CREATE_PAYMENT_PLAN_COMPLETED:
                return ChorResponse.Status.COMPLETED_PP_SUCCESS;
            case CREATE_PAYMENT_PLAN_FAILED:
                return ChorResponse.Status.COMPLETED_PP_FAIL;
            case CANCEL_PAYMENT_PLAN_COMPLETED:
                return ChorResponse.Status.COMPLETED_CANCEL_PP_SUCCESS;
            case CANCEL_PAYMENT_PLAN_FAILED:
                return ChorResponse.Status.COMPLETED_CANCEL_PP_FAIL;
            default:
                return ChorResponse.Status.COMPLETED_SIMBILL_SUCCESS;
        }
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("chorState", chorState)
                .append("history", history)
                .toString();
    }
}
