package uk.co.stwater.api.osgi.chor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;

import java.time.LocalDate;
import java.util.Optional;

public class ChorSimBillProcessor extends AbstractChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorSimBillProcessor.class);

    private static final String ASSESSED = "A";
    private static final String UNMEASURED = "U";
    private static final String MEASURED = "M";
    private static final String ADDRESS_IS_NULL_FROM_S = "address is null from %s";

    ChorSimBillProcessor(ServiceFacade serviceFacade, ChorStateManager chorStateManager, ChorStateProcessor nextStateProcessor) {
        super(serviceFacade, chorStateManager, nextStateProcessor);
    }

    @Override
    public boolean canProcess(ChorState chorState) {
        return false;
    }

    @Override
    protected void processState(ChorContext chorContext) {
        logger.debug("processState entry");
        logger.info("Move completed - checking whether to calculate charges");
        if (chorContext.getChorStateManager().hasState(ChorState.MOVE_OUT)) {
            if (chorContext.getChorStateManager().hasState(ChorState.MOVE_IN) && chorContext.isBillPayerAtMovingInAddress()) {
                //double-sided chor
                setSupplyType(chorContext);
                switch (getSupplyType(chorContext)) {
                    case UNMEASURED:
                        doUnmeasuredMoveIn(chorContext);
                        break;
                    case MEASURED:
                        doMeasuredMoveIn(chorContext);
                        break;
                    default:
                        logger.debug("move in for double-sided is assessed - skipping sim bill");
                        simBillSkipped(chorContext);
                }
            } else {
                if (chorContext.getMovingOutDetails().isMeasured() && chorContext.getMovingOutDetails().isFuture()) {
                    logger.debug("move out is future dated and measured - skipping sim bill");
                    chorContext.getChorStateManager().moveOutSimBill(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
                } else {
                    serviceFacade.getChargesCalculator().calculateChargesForExistingCustomer(chorContext, chorContext.getUsername(), true);
                }
            }
        } else {
            MoveRequestDetail movingInDetails = chorContext.getMovingInDetails();
            if (isPropertyUnmeasured(movingInDetails, chorContext.getAccountNumber(), chorContext.getUsername())) {
                serviceFacade.getChargesCalculator().calculateChargesForNewCustomer(movingInDetails, chorContext.getUsername(), chorContext.getChorResponse(),
                        chorContext.getChorResponse().getNewAccountNumber());
            } else {
                logger.debug("move in is future dated and measured - skipping sim bill");
                ChorResponse chorResponse = chorContext.getChorResponse();
                chorResponse.setMeterReadRequired(movingInDetails.getDate().isBefore(LocalDate.now()
                        .minusMonths(serviceFacade.getConfigService().getMonthsInPastBeforeMeterReadRequiredNewCustomer())));
                chorContext.getChorStateManager().moveInSimBill(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
            }
        }
        logger.debug("processState exit");
    }

    private void doMeasuredMoveIn(ChorContext chorContext) {
        if (chorContext.getMovingOutDetails().isMeasured()) {
            logger.debug("move out for double-sided is measured - skipping sim bill");
            simBillSkipped(chorContext);
        } else {
            serviceFacade.getChargesCalculator().calculateChargesForExistingCustomer(chorContext,
                    chorContext.getUsername(), true);
        }
    }

    private void doUnmeasuredMoveIn(ChorContext chorContext) {
        if (chorContext.getMovingOutDetails().isMeasured() && chorContext.getMovingOutDetails().isFuture()) {
            logger.debug("move out for double-sided is measured and future dated - skipping sim bill");
            simBillSkipped(chorContext);
        } else {
            serviceFacade.getChargesCalculator().calculateChargesForExistingCustomer(chorContext,
                    chorContext.getUsername(), true);
        }
    }

    private static void simBillSkipped(ChorContext chorContext) {
        chorContext.getChorStateManager().moveOutSimBill(ChorProgressMonitor.Progress.NOT_ATTEMPTED)
                .forcedOutSimBill(ChorProgressMonitor.Progress.NOT_ATTEMPTED)
                .moveInSimBill(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
    }

    private void setSupplyType(ChorContext chorContext) {
        if (chorContext.getMovingOutDetails() != null && chorContext.getChorResponse() != null) {
            if (chorContext.getMovingOutDetails().isMeasured()) {
                chorContext.getChorResponse().setSupplyType(MEASURED);
            } else {
                chorContext.getChorResponse().setSupplyType(UNMEASURED);
            }
            if (chorContext.getMovingInDetails() != null && chorContext.getMovingInDetails().getAddress() != null
                    && chorContext.getMovingInDetails().getAddress().getPropertyNum() != null
                    && isPropertyAssessed(chorContext.getAccountNumber(),
                    chorContext.getMovingInDetails().getAddress().getPropertyNum(),
                    chorContext.getUsername())) {
                chorContext.getChorResponse().setSupplyType(ASSESSED);
            }
        }
    }

    private SupplyType getSupplyType(ChorContext chorContext) {
        MoveRequestDetail moveRequestDetail = chorContext.getMovingInDetails();
        if (moveRequestDetail.getAddress() == null) {
            String msg = String.format(ADDRESS_IS_NULL_FROM_S, moveRequestDetail.toString());
            throw new ChorException(msg);
        }
        if (isPropertyAssessed(chorContext.getAccountNumber(), moveRequestDetail.getAddress().getPropertyNum(), chorContext.getUsername())) {
            return SupplyType.ASSESSED;
        } else if (moveRequestDetail.isMeasured()) {
            return SupplyType.MEASURED;
        } else {
            return SupplyType.UNMEASURED;
        }
    }

    private boolean isPropertyUnmeasured(MoveRequestDetail moveRequestDetail, TargetAccountNumber targetAccountNumber, String authToken) {
        if (moveRequestDetail.getAddress() == null) {
            String msg = String.format(ADDRESS_IS_NULL_FROM_S, moveRequestDetail.toString());
            throw new ChorException(msg);
        }
        return !(moveRequestDetail.isMeasured() || isPropertyAssessed(targetAccountNumber,
                moveRequestDetail.getAddress().getPropertyNum(), authToken));
    }

    private boolean isPropertyAssessed(TargetAccountNumber targetAccountNumber, long propertyNumber, String authToken) {
        boolean isAssessed = false;
        Optional<Property> optionalProperty = serviceFacade.getPropertiesForAccountNumberService().getPropertiesForAccountNumber(targetAccountNumber, authToken)
                .stream().filter(property -> property.getPropertyId().equals(String.valueOf(propertyNumber))).findFirst();
        if (optionalProperty.isPresent()) {
            isAssessed = optionalProperty.get().getMeasuredIndicator() != null
                    && ASSESSED.equalsIgnoreCase(optionalProperty.get().getMeasuredIndicator().getCode());
        }
        return isAssessed;
    }

}
