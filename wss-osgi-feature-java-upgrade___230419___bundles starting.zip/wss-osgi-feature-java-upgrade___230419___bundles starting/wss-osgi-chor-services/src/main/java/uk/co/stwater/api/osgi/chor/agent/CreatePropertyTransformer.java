package uk.co.stwater.api.osgi.chor.agent;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.properties.create.IIBCreatePropertyRequest;

public class CreatePropertyTransformer implements Transformer {

	@Override
	public Object transform(Object source) {

		IIBCreatePropertyRequest request = null;

		if (null == source) {
			throw new STWBusinessException("source is a required parameter");
		}

		if (source instanceof Property) {
			Property property = (Property) source;
			request = new IIBCreatePropertyRequest();

			request.setAddress(property.getAddress());
			request.setChargingZone(property.getChargingZone());
			request.setEndDate(property.getEndDate());
			// request.setMeasuredIndicator(property.getMeasuredIndicator());
			request.setPropertyId(property.getPropertyId());
			if (null != property.getRateableValue() && property.getRateableValue().length() > 0) {
				request.setRateableValue(Float.valueOf(property.getRateableValue()));
			}
			request.setStartDate(property.getStartDate());
			// request.setStatus(property.getStatus());

		}
		return request;
	}

}
