package uk.co.stwater.api.osgi.chor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.targetconnector.client.api.insertmailingaddress.MailingAddress;

public class ChorMoveOutAddressProcessor extends AbstractChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorMoveOutAddressProcessor.class);

    ChorMoveOutAddressProcessor(ServiceFacade serviceFacade, ChorStateManager chorStateManager, ChorStateProcessor nextStateProcessor) {
        super(serviceFacade, chorStateManager, nextStateProcessor);
    }

    @Override
    public boolean canProcess(ChorState chorState) {
        return false;
    }

    @Override
    protected void processState(ChorContext chorContext) {
        logger.debug("processState entry");
        if (chorContext.getMovingInDetails().getAddress().getAddressCode() != NO_ADDRESS_CODE) {
            MailingAddress mailingAddress = new MailingAddress(chorContext.getAccountNumber(),
                    chorContext.getMovingOutDetails().getDate(), chorContext.getMovingInDetails().getAddress());
            serviceFacade.getMailingAddressClient().insertMailingAddress(mailingAddress);
            chorStateManager.moveOutNewAddress(ChorProgressMonitor.Progress.COMPLETED);
        } else {
            chorStateManager.moveOutNewAddress(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
        }
        logger.debug("processState exit");
    }
}
