package uk.co.stwater.api.osgi.chor;


import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.MoveCharges;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * Created by tellis3 on 25/04/2017.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "chorResponse")
public class ChorResponse {

    @XmlElement(name = "success")
    private boolean success;
    @XmlElement(name = "forcedOutAccountNumber")
    private TargetAccountNumber forcedOutAccountNumber;
    @XmlElement(name = "newAccountNumber")
    private TargetAccountNumber newAccountNumber;
    @XmlElement(name = "newLegalEntityId")
    private Long newLegalEntityId;
    @XmlElement(name = "chorProgressMonitor")
    private ChorProgressMonitor chorProgressMonitor;

    @XmlElement(name = "exceptionOccurred")
    private boolean exceptionOccurred;
    @XmlElement(name = "errorCode")
    private String errorCode;
    @XmlElement(name = "errorMessage")
    private String errorMessage;

    @XmlElement(name = "monthLimitRequiringDocumentation")
    private Integer monthLimitRequiringDocumentation;

    private Status status;
    @XmlElement(name = "emailAlreadyExists")
    private boolean emailAlreadyExists;

    @XmlElement(name = "finalBalanceAmount")
    private Float finalBalanceAmount;

    @XmlElement(name = "meterReadRequired")
    private boolean meterReadRequired;

    @XmlElement(name = "moveInCharges")
    private MoveCharges moveInCharges;

    @XmlElement(name = "moveOutCharges")
    private MoveCharges moveOutCharges;

    @XmlElement(name = "paymentPlan")
    @JsonProperty("paymentPlan")
    private boolean paymentPlan;

    @XmlElement(name = "supplyType")
    @JsonProperty("supplyType")
    private String supplyType;


    public String getSupplyType() {
        return supplyType;
    }

    public void setSupplyType(String supplyType) {
        this.supplyType = supplyType;
    }

    public Integer getMonthLimitRequiringDocumentation() {
        return monthLimitRequiringDocumentation;
    }

    public void setMonthLimitRequiringDocumentation(Integer monthLimitRequiringDocumentation) {
        this.monthLimitRequiringDocumentation = monthLimitRequiringDocumentation;
    }

    public Float getFinalBalanceAmount() {
        return finalBalanceAmount;
    }

    public void setFinalBalanceAmount(Float finalBalanceAmount) {
        this.finalBalanceAmount = finalBalanceAmount;
    }

    public boolean isMeterReadRequired() {
        return meterReadRequired;
    }

    public void setMeterReadRequired(boolean meterReadRequired) {
        this.meterReadRequired = meterReadRequired;
    }

    public MoveCharges getMoveInCharges() {
        return moveInCharges;
    }

    public void setMoveInCharges(MoveCharges moveInCharges) {
        this.moveInCharges = moveInCharges;
    }

    public MoveCharges getMoveOutCharges() {
        return moveOutCharges;
    }

    public void setMoveOutCharges(MoveCharges moveOutCharges) {
        this.moveOutCharges = moveOutCharges;
    }

    public enum Status {
        NEW_CUSTOMER_COMPLETED_REGISTERED("DM18.11"),
        NEW_CUSTOMER_COMPLETED_NOT_REGISTERED("DM18.23"),
        COMPLETED_SIMBILL_FAILED("DM18.12"),
        COMPLETED_SIMBILL_SUCCESS("DM18.47"),
        COMPLETED_WITH_FAILED_PP("DM18.56"),
        AQ_RAISED("DM18.13"),
        NEEDS_DOCUMENTATION("DM18.14"),
        INVALID_BRAND_PROPERTY("DM18.26"),
        EXISTING_DEBIT("DM18.28"),
        EXISTING_CREDIT_OR_ZERO("DM18.29"),
        COMPLETED_PP_SUCCESS("DM18.48"),
        COMPLETED_WITHOUT_SIMBILL_FOR_DD("DM18.58"),
        COMPLETED_CANCEL_PP_SUCCESS("DM18.57"),
        COMPLETED_PP_FAIL("DM18.56"),
        COMPLETED_CANCEL_PP_FAIL("DM18.12"),
        COMPLETED_MEASURED_MOVE_IN_SUCCESS("DM18.16");

        private String displayedMessage;

        Status(String displayedMessage) {
            this.displayedMessage = displayedMessage;
        }

        public String getDisplayedMessage() {
            return displayedMessage;
        }
    }

    public ChorResponse(boolean success) {
        this.success = success;
    }

    public ChorResponse() {
    }

    public Boolean getEmailAlreadyExists() {
        return emailAlreadyExists;
    }

    public void setEmailAlreadyExists(Boolean emailAlreadyExists) {
        this.emailAlreadyExists = emailAlreadyExists;
    }


    public boolean isSuccess() {
        return success;
    }

    public TargetAccountNumber getForcedOutAccountNumber() {
        return forcedOutAccountNumber;
    }

    public TargetAccountNumber getNewAccountNumber() {
        return newAccountNumber;
    }

    public Long getNewLegalEntityId() {
        return newLegalEntityId;
    }

    public ChorProgressMonitor getChorProgressMonitor() {
        return chorProgressMonitor;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public void setForcedOutAccountNumber(TargetAccountNumber forcedOutAccountNumber) {
        this.forcedOutAccountNumber = forcedOutAccountNumber;
    }

    public void setNewAccountNumber(TargetAccountNumber newAccountNumber) {
        this.newAccountNumber = newAccountNumber;
    }

    public void setNewLegalEntityId(Long newLegalEntityId) {
        this.newLegalEntityId = newLegalEntityId;
    }

    public void setChorProgressMonitor(ChorProgressMonitor chorProgressMonitor) {
        this.chorProgressMonitor = chorProgressMonitor;
    }

    public boolean isExceptionOccurred() {
        return exceptionOccurred;
    }

    public void setExceptionOccurred(boolean exceptionOccurred) {
        this.exceptionOccurred = exceptionOccurred;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("success", success)
                .append("forcedOutAccountNumber", forcedOutAccountNumber)
                .append("newAccountNumber", newAccountNumber)
                .append("newLegalEntityId", newLegalEntityId)
                .append("chorProgressMonitor", chorProgressMonitor)
                .append("exceptionOccurred", exceptionOccurred)
                .append("errorCode", errorCode)
                .append("errorMessage", errorMessage)
                .append("monthLimitRequiringDocumentation", monthLimitRequiringDocumentation)
                .append("status", status)
                .append("emailAlreadyExists", emailAlreadyExists)
                .toString();
    }

    public boolean isPaymentPlan() {
        return paymentPlan;
    }

    public void setPaymentPlan(boolean paymentPlan) {
        this.paymentPlan = paymentPlan;
    }

}
