package uk.co.stwater.api.osgi.chor.agent.memo;

public interface ForceMoveOutMemoService {
	void createForceMoveOutMemo(ForceMoveOutMemoTaskDescriptor taskDescriptor, String authToken);
}
