package uk.co.stwater.api.osgi.chor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChorDoNothingProcessor implements ChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorDoNothingProcessor.class);

    @Override
    public boolean canProcess(ChorState chorState) {
        return false;
    }

    @Override
    public void process(ChorContext chorContext) {
        logger.debug("process invoked");
    }
}
