package uk.co.stwater.api.osgi.chor;

import static uk.co.stwater.api.osgi.chor.ChorServiceImpl.NON_ACTIVE_PAYMENT_PLAN_INDICATOR;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;

/**
 * Created by tellis3 on 04/05/2017.
 */
public class ChorUtils {

    private static final Logger log = LoggerFactory.getLogger(ChorUtils.class);
    
    public static boolean isPreValidationCheckFailed(List<ChorMeterRead> movingInMeterReadings, List<ChorMeterRead> movingOutMeterReadings){

        // over ride flag has been set
        // i.e the user has confirmed the meter reading entered is correct even though it has failed hi lo validation.
        //for registered chor.


        Predicate<ChorMeterRead> preValidationTest  = (ChorMeterRead::isPreValidationCheckFailed);

        if(movingInMeterReadings!=null) {
            if (movingInMeterReadings.size() > 1) {
                return true;
            } else {
                if (movingInMeterReadings.stream().filter(Objects::nonNull).anyMatch(preValidationTest)) {
                    log.info("Moving In meter readings failed pre-validation checks");
                    return true;
                }
            }
        }

        if(movingOutMeterReadings!=null) {
            if (movingOutMeterReadings.size() > 1) {
                return true;
            } else {
                if (movingOutMeterReadings.stream().filter(Objects::nonNull).anyMatch(preValidationTest)) {
                    log.info("Moving out meter readings meter readings failed pre-validation checks");
                    return true;
                }
            }
        }
        return false;
    }


    public static boolean isForcedMeterReading(List<ChorMeterRead> movingInMeterReadings, List<ChorMeterRead> movingOutMeterReadings){

        // over ride flag has been set
        // i.e the user has confirmed the meter reading entered is correct even though it has failed hi lo validation.
        //for registered chor.

        Predicate<ChorMeterRead> overrideValidationTest  = (ChorMeterRead::isOverrideValidation);

        if(movingInMeterReadings!=null) {
            if (movingInMeterReadings.stream().filter(Objects::nonNull).anyMatch(overrideValidationTest)) {
                log.info("Moving In meter readings failed hi lo validation but was confirmed by user");
                return true;
            }
        }

        if(movingOutMeterReadings!=null) {
            if (movingOutMeterReadings.stream().filter(Objects::nonNull).anyMatch(overrideValidationTest)) {
                log.info("Moving out meter readings failed hi lo validation but was confirmed by user");
                return true;
            }
        }
        return false;
    }
    
    public static boolean isDoubleSidedChor(MoveRequestDetail movingInDetails, MoveRequestDetail movingOutDetails,
            boolean billPayerAtMovingInAddress) {
        return isMovingIn(movingInDetails, billPayerAtMovingInAddress) && isMovingOut(movingOutDetails);
    }

    public static boolean isMoveInOnly(MoveRequestDetail movingInDetails, MoveRequestDetail movingOutDetails,
            boolean billPayerAtMovingInAddress) {
        return !isMovingOut(movingOutDetails) && isMovingIn(movingInDetails, billPayerAtMovingInAddress);
    }

    public static boolean isMoveInOnly(ChorContext chorContext) {
        return isMoveInOnly(chorContext.getMovingInDetails(), chorContext.getMovingOutDetails(), chorContext.isBillPayerAtMovingInAddress());
    }

    public static boolean isMoveOutOnly(MoveRequestDetail movingInDetails, MoveRequestDetail movingOutDetails,
            boolean billPayerAtMovingInAddress) {
        return isMovingOut(movingOutDetails) && !isMovingIn(movingInDetails, billPayerAtMovingInAddress);
    }

    public static boolean isMoveOutOnly(ChorContext chorContext) {
        return isMoveOutOnly(chorContext.getMovingInDetails(), chorContext.getMovingOutDetails(), chorContext.isBillPayerAtMovingInAddress());
    }

    public static boolean hasSimBillFailed(final ChorProgressMonitor chorProgressMonitor) {
        return chorProgressMonitor.getChorStateManager().hasState(ChorState.MOVE_IN_SIM_BILL_FAILED)
                || chorProgressMonitor.getChorStateManager().hasState(ChorState.MOVE_OUT_SIM_BILL_FAILED);
    }

    public static boolean isMovingOut(MoveRequestDetail movingOutDetails) {
        return movingOutDetails != null && movingOutDetails.getAddress() != null
                && movingOutDetails.getAddress().getPropertyNum() != null;
    }

    public static boolean isMovingIn(MoveRequestDetail movingInDetails, boolean billPayerAtMovingInAddress) {
        return movingInDetails != null && movingInDetails.getAddress() != null
                && movingInDetails.getAddress().getPropertyNum() != null && billPayerAtMovingInAddress;
    }

    public static boolean hasActivePaymentPlan(Account account) {
        String paymentPlanIndicator = account.getPaymentPlanIndicator();
        return paymentPlanIndicator != null
                && !NON_ACTIVE_PAYMENT_PLAN_INDICATOR.equals(account.getPaymentPlanIndicator());
    }
    
    public static boolean isMoveOutDateInFuture(MoveRequestDetail movingOutDetails) {
        return movingOutDetails != null && movingOutDetails.getDate() != null && movingOutDetails.isFuture();
    }
    
    public static boolean ifMoveInMoveOutUnMeasuredAndInPast(ChorRequest request) {
        return request != null
                && isDoubleSidedChor(request.getMovingInDetails(), request.getMovingOutDetails(),
                        request.isBillPayerAtMovingInAddess())
                && !request.getMovingInDetails().isMeasured() && !request.getMovingOutDetails().isMeasured()
                && !request.getMovingOutDetails().isFuture();
    }
    
}