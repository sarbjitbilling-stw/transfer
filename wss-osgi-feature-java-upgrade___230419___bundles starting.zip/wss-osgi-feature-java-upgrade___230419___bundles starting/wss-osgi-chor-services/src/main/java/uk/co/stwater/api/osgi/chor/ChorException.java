package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.util.STWTechnicalException;

/**
 * Created by tellis3 on 13/05/2017.
 */
public class ChorException extends STWTechnicalException {

    public ChorException(String msg) {
        super(msg);
    }

    public ChorException(String msg, Throwable t){
        super(msg, t);
    }
}
