package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;

public interface ChargesCalculator {

    void calculateChargesForExistingCustomer(ChorContext chorContext,
                                             String authToken,
                                             boolean isSingleSidedMoveOutOnlyInPast);

    void calculateChargesForNewCustomer(MoveRequestDetail movingInDetails,
                                        String username, ChorResponse chorResponse,
                                        TargetAccountNumber newAccountNumber);
}
