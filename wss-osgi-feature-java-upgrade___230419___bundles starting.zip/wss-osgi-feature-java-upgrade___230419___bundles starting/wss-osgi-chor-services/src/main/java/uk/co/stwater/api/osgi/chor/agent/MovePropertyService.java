package uk.co.stwater.api.osgi.chor.agent;

import uk.co.stwater.api.osgi.model.MoveProperty;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

public interface MovePropertyService {

	public MoveProperty moveProperty(MoveProperty moveProperty, String authToken)
			throws STWBusinessException, STWTechnicalException;

}
