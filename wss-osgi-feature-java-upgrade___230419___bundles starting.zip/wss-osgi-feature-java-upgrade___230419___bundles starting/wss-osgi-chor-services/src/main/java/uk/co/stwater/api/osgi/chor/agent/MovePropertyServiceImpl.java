package uk.co.stwater.api.osgi.chor.agent;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import uk.co.stwater.api.metering.MeteringService;
import uk.co.stwater.api.metering.agent.MeterReadService;
import uk.co.stwater.api.osgi.chor.agent.memo.ForceMoveOutMemoService;
import uk.co.stwater.api.osgi.chor.agent.memo.ForceMoveOutMemoTaskDescriptor;
import uk.co.stwater.api.osgi.chor.specialconditions.ChorSpecialConditionService;
import uk.co.stwater.api.osgi.model.AccountRole;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.BillAddress;
import uk.co.stwater.api.osgi.model.Move;
import uk.co.stwater.api.osgi.model.MoveDetails;
import uk.co.stwater.api.osgi.model.MoveProperty;
import uk.co.stwater.api.osgi.model.ProcessOutcome;
import uk.co.stwater.api.osgi.model.ProcessOutcomeList;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.metering.read.MeterReadDetailRequest;
import uk.co.stwater.api.osgi.model.metering.read.MeterReadInfoRequest;
import uk.co.stwater.api.osgi.model.metering.read.MeterReadRefData;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.accounts.IIBAccountsClient;
import uk.co.stwater.iib.client.api.accounts.create.IIBCreateAccountClient;
import uk.co.stwater.iib.client.api.accounts.create.IIBCreateAccountResponse;
import uk.co.stwater.iib.client.api.accounts.patch.IIBPatchAccountClient;
import uk.co.stwater.iib.client.api.accounts.patch.IIBPatchAccountRequest;
import uk.co.stwater.iib.client.api.bill.simulate.IIBSimulateBillClient;
import uk.co.stwater.iib.client.api.bill.simulate.IIBSimulateBillRequest;
import uk.co.stwater.iib.client.api.bill.simulate.IIBSimulateBillResponse;
import uk.co.stwater.iib.client.api.bill.simulate.SimulateBillResponseDTO;
import uk.co.stwater.iib.client.api.chor.create.IIBChorResponse;
import uk.co.stwater.iib.client.api.chor.create.IIBCreateChorClient;
import uk.co.stwater.iib.client.api.chor.create.IIBCreateChorRequest;
import uk.co.stwater.iib.client.api.common.TargetError;
import uk.co.stwater.iib.client.api.customer.create.IIBCreateCustomerClient;
import uk.co.stwater.iib.client.api.customer.get.CustomerResponse;
import uk.co.stwater.iib.client.api.customer.get.GetCustomerClient;
import uk.co.stwater.iib.client.api.customer.update.IIBUpdateCustomerClient;
import uk.co.stwater.iib.client.api.customer.update.IIBUpdateCustomerRequest;
import uk.co.stwater.iib.client.api.meterread.get.IIBGetMeterReadResponse;
import uk.co.stwater.iib.client.api.meterread.get.IIBGetMeterReadWrapper;
import uk.co.stwater.iib.client.api.meters.estimates.get.IIBGetMeterReadingEstimateClient;
import uk.co.stwater.iib.client.api.meters.summary.get.IIBMeterSummary;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.iib.client.api.roles.create.IIBCreateRoleClient;
import uk.co.stwater.iib.client.api.roles.create.IIBCreateRoleRequest;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesForAccountClient;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesResponse;
import uk.co.stwater.iib.client.api.roles.update.IIBUpdateRoleClient;
import uk.co.stwater.iib.client.api.services.IIBGetServicesForAccountClient;

@Named
@OsgiServiceProvider(classes = {MovePropertyService.class})
public class MovePropertyServiceImpl implements MovePropertyService {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private static final String READ_SOURCE_CODE_S = "S";

    private static final String STATUS_CODE_B = "B";

    private static final String READ_TYPE_CODE_Z = "Z";

    private static final String STATUS_NEW = "New";

    private static final String OVERRIDE_FLAG_H = "H";

    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String MOVE_IN = "IN";
    private static final String MOVE_OUT = "OU";

    private static final String UNMEASURED = "U";

    private static final String ACTION_UPDATE = "U";
    private static final String ACTION_SIMULATE = "X";

    private static final String CARE_OF_PREFIX = "b";

    public static final String ROLE_PRIMARY = "P";
    public static final String ROLE_CO_PRIMARY = "C";

    private static final String STATUS_ACTIVE = "A";
    private static final String STATUS_INACTIVE = "I";

    private static final int ONE_DAY_AFTER_MOVE_OUT = 1;
    private static final int NO_OF_ATTEMPTS_OF_CHOR_TURN_OFF_CHECK = 3;

    private static final int DELAY_IN_MILLI_SECONDS = 1000;

    private static final String TARGET_ERROR_CODE_ADDRESS_START_DATE_EQUAL_TO_EXISTING = "013520";

    private static final String PROPERTY_STATUS_CODE_REVERSED = "R";

    @Inject
    @OsgiService
    private IIBAccountsClient iibAccountsClient;

    @Inject
    private CreateAccountRoleTransformer createAccountRoleTransformer;

    @Inject
    private UpdateGeneralCustomerInfoRequestTransformer updateGeneralCustomerInfoRequestTransformer;

    @Inject
    private AccountRoleTransformer getAccountRoleTransformer;

    @Inject
    @OsgiService
    private IIBSimulateBillClient iibSimulateBillClient;

    @Inject
    @OsgiService
    private IIBPatchAccountClient iibPatchAccountClient;

    @Inject
    @OsgiService
    private IIBCreateAccountClient createAccountClient;

    @Inject
    @OsgiService
    private IIBCreateChorClient iibCreateChorClient;

    @Inject
    @OsgiService
    private IIBCreateRoleClient iibCreateRoleClient;

    @Inject
    @OsgiService
    private IIBCreateCustomerClient iibCreateCustomerClient;

    @Inject
    @OsgiService
    private GetCustomerClient iibGetCustomerclient;

    @Inject
    @OsgiService
    private IIBUpdateCustomerClient iibUpdateCustomerClient;

    @Inject
    @OsgiService
    private IIBUpdateRoleClient iibUpdateRoleClient;

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient iibGetPropertiesClient;

    @Inject
    @OsgiService
    private IIBGetRolesForAccountClient iibAccountRolesClient;

    @Inject
    private ForceMoveOutMemoService forceMoveOutMemoService;

    @Inject
    @OsgiService
    private IIBGetServicesForAccountClient iibServicesForAccountClient;

    @Inject
    @OsgiService
    private MeterReadService meterReadService;

    @Inject
    @OsgiService
    private MeteringService meteringervice;

    @Inject
    @OsgiService
    private IIBGetMeterReadingEstimateClient iibReadingEstimateClient;

    @Inject
    private ChorSpecialConditionService specialConditionService;

    @Override
    public MoveProperty moveProperty(MoveProperty moveProperty, String authToken)
            throws STWBusinessException, STWTechnicalException {

        if (null == moveProperty) {
            throw new STWBusinessException("moveProperty is a required parameter");
        }

        if (null == moveProperty.getMoveFrom() && null == moveProperty.getMoveTo()) {
            throw new STWBusinessException("either moveTo or moveFrom must be specified");
        }

        if (null != moveProperty.getMoveFrom()) {
            validateMove(moveProperty.getMoveFrom());
        }

        if (null != moveProperty.getMoveTo()) {
            validateMove(moveProperty.getMoveTo());
        }

        List<ProcessOutcome> outcomeList = new ArrayList<>();

        if (null != moveProperty.getMoveFrom()) {
            outcomeList.addAll(moveOut(moveProperty.getMoveFrom(), authToken, false).getItems());
        }

        if (null != moveProperty.getMoveTo()) {
            outcomeList.addAll(moveIn(moveProperty.getMoveTo(), authToken, false).getItems());
        }

        ProcessOutcomeList list = new ProcessOutcomeList();
        list.setItems(outcomeList);

        moveProperty.setOutcome(list);

        return moveProperty;
    }

    private ProcessOutcomeList moveOut(Move moveFrom, String authToken, boolean forceMoveOut) {

        ProcessOutcomeList outcomeList = new ProcessOutcomeList();
        List<AccountRole> legalEntityList = moveFrom.getOutgoingMoveDetails().getLegalEntityList();
        AccountRole primaryRole = findPrimaryAccountRole(legalEntityList);
        TargetAccountNumber accountNumber = primaryRole.getAccountNumber();

        //changes to estimate read and save meter read so we have meter read when we call createCHOR
        if (moveFrom.getOutgoingMoveDetails() != null && moveFrom.getIncomingMoveDetails() != null) {
            if (moveFrom.getOutgoingMoveDetails().getMoveDate()
                    .isBefore(moveFrom.getIncomingMoveDetails().getMoveDate())) {
                if (forceMoveOut) {
                    saveEstimatedRead(moveFrom.getOutgoingMoveDetails().getMoveDate(), moveFrom.getProperty(),
                            authToken, accountNumber);
                } else {
                    saveEstimatedRead(moveFrom.getIncomingMoveDetails().getMoveDate(), moveFrom.getProperty(),
                            authToken, accountNumber);
                }
            }
        }

        // terminate the services
        outcomeList.addOutcome(setServiceStatusInactive(moveFrom, moveFrom.getProperty(), authToken));

        // update special conditions done straight after target CHORServices request
        if (!outcomeList.hasErrors()) {
            outcomeList.addOutcomes(specialConditionService.afterMoveOut(moveFrom, authToken));
        }

        if (!outcomeList.hasErrors()) {

            if (null != moveFrom.getOutgoingMoveDetails().getCorrespondenceAddress()) {

                // record forwarding address
                ProcessOutcome recordForwardingAddress = updateCorrespondenceAddress(moveFrom.getOutgoingMoveDetails(),
                        primaryRole, authToken);

                outcomeList.addOutcome(recordForwardingAddress);
            }

            if (!outcomeList.hasErrors()) {

                // issue a first bill for the incoming legal entities...

                if (forceMoveOut) {
                    outcomeList = processFinalBillMultipleAttempts(moveFrom, authToken, outcomeList, true);
                    if (!outcomeList.hasErrors()) {
                        ProcessOutcome memo = recordMemo(primaryRole, authToken, moveFrom);
                        outcomeList.addOutcome(memo);
                    }

                } else if (null != moveFrom.getIncomingMoveDetails()) {
                    ProcessOutcomeList forceMoveIn = moveIn(moveFrom, authToken, true);
                    outcomeList.addOutcomes(forceMoveIn.getItems());
                }

            }

        }

        return outcomeList;

    }

    /**
     * 1st Attempt of produceFinalBill: Without any Delay
     * 2nd Attempt of produceFinalBill: With a 1 Sec Delay,
     * Note: Target Needs a delay between CHOR-TurnOff and Online Bill.
     */
    private ProcessOutcomeList processFinalBillMultipleAttempts(Move moveFrom, String authToken, ProcessOutcomeList outcomeList, boolean whiteListTargetErrors) {
        log.debug("processFinalBillForTwoAttempts - START - produceFinalBill - 1st Attempt");
        ProcessOutcome finalBillFirstAttempt = produceFinalBill(moveFrom, authToken, whiteListTargetErrors);
        if (finalBillFirstAttempt.getErrorDescription() != null) { // Error Occured, Need to introuce 1 Sec delay.
            log.debug("processFinalBillForTwoAttempts - produceFinalBill - 1st Attempt - Error Occured");
            outcomeList.addOutcome(introduceDelay(DELAY_IN_MILLI_SECONDS));
            if (outcomeList.hasErrors()) {
                return outcomeList;
            }
            log.debug("processFinalBillForTwoAttempts - produceFinalBill - 2nd Attempt");
            ProcessOutcome finalBillAfterDelay = produceFinalBill(moveFrom, authToken, whiteListTargetErrors);
            outcomeList.addOutcome(finalBillAfterDelay);
        } else {
            outcomeList.addOutcome(finalBillFirstAttempt);
        }
        return outcomeList;
    }

    /**
     * Note: Target Needs a delay between CHOR-TurnOff and Online Bill.
     * Minimum delay required is 1 Second, as per Target 1 milliseond is not sufficient.
     */
    private ProcessOutcome introduceDelay(int milliseconds) {
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.INTRODUCE_DELAY.getStepId());
        outcome.setDescription(ProcessOutcomeEnum.INTRODUCE_DELAY.getDescription());
        outcome.setErrorDescription(null);
        outcome.setPath(ProcessOutcomeEnum.INTRODUCE_DELAY.getPath());
        try {
            log.debug("introduceDelay - START");
            Thread.sleep(milliseconds);
            log.debug("introduceDelay - END");
        } catch (InterruptedException e) {
            log.error(e.getMessage(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.INTRODUCE_DELAY.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
            Thread.currentThread().interrupt();
        }
        return outcome;
    }

    private ProcessOutcome produceFirstBill(Move move, String authToken, boolean whiteListTargetErrors) {

        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setDescription(ProcessOutcomeEnum.FIRST_BILL.getDescription());
        outcome.setStepId(ProcessOutcomeEnum.FIRST_BILL.getStepId());

        if (null != move.getIncomingMoveDetails().getLegalEntityList()
                && move.getIncomingMoveDetails().getLegalEntityList().size() > 0) {

            AccountRole primaryRole = findPrimaryAccountRole(move.getIncomingMoveDetails().getLegalEntityList());

            IIBSimulateBillRequest simulateRequest;
            TargetAccountNumber accountNumber = primaryRole.getAccountNumber();
            simulateRequest = getSimulateBillRequest(ACTION_SIMULATE, new Long(0), accountNumber, Long.valueOf(move.getProperty().getPropertyId()),
                    new Float(0), new Long(0), move.getIncomingMoveDetails().getNextBillEndDate());

            try {

                SimulateBillResponseDTO responseDTO = iibSimulateBillClient.simulateBill(simulateRequest, authToken, whiteListTargetErrors);
                IIBSimulateBillResponse response = responseDTO.getIibSimulateBillResponse();
                IIBSimulateBillRequest firstBillRequest;
                if (response != null) {
                    firstBillRequest = getSimulateBillRequest(ACTION_UPDATE, simulateRequest.getAccountBillGroupNum(), simulateRequest.getAccountNumber(), simulateRequest.getPropertyId(),
                            response.getBilledRunAmount(), response.getCombinedNum(), move.getIncomingMoveDetails().getNextBillEndDate());

                    responseDTO = iibSimulateBillClient.simulateBill(firstBillRequest, authToken, whiteListTargetErrors);
                    response = responseDTO.getIibSimulateBillResponse();
                    if (response == null) {
                        TargetError targetError = responseDTO.getTargetError();
                        String warningMessage = String.format(ProcessOutcomeEnum.FIRST_BILL.getErrorMessage(), targetError.getReasonText());
                        outcome.setWarningDescription(warningMessage);

                    }

                } else {
                    TargetError targetError = responseDTO.getTargetError();
                    String warningMessage = String.format(ProcessOutcomeEnum.FIRST_BILL.getErrorMessage(), targetError.getReasonText());
                    outcome.setWarningDescription(warningMessage);
                }

                String thaPath = String.format(ProcessOutcomeEnum.FIRST_BILL.getPath(), primaryRole.getAccountNumber());
                outcome.setPath(thaPath);

            } catch (STWBusinessException | STWTechnicalException e) {
                log.error(e.getMessage(), e);
                String errorMessage = String.format(ProcessOutcomeEnum.FIRST_BILL.getErrorMessage(), e.getMessage());
                outcome.setErrorDescription(errorMessage);
            }
        }

        return outcome;
    }

    private IIBSimulateBillRequest getSimulateBillRequest(final String functionCode, final Long accountBillGroupNum, final TargetAccountNumber accountNumber, final Long propertyId,
                                                          final Float billedRunAmount, final Long combinedNum, final LocalDate endDate) {
        IIBSimulateBillRequest simulateBillRequest = new IIBSimulateBillRequest();
        simulateBillRequest.setFunctionCode(functionCode);
        simulateBillRequest.setAccountBillGroupNum(accountBillGroupNum);
        simulateBillRequest.setAccountNumber(accountNumber);
        simulateBillRequest.setPropertyId(propertyId);
        simulateBillRequest.setBilledRunAmount(billedRunAmount);
        simulateBillRequest.setCombinedNum(combinedNum);
        simulateBillRequest.setEndDate(endDate);
        return simulateBillRequest;
    }

    private ProcessOutcome produceFinalBill(Move move, String authToken, boolean whiteListTargetErrors) {

        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setDescription(ProcessOutcomeEnum.FINAL_BILL.getDescription());
        outcome.setStepId(ProcessOutcomeEnum.FINAL_BILL.getStepId());

        if (null != move.getOutgoingMoveDetails().getLegalEntityList()
                && move.getOutgoingMoveDetails().getLegalEntityList().size() > 0) {

            AccountRole primaryRole = findPrimaryAccountRole(move.getOutgoingMoveDetails().getLegalEntityList());
            
            String thePath = String.format(ProcessOutcomeEnum.FINAL_BILL.getPath(), primaryRole.getAccountNumber());
            outcome.setPath(thePath);
            IIBSimulateBillRequest simulateBillRequest;
            TargetAccountNumber accountNumber = primaryRole.getAccountNumber();
            simulateBillRequest = getSimulateBillRequest(ACTION_SIMULATE, new Long(0), accountNumber, Long.valueOf(move.getProperty().getPropertyId()),
                    new Float(0), new Long(0), move.getOutgoingMoveDetails().getMoveDate());

            try {
                SimulateBillResponseDTO responseDTO = iibSimulateBillClient.simulateBill(simulateBillRequest, authToken, whiteListTargetErrors);
                IIBSimulateBillResponse response = responseDTO.getIibSimulateBillResponse();
                IIBSimulateBillRequest finalBillRequest;

                if (response != null) {
                    finalBillRequest = getSimulateBillRequest(ACTION_UPDATE, simulateBillRequest.getAccountBillGroupNum(), simulateBillRequest.getAccountNumber(), simulateBillRequest.getPropertyId(),
                            response.getBilledRunAmount(), response.getCombinedNum(), simulateBillRequest.getEndDate());

                    responseDTO = iibSimulateBillClient.simulateBill(finalBillRequest, authToken, whiteListTargetErrors);
                    response = responseDTO.getIibSimulateBillResponse();
                    if (response == null) {
                        TargetError targetError = responseDTO.getTargetError();
                        String warningMessage = String.format(ProcessOutcomeEnum.FINAL_BILL.getErrorMessage(), targetError.getReasonText());
                        outcome.setWarningDescription(warningMessage);
                    }

                } else {
                    TargetError targetError = responseDTO.getTargetError();
                    String warningMessage = String.format(ProcessOutcomeEnum.FINAL_BILL.getErrorMessage(), targetError.getReasonText());
                    outcome.setWarningDescription(warningMessage);
                }

                String thaPath = String.format(ProcessOutcomeEnum.FINAL_BILL.getPath(), primaryRole.getAccountNumber());
                outcome.setPath(thaPath);

            } catch (STWTechnicalException e) {
                log.error(e.getMessage(), e);
                String errorMessage = String.format(ProcessOutcomeEnum.FINAL_BILL.getErrorMessage(), e.getMessage());
                outcome.setErrorDescription(errorMessage);
            } catch (STWBusinessException e) {
                log.warn(e.getMessage(), e);
                String warningMessage = String.format(ProcessOutcomeEnum.FINAL_BILL.getErrorMessage(), e.getMessage());
                outcome.setWarningDescription(warningMessage);
            }
        }

        return outcome;
    }

    private ProcessOutcomeList moveIn(Move moveTo, String authToken, boolean forceMoveIn) {

        ProcessOutcomeList outcomeList = new ProcessOutcomeList();

        if (null != moveTo && null != moveTo.getIncomingMoveDetails().getLegalEntityList()
                && moveTo.getIncomingMoveDetails().getLegalEntityList().size() > 0) {
            // force move out of the existing legal entities....

            if (null != moveTo.getOutgoingMoveDetails() && !forceMoveIn) {
                ProcessOutcomeList moveOut = moveOut(moveTo, authToken, true);

                outcomeList.addOutcomes(moveOut.getItems());

            }
        }

        if (!outcomeList.hasErrors()) {

            ProcessOutcomeList createAccountAndLinkRoles = createAccountAndLinkRoles(moveTo, authToken, forceMoveIn);
            boolean isNewAccountCreatedForMoveIn = createAccountAndLinkRoles.isProcessOutcomePresent(ProcessOutcomeEnum.CREATE_ACCOUNT.getStepId());
            outcomeList.addOutcomes(createAccountAndLinkRoles.getItems());

            if (!createAccountAndLinkRoles.hasErrors()) {

                ProcessOutcomeList preferredName = determinePreferredName(moveTo, authToken);

                outcomeList.addOutcomes(preferredName.getItems());

                if (!outcomeList.hasErrors()) {
                    outcomeList.addOutcomes(
                            specialConditionService.beforeMoveIn(moveTo, isNewAccountCreatedForMoveIn, authToken));

                    if (!outcomeList.hasErrors()) {
                        ProcessOutcome setServiceStatus = setServiceStatusActive(moveTo, moveTo.getProperty(),
                                authToken);
                        // set the status of the services to active
                        outcomeList.addOutcome(setServiceStatus);

                        if (!outcomeList.hasErrors()
                                && moveTo.getIncomingMoveDetails().getCorrespondenceAddress() != null) {
                            // record forwarding address

                            AccountRole primaryRole = getLegalEntity(
                                    moveTo.getIncomingMoveDetails().getLegalEntityList(), ROLE_PRIMARY);

                            // In Double side UI journey, main account holders correspondence address get saved twice, which throws error in Target.
                            // Target do not allow to save correspondence address starting on same date more than once, for the same account.
                            // Solution: Block saving more than once, via isCanSkipCorrespondenceAddressSave and based on whether same account is created.
                            boolean skipSavingCorrespondenceAddress = moveTo.getIncomingMoveDetails().isCanSkipCorrespondenceAddressSave() && !isNewAccountCreatedForMoveIn;
                            if (!skipSavingCorrespondenceAddress) {
                                ProcessOutcome recordForwardingAddress = updateCorrespondenceAddress(
                                        moveTo.getIncomingMoveDetails(), primaryRole, authToken);
                                outcomeList.addOutcome(recordForwardingAddress);
                            }
                        }

                        if (!outcomeList.hasErrors() && forceMoveIn) {
                            // issue first bill for the force move in...
                            if (moveTo.getProperty().getMeasuredIndicator().getCode().equalsIgnoreCase(UNMEASURED)) {
                                ProcessOutcome firstBill = produceFirstBill(moveTo, authToken, false);
                                outcomeList.addOutcome(firstBill);
                            }
                        }

                    }

                }

            }

        }

        return outcomeList;

    }

    private ProcessOutcome updateLegalEntity(AccountRole accountRole, String preferredName, String authToken) {
        ProcessOutcome updateLegalEntity = new ProcessOutcome();
        String description = String.format(ProcessOutcomeEnum.UPDATE_LEGAL_ENTITY.getDescription(), preferredName);
        updateLegalEntity.setDescription(description);
        updateLegalEntity.setStepId(ProcessOutcomeEnum.UPDATE_LEGAL_ENTITY.getStepId());
        String thePath = String.format(ProcessOutcomeEnum.UPDATE_LEGAL_ENTITY.getPath(),
                accountRole.getAccountRoleId());
        updateLegalEntity.setPath(thePath);

        try {

            Optional<CustomerResponse> customerResponse = iibGetCustomerclient
                    .getCustomer(accountRole.getLegalEntityId());

            if (customerResponse.isPresent()) {
                CustomerResponse customer = customerResponse.get();

                /// update primary LE to reflect the new preferred name, this transfomer will only transform General Customer Data, and not Additional Customer Data.
                IIBUpdateCustomerRequest request = (IIBUpdateCustomerRequest) updateGeneralCustomerInfoRequestTransformer
                        .transform(customer);
                request.setPreferredName(preferredName);

                iibUpdateCustomerClient.updateCustomer(request, authToken);

            }
        } catch (STWBusinessException | STWTechnicalException e) {
            updateLegalEntity.setErrorDescription(e.getMessage());
            log.error(e.getMessage(), e);
        }

        return updateLegalEntity;

    }

    private ProcessOutcomeList determinePreferredName(Move move, String authToken) {

        ProcessOutcomeList outcomeList = new ProcessOutcomeList();
        ProcessOutcome determinePreferredName = new ProcessOutcome();
        determinePreferredName.setDescription(ProcessOutcomeEnum.PREFERRED_NAME.getDescription());
        determinePreferredName.setStepId(ProcessOutcomeEnum.PREFERRED_NAME.getStepId());

        AccountRole primaryRole = findPrimaryAccountRole(move.getIncomingMoveDetails().getLegalEntityList());

        String thePreferredName = null;

        try {
            String thePath = String.format(ProcessOutcomeEnum.PREFERRED_NAME.getPath(),
                    primaryRole.getAccountNumber().getAccountNumberAsLong());
            determinePreferredName.setPath(thePath);

            thePreferredName = iibAccountsClient.getPreferredName(primaryRole.getAccountNumber(), authToken);

        } catch (STWBusinessException | STWTechnicalException e) {
            determinePreferredName.setErrorDescription(e.getMessage());
        }

        outcomeList.addOutcome(determinePreferredName);

        if (!outcomeList.hasErrors()) {

            ProcessOutcome updateLegalEntity = updateLegalEntity(primaryRole, thePreferredName, authToken);

            outcomeList.addOutcome(updateLegalEntity);
        }

        return outcomeList;
    }

    private ProcessOutcome recordMemo(AccountRole primaryRole, String authToken, Move move) {

        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setDescription("Record memo");
        outcome.setStepId("record memo");

        final Long propertyId = Long.valueOf(move.getProperty().getPropertyId());
        ForceMoveOutMemoTaskDescriptor taskDescriptor = new ForceMoveOutMemoTaskDescriptor();
        taskDescriptor.setAccountNumber(primaryRole.getAccountNumber());
        taskDescriptor.setLegalEntityNo(primaryRole.getLegalEntityId());
        taskDescriptor.setPropertyId(propertyId);
        taskDescriptor.setMove(move);
        try {
            forceMoveOutMemoService.createForceMoveOutMemo(taskDescriptor, authToken);
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setErrorDescription(e.getMessage());
        }

        return outcome;
    }

    private boolean hasSameServices(String targetServiceType, List<Property> propertyList) {
        return propertyList.stream()
                .allMatch(property -> property.getMeasuredIndicator().getCode().equalsIgnoreCase(targetServiceType));
    }

    private boolean isNewAccountRequired(Move moveTo, TargetAccountNumber accountNumber, String authToken) {
        return !isBrandNewAccountWithNoProperties(accountNumber, authToken) &&
                (isNewAccountRequiredDueToDifferentPrimaryOrCoPrimary(moveTo, accountNumber, authToken) ||
                        isNewAccountRequiredDueToBrandMismatch(moveTo) ||
                        isNewAccountRequiredDueToMultiPropertyOrOverlapServices(moveTo, accountNumber, authToken));
    }

    private boolean isBrandNewAccountWithNoProperties(final TargetAccountNumber accountNumber, String authToken) {
        return CollectionUtils.isEmpty(iibGetPropertiesClient.getPropertiesForAccountNumber(accountNumber, authToken));
    }

    private boolean isNewAccountRequiredDueToBrandMismatch(Move moveTo) {
        log.debug("isNewAccountRequiredDueToBrandMismatch start");
        return !StringUtils.equals(moveTo.getIncomingMoveDetails().getPrimaryAccountBrand(), moveTo.getIncomingMoveDetails().getPropertyBrand());
    }

    private boolean isNewAccountRequiredDueToMultiPropertyOrOverlapServices(Move moveTo, TargetAccountNumber accountNumber, String authToken) {
        log.debug("isNewAccountRequiredDueToMultiPropertyOrOverlapServices start");
        boolean newAccountRequired = false;
        List<Property> propertyList = iibGetPropertiesClient.getPropertiesForAccountNumber(accountNumber, authToken);
        List<Property> nonReversedPropertyList = removeReversedProperties(propertyList);
        List<Property> currentAndFutureActiveProperties = getCurrentAndFutureActiveProperties(propertyList);

        //Note: At this moment the new MoveIn Property is not yet Active for this account.
        if (!CollectionUtils.isEmpty(currentAndFutureActiveProperties) && currentAndFutureActiveProperties.size() > 0) {
            newAccountRequired = true;
        } else {
            List<Property> serviceOverlapProperties = getServiceOverlapProperties(nonReversedPropertyList,
                    moveTo.getIncomingMoveDetails().getMoveDate());
            if (!CollectionUtils.isEmpty(serviceOverlapProperties) && serviceOverlapProperties.size() > 0) {
                //Now check if same services.
                boolean allOverlapPropertiesHasSameServices = hasSameServices(moveTo.getProperty().getMeasuredIndicator().getCode(), serviceOverlapProperties);
                if (!allOverlapPropertiesHasSameServices) {
                    newAccountRequired = true;
                }
            }
        }

        log.debug("new account required{}", newAccountRequired);
        log.debug("isNewAccountRequiredDueToMultiPropertyOrOverlapServices end");
        return newAccountRequired;
    }

    private boolean isNewAccountRequiredDueToDifferentPrimaryOrCoPrimary(Move moveTo, TargetAccountNumber accountNumber, String authToken) {
        log.debug("isNewAccountRequiredDueToDifferentPrimaryOrCoPrimary start");

        MoveDetails incomingMoveDetails = moveTo.getIncomingMoveDetails();
        // get the list of roles for the account from Target
        List<AccountRole> targetAccountRoles = getCurrentAndFutureActiveRolesForAccount(accountNumber, authToken);

        boolean primaryMatched = matchRole(incomingMoveDetails.getLegalEntityList(), targetAccountRoles, ROLE_PRIMARY);
        log.debug("comparison check for primary:{}", primaryMatched);

        if (!primaryMatched) {
            return true;
        }

        boolean coPrimaryMatched = matchRole(incomingMoveDetails.getLegalEntityList(), targetAccountRoles, ROLE_CO_PRIMARY);
        log.debug("comparison check for co-primary:{}", coPrimaryMatched);
        log.debug("isNewAccountRequiredDueToDifferentPrimaryOrCoPrimary end");
        return !coPrimaryMatched;
    }

    private boolean isServiceStatusActiveOnAGivenDate(final TargetAccountNumber accountNumber, final Property property, final LocalDate dateOfInterest, final String authToken) {
        List<Property> propertyList = iibGetPropertiesClient.getPropertiesForAccountNumber(accountNumber, authToken);
        List<Property> activePropertyListOnAGivenDate = getActivePropertyListOnAGivenDate(propertyList, dateOfInterest);
        return !CollectionUtils.isEmpty(activePropertyListOnAGivenDate) && activePropertyListOnAGivenDate.stream()
                .anyMatch(prop -> prop.getPropertyId().equalsIgnoreCase(property.getPropertyId()));
    }

    private boolean isBetweenInclusively(final LocalDate dateOfInterest, final LocalDate earlierDate, final LocalDate latterDate) {
        return (dateOfInterest.isEqual(earlierDate) || dateOfInterest.isAfter(earlierDate)) &&
                (dateOfInterest.isEqual(latterDate) || dateOfInterest.isBefore(latterDate));
    }

    private List<Property> getActivePropertyListOnAGivenDate(final List<Property> propertyList, final LocalDate dateOfInterest) {
        List<Property> activePropertyList = new ArrayList<>();
        if (CollectionUtils.isEmpty(propertyList)) {
            return activePropertyList;
        }

        // property.status is do not reflect the property active/inactive status. As when a property is made inActive in future, the status is changed to Inactive immediately.
        // Property status can be decided by checking, if the dateOfInterest is between property startdate and enddate.
        return propertyList.stream().filter(property -> {
            if (property.getEndDate() != null) {
                return isBetweenInclusively(dateOfInterest, property.getStartDate(), property.getEndDate());// If Property has an endDate.
            }
            return dateOfInterest.isEqual(property.getStartDate()) || dateOfInterest.isAfter(property.getStartDate());
        }).collect(Collectors.toList());
    }

    private List<Property> removeReversedProperties(List<Property> propertyList) {
        // @formatter:off
        return propertyList.stream()
                .filter(property -> {
                    if (property.getStatus() == null) {
                        return true;
                    }
                    return !PROPERTY_STATUS_CODE_REVERSED.equals(property.getStatus().getCode());
                }).collect(Collectors.toList());
        // @formatter:on
    }

    /**
     * Active Property has endDate = null;
     */
    private List<Property> getCurrentAndFutureActiveProperties(final List<Property> propertyList) {
        if (CollectionUtils.isEmpty(propertyList)) {
            return new ArrayList<>();
        }
        // @formatter:off
        return removeReversedProperties(propertyList).stream()
                .filter(property -> property.getEndDate() == null)
                .collect(Collectors.toList());
        // @formatter:on
    }

    /**
     * Get Service Overlap prperties
     * Overlap check condition: New Property moveDate is between startDate and EndDate . (or before EndDate)
     * Note: This services will not consider Active properties which has endDate = null
     * Same day is not considered as overlap.
     */
    private List<Property> getServiceOverlapProperties(final List<Property> propertyList, final LocalDate moveDate) {
        if (CollectionUtils.isEmpty(propertyList)) {
            return new ArrayList<>();
        }

        return propertyList.stream().filter(property ->
                property.getEndDate() != null
                        && moveDate.isBefore(property.getEndDate())
        ).collect(Collectors.toList());
    }

    /*
     * Checks equality based on Role and Legal Entity Id.
     * If both incomingRoles && existingRoles are empty true will be returned.
     */
    private boolean matchRole(List<AccountRole> incomingRoles, List<AccountRole> existingRoles, String roleType) {
        List<Long> incomingLeList = incomingRoles.stream()
                .filter(accountRole -> accountRole.getRole().getCode().equalsIgnoreCase(roleType))
                .map(AccountRole::getLegalEntityId)
                .collect(Collectors.toList());

        List<Long> existingLeList = existingRoles.stream()
                .filter(accountRole -> accountRole.getRole().getCode().equalsIgnoreCase(roleType))
                .map(AccountRole::getLegalEntityId)
                .collect(Collectors.toList());

        return islistEqual(incomingLeList, existingLeList);
    }

    /**
     * This method will ignore the order and any duplicates.
     */
    private <T> boolean islistEqual(List<T> list1, List<T> list2) {
        return new HashSet<>(list1).equals(new HashSet<>(list2));
    }

    /*
     * Get the Target view of roles for the specified account.
     */
    private List<AccountRole> getCurrentAndFutureActiveRolesForAccount(TargetAccountNumber accountNumber, String authToken) {
        List<AccountRole> theRoleList;
        List<IIBGetRolesResponse> rolesList = iibAccountRolesClient.getCurrentAndFutureActiveRolesForAccount(accountNumber, authToken);

        theRoleList = (List<AccountRole>) CollectionUtils.collect(rolesList, getAccountRoleTransformer);

        return theRoleList;
    }

    private ProcessOutcomeList createAccountAndLinkRoles(Move moveTo, String authToken, boolean forceMoveIn) {

        ProcessOutcomeList outcomeList = new ProcessOutcomeList();
        // create an account for the primary role

        if (moveTo == null) {
            throw new STWBusinessException("create account and link roles requires moveTo");
        }
        List<AccountRole> incomingLegalEntites = moveTo.getIncomingMoveDetails().getLegalEntityList();

        AccountRole primaryRole = findPrimaryAccountRole(incomingLegalEntites);
        TargetAccountNumber accountNumber = primaryRole.getAccountNumber();

        // is forced in then always create a new account
        boolean isNewAccountRequired = forceMoveIn;

        if (!isNewAccountRequired) {
            // if not forced in then run this logic to determine if a new account is
            // required
            isNewAccountRequired = isNewAccountRequired(moveTo, accountNumber, authToken);
        }

        if (isNewAccountRequired) {

            // if it's the primary then we need to create a new account
            ProcessOutcome accountCreated = new ProcessOutcome();
            accountCreated.setStepId(ProcessOutcomeEnum.CREATE_ACCOUNT.getStepId());
            String description = String.format(ProcessOutcomeEnum.CREATE_ACCOUNT.getDescription(),
                    primaryRole.getLegalEntityId());
            accountCreated.setDescription(description);

            try {

                accountNumber = createAccount(primaryRole, moveTo.getIncomingMoveDetails(), authToken);
                primaryRole.setAccountNumber(accountNumber);

                String thePath = String.format(ProcessOutcomeEnum.CREATE_ACCOUNT.getPath(),
                        accountNumber.getAccountNumber());
                accountCreated.setPath(thePath);

                outcomeList.addOutcome(accountCreated);
            } catch (STWBusinessException | STWTechnicalException e) {
                log.error(e.getMessage(), e);
                String errorMessage = String.format(ProcessOutcomeEnum.CREATE_ACCOUNT.getErrorMessage(),
                        e.getMessage());
                accountCreated.setErrorDescription(errorMessage);
                outcomeList.addOutcome(accountCreated);
            }

        }

        // now loop through the legal entities creating new roles and assigning them to Account
        if (isCreatingNewRolesRequired(isNewAccountRequired, accountNumber, authToken)) {
            for (AccountRole accountRole : incomingLegalEntites) {
                if (!accountRole.getRole().getCode().equals(ROLE_PRIMARY)) {
                    accountRole.setAccountNumber(accountNumber);
                    accountRole.setStartDate(moveTo.getIncomingMoveDetails().getMoveDate());
                    ProcessOutcome outcome = createRole(accountRole, authToken);
                    outcomeList.addOutcome(outcome);
                }
            }
        }

        return outcomeList;

    }

    /**
     * Usecase1: If new Account is created , always create and link new Roles to the Account,
     * Usecase2: For a Brand New Account, New Account wont be created, but we need to create and link new Roles to the Account.
     */
    boolean isCreatingNewRolesRequired(boolean isNewAccountCreated, TargetAccountNumber accountNumber, String authToken) {
        return isNewAccountCreated || isBrandNewAccountWithNoProperties(accountNumber, authToken);
    }

    /**
     * Links the customer to the role
     *
     * @param role
     * @param authToken
     * @return
     */
    private ProcessOutcome createRole(AccountRole role, String authToken) {

        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setDescription(ProcessOutcomeEnum.CREATE_ROLE.getDescription());

        try {

            IIBCreateRoleRequest request = (IIBCreateRoleRequest) createAccountRoleTransformer.transform(role);

            Long roleId = iibCreateRoleClient.createRole(request, authToken);
            role.setAccountRoleId(roleId);

            outcome.setStepId(ProcessOutcomeEnum.CREATE_ROLE.getStepId());
            String description = String.format(ProcessOutcomeEnum.CREATE_ROLE.getDescription(),
                    role.getLegalEntityId());
            outcome.setDescription(description);
            String thePath = String.format(ProcessOutcomeEnum.CREATE_ROLE.getPath(), roleId);
            outcome.setPath(thePath);

        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.CREATE_ROLE.getErrorMessage(),
                    role.getLegalEntityId());
            outcome.setErrorDescription(errorMessage);
            outcome.setErrorDescription(e.getMessage());
        }

        return outcome;
    }

    private TargetAccountNumber createAccount(AccountRole primary, MoveDetails moveDetails, String authToken) {

        /**
         * Need to create an account and link it to the primary role
         */

        IIBCreateAccountResponse response = createAccountClient.createAccount(primary.getLegalEntityId(), authToken);
        Long newAccountNumber = response.getAccountNumber();
        TargetAccountNumber targetAccountNumber = new TargetAccountNumber(newAccountNumber, null);

        primary.setAccountRoleId(Long.valueOf(response.getRoleId()));

        return targetAccountNumber;
    }

    private ProcessOutcome setServiceStatusActive(Move moveTo, Property property, String authToken) {

        Long propertyId = Long.valueOf(property.getPropertyId());
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.STATUS_ACTIVATED.getStepId());
        String description = String.format(ProcessOutcomeEnum.STATUS_ACTIVATED.getDescription(), propertyId);
        outcome.setDescription(description);

        if (moveTo != null) {

            String thePath = String.format(ProcessOutcomeEnum.STATUS_ACTIVATED.getPath(), propertyId);
            outcome.setPath(thePath);

            if (moveTo.getIncomingMoveDetails().getLegalEntityList() != null
                    && moveTo.getIncomingMoveDetails().getLegalEntityList().size() > 0) {

                AccountRole primary = findPrimaryAccountRole(moveTo.getIncomingMoveDetails().getLegalEntityList());

                try {

                    IIBCreateChorRequest request = new IIBCreateChorRequest();
                    request.setPropertyId(propertyId);
                    request.setAccountNumber(primary.getAccountNumber());
                    request.setSourceCode(MOVE_IN);
                    request.setStartDate(moveTo.getIncomingMoveDetails().getMoveDate());
                    request.setServiceProvisionTariffs(moveTo.getIncomingMoveDetails().getServiceProvisionTariffs());

                    IIBChorResponse response = iibCreateChorClient.createCHOR(primary.getAccountNumber(), request, authToken);

                    moveTo.getIncomingMoveDetails().setNextBillEndDate(response.getNextBillEndDate());
                    RefData unmeasuredBillType = new RefData();
                    if (null != response.getUnMeasuredBillType()) {
                        unmeasuredBillType.setCode(response.getUnMeasuredBillType().getCode());
                    }
                    moveTo.getIncomingMoveDetails().setUnmeasuredBillType(unmeasuredBillType);

                } catch (STWBusinessException | STWTechnicalException e) {
                    log.error(e.getMessage(), e);
                    String errorMessage = String.format(ProcessOutcomeEnum.STATUS_ACTIVATED.getErrorMessage(),
                            moveTo.getProperty().getAddress(), e.getMessage());
                    outcome.setErrorDescription(errorMessage);
                }
            }

        }

        return outcome;

    }

    private ProcessOutcome updateCorrespondenceAddress(MoveDetails moveDetails, AccountRole primaryRole,
                                                       String authToken) {

        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getStepId());
        outcome.setDescription(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getDescription());

        String thePath = String.format(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getPath(),
                moveDetails.getCorrespondenceAddress().getId());

        outcome.setPath(thePath);

        Address correspondenceAddress = moveDetails.getCorrespondenceAddress();

        try {

            // doesn't fit the transformer pattern well as the re are multiple inout objects
            // required.
            IIBPatchAccountRequest request = new IIBPatchAccountRequest();
            request.setAccountNumber(primaryRole.getAccountNumber());

            BillAddress billAddress = new BillAddress();
            billAddress.setId(Long.valueOf(correspondenceAddress.getId()));
            billAddress.setLine1(correspondenceAddress.getLine1());
            billAddress.setLine2(correspondenceAddress.getLine2());
            billAddress.setLine3(correspondenceAddress.getCity());
            billAddress.setLine4(correspondenceAddress.getPostcode());
            billAddress.setStartDate(correspondenceAddress.getStartDate());
            request.setRoleId(String.valueOf(primaryRole.getAccountRoleId()));
            request.setBillingAddress(billAddress);

            iibPatchAccountClient.patchAccount(request, authToken);

        } catch (STWBusinessException | STWTechnicalException e) {
            ObjectReader targetErrorReader = objectMapper.readerFor(TargetError.class);

            TargetError targetError = null;
            try {
                targetError = targetErrorReader.readValue(e.getMessage());
            } catch (Exception e1) {
                log.debug("Exception message is not in TargetError format", e1);
            }

            if (targetError != null && TARGET_ERROR_CODE_ADDRESS_START_DATE_EQUAL_TO_EXISTING
                    .equals(targetError.getTargetReturnCode())) {
                log.warn("Whitelisted target error: {}", e.getMessage(), e);
                outcome.setWarningDescription(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getErrorMessage());
            } else {
                log.error(e.getMessage(), e);
                outcome.setErrorDescription(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getErrorMessage());
                outcome.setExceptionMessage(e.getMessage());
            }
        }

        return outcome;

    }

    /**
     * Terminate the services at the address, using the first legal entity id in the
     * outgoing list to identify the account.
     * Note: Target Needs a delay between CHOR-TurnOff and Online Bill.
     */
    private ProcessOutcome setServiceStatusInactive(Move move, Property property, String authToken) {

        Long propertyId = Long.valueOf(property.getPropertyId());

        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.STATUS_INACTIVE.getStepId());
        String description = String.format(ProcessOutcomeEnum.STATUS_INACTIVE.getDescription(), propertyId);
        outcome.setDescription(description);
        outcome.setErrorDescription(null);

        String thePath = String.format(ProcessOutcomeEnum.STATUS_INACTIVE.getPath(), propertyId);
        outcome.setPath(thePath);

        AccountRole primary = findPrimaryAccountRole(move.getOutgoingMoveDetails().getLegalEntityList());

        TargetAccountNumber accountNumber = primary.getAccountNumber();


        try {

            IIBCreateChorRequest request = new IIBCreateChorRequest();
            request.setPropertyId(propertyId);
            request.setAccountNumber(accountNumber);
            request.setSourceCode(MOVE_OUT);
            request.setEndDate(move.getOutgoingMoveDetails().getMoveDate());

            IIBChorResponse response = iibCreateChorClient.createCHOR(accountNumber, request, authToken);
            move.getOutgoingMoveDetails().setPayPlanCancelFlag(response.getPayPlanCancelFlag());
            move.getOutgoingMoveDetails().setPayPlanCancelTooLateFlag(response.getPayPlanCancelTooLateFlag());

            if (!checkIfServiceStatusInactiveSuccessful(move, accountNumber, authToken)) {
                log.debug("setServiceStatusInactive: Error During Chor-Turn Off -Immediate check of service turn off was not successful ");
                return getOutcomeForServiceStatusInactiveFailure(move, move.getProperty());
            }

        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.STATUS_INACTIVE.getErrorMessage(),
                    move.getProperty().getAddress(), e.getMessage());
            outcome.setErrorDescription(errorMessage);

        }

        return outcome;

    }

    private void saveEstimatedRead(LocalDate moveDate, Property property, String authToken, TargetAccountNumber accountNumber) {

        List<IIBMeterSummary> meterSummaries = meterReadService.getMeterSummaryWithReadHistory(accountNumber,
                property.getPropertyId(), authToken);

        Optional<IIBMeterSummary> optIIBMeterSummary = meterSummaries.stream().findFirst();
        if (optIIBMeterSummary.isPresent()) {
            IIBMeterSummary iibMeterSummary = optIIBMeterSummary.get();
            Long combinedNumber = iibMeterSummary.getCombinedNum();
            Long serialOrEquipNumber = iibMeterSummary.getEquipNum();
            LocalDate dateToEstimate = moveDate;

            Float readingEstimate = meterReadService.getReadingEstimate(serialOrEquipNumber, combinedNumber,
                    dateToEstimate, authToken);
            MeterReadInfoRequest meterReadInfo = new MeterReadInfoRequest();
            meterReadInfo.setCombinedNum(combinedNumber);
            meterReadInfo.setMoveDate(dateToEstimate);
            meterReadInfo.setMoveDirection(MOVE_OUT);
            meterReadInfo.setPropertyId(property.getPropertyId());

            createMeterReadDetailRequestFromIIBMeterReadResponse(iibMeterSummary, serialOrEquipNumber, readingEstimate,
                    meterReadInfo, dateToEstimate);

            meterReadService.createMeterRead(serialOrEquipNumber, meterReadInfo, authToken);
        }


    }

    private void createMeterReadDetailRequestFromIIBMeterReadResponse(IIBMeterSummary iibMeterSummary,
                                                                      Long serialOrEquipNumber, Float readingEstiate, MeterReadInfoRequest meterReadInfo, LocalDate moveDate) {

        meterReadInfo.setUtilEquipNum(String.valueOf(serialOrEquipNumber));
        Optional<IIBGetMeterReadWrapper> optIIBMeterReadResponse = iibMeterSummary.getIibMeterReads().stream()
                .findFirst();
        List<MeterReadDetailRequest> reads = new ArrayList<>();
        MeterReadDetailRequest meterReadRequest = new MeterReadDetailRequest();

        if (optIIBMeterReadResponse.isPresent()) {
            IIBGetMeterReadResponse iibMeterReadResponse = optIIBMeterReadResponse.get().getIibGetMeterReadResponse();
            meterReadInfo.setRegisterNum(iibMeterReadResponse.getRegisterNum());
            meterReadRequest.setCapturedDate(moveDate);
            meterReadRequest.setOverrideFlag(OVERRIDE_FLAG_H);
            meterReadRequest.setReading(readingEstiate);
            setReadSource(iibMeterReadResponse, meterReadRequest);
            setReadStatus(iibMeterReadResponse, meterReadRequest);
            setReadType(iibMeterReadResponse, meterReadRequest);
            meterReadRequest.setReadUsage(String.valueOf(iibMeterSummary.getAmountUsage()));
            meterReadRequest.setStatus(STATUS_NEW);
            reads.add(meterReadRequest);
            meterReadInfo.setReads(reads);
        }
    }

    private void setReadType(IIBGetMeterReadResponse iibMeterReadResponse, MeterReadDetailRequest meterReadRequest) {
        MeterReadRefData readType = new MeterReadRefData();
        readType.setCode(READ_TYPE_CODE_Z);
        meterReadRequest.setReadType(readType);
    }

    private void setReadStatus(IIBGetMeterReadResponse iibMeterReadResponse, MeterReadDetailRequest meterReadRequest) {
        MeterReadRefData readStatus = new MeterReadRefData();
        readStatus.setCode(STATUS_CODE_B);
        meterReadRequest.setReadStatus(readStatus);
    }

    private void setReadSource(IIBGetMeterReadResponse iibMeterReadResponse, MeterReadDetailRequest meterReadRequest) {
        MeterReadRefData readSource = new MeterReadRefData();
        readSource.setCode(READ_SOURCE_CODE_S);
        meterReadRequest.setReadSource(readSource);
    }

    /*
     * This check is done as a Mechanism to create a Delay between Chor-TurnOff service and OnlineBIll Service.
        Note: Target Needs a delay between CHOR-TurnOff and Online Bill.
        Note: Initially the check was done just once, but target seems to be slowing down intermittently, so will be trying 3 attempts.
     */
    private boolean checkIfServiceStatusInactiveSuccessful(Move move, TargetAccountNumber accountNumber, String authToken) {
        log.debug("checkIfServiceStatusInactiveSuccessful Start");
        LocalDate dayAfterMoveOut = move.getOutgoingMoveDetails().getMoveDate().plusDays(ONE_DAY_AFTER_MOVE_OUT);
        boolean isServiceStatusActive = isServiceStatusActiveOnAGivenDate(accountNumber, move.getProperty(), dayAfterMoveOut, authToken);
        int chorTurnOffCheckCycle = NO_OF_ATTEMPTS_OF_CHOR_TURN_OFF_CHECK;
        while (isServiceStatusActive && chorTurnOffCheckCycle > 0) {
            isServiceStatusActive = isServiceStatusActiveOnAGivenDate(accountNumber, move.getProperty(), dayAfterMoveOut, authToken);
            chorTurnOffCheckCycle--;
            log.debug("checkIfServiceStatusInactiveSuccessful chorTurnOffCheckCycle = {}", chorTurnOffCheckCycle);
        }
        log.debug("checkIfServiceStatusInactiveSuccessful End");
        return !isServiceStatusActive;

    }

    private ProcessOutcome getOutcomeForServiceStatusInactiveFailure(Move move, Property property) {
        Long propertyId = Long.valueOf(property.getPropertyId());
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.STATUS_INACTIVE_SUCCESS_CHECK_FAILED.getStepId());
        String description = String.format(ProcessOutcomeEnum.STATUS_INACTIVE_SUCCESS_CHECK_FAILED.getDescription(), propertyId);
        outcome.setDescription(description);
        String thePath = String.format(ProcessOutcomeEnum.STATUS_INACTIVE_SUCCESS_CHECK_FAILED.getPath(), propertyId);
        outcome.setPath(thePath);
        String errorMessage = String.format(ProcessOutcomeEnum.STATUS_INACTIVE_SUCCESS_CHECK_FAILED.getErrorMessage(),
                move.getProperty().getAddress());
        outcome.setErrorDescription(errorMessage);
        return outcome;
    }

    private AccountRole findPrimaryAccountRole(List<AccountRole> legalEntityList) {
        AccountRole primaryRole = getLegalEntity(legalEntityList, ROLE_PRIMARY);
        if (primaryRole == null) {
            throw new STWBusinessException("Unable to find primary role in legal entity list");
        }
        return primaryRole;
    }

    private AccountRole getLegalEntity(List<AccountRole> legalEntityList, String role) {
        AccountRole primary = null;

        for (AccountRole accountRole : legalEntityList) {

            if (accountRole.getRole().getCode().equalsIgnoreCase(role)) {
                primary = accountRole;
                break;
            }

        }

        return primary;

    }

    private void validateMove(Move move) {
        if (null == move.getProperty()) {
            throw new STWBusinessException("property is a required property");
        } else {
            if (null == move.getProperty().getPropertyId()) {
                throw new STWBusinessException("property.id is a required property");
            }

            if (null == move.getProperty().getMeasuredIndicator()) {
                throw new STWBusinessException("property.measuredInd is a required property");
            } else {
                if (null == move.getProperty().getMeasuredIndicator().getCode()) {
                    throw new STWBusinessException("property.measuredInd.code is a required property");
                }
            }

        }

        if (null == move.getIncomingMoveDetails() && null == move.getOutgoingMoveDetails()) {
            throw new STWBusinessException("incoming and/or outgoing move details is a required property");
        }

        if (null != move.getIncomingMoveDetails()) {
            validateMoveDetails(move.getIncomingMoveDetails());
        }

        if (null != move.getOutgoingMoveDetails()) {
            validateMoveDetails(move.getOutgoingMoveDetails());
        }
    }

    private void validateMoveDetails(MoveDetails moveDetails) {
        if (null == moveDetails.getLegalEntityList() || moveDetails.getLegalEntityList().size() < 1) {
            throw new STWBusinessException("legalEntityList is a required property");
        }

        validateRoles(moveDetails.getLegalEntityList());

        if (null == moveDetails.getMoveDate()) {
            throw new STWBusinessException("moveDate is a required property");
        }

        if (null != moveDetails.getMeterReading() && null == moveDetails.getMeterReadDate()) {
            throw new STWBusinessException("meterRead date is a a required parameter if meter reading is supplied");
        }

        if (null == moveDetails.getCorrespondenceAddress()) {

        }

        if (null != moveDetails.getCorrespondenceAddress()) {
            if (null == moveDetails.getCorrespondenceAddress().getId()) {
                throw new STWBusinessException("correspondenceAddress.id is a required property");
            }
        }

    }

    private void validateRoles(List<AccountRole> roles) {
        for (AccountRole accountRole : roles) {
            validateRole(accountRole);
        }
    }

    private void validateRole(AccountRole accountRole) {
        if (null != accountRole) {
            if (null != accountRole.getCustomer() && null == accountRole.getCustomer().getId()) {
                throw new STWBusinessException("id is a required property of Customer.");
            }
        }

        if (accountRole != null && null == accountRole.getRole()) {
            throw new STWBusinessException("accountRole.role is a required property");
        }
    }
}
