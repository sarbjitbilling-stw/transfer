package uk.co.stwater.api.osgi.chor.agent;

import uk.co.stwater.api.osgi.model.ClientReverseBillRequest;
import uk.co.stwater.api.osgi.model.ReverseBillRequest;
import uk.co.stwater.api.osgi.model.ReverseBillResponse;
import uk.co.stwater.api.osgi.model.transaction.AccountEvent;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.util.List;

public interface ReverseBillService {

    List<ReverseBillResponse> reverseBill(ClientReverseBillRequest request, String authToken) throws STWBusinessException, STWTechnicalException;

    List<ReverseBillResponse> reverseBill(final ClientReverseBillRequest clientReverseBillRequest, final boolean retryAfterTimeout, final String authToken) throws STWBusinessException, STWTechnicalException;

    List<ReverseBillResponse> reverseBill(ClientReverseBillRequest clientReverseBillRequest, ReverseBillRequest reverseBillRequestInfo, boolean retryAfterTimeout, String authToken) throws STWBusinessException, STWTechnicalException;

    List<AccountEvent> reChorBillsToReverse(ClientReverseBillRequest request, String authToken) throws STWBusinessException, STWTechnicalException;

}
