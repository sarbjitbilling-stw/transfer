package uk.co.stwater.api.osgi.chor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

abstract class AbstractChorStateProcessor implements ChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(AbstractChorStateProcessor.class);

    static final int NO_ADDRESS_CODE = 0;

    static final long NO_PROPERTY_NUMBER = 0L;

    static final String UNKNOWN_POSTCODE = "POSTCODE";

    ChorStateManager chorStateManager;

    ChorStateProcessor nextStateProcessor;

    ServiceFacade serviceFacade;

    ChorPreProcessor chorPreProcessor;

    ChorPostProcessor chorPostProcessor;

    AbstractChorStateProcessor(ServiceFacade serviceFacade, ChorStateManager chorStateManager, ChorStateProcessor nextStateProcessor) {
        this.serviceFacade = serviceFacade;
        this.chorStateManager = chorStateManager;
        this.nextStateProcessor = nextStateProcessor;
    }

    void setChorPreProcessor(ChorPreProcessor chorPreProcessor) {
        this.chorPreProcessor = chorPreProcessor;
    }

    void setChorPostProcessor(ChorPostProcessor chorPostProcessor) {
        this.chorPostProcessor = chorPostProcessor;
    }

    @Override
    public final void process(ChorContext chorContext) {

        try {
            logger.debug("process invoked");
            if(chorPreProcessor != null) {
                logger.debug("invoking pre processor");
                chorPreProcessor.preProcess(chorContext);
            }

            processState(chorContext);

            if(chorPostProcessor != null) {
                logger.debug("invoking post processor");
                chorPostProcessor.postProcess(chorContext);
            }

            nextStateProcessor.process(chorContext);
        } catch (ChorProcessingException e) {
            logger.error("processor threw exception", e);
        }
    }

    protected abstract void processState(ChorContext chorContext);
}
