package uk.co.stwater.api.osgi.chor.agent.memo;

import io.swagger.model.RefData;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.Move;
import uk.co.stwater.api.osgi.model.MoveDetails;
import uk.co.stwater.api.osgi.model.memo.RefDataDefinition;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.contactevent.patch.IIBPatchContactEventClient;
import uk.co.stwater.iib.client.api.contactevent.patch.IIBPatchContactEventRequest;
import uk.co.stwater.iib.client.api.contactevent.patch.IIBPatchContactEventResponse;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.time.format.DateTimeFormatter;
import java.util.function.Function;

@Named
@OsgiServiceProvider(classes = {ForceMoveOutMemoService.class})
public class ForceMoveOutMemoServiceImpl implements ForceMoveOutMemoService {
    private static final String CONTACT_PACKAGE_ID = "131";
    private static final String CE_FLAG_N = "N";
    private static final String CE_FLAG_Y = "Y";

    private static final String MEASUREDINDICATOR_MEASURED_CODE = "M";

    private static final String MSG_MEMO_CONTENT = "Account closed. Move out date advised by new occupier.";

    private static final String FIELD_MOVE_OUT_DATE = "Move out date";
    private static final String FIELD_CORRESPOND_ADDR = "Correspondence address";
    private static final String FIELD_PLAN_CANCELLED = "Payment plan cancelled";
    private static final String FIELD_METER_READ = "Meter Read";
    private static final String FIELD_METER_READ_TYPE = "Meter Read Type";

    private static final String MSG_UNKNOWN = "Not Specified";
    private static final String MSG_CORRESPOND_ADDRES_UNKNOWN = "Correspondence address unknown";
    private static final String MSG_CANCEL_PAYMENT_PLAN_OK = "Payment arrangement cancelled";
    private static final String MSG_CANCEL_PAYMENT_PLAN_FAILED = "Unable to cancel payment arrangement";
    private static final String MSG_METER_READ_UNKNOWN = "Meter read unknown";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private Logger log = LoggerFactory.getLogger(ForceMoveOutMemoService.class);

    @Inject
    @OsgiService
    private IIBPatchContactEventClient patchClient;

    /**
     * {@inheritDoc}
     */
    @Override
    public void createForceMoveOutMemo(final ForceMoveOutMemoTaskDescriptor moveOutMemoTask, final String authToken) {
        log.debug("createForceMoveOutMemo : Attempting to create force-move-out memo {}", moveOutMemoTask);
        if (moveOutMemoTask == null) {
            log.error("createForceMoveOutMemo parameter, moveOutMemoTask must not be null");
            throw new STWTechnicalException("the specified CreateForceMoveOutMemoTaskDescriptor cannot be null");
        }
        // The memo content has not been agreed yet, hard coding this for now.
        if (moveOutMemoTask.getPropertyId() == null
                || moveOutMemoTask.getLegalEntityNo() == null
                || moveOutMemoTask.getAccountNumber() == null
                || moveOutMemoTask.getMove() == null
                || moveOutMemoTask.getMove().getOutgoingMoveDetails() == null) {
            log.debug(
                    "createForceMoveOutMemo failed: move/outgoingMoveDetails, propertyId, legalEntityNo, accountId and contactPackageId must be specified for {}",
                    moveOutMemoTask);
            throw new STWTechnicalException(
                    "move/outgoingMoveDetails, propertyId, legalEntityNo, accountId and contactPackageId are mandatory.");
        }

        final IIBPatchContactEventRequest createContactRecordRequest = makeCreateContactRecordPatchRequest(
                moveOutMemoTask);
        final IIBPatchContactEventResponse createContactRecordResponse = patchClient
                .createContactRecord(createContactRecordRequest, authToken);

        if ((createContactRecordResponse == null) || (createContactRecordResponse.getContactId() == null)) {
            log.error("Unable to retrieve contact ID for existing occupier : {}", moveOutMemoTask);
            throw new STWBusinessException("Unable to retrieve contact ID for existing occupier",
                    Response.Status.NOT_FOUND);
        }
        final String contactId = createContactRecordResponse.getContactId();
        log.debug("initial patch request successful, obtained contactId {}",
                createContactRecordResponse.getContactId());

        // we should now have the contact id in the response - build the memo request
        final String notesDescription = buildMemoDescription(moveOutMemoTask.getMove());
        log.debug("memo notesDescription {}", notesDescription);
        final IIBPatchContactEventRequest createMemoRequest = makeMoveOutMemo(contactId, notesDescription);
        try {
            patchClient.setContactEventMemo(createMemoRequest, authToken);
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error("Setting notes description for contactId {} failed {}", contactId, e.getLocalizedMessage());
            throw e;
        }
    }

    /**
     * @param moveOutMemoTask
     * @return
     */
    private IIBPatchContactEventRequest makeCreateContactRecordPatchRequest(
            final ForceMoveOutMemoTaskDescriptor moveOutMemoTask) {
        final IIBPatchContactEventRequest request = new IIBPatchContactEventRequest();
        request.setPropertyId(moveOutMemoTask.getPropertyId());
        request.setAccountNumber(moveOutMemoTask.getAccountNumber());
        request.setLegalEntityNo(moveOutMemoTask.getLegalEntityNo());
        request.setContactPackageId(CONTACT_PACKAGE_ID);
        request.setComplaintReceivedFlag(CE_FLAG_N);
        request.setRepeatReqFlag(CE_FLAG_N);
        request.setSubstituteRespFlag(CE_FLAG_Y);
        request.setResolution(makeResolution());
        request.setRootCauseType(makeRootCauseType());
        request.setContactInitiatedBy(makeContactInitiatedRefData());
        request.setContactType(makeContactTypeRefData());
        request.setContactSubType(makeRefData(RefDataDefinition.CONTACT_SUB_TYPE));
        return request;
    }

    private IIBPatchContactEventRequest makeMoveOutMemo(
            final String contactId,
            final String memoContent) {
        final IIBPatchContactEventRequest request = new IIBPatchContactEventRequest();
        request.setNotesType(makeNotesTypeRefData());
        request.setContactId(contactId);
        request.setNotesDescription(memoContent);
        return request;
    }

    private String buildMemoDescription(
            final Move move) {
        log.debug("buildMemoDescription");

        final MoveDetails outgoingMoveDetails = move.getOutgoingMoveDetails();
        final MemoBuilder builder = new MemoBuilder();
        builder
                .appendLine(MSG_MEMO_CONTENT)
                .appendLine("")
                .appendDataField(FIELD_MOVE_OUT_DATE, obtainMoveOutDateAsText(outgoingMoveDetails))
                .appendDataField(FIELD_CORRESPOND_ADDR, obtainCorrespondanceAddressText(outgoingMoveDetails))
                .appendDataField(FIELD_PLAN_CANCELLED, obtainPaymentPlanCancelledText(outgoingMoveDetails));

        if (isMeteredProperty(move)) {
            builder
                    .appendDataField(FIELD_METER_READ, obtainMeterReadText(outgoingMoveDetails))
                    .appendDataField(FIELD_METER_READ_TYPE, obtainMeterReadTypeText(outgoingMoveDetails));
        }
        return builder.toString();
    }

    private boolean isMeteredProperty(final Move move) {
        boolean metered = false;
        if (
                move.getProperty() != null
                        && move.getProperty().getMeasuredIndicator() != null
                        && move.getProperty().getMeasuredIndicator().getCode() != null) {
            metered = move.getProperty().getMeasuredIndicator().getCode().equals(MEASUREDINDICATOR_MEASURED_CODE);
        }
        return metered;
    }

    private RefData makeResolution() {
        return makeRefData(RefDataDefinition.RESOLUTION);
    }

    private RefData makeRootCauseType() {
        return makeRefData(RefDataDefinition.ROOT_CAUSE_TYPE);
    }

    private RefData makeNotesTypeRefData() {
        return makeRefData(RefDataDefinition.NOTES_TYPE);
    }

    private RefData makeContactTypeRefData() {
        return makeRefData(RefDataDefinition.CONTACT_TYPE);
    }

    private RefData makeContactInitiatedRefData() {
        return makeRefData(RefDataDefinition.CONTACT_INIT);
    }

    private String obtainMoveOutDateAsText(final MoveDetails moveDetails) {
        log.trace("obtainMoveOutDateAsText");
        return obtainFieldAsText(MoveDetails::getMoveDate, d -> DATE_FORMATTER.format(d), moveDetails, MSG_UNKNOWN);
    }

    private String obtainMeterReadText(final MoveDetails moveDetails) {
        log.trace("obtainMeterReadText");
        return obtainFieldAsText(MoveDetails::getMeterReading,
                reading -> String.format("%s%s", Integer.toString(reading), "m3"),
                moveDetails, MSG_METER_READ_UNKNOWN);
    }

    private String obtainMeterReadTypeText(final MoveDetails moveDetails) {
        log.trace("obtainMeterReadTypeText");
        return obtainFieldAsText(MoveDetails::getMeterReadingType, Function.identity(), moveDetails, MSG_METER_READ_UNKNOWN);
    }

    private String obtainCorrespondanceAddressText(final MoveDetails moveDetails) {
        log.trace("obtainCorrespondanceAddressText");
        return obtainFieldAsText(MoveDetails::getCorrespondenceCombinedAddress, Function.identity(), moveDetails, MSG_CORRESPOND_ADDRES_UNKNOWN);
    }

    private String obtainPaymentPlanCancelledText(final MoveDetails moveDetails) {
        log.trace("obtainPaymentPlanCancelledText");
        return moveDetails.isPayPlanCancelFlag() ? MSG_CANCEL_PAYMENT_PLAN_OK : MSG_CANCEL_PAYMENT_PLAN_FAILED;
    }

    private <E, T> String obtainFieldAsText(
            final Function<E, T> resolver,
            final Function<T, String> toString,
            final E moveDetails,
            final String defaultValue) {
        log.trace("obtainFieldAsText");
        String value = defaultValue;
        final T resolvedValue = resolver.apply(moveDetails);
        if (resolvedValue != null) {
            final String valueAsString = toString.apply(resolvedValue);
            if (StringUtils.isNotBlank(valueAsString)) {
                log.debug("found non blank value {}, setting return value", valueAsString);
                value = valueAsString;
            }
        }
        return value;
    }

    private RefData makeRefData(final RefDataDefinition refDataDef) {
        final RefData refData = new RefData();
        refData.setValue(refDataDef.getValue());
        refData.setCode(refDataDef.getCode());
        refData.setValueSet(refDataDef.getValueSet());
        return refData;
    }

    /**
     * StringBuilder decorator.
     * Convenience class for adding formatted text to memo notes.
     *
     * @author Andrew Landeg
     */
    private static class MemoBuilder {
        private static final String LINE_BREAK = System.lineSeparator();
        private final StringBuilder builder = new StringBuilder();

        public MemoBuilder append(final String str) {
            builder.append(str);
            return this;
        }

        public MemoBuilder appendLine(final String str) {
            append(str);
            append(LINE_BREAK);
            return this;
        }

        public MemoBuilder appendDataField(final String field, final String value) {
            builder.append(field)
                    .append("  : ")
                    .append(value)
                    .append(LINE_BREAK);
            return this;
        }

        public String toString() {
            return builder.toString();
        }

    }

}
