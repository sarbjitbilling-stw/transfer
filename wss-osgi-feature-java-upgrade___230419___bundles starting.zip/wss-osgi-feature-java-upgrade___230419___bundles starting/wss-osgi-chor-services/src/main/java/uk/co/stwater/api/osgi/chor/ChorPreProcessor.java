package uk.co.stwater.api.osgi.chor;

/**
 * ChorPreProcessor provides functionality that should be executed before a {@link ChorStateProcessor} performs its work.
 */
public interface ChorPreProcessor {

    void preProcess(ChorContext chorContext);

}
