package uk.co.stwater.api.osgi.chor.agent;

import javax.inject.Named;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.model.AccountRole;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesResponse;

@Named
public class AccountRoleTransformer implements Transformer {

	@Override
	public Object transform(Object source) {

		AccountRole accountRole = null;
		if (null == source) {
			throw new STWBusinessException("source is a required parameter");
		}

		if (source instanceof IIBGetRolesResponse) {
			IIBGetRolesResponse response = (IIBGetRolesResponse) source;
			accountRole = new AccountRole();

			Customer customer = new Customer();
			customer.setId(String.valueOf(response.getLegalEntityNo()));
			customer.setFirstName(response.getFirstName());
			customer.setLastName(response.getLastName());
			// customer.setTitle(response.getTitle());
			accountRole.setCustomer(customer);
			accountRole.setAccountRoleId(Long.valueOf(response.getRoleId()));
			RefData theRole = new RefData();
			theRole.setCode(response.getRole().getCode());
			accountRole.setLegalEntityId(response.getLegalEntityNo());
			accountRole.setRole(theRole);
		}

		return accountRole;
	}

}
