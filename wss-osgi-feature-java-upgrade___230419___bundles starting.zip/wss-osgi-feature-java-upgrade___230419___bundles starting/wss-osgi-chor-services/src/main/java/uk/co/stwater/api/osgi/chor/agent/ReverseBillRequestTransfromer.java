package uk.co.stwater.api.osgi.chor.agent;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import javax.inject.Named;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.model.ReverseBillReason;
import uk.co.stwater.api.osgi.model.ReverseBillRequest;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.bill.cancel.IIBCancelBillReason;
import uk.co.stwater.iib.client.api.bill.cancel.IIBCancelBillRequest;

@Named
public class ReverseBillRequestTransfromer implements Transformer {

	@Override
	public Object transform(Object source) {
		IIBCancelBillRequest cancelBillRequest = new IIBCancelBillRequest();
		if (null == source) {
			throw new STWBusinessException("source is a mandatory parameter");
		}

		if (source instanceof ReverseBillRequest) {

			ReverseBillRequest reverseBillRequest = (ReverseBillRequest) source;
			cancelBillRequest.setAccountNumber(reverseBillRequest.getAccountId().getAccountNumberAsLong());
			cancelBillRequest.setPropertyId(reverseBillRequest.getPropertyId());
			if (reverseBillRequest.getCreatedTime() != null) {
				OffsetDateTime createdTime = OffsetDateTime.of(reverseBillRequest.getCreatedTime(), ZoneOffset.UTC);
				cancelBillRequest.setCreatedTime(createdTime);
			}
			if (reverseBillRequest.getDateOfIssue() != null) {
				OffsetDateTime dateOfIssue = OffsetDateTime.of(reverseBillRequest.getDateOfIssue(),ZoneOffset.UTC);
				cancelBillRequest.setDateOfIssue(dateOfIssue);
			}
			IIBCancelBillReason cancelBillReason = new IIBCancelBillReason();
			ReverseBillReason reverseBillReason = reverseBillRequest.getBillCancelReason();
			cancelBillReason.setCode(reverseBillReason.getCode());
			cancelBillReason.setValue(reverseBillReason.getValue());
			cancelBillReason.setValueSet(reverseBillReason.getValueSet());
			cancelBillRequest.setBillCancelReason(cancelBillReason);
			cancelBillRequest.setCheckMultiSPFlag(reverseBillRequest.getCheckMultiSPFlag());
			cancelBillRequest.setIsCancelAllReads(reverseBillRequest.getIsCancelAllReads());
			cancelBillRequest.setPrintAdjustNoteFlag(reverseBillRequest.getPrintAdjustNoteFlag());
			cancelBillRequest.setRebillFlag(reverseBillRequest.getRebillFlag());
			cancelBillRequest.setServiceProvisionNum(reverseBillRequest.getServiceProvisionNum());
			cancelBillRequest.setShowOnBill(reverseBillRequest.getShowOnBill());

		} else {
			throw new STWBusinessException("source must be an instance of ReverseBillRequest");
		}

		return cancelBillRequest;
	}

}
