package uk.co.stwater.api.osgi.chor.contact;

import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.chor.ChorResponse;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

import java.util.List;

/**
 * Created by tellis3 on 04/05/2017.
 */
public interface ChorContactTypeResolver {
    
    List<ContactType> getContactTypes(ChorResponse response, Long legalEntityId, Account account, TargetAccountNumber targetAccountNumber, MoveRequestDetail movingOutDetails, MoveRequestDetail movingInDetails,
            Address newAddressPreviousCustomer, boolean billPayerMovingInAddress, AccountBrand accountBrand) throws STWTechnicalException, STWBusinessException;

}
