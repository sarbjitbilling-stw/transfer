package uk.co.stwater.api.osgi.chor;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.email.service.EmailService;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.payment.common.AccountInfo;
import uk.co.stwater.api.osgi.model.payment.common.PaymentPlan;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.payment.scheduled.CancelPlanException;
import uk.co.stwater.api.payment.scheduled.CreatePlanException;
import uk.co.stwater.api.payment.scheduled.ScheduledPaymentPlanService;
import uk.co.stwater.api.payment.scheduled.ScheduledPaymentService;
import uk.co.stwater.api.payment.scheduled.ScheduledPaymentServiceImpl;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;
import uk.co.stwater.targetconnector.client.api.directdebit.GetDirectDebitClient;

@Named
public class ChorPaymentPlanServiceImpl implements ChorPaymentPlanService {

    private static Logger logger = LoggerFactory.getLogger(ChorPaymentPlanServiceImpl.class);

    private static final String UNKNOWN_POSTCODE = "POSTCODE";

    private static final String CANCEL_PAYMENT_PLAN_FAILED = "Cancel payment plan failed";

    private static final String EMAIL_0184_REQUEST_SUCCESS = "E18.4";
    private static final String EMAIL_0182_REQUEST_SUCCESS = "E18.2";
    private static final String EMAIL_0181_REQUEST_SUCCESS = "E18.1";
    private static final String EMAIL_0185_REQUEST_SUCCESS = "E18.5";
    private static final String EMAIL_0186_REQUEST_SUCCESS = "E18.6";
    private static final String EMAIL_163_REQUEST_FAIL = "E16.3";
    private static final String EMAIL_1810_REQUEST_SUCCESS = "E18.10";
    private static final String EMAIL_0188_REQUEST_SUCCESS = "E18.8";
    private static final String EMAIL_0189_REQUEST_FAIL = "E18.9";
    private static final String PAYMENT_PLAN_SUCCESS_CONTACT = "705";
    private static final String PAYMENT_PLAN_CANCEL_CONTACT = "707";
    private static final String PAYMENT_PLAN_FAIL_CONTACT = "708";
    private static final String PAYMENT_PLAN_CANCEL_FAIL_CONTACT = "709";
    private static final String PAYMENT_PLAN_CANCEL_FAIL_INSETUP_CONTACT = "714";
    private static final String PAYMENT_FREQUENCY_MONTHLY = "monthly";
    private static final String PAYMENT_FREQUENCY_FORTNIGHTLY = "every 2 weeks";
    private static final String PAYMENT_FREQUENCY_WEEKLY = "weekly";
    private static final String PAYMENT_FREQUENCY_FOUR_WEEKLY = "every 4 weeks";

    @Inject
    @OsgiService
    private ScheduledPaymentService scheduledPaymentService;

    @Inject
    @OsgiService
    private ScheduledPaymentPlanService scheduledPaymentPlanService;

    @Inject
    @OsgiService
    private GetDirectDebitClient getDirectDebitClient;

    @Inject
    @OsgiService
    private CreateContactClient createContactClient;

    @OsgiService
    @Inject
    private ReferenceDataService referenceDataService;

    @Inject
    @OsgiService
    private EmailService emailService;

    @Override
    public ChorResponse createPaymentPlan(TargetAccountNumber accountNumber, String legalEntityNumber,
                                          ContactDto contactDto, String username, ChorRequest chorRequest) {

        ChorProgressMonitor progressMonitor = new ChorProgressMonitor(ChorStateManager.existingCustomer(), true, true);
        ChorResponse chorResponse = new ChorResponse(false);
        chorResponse.setChorProgressMonitor(progressMonitor);

        ChorStateManager chorStateManager = progressMonitor.getChorStateManager();
        fastForwardChorStates(chorStateManager);
        scheduledPaymentService.getActivePaymentPlan(accountNumber).ifPresent(oldPaymentPlan -> {
            progressMonitor.setOldPaymentPlan(oldPaymentPlan);
            if (oldPaymentPlan.getFacilityCode().equals(
                    uk.co.stwater.targetconnector.client.api.payplan.PaymentPlan.Facility.DIRECT_DEBIT_PAYMENT_FACILITY
                            .getValue())) {
                progressMonitor
                        .setOldPaymentMandate(getDirectDebitClient.getDirectDebit(accountNumber, UNKNOWN_POSTCODE));
            }
            try {
                chorResponse.setSuccess(true);
                boolean doNotMaintainInstalmentAmount = true;
                ScheduledPaymentServiceImpl.PlanChangeRequest changeRequest = new ScheduledPaymentServiceImpl.PlanChangeRequest();
                changeRequest.setAccountNumber(accountNumber);
                changeRequest.setDoNotMaintainInstalmentAmount(doNotMaintainInstalmentAmount);
                PaymentPlan newPaymentPlan = scheduledPaymentService.recreatePaymentPlan(changeRequest);
                chorStateManager.createPaymentPlan(ChorProgressMonitor.Progress.COMPLETED);
                progressMonitor.setNewPaymentPlan(newPaymentPlan);
            } catch (CancelPlanException ex) {
                logger.warn("Could not cancel existing payment plan", ex);
                chorStateManager.cancelPaymentPlan(ChorProgressMonitor.Progress.FAILED);
                chorResponse.setErrorMessage(ex.getLocalizedMessage());
            } catch (CreatePlanException ex) {
                logger.warn("Could not re-create existing payment plan", ex);
                progressMonitor.setCreateNewPaymentPlanErrorReason(ex.getLocalizedMessage());
                chorStateManager.createPaymentPlan(ChorProgressMonitor.Progress.FAILED);
                chorResponse.setErrorMessage(ex.getLocalizedMessage());
            } catch (STWBusinessException ex) {
                if (CANCEL_PAYMENT_PLAN_FAILED.equals(ex.getLocalizedMessage())) {
                    logger.warn("Could not cancel existing payment plan", ex);
                    chorStateManager.cancelPaymentPlan(ChorProgressMonitor.Progress.FAILED);
                    chorResponse.setErrorMessage(ex.getLocalizedMessage());
                }
            }
        });

        setUpDMContactEmailForSetUpPP(chorRequest, chorResponse, legalEntityNumber, accountNumber, contactDto,
                chorResponse.getErrorMessage(), username, chorStateManager);
        return chorResponse;
    }

    @Override
    public ChorResponse cancelPaymentPlan(TargetAccountNumber accountNumber, String legalEntityNumber, ContactDto contactDto,
                                          String username, ChorRequest chorRequest) throws ChorException {
      
        ChorProgressMonitor progressMonitor = new ChorProgressMonitor(ChorStateManager.existingCustomer(), true, true);
        ChorResponse chorResponse = new ChorResponse(false);
        chorResponse.setChorProgressMonitor(progressMonitor);
        ChorStateManager chorStateManager = progressMonitor.getChorStateManager();
        fastForwardChorStates(chorStateManager);

        scheduledPaymentService.getActivePaymentPlan(accountNumber).ifPresent(oldPaymentPlan -> {
            progressMonitor.setOldPaymentPlan(oldPaymentPlan);
            if (oldPaymentPlan.getFacilityCode().equals(
                    uk.co.stwater.targetconnector.client.api.payplan.PaymentPlan.Facility.DIRECT_DEBIT_PAYMENT_FACILITY
                            .getValue())) {
                progressMonitor.setOldPaymentMandate(getDirectDebitClient.getDirectDebit(accountNumber, UNKNOWN_POSTCODE));
            }
            try {
                chorResponse.setSuccess(true);

                AccountInfo accountInfo = new AccountInfo() {
                    @Override
                    public TargetAccountNumber getAccountNumber() {
                        return accountNumber;
                    }

                    @Override
                    public BigDecimal getAccountBalance() {
                        return BigDecimal.ZERO;
                    }

                    @Override
                    public Address getAddress() {
                        return chorRequest.getNewAddressPreviousCustomer();
                    }

                    @Override
                    public boolean isFutureStartPlan() {
                        return false;
                    }

                };
                scheduledPaymentPlanService.cancelPaymentPlan(accountInfo);
                chorStateManager.cancelPaymentPlan(ChorProgressMonitor.Progress.COMPLETED);
            } catch (CancelPlanException ex) {
                logger.warn("Could not cancel existing payment plan", ex);
                chorStateManager.cancelPaymentPlan(ChorProgressMonitor.Progress.FAILED);
            }
        });
        setUpDMContactEmailForCancelPP(chorRequest, chorResponse, legalEntityNumber, accountNumber, contactDto,
                chorResponse.getErrorMessage(), username, chorStateManager);
        return chorResponse;
    }

    private static void fastForwardChorStates(ChorStateManager chorStateManager) {
        chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.COMPLETED)
                .moveOutNewAddress(ChorProgressMonitor.Progress.COMPLETED)
                .moveOutChorOn(ChorProgressMonitor.Progress.COMPLETED).moveOutRole(ChorProgressMonitor.Progress.COMPLETED)
                .moveInChorOn(ChorProgressMonitor.Progress.COMPLETED).moveInAddress(ChorProgressMonitor.Progress.COMPLETED)
                .moveInRole(ChorProgressMonitor.Progress.COMPLETED).forcedOutSimBill(ChorProgressMonitor.Progress.COMPLETED)
                .moveInSimBill(ChorProgressMonitor.Progress.COMPLETED);
    }

    private void setUpDMContactEmailForSetUpPP(ChorRequest chorRequest, ChorResponse chorResponse, String legalEntityId,
                                               TargetAccountNumber accountNumber, ContactDto contactDto,
                                               String failureReason, String userName, ChorStateManager chorStateManager) {
        if (chorResponse.isSuccess()) {
            ChorState chorState = chorStateManager.getChorState();
            onPaymentPlanStatusContactAndEmail(chorRequest, chorResponse, legalEntityId, accountNumber, contactDto,
                    chorState.getContactId(), chorState.getEmailReference(), failureReason, userName);
            chorResponse.setStatus(chorStateManager.getStatus());
        } else {
            onPaymentPlanStatusContactAndEmail(chorRequest, chorResponse, legalEntityId, accountNumber, contactDto,
                    PAYMENT_PLAN_CANCEL_FAIL_INSETUP_CONTACT, EMAIL_0189_REQUEST_FAIL, failureReason, userName);
            chorResponse.setStatus(ChorResponse.Status.COMPLETED_PP_FAIL);
        }
    }

    private void setUpDMContactEmailForCancelPP(ChorRequest chorRequest, ChorResponse chorResponse, String legalEntityId,
                                                TargetAccountNumber accountNumber, ContactDto contactDto,
                                                String failureReason, String userName, ChorStateManager chorStateManager) {
        if (chorResponse.isSuccess()) {
            if (chorStateManager.getChorState() == ChorState.CANCEL_PAYMENT_PLAN_FAILED) {
                onPaymentPlanStatusContactAndEmail(chorRequest, chorResponse, legalEntityId, accountNumber, contactDto,
                        PAYMENT_PLAN_CANCEL_FAIL_CONTACT, EMAIL_1810_REQUEST_SUCCESS, failureReason, userName);
                chorResponse.setStatus(chorStateManager.getStatus());
            }
            if (chorStateManager.getChorState() == ChorState.CANCEL_PAYMENT_PLAN_COMPLETED) {
                onPaymentPlanStatusContactAndEmail(chorRequest, chorResponse, legalEntityId, accountNumber, contactDto,
                        PAYMENT_PLAN_CANCEL_CONTACT, EMAIL_0188_REQUEST_SUCCESS, failureReason, userName);
                chorResponse.setStatus(chorStateManager.getStatus());
            }
        } else {
            onPaymentPlanStatusContactAndEmail(chorRequest, chorResponse, legalEntityId, accountNumber, contactDto,
                    PAYMENT_PLAN_CANCEL_FAIL_CONTACT, EMAIL_1810_REQUEST_SUCCESS, failureReason, userName);
            chorResponse.setStatus(ChorResponse.Status.COMPLETED_CANCEL_PP_FAIL);
        }
    }

    private void onPaymentPlanStatusContactAndEmail(ChorRequest chorRequest, ChorResponse response,
                                                    String legalEntityId, TargetAccountNumber accountNumber,
                                                    ContactDto contactDto, String contctNumber,
                                                    String emailNumber, String failureReason, String userName) {
        ContactNotesData contactNotesData = createContactClient.getContactNotesData(accountNumber,
                Long.parseLong(legalEntityId));
        CustomerContact customerContact;
        customerContact = new ScheduledPaymentPlanContactSuccess(chorRequest, response, accountNumber, contactNotesData,
                contctNumber, failureReason, userName, referenceDataService);
        createContactClient.createContact(customerContact);
        sendEmailOnPaymentPlanStatus(chorRequest, response, contactDto, emailNumber, userName);
    }

    private void sendEmailOnPaymentPlanStatus(ChorRequest chorRequest, ChorResponse response, ContactDto contactDto, String emailNumber, String userName) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put("${fullName}", contactDto.getFullName());
        fieldData.put("${four_digits_accNum}", chorRequest.getAccountNumber().getAccountNumberWithCheckDigit());
        if (response.getChorProgressMonitor().getNewPaymentPlan() != null) {
            if (response.getChorProgressMonitor().getNewPaymentPlan().getScheduleFreqCode() != null) {
                fieldData.put("${paymentFrequency}", getFrequencyDescription(uk.co.stwater.targetconnector.client.api.payplan.PaymentPlan.Frequency.of(response.getChorProgressMonitor().getNewPaymentPlan().getScheduleFreqCode()).toString()));
            }
            if (response.getChorProgressMonitor().getNewPaymentPlan().getFacilityCode() != null) {
                fieldData.put("${paymentMethod}", referenceDataService.getRefDataDesc(RefDataType.FACILITY_CODE, response.getChorProgressMonitor().getNewPaymentPlan().getFacilityCode(), userName));
            }
        }
        emailService.mailMergeAndSend(emailNumber, fieldData, chorRequest.getEmailAddress(), contactDto.getAccountNumber(), contactDto.getLeId());
    }

    private String getFrequencyDescription(String fCode) {
        switch (fCode) {
            case "MONTHLY":
                return PAYMENT_FREQUENCY_MONTHLY;
            case "FORTNIGHTLY":
                return PAYMENT_FREQUENCY_FORTNIGHTLY;
            case "WEEKLY":
                return PAYMENT_FREQUENCY_WEEKLY;
            case "FOUR_WEEKLY":
                return PAYMENT_FREQUENCY_FOUR_WEEKLY;
            default:
                return fCode;
        }
    }

}
