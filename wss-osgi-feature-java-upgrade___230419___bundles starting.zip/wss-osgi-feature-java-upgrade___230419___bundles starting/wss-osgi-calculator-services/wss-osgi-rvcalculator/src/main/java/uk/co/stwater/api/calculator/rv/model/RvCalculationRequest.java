package uk.co.stwater.api.calculator.rv.model;

import java.time.LocalDate;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlAdapter;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import uk.co.stwater.api.osgi.model.CalculatorRequest;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class RvCalculationRequest extends CalculatorRequest {

	@XmlElement(required=true)
	private int zone;
	
	@XmlElement(required=true)
	private int rateableValue;
	
	@XmlElement(required=true)
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate startDate;
	
	@XmlElement(required=true)
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate endDate;

	public int getZone() {
		return zone;
	}
	public void setZone(int zone) {
		this.zone = zone;
	}
	public int getRateableValue() {
		return rateableValue;
	}
	public void setRateableValue(int rateableValue) {
		this.rateableValue = rateableValue;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "RvCalculationRequest [zone=" + zone + ", rateableValue=" + rateableValue + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", waterService=" + isWaterService() + ", sewerageService=" + isSewerageService()
				+ ", surfaceWaterService=" + isWaterService() + ", usedWaterService=" + isUsedWaterService() 
				+ ", highwaysDrainageService=" + isHighwaysDrainageService() +"]";
	}
}

class LocalDateAdapter extends XmlAdapter<String, LocalDate> {
    @Override
    public LocalDate unmarshal(String v) throws Exception {
        return LocalDate.parse(v);
    }

    @Override
    public String marshal(LocalDate v) throws Exception {
        return v.toString();
    }
}
