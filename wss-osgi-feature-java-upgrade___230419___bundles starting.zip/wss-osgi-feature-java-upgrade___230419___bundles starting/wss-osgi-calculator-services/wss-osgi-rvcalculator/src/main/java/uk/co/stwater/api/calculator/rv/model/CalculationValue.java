package uk.co.stwater.api.calculator.rv.model;

import java.io.Serializable;

public class CalculationValue implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public static final String WATER_SERVICE = "water"; 
	public static final String SEWERAGE_SERVICE = "sewerage"; 
	public static final String SURFACE_WATER_SERVICE = "surfaceWater"; 
	public static final String USED_WATER_SERVICE = "usedWater";
        public static final String HIGHWAYS_DRAINAGE = "highwaysDrainage"; 
	
	private String service;
	private double value;

	public CalculationValue() {}
	
	public CalculationValue(String service, double value) {
		this.service = service;
		this.value = value;
	}
	
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}

}
