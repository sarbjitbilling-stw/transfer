package uk.co.stwater.api.calculator.rv.dao;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.rv.model.ZoneCharge;
import uk.co.stwater.api.core.dao.AbstractCrudDao;

@OsgiServiceProvider(classes = { ZoneChargeDao.class })
@Transactional
@Named
public class ZoneChargeDaoImpl extends AbstractCrudDao<java.math.BigInteger, ZoneCharge> implements ZoneChargeDao {

	private static final String ZONE = "zone";

    private static final String SUPPLIER_CODE = "supplierCode";

    Logger log = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext(unitName = "wssPersistence-rvc")
	protected EntityManager entityManager;

	public ZoneChargeDaoImpl() {
	}

	public ZoneChargeDaoImpl(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public ZoneCharge findByZone(int zone) {

        log.debug("ZoneChargeDaoImpl findByZone for zone {}", zone);

		CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
		CriteriaQuery<ZoneCharge> criteriaQuery = criteriaBuilder.createQuery(ZoneCharge.class);
		Root<ZoneCharge> adc = criteriaQuery.from(ZoneCharge.class);

		Predicate adcPredicate = criteriaBuilder.equal(adc.get(ZONE), zone);
		Predicate selectPredicate = criteriaBuilder.and(adcPredicate);
		criteriaQuery.where(selectPredicate);

		TypedQuery<ZoneCharge> query = this.entityManager.createQuery(criteriaQuery);

		return query.getSingleResult();
	}

	@Override
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

    @Override
    public ZoneCharge findByZoneAndSupplier(int zone, String supplierCode) {
        log.debug("ZoneChargeDaoImpl findByZone for zone {} and supplier {}", zone, supplierCode);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<ZoneCharge> criteriaQuery = criteriaBuilder.createQuery(ZoneCharge.class);
        Root<ZoneCharge> adc = criteriaQuery.from(ZoneCharge.class);

        Predicate adcPredicate = criteriaBuilder.equal(adc.get(ZONE), zone);
        Predicate supplierPredicate = criteriaBuilder.equal(adc.get(SUPPLIER_CODE), supplierCode);
        
        Predicate selectPredicate = criteriaBuilder.and(adcPredicate, supplierPredicate);
        criteriaQuery.where(selectPredicate);

        TypedQuery<ZoneCharge> query = this.entityManager.createQuery(criteriaQuery);

        return query.getSingleResult();
    }
}
