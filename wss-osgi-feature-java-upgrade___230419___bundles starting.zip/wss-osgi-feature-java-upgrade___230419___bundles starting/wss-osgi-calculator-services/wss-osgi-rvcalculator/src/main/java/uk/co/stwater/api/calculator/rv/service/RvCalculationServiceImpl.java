package uk.co.stwater.api.calculator.rv.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.persistence.NoResultException;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.common.service.CalculatorSuppliersService;
import uk.co.stwater.api.calculator.rv.dao.ZoneChargeDao;
import uk.co.stwater.api.calculator.rv.model.RvCalculation;
import uk.co.stwater.api.calculator.rv.model.CalculationValue;
import uk.co.stwater.api.calculator.rv.model.RvCalculationRequest;
import uk.co.stwater.api.calculator.rv.model.ZoneCharge;
import uk.co.stwater.api.core.service.BaseService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@OsgiServiceProvider(classes = { RvCalculationService.class })
@Named
@Transactional
@Singleton
public class RvCalculationServiceImpl extends BaseService implements RvCalculationService {

	Logger log = LoggerFactory.getLogger(this.getClass());

	private static final int DAYS_IN_YEAR = 365;
	
	// exception error messages and codes
	private static final String INVALID_REQUEST_CODE = "RVCALC001";
	private static final String INVALID_REQUEST_MSG = "Must enter a valid request";
	private static final String INVALID_ZONE_CODE = "RVCALC002";
    private static final String INVALID_ZONE_MSG = "Invalid zone entered";
    private static final String NO_SERVICES_SPECIFIED_CODE = "RVCALC003";
    private static final String NO_SERVICES_SPECIFIED_MSG = "At least 1 service must be specified";
    private static final String INVALID_START_END_DATE_CODE = "RVCALC004";
    private static final String INVALID_START_END_DATE_MSG = "End date is before start date";
    private static final String INVALID_DATES_CODE = "RVCALC005";
    private static final String INVALID_DATES_MSG = "Too long between start and end date";
    private static final String ZONE_CHARGES_NOT_FOUND_CODE = "RVCALC006";
    private static final String ZONE_CHARGES_NOT_FOUND_MSG = "Zone charges not found";
    private static final String CANNOT_CALCULATE_NOT_FOUND_CODE = "RVCALC007";
    private static final String CANNOT_CALCULATE_MSG = "Cannot calculate for specified services/suppliers";

    private static final String RV_WORKS_FIELD = "rvWorks";

	@Inject
	private ZoneChargeDao zoneChargeDao;

	@OsgiService
    @Inject
    private CalculatorSuppliersService calculatorSuppliersService;
	
	public RvCalculationServiceImpl() {

	}

	@Override
	public void init() {
		super.init();
	}

	@Override
	public RvCalculation calculate(RvCalculationRequest rvCalculationRequest) throws ServiceException {
        log.debug("calculating for {}", rvCalculationRequest);
		
		//Validation
		if (rvCalculationRequest==null) {
		    throw new STWBusinessException(INVALID_REQUEST_MSG, INVALID_REQUEST_CODE, ErrorCategory.RV_CALCULATOR);
		}
		if (rvCalculationRequest.getZone()<=0) {
		    throw new STWBusinessException(INVALID_ZONE_MSG, INVALID_ZONE_CODE, ErrorCategory.RV_CALCULATOR);
		}
		if (!rvCalculationRequest.isUsedWaterService()
				&& !rvCalculationRequest.isSewerageService()
				&& !rvCalculationRequest.isSurfaceWaterService()
				&& !rvCalculationRequest.isWaterService()) {
		    throw new STWBusinessException(NO_SERVICES_SPECIFIED_MSG, NO_SERVICES_SPECIFIED_CODE, ErrorCategory.RV_CALCULATOR);
		}
		LocalDate startDate = rvCalculationRequest.getStartDate();
		LocalDate endDate = rvCalculationRequest.getEndDate();
		if (startDate.isAfter(endDate) || startDate.isEqual(endDate)) {
		    throw new STWBusinessException(INVALID_START_END_DATE_MSG, INVALID_START_END_DATE_CODE, ErrorCategory.RV_CALCULATOR);
		}
		
        if (!calculatorSuppliersService.canCalculateAllSuppliers(rvCalculationRequest, RV_WORKS_FIELD)) {
            throw new STWBusinessException(CANNOT_CALCULATE_MSG, CANNOT_CALCULATE_NOT_FOUND_CODE,
                    ErrorCategory.RV_CALCULATOR);
        }
		
		RvCalculation rvCalculation = new RvCalculation();
		
		//Calculate number of days between start and end
		long daysBetween = ChronoUnit.DAYS.between(startDate,endDate);
		if (daysBetween > Integer.MAX_VALUE) {
		    throw new STWBusinessException(INVALID_DATES_MSG, INVALID_DATES_CODE, ErrorCategory.RV_CALCULATOR);
		}
		
		int numberOfDays = (int) daysBetween;
		rvCalculation.setNumberOfDays(numberOfDays);
		
		//Get rateable value
		int rateableValue = rvCalculationRequest.getRateableValue();

		//Calculate annualWaterAmount - all values rounded to zero DP
        //all these values are rounded to nearest pound, and am currently assuming UI will format with £ sign
        //and .00 pence or however they want to see it...
		//Add the calculated elements for the supplied waterservices to the response object
		Set<CalculationValue> calculation = new LinkedHashSet<>();
		double annualTotal = 0.00D;
		double proratedTotal = 0.00D;

		ZoneCharge zoneCharge;
		
		if(rvCalculationRequest.isWaterService()) {
            zoneCharge = getZoneChargeByZoneAndSupplier(rvCalculationRequest.getZone(),
                    rvCalculationRequest.getWaterSupplier());
            double waterChargePence = zoneCharge.getUnmeasuredWaterPence();
            double annualWaterAmount = (rateableValue * waterChargePence) / 100;

            // verify against minimum charge
            if (annualWaterAmount < zoneCharge.getMinimumWaterChargePence()) {
                annualWaterAmount = zoneCharge.getMinimumWaterChargePence();
            }

            rvCalculation.setAnnualWaterAmount(round(annualWaterAmount, 0));

            // compare to min charge
            double proratedChargeForService = (annualWaterAmount / DAYS_IN_YEAR) * numberOfDays;
            calculation.add(new CalculationValue(CalculationValue.WATER_SERVICE, proratedChargeForService));
            proratedTotal = proratedTotal + proratedChargeForService;
            annualTotal = annualTotal + annualWaterAmount;
            
            double annualWaterStandingCharge = zoneCharge.getAnnualStandingPence();
            annualTotal = annualTotal + annualWaterStandingCharge;
        }
        if (rvCalculationRequest.isSewerageService()) {
            zoneCharge = getZoneChargeByZoneAndSupplier(rvCalculationRequest.getZone(),
                    rvCalculationRequest.getSewerageSupplier());
            double fullSewerageChargePence = zoneCharge.getFullUnmeasuredSeweragePence();
            double annualSewerageAmount = (rateableValue * fullSewerageChargePence) / 100;
            rvCalculation.setAnnualSewerageAmount(round(annualSewerageAmount, 0));

            double proratedChargeForService = (annualSewerageAmount / DAYS_IN_YEAR) * numberOfDays;
            calculation.add(new CalculationValue(CalculationValue.SEWERAGE_SERVICE, proratedChargeForService));
            proratedTotal = proratedTotal + proratedChargeForService;
            annualTotal = annualTotal + annualSewerageAmount;
            
            double annualWasteStandingCharge = zoneCharge.getAnnualStandingWaste();
            annualTotal = annualTotal + annualWasteStandingCharge;
        }
        if (rvCalculationRequest.isSurfaceWaterService()) {
            zoneCharge = getZoneChargeByZoneAndSupplier(rvCalculationRequest.getZone(),
                    rvCalculationRequest.getSurfaceWaterSupplier());
            double propertySurfaceWaterPence = zoneCharge.getPropertySurfaceWaterPence();
            double annualDrainageAmount = (rateableValue * propertySurfaceWaterPence) / 100;
            rvCalculation.setAnnualDrainageAmount(round(annualDrainageAmount, 0));

            double proratedChargeForService = (annualDrainageAmount / DAYS_IN_YEAR) * numberOfDays;
            calculation.add(new CalculationValue(CalculationValue.SURFACE_WATER_SERVICE, proratedChargeForService));
            proratedTotal = proratedTotal + proratedChargeForService;
            annualTotal = annualTotal + annualDrainageAmount;
        }
        if (rvCalculationRequest.isUsedWaterService()) {
            zoneCharge = getZoneChargeByZoneAndSupplier(rvCalculationRequest.getZone(),
                    rvCalculationRequest.getUsedWaterSupplier());
            double usedWaterPence = zoneCharge.getUsedWaterPence();
            double annualUsedWaterAmount = (rateableValue * usedWaterPence) / 100;
            rvCalculation.setAnnualUsedWaterAmount(round(annualUsedWaterAmount, 0));

            double proratedChargeForService = (annualUsedWaterAmount / DAYS_IN_YEAR) * numberOfDays;
            calculation.add(new CalculationValue(CalculationValue.USED_WATER_SERVICE, proratedChargeForService));
            proratedTotal = proratedTotal + proratedChargeForService;
            annualTotal = annualTotal + annualUsedWaterAmount;
        }

        if (rvCalculationRequest.isHighwaysDrainageService()) {
            zoneCharge = getZoneChargeByZoneAndSupplier(rvCalculationRequest.getZone(),
                    rvCalculationRequest.getHighwayDrainageSupplier());
            double annualHighwaysDrainageCharge = zoneCharge.getHighwaysDrainagePence();
            annualTotal = annualTotal + annualHighwaysDrainageCharge;
            // add the highways drainage charge to calculation without prorata calculation
            calculation.add(new CalculationValue(CalculationValue.HIGHWAYS_DRAINAGE, annualHighwaysDrainageCharge));
            proratedTotal = proratedTotal + annualHighwaysDrainageCharge;
        }
            
		//Add the total for all the waterservices
        rvCalculation.setTotal(round(annualTotal, 2));

		//Calculate prorated values of the total
		double prorated = round(proratedTotal,2);
		rvCalculation.setProrated(prorated);

        double proratedRounded = round(proratedTotal, 0);
		rvCalculation.setProratedRounded(proratedRounded);

        // round all calculation value to 0dp
        for (CalculationValue calculationValue : calculation) {
            double roundedAmount = round(calculationValue.getValue(), 2);
            calculationValue.setValue(roundedAmount);
        }
			
		rvCalculation.setCalculation(calculation);
		
		return rvCalculation;
	}

    private ZoneCharge getZoneChargeByZoneAndSupplier(int zone, String supplier) {
        try {
            return zoneChargeDao.findByZoneAndSupplier(zone, supplier);
        } catch (NoResultException e) {
            log.warn("Zone charges not found for zone {} and supplier {} so unable to complete RV calculation", zone, supplier, e);
            throw new STWBusinessException(ZONE_CHARGES_NOT_FOUND_MSG, ZONE_CHARGES_NOT_FOUND_CODE,
                    ErrorCategory.RV_CALCULATOR);
        }
    }	
	
	private double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		long factor = (long) Math.pow(10, places);
		value = value * factor;
		long tmp = Math.round(value);
		return (double) tmp / factor;
	}
}
