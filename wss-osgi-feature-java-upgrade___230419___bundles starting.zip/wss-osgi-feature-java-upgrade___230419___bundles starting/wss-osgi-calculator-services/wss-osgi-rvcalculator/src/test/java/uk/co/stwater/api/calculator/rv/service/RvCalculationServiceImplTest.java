package uk.co.stwater.api.calculator.rv.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.time.LocalDate;

import javax.persistence.NoResultException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.calculator.common.service.CalculatorSuppliersService;
import uk.co.stwater.api.calculator.rv.dao.ZoneChargeDao;
import uk.co.stwater.api.calculator.rv.model.RvCalculation;
import uk.co.stwater.api.calculator.rv.model.CalculationValue;
import uk.co.stwater.api.calculator.rv.model.RvCalculationRequest;
import uk.co.stwater.api.calculator.rv.model.ZoneCharge;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RvCalculationServiceImplTest {

    private static final String CALC_TYPE = "rvWorks";

    @Mock
    private ZoneChargeDao zoneChargeDao;
    
    @Mock
    private CalculatorSuppliersService calculatorSuppliersService;
    
    @InjectMocks
    private RvCalculationService service = new RvCalculationServiceImpl();

    RvCalculationRequest request;
    
    @Before
    public void setUp() throws Exception {
        request = new RvCalculationRequest();
        setRequestSupplierDefaults(request, "1");
        
        Mockito.when(zoneChargeDao.findByZone(0)).thenReturn(getTestZoneCharge(0));
        for(int i=0;i<24;i++) {
            Mockito.when(zoneChargeDao.findByZoneAndSupplier(i, "1")).thenReturn(getTestZoneCharge(i));
        }
        
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithNoRequestShouldFail() throws Exception {
        service.calculate(null);
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithEmptyRequestShouldFail() throws Exception {
        service.calculate(request);
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithNegativeZoneShouldFail() throws Exception {
        request.setZone(-1);
        service.calculate(request);
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithInvalidZoneShouldFail() throws Exception {
        request.setZone(3646537);
        service.calculate(request);
        request.setZone(0);
        service.calculate(request);
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithZeroZoneShouldFail() throws Exception {
        request.setZone(0);
        service.calculate(request);
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithWrongStartEndDatesShouldFail() throws Exception {
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2017-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-01"));
        service.calculate(request);
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithNoServicesShouldFail() throws Exception {
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-02"));
        service.calculate(request);
    }
    
    @Test(expected = STWBusinessException.class)
    public void calculateWithInvalidSupplierCalculation() throws Exception {
        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true); // supplied waterservices: water only, all other waterservices default to false
        
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(false);
        
        service.calculate(request);
    }
    
    @Test
    public void calculateBasicHappyPath() throws Exception {
        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true); // supplied waterservices: water only, all other waterservices default to false

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D); // should be 5p * 500 / 100
        assertEquals(30.00, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                       // supplied)
        assertEquals(0.68, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                         // multiply by days
        assertEquals(1.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.68, value.getValue(), 0.00D);
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
        });
    }

    @Test
    public void calculateHappyPathWithAllServices() throws Exception {

        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true);
        request.setSewerageService(true);
        request.setSurfaceWaterService(true);
        request.setUsedWaterService(true);
        request.setHighwaysDrainageService(true);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D); // should be 500 * 5p / 100
        assertEquals(391.00, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                        // supplied)
        assertEquals(15.27, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(15.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.68, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                assertEquals(2.74, value.getValue(), 0.00D); // should be 500 * 20p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    @Test
    public void calculateHappyPathWithAllServicesExceptHighwaysDrainage() throws Exception {

        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true);
        request.setWaterSupplier("1");
        request.setSewerageService(true);
        request.setSewerageSupplier("1");
        request.setSurfaceWaterService(true);
        request.setSurfaceWaterSupplier("1");
        request.setUsedWaterService(true);
        request.setUsedWaterSupplier("1");
        request.setHighwaysDrainageService(false);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D);
        assertEquals(386.00, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                        // supplied)
        assertEquals(10.27, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(10.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.68, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                assertEquals(2.74, value.getValue(), 0.00D); // should be 500 * 20p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    @Test
    public void calculateHappyPathWithAllServicesExceptHighwaysDrainageZone21Defect4305() throws Exception {

        request.setRateableValue(86);
        request.setZone(21);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true);
        request.setWaterSupplier("1");
        request.setSewerageService(true);
        request.setSewerageSupplier("1");
        request.setSurfaceWaterService(true);
        request.setSurfaceWaterSupplier("1");
        request.setUsedWaterService(true);
        request.setUsedWaterSupplier("1");
        request.setHighwaysDrainageService(false);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(102.00, result.getAnnualWaterAmount(), 0.00D);
        assertEquals(321.22, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                        // supplied)
        assertEquals(8.64, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(9.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(2.79, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(2.90, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                assertEquals(0.89, value.getValue(), 0.00D); // should be 500 * 20p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(2.05, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    
    @Test
    public void calculateHappyPathWithAllServicesExceptFreshWater() throws Exception {

        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(false);
        request.setWaterSupplier("1");
        request.setSewerageService(true);
        request.setSewerageSupplier("1");
        request.setSurfaceWaterService(true);
        request.setSurfaceWaterSupplier("1");
        request.setUsedWaterService(true);
        request.setUsedWaterSupplier("1");
        request.setHighwaysDrainageService(true);
        request.setHighwayDrainageSupplier("1");

        ZoneCharge zoneCharge = getTestZoneCharge();

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        Mockito.when(zoneChargeDao.findByZoneAndSupplier(1, "1")).thenReturn(zoneCharge);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(0.00, result.getAnnualWaterAmount(), 0.00D);
        assertEquals(361.00, result.getTotal(), 0.00D); // total of waste services, no fresh
        assertEquals(14.59, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(15.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                assertEquals(2.74, value.getValue(), 0.00D); // should be 500 * 20p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    @Test
    public void calculateHappyPathWithAllServicesExceptSurfaceWater() throws Exception {

        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        
        setRequestSupplierDefaults(request, "1");
        
        request.setWaterService(true);
        request.setSewerageService(true);
        request.setSurfaceWaterService(false);
        request.setSurfaceWaterSupplier(null);
        request.setUsedWaterService(true);
        request.setHighwaysDrainageService(true);
        
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D);
        assertEquals(291.00, result.getTotal(), 0.00D); // total of waste services, no fresh
        assertEquals(12.53, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(13.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.68, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    @Test
    public void calculateWithAllServicesAndZone8() throws Exception {

        request.setRateableValue(500);
        request.setZone(8);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        
        setRequestSupplierDefaults(request, "6");
        
        request.setWaterService(true);
        request.setSewerageService(true);
        request.setSurfaceWaterService(false);
        request.setSurfaceWaterSupplier(null);
        request.setUsedWaterService(true);
        request.setHighwaysDrainageService(true);
        
        ZoneCharge zoneCharge = getTestZoneCharge();

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        Mockito.when(zoneChargeDao.findByZoneAndSupplier(8, "6")).thenReturn(zoneCharge);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D);
        assertEquals(291.00, result.getTotal(), 0.00D); // total of waste services, no fresh
        assertEquals(12.53, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(13.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.68, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    @Test(expected = STWBusinessException.class)
    public void calculateWithAllServicesZone8IncompatibleSupplier() throws Exception {

        request.setRateableValue(500);
        request.setZone(8);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        
        setRequestSupplierDefaults(request, "6");
        
        request.setWaterService(true);
        request.setSewerageService(true);
        request.setSurfaceWaterService(false);
        request.setSurfaceWaterSupplier(null);
        request.setUsedWaterService(true);
        request.setHighwaysDrainageService(true);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        Mockito.when(zoneChargeDao.findByZoneAndSupplier(8, "6")).thenThrow(NoResultException.class);
        
        RvCalculation result = service.calculate(request);
    }
    
    // Data used in the worked example in
    // https://tracking.keytree.net/browse/SCBIP-343
    @Test
    public void calculateHappyPathAsInTheWorkedExampleInTheStory() throws Exception {
        request.setRateableValue(192);
        request.setZone(5);
        request.setStartDate(LocalDate.parse("2017-02-09"));
        request.setEndDate(LocalDate.parse("2017-07-09")); // i.e. 150 days
        request.setWaterService(true); // supplied waterservices: water
        request.setSewerageService(true); // supplied waterservices: sewerage

        // Mock DB result:
        ZoneCharge zoneCharge = new ZoneCharge();
        zoneCharge.setZone(5);
        zoneCharge.setUnmeasuredWaterPence(114.31D);
        zoneCharge.setFullUnmeasuredSeweragePence(117.01D);
        zoneCharge.setPropertySurfaceWaterPence(20.00D); // irrelevant, not used
        zoneCharge.setUsedWaterPence(40.00D); // irrelevant, not used
        zoneCharge.setAnnualStandingWaste(6.0);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        Mockito.when(zoneChargeDao.findByZoneAndSupplier(5, "1")).thenReturn(zoneCharge);
        
        RvCalculation result = service.calculate(request);
        assertEquals(150, result.getNumberOfDays());
        //assertEquals(219.00, result.getAnnualWaterAmount(), 0.00D); // should be 114.31p * 192 / 100, rounded to £
        assertEquals(225.00, result.getAnnualSewerageAmount(), 0.00D); // should be 117.01p * 192 / 100, rounded to £
        assertEquals(450.13, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                        // supplied)
        assertEquals(182.52, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by
                                                           // 365, multiply by days
        assertEquals(183.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                  // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(90.2, value.getValue(), 0.00D);
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(92.33, value.getValue(), 0.00D);
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                fail("Result calculation should not contain a value for this service");
            }
        });
    }

    
    @Test
    public void calculateHappyPathWithAllServicesUseMinimumCharge() throws Exception {

        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true);
        request.setSewerageService(true);
        request.setSurfaceWaterService(true);
        request.setUsedWaterService(true);
        request.setHighwaysDrainageService(true);

        ZoneCharge zoneCharge = getTestZoneCharge();
        zoneCharge.setMinimumWaterChargePence(25.01);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        Mockito.when(zoneChargeDao.findByZoneAndSupplier(1, "1")).thenReturn(zoneCharge);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D); // should be 500 * 5p / 100
        assertEquals(391.01, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                        // supplied)
        assertEquals(15.27, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(15.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.69, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                assertEquals(2.74, value.getValue(), 0.00D); // should be 500 * 20p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }

    @Test
    public void calculateHappyPathWithAllServicesDontUseMinimumCharge() throws Exception {

        request.setRateableValue(500);
        request.setZone(1);
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days
        request.setWaterService(true);
        request.setSewerageService(true);
        request.setSurfaceWaterService(true);
        request.setUsedWaterService(true);
        request.setHighwaysDrainageService(true);

        ZoneCharge zoneCharge = getTestZoneCharge();
        zoneCharge.setMinimumWaterChargePence(24.99);

        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        Mockito.when(zoneChargeDao.findByZoneAndSupplier(1, "1")).thenReturn(zoneCharge);
        
        RvCalculation result = service.calculate(request);
        assertEquals(10, result.getNumberOfDays());
        assertEquals(25.00, result.getAnnualWaterAmount(), 0.00D); // should be 500 * 5p / 100
        assertEquals(391.00, result.getTotal(), 0.00D); // total of all waterservices (but there's only one service
                                                        // supplied)
        assertEquals(15.27, result.getProrated(), 0.00D); // prorated for 10 days, for one service - i.e. divide by 365,
                                                          // multiply by days
        assertEquals(15.00, result.getProratedRounded(), 0.00D); // prorated for 10 days, for one service, rounded to
                                                                 // nearest £
        result.getCalculation().forEach(value -> {
            if (value.getService().equals(CalculationValue.WATER_SERVICE)) {
                assertEquals(0.68, value.getValue(), 0.00D); // should be 500 * 5p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SEWERAGE_SERVICE)) {
                assertEquals(1.37, value.getValue(), 0.00D); // should be 500 * 10p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.SURFACE_WATER_SERVICE)) {
                assertEquals(2.74, value.getValue(), 0.00D); // should be 500 * 20p / 100 prorated
            }
            if (value.getService().equals(CalculationValue.USED_WATER_SERVICE)) {
                assertEquals(5.48, value.getValue(), 0.00D); // should be 500 * 40p / 100 prorated
            }
        });
    }
    
    private ZoneCharge getTestZoneCharge() {
        // Test data: Zone 1, water=5p, sewerage=10p, surfaceWater=20p, usedWater=40p
        // Rateable value=500, numberOfDays=10
        ZoneCharge zoneCharge = new ZoneCharge();
        zoneCharge.setZone(1);
        zoneCharge.setUnmeasuredWaterPence(5.00D);
        zoneCharge.setFullUnmeasuredSeweragePence(10.00D);
        zoneCharge.setPropertySurfaceWaterPence(20.00D);
        zoneCharge.setUsedWaterPence(40.00D);
        zoneCharge.setHighwaysDrainagePence(5.00D);
        zoneCharge.setAnnualStandingPence(5.00D);
        zoneCharge.setAnnualStandingWaste(6.0);
        return zoneCharge;
    }
    
    private ZoneCharge getTestZoneCharge(int zoneNum) {
        // Test data: Zone 1, water=5p, sewerage=10p, surfaceWater=20p, usedWater=40p
        // Rateable value=500, numberOfDays=10
        ZoneCharge zoneCharge = new ZoneCharge();
        
        if(zoneNum==21) {
            zoneCharge.setZone(zoneNum);
            zoneCharge.setUnmeasuredWaterPence(109.12D);
            zoneCharge.setFullUnmeasuredSeweragePence(123.25D);
            zoneCharge.setPropertySurfaceWaterPence(37.66D);
            zoneCharge.setUsedWaterPence(87.21D);
            zoneCharge.setHighwaysDrainagePence(0.00D);
            zoneCharge.setAnnualStandingPence(0.00D);
            //zoneCharge.setMinimumWaterChargePence(100.94D);
            zoneCharge.setMinimumWaterChargePence(101.84D);
            zoneCharge.setAnnualStandingWaste(6.0);
        }
        else {
            zoneCharge.setZone(zoneNum);
            zoneCharge.setUnmeasuredWaterPence(5.00D);
            zoneCharge.setFullUnmeasuredSeweragePence(10.00D);
            zoneCharge.setPropertySurfaceWaterPence(20.00D);
            zoneCharge.setUsedWaterPence(40.00D);
            zoneCharge.setHighwaysDrainagePence(5.00D);
            zoneCharge.setAnnualStandingPence(5.00D);
            zoneCharge.setAnnualStandingWaste(6.0);
        }
        return zoneCharge;
    }

    private void setRequestSupplierDefaults(RvCalculationRequest request, String defaultSupplier) {
        request.setWaterSupplier(defaultSupplier);
        request.setSewerageSupplier(defaultSupplier);
        request.setSurfaceWaterSupplier(defaultSupplier);
        request.setUsedWaterSupplier(defaultSupplier);
        request.setHighwayDrainageSupplier(defaultSupplier);
    }
}