package uk.co.stwater.api.calculator.bds;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.common.util.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorRequest;
import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorResponse;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.iib.client.api.offers.OffersTargetService;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;

@Path("/calculation")
@Named("bdsCalculatorResource")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BdsCalculatorResource extends AbstractResource {
    private static final Logger LOG = LoggerFactory.getLogger(BdsCalculatorResource.class);

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient targetAccountPropertiesClient;

    @Inject
    @OsgiService
    private OffersTargetService offersTargetService;

    @Inject
    private BdsCalculatorService bdsCalculatorService;

    @POST
    public Response calculatePlanAmount(BdsPlanAmountCalculatorRequest calculatorRequest) {
        if (calculatorRequest == null) {
            throw new BdsCalculationException("calculatorRequest body is required");
        }

        if (calculatorRequest.getRequest() != null) {
            throw new BdsCalculationException("request field must not be specified");
        }

        if (calculatorRequest.hasCalculationInformation()) {
            verifyPlanAmountRequest(calculatorRequest);
            return handlePlanAmountCalculation(calculatorRequest);
        } else if (calculatorRequest.getLegalEntity() != null && calculatorRequest.getAccountNumber() != null) {
            return handlePlanAmountDefaults(calculatorRequest);
        } else {
            throw new BdsCalculationException("Missing fields for calculation and for calculating defaults");
        }
    }

    private Response handlePlanAmountDefaults(BdsPlanAmountCalculatorRequest calculatorRequest) {
        LOG.debug("Calculating BDS plan amount calculation defaults for legalEntity={} accountNumber={}",
                calculatorRequest.getLegalEntity(), calculatorRequest.getAccountNumber());
        BdsPlanAmountCalculatorRequest entity = new BdsPlanAmountCalculatorRequest(calculatorRequest);
        entity.setRequest(calculatorRequest);

        if (entity.getInArrears() == null) {
            boolean inArrears = offersTargetService.isAccountInArrears(calculatorRequest.getAccountNumber(), null);
            entity.setInArrears(inArrears);
        }

        return Response.ok(entity).build();
    }

    void verifyPlanAmountRequest(BdsPlanAmountCalculatorRequest calculatorRequest) {
        if (calculatorRequest.getBdsPlanRegion() == null) {
            throw new BdsCalculationException("bdsPlanRegion field is required");
        }
        if (calculatorRequest.getInArrears() == null) {
            throw new BdsCalculationException("inArrears field is required");
        }
        if (StringUtils.isEmpty(calculatorRequest.getBand())) {
            throw new BdsCalculationException("band field is required");
        }
        if (calculatorRequest.getMonthsLeft() == null) {
            throw new BdsCalculationException("monthsLeft field is required");
        }
        if (calculatorRequest.getPaidToDate() == null) {
            throw new BdsCalculationException("paidToDate field is required");
        }
        if (calculatorRequest.getPaidToDate().signum() < 0) {
            throw new BdsCalculationException("paidToDate field must not be negative");
        }
    }

    private Response handlePlanAmountCalculation(BdsPlanAmountCalculatorRequest calculatorRequest) {
        LOG.debug("Calculating BDS payment plan amount");
        BdsPlanAmountCalculatorResponse entity = bdsCalculatorService.calculatePlanAmounts(calculatorRequest);

        return Response.ok(entity).build();
    }
}
