package uk.co.stwater.api.calculator.bds.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Test;

import uk.co.stwater.api.dao.entity.BdsPlanRegion;

public class BdsPlanAmountCalculatorRequestTest {

    @Test
    public void hasCalculationInformationAllRequiredFields() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();

        assertTrue(request.hasCalculationInformation());
    }

    @Test
    public void hasCalculationInformationNullPlanType() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setBdsPlanRegion(null);

        assertFalse(request.hasCalculationInformation());
    }

    @Test
    public void hasCalculationInformationNullInArrears() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setInArrears(null);

        assertFalse(request.hasCalculationInformation());
    }

    @Test
    public void hasCalculationInformationNullBand() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setBand(null);

        assertFalse(request.hasCalculationInformation());
    }

    @Test
    public void hasCalculationInformationNullPaidToDate() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setPaidToDate(null);

        assertFalse(request.hasCalculationInformation());
    }

    @Test
    public void hasCalculationInformationNullMonthsLeft() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setMonthsLeft(null);

        assertFalse(request.hasCalculationInformation());
    }

    private BdsPlanAmountCalculatorRequest buildBdsPlanAmountCalculatorRequest() {
        BdsPlanAmountCalculatorRequest request = new BdsPlanAmountCalculatorRequest();

        request.setBand("3");
        request.setBdsPlanRegion(BdsPlanRegion.DVW_CHESTER_WREXHAM);
        request.setInArrears(false);
        request.setMonthsLeft(6);
        request.setPaidToDate(BigDecimal.ZERO);

        return request;
    }

}
