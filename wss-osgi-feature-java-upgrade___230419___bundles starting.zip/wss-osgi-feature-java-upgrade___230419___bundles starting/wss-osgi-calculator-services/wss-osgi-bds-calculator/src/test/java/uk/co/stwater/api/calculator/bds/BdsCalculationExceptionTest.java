package uk.co.stwater.api.calculator.bds;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;

public class BdsCalculationExceptionTest {

    private static final String EXCEPTION_MESSAGE = "Sample BDS exception message";

    @Test
    public void constructorMessageDefaultValues() {
        BdsCalculationException e = new BdsCalculationException(EXCEPTION_MESSAGE);

        validatedSapPiClientException(e);
    }

    @Test
    public void constructorMessageExceptionDefaultValues() {
        BdsCalculationException e = new BdsCalculationException(EXCEPTION_MESSAGE, new Exception());

        validatedSapPiClientException(e);
    }

    @Test
    public void constructorMessageErrorCodeDefaultValues() {
        String errorCode = "BDS_000";
        BdsCalculationException e = new BdsCalculationException(errorCode, EXCEPTION_MESSAGE);

        validatedBdsException(e, errorCode);
    }

    @Test
    public void constructorMessageErrorCodeExceptionDefaultValues() {
        String errorCode = "BDS_778";
        BdsCalculationException e = new BdsCalculationException(errorCode, EXCEPTION_MESSAGE, new Exception());

        validatedBdsException(e, errorCode);
    }

    private void validatedSapPiClientException(BdsCalculationException e) {
        validatedBdsException(e, BdsCalculationException.DEFAULT_ERROR_CODE);
    }

    private void validatedBdsException(BdsCalculationException e, String errorCode) {
        assertEquals(EXCEPTION_MESSAGE, e.getMessage());
        assertEquals(ErrorCategory.BDS_CALCULATOR.toString(), e.getErrorCategory());
        assertEquals(errorCode, e.getErrorCode());
    }

}
