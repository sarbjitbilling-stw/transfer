package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.math.BigDecimal;
import java.util.Date;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

public class TestAccountSummary implements AccountSummaryResponse {

	private BigDecimal accountBalanace;

	private TargetAccountNumber accountNumber;
	
	private boolean paperless;
	
	private Date lastPaymentDate;

	@Override
	public BigDecimal getAccountBalance() {
		return accountBalanace;
	}

	@Override
	public TargetAccountNumber getAccountNumber() {

		return accountNumber;
	}

	@Override
	public String getAccountStatus() {
		return null;
	}

	@Override
	public String getBillPrintMedium() {
		return null;
	}

	@Override
	public BigDecimal getCurrentAmountDue() {
		return null;
	}

	@Override
	public BigDecimal getLastInvoiceAmount() {
		
		return null;
	}

	@Override
	public Date getLastInvoiceDueDate() {
		
		return null;
	}

	@Override
	public Date getLastInvoiceIssueDate() {
		
		return null;
	}

	@Override
	public BigDecimal getLastPaymentAmount() {
		
		return null;
	}

	@Override
	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}

	@Override
	public Long getPropertyNum() {
		
		return null;
	}

	@Override
	public boolean hasDemandDirectDebit() {
		return false;
	}

	@Override
	public boolean isIsDirectSpecialConditionSet() {
		
		return false;
	}

	@Override
	public boolean hasAmiMeterFlag() {
		return false;
	}

	@Override
	public boolean isIsPaperless() {
		return paperless;
	}

	@Override
	public boolean isIsPostClaimFlag() {
		
		return false;
	}

	@Override
	public void setAccountBalance(BigDecimal bal) {
		this.accountBalanace = bal;

	}

	@Override
	public void setAccountStatus(String arg0) {
		

	}

	@Override
	public void setBillPrintMedium(String arg0) {
		

	}

	@Override
	public void setCurrentAmountDue(BigDecimal arg0) {
		

	}

	@Override
	public void setIsDirectSpecialConditionSet(boolean arg0) {
		

	}

	@Override
	public void setIsPaperless(boolean paperless) {
		this.paperless = paperless;

	}

	@Override
	public void setIsPostClaimFlag(boolean arg0) {
		

	}

	@Override
	public void setLastInvoiceAmount(BigDecimal arg0) {
		

	}

	@Override
	public void setLastInvoiceDueDate(Date arg0) {
		

	}

	@Override
	public void setLastInvoiceIssueDate(Date arg0) {
		

	}

	@Override
	public void setLastPaymentAmount(BigDecimal arg0) {
		

	}

	@Override
	public boolean isPostJudgementFlag() {
		return false;
	}

	@Override
	public boolean isPreClaimFlag() {
		return false;
	}

	@Override
	public boolean isMaxDefaultedPlansFlag() {
		return false;
	}

	@Override
	public void setLastPaymentDate(Date theDate) {
		lastPaymentDate = theDate;

	}

	public void setAccountBalanace(BigDecimal accountBalanace) {
		this.accountBalanace = accountBalanace;
	}

	public void setAccountNumber(TargetAccountNumber accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public boolean isConditionalPayPlanFlag() {
		return false;
	}

	@Override
	public String getPayPlanStatus() {
		return null;
	}

    @Override
    public boolean isOutstandingAQFlag() {
        return false;
    }

    @Override
    public void setOutstandingAQFlag(boolean outstandingAQFlag) {
    }

    @Override
    public Long getOutstandingAQOrg() {
        return null;
    }

    @Override
    public void setOutstandingAQOrg(Long outstandingAQOrg) {
    }

	@Override
	public String getServAddress() {
		return null;
	}
}
