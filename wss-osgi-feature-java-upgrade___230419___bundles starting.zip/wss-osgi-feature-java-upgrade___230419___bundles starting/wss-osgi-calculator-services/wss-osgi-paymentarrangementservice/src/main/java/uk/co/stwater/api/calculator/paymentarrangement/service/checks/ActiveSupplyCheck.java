package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

import java.util.List;
import java.util.Map;

/**
 * Checks to see if there is an active supply to the properties.
 *
 * @author droberts
 */
public class ActiveSupplyCheck implements EligiblityCheck {

    Logger log = LoggerFactory.getLogger(this.getClass());

    private final String ACTIVE_PROPERTY = "A";

    @Override
    public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
                                         List<Property> propertyList, String channel,
                                         Map<String, List<SpecialConditionRestriction>> specialConditionsMap,
                                         CreatePaymentPlanContext ctx) {

        if (null == method) {
            throw new IllegalArgumentException("paymentMethod is a mandatory parameter");
        }

        if (null == propertyList) {
            throw new IllegalArgumentException("propertyList is a mandatory parameter");
        }

        // assume the customer is elidgible until the property status is
        // checked.
        EligibilityStatus status = new EligibilityStatus();
        status.setStatus(EligabilityStatusConstants.ELIGIBLE);

        // first check to see if the payment method is configured as a plan.
        if (method.isPlan()) {

            // Active Property have EndDate = null
            boolean isCurrentOrFutureActivePropertyFound = propertyList.stream()
                    .anyMatch(property -> property.getEndDate() == null
                    );

            if (!isCurrentOrFutureActivePropertyFound && accountSummary.getAccountBalance().signum() < 1) {
                status = new EligibilityStatus();
                status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
                status.setText(EligabilityStatusConstants.ARREARS_PAYMENT_PLAN_NOT_ALLOWED);
            }
        }

        return status;
    }

}
