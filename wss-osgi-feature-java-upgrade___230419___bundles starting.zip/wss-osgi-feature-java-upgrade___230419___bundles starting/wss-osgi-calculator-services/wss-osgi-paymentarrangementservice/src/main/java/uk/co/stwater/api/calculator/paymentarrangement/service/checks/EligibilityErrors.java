package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

public enum EligibilityErrors {
    MULTIPLE_ACTIVE_SUPPLIES_DIFF_TYPES("ELEGI001", "Multiple active supplies with different types");

    private final String code;
    private final String message;

    EligibilityErrors(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
