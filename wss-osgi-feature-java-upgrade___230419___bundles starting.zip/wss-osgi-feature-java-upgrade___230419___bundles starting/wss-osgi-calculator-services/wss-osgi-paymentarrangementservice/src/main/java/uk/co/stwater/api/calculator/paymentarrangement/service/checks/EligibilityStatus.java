package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

public class EligibilityStatus {
	
	private Integer status;
	
	private String text;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
    public boolean isEligibleOrWarning() {
        return EligabilityStatusConstants.ELIGIBLE.equals(status)
                || EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING.equals(status);
    }

    public boolean isEligibleAndNoWarning() {
        return EligabilityStatusConstants.ELIGIBLE.equals(status);
    }

    public boolean isHigherThan(EligibilityStatus status) {
        return this.getStatus() > status.getStatus();
    }
	
    public boolean isHighest() {
        return EligabilityStatusConstants.NOT_ELIGIBLE.equals(this.getStatus());
    }

}
