package uk.co.stwater.api.calculator.paymentarrangement.service;

public interface PaymentMethodTypeConstants {

    String PAPERLESS = "PB";

    String DIRECT_DEBIT = "DD";

    String WATER_CARD_ACTION_CREATE = "C";
    String WATER_CARD_ACTION_REPLACE = "R";

    String PAYMENT_METHOD_WATERCARD = "WC";

    String PAYMENT_FREQUENCY_MONTHLY = "M";

    String PAYMENT_MANDATE_STATUS_ACTIVE = "AC";
    String PAYMENT_MANDATE_STATUS_PENDING = "PE";
    String PAYMENT_MANDATE_STATUS_INACTIVE = "IN";

    String TARGET_ACTION_CODE_UPDATE = "U";
    String TARGET_ACTION_CODE_INSERT = "I";

    String ACTIVE_PROPERTY = "A";

}
