package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.iib.client.api.bill.status.AccountBillStatusClient;
import uk.co.stwater.iib.client.api.bill.status.NextBillStatusResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

/**
 * Used to check that account does not have a property with pending bill
 * triggers.
 * 
 * <p>
 * When all active properties are either {@code Assessed} or {@code Measured}
 * will return status {@code ELIGIBLE}. If the property list contains active
 * {@code Unmeasured} properties will return {@code NOT_ELIGIBLE} if any of them
 * have pending bill triggers otherwise will return {@code ELIGIBLE}.
 */
@Named
public class PendingBillTriggersCheck implements EligiblityCheck {
    private static final Logger LOG = LoggerFactory.getLogger(PendingBillTriggersCheck.class);

    @Inject
    @OsgiService
    private AccountBillStatusClient accountBillStatusClient;

    @Override
    public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
            List<Property> propertyList, String channel,
            Map<String, List<SpecialConditionRestriction>> specialConditions, CreatePaymentPlanContext ctx) {

        if (accountSummary == null) {
            throw new IllegalArgumentException("accountSummary is a required parameter");
        }

        TargetAccountNumber accountNumber = accountSummary.getAccountNumber();

        if (accountNumber == null) {
            throw new IllegalArgumentException("TargetAccountNumer is null");
        }

        EligibilityStatus status = new EligibilityStatus();
        status.setStatus(EligabilityStatusConstants.ELIGIBLE);

        for (Property property : propertyList) {
            if (property.isActive() && property.isUnmeasured()) {
                NextBillStatusResponse nextBillStatus = accountBillStatusClient.getNextBillStatus(accountNumber,
                        property);

                if (nextBillStatus.isOffCycleBillTrigger()) {
                    LOG.debug("Customer has property with a pending bill trigger. accountNumber={}, propertyId={}",
                            accountNumber.getAccountNumber(), property.getPropertyId());
                    status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
                    status.setText(
                            "Customer has a property with a pending bill trigger, bill before creating playment plan");
                    break;
                }
            }
        }

        return status;
    }
}
