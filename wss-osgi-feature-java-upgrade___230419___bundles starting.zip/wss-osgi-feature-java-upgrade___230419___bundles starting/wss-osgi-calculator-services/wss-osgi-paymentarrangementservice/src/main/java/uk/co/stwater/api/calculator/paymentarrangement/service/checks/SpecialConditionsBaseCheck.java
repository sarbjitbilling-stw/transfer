package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionChannel;
import uk.co.stwater.api.specialconditions.SpecialConditionService;

public class SpecialConditionsBaseCheck {

	protected List<SpecialConditionRestriction> getSpecialConditions(SpecialConditionService specialConditionsService,
			Long accountId, Long legalEntityId, String channelName, String actionName) {

            
            
		return specialConditionsService.checkSpecialConditions(
                        new TargetAccountNumber(accountId), 
                        legalEntityId, 
                        StringUtils.EMPTY,
                        SpecialConditionChannel.byName(channelName),
                        SpecialConditionAction.byName(actionName));
	}

}
