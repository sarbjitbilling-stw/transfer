package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTypeConstants;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

public class PaperlessCheck implements EligiblityCheck {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
			List<Property> propertyList, String channel,
			Map<String, List<SpecialConditionRestriction>> specialConditionsMap, CreatePaymentPlanContext ctx) {

		if (null == accountSummary) {
			throw new IllegalArgumentException("accountSummary is a required parameter");
		}

		if (null == method) {
			throw new IllegalArgumentException("paymentMethod is a required parameter");
		}

		EligibilityStatus status = new EligibilityStatus();
		status.setStatus(EligabilityStatusConstants.ELIGIBLE);

		log.debug("isPlan:{}", method.isPlan());
		log.debug("paymentMethodType:{}" , method.getPaymentMethodCode());
		log.debug("isPaperless:{}" , accountSummary.isIsPaperless());

		if (accountSummary.isIsPaperless() && method.isPlan() && method.getPaymentMethodCode() != null
				&& method.getPaymentMethodCode().equalsIgnoreCase(PaymentMethodTypeConstants.PAPERLESS)) {
			status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
			status.setText("Payment Booklet not allowed for Paperless customers");
		}
		return status;
	}

}
