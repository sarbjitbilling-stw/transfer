package uk.co.stwater.api.calculator.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.Month;

import javax.persistence.NoResultException;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.common.service.CalculatorSuppliersService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.dao.entity.AverageDailyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredPropertyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredUsageCharge;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;
import uk.co.stwater.api.osgi.model.calculator.consumption.BudgetType;
import uk.co.stwater.api.osgi.model.calculator.consumption.EstimateRequest;
import uk.co.stwater.api.osgi.model.calculator.consumption.Estimates;
import uk.co.stwater.api.osgi.model.calculator.consumption.OccupantType;
import uk.co.stwater.api.osgi.model.calculator.consumption.ServiceType;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CalculationServiceImplTest {

    EstimateRequest estimateRequest = new EstimateRequest();

    private static final String MEASURED_WORKS_FIELD = "measuredWorks";

    @InjectMocks
    private CalculationServiceImpl calculationService;

    @Mock
    private CalculatorSuppliersService calculatorSupplierService;

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Before
    public void setUp() throws Exception {
        estimateRequest = new EstimateRequest();
        setRequestSupplierDefaults(estimateRequest, "1");
        MockitoAnnotations.initMocks(calculationService);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test(expected = STWBusinessException.class)
    public void testEstimateCanCalculateAllSuppliersInvalid() throws Exception {
        setUpMocks();

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(false);

        calculationService.calculate(estimateRequest);
    }

    @Test
    public void testEstimateWithChildOccupantError() throws Exception {
        setUpMocks();

        estimateRequest.setNumberOfAdultOccupants(1);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.FLAT);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);

        expectedException.expect(ServiceException.class);
        expectedException.expectMessage("No of children not configured in Database");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

        when(calculatorSupplierService.findByNumberOfOccupants(1, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenThrow(new NoResultException());

        calculationService.calculate(estimateRequest);
    }

    @Test
    public void testEstimateWithAdultOccupantError() throws Exception {
        setUpMocks();

        estimateRequest.setNumberOfAdultOccupants(1);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.FLAT);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);

        expectedException.expect(ServiceException.class);
        expectedException.expectMessage("No of Adults Not configured in Database");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

        when(calculatorSupplierService.findByNumberOfOccupants(1, OccupantType.ADULT, BudgetType.LOW))
                .thenThrow(new NoResultException());

        calculationService.calculate(estimateRequest);
    }

    @Test
    public void testEstimateUsageServiceFailure() throws Exception {
        setUpMocks();

        estimateRequest.setNumberOfAdultOccupants(1);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.FLAT);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);

        expectedException.expect(ServiceException.class);
        expectedException.expectMessage("Service Usage unit cost not configured in Database");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

        when(calculatorSupplierService.getMeasuredUsageChargesBySupplier(anyString()))
                .thenThrow(new NoResultException());

        calculationService.calculate(estimateRequest);
    }

    @Test
    public void testEstimatePropertyServiceFailure() throws Exception {
        setUpMocks();

        estimateRequest.setNumberOfAdultOccupants(1);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.FLAT);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);
        estimateRequest.setSurfaceWaterService(true);

        expectedException.expect(ServiceException.class);
        expectedException.expectMessage("Property Type not configured in Database");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty(anyString(),
                any(PropertyType.class)))
                .thenThrow(new NoResultException());

        calculationService.calculate(estimateRequest);
    }

    @Test
    public void testEstimateOneAdultOneChildInFlat() throws Exception {
        setUpMocks();

        estimateRequest.setNumberOfAdultOccupants(1);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.FLAT);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);
        estimateRequest.setWaterSupplier("1");
        estimateRequest.setUsedWaterService(true);
        estimateRequest.setSurfaceWaterService(true);
        estimateRequest.setSurfaceWaterSupplier("1");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

            Estimates estimates = calculationService.calculate(estimateRequest);
            assertEquals("numberOfDays Match", 365, estimates.getNumberOfDays());
            estimates.getUsageBands().forEach(usageBand -> {
                if (usageBand.getType().equals(BudgetType.LOW)) {
                    assertEquals("LOW: Total", 219.89, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("LOW: waterOnly Price", 115.20, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("LOW: Used Price", 71.74, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("LOW: Surface Water Price", 32.95, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

                if (usageBand.getType().equals(BudgetType.AVERAGE)) {
                    assertEquals("AVERAGE: Total", 262.73, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("AVERAGE: waterOnly Price", 140.74, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("AVERAGE: Used Price", 89.04, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("AVERAGE: Surface Water Price", 32.95, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

                if (usageBand.getType().equals(BudgetType.HIGH)) {
                    assertEquals("HIGH: Total", 305.58, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("HIGH: waterOnly Price", 166.29, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("HIGH: Used Price", 106.34, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("HIGH: Surface Water Price", 32.95, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

            });
    }

    @Test
    public void testEstimateTwoAdultOneChildInSemi() throws Exception {
        setUpMocks();
        EstimateRequest estimateRequest = new EstimateRequest();
        estimateRequest.setNumberOfAdultOccupants(2);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.DETACHED);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);
        estimateRequest.setWaterSupplier("2");
        estimateRequest.setUsedWaterService(true);
        estimateRequest.setUsedWaterSupplier("2");
        estimateRequest.setSurfaceWaterService(true);
        estimateRequest.setSurfaceWaterSupplier("2");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

        try {
            Estimates estimates = calculationService.calculate(estimateRequest);
            assertEquals("numberOfDays Match", 365, estimates.getNumberOfDays());
            estimates.getUsageBands().forEach(usageBand -> {
                if (usageBand.getType().equals(BudgetType.LOW)) {
                    assertEquals("LOW: Total", 327.34, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("LOW: waterOnly Price", 166.29, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("LOW: Used Price", 106.34, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("LOW: Surface Water Price", 54.71, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

                if (usageBand.getType().equals(BudgetType.AVERAGE)) {
                    assertEquals("AVERAGE: Total", 413.02, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("AVERAGE: waterOnly Price", 217.38, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("AVERAGE: Used Price", 140.93, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("AVERAGE: Surface Water Price", 54.71, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

                if (usageBand.getType().equals(BudgetType.HIGH)) {
                    assertEquals("HIGH: Total", 498.71, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("HIGH: waterOnly Price", 268.48, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("HIGH: Used Price", 175.52, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("HIGH: Surface Water Price", 54.71, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

            });

        } catch (ServiceException e) {
            log.debug(e.getMessage());
        }

    }

    private void setUpMocks() {

        CalculateMeasuredUsageCharge measUsageChargeSTW = new CalculateMeasuredUsageCharge();

        measUsageChargeSTW.setFwFixedCharge(28.34);
        measUsageChargeSTW.setFwUnitCharge(1.3998);
        measUsageChargeSTW.setHdFixedCharge(5.0);
        measUsageChargeSTW.setHdUnitCharge(0.0);
        measUsageChargeSTW.setUwFixedCharge(12.94);
        measUsageChargeSTW.setUwUnitCharge(0.9477);

        measUsageChargeSTW.setSupplierCode("1");
        measUsageChargeSTW.setSupplierText("STW");

        CalculateMeasuredUsageCharge measUsageChargeChester = new CalculateMeasuredUsageCharge();

        measUsageChargeChester.setFwFixedCharge(28.34);
        measUsageChargeChester.setFwUnitCharge(1.3998);
        measUsageChargeChester.setHdFixedCharge(0.0);
        measUsageChargeChester.setHdUnitCharge(0.0);
        measUsageChargeChester.setUwFixedCharge(12.94);
        measUsageChargeChester.setUwUnitCharge(0.9477);

        measUsageChargeChester.setSupplierCode("2");
        measUsageChargeChester.setSupplierText("Chester");

        CalculateMeasuredUsageCharge measUsageChargePowys = new CalculateMeasuredUsageCharge();

        measUsageChargePowys.setFwFixedCharge(21.0);
        measUsageChargePowys.setFwUnitCharge(1.3998);
        measUsageChargePowys.setHdFixedCharge(5.0);
        measUsageChargePowys.setHdUnitCharge(0.0);
        measUsageChargePowys.setUwFixedCharge(38.97);
        measUsageChargePowys.setUwUnitCharge(1.369);
        
        measUsageChargePowys.setSupplierCode("4");
        measUsageChargePowys.setSupplierText("Powys");
        
        
        CalculateMeasuredPropertyCharge measPropertyChargeSTW_Terrace = new CalculateMeasuredPropertyCharge();

        measPropertyChargeSTW_Terrace.setPropertyDescription(PropertyType.TERRACED);
        measPropertyChargeSTW_Terrace.setSupplierCode("1");
        measPropertyChargeSTW_Terrace.setSupplierText("STW");
        measPropertyChargeSTW_Terrace.setSwdFixedCharge(12.94);

        CalculateMeasuredPropertyCharge measPropertyChargeSTW_Semi = new CalculateMeasuredPropertyCharge();

        measPropertyChargeSTW_Semi.setPropertyDescription(PropertyType.SEMI);
        measPropertyChargeSTW_Semi.setSupplierCode("1");
        measPropertyChargeSTW_Semi.setSupplierText("STW");
        measPropertyChargeSTW_Semi.setSwdFixedCharge(12.94);

        CalculateMeasuredPropertyCharge measPropertyChargeSTW_Flat = new CalculateMeasuredPropertyCharge();

        measPropertyChargeSTW_Flat.setPropertyDescription(PropertyType.FLAT);
        measPropertyChargeSTW_Flat.setSupplierCode("1");
        measPropertyChargeSTW_Flat.setSupplierText("STW");
        measPropertyChargeSTW_Flat.setSwdFixedCharge(32.95);

        CalculateMeasuredPropertyCharge measPropertyChargeChester_Detached = new CalculateMeasuredPropertyCharge();

        measPropertyChargeChester_Detached.setPropertyDescription(PropertyType.DETACHED);
        measPropertyChargeChester_Detached.setSupplierCode("2");
        measPropertyChargeChester_Detached.setSupplierText("Ch");
        measPropertyChargeChester_Detached.setSwdFixedCharge(54.71);

        CalculateMeasuredPropertyCharge measPropertyChargeChester_Flat = new CalculateMeasuredPropertyCharge();

        measPropertyChargeChester_Flat.setPropertyDescription(PropertyType.FLAT);
        measPropertyChargeChester_Flat.setSupplierCode("2");
        measPropertyChargeChester_Flat.setSupplierText("Ch");
        measPropertyChargeChester_Flat.setSwdFixedCharge(12.94);

        CalculateMeasuredPropertyCharge measPropertyChargeChester_Semi = new CalculateMeasuredPropertyCharge();

        measPropertyChargeChester_Semi.setPropertyDescription(PropertyType.SEMI);
        measPropertyChargeChester_Semi.setSupplierCode("4");
        measPropertyChargeChester_Semi.setSupplierText("Ch");
        measPropertyChargeChester_Semi.setSwdFixedCharge(15.86);

        AverageDailyCharge adc_child = new AverageDailyCharge();
        adc_child.setNumberOfOccupants(1);
        adc_child.setOccupantType(OccupantType.CHILD);
        adc_child.setType(BudgetType.AVERAGE);
        adc_child.setValue(0.07);

        AverageDailyCharge adc_child2 = new AverageDailyCharge();
        adc_child2.setNumberOfOccupants(2);
        adc_child2.setOccupantType(OccupantType.CHILD);
        adc_child2.setType(BudgetType.AVERAGE);
        adc_child2.setValue(0.13);

        AverageDailyCharge adc_child3 = new AverageDailyCharge();
        adc_child3.setNumberOfOccupants(3);
        adc_child3.setOccupantType(OccupantType.CHILD);
        adc_child3.setType(BudgetType.AVERAGE);
        adc_child3.setValue(0.20);

        AverageDailyCharge adc_child4 = new AverageDailyCharge();
        adc_child4.setNumberOfOccupants(4);
        adc_child4.setOccupantType(OccupantType.CHILD);
        adc_child4.setType(BudgetType.AVERAGE);
        adc_child4.setValue(0.27);

        AverageDailyCharge adc_child5 = new AverageDailyCharge();
        adc_child5.setNumberOfOccupants(5);
        adc_child5.setOccupantType(OccupantType.CHILD);
        adc_child5.setType(BudgetType.AVERAGE);
        adc_child5.setValue(0.33);

        AverageDailyCharge adc_child6 = new AverageDailyCharge();
        adc_child6.setNumberOfOccupants(6);
        adc_child6.setOccupantType(OccupantType.CHILD);
        adc_child6.setType(BudgetType.AVERAGE);
        adc_child6.setValue(0.40);

        when(calculatorSupplierService.findByNumberOfOccupants(1, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenReturn(adc_child);
        when(calculatorSupplierService.findByNumberOfOccupants(2, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenReturn(adc_child2);
        when(calculatorSupplierService.findByNumberOfOccupants(3, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenReturn(adc_child3);
        when(calculatorSupplierService.findByNumberOfOccupants(4, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenReturn(adc_child4);
        when(calculatorSupplierService.findByNumberOfOccupants(5, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenReturn(adc_child5);
        when(calculatorSupplierService.findByNumberOfOccupants(6, OccupantType.CHILD, BudgetType.AVERAGE))
                .thenReturn(adc_child6);

        AverageDailyCharge adc_l = new AverageDailyCharge();
        adc_l.setNumberOfOccupants(1);
        adc_l.setOccupantType(OccupantType.ADULT);
        adc_l.setType(BudgetType.LOW);
        adc_l.setValue(0.10);

        AverageDailyCharge adc_a = new AverageDailyCharge();
        adc_a.setNumberOfOccupants(1);
        adc_a.setOccupantType(OccupantType.ADULT);
        adc_a.setType(BudgetType.AVERAGE);
        adc_a.setValue(0.15);

        AverageDailyCharge adc_h = new AverageDailyCharge();
        adc_h.setNumberOfOccupants(1);
        adc_h.setOccupantType(OccupantType.ADULT);
        adc_h.setType(BudgetType.HIGH);
        adc_h.setValue(0.20);

        when(calculatorSupplierService.findByNumberOfOccupants(1, OccupantType.ADULT, BudgetType.LOW)).thenReturn(adc_l);

        when(calculatorSupplierService.findByNumberOfOccupants(1, OccupantType.ADULT, BudgetType.AVERAGE))
                .thenReturn(adc_a);

        when(calculatorSupplierService.findByNumberOfOccupants(1, OccupantType.ADULT, BudgetType.HIGH)).thenReturn(adc_h);

        AverageDailyCharge adc_l2 = new AverageDailyCharge();
        adc_l2.setNumberOfOccupants(2);
        adc_l2.setOccupantType(OccupantType.ADULT);
        adc_l2.setType(BudgetType.LOW);
        adc_l2.setValue(0.20);

        AverageDailyCharge adc_a2 = new AverageDailyCharge();
        adc_a2.setNumberOfOccupants(2);
        adc_a2.setOccupantType(OccupantType.ADULT);
        adc_a2.setType(BudgetType.AVERAGE);
        adc_a2.setValue(0.30);

        AverageDailyCharge adc_h2 = new AverageDailyCharge();
        adc_h2.setNumberOfOccupants(2);
        adc_h2.setOccupantType(OccupantType.ADULT);
        adc_h2.setType(BudgetType.HIGH);
        adc_h2.setValue(0.40);

        when(calculatorSupplierService.findByNumberOfOccupants(2, OccupantType.ADULT, BudgetType.LOW)).thenReturn(adc_l2);

        when(calculatorSupplierService.findByNumberOfOccupants(2, OccupantType.ADULT, BudgetType.AVERAGE))
                .thenReturn(adc_a2);

        when(calculatorSupplierService.findByNumberOfOccupants(2, OccupantType.ADULT, BudgetType.HIGH)).thenReturn(adc_h2);

        
        when(calculatorSupplierService.getMeasuredUsageChargesBySupplier(eq("1"))).thenReturn(measUsageChargeSTW);

        when(calculatorSupplierService.getMeasuredUsageChargesBySupplier("2"))
                .thenReturn(measUsageChargeChester);

        when(calculatorSupplierService.getMeasuredUsageChargesBySupplier("4")).thenReturn(measUsageChargePowys);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty("1", PropertyType.TERRACED))
                .thenReturn(measPropertyChargeSTW_Terrace);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty("1", PropertyType.SEMI))
                .thenReturn(measPropertyChargeSTW_Semi);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty("1", PropertyType.FLAT))
                .thenReturn(measPropertyChargeSTW_Flat);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty("2", PropertyType.DETACHED))
                .thenReturn(measPropertyChargeChester_Detached);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty("2", PropertyType.FLAT))
                .thenReturn(measPropertyChargeChester_Flat);

        when(calculatorSupplierService.getMeasuredPropertyChargesBySupplierAndProperty("4", PropertyType.SEMI))
                .thenReturn(measPropertyChargeChester_Semi);

    }

    @Test
    public void testEstimateOneAdultOneChildInFlatWthHighwaysDrainage() throws Exception {
        setUpMocks();

        estimateRequest.setNumberOfAdultOccupants(1);
        estimateRequest.setNumberOfChildrenOccupants(1);
        estimateRequest.setPropertyType(PropertyType.SEMI);
        estimateRequest.setStartDate(LocalDate.of(2017, Month.JANUARY, 1));
        estimateRequest.setEndDate(LocalDate.of(2018, Month.JANUARY, 1));
        estimateRequest.setWaterService(true);
        estimateRequest.setWaterSupplier("4");
        estimateRequest.setUsedWaterService(true);
        estimateRequest.setUsedWaterSupplier("4");
        estimateRequest.setSurfaceWaterService(true);
        estimateRequest.setSurfaceWaterSupplier("4");
        estimateRequest.setHighwaysDrainageService(true);
        estimateRequest.setHighwayDrainageSupplier("4");

        when(calculatorSupplierService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD))
                .thenReturn(true);

        try {
            Estimates estimates = calculationService.calculate(estimateRequest);
            assertEquals("numberOfDays Match", 365, estimates.getNumberOfDays());
            estimates.getUsageBands().forEach(usageBand -> {
                if (usageBand.getType().equals(BudgetType.LOW)) {
                    assertEquals("LOW: Total", 252.64, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("LOW: waterOnly Price", 107.86, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("LOW: Used Price", 123.92, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("LOW: Surface Water Price", 15.86, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.HIGHWAYS_DRAINAGE.name())) {
                            assertEquals("LOW: Surface Water Price", 5.0, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

                if (usageBand.getType().equals(BudgetType.AVERAGE)) {
                    assertEquals("AVERAGE: Total", 303.16, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("AVERAGE: waterOnly Price", 133.40, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("AVERAGE: Used Price", 148.90, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("AVERAGE: Surface Water Price", 15.86, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.HIGHWAYS_DRAINAGE.name())) {
                            assertEquals("AVERAGE: Surface Water Price", 5.0, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

                if (usageBand.getType().equals(BudgetType.HIGH)) {
                    assertEquals("HIGH: Total", 353.69, usageBand.getTotal(), 0.001);
                    usageBand.getCalculation().forEach(calculationValue -> {
                        if (calculationValue.getService().equals(ServiceType.WATER.name())) {
                            assertEquals("HIGH: waterOnly Price", 158.95, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.USED_WATER.name())) {
                            assertEquals("HIGH: Used Price", 173.88, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.SURFACE_WATER.name())) {
                            assertEquals("HIGH: Surface Water Price", 15.86, calculationValue.getValue(), 0.0001);
                        }

                        if (calculationValue.getService().equals(ServiceType.HIGHWAYS_DRAINAGE.name())) {
                            assertEquals("HIGH: Surface Water Price", 5.0, calculationValue.getValue(), 0.0001);
                        }
                    });
                }

            });

        } catch (ServiceException e) {
            log.debug(e.getMessage());
        }

    }

    private void setRequestSupplierDefaults(EstimateRequest request, String defaultSupplier) {
        request.setWaterSupplier(defaultSupplier);
        request.setSewerageSupplier(defaultSupplier);
        request.setSurfaceWaterSupplier(defaultSupplier);
        request.setUsedWaterSupplier(defaultSupplier);
        request.setHighwayDrainageSupplier(defaultSupplier);
    }
}