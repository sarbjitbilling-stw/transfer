package uk.co.stwater.api.calculator.service;


import uk.co.stwater.api.core.service.Service;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.consumption.EstimateRequest;
import uk.co.stwater.api.osgi.model.calculator.consumption.Estimates;

public interface CalculationService extends Service {

    Estimates calculate(EstimateRequest request) throws ServiceException;
}
