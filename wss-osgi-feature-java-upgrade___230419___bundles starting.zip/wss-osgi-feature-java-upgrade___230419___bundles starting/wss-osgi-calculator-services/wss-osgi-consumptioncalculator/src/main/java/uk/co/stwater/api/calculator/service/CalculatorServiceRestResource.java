package uk.co.stwater.api.calculator.service;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.consumption.EstimateRequest;
import uk.co.stwater.api.osgi.model.calculator.consumption.Estimates;
import uk.co.stwater.api.osgi.util.AbstractResource;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/calculation")
@Named("consumptionCalculatorRestResource")
public class CalculatorServiceRestResource extends AbstractResource {

	@Inject
	private CalculationService calculationService;

	public CalculatorServiceRestResource() {

	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response calculate(EstimateRequest request) throws ServiceException {
		GenericEntity<Estimates> entity = null;
		entity = new GenericEntity<Estimates>(calculationService.calculate(request)) {
		};
		return Response.status(200).entity(entity).build();
	}
}
