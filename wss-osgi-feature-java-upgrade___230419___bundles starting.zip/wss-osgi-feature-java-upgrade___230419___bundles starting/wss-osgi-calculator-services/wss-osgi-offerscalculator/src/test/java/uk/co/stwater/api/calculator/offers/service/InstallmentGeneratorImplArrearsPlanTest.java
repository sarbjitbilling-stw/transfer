package uk.co.stwater.api.calculator.offers.service;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.calculator.offers.model.TestSummary;
import uk.co.stwater.api.osgi.model.calculator.offers.Installment;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.math.BigDecimal;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class InstallmentGeneratorImplArrearsPlanTest {
    Logger log = LoggerFactory.getLogger(this.getClass());

    private final BigDecimal MAX_MEASURED_FLEX_VARIANT_AMOUNT = new BigDecimal("0.30");

    Map<String, TestSummary> testSummaryMap = null;
    Map<String, Offer> inputOffersMap = null;
    Map<String, OffersCalculation> inputOffersCalculationMap = null;
    Map<String, OffersCalculationRequest> inputOffersCalculationRequestMap = null;
    Map<String, Offer> outputOffersMap = null;
    Map<String, List<Installment>> outputInstallmentMap = null;

    @InjectMocks
    private InstallmentGenerator installmentGenerator = new InstallmentGeneratorImpl();

    private String getFilePath(String fileName) {
        String platformIndependentPath;
        try {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            platformIndependentPath = Paths.get(classloader.getResource(fileName).toURI()).toString();
            log.debug("platformIndependentPath : {} ", platformIndependentPath);
        } catch (Exception ex) {
            log.error("Error in InstallmentGeneratorImplTest.getFilePath, {} , {} ", ex.getMessage(), ex);
            throw new STWTechnicalException(ex.getMessage(), ex);
        }
        return platformIndependentPath;
    }

    private Map<String, Offer> readInputOffersMap() {
        return OffersCsvTransformers.readOffersMap(getFilePath("install_generator_arrears_plan_input_offers.csv"));
    }

    private Map<String, OffersCalculationRequest> readInputOffersCalculationRequestMap() {
        return OffersCsvTransformers.readOffersCalculationRequestMap(getFilePath("install_generator_arrears_plan_input_calculationrequest.csv"));
    }

    private Map<String, OffersCalculation> readInputOffersCalculationMap() {
        return OffersCsvTransformers.readInputOffersCalculationMap(getFilePath("install_generator_arrears_plan_input_offerscalculation.csv"), false);
    }

    private Map<String, List<Installment>> readOutputInstallmentMap() {
        return OffersCsvTransformers.readInstallmentMap(getFilePath("install_generator_arrears_plan_output_installment.csv"));
    }

    private Map<String, TestSummary> readTestSummaryMap() {
        return OffersCsvTransformers.readTestSummaryMap(getFilePath("install_generator_arrears_plan_test_summary.csv"));
    }

    private Map<String, Offer> readOutputOffersMap() {
        return OffersCsvTransformers.readOffersMap(getFilePath("install_generator_arrears_plan_output_offers.csv"));
    }

    @BeforeEach
    void setUp() throws Exception {
        testSummaryMap = readTestSummaryMap();
        inputOffersMap = readInputOffersMap();
        inputOffersCalculationMap = readInputOffersCalculationMap();
        inputOffersCalculationRequestMap = readInputOffersCalculationRequestMap();
        outputOffersMap = readOutputOffersMap();
        outputInstallmentMap = readOutputInstallmentMap();
    }

    private OffersCalculation getOffersCalculation(String testId) {
        OffersCalculation offersCalculation = inputOffersCalculationMap.get(testId);
        offersCalculation.setOffersCalculationRequest(inputOffersCalculationRequestMap.get(testId));
        return offersCalculation;
    }

    @Test
    void calculateAndSetInstallments() {
        BigDecimal maxMeasuredFlexVariantAmount = MAX_MEASURED_FLEX_VARIANT_AMOUNT;
        testSummaryMap.forEach((testId, testSummary) -> {
                    if (testSummary.isActive()) {
                        calculateAndSetInstallments(testId, maxMeasuredFlexVariantAmount);
                    }
                }
        );
    }

    @Test
    void calculateAndSetInstallmentsForSingleTestID() {
        String testId = "SHORT_L11_M_WITH_BAL_109";
        BigDecimal maxMeasuredFlexVariantAmount = MAX_MEASURED_FLEX_VARIANT_AMOUNT;
        calculateAndSetInstallments(testId, maxMeasuredFlexVariantAmount);
    }

    private void calculateAndSetInstallments(String testId, BigDecimal maxMeasuredFlexVariantAmount) {
        Offer offer = inputOffersMap.get(testId);
        List<Offer> offers = new ArrayList<>();
        offers.add(offer);
//        printInput(getTestDetails(testId), offers, getOffersCalculation(testId));
        installmentGenerator.calculateAndSetInstallments(offers, getOffersCalculation(testId), maxMeasuredFlexVariantAmount);
        log.debug(getTestDetails(testId));
        printResult(getTestDetails(testId), offers);
        assertOffers(testId, offers, outputOffersMap.get(testId));
        assertInstallments(testId, offers, outputInstallmentMap.get(testId));
    }

    private String getTestDetails(String testId) {
        return "******TEST ID:".concat(testId).concat(":").concat(testSummaryMap.get(testId).getDetails()).concat(":************");
    }

    private void assertInstallments(String testId, List<Offer> offers, List<Installment> expectedInstallments) {
        String message = "TestID : ".concat(testId).concat(":Installment Check:");
        final int FIRST_OFFER_POSITION = 0;
        final int FIRST_INSTALLMENT_POSITION = 0;
        final int SECOND_INSTALLMENT_POSITION = 1;
        final int THIRD_INSTALLMENT_POSITION = 2;
        final int FINAL_INSTALLMENT_POSITION = 3;
        final int SIZE_TWO_INSTALLMENTS = 2;
        final int SIZE_THREE_INSTALLMENTS = 3;

        Offer actualOffer = offers.get(FIRST_OFFER_POSITION);
        List<Installment> actualInstallments = actualOffer.getInstallments();
        int finalActualInstallmentPosition = actualInstallments.size() - 1;

        assertInstallment(message.concat(" First Installment : "), actualInstallments.get(FIRST_INSTALLMENT_POSITION), expectedInstallments.get(FIRST_INSTALLMENT_POSITION));
        if (actualInstallments.size() >= SIZE_TWO_INSTALLMENTS) {
            assertInstallment(message.concat(" Second Installment : "), actualInstallments.get(SECOND_INSTALLMENT_POSITION), expectedInstallments.get(SECOND_INSTALLMENT_POSITION));
        }
        if (actualInstallments.size() >= SIZE_THREE_INSTALLMENTS) {
            assertInstallment(message.concat(" Third Installment : "), actualInstallments.get(THIRD_INSTALLMENT_POSITION), expectedInstallments.get(THIRD_INSTALLMENT_POSITION));
        }

        assertInstallment(message.concat(" Final Installment : "), actualInstallments.get(finalActualInstallmentPosition), expectedInstallments.get(FINAL_INSTALLMENT_POSITION));
    }

    private void assertInstallment(String message, Installment actualInstallment, Installment expectedInstallment) {
        assertThat(message.concat(" -> InstallmentAmount"), actualInstallment.getInstallmentAmount(), Matchers.comparesEqualTo(expectedInstallment.getInstallmentAmount()));
        assertThat(message.concat(" -> InstallmentArrearsAmount"), actualInstallment.getInstallmentArrearsAmount(), Matchers.comparesEqualTo(expectedInstallment.getInstallmentArrearsAmount()));
        assertThat(message.concat(" -> InstallmentForecastAmount"), actualInstallment.getInstallmentForecastAmount(), Matchers.comparesEqualTo(expectedInstallment.getInstallmentForecastAmount()));
        assertEquals(expectedInstallment.getExpectedPaymentDate(), actualInstallment.getExpectedPaymentDate(), message.concat(" -> ExpectedPaymentDate"));
    }

    private void assertOffers(String testId, List<Offer> offers, Offer expectedOffer) {
        String message = "TestID : ".concat(testId).concat(":Offer Check:");
        final int FIRST_OFFER_POSITION = 0;
        Offer actualOffer = offers.get(FIRST_OFFER_POSITION);

        assertThat(message.concat(" -> Forecast"), actualOffer.getForecast(), Matchers.comparesEqualTo(expectedOffer.getForecast()));
        assertThat(message.concat(" -> Accrued"), actualOffer.getAccrued(), Matchers.comparesEqualTo(expectedOffer.getAccrued()));
        assertThat(message.concat(" -> Arrears:AccountArrears"), actualOffer.getArrears().getAccountArrears(), Matchers.comparesEqualTo(expectedOffer.getArrears().getAccountArrears()));
        assertThat(message.concat(" -> Arrears:ThirdPartyCharges"), actualOffer.getArrears().getThirdPartyCharges(), Matchers.comparesEqualTo(expectedOffer.getArrears().getThirdPartyCharges()));
        assertThat(message.concat(" -> PlanAmount"), actualOffer.getPlanAmount(), Matchers.comparesEqualTo(expectedOffer.getPlanAmount()));
        assertThat(message.concat(" -> PotentialUnderPayment"), actualOffer.getPotentialUnderPayment(), Matchers.comparesEqualTo(expectedOffer.getPotentialUnderPayment()));
        assertThat(message.concat(" -> InstallmentArrearsAmount"), actualOffer.getInstallmentArrearsAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentArrearsAmount()));
        assertThat(message.concat(" -> InstallmentForecastAmount"), actualOffer.getInstallmentForecastAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentForecastAmount()));
        assertThat(message.concat(" -> InstallmentAmount"), actualOffer.getInstallmentAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentAmount()));

        assertEquals(expectedOffer.getStartDate(), actualOffer.getStartDate(), message.concat(" -> StartDate"));
        assertEquals(expectedOffer.getEndDate(), actualOffer.getEndDate(), message.concat(" -> EndDate"));
    }

    private void printInput(String testDetails, List<Offer> list, OffersCalculation offersCalculation) {
        log.debug("{}, printInput:  offersCalculation: {} ", testDetails, offersCalculation.toString());
        list.forEach(offer ->
                log.debug("{},  printInput:  offer: {} ", testDetails, offer.toString())
        );
    }

    private void printResult(String testDetails, List<Offer> list) {
        list.forEach(offer -> {
            log.debug("{} printResult: {} ", testDetails, offer.toString());
            List<Installment> installments = offer.getInstallments();
            installments.forEach(installment ->
                    log.debug("{}, Installment: {} ", testDetails, installment.toString())
            );
        });
    }
}