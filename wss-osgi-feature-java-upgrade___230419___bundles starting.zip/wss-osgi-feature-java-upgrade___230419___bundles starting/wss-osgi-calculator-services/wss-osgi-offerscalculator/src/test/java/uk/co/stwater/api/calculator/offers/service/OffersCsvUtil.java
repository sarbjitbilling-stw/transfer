package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.osgi.model.calculator.offers.Arrears;
import uk.co.stwater.api.osgi.model.referencedata.RefData;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class OffersCsvUtil {

    static private final int TESTID_COLUMN_POSITION = 0;
    static private final int GROUP_TESTID_COLUMN_POSITION = 1;

    static protected List<String> readFile(String filePath) {
        List<String> list = new ArrayList<>();

        try (BufferedReader br = Files.newBufferedReader(Paths.get(filePath))) {
            list = br.lines().collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    static protected Arrears getArrearsObject(BigDecimal accountArrears, BigDecimal thirdPartyCharges) {
        return new Arrears(accountArrears, thirdPartyCharges);
    }

    static private String getID(String[] itemArray, boolean isGroupID) {
        if (isGroupID) {
            return itemArray[GROUP_TESTID_COLUMN_POSITION];
        } else {
            return itemArray[TESTID_COLUMN_POSITION];
        }
    }

    static protected RefData createRefData(final String code, final String value, final String set) {
        RefData refData = new RefData();
        refData.setCode(code);
        refData.setValue(value);
        refData.setSet(set);
        return refData;
    }
}
