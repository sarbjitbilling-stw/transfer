package uk.co.stwater.api.calculator.offers.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.offers.model.TestSummary;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.bill.status.AccountBillStatusClient;
import uk.co.stwater.iib.client.api.bill.status.NextBillStatusResponse;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class OfferGeneratorImplTest {
    private static final Logger log = LoggerFactory.getLogger(OfferGeneratorImplTest.class);

    @Mock
    private AccountBillStatusClient accountBillStatusClient;

    @InjectMocks
    private OfferGeneratorImpl offerGenerator = new OfferGeneratorImpl();

    private static Map<String, TestSummary> testSummaryMap = null;
    private static Map<String, List<PaymentPlan>> inputPaymentPlanByGroupMap = null;
    private static Map<String, PaymentPlan> inputPaymentPlanMap = null;
    private static Map<String, OffersCalculation> inputOffersCalculationMap = null;
    private static Map<String, OffersCalculationRequest> inputOffersCalculationRequestMap = null;
    private static Map<String, Offer> outputOffersMap = null;

    private static String getFilePath(String fileName) {
        String platformIndependentPath;
        try {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            platformIndependentPath = Paths.get(classloader.getResource(fileName).toURI()).toString();
        } catch (Exception ex) {
            log.error("Error in InstallmentGeneratorImplTest.getFilePath, {} , {} ", ex.getMessage(), ex);
            throw new STWTechnicalException(ex.getMessage(), ex);
        }
        return platformIndependentPath;
    }

    private static Map<String, PaymentPlan> readInputPaymentPlanMap() {
        return OffersCsvTransformers.readPaymentPlanMap(getFilePath("offer_generator_input_payment_plans.csv"));
    }

    private static Map<String, List<PaymentPlan>> readInputPaymentPlanByGroupMap() {
        return OffersCsvTransformers.readPaymentPlanByGroupMap(getFilePath("offer_generator_input_payment_plans.csv"));
    }

    private static Map<String, OffersCalculationRequest> readInputOffersCalculationRequestMap() {
        return OffersCsvTransformers.readOffersCalculationRequestMap(getFilePath("offer_generator_input_calculationrequest.csv"));
    }

    private static Map<String, OffersCalculation> readInputOffersCalculationMap() {
        return OffersCsvTransformers.readInputOffersCalculationMap(getFilePath("offer_generator_input_offerscalculation.csv"), true);
    }

    private static Map<String, TestSummary> readTestSummaryMap() {
        return OffersCsvTransformers.readTestSummaryMap(getFilePath("offer_generator_test_summary.csv"));
    }

    private static Map<String, Offer> readOutputOffersMap() {
        return OffersCsvTransformers.readOffersMap(getFilePath("offer_generator_output_offers.csv"));
    }

    private OffersCalculationRequest getOffersCalculationRequest() {
        OffersCalculationRequest request = new OffersCalculationRequest();
        request.setAccountNumber(new TargetAccountNumber("359002218", null));
        request.setLegalEntityNo("954002067");
        request.setPaymentMethod("DD");
        request.setPaymentFrequency("M");
        request.setFirstInstallmentAmount(new BigDecimal("90.00"));
        request.setUpfrontPaymentAmount(BigDecimal.ZERO);
        request.setGetAllPPCOffers(true);
        request.setPreferredPaymentDay(20);
        request.setPreferredPaymentDate(LocalDate.of(2017, Month.AUGUST, 20));
        return request;
    }

    @BeforeAll
    static void setUp() throws Exception {
        testSummaryMap = readTestSummaryMap();
        inputPaymentPlanMap = readInputPaymentPlanMap();
//        printPaymentPlanMap(inputPaymentPlanMap);
        inputPaymentPlanByGroupMap = readInputPaymentPlanByGroupMap();
//        printPaymentPlanByGroupMap(inputInvoiceByGroupMap);

        inputOffersCalculationMap = readInputOffersCalculationMap();
//        printOffersCalculationMap(inputOffersCalculationMap);
        inputOffersCalculationRequestMap = readInputOffersCalculationRequestMap();
//        printOffersCalculationRequestMap(inputOffersCalculationRequestMap);
        outputOffersMap = readOutputOffersMap();

    }

    @Test
    void getOffers() {
        testSummaryMap.forEach((testId, testSummary) -> {
                    if (testSummary.isActive()) {
                        getOffersTest(testId);
                    }
                }
        );
    }

    private void getOffersTest(String testId) {
        List<PaymentPlan> paymentPlans = new ArrayList<>();
        paymentPlans.add(inputPaymentPlanMap.get(testId));

        List<Offer> offers = offerGenerator.getOffers(paymentPlans, getOffersCalculation(testId));
        log.debug(getTestDetails(testId));
        printResult(getTestDetails(testId), offers);
        assertOffers(testId, offers, outputOffersMap.get(testId));
    }

    @Test
    void getOffersForSingleTestID() {
        String testId = "M_STD_M_100_WITH_FP";
        getOffersTest(testId);
    }

    @Test
    public void includeForecastForUnmeasuredAccountIncludeForecastNull() {
        includeForecastForUnmeasuredAccountTemplate(null, false);
    }

    @Test
    public void includeForecastForUnmeasuredAccountIncludeForecastInvalid() {
        includeForecastForUnmeasuredAccountTemplate("INVALID", false);
    }

    @Test
    public void includeForecastForUnmeasuredAccountIncludeForecastY() {
        includeForecastForUnmeasuredAccountTemplate("Y", true);
    }

    @Test
    public void includeForecastForUnmeasuredAccountIncludeForecastN() {
        includeForecastForUnmeasuredAccountTemplate("N", false);
    }

    @Test
    public void includeForecastForUnmeasuredAccountIncludeForecastRAndMainBilled() {
        includeForecastForUnmeasuredAccountTemplate("R", true, false);
    }

    @Test
    public void includeForecastForUnmeasuredAccountIncludeForecastRAndNotMainBilled() {
        includeForecastForUnmeasuredAccountTemplate("R", false, true);
    }

    private void includeForecastForUnmeasuredAccountTemplate(String includeForecast, boolean expected) {
        includeForecastForUnmeasuredAccountTemplate(includeForecast, false, expected);
    }

    private void includeForecastForUnmeasuredAccountTemplate(String includeForecast, boolean isMainBilled,
            boolean expected) {
        TargetAccountNumber accountNumber = new TargetAccountNumber("123459");
        PaymentPlan paymentPlan = new PaymentPlan();
        paymentPlan.setIncludeForecast(includeForecast);

        NextBillStatusResponse response = mock(NextBillStatusResponse.class);
        when(response.isMainBilled()).thenReturn(isMainBilled);
        when(accountBillStatusClient.getNextBillStatus(accountNumber)).thenReturn(response);

        boolean actual = offerGenerator.includeForecastForUnmeasuredAccount(accountNumber, paymentPlan);

        assertEquals(expected, actual);
    }

    private String getTestDetails(String testId) {
        return "******TEST ID:".concat(testId).concat(":").concat(testSummaryMap.get(testId).getDetails()).concat(":************");
    }

    private OffersCalculation getOffersCalculation(String testId) {
        OffersCalculation offersCalculation = inputOffersCalculationMap.get(testId);
        offersCalculation.setOffersCalculationRequest(inputOffersCalculationRequestMap.get(testId));
        return offersCalculation;
    }

    private void assertOffers(String testId, List<Offer> offers, Offer expectedOffer) {
        String message = "TestID : ".concat(testId).concat(":Offer Check:");
        final int FIRST_OFFER_POSITION = 0;
        Offer actualOffer = offers.get(FIRST_OFFER_POSITION);

        assertEquals(expectedOffer.getOfferId(), actualOffer.getOfferId(), message.concat(" -> OfferId"));
        assertEquals(expectedOffer.getOfferDetail(), actualOffer.getOfferDetail(), message.concat(" -> OfferDetail"));
        assertEquals(expectedOffer.getGroup(), actualOffer.getGroup(), message.concat(" -> Group"));
        assertEquals(expectedOffer.getPaymentFrequency(), actualOffer.getPaymentFrequency(), message.concat(" -> PaymentFrequency"));
        assertEquals(expectedOffer.getPaymentMethod(), actualOffer.getPaymentMethod(), message.concat(" -> PaymentMethod"));
        assertEquals(expectedOffer.getLengthInMonths(), actualOffer.getLengthInMonths(), message.concat(" -> LengthInMonths"));
        assertThat(message.concat(" -> VariantAmount"), actualOffer.getVariantAmount(), Matchers.comparesEqualTo(expectedOffer.getVariantAmount()));
        assertEquals(expectedOffer.getPlanVariant(), actualOffer.getPlanVariant(), message.concat(" -> PlanVariant"));
        assertEquals(expectedOffer.getMonth(), actualOffer.getMonth(), message.concat(" -> Month"));
        assertEquals(expectedOffer.getMonthName(), actualOffer.getMonthName(), message.concat(" -> MonthName"));

        assertThat(message.concat(" -> NumOfInstallments"), actualOffer.getNumOfInstallments(), Matchers.comparesEqualTo(expectedOffer.getNumOfInstallments()));
        assertThat(message.concat(" -> PlanAmount"), actualOffer.getPlanAmount(), Matchers.comparesEqualTo(expectedOffer.getPlanAmount()));

        assertThat(message.concat(" -> Forecast"), actualOffer.getForecast(), Matchers.comparesEqualTo(expectedOffer.getForecast()));
        assertThat(message.concat(" -> BaseForecast"), actualOffer.getBaseForecast(), Matchers.comparesEqualTo(expectedOffer.getBaseForecast()));
        assertThat(message.concat(" -> OriginalForecast"), actualOffer.getOriginalForecast(), Matchers.comparesEqualTo(expectedOffer.getOriginalForecast()));
        assertThat(message.concat(" -> Accrued"), actualOffer.getAccrued(), Matchers.comparesEqualTo(expectedOffer.getAccrued()));
        assertThat(message.concat(" -> BaseAccrued"), actualOffer.getBaseAccrued(), Matchers.comparesEqualTo(expectedOffer.getBaseAccrued()));
        assertThat(message.concat(" -> OriginalAccrued"), actualOffer.getOriginalAccrued(), Matchers.comparesEqualTo(expectedOffer.getOriginalAccrued()));
        assertThat(message.concat(" -> Arrears:AccountArrears"), actualOffer.getArrears().getAccountArrears(), Matchers.comparesEqualTo(expectedOffer.getArrears().getAccountArrears()));
        assertThat(message.concat(" -> Arrears:ThirdPartyCharges"), actualOffer.getArrears().getThirdPartyCharges(), Matchers.comparesEqualTo(expectedOffer.getArrears().getThirdPartyCharges()));
        assertThat(message.concat(" -> BaseArrears:AccountArrears"), actualOffer.getBaseArrears().getAccountArrears(), Matchers.comparesEqualTo(expectedOffer.getBaseArrears().getAccountArrears()));
        assertThat(message.concat(" -> BaseArrears:ThirdPartyCharges"), actualOffer.getBaseArrears().getThirdPartyCharges(), Matchers.comparesEqualTo(expectedOffer.getBaseArrears().getThirdPartyCharges()));
        assertThat(message.concat(" -> OriginalArrears:AccountArrears"), actualOffer.getOriginalArrears().getAccountArrears(), Matchers.comparesEqualTo(expectedOffer.getOriginalArrears().getAccountArrears()));
        assertThat(message.concat(" -> OriginalArrears:ThirdPartyCharges"), actualOffer.getOriginalArrears().getThirdPartyCharges(), Matchers.comparesEqualTo(expectedOffer.getOriginalArrears().getThirdPartyCharges()));

        assertEquals(expectedOffer.getDisplayOrder(), actualOffer.getDisplayOrder(), message.concat(" -> DisplayOrder"));

        assertThat(message.concat(" -> PotentialUnderPayment"), actualOffer.getPotentialUnderPayment(), Matchers.comparesEqualTo(expectedOffer.getPotentialUnderPayment()));
        assertThat(message.concat(" -> InstallmentArrearsAmount"), actualOffer.getInstallmentArrearsAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentArrearsAmount()));
        assertThat(message.concat(" -> InstallmentForecastAmount"), actualOffer.getInstallmentForecastAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentForecastAmount()));
        assertThat(message.concat(" -> InstallmentAmount"), actualOffer.getInstallmentAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentAmount()));
        assertEquals(expectedOffer.getStartDate(), actualOffer.getStartDate(), message.concat(" -> StartDate"));
        assertEquals(expectedOffer.getEndDate(), actualOffer.getEndDate(), message.concat(" -> EndDate"));
    }

    private void printOffersCalculationRequestMap(Map<String, OffersCalculationRequest> inputOffersCalculationRequestMap) {
        if (inputOffersCalculationRequestMap != null) {
            inputOffersCalculationRequestMap.forEach((testId, offersCalculationRequest) ->
                    log.debug("==========testId======={}====offersCalculationRequest: {}", testId, offersCalculationRequest.toString())
            );
        }
    }

    private void printOffersCalculationMap(Map<String, OffersCalculation> inputOffersCalculationMap) {
        if (inputOffersCalculationMap != null) {
            inputOffersCalculationMap.forEach((testId, offersCalculation) ->
                    log.debug("==========testId======={}====offersCalculation: {}", testId, offersCalculation.toString())
            );
        }
    }

    private void printPaymentPlanMap(Map<String, PaymentPlan> inputPaymentPlanMap) {
        if (inputPaymentPlanMap != null) {
            inputPaymentPlanMap.forEach((testId, paymentPlan) ->
                    log.debug("==========testId======={}====paymentPlan: {}", testId, paymentPlan.toString())
            );
        }
    }

    private void printPaymentPlanByGroupMap(Map<String, List<PaymentPlan>> inputPaymentPlanByGroupMap) {
        if (inputPaymentPlanByGroupMap != null) {
            inputPaymentPlanByGroupMap.forEach((groupId, list) -> {
                log.debug("==========groupID======={}=====", groupId);
                list.forEach(paymentPlan ->
                        log.debug("paymentPlan : {}", paymentPlan.toString()));
            });
        }
    }

    private void printResult(String testDetails, List<Offer> list) {
        list.forEach(offer ->
                log.debug("{} printResult: {}", testDetails, offer.toString())
        );
    }
}