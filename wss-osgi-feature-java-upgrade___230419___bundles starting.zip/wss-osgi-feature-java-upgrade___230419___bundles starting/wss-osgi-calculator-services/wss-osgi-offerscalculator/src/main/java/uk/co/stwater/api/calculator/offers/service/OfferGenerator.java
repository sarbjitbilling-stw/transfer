package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

import java.util.List;

public interface OfferGenerator {
    List<Offer> getOffers(final List<PaymentPlan> paymentPlans, final OffersCalculation offersCalculation) throws ServiceException;

    List<PaymentPlan> getPaymentPlansBasedOnArrearsAndMonth(final List<PaymentPlan> paymentPlans, final OffersCalculation offersCalculation);
}
