package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.inject.Named;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.calculator.offers.BasePeriodCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.Budget;
import uk.co.stwater.api.osgi.model.calculator.offers.BudgetPlanTypes;
import uk.co.stwater.api.osgi.model.calculator.offers.Invoice;
import uk.co.stwater.api.osgi.model.calculator.offers.InvoiceLine;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvision;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvisionBudget;
import uk.co.stwater.api.osgi.model.calculator.offers.WarningDTO;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@OsgiServiceProvider(classes = {BasePeriodAnalyser.class})
@Transactional
@Named
public class BasePeriodAnalyserImpl implements BasePeriodAnalyser {

    Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * @param offersCalculation
     * @param measuredIndicator
     * @throws ServiceException Sets following of OffersCalculation
     *                          BaseForecast, OriginalForecast, BaseAccrued, OriginalAccrued
     */
    @Override
    public void calculateForecastAndAccruedDetails(final OffersCalculation offersCalculation, final String measuredIndicator) throws ServiceException {
        BasePeriodCalculation basePeriodCalculation;
        if (offersCalculation.isUnmeasured()) {
            basePeriodCalculation = getUnmeasuredBasePeriodCalculation(offersCalculation);
        } else {
            basePeriodCalculation = getBasePeriodCalculation(offersCalculation);
        }

        offersCalculation.getBudget().setBasePeriodCalculation(basePeriodCalculation);

        if (!OffersUtil.exitIfNoHistoryAndNoForecast(offersCalculation)) {
            calculateForecastAccruedRelevantInfo(offersCalculation);
        }
    }

    private void calculateForecastAccruedRelevantInfo(final OffersCalculation offersCalculation) {
        if (offersCalculation.isMeasured()) {
            populateAverageDailyChargeAndAccruedStartDate(offersCalculation);
            setForecastAndAccrued(offersCalculation, offersCalculation.getOffersCalculationRequest());
        } else if (offersCalculation.isUnmeasured()) {
            setForecastAndAccrued(offersCalculation, offersCalculation.getOffersCalculationRequest());
        } else if (offersCalculation.isAssessed()) {
            populateAverageDailyChargeAndAccruedStartDate(offersCalculation);
            setForecastAndAccrued(offersCalculation, offersCalculation.getOffersCalculationRequest());
        }
    }

    private void setForecastAndAccrued(final OffersCalculation offersCalculation, final OffersCalculationRequest offersCalculationRequest) {
        raiseErrorBasedOnConsumptionData(offersCalculation, offersCalculationRequest);
        setForecastAndAccruedUsingServiceProvAvg(offersCalculation, true);
        if (offersCalculation.getOffersCalculationRequest().getForecast().signum() == 1) {
            populateAverageDailyChargeFromCalculatorForecast(offersCalculation, offersCalculation.getServiceProvisions(), offersCalculationRequest.getForecast());
            setForecastAndAccruedUsingServiceProvAvg(offersCalculation, false);
            setAverageAccruedDays(offersCalculation, offersCalculation.getServiceProvisions(), false);
        } else {
            setAverageAccruedDays(offersCalculation, offersCalculation.getServiceProvisions(), true);
        }
    }

    private void setForecastAndAccruedUsingServiceProvAvg(final OffersCalculation offersCalculation, final boolean useBills) {
        offersCalculation.getServiceProvisions().stream()
                .map(serviceProvision -> {
                    List<ServiceProvisionBudget> serviceProvisionBudgets = useBills ? serviceProvision.getServiceProvisionBudgetFromBills() : serviceProvision.getServiceProvisionBudgetFromCalcs();
                    populateForecastAndAccruedForServiceProvisionBudgets(serviceProvisionBudgets, offersCalculation);
                    return serviceProvision;

                }).collect(Collectors.toList());

        offersCalculation.setBaseForecast(getForecastOrAccruedChargeWithUplift(offersCalculation, useBills, false, true));
        offersCalculation.setBaseForecastForPPC(getForecastOrAccruedChargeWithUplift(offersCalculation, useBills, true, true));
        offersCalculation.setBaseAccrued(getAccruedChargeWithUplift(offersCalculation, useBills, false));
        offersCalculation.setBaseAccruedForPPC(getAccruedChargeWithUplift(offersCalculation, useBills, true));

        if (useBills) {//always value from biils/invoice is set as original
            offersCalculation.setOriginalForecast(offersCalculation.getBaseForecast());
            offersCalculation.setOriginalAccrued(offersCalculation.getBaseAccrued());

            //PPC
            offersCalculation.setOriginalForecastForPPC(offersCalculation.getBaseForecastForPPC());
            offersCalculation.setOriginalAccruedForPPC(offersCalculation.getBaseAccruedForPPC());
        }
    }

    private static Predicate<ServiceProvisionBudget> isPPCServiceProvisionBudgetPredicate() {
        return serviceProvisionBudget -> serviceProvisionBudget.getBudgetUplift().getBudgetPlanType().equalsIgnoreCase(BudgetPlanTypes.PPC.getCode());
    }

    private static Predicate<ServiceProvisionBudget> isNonPPCServiceProvisionBudgetPredicate() {
        return serviceProvisionBudget -> !serviceProvisionBudget.getBudgetUplift().getBudgetPlanType().equalsIgnoreCase(BudgetPlanTypes.PPC.getCode());
    }

    /*
    For future Move-In, accrued will be negative, due to accruedStartDate > target date.
    Solution: If accrued is negative then revert to zero.
     */
    private BigDecimal getAccruedChargeWithUplift(final OffersCalculation offersCalculation, final boolean useBills, final boolean isForPPC) {
        BigDecimal baseAccrued = getForecastOrAccruedChargeWithUplift(offersCalculation, useBills, isForPPC, false);
        return baseAccrued.signum() == 1 ? baseAccrued : BigDecimal.ZERO;
    }

    private BigDecimal getForecastOrAccruedChargeWithUplift(final OffersCalculation offersCalculation, final boolean useBills, final boolean isForPPC, final boolean isForForecast) {
        Predicate<ServiceProvisionBudget> serviceProvisionBudgetPredicate = isForPPC ? isPPCServiceProvisionBudgetPredicate() : isNonPPCServiceProvisionBudgetPredicate();
        return offersCalculation.getServiceProvisions().stream()
                .map(serviceProvision -> {
                    List<ServiceProvisionBudget> serviceProvisionBudgets = useBills ? serviceProvision.getServiceProvisionBudgetFromBills() : serviceProvision.getServiceProvisionBudgetFromCalcs();
                    Optional<ServiceProvisionBudget> serviceProvisionBudgetOptional = serviceProvisionBudgets.stream()
                            .filter(serviceProvisionBudgetPredicate)
                            .findFirst();

                    if (serviceProvisionBudgetOptional.isPresent()) {
                        if (isForForecast) {
                            return serviceProvisionBudgetOptional.get().getForecastWithUplift();
                        } else {
                            return serviceProvisionBudgetOptional.get().getAccruedChargeWithUplift();
                        }
                    }
                    return BigDecimal.ZERO;

                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private void populateForecastAndAccruedForServiceProvisionBudgets(final List<ServiceProvisionBudget> serviceProvisionBudgets, final OffersCalculation offersCalculation) {
        int decimalPlaces = offersCalculation.isUnmeasured() ? OffersConstants.DECIMAL_PLACES_SIX : OffersConstants.DECIMAL_PLACES;
        serviceProvisionBudgets.forEach(serviceProvisionBudget -> {
            BigDecimal percentageUplift = serviceProvisionBudget.getBudgetUplift().getPercentageUplift();
            serviceProvisionBudget.setForecastDays(OffersConstants.DAYS_IN_YEAR);
            serviceProvisionBudget.setForecastNewAnnualCharge(
                    serviceProvisionBudget.getAverageDailyCharge()
                            .multiply(serviceProvisionBudget.getForecastDays())
                            .setScale(decimalPlaces, RoundingMode.HALF_UP));

            serviceProvisionBudget.setForecastWithUplift(
                    serviceProvisionBudget.getForecastNewAnnualCharge()
                            .multiply(percentageUplift)
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));

            if (serviceProvisionBudget.getAccruedStartDate() != null) {
                serviceProvisionBudget.setAccruedDays(
                        new BigDecimal(ChronoUnit.DAYS.between(serviceProvisionBudget.getAccruedStartDate(), offersCalculation.getTargetDate()))
                );
            }

            serviceProvisionBudget.setAccruedCharge(
                    serviceProvisionBudget.getAverageDailyCharge()
                            .multiply(serviceProvisionBudget.getAccruedDays())
                            .setScale(decimalPlaces, RoundingMode.HALF_UP));

            serviceProvisionBudget.setAccruedChargeWithUplift(
                    serviceProvisionBudget.getAccruedCharge()
                            .multiply(percentageUplift)
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));

        });
    }

    private void raiseErrorBasedOnConsumptionData(final OffersCalculation offersCalculation, final OffersCalculationRequest offersCalculationRequest) {
        if (offersCalculation.isUnmeasured()) {
            if (offersCalculationRequest.getForecast().signum() == 1) {
                log.error("OffersCalc: Error: Un-measured with forecast as input is currently not supported");
                throw new ServiceException(OffersCalculatorErrorCodes.UNMEASURED_WITH_FORECAST_NOT_SUPPORTED);
            }
        } else if (offersCalculation.isAssessed()) {
            if (offersCalculationRequest.getForecast().signum() != 1) {
                log.error("OffersCalc: Assessed: planAmount not passed in - cannot proceed");
                throw new ServiceException(OffersCalculatorErrorCodes.ASSESSED_ACCOUNT_INVALID);
            }
        }
    }

    private void populateAverageDailyChargeAndAccruedStartDate(final OffersCalculation offersCalculation) throws ServiceException {
        List<ServiceProvision> activeServiceProvisions = offersCalculation.getServiceProvisions();

        boolean averageDailyChargeAndBillEndDateCalculated = false;
        //STEP1: If history exist in last one year, and last bill is not cancelled.
        if (offersCalculation.getBudget().getBasePeriodCalculation() != null &&
                offersCalculation.getBudget().getBasePeriodCalculation().getBillPeriodEndDate() != null) {
            //service provision level adc and billPeriodEndDate is already set by BasePeriodAnalyserImpl...Need to copy same to serviceProvisionBudgetFromCalcs
            populateBillEndDateIfHistoryExist(activeServiceProvisions);
            populateBillEndDateForServiceProvisionWithNoHistory(activeServiceProvisions);//Populate into ServiceProvisionBudgetFromCalcs
            averageDailyChargeAndBillEndDateCalculated = true;
        }


        //STEP2:: lastBill was cancelled or no History in last one year
        if (!averageDailyChargeAndBillEndDateCalculated && offersCalculation.getBudget().getLatestInvoice() != null) {
            averageDailyChargeAndBillEndDateCalculated = true;
            populateBillEndDateIfNoHistory(activeServiceProvisions, offersCalculation.getBudget().getLatestInvoice());
        }

        //STEP3:: if no history at all or new customer with no invoices.
        if (!averageDailyChargeAndBillEndDateCalculated) {
            populateBillEndDateIfNewCustomer(offersCalculation.getServiceProvisions());
        }
    }

    private void populateBillEndDateForServiceProvisionWithNoHistory(final List<ServiceProvision> serviceProvisions) {
        serviceProvisions.stream()
                .filter(serviceProvision -> serviceProvision.getDays().signum() == 0)
                .map(serviceProvision -> {
                    populateAccruedStartDateForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromCalcs(), serviceProvision.getServiceStartDate());
                    return serviceProvision;
                }).collect(Collectors.toList());
    }

    private void populateAccruedStartDateForServiceProvisionBudgets(final List<ServiceProvisionBudget> serviceProvisionBudgets, LocalDate accruedStartDate) {
        serviceProvisionBudgets.forEach(serviceProvisionBudget ->
                serviceProvisionBudget.setAccruedStartDate(accruedStartDate)
        );
    }

    private void populateBillEndDateIfNoHistory(final List<ServiceProvision> serviceProvisions, final Invoice latestInvoice) {
        serviceProvisions.stream()
                .map(serviceProvision -> {
                    Optional<InvoiceLine> maxBillPeriodEndDateOpitional = latestInvoice.getInvoiceLines().stream()
                            .filter(invoiceLine -> invoiceLine.getPropertyAndServiceProvisionNum().equals(serviceProvision.getPropertyAndServiceProvisionNum()))
                            .max(Comparator.comparing(InvoiceLine::getBillPeriodEndDate));

                    LocalDate maxBillPeriodEndDate = null;
                    if (maxBillPeriodEndDateOpitional.isPresent()) {
                        maxBillPeriodEndDate = maxBillPeriodEndDateOpitional.get().getBillPeriodEndDate();
                    }

                    populateAccruedStartDateForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromCalcs(), maxBillPeriodEndDate);

                    return serviceProvision;
                }).collect(Collectors.toList());
    }

    private void populateBillEndDateIfNewCustomer(final List<ServiceProvision> serviceProvisions) {
        serviceProvisions.stream()
                .map(serviceProvision -> {
                    populateAccruedStartDateForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromCalcs(), serviceProvision.getServiceStartDate());

                    return serviceProvision;
                }).collect(Collectors.toList());
    }

    private void populateBillEndDateIfHistoryExist(final List<ServiceProvision> serviceProvisions) {
        serviceProvisions.stream()
                .map(serviceProvision -> {
                    LocalDate accruedStartDate = serviceProvision.getServiceProvisionBudgetFromBills().get(OffersConstants.FIRST_SERVICE_PROVISION_BUDGET).getAccruedStartDate();
                    populateAccruedStartDateForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromCalcs(), accruedStartDate);

                    return serviceProvision;
                }).collect(Collectors.toList());
    }

    /**
     * Accrued Days can be read from one of the ServiceProvisionBudget List.
     * Note: Only difference in the ServiceProvisionBudget items, are they use different uplift for calculation.
     */
    private void setAverageAccruedDays(final OffersCalculation offersCalculation, final List<ServiceProvision> serviceProvisions, final boolean useBills) {
        // @formatter:off
        BigDecimal averageAccruedDays = serviceProvisions.stream()
                .map(serviceProvision -> useBills ? serviceProvision.getServiceProvisionBudgetFromBills() : serviceProvision.getServiceProvisionBudgetFromCalcs())
                .map(serviceProvisionList -> {
                    if (serviceProvisionList == null || 
                            serviceProvisionList.size() <= OffersConstants.FIRST_SERVICE_PROVISION_BUDGET) {
                        throw new ServiceException(OffersCalculatorErrorCodes.NO_VALID_OFFERS);
                    }
                    
                    return serviceProvisionList.get(OffersConstants.FIRST_SERVICE_PROVISION_BUDGET);
                })
                .map(ServiceProvisionBudget::getAccruedDays)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(serviceProvisions.size()), OffersConstants.DECIMAL_PLACES_IN_DAYS, BigDecimal.ROUND_HALF_UP);
        // @formatter:on

        if (averageAccruedDays.signum() == -1) {
            averageAccruedDays = BigDecimal.ZERO;
        }
        offersCalculation.getBudget().setNumOfDaysAccrued(averageAccruedDays);
    }

    private void populateAverageDailyChargeForServiceProvisionBudgets(final List<ServiceProvisionBudget> serviceProvisionBudgets, BigDecimal averageDailyCharge) {
        serviceProvisionBudgets.forEach(serviceProvisionBudget ->
                serviceProvisionBudget.setAverageDailyCharge(averageDailyCharge)
        );
    }

    private void populateAverageDailyChargeFromCalculatorForecast(final OffersCalculation offersCalculation, final List<ServiceProvision> serviceProvisions, final BigDecimal annualForecastFromCalculator) {
        int decimalPlaces = offersCalculation.isUnmeasured() ? OffersConstants.DECIMAL_PLACES_SIX : OffersConstants.DECIMAL_PLACES;
        BigDecimal averageDailyCharge = annualForecastFromCalculator.divide(OffersConstants.DAYS_IN_YEAR, decimalPlaces, RoundingMode.HALF_UP)
                .divide(BigDecimal.valueOf(serviceProvisions.size()), decimalPlaces, RoundingMode.HALF_UP);

        serviceProvisions.stream()
                .map(serviceProvision -> {
                    populateAverageDailyChargeForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromCalcs(), averageDailyCharge);
                    return serviceProvision;
                }).collect(Collectors.toList());
    }

    private BasePeriodCalculation getUnmeasuredBasePeriodCalculation(final OffersCalculation offersCalculation) throws ServiceException {
        Budget budget = offersCalculation.getBudget();
        BasePeriodCalculation basePeriodCalculation = new BasePeriodCalculation();
        offersCalculation.getBudget().setBasePeriodCalculation(basePeriodCalculation);
        List<Invoice> pastOneYearInvoices = budget.getInvoices();
        if (CollectionUtils.isEmpty(pastOneYearInvoices)) {
            throw new ServiceException(OffersCalculatorErrorCodes.PLAN_NOT_POSSIBLE_NO_BILLS);
        }

        Invoice latestInvoice = pastOneYearInvoices.get(0);//Always will be one Invoice.

        latestInvoice.setCalculationStatus(OffersConstants.CALCULATION_STATUS_FIRST_ELIGIBLE);
        LocalDate latestBillStartDate = latestInvoice.getBillStartDate();
        LocalDate latestBillEndDate = latestInvoice.getBillEndDate();

        warnBasedOnOldestBillStartDate(latestBillStartDate, offersCalculation);

        List<ServiceProvision> serviceProvisions = offersCalculation.getServiceProvisions();
        Map<String, ServiceProvision> serviceProvisionsMap = getServiceProvisionsMap(serviceProvisions);

        updateServiceProvisionDaysAndTotal(latestInvoice, offersCalculation, serviceProvisionsMap, true);

        BigDecimal totalInvoiceAmount = latestInvoice.getEventAmount()
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal totalInvoiceDays = (new BigDecimal(ChronoUnit.DAYS.between(latestInvoice.getBillStartDate(), latestInvoice.getBillEndDate())))
                .setScale(OffersConstants.DECIMAL_PLACES_IN_DAYS, RoundingMode.HALF_UP);

        if (OffersUtil.isAnyServiceProvisionWithNoHistory(serviceProvisions)) {
            throw new ServiceException(OffersCalculatorErrorCodes.PLAN_NOT_POSSIBLE_NO_BILLS);
        }

        //calculate ADC for each service Provision
        serviceProvisions = calculateAverageDailyCharge(serviceProvisions, OffersConstants.DECIMAL_PLACES_SIX);
        offersCalculation.setServiceProvisions(serviceProvisions);
        ServiceProvision serviceProvisionWithHighestDays = getServiceProvisionWithHighestDays(serviceProvisions);
        BigDecimal averageDailyChargeServiceProvisionLevel = getAverageDailyChargeFromServiceProvision(serviceProvisions, OffersConstants.DECIMAL_PLACES_SIX);
        BigDecimal averageDailyChargeInvoiceLevel = totalInvoiceAmount.divide(totalInvoiceDays, OffersConstants.DECIMAL_PLACES_SIX, RoundingMode.HALF_UP);

        basePeriodCalculation.setAverageDailyCharge(averageDailyChargeServiceProvisionLevel);
        basePeriodCalculation.setAverageDailyChargeInvoiceLevel(averageDailyChargeInvoiceLevel);
        basePeriodCalculation.setAverageDailyChargeServiceProvisionLevel(averageDailyChargeServiceProvisionLevel);
        basePeriodCalculation.setBillPeriodEndDate(latestBillEndDate);
        basePeriodCalculation.setBillPeriodStartDate(latestBillStartDate);
        basePeriodCalculation.setNumberOfDaysinBasePeriod(serviceProvisionWithHighestDays.getDays());
        basePeriodCalculation.setNumberOfInvoices(BigDecimal.ONE);
        basePeriodCalculation.setTotalInvoiceAmount(totalInvoiceAmount);
        basePeriodCalculation.setTotalInvoiceDays(totalInvoiceDays);
        log.debug("OffersCalc: set BasePeriodCalculation: {}", basePeriodCalculation);
        return basePeriodCalculation;
    }

    private void issueWarningOrErrorIfNoHistory(final OffersCalculation offersCalculation) throws ServiceException {
        String accountBrand = offersCalculation.getOffersCalculationRequest().getAccountBrand();
        if (accountBrand.equalsIgnoreCase(AccountBrand.SEVERN_TRENT.getAccountBrand())
                || accountBrand.equalsIgnoreCase(AccountBrand.HD_HOUSE_HOLD.getAccountBrand())) {
            offersCalculation.getWarnings().add(OffersCalculatorWarnings.WARNING_NO_HISTORY);
        } else {
            log.warn(
                    "HD Non-Household account without billing history - Please drop to Target to create payment arrangement");
            throw new ServiceException(OffersCalculatorErrorCodes.HD_NON_HOUSEHOLD_ACCOUNT_WITH_NO_BILLING_HISTORY);
        }
    }

    private BasePeriodCalculation getBasePeriodCalculation(final OffersCalculation offersCalculation) throws ServiceException {
        Budget budget = offersCalculation.getBudget();
        BasePeriodCalculation basePeriodCalculation = new BasePeriodCalculation();
        offersCalculation.getBudget().setBasePeriodCalculation(basePeriodCalculation);
        List<Invoice> pastOneYearInvoices = budget.getInvoices();
        if (CollectionUtils.isEmpty(pastOneYearInvoices)) {
            issueWarningOrErrorIfNoHistory(offersCalculation);
            return basePeriodCalculation;
        }

        // Sort invoices by bill start date
        log.debug("OffersCalc: sorting invoices into start date order. Invoice count={}", pastOneYearInvoices.size());
        pastOneYearInvoices.sort(Comparator.comparing(Invoice::getBillStartDate));

        pastOneYearInvoices = pastOneYearInvoices.stream()
                .map(invoice -> {
                    invoice.setCalculationStatus(OffersConstants.CALCULATION_STATUS_SUBSEQUENT_ELIGIBLE);
                    return invoice;
                })
                .collect(Collectors.toList());

        Invoice oldestInvoice = pastOneYearInvoices.get(0);
        oldestInvoice.setCalculationStatus(OffersConstants.CALCULATION_STATUS_FIRST_ELIGIBLE);
        LocalDate oldestBillStartDate = oldestInvoice.getBillStartDate();
        LocalDate latestBillEndDate = pastOneYearInvoices.get(pastOneYearInvoices.size() - 1).getBillEndDate();
        warnBasedOnOldestBillStartDate(oldestBillStartDate, offersCalculation);

        List<ServiceProvision> serviceProvisions = offersCalculation.getServiceProvisions();
        Map<String, ServiceProvision> serviceProvisionsMap = getServiceProvisionsMap(serviceProvisions);

        //For each invoice line, update the serviceProvision with total and days.
        pastOneYearInvoices.forEach(invoice ->
                updateServiceProvisionDaysAndTotal(invoice, offersCalculation, serviceProvisionsMap, false)
        );

        BigDecimal totalInvoiceAmount = pastOneYearInvoices.stream()
                .map(Invoice::getEventAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal totalInvoiceDays = pastOneYearInvoices.stream()
                .map(invoice -> new BigDecimal(ChronoUnit.DAYS.between(invoice.getBillStartDate(), invoice.getBillEndDate())))
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(OffersConstants.DECIMAL_PLACES_IN_DAYS, RoundingMode.HALF_UP);

        //Add warning and carry on. as we can calculate averageDailycharge for the rest of service provisions.
        // For HD Accounts with No_History, this code will be never reached.
        if (OffersUtil.isAnyServiceProvisionWithNoHistory(serviceProvisions)) {
            issueWarningOrErrorIfNoHistory(offersCalculation);
        }
        //calculate ADC for each service Provision
        serviceProvisions = calculateAverageDailyCharge(serviceProvisions, OffersConstants.DECIMAL_PLACES);
        offersCalculation.setServiceProvisions(serviceProvisions);
        ServiceProvision serviceProvisionWithHighestDays = getServiceProvisionWithHighestDays(serviceProvisions);
        BigDecimal averageDailyChargeServiceProvisionLevel = getAverageDailyChargeFromServiceProvision(serviceProvisions, OffersConstants.DECIMAL_PLACES);
        BigDecimal averageDailyChargeInvoiceLevel = totalInvoiceAmount.divide(totalInvoiceDays, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

        basePeriodCalculation.setAverageDailyCharge(averageDailyChargeServiceProvisionLevel);
        basePeriodCalculation.setAverageDailyChargeInvoiceLevel(averageDailyChargeInvoiceLevel);
        basePeriodCalculation.setAverageDailyChargeServiceProvisionLevel(averageDailyChargeServiceProvisionLevel);
        basePeriodCalculation.setBillPeriodEndDate(latestBillEndDate);
        basePeriodCalculation.setBillPeriodStartDate(oldestBillStartDate);
        basePeriodCalculation.setNumberOfDaysinBasePeriod(serviceProvisionWithHighestDays.getDays());
        basePeriodCalculation.setNumberOfInvoices(BigDecimal.valueOf(pastOneYearInvoices.size()));
        basePeriodCalculation.setTotalInvoiceAmount(totalInvoiceAmount);
        basePeriodCalculation.setTotalInvoiceDays(totalInvoiceDays);
        log.debug("OffersCalc: set BasePeriodCalculation: {}", basePeriodCalculation);
        return basePeriodCalculation;
    }

    // The "highest" number of days is set in the basePeriodCalculation
    // this will usually be correct as people start and end all the service provisions at the same time...
    private ServiceProvision getServiceProvisionWithHighestDays(final List<ServiceProvision> serviceProvisions) {
        return serviceProvisions.stream()
                .max(Comparator.comparing(ServiceProvision::getDays))
                .orElseThrow(() -> new STWBusinessException(
                        "No ServiceProvision's found, so unable to find one with higher number of days"));
    }

    private BigDecimal getAverageDailyChargeFromServiceProvision(final List<ServiceProvision> serviceProvisions, final int decimalPlaces) {
        return serviceProvisions.stream()
                .map(ServiceProvision::getAverageDailyCharge)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(decimalPlaces, RoundingMode.HALF_UP);
    }

    private void updateServiceProvisionDaysAndTotal(final Invoice invoice, final OffersCalculation offersCalculation, final Map<String, ServiceProvision> serviceProvisionsByNumMap, boolean isUnmeasured) {
        invoice.getInvoiceLines().forEach(invoiceLine -> {
            String propertyAndServiceProvisionNum = invoiceLine.getPropertyAndServiceProvisionNum();
            ServiceProvision serviceProvision = serviceProvisionsByNumMap.get(propertyAndServiceProvisionNum);
            if (serviceProvision != null) {
                BigDecimal subPeriodChargeAmount = invoiceLine.getSubPeriodChargeAmount().setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                BigDecimal serviceProvisionTotal = serviceProvision.getTotal().add(subPeriodChargeAmount).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                serviceProvision.setTotal(serviceProvisionTotal);
                LocalDate billSubPeriodStartDate = invoiceLine.getBillSubPeriodStartDate();
                LocalDate applicableBillPeriodEndDate = invoiceLine.getApplicableBillPeriodEndDate();
                BigDecimal invoiceLineDaysBetween = new BigDecimal(ChronoUnit.DAYS.between(billSubPeriodStartDate, applicableBillPeriodEndDate));
                serviceProvision.setDays(serviceProvision.getDays().add(invoiceLineDaysBetween).setScale(OffersConstants.DECIMAL_PLACES_IN_DAYS, RoundingMode.HALF_UP));
                if (!isUnmeasured && !(serviceProvision.getServiceProvisionBudgetFromBills().get(OffersConstants.FIRST_SERVICE_PROVISION_BUDGET).getAccruedStartDate() != null
                        && serviceProvision.getServiceProvisionBudgetFromBills().get(OffersConstants.FIRST_SERVICE_PROVISION_BUDGET).getAccruedStartDate().isAfter(invoiceLine.getBillPeriodEndDate()))) {

                    populateAccruedStartDateForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromBills(), invoiceLine.getBillPeriodEndDate());

                }
                log.debug("OffersCalc: calculating values for a Service Provision: {}", serviceProvision.toString());
            } else {
                WarningDTO warningDTO = OffersCalculatorWarnings.WARNING_NO_ACTIVE_SERVICE_PROVISIONS_FOUND();
                StringBuilder sb = new StringBuilder(warningDTO.getDescription());
                sb.append(", invoiceNum=").append(invoice.getInvoiceNum());
                sb.append(", serviceProvisionNum=").append(propertyAndServiceProvisionNum);
                sb.append(", invoiceLine.combinedNum=").append(invoiceLine.getCombinedNum());
                warningDTO.setDescription(sb.toString());
                offersCalculation.getWarnings().add(warningDTO);
                log.warn(sb.toString());
            }
        });
    }

    private List<ServiceProvision> calculateAverageDailyCharge(final List<ServiceProvision> serviceProvisions, final int decimalPlaces) {
        return serviceProvisions.stream()
                .map(serviceProvision -> {
                    if (serviceProvision.getDays().signum() == 1) {//Some service provisions may not have history.
                        BigDecimal averageDailyCharge = serviceProvision.getTotal().divide(serviceProvision.getDays(), decimalPlaces, RoundingMode.HALF_UP);
                        populateAverageDailyChargeForServiceProvisionBudgets(serviceProvision.getServiceProvisionBudgetFromBills(), averageDailyCharge);
                    }
                    return serviceProvision;
                }).collect(Collectors.toList());
    }

    private void warnBasedOnOldestBillStartDate(final LocalDate oldestBillStartDate, final OffersCalculation offersCalculation) {
        LocalDate oneYearAgo = offersCalculation.getTargetDate().minus(1, ChronoUnit.YEARS);
        if (oldestBillStartDate.isAfter(oneYearAgo)) {
            log.debug("OffersCalc: oldest invoice is less than one year old");
            offersCalculation.getWarnings().add(OffersCalculatorWarnings.WARNING_LESS_THAN_ONE_YEAR_HISTORY);
        }

        LocalDate twoMonthsAgo = offersCalculation.getTargetDate().minus(2, ChronoUnit.MONTHS);
        if (oldestBillStartDate.isAfter(twoMonthsAgo)) {
            log.debug("OffersCalc: oldest invoice is less than 2 months old");
            offersCalculation.getWarnings().add(OffersCalculatorWarnings.WARNING_LESS_THAN_MINIMUM_HISTORY);
        }
    }

    private Map<String, ServiceProvision> getServiceProvisionsMap(final List<ServiceProvision> serviceProvisions) {
        return serviceProvisions.stream()
                .collect(Collectors.toMap(ServiceProvision::getPropertyAndServiceProvisionNum, Function.identity()));
    }
}
