package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.model.calculator.offers.PreferredPayment;

import java.util.List;

public interface OfferGeneratorPreferredPayment {
    boolean addPreferredPaymentOffers(final OffersCalculation offersCalculation, final List<PreferredPayment> preferredPaymentIncrements) throws ServiceException;
}
