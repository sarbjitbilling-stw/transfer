package uk.co.stwater.model.calculator.offers;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import uk.co.stwater.api.core.model.BaseModel;

@Entity()
@Table(name="WSS_PAYMENT_PLANS")
public class PaymentPlan extends BaseModel<Long> {
    public static final String SERVICE_TYPE_UNMEASURED = "Unmeasured";
    public static final String PLAN_VARIANT_BDS = "BDS";
    public static final String ARREARS_NO = "N";
    public static final String ARREARS_YES = "Y";

	private String offerId; //Offer ID
	private String offerDescription; //Offer Desciption	
	private String serviceType; //Service Type	
	private String arrears; //Arrears	
	private int offerLevel; //Offer Level	
	private String planType; //Plan Type	
	private String paymentFrequency; //Payment Frequency	
	private String paymentMethod; //Payment Method	
	private BigDecimal length = BigDecimal.ZERO; //Length
	private BigDecimal variantAmount = BigDecimal.ZERO; //Variant Amount
	private String planVariant; //Plan Variant	
	private String reconciliationMethodCode; //reconciliationMethodCode	
	private String conditional; //Conditional Flag
	private String active; //Active Flag
	private int month;
	private String monthName;
	private String includeForecast;
	
	@Column(nullable=false)
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	
	@Column(nullable=false)
	public String getOfferDescription() {
		return offerDescription;
	}
	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}
	
	@Column(nullable=false)
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	@Column(nullable=false)
	public int getOfferLevel() {
		return offerLevel;
	}
	public void setOfferLevel(int offerLevel) {
		this.offerLevel = offerLevel;
	}
	
	@Column(nullable=false)
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	
	@Column(nullable=false)
	public String getPaymentFrequency() {
		return paymentFrequency;
	}
	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}
	
	@Column(nullable=false)
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	@Column(nullable=false)
	public BigDecimal getLength() {
		return length;
	}
	public void setLength(BigDecimal length) {
		this.length = length;
	}
	
	@Column(nullable=false)
	public BigDecimal getVariantAmount() {
		return variantAmount;
	}
	public void setVariantAmount(BigDecimal variantAmount) {
		this.variantAmount = variantAmount;
	}
	
	@Column(nullable=false)
	public String getPlanVariant() {
		return planVariant;
	}
	public void setPlanVariant(String planVariant) {
		this.planVariant = planVariant;
	}
	
	@Column(nullable=false)
	public String getReconciliationMethodCode() {
		return reconciliationMethodCode;
	}
	public void setReconciliationMethodCode(String reconciliationMethodCode) {
		this.reconciliationMethodCode = reconciliationMethodCode;
	}
	
	@Column(nullable=false)
	public String getArrears() {
		return arrears;
	}
	public void setArrears(String arrears) {
		this.arrears = arrears;
	}
	
	@Column(nullable=false)
	public String getConditional() {
		return conditional;
	}
	public void setConditional(String conditional) {
		this.conditional = conditional;
	}

	@Column(nullable=false)
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}

	@Column
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}

	@Column
	public String getMonthName() {
		return monthName;
	}
	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}

	@Column
	public String getIncludeForecast() {
		return includeForecast;
	}
	public void setIncludeForecast(String includeForecast) {
		this.includeForecast = includeForecast;
	}

}
