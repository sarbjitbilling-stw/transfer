package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.core.error.ErrorCode;

public class OffersCalculatorErrorCodes {
    public static final ErrorCode INVALID_REQUEST = new ErrorCode("OFFERS001",
            "Must enter a valid request. Account number, legal entity, payment method, frequency and valid Account Brand are mandatory.");
    public static final ErrorCode ASSESSED_ACCOUNT_INVALID = new ErrorCode("OFFERS002",
            "Please complete the Assessed calculator before proceeding to create Regular Payments for your customer");

    public static final ErrorCode MIXED_MEASURED_INDICATORS = new ErrorCode("OFFERS003",
            "We cannot create a plan as this account has a mixture of Measured & Unmeasured services. Please use Bill Query to determine the correct Services.");
    public static final ErrorCode NO_MEASURED_INDICATORS = new ErrorCode("OFFERS004",
            "We cannot create a plan as this account does not have the correct services in place. Please use Bill Query to determine the correct Services.");
    public static final ErrorCode INVALID_MEASURED_INDICATOR = new ErrorCode("OFFERS005",
            "We cannot create a plan as this account does not have the correct services in place. Please use Bill Query to determine the correct Services.");
    public static final ErrorCode PLAN_NOT_POSSIBLE = new ErrorCode("OFFERS006",
            "We cannot create a plan for this account as nothing is owed. Please check that the plan forecast is correct, and whether your customer owes enough to require a plan, or may be due a refund.");
    public static final ErrorCode PLAN_NOT_POSSIBLE_NO_BILLS = new ErrorCode("OFFERS007",
            "No billing history has been found for your customer. Please use Bill Query to review their bill history.");
    public static final ErrorCode INVALID_REQUEST_PREFERRED_PAYMENT_DAYS = new ErrorCode("OFFERS008",
            "Invalid request: preferred payment date and day must match up");
    public static final ErrorCode INVALID_PAYMENT_PLANS_FREQUENCY = new ErrorCode("OFFERS009",
            "Invalid Payment Plans DB Values : Payment Plans invalid frequency code. ");
    public static final ErrorCode FIRST_INSTALLMENT_ERROR = new ErrorCode("OFFERS010",
            "One installment plan not allowed as plan amount do not match first installment");
    public static final ErrorCode INVALID_NO_OF_INSTALLMENTS = new ErrorCode("OFFERS011",
            "No of installments cannot be less than 1.");
    public static final ErrorCode ONE_INSTALLMENT_PLAN_NOT_ALLOWED = new ErrorCode("OFFERS012",
            "One installment plan not allowed for PPC or Flex");
    public static final ErrorCode OFFER_EXCEEDED_MAX_FLEX_REDUCTION = new ErrorCode("OFFERS013",
            "Offer exceeded maximum flex reduction");
    public static final ErrorCode UNMEASURED_WITH_FORECAST_NOT_SUPPORTED = new ErrorCode("OFFERS014",
            "Un-measured with forecast as input is currently not supported");
    public static final ErrorCode INVALID_REQUEST_NEGATIVE_UPFRONT = new ErrorCode("OFFERS015",
            "Invalid request: Negative upfront not allowed");
    public static final ErrorCode INVALID_REQUEST_NEGATIVE_PREFERRED_PAYMENT = new ErrorCode("OFFERS016",
            "Invalid request: Negative Preferred payment not allowed");
    public static final ErrorCode NO_STANDARD_OFFER_GENERATED = new ErrorCode("OFFERS017",
            "Unexpected Error: No standard offer generated.");

    public static final ErrorCode STD_PREFERRED_PAYMENT_INCREMENT_NOT_CONFIGURED = new ErrorCode("OFFERS020",
            "Database configuration: Standard Preferred payment increment not configured for given frequency.");
    public static final ErrorCode ALL_MEASURED_FLEX_OFFERS_NOT_GENERATED = new ErrorCode("OFFERS021",
            "Unexpected Error: All measured Flex offers not generated");

    public static final ErrorCode ALL_PPC_OFFERS_NOT_GENERATED = new ErrorCode("OFFERS023",
            "Unexpected Error: All PPC offers not generated");

    public static final ErrorCode INVALID_REQUEST_NEGATIVE_1ST_INSTALLMENT = new ErrorCode("OFFERS025",
            "Invalid request: Negative first installment not allowed");
    public static final ErrorCode INVALID_REQUEST_STANDARD_PREFERRED_PAYMENT_NOT_ALLOWED = new ErrorCode("OFFERS026",
            "Invalid request: Standard preferred payment not allowed");
    public static final ErrorCode INVALID_REQUEST_FLEX_PREFERRED_PAYMENT_NOT_ALLOWED = new ErrorCode("OFFERS027",
            "Invalid request: Flex preferred payment not allowed");

    protected static ErrorCode STANDARD_PREFERRED_PAYMENT_AMOUNT_TOO_HIGH() {
        return new ErrorCode("OFFERS019",
                "This preferred payment amount is too high. Please update to a value that is less than %s");
    }

    protected static ErrorCode STD_PREFERRED_PAYMENT_LESS_THAN_STD_OFFER() {
        return new ErrorCode("OFFERS018",
                "This preferred payment amount is too low. Please update to a value that is greater than %s");
    }

    //FLEX PPC
    protected static ErrorCode FLEX_PREFERRED_PAYMENT_NOT_BETWEEN_FLEX6_AND_FLEX1() {
        return new ErrorCode("OFFERS022",
                "This preferred payment amount is outside the range of the standard and flex values. Please enter a value between %s and %s, or return to standard plan or to a PPC as appropriate.");
    }

    //PPC PP: BILLING AGENT
    protected static ErrorCode PPC_PREFERRED_PAYMENT_NOT_BETWEEN_PPC1_AND_SMALLEST_FLEX() {
        return new ErrorCode("OFFERS032",
                "This preferred payment amount is outside the range between the lowest flex value and PPC1. Please enter a value between %s and %s or refer to IOC if your customer wishes to pay less than the PPC1 value");
    }

    //PPC PP: BILLING AGENT - Assessed
    protected static ErrorCode PPC_PREFERRED_PAYMENT_FOR_ASSESSED_NOT_BETWEEN_PPC1_AND_STANDARD() {
        return new ErrorCode("OFFERS032B",
                "This preferred payment amount is outside the range between the standard value and PPC1. Please enter a value between %s and %s or refer to IOC if your customer wishes to pay less than the PPC1 value");
    }

    ////PPC PP: BILLING AGENT
    protected static ErrorCode BILLING_AGENT_PPC_PREFERRED_NOT_ALLOWED_AS_PPC1_IS_GREATER_THAN_SMALLEST_FLEX() {
        return new ErrorCode("OFFERS033",
                "Preferred payment value exceeds the lowest value available in the flex. Please go back to flex payments and enter the preferred payment amount there.");
    }

    ////PPC PP: BILLING AGENT - For Assesssed
    protected static ErrorCode BILLING_AGENT_PPC_PREFERRED_FOR_ASSESSED_NOT_ALLOWED_AS_PPC1_IS_GREATER_THAN_STANDARD() {
        return new ErrorCode("OFFERS033B",
                "Preferred payment value exceeds the standard value. Please go back to standard plan and enter the preferred payment amount there.");
    }

    //PPC PP : IOC AGENT
    protected static ErrorCode IOC_AGENT_PPC_PREFERRED_PAYMENT_MUST_BE_BETWEEN_PPC8_AND_SMALLEST_FLEX_OR_PPC1_OR_PPC2() {
        return new ErrorCode("OFFERS034",
                "This preferred payment amount is outside the range between the lowest flex value and PPC8. Please enter a value between %s and %s or refer to the Care & Assistance team if you think your customer should apply for Social Tariffs");
    }

    //PPC PP : IOC AGENT - Assessed
    protected static ErrorCode IOC_AGENT_PPC_PREFERRED_PAYMENT_FOR_ASSESSED_MUST_BE_BETWEEN_PPC8_AND_STANDARD_OR_PPC1_OR_PPC2() {
        return new ErrorCode("OFFERS034B",
                "This preferred payment amount is outside the range between the standard value and PPC8. Please enter a value between %s and %s or refer to the Care & Assistance team if you think your customer should apply for Social Tariffs");
    }

    //PPC PP
    protected static ErrorCode PPC_PREFERRED_PAYMENT_CURRENTLY_EXIST() {
        return new ErrorCode("OFFERS035",
                "This preferred payment value is already available, please select it in the table below.");
    }

    protected static final ErrorCode NO_VALID_OFFERS = new ErrorCode("OFFERS030",
            "No valid offers");

    public static final ErrorCode ALL_UNMEASURED_FLEX_OFFERS_NOT_GENERATED = new ErrorCode("OFFERS031",
            "Unexpected Error: All unmeasured Flex offers not generated");

    public static final ErrorCode MISMATCH_IN_PROPERTY_TYPE_AND_ACCOUNT_DEBT_CLASS = new ErrorCode("OFFERS036",
            "Cannot determine Uplift. Possible mismatch in property type and Account Debt Class");

    public static final ErrorCode INVALID_BUDGET_PLAN_TYPE = new ErrorCode("OFFERS037",
            "Invalid Payment Plans DB Values : Payment Plans invalid Budget Plan Type");

    protected static ErrorCode UNABLE_TO_DETERMINE_NUMBER_OF_INSTALLMENTS() {
        return new ErrorCode("OFFERS038", "Unable to determine number of installments for offer id %s");
    }

    public static final ErrorCode HD_NON_HOUSEHOLD_ACCOUNT_WITH_NO_BILLING_HISTORY = new ErrorCode("OFFERS039",
            "HD Non-Household account without billing history - Please drop to Target to create payment arrangement");

    // BDS Payment Plan
    public static final ErrorCode INVALID_BDS_REQUEST = new ErrorCode("OFFERS040",
            "BDS request must include numberOfMonths, monthlyTariffAmount and monthlyArrearsAmount fields");

}