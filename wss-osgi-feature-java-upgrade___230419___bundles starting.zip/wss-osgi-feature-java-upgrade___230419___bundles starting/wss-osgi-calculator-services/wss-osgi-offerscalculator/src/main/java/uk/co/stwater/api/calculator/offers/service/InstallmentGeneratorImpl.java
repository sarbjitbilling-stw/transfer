package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.inject.Named;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.Installment;
import uk.co.stwater.api.osgi.model.calculator.offers.MeasuredIndicator;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OfferPaymentFrequency;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@OsgiServiceProvider(classes = {InstallmentGenerator.class})
@Transactional
@Named
public class InstallmentGeneratorImpl implements InstallmentGenerator {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    public void calculateAndSetInstallments(final List<Offer> offers, final OffersCalculation offersCalculation, final BigDecimal maxMeasuredFlexVariantAmount) {
        log.debug("OffersCalc: calculating Installments for the Offers...");
        offers.forEach((offer) -> {
            List<Installment> installments = new ArrayList<>();
            if (OffersUtil.isMeasuredFlexOffer(offer)) {
                calculateAndSetInstallmentsForFlex(installments, offersCalculation, offer, RoundingMode.HALF_UP);
                validateFlexOffer(offersCalculation, maxMeasuredFlexVariantAmount, offer, installments);
            } else if (OffersUtil.isPPCOffer(offer)) {
                populateInstallmentAmountForPPC(installments, offersCalculation, offer);
                adjustPlanTotalAndArrearsWithForecastForPPC(installments, offersCalculation, offer);
            } else {
                populateInstallmentAmount(installments, offersCalculation, offer);
            }

            populateInstallmentDates(installments, offersCalculation, offer);
            populateArrearsAndForecast(installments, offer);
            offer.setInstallments(installments);
            populateInstallmentAvgDetails(installments, offer);
            recalculatePotentialUnderpayment(offer);
        });
    }

    @Override
    public void addPreferredPaymentInstallments(final OffersCalculation offersCalculation) {
        Optional<Offer> stdPreferredPaymentOfferOptional = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getOfferId().contains(OffersConstants.PREFERRED_PAYMENT_STANDARD_IDENTIFIER))
                .findFirst();

        stdPreferredPaymentOfferOptional.ifPresent(stdPreferredPaymentOffer ->
                adjustValuesForPreferredPayment(offersCalculation, stdPreferredPaymentOffer, offersCalculation.getOffersCalculationRequest().getPreferredPaymentStandard())
        );

        Optional<Offer> flexPreferredPaymentOfferOptional = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getOfferId().contains(OffersConstants.PREFERRED_PAYMENT_FLEX_IDENTIFIER))
                .findFirst();
        flexPreferredPaymentOfferOptional.ifPresent(flexPreferredPaymentOffer ->
                adjustValuesForPreferredPayment(offersCalculation, flexPreferredPaymentOffer, offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex())
        );

        Optional<Offer> ppcPreferredPaymentOfferOptional = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getOfferId().contains(OffersConstants.PREFERRED_PAYMENT_PPC_IDENTIFIER))
                .findFirst();
        ppcPreferredPaymentOfferOptional.ifPresent(ppcPreferredPaymentOffer ->
                adjustValuesForPreferredPayment(offersCalculation, ppcPreferredPaymentOffer, offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC())
        );

    }

    @Override
    public void removeDuplicateMeasuredFlexOffers(final OffersCalculation offersCalculation) {
        if (offersCalculation.isMeasured()) {
            List<Offer> offerList = offersCalculation.getOffers().stream()
                    .filter(offer -> OffersUtil.isMeasuredFlexOffer(offer))
                    .collect(Collectors.toCollection(
                            () -> new TreeSet<>(Comparator.comparing(Offer::getPlanAmount))
                    ))
                    .stream()
                    .collect(Collectors.toList());
            offerList.addAll(offersCalculation.getOffers().stream()
                    .filter(offer -> !OffersUtil.isMeasuredFlexOffer(offer))
                    .collect(Collectors.toList()));

            offerList.sort(Comparator.comparing(Offer::getDisplayOrder));
            offersCalculation.setOffers(offerList);
        }
    }

    @Override
    public void checkOfferValidity(final OffersCalculation offersCalculation) {
        offersCalculation.getOffers().forEach(offer -> {
            boolean isInvalidOffer;
            if (OffersUtil.isBdsOffer(offer)) {
                isInvalidOffer = offer.getInstallments().stream()
                        .anyMatch(installment -> !isBdsInstallmentGreaterThanMinimumThreshold(installment));
            } else {
                isInvalidOffer = offer.getInstallments().stream()
                        .anyMatch(installment -> !isInstallmentGreaterThanMinimumThreshold(offer,
                                installment.getInstallmentAmount()));
            }

            if (!isInvalidOffer) {
                isInvalidOffer = !isNoOfInstallmentsHigherThanMinimumThreshold(offer);
            }

            if (isInvalidOffer) {
                offer.setValid(false);
            }
        });

        if (offersCalculation.getOffers().stream().noneMatch(Offer::isValid)) {
            throw new ServiceException(OffersCalculatorErrorCodes.NO_VALID_OFFERS);
        }
    }

    private boolean isInstallmentGreaterThanMinimumThreshold(final Offer offer, final BigDecimal installmentAmount) {
        String paymentFrequency = offer.getPaymentFrequency();
        if (paymentFrequency.equals(OfferPaymentFrequency.WEEKLY.getCode())) {
            return installmentAmount.compareTo(OffersConstants.MIN_WEEKLY_OR_FORTNIGHTLY_INSTALLMENT) > -1;
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            return installmentAmount.compareTo(OffersConstants.MIN_WEEKLY_OR_FORTNIGHTLY_INSTALLMENT) > -1;
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            return installmentAmount.compareTo(OffersConstants.MIN_MONTHLY_OR_FOUR_WEEKLY_INSTALLMENT) > -1;
        } else if (paymentFrequency.equals(OfferPaymentFrequency.MONTHLY.getCode())) {
            return installmentAmount.compareTo(OffersConstants.MIN_MONTHLY_OR_FOUR_WEEKLY_INSTALLMENT) > -1;
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }
    }

    private boolean isBdsInstallmentGreaterThanMinimumThreshold(Installment installment) {
        if (installment.getInstallmentAmount() == null) {
            throw new STWBusinessException("Installment amount is null");
        }

        return installment.getInstallmentAmount().compareTo(OffersConstants.MIN_BDS_INSTALLMENT) > -1;
    }

    private boolean isNoOfInstallmentsHigherThanMinimumThreshold(final Offer offer) {
        String paymentFrequency = offer.getPaymentFrequency();
        BigDecimal numOfInstallments = offer.getNumOfInstallments();
        if (paymentFrequency.equals(OfferPaymentFrequency.WEEKLY.getCode())) {
            return numOfInstallments.compareTo(OffersConstants.MIN_WEEKLY_NO_OF_INSTALLMENTS) > -1;
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            return numOfInstallments.compareTo(OffersConstants.MIN_FORTNIGHTLY_NO_OF_INSTALLMENTS) > -1;
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            return numOfInstallments.compareTo(OffersConstants.MIN_FOUR_WEEKLY_NO_OF_INSTALLMENTS) > -1;
        } else if (paymentFrequency.equals(OfferPaymentFrequency.MONTHLY.getCode())) {
            return numOfInstallments.compareTo(OffersConstants.MIN_MONTHLY_NO_OF_INSTALLMENTS) > -1;
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }
    }

    private void adjustValuesForPreferredPayment(final OffersCalculation offersCalculation, final Offer preferredPaymentOffer, final BigDecimal preferredPayment) {
        addPreferredPaymentInstallments(preferredPayment, offersCalculation, preferredPaymentOffer);
        populateInstallmentDates(preferredPaymentOffer.getInstallments(), offersCalculation, preferredPaymentOffer);
        populateArrearsAndForecast(preferredPaymentOffer.getInstallments(), preferredPaymentOffer);
        populateInstallmentAvgDetails(preferredPaymentOffer.getInstallments(), preferredPaymentOffer);
        recalculatePotentialUnderpayment(preferredPaymentOffer);
    }

    private void addPreferredPaymentInstallments(final BigDecimal preferredPaymentInstallment, final OffersCalculation offersCalculation, final Offer offer) {
        if (!CollectionUtils.isEmpty(offer.getInstallments())) {
            offer.getInstallments().clear();
        }

        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();

        //Assign all same installment.
        for (int i = 0; i < numberOfInstallments.intValue(); i++) {
            offer.getInstallments().add(createInstallment(preferredPaymentInstallment));
        }

        if (firstInstallmentAmount.signum() == 1) {
            offer.getInstallments().get(0).setInstallmentAmount(firstInstallmentAmount);
        }
    }

    private void recalculatePotentialUnderpayment(final Offer offer) {
        BigDecimal potentialUnderPayment = offer.getBaseForecast().subtract(offer.getForecast())
                .add(offer.getBaseAccrued()).subtract(offer.getAccrued())
                .add(offer.getBaseArrears().getTotalArrears()).subtract(offer.getArrears().getTotalArrears())
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

        offer.setPotentialUnderPayment(potentialUnderPayment);
    }

    private void validateFlexOffer(final OffersCalculation offersCalculation, final BigDecimal maxMeasuredFlexVariantAmount, final Offer offer, final List<Installment> installments) {
        if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.MEASURED.getTargetCode())) {
            if (!validateMeasuredFlexIsWithInMaxRange(offer, maxMeasuredFlexVariantAmount)) {
                revertPlanTotalAndForecastAndAccruedForFlex(offer);
                installments.clear();//Clear them as they will be added in the calculateAndSetInstallmentsForFlex
                calculateAndSetInstallmentsForFlex(installments, offersCalculation, offer, RoundingMode.CEILING);//With Higher installments, hence RoundingMode.CEILING
                if (!validateMeasuredFlexIsWithInMaxRange(offer, maxMeasuredFlexVariantAmount)) {
                    throw new ServiceException(OffersCalculatorErrorCodes.OFFER_EXCEEDED_MAX_FLEX_REDUCTION);
                }
            }
        }
    }

    private boolean validateMeasuredFlexIsWithInMaxRange(final Offer offer, final BigDecimal maxMeasuredFlexVariantAmount) {
        BigDecimal baseAccruedAndForecast = offer.getBaseAccrued().add(offer.getBaseForecast());
        BigDecimal accruedAndForecast = offer.getAccrued().add(offer.getForecast());
        BigDecimal currentFlexReduction = baseAccruedAndForecast.subtract(accruedAndForecast).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        BigDecimal permittedMaxFlexReduction = baseAccruedAndForecast.multiply(maxMeasuredFlexVariantAmount).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        return permittedMaxFlexReduction.compareTo(currentFlexReduction) >= 0;
    }

    private void calculateAndSetInstallmentsForFlex(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer, final RoundingMode roundingMode) {
        populateInstallmentAmountForFlex(installments, offersCalculation, offer, roundingMode);
        adjustPlanTotalAndForecastForFlex(installments, offersCalculation, offer);
    }

    private void warnIfOnlyOneInstallmentForFlexAndPPC() {
        throw new ServiceException(OffersCalculatorErrorCodes.ONE_INSTALLMENT_PLAN_NOT_ALLOWED);
    }

    private void populateInstallmentAmountForFlex(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer, final RoundingMode roundingMode) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        if (numberOfInstallments.compareTo(new BigDecimal(OffersConstants.NO_OF_INSTALLMENTS_IS_TWO)) < 0) {
            warnIfOnlyOneInstallmentForFlexAndPPC();
        }
        BigDecimal offerPlanAmount = offer.getPlanAmount();
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        BigDecimal installmentAmount = getRoundingModeForFlex(offer,
                offerPlanAmount.divide(numberOfInstallments, OffersConstants.DECIMAL_PLACES_FOUR, RoundingMode.HALF_UP),
                roundingMode);
        if (firstInstallmentAmount.signum() == 1) {
            installmentAmount = getRoundingModeForFlex(offer,
                    (offerPlanAmount.subtract(firstInstallmentAmount)).divide((numberOfInstallments.subtract(BigDecimal.ONE)),
                            OffersConstants.DECIMAL_PLACES_FOUR, RoundingMode.HALF_UP),
                    roundingMode);

        }

        //Assign all same installment.
        for (int i = 0; i < numberOfInstallments.intValue(); i++) {
            installments.add(createInstallment(installmentAmount));
        }

        if (firstInstallmentAmount.signum() == 1) {
            installments.get(0).setInstallmentAmount(firstInstallmentAmount);
        }
    }

    private void populateInstallmentAmountForPPC(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        if (numberOfInstallments.compareTo(new BigDecimal(OffersConstants.NO_OF_INSTALLMENTS_IS_TWO)) < 0) {
            warnIfOnlyOneInstallmentForFlexAndPPC();
        }
        BigDecimal offerPlanAmount = offer.getPlanAmount();
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        BigDecimal installmentAmount = offerPlanAmount.divide(numberOfInstallments, OffersConstants.NEAREST_POUND, RoundingMode.CEILING);
        if (firstInstallmentAmount.signum() == 1) {
            installmentAmount = (offerPlanAmount.subtract(firstInstallmentAmount))
                    .divide((numberOfInstallments.subtract(BigDecimal.ONE))
                            , OffersConstants.NEAREST_POUND, RoundingMode.HALF_UP);

        }

        //Assign all same installment.
        for (int i = 0; i < numberOfInstallments.intValue(); i++) {
            installments.add(createInstallment(installmentAmount));
        }

        if (firstInstallmentAmount.signum() == 1) {
            installments.get(0).setInstallmentAmount(firstInstallmentAmount);
        }
    }

    private void adjustPlanTotalAndForecastForFlex(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        adjustPlanTotalForFlexAndPPC(installments, offersCalculation, offer);
        BigDecimal adjustedForecast = offer.getPlanAmount().subtract(offer.getArrears().getTotalArrears()).subtract(offer.getAccrued())
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

        offer.setForecast(adjustedForecast);
    }

    private void adjustPlanTotalAndArrearsWithForecastForPPC(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        adjustPlanTotalForFlexAndPPC(installments, offersCalculation, offer);
        if (offer.getArrears().getTotalArrears().signum() > -1) {
            BigDecimal adjustedArrears = offer.getPlanAmount().subtract(offer.getForecast()).subtract(offer.getAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            OffersUtil.adjustArrearsAndForecastForPPC(offer, adjustedArrears);
        } else {//Account in credit
            BigDecimal adjustedForecast = offer.getPlanAmount().subtract(offer.getArrears().getTotalArrears()).subtract(offer.getAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            offer.setForecast(adjustedForecast);
        }
    }

    private Installment createInstallment(final BigDecimal installmentAmount) {
        Installment installment = new Installment();
        installment.setInstallmentAmount(installmentAmount);
        return installment;
    }

    private void ifOnlyOneInstallment(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal offerPlanAmount = offer.getPlanAmount();
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        if (firstInstallmentAmount.signum() == 1 && firstInstallmentAmount.compareTo(offerPlanAmount) != 0) {
            throw new ServiceException(OffersCalculatorErrorCodes.FIRST_INSTALLMENT_ERROR);
        }
        installments.add(createInstallment(offerPlanAmount));
    }

    private void ifOnlyTwoInstallments(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        BigDecimal offerPlanAmount = offer.getPlanAmount();
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        BigDecimal secondInstallment;
        if (firstInstallmentAmount.signum() == 1) {
            secondInstallment = offerPlanAmount.subtract(firstInstallmentAmount).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else {
            secondInstallment = offerPlanAmount.divide(numberOfInstallments, OffersConstants.DECIMAL_PLACES, RoundingMode.FLOOR);//GET LOWER SECOND INSTALLMENT
            firstInstallmentAmount = offerPlanAmount.subtract(secondInstallment).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        }

        installments.add(createInstallment(firstInstallmentAmount));
        installments.add(createInstallment(secondInstallment));
    }

    private void ifLessThan3Installments(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        switch (numberOfInstallments.intValue()) {
            case 1:
                ifOnlyOneInstallment(installments, offersCalculation, offer);
                break;
            case 2:
                ifOnlyTwoInstallments(installments, offersCalculation, offer);
                break;
            default:
                throw new ServiceException(OffersCalculatorErrorCodes.INVALID_NO_OF_INSTALLMENTS);
        }
    }

    private void populateInstallmentAmount(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        if (numberOfInstallments.compareTo(new BigDecimal(OffersConstants.NO_OF_INSTALLMENTS_IS_THREE)) < 0) {
            ifLessThan3Installments(installments, offersCalculation, offer);
        } else {
            populateIfThreeOrMoreInstallments(installments, offersCalculation, offer);
        }
    }

    private void populateIfThreeOrMoreInstallments(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        BigDecimal offerPlanAmount = offer.getPlanAmount();
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        BigDecimal installmentAmount = offerPlanAmount.divide(numberOfInstallments, OffersConstants.DECIMAL_PLACES, RoundingMode.FLOOR);//GET LOWER INSTALLMENTS.
        if (firstInstallmentAmount.signum() == 1) {
            installmentAmount = (offerPlanAmount.subtract(firstInstallmentAmount))
                    .divide(numberOfInstallments.subtract(BigDecimal.ONE), OffersConstants.DECIMAL_PLACES, RoundingMode.FLOOR);
        }

        //Assign all same installment.
        for (int i = 0; i < numberOfInstallments.intValue(); i++) {
            installments.add(createInstallment(installmentAmount));
        }

        if (firstInstallmentAmount.signum() == 1) {
            installments.get(0).setInstallmentAmount(firstInstallmentAmount);
            BigDecimal totalExceptFirstAndSecondInstallment = installmentAmount.multiply(numberOfInstallments.subtract(new BigDecimal("2")));
            BigDecimal adjustedInstallmentAmount = offerPlanAmount.subtract(firstInstallmentAmount).subtract(totalExceptFirstAndSecondInstallment)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

            installments.get(1).setInstallmentAmount(adjustedInstallmentAmount);
        } else {
            BigDecimal totalExceptFirstInstallment = installmentAmount.multiply(numberOfInstallments.subtract(BigDecimal.ONE));
            BigDecimal adjustedInstallmentAmount = offerPlanAmount.subtract(totalExceptFirstInstallment)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            installments.get(0).setInstallmentAmount(adjustedInstallmentAmount);
        }
    }

    private void populateInstallmentDates(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        LocalDate originalInstallmentDate = (offersCalculation.getOffersCalculationRequest()
                .getPreferredPaymentDate() != null)
                ? offersCalculation.getOffersCalculationRequest().getPreferredPaymentDate()
                : offersCalculation.getTargetDate();

        LocalDate adjustedInstallmentDate = OffersUtil.adjustForPreferredPaymentDay(offersCalculation,
                originalInstallmentDate, offer);

        //1st Installment
        Installment installment = installments.get(0);
        offer.setStartDate(adjustedInstallmentDate);
        installment.setExpectedPaymentDate(adjustedInstallmentDate);

        //Start from 2nd installment.
        for (int i = 1; i < installments.size(); i++) {
            installment = installments.get(i);
            originalInstallmentDate = getIncrementedInstallmentDate(originalInstallmentDate, offer);
            adjustedInstallmentDate = OffersUtil.adjustForPreferredPaymentDay(offersCalculation, originalInstallmentDate, offer);
            installment.setExpectedPaymentDate(adjustedInstallmentDate);
        }

        //final Installment additional setters.
        installment = installments.get(installments.size() - 1);
        offer.setEndDate(installment.getExpectedPaymentDate());
        offer.setPreferredPayDay(offersCalculation.getOffersCalculationRequest().getPreferredPaymentDay());
    }

    private void populateArrearsAndForecast(final List<Installment> installments, final Offer offer) {
        BigDecimal arrears = offer.getArrears().getTotalArrears();
        for (Installment installment : installments) {
            if (arrears.signum() == 1) {
                if (arrears.compareTo(installment.getInstallmentAmount()) >= 0) {
                    installment.setInstallmentArrearsAmount(installment.getInstallmentAmount());
                } else {
                    installment.setInstallmentArrearsAmount(arrears);
                }
                arrears = arrears.subtract(installment.getInstallmentArrearsAmount())
                        .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                installment.setInstallmentForecastAmount(installment.getInstallmentAmount().subtract(installment.getInstallmentArrearsAmount())
                        .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));
            } else {
                installment.setInstallmentArrearsAmount(BigDecimal.ZERO);
                installment.setInstallmentForecastAmount(installment.getInstallmentAmount());
            }

        }
    }

    private void populateInstallmentAvgDetails(final List<Installment> installments, final Offer offer) {
        if (CollectionUtils.isNotEmpty(installments)) {
            BigDecimal avgArrearsAmount = installments.stream()
                    .map(Installment::getInstallmentArrearsAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            avgArrearsAmount = avgArrearsAmount.divide(BigDecimal.valueOf(installments.size()), OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            offer.setInstallmentArrearsAmount(avgArrearsAmount);

            BigDecimal avgForecastAndAccrued = installments.stream()
                    .map(Installment::getInstallmentForecastAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            avgForecastAndAccrued = avgForecastAndAccrued.divide(BigDecimal.valueOf(installments.size()), OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            offer.setInstallmentForecastAmount(avgForecastAndAccrued);

            offer.setInstallmentAmount(offer.getInstallmentArrearsAmount().add(offer.getInstallmentForecastAmount()).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));
        }
    }

    private void adjustPlanTotalForFlexAndPPC(final List<Installment> installments, final OffersCalculation offersCalculation, final Offer offer) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        BigDecimal numberOfAvgInstallments = numberOfInstallments;
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        if (firstInstallmentAmount.signum() == 1) {
            numberOfAvgInstallments = numberOfInstallments.subtract(BigDecimal.ONE);
        }

        BigDecimal installmentAmount = installments.get(1).getInstallmentAmount();//avoid the firstInstallment.
        BigDecimal adjustedOfferPlanAmount = firstInstallmentAmount.add((numberOfAvgInstallments.multiply(installmentAmount)))
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        offer.setPlanAmount(adjustedOfferPlanAmount);
    }

    private void revertPlanTotalAndForecastAndAccruedForFlex(final Offer offer) {
        BigDecimal forecast = offer.getBaseForecast();
        BigDecimal accrued = offer.getBaseAccrued();

        BigDecimal variantAmount = offer.getVariantAmount();
        BigDecimal forecastReduction = forecast.multiply(variantAmount);
        BigDecimal accruedReduction = accrued.multiply(variantAmount);
        forecast = forecast.subtract(forecastReduction).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        accrued = accrued.subtract(accruedReduction).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        offer.setForecast(forecast);
        offer.setAccrued(accrued);

        BigDecimal planAmount = offer.getArrears().getTotalArrears().add(offer.getForecast()).add(offer.getAccrued())
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

        offer.setPlanAmount(planAmount);
    }

    private LocalDate getIncrementedInstallmentDate(final LocalDate installmentDate, final Offer offer) {
        LocalDate nextInstallmentDate;
        String paymentFrequency = offer.getPaymentFrequency();
        if (paymentFrequency.equals(OfferPaymentFrequency.WEEKLY.getCode())) {
            nextInstallmentDate = installmentDate.plus(1, ChronoUnit.WEEKS);
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            nextInstallmentDate = installmentDate.plus(2, ChronoUnit.WEEKS);
        } else if (paymentFrequency.equals(OfferPaymentFrequency.MONTHLY.getCode())) {
            nextInstallmentDate = installmentDate.plus(1, ChronoUnit.MONTHS);
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            nextInstallmentDate = installmentDate.plus(4, ChronoUnit.WEEKS);
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }
        return nextInstallmentDate;
    }

    private BigDecimal getRoundingModeForFlex(final Offer offer, final BigDecimal value, final RoundingMode roundingMode) {
        String paymentFrequency = offer.getPaymentFrequency();
        if (paymentFrequency.equals(OfferPaymentFrequency.WEEKLY.getCode())) {
            return OffersUtil.roundingTo10Pence(value, roundingMode);
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            return OffersUtil.roundingTo50Pence(value, roundingMode);
        } else if (paymentFrequency.equals(OfferPaymentFrequency.MONTHLY.getCode())) {
            return OffersUtil.roundingToOnePound(value, roundingMode);
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            return OffersUtil.roundingToOnePound(value, roundingMode);
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }
    }

}
