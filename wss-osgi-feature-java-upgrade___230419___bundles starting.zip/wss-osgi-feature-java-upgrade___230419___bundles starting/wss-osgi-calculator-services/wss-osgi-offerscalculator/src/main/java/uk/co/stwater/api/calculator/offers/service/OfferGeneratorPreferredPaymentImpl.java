package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.inject.Named;
import javax.transaction.Transactional;

import org.apache.commons.beanutils.BeanUtils;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.Arrears;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanOfferLevel;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanVariant;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.model.calculator.offers.PreferredPayment;

@OsgiServiceProvider(classes = {OfferGeneratorPreferredPayment.class})
@Transactional
@Named
public class OfferGeneratorPreferredPaymentImpl implements OfferGeneratorPreferredPayment {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    public boolean addPreferredPaymentOffers(final OffersCalculation offersCalculation, final List<PreferredPayment> preferredPaymentIncrements) throws ServiceException {
        boolean isPreferredPaymentOfferAdded = false;

        if (isPreferredPaymentOfferRequested(offersCalculation)) {
            populateAvgInstallmentExcludingFirstPymtForOffers(offersCalculation);
        }

        if (offersCalculation.getOffersCalculationRequest().getPreferredPaymentStandard().signum() == 1 &&
                offersCalculation.isMeasured()) {
            addPreferredPaymentStandardOffer(offersCalculation, preferredPaymentIncrements);
            isPreferredPaymentOfferAdded = true;
        }
        if (offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex().signum() == 1 &&
                offersCalculation.isMeasured()) {
            addPreferredPaymentFlexOffer(offersCalculation);
            isPreferredPaymentOfferAdded = true;
        }
        if (offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC().signum() == 1) {
            addPreferredPaymentPPCOffer(offersCalculation);
            isPreferredPaymentOfferAdded = true;
        }

        if (isPreferredPaymentOfferAdded) {
            sortOffers(offersCalculation);
        }
        return isPreferredPaymentOfferAdded;
    }

    private boolean isPreferredPaymentOfferRequested(final OffersCalculation offersCalculation) {
        return offersCalculation.getOffersCalculationRequest().getPreferredPaymentStandard().signum() == 1 ||
                offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex().signum() == 1 ||
                offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC().signum() == 1;

    }

    private void populateAvgInstallmentExcludingFirstPymtForOffers(final OffersCalculation offersCalculation) {
        offersCalculation.getOffers().forEach((offer) ->
                populateAvgInstallmentExcludingFirstPymt(offer, offersCalculation)
        );
    }

    private void populateAvgInstallmentExcludingFirstPymt(final Offer offer, final OffersCalculation offersCalculation) {
        BigDecimal avgInstallmentExcludingFirstPymt;
        if (offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount().signum() == 1) {
            //This is required as 2nd Installment might have the rounding correction. from 3rd Installment, all will be same.
            avgInstallmentExcludingFirstPymt = offer.getPlanAmount()
                    .subtract(offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount())
                    .divide((offer.getNumOfInstallments().subtract(BigDecimal.ONE)), OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else {
            avgInstallmentExcludingFirstPymt = offer.getInstallmentAmount();
        }
        offer.setAvgInstallmentExcludingFirstPymt(avgInstallmentExcludingFirstPymt);
    }

    private void sortOffers(final OffersCalculation offersCalculation) {
        offersCalculation.getOffers().sort(Comparator.comparing(Offer::getDisplayOrder));
    }

    private void addPreferredPaymentPPCOffer(final OffersCalculation offersCalculation) {
        boolean result = isPreferredPaymentPPCOfferValid(offersCalculation);

        boolean userHasIOCRole = offersCalculation.getOffersCalculationRequest().isUserHasIOCRole();
        Offer offerToClone;
        if (userHasIOCRole) {

            if (is3MonthPPCPreferredPaymentRequired(offersCalculation)) {
                offerToClone = getClosest3MonthPPCOffer(offersCalculation, offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC());
            } else {
                offerToClone = getClosestPPC12MonthOffer(offersCalculation);//get PPC1
            }

        } else {
            offerToClone = getClosestPPC12MonthOffer(offersCalculation);//get PPC1
        }

        if (result) {
            Offer offerPreferredPayment = new Offer();
            BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC();

            boolean isNewOfferAfterClonedOffer = offerToClone.getAvgInstallmentExcludingFirstPymt()
                    .compareTo(preferredPayment) > 0;

            try {
                BeanUtils.copyProperties(offerPreferredPayment, offerToClone);
            } catch (Exception e) {
                log.error("OfferGeneratorImpl: addPreferredPaymentPPCOffer, Error during clone Flex Offer");
                throw new STWTechnicalException("Error cloning flex offer", e);
            }

            offerPreferredPayment.setInstallments(new ArrayList<>());
            offerPreferredPayment.setOfferId(offerPreferredPayment.getOfferId().concat(OffersConstants.PREFERRED_PAYMENT_PPC_IDENTIFIER));
            offerPreferredPayment.setOfferDetail(offerPreferredPayment.getOfferDetail().concat(OffersConstants.PREFERRED_PAYMENT_PPC_IDENTIFIER));
            offerPreferredPayment.setPlanVariant(offerPreferredPayment.getPlanVariant().concat(OffersConstants.PREFERRED_PAYMENT_PPC_IDENTIFIER));
            if (isNewOfferAfterClonedOffer) {
                offerPreferredPayment.setDisplayOrder(offerPreferredPayment.getDisplayOrder() + OffersConstants.PREFERRED_PAYMENT_DISPLAY_ORDER_INCREMENT);
            } else {
                offerPreferredPayment.setDisplayOrder(offerPreferredPayment.getDisplayOrder() - OffersConstants.PREFERRED_PAYMENT_DISPLAY_ORDER_INCREMENT);
            }

            BigDecimal planAmount = getPlanTotalForPreferredPayment(offersCalculation, offerPreferredPayment, offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC());
            offerPreferredPayment.setPlanAmount(planAmount);

            BigDecimal adjustedArrears = planAmount.subtract(offerPreferredPayment.getForecast()).subtract(offerPreferredPayment.getAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

            Arrears arrears = new Arrears();
            arrears.setAccountArrears(adjustedArrears);
            arrears.setThirdPartyCharges(BigDecimal.ZERO);
            offerPreferredPayment.setArrears(arrears);
            offersCalculation.getOffers().add(offerPreferredPayment);
        }
    }

    private boolean is3MonthPPCPreferredPaymentRequired(final OffersCalculation offersCalculation) {
        Offer smallestFlexInstallmentOffer = getSmallestFlexOrStandardInstallmentOffer(offersCalculation);

        Optional<Offer> optionalOffer12MonthPPC1 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC1.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        Optional<Offer> optionalOfferPPC2 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC2.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        Optional<Offer> optionalOfferPPC8 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC8.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        if (!(optionalOffer12MonthPPC1.isPresent() && optionalOfferPPC2.isPresent() && optionalOfferPPC8.isPresent())) {
            throw new ServiceException(OffersCalculatorErrorCodes.ALL_PPC_OFFERS_NOT_GENERATED);
        }

        Offer offer12MonthPPC1 = optionalOffer12MonthPPC1.get();
        BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC();

        if (OffersUtil.isBetweenExclusivelyInGivenOrder(preferredPayment,
                offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt(),
                smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt())) {
            return false;//12 months

        } else {//all edge cases not covered.
            return true;//3 months
        }
    }

    private Offer getSmallestFlexOrStandardInstallmentOffer(final OffersCalculation offersCalculation) {
        if (offersCalculation.isMeasured()) {
            Optional<Offer> optionalOfferFlex6 = offersCalculation.getOffers().stream()
                    .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.FLEX6.getPlanVariant()))
                    .findFirst();
            if (!optionalOfferFlex6.isPresent()) {
                throw new ServiceException(OffersCalculatorErrorCodes.ALL_MEASURED_FLEX_OFFERS_NOT_GENERATED);
            }
            return optionalOfferFlex6.get();

        } else if (offersCalculation.isUnmeasured()) {
            Optional<Offer> smallestUnmeasuredOfferOptional = offersCalculation.getOffers().stream()
                    .filter(OffersUtil::isUnMeasuredFlexOffer)
                    .min(Comparator.comparing(Offer::getAvgInstallmentExcludingFirstPymt));

            if (!smallestUnmeasuredOfferOptional.isPresent()) {
                throw new ServiceException(OffersCalculatorErrorCodes.ALL_UNMEASURED_FLEX_OFFERS_NOT_GENERATED);
            }
            return smallestUnmeasuredOfferOptional.get();
        } else if (offersCalculation.isAssessed()) {
            Optional<Offer> standardOfferOptional = offersCalculation.getOffers().stream()
                    .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                    .findFirst();
            if (!standardOfferOptional.isPresent()) {
                throw new ServiceException(OffersCalculatorErrorCodes.NO_STANDARD_OFFER_GENERATED);
            }
            return standardOfferOptional.get();
        }

        throw new STWBusinessException("Unable to find smallest flex or standard installment offer");
    }

    private boolean isPreferredPaymentPPCOfferValid(final OffersCalculation offersCalculation) {
        boolean userHasIOCRole = offersCalculation.getOffersCalculationRequest().isUserHasIOCRole();
        if (userHasIOCRole) {
            return isPreferredPaymentPPCOfferValidForIOCAgent(offersCalculation);
        } else {
            return isPreferredPaymentPPCOfferValidForBillingAgent(offersCalculation);
        }
    }

    private boolean isPreferredPaymentPPCOfferValidForBillingAgent(final OffersCalculation offersCalculation) {
        if (isPreferredPaymentForPPC1Allowed(offersCalculation)) {
            return isEnteredPreferredPaymentForPPC1Allowed(offersCalculation);
        } else {
            Offer smallestFlexInstallmentOffer = getSmallestFlexOrStandardInstallmentOffer(offersCalculation);

            if (offersCalculation.isAssessed()) {
                throw new ServiceException(OffersUtil.getErrorMessage(
                        OffersCalculatorErrorCodes.BILLING_AGENT_PPC_PREFERRED_FOR_ASSESSED_NOT_ALLOWED_AS_PPC1_IS_GREATER_THAN_STANDARD(),
                        OffersUtil.getCurrencyFormat(smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt())));
            } else {
                throw new ServiceException(OffersUtil.getErrorMessage(
                        OffersCalculatorErrorCodes.BILLING_AGENT_PPC_PREFERRED_NOT_ALLOWED_AS_PPC1_IS_GREATER_THAN_SMALLEST_FLEX(),
                        OffersUtil.getCurrencyFormat(smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt())));
            }

        }
    }

    private boolean isPreferredPaymentForPPC1Allowed(final OffersCalculation offersCalculation) {
        Optional<Offer> optionalOffer12MonthPPC1 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC1.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        if (!(optionalOffer12MonthPPC1.isPresent())) {
            throw new ServiceException(OffersCalculatorErrorCodes.ALL_PPC_OFFERS_NOT_GENERATED);
        }

        Offer offer12MonthPPC1 = optionalOffer12MonthPPC1.get();
        Offer smallestFlexInstallmentOffer = getSmallestFlexOrStandardInstallmentOffer(offersCalculation);

        BigDecimal minAllowedValue = offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt();
        BigDecimal maxAllowedValue = smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt();
        if (smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt().compareTo(offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt()) < 1) {//If smallest Flex is greater than ppc1, then PPC1 can go till smallestFlexAmount
            maxAllowedValue = minAllowedValue;
        }

        return maxAllowedValue.compareTo(minAllowedValue) > 0;
    }

    private boolean isEnteredPreferredPaymentForPPC1Allowed(final OffersCalculation offersCalculation) {
        Optional<Offer> optionalOffer12MonthPPC1 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC1.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        if (!(optionalOffer12MonthPPC1.isPresent())) {
            throw new ServiceException(OffersCalculatorErrorCodes.ALL_PPC_OFFERS_NOT_GENERATED);
        }

        Offer offer12MonthPPC1 = optionalOffer12MonthPPC1.get();
        BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC();

        Offer smallestFlexInstallmentOffer = getSmallestFlexOrStandardInstallmentOffer(offersCalculation);

        BigDecimal minAllowedValue = offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt();
        BigDecimal maxAllowedValue = smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt();

        warnIfPreferredPaymentIsSameAsPPC1(preferredPayment,
                offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt()
        );

        if (!OffersUtil.isBetweenExclusivelyInGivenOrder(preferredPayment,
                minAllowedValue,
                maxAllowedValue
        )) {
            if (offersCalculation.isAssessed()) {
                throw new ServiceException(OffersUtil.getErrorMessage(
                        OffersCalculatorErrorCodes.PPC_PREFERRED_PAYMENT_FOR_ASSESSED_NOT_BETWEEN_PPC1_AND_STANDARD(),
                        OffersUtil.getCurrencyFormat(offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt()),
                        OffersUtil.getCurrencyFormat(smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt())));
            } else {
                throw new ServiceException(OffersUtil.getErrorMessage(
                        OffersCalculatorErrorCodes.PPC_PREFERRED_PAYMENT_NOT_BETWEEN_PPC1_AND_SMALLEST_FLEX(),
                        OffersUtil.getCurrencyFormat(offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt()),
                        OffersUtil.getCurrencyFormat(smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt())));
            }

        } else {
            return true;
        }

    }

    private boolean isPreferredPaymentPPCOfferValidForIOCAgent(final OffersCalculation offersCalculation) {
        Offer smallestFlexInstallmentOffer = getSmallestFlexOrStandardInstallmentOffer(offersCalculation);

        Optional<Offer> optionalOffer12MonthPPC1 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC1.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        Optional<Offer> optionalOfferPPC2 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC2.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        Optional<Offer> optionalOfferPPC8 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC8.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        if (!(optionalOffer12MonthPPC1.isPresent() && optionalOfferPPC2.isPresent() && optionalOfferPPC8.isPresent())) {
            throw new ServiceException(OffersCalculatorErrorCodes.ALL_PPC_OFFERS_NOT_GENERATED);
        }

        Offer offer12MonthPPC1 = optionalOffer12MonthPPC1.get();
        Offer offerPPC2 = optionalOfferPPC2.get();
        Offer offerPPC8 = optionalOfferPPC8.get();

        BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentPPC();

        warnIfPreferredPaymentIsSameAsPPC1(preferredPayment,
                offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt()
        );

        warnIfPreferredPaymentIsSameAsPPC2OrPPC8(preferredPayment,
                offerPPC2.getAvgInstallmentExcludingFirstPymt(),
                offerPPC8.getAvgInstallmentExcludingFirstPymt()
        );

        BigDecimal minAllowedValue = offerPPC8.getAvgInstallmentExcludingFirstPymt();
        ArrayList<BigDecimal> maxAllowedValueList = new ArrayList<>();
        maxAllowedValueList.add(smallestFlexInstallmentOffer.getAvgInstallmentExcludingFirstPymt());
        maxAllowedValueList.add(offer12MonthPPC1.getAvgInstallmentExcludingFirstPymt());
        maxAllowedValueList.add(offerPPC2.getAvgInstallmentExcludingFirstPymt());

        BigDecimal maxAllowedValue = maxAllowedValueList.stream()
                .max(Comparator.naturalOrder())
                .orElseThrow(() -> new STWBusinessException("Unable to find max allowed value"));

        if (!OffersUtil.isBetweenExclusivelyInGivenOrder(preferredPayment,
                minAllowedValue,
                maxAllowedValue
        )) {
            if (offersCalculation.isAssessed()) {
                throw new ServiceException(OffersUtil.getErrorMessage(
                        OffersCalculatorErrorCodes.IOC_AGENT_PPC_PREFERRED_PAYMENT_FOR_ASSESSED_MUST_BE_BETWEEN_PPC8_AND_STANDARD_OR_PPC1_OR_PPC2(),
                        OffersUtil.getCurrencyFormat(minAllowedValue),
                        OffersUtil.getCurrencyFormat(maxAllowedValue)));
            } else {
                throw new ServiceException(OffersUtil.getErrorMessage(
                        OffersCalculatorErrorCodes.IOC_AGENT_PPC_PREFERRED_PAYMENT_MUST_BE_BETWEEN_PPC8_AND_SMALLEST_FLEX_OR_PPC1_OR_PPC2(),
                        OffersUtil.getCurrencyFormat(minAllowedValue),
                        OffersUtil.getCurrencyFormat(maxAllowedValue)));
            }

        }
        return true;
    }

    private void warnIfPreferredPaymentIsSameAsPPC1(BigDecimal preferredPayment, BigDecimal offer12MonthPPC1Amount) {
        if (preferredPayment.compareTo(offer12MonthPPC1Amount) == 0) {
            throw new ServiceException(OffersCalculatorErrorCodes.PPC_PREFERRED_PAYMENT_CURRENTLY_EXIST());
        }
    }

    private void warnIfPreferredPaymentIsSameAsPPC2OrPPC8(BigDecimal preferredPayment, BigDecimal offerPPC2Amount, BigDecimal offerPPC8Amount) {
        if (preferredPayment.compareTo(offerPPC2Amount) == 0 ||
                preferredPayment.compareTo(offerPPC8Amount) == 0) {
            throw new ServiceException(OffersCalculatorErrorCodes.PPC_PREFERRED_PAYMENT_CURRENTLY_EXIST());
        }
    }

    private void addPreferredPaymentFlexOffer(final OffersCalculation offersCalculation) {
        boolean result = isPreferredPaymentFlexOfferValid(offersCalculation);
        Offer offerToClone = getClosestFlexOffer(offersCalculation, offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex());

        if (result && offerToClone != null) {
            Offer offerPreferredPayment = new Offer();
            BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex();

            boolean isNewOfferAfterClonedOffer = offerToClone.getAvgInstallmentExcludingFirstPymt()
                    .compareTo(preferredPayment) > 0;

            try {
                BeanUtils.copyProperties(offerPreferredPayment, offerToClone);
            } catch (Exception e) {
                log.error("OfferGeneratorImpl: addPreferredPaymentFlexOffer, Error during clone Flex Offer");
                throw new STWTechnicalException("Failed to code flex offer", e);
            }

            offerPreferredPayment.setInstallments(new ArrayList<>());
            offerPreferredPayment.setOfferId(offerPreferredPayment.getOfferId().concat(OffersConstants.PREFERRED_PAYMENT_FLEX_IDENTIFIER));
            offerPreferredPayment.setOfferDetail(offerPreferredPayment.getOfferDetail().concat(OffersConstants.PREFERRED_PAYMENT_FLEX_IDENTIFIER));
            offerPreferredPayment.setPlanVariant(offerPreferredPayment.getPlanVariant().concat(OffersConstants.PREFERRED_PAYMENT_FLEX_IDENTIFIER));
            if (isNewOfferAfterClonedOffer) {
                offerPreferredPayment.setDisplayOrder(offerPreferredPayment.getDisplayOrder() + OffersConstants.PREFERRED_PAYMENT_DISPLAY_ORDER_INCREMENT);
            } else {
                offerPreferredPayment.setDisplayOrder(offerPreferredPayment.getDisplayOrder() - OffersConstants.PREFERRED_PAYMENT_DISPLAY_ORDER_INCREMENT);
            }

            BigDecimal planAmount = getPlanTotalForPreferredPayment(offersCalculation, offerPreferredPayment, offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex());

            offerPreferredPayment.setPlanAmount(planAmount);
            BigDecimal forecast = planAmount.subtract(offerPreferredPayment.getArrears().getTotalArrears()).subtract(offerPreferredPayment.getAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            offerPreferredPayment.setForecast(forecast);
            offersCalculation.getOffers().add(offerPreferredPayment);
        }
    }

    private static Predicate<Offer> isPPC3MonthsPredicate(final String paymentFrequency) {
        return offer -> OffersUtil.isPPC3MonthsOffer(offer)
                && offer.getPaymentFrequency().equalsIgnoreCase(paymentFrequency);
    }

    private Offer getClosestPPC12MonthOffer(final OffersCalculation offersCalculation) {
        Optional<Offer> optionalOffer12MonthPPC1 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.PPC1.getPlanVariant())
                        && offer.getPaymentFrequency().equalsIgnoreCase(offersCalculation.getOffersCalculationRequest().getPaymentFrequency()))
                .findFirst();

        if (!(optionalOffer12MonthPPC1.isPresent())) {
            throw new ServiceException(OffersCalculatorErrorCodes.ALL_PPC_OFFERS_NOT_GENERATED);
        }

        return optionalOffer12MonthPPC1.get();
    }

    private Offer getClosest3MonthPPCOffer(final OffersCalculation offersCalculation, final BigDecimal preferredPayment) {
        Predicate<Offer> ppc3MonthsPredicate = isPPC3MonthsPredicate(offersCalculation.getOffersCalculationRequest().getPaymentFrequency());
        List<Offer> ppc3MonthsList = offersCalculation.getOffers().stream()
                .filter(ppc3MonthsPredicate)
                .map(offer -> {
                    offer.setProximityToPreferredPayment(offer.getAvgInstallmentExcludingFirstPymt().subtract(preferredPayment)
                            .abs()
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));

                    return offer;
                })
                .collect(Collectors.toList());

        Optional<Offer> optionalClosestOffer = ppc3MonthsList.stream()
                .min(Comparator.comparing(Offer::getProximityToPreferredPayment));

        if (optionalClosestOffer.isPresent()) {
            BigDecimal smallestProximity = optionalClosestOffer.get().getProximityToPreferredPayment();

            //there could be 2 offers with same proximity(+2 and -2), then select the offer with higher installment.
            Optional<Offer> optionalOfferToClone = ppc3MonthsList.stream()
                    .filter(offer -> offer.getProximityToPreferredPayment().compareTo(smallestProximity) == 0)
                    .max(Comparator.comparing(Offer::getAvgInstallmentExcludingFirstPymt));

            if (optionalOfferToClone.isPresent()) {
                return optionalOfferToClone.get();
            }
        }

        throw new STWBusinessException("Unable to find closest 2 month PPC offer");
    }

    private Offer getClosestFlexOffer(final OffersCalculation offersCalculation, final BigDecimal preferredPayment) {
        Predicate<Offer> flexPredicate = OffersUtil::isMeasuredFlexOffer;

        List<Offer> flexList = offersCalculation.getOffers().stream()
                .filter(flexPredicate)
                .map(offer -> {
                    offer.setProximityToPreferredPayment(offer.getAvgInstallmentExcludingFirstPymt().subtract(preferredPayment)
                            .abs()
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));

                    return offer;
                })
                .collect(Collectors.toList());

        Optional<Offer> optionalClosestOffer = flexList.stream()
                .min(Comparator.comparing(Offer::getProximityToPreferredPayment));

        if (optionalClosestOffer.isPresent()) {
            BigDecimal smallestProximity = optionalClosestOffer.get().getProximityToPreferredPayment();

            //there could be 2 offers with same proximity(+2 and -2), then select the offer with higher installment.
            Optional<Offer> optionalOfferToClone = flexList.stream()
                    .filter(offer -> offer.getProximityToPreferredPayment().compareTo(smallestProximity) == 0)
                    .max(Comparator.comparing(Offer::getAvgInstallmentExcludingFirstPymt));

            if (optionalOfferToClone.isPresent()) {
                return optionalOfferToClone.get();
            }
        }
        return null;
    }

    private boolean isPreferredPaymentFlexOfferValid(final OffersCalculation offersCalculation) {
        Optional<Offer> standardOfferOptional = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .findFirst();
        if (!standardOfferOptional.isPresent()) {
            throw new ServiceException(OffersCalculatorErrorCodes.NO_STANDARD_OFFER_GENERATED);
        }

        Optional<Offer> optionalOfferFlex6 = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getPlanVariant().equalsIgnoreCase(PaymentPlanVariant.FLEX6.getPlanVariant()))
                .findFirst();

        if (!optionalOfferFlex6.isPresent()) {
            throw new ServiceException(OffersCalculatorErrorCodes.ALL_MEASURED_FLEX_OFFERS_NOT_GENERATED);
        }

        Offer standardOffer = standardOfferOptional.get();
        Offer offerFlex6 = optionalOfferFlex6.get();
        BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentFlex();

        if (!OffersUtil.isBetweenExclusivelyInGivenOrder(preferredPayment,
                offerFlex6.getAvgInstallmentExcludingFirstPymt(),
                standardOffer.getAvgInstallmentExcludingFirstPymt()
        )) {

            throw new ServiceException(OffersUtil.getErrorMessage(
                    OffersCalculatorErrorCodes.FLEX_PREFERRED_PAYMENT_NOT_BETWEEN_FLEX6_AND_FLEX1(),
                    OffersUtil.getCurrencyFormat(offerFlex6.getAvgInstallmentExcludingFirstPymt()),
                    OffersUtil.getCurrencyFormat(standardOffer.getAvgInstallmentExcludingFirstPymt())
            ));
        }
        return true;
    }

    private void addPreferredPaymentStandardOffer(final OffersCalculation offersCalculation, final List<PreferredPayment> preferredPaymentIncrements) {
        Optional<Offer> standardOfferOptional = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .findFirst();
        if (!standardOfferOptional.isPresent()) {
            throw new ServiceException(OffersCalculatorErrorCodes.NO_STANDARD_OFFER_GENERATED);
        }
        Offer standardOffer = standardOfferOptional.get();
        boolean result = isPreferredPaymentStandardOfferValid(offersCalculation, standardOffer, preferredPaymentIncrements);
        if (result) {
            Offer offerPreferredPayment = new Offer();
            try {
                BeanUtils.copyProperties(offerPreferredPayment, standardOffer);
            } catch (Exception e) {
                log.error("OfferGeneratorImpl: addPreferredPaymentStandardOffer, Error during clone standard Offer");
                throw new STWTechnicalException("Failed to clone standard offer", e);
            }

            offerPreferredPayment.setInstallments(new ArrayList<>());
            offerPreferredPayment.setOfferId(offerPreferredPayment.getOfferId().concat(OffersConstants.PREFERRED_PAYMENT_STANDARD_IDENTIFIER));
            offerPreferredPayment.setOfferDetail(offerPreferredPayment.getOfferDetail().concat(OffersConstants.PREFERRED_PAYMENT_STANDARD_IDENTIFIER));

            offerPreferredPayment.setDisplayOrder(OffersConstants.DISPLAY_ORDER_INIT_VALUE_STANDARD);//set as Standard.
            standardOffer.setDisplayOrder(OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX);//Set as the 0% of Flex
            standardOffer.setGroup(PaymentPlanOfferLevel.FLEX.getOfferLevel());
            standardOffer.setPlanVariant(OffersConstants.PLAN_VARIANT_ZERO_PERCENTAGE_FLEX);//Set as the 0% of Flex

            BigDecimal planAmount = getPlanTotalForPreferredPayment(offersCalculation, offerPreferredPayment, offersCalculation.getOffersCalculationRequest().getPreferredPaymentStandard());
            offerPreferredPayment.setPlanAmount(planAmount);
            BigDecimal forecast = planAmount.subtract(offerPreferredPayment.getArrears().getTotalArrears()).subtract(offerPreferredPayment.getAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            offerPreferredPayment.setForecast(forecast);
            offersCalculation.getOffers().add(offerPreferredPayment);
        }
    }

    private BigDecimal getPlanTotalForPreferredPayment(final OffersCalculation offersCalculation, final Offer offer, final BigDecimal preferredPayment) {
        BigDecimal numberOfInstallments = offer.getNumOfInstallments();
        BigDecimal numberOfAvgInstallments = numberOfInstallments;
        BigDecimal firstInstallmentAmount = offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount();
        if (firstInstallmentAmount.signum() == 1) {
            numberOfAvgInstallments = numberOfInstallments.subtract(BigDecimal.ONE);
        }
        return firstInstallmentAmount.add((numberOfAvgInstallments.multiply(preferredPayment)))
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
    }

    private boolean isPreferredPaymentStandardOfferValid(final OffersCalculation offersCalculation, final Offer standardOffer, final List<PreferredPayment> preferredPaymentIncrements) {
        BigDecimal preferredPayment = offersCalculation.getOffersCalculationRequest().getPreferredPaymentStandard();

        if (preferredPayment.compareTo(standardOffer.getAvgInstallmentExcludingFirstPymt()) < 1) {
            throw new ServiceException(OffersUtil.getErrorMessage(OffersCalculatorErrorCodes.STD_PREFERRED_PAYMENT_LESS_THAN_STD_OFFER(),
                    OffersUtil.getCurrencyFormat(getAverageStandardPayment(offersCalculation, standardOffer))));
        }
        //check if installment increase is within range 25/weekly, 50/Fortnightly, 75/4-weekly or Monthly,
        if (!isPreferredPaymentStandardOfferInRange(standardOffer, offersCalculation.getOffersCalculationRequest().getPreferredPaymentStandard(), offersCalculation, preferredPaymentIncrements)) {
            BigDecimal maxAllowedStandardPreferredPayment = getMaxAllowedStandardPreferredPayment(standardOffer, offersCalculation, preferredPaymentIncrements);
            throw new ServiceException(OffersUtil.getErrorMessage(OffersCalculatorErrorCodes.STANDARD_PREFERRED_PAYMENT_AMOUNT_TOO_HIGH(),
                    OffersUtil.getCurrencyFormat(maxAllowedStandardPreferredPayment)));

        }
        return true;
    }

    private BigDecimal getAverageStandardPayment(final OffersCalculation offersCalculation, final Offer standardOffer) {
        if (offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount().signum() == 1) {
            //This is required as 2nd Installment will have the rounding correction. from 3rd Installment, all will be same.
            return standardOffer.getPlanAmount()
                    .subtract(offersCalculation.getOffersCalculationRequest().getFirstInstallmentAmount())
                    .divide((standardOffer.getNumOfInstallments().subtract(BigDecimal.ONE)), OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else {
            return standardOffer.getInstallmentAmount();
        }

    }

    private BigDecimal getMaxAllowedStandardPreferredPayment(final Offer standardOffer,
            final OffersCalculation offersCalculation, final List<PreferredPayment> preferredPaymentIncrements) {
        String paymentFrequency = standardOffer.getPaymentFrequency();
        BigDecimal maxAllowedIncrement = getStandardPreferredPaymentIncrement(preferredPaymentIncrements, paymentFrequency);
        BigDecimal averageStandardPayment = getAverageStandardPayment(offersCalculation, standardOffer);

        return averageStandardPayment.add(maxAllowedIncrement)
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
    }

    private boolean isPreferredPaymentStandardOfferInRange(final Offer standardOffer, final BigDecimal preferredPaymentStandard,
            final OffersCalculation offersCalculation, final List<PreferredPayment> preferredPaymentIncrements) {
        BigDecimal maxAllowedStandardPreferredPayment = getMaxAllowedStandardPreferredPayment(standardOffer, offersCalculation, preferredPaymentIncrements);
        return preferredPaymentStandard.compareTo(maxAllowedStandardPreferredPayment) < 1;
    }

    private BigDecimal getStandardPreferredPaymentIncrement(final List<PreferredPayment> preferredPaymentIncrements, final String paymentFrequency) {
        Optional<PreferredPayment> preferredPaymentOptional = preferredPaymentIncrements.stream()
                .filter(preferredPayment -> preferredPayment.getPaymentFrequency().equalsIgnoreCase(paymentFrequency))
                .findFirst();

        if (!preferredPaymentOptional.isPresent()) {
            throw new ServiceException(OffersCalculatorErrorCodes.STD_PREFERRED_PAYMENT_INCREMENT_NOT_CONFIGURED);
        }
        return preferredPaymentOptional.get().getMaxIncrement();
    }
}
