package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.calculator.offers.Arrears;
import uk.co.stwater.api.osgi.model.calculator.offers.BudgetPlanType;
import uk.co.stwater.api.osgi.model.calculator.offers.BudgetPlanTypes;
import uk.co.stwater.api.osgi.model.calculator.offers.BudgetUplift;
import uk.co.stwater.api.osgi.model.calculator.offers.MeasuredIndicator;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OfferPaymentFrequency;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.PayPlanType;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanConditional;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanIncludeForecast;
import uk.co.stwater.api.osgi.model.calculator.offers.ReconciliationMethod;
import uk.co.stwater.iib.client.api.bill.status.AccountBillStatusClient;
import uk.co.stwater.iib.client.api.bill.status.NextBillStatusResponse;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

@OsgiServiceProvider(classes = {OfferGenerator.class})
@Transactional
@Named
public class OfferGeneratorImpl implements OfferGenerator {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    @OsgiService
    private AccountBillStatusClient accountBillStatusClient;

    @Override
    public List<Offer> getOffers(final List<PaymentPlan> filteredPaymentPlans, final OffersCalculation offersCalculation) throws ServiceException {
        List<Offer> offers = new ArrayList<>();
        filteredPaymentPlans.forEach(paymentPlan -> {
            Offer offer = new Offer();
            offer.setGroup(paymentPlan.getOfferLevel());
            offer.setOfferId(paymentPlan.getOfferId());
            String budgetPlanTypeCode = paymentPlan.getPlanType().substring(0, 1);
            offer.setBudgetPlanType(new BudgetPlanType(null, budgetPlanTypeCode));
            offer.setPayPlanType(getPayPlanType(offersCalculation));
            offer.setConditionalFlag((paymentPlan.getConditional().equalsIgnoreCase(PaymentPlanConditional.YES.getCondition())));
            offer.setNumOfInstallments(calculateNumberOfInstallments(paymentPlan, offersCalculation));
            offer.setPlanVariant(paymentPlan.getPlanVariant());
            offer.setLengthInMonths(paymentPlan.getLength().intValue());
            offer.setDisplayOrder(getDisplayOrder(offer, offersCalculation));
            offer.setOfferDetail(paymentPlan.getOfferDescription());
            offer.setMonth(paymentPlan.getMonth());
            offer.setMonthName(paymentPlan.getMonthName());
            offer.setVariantAmount(paymentPlan.getVariantAmount());

            offer.setPlanVariant(paymentPlan.getPlanVariant());
            offer.setReconciliationMethod(
                    new ReconciliationMethod(null, paymentPlan.getReconciliationMethodCode()));
            offer.setPaymentMethod(paymentPlan.getPaymentMethod());
            offer.setPaymentFrequency(paymentPlan.getPaymentFrequency());
            offer.setUnmeasuredFutureStart(isUnmeasuredFutureStartPlan(paymentPlan));

            offer.setOriginalArrears(OffersUtil.getArrearsClone(offersCalculation.getOriginalArrears()));
            offer.setBaseArrears(OffersUtil.getArrearsClone(offersCalculation.getBaseArrears()));
            offer.setArrears(OffersUtil.getArrearsClone(offersCalculation.getBaseArrears()));
            populateForecastAndAccrued(offer, offersCalculation, paymentPlan);
            populateUplift(offer, offersCalculation, paymentPlan);

            adjustOfferForUnMeasured(offer, offersCalculation, paymentPlan);
            adjustOfferForMeasuredFlexReduction(offer, offersCalculation, paymentPlan);
            adjustOfferForPPC(offer, paymentPlan);

            BigDecimal planAmount = offer.getArrears().getTotalArrears().add(offer.getForecast()).add(offer.getAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            offer.setPlanAmount(planAmount);
            offers.add(offer);
        });

        return offers;
    }

    private String getPayPlanType(final OffersCalculation offersCalculation) {
        return offersCalculation.isArrearsPlan() ? PayPlanType.ARREARS.getPayPlanType() : PayPlanType.NONE.getPayPlanType();
    }

    private boolean isUnmeasuredFutureStartPlan(PaymentPlan paymentPlan) {
        boolean isUnmeasured = PaymentPlan.SERVICE_TYPE_UNMEASURED.equalsIgnoreCase(paymentPlan.getServiceType());
        boolean isNonArrearsPlan = PaymentPlan.ARREARS_NO.equalsIgnoreCase(paymentPlan.getArrears());

        return isUnmeasured && isNonArrearsPlan;
    }

    private void populateUplift(final Offer offer, final OffersCalculation offersCalculation, final PaymentPlan paymentPlan) {
        if (CollectionUtils.isNotEmpty(offersCalculation.getBudgetUplifts())) {
            Optional<BudgetUplift> budgetUpliftOptional;
            if (OffersUtil.isPPCPlan(paymentPlan)) {
                budgetUpliftOptional = offersCalculation.getBudgetUplifts().stream()
                        .filter(budgetUplift ->
                                budgetUplift.getBudgetPlanType().equalsIgnoreCase(BudgetPlanTypes.PPC.getCode())
                        ).findFirst();
            } else {
                budgetUpliftOptional = offersCalculation.getBudgetUplifts().stream()
                        .filter(budgetUplift ->
                                !budgetUplift.getBudgetPlanType().equalsIgnoreCase(BudgetPlanTypes.PPC.getCode())
                        ).findFirst();
            }

            budgetUpliftOptional.ifPresent(budgetUplift ->
                    offer.setUpliftedAccruedPercent(budgetUplift.getUplift())
            );
        }
    }

    private void populateForecastAndAccrued(final Offer offer, final OffersCalculation offersCalculation, final PaymentPlan paymentPlan) {
        if (OffersUtil.isPPCPlan(paymentPlan)) {
            offer.setOriginalForecast(offersCalculation.getOriginalForecastForPPC());
            offer.setOriginalAccrued(offersCalculation.getOriginalAccruedForPPC());

            offer.setBaseForecast(offersCalculation.getBaseForecastForPPC());
            offer.setBaseAccrued(offersCalculation.getBaseAccruedForPPC());

            offer.setForecast(offersCalculation.getBaseForecastForPPC());
            offer.setAccrued(offersCalculation.getBaseAccruedForPPC());
        } else {
            offer.setOriginalForecast(offersCalculation.getOriginalForecast());
            offer.setOriginalAccrued(offersCalculation.getOriginalAccrued());

            offer.setBaseForecast(offersCalculation.getBaseForecast());
            offer.setBaseAccrued(offersCalculation.getBaseAccrued());

            offer.setForecast(offersCalculation.getBaseForecast());
            offer.setAccrued(offersCalculation.getBaseAccrued());
        }
    }

    private void adjustOfferForMeasuredFlexReduction(final Offer offer, final OffersCalculation offersCalculation, final PaymentPlan paymentPlan) {
        if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.MEASURED.getTargetCode())
                && OffersUtil.isMeasuredFlexPlan(paymentPlan)) {
            BigDecimal variantAmount = paymentPlan.getVariantAmount();
            BigDecimal forecastReduction = offer.getBaseForecast().multiply(variantAmount);
            BigDecimal accruedReduction = offer.getBaseAccrued().multiply(variantAmount);
            BigDecimal forecast = offer.getBaseForecast().subtract(forecastReduction).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
            BigDecimal accrued = offer.getBaseAccrued().subtract(accruedReduction).setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

            offer.setForecast(forecast);
            offer.setAccrued(accrued);
        }
    }

    private void adjustOfferForPPC(final Offer offer, final PaymentPlan paymentPlan) {
        /*
         * BDS plans are treated as PPC in some places but in this case do not want to
         * adjust the forecast amounts as they will already be set to the length
         */
        if (OffersUtil.isPPCPlan(paymentPlan) && !OffersUtil.isBdsPlan(paymentPlan)) {

            //Change Original, Base and current Forecast based on the length.
            if (paymentPlan.getLength().compareTo(OffersConstants.PPC_LENGTH_TWELVE) != 0) {
                BigDecimal forecast = offer.getForecast().multiply(paymentPlan.getLength())
                        .divide(OffersConstants.PPC_LENGTH_TWELVE, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                offer.setForecast(forecast);
                offer.setBaseForecast(forecast);
                offer.setOriginalForecast(offer.getOriginalForecast().multiply(paymentPlan.getLength())
                        .divide(OffersConstants.PPC_LENGTH_TWELVE, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));

                BigDecimal accrued = offer.getAccrued().multiply(paymentPlan.getLength())
                        .divide(OffersConstants.PPC_LENGTH_TWELVE, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                offer.setBaseAccrued(accrued);
                offer.setOriginalAccrued(offer.getOriginalAccrued().multiply(paymentPlan.getLength())
                        .divide(OffersConstants.PPC_LENGTH_TWELVE, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));

                adjustBaseArrearsToBe3MonthsEquivalantIfNotInCredit(offer, paymentPlan);

            }

            // INC640983: For PPC set accrued to zero.
            offer.setAccrued(BigDecimal.ZERO);

            BigDecimal totalChargePaidTowardsArrears = calculateAmountFromWeeklyCharge(paymentPlan, offer.getNumOfInstallments());
            OffersUtil.adjustArrearsAndForecastForPPC(offer, totalChargePaidTowardsArrears);
        }
    }

    /**
     * Make only BaseArrears 3 months Equvalant. Original Arreas will be kept at 12 months.
     * 3Months Equivalant will wont be applied if the account is in Credit. (Negative balance)
     */
    private void adjustBaseArrearsToBe3MonthsEquivalantIfNotInCredit(final Offer offer, final PaymentPlan paymentPlan) {
        if (offer.getBaseArrears().getTotalArrears().signum() == 1) {
            Arrears adjustedArrears = OffersUtil.getArrearsClone(offer.getBaseArrears());
            adjustedArrears.setAccountArrears(adjustedArrears.getAccountArrears().multiply(paymentPlan.getLength())
                    .divide(OffersConstants.PPC_LENGTH_TWELVE, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));
            adjustedArrears.setThirdPartyCharges(adjustedArrears.getThirdPartyCharges().multiply(paymentPlan.getLength())
                    .divide(OffersConstants.PPC_LENGTH_TWELVE, OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP));
            offer.setBaseArrears(adjustedArrears);
        }
    }

    //By default Unmeasured accrued =0, and forecast = 0 (As forecast is included in arrears)
    //Note: Unmeasured Accrued is always zero.
    private void adjustOfferForUnMeasured(final Offer offer, final OffersCalculation offersCalculation, final PaymentPlan paymentPlan) {
        //make setOriginalForecast, & setOriginalAccrued also Zero if
        //1) If Unmeasured and NOT PaymentPlanIncludeForecast.YES
        //2) If Unmeasured and PaymentPlanIncludeForecast.YES   and Main Billing is completed (Except for PPC)
        if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.UNMEASURED.getTargetCode())
                && !includeForecastForUnmeasuredAccount(offersCalculation.getAccountNumber(), paymentPlan)) {

            offer.setOriginalForecast(BigDecimal.ZERO);
            offer.setBaseForecast(BigDecimal.ZERO);
            offer.setForecast(BigDecimal.ZERO);

            offer.setOriginalAccrued(BigDecimal.ZERO);
            offer.setBaseAccrued(BigDecimal.ZERO);
            offer.setAccrued(BigDecimal.ZERO);

        }
    }

    boolean includeForecastForUnmeasuredAccount(TargetAccountNumber accountNumber, PaymentPlan paymentPlan) {
        Optional<PaymentPlanIncludeForecast> includeForecastOpt = PaymentPlanIncludeForecast
                .fromIdentifier(paymentPlan.getIncludeForecast());

        if (includeForecastOpt.isPresent()) {
            PaymentPlanIncludeForecast includeForecast = includeForecastOpt.get();
            if (PaymentPlanIncludeForecast.YES == includeForecast) {
                return true;
            } else if (PaymentPlanIncludeForecast.RULE == includeForecast) {
                /*
                 * Main Billing happens during month of Feb and March, prior to 31 March. - as
                 * Billing Cycle batches. Once the main Billing happens, for Unmeasured Accounts
                 * the Account Balance will reflect the Forecast for the new year, Therefore
                 * should not add any Forecast.
                 */
                NextBillStatusResponse nextBillStatus = accountBillStatusClient.getNextBillStatus(accountNumber);

                return !nextBillStatus.isMainBilled();
            }
        }

        return false;
    }

    private int getDisplayOrder(final Offer offer, final OffersCalculation offersCalculation) {
        int initialValue = 0;
        int multiplier = 1;

        if (StringUtils.isEmpty(offer.getPlanVariant())) {
            if (offersCalculation.isMeasured()) {//Measured: empty is 0% flex
                initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX;
                multiplier = 0;
            } else if (offersCalculation.isUnmeasured()) {//Unmeasured: empty is End of SHORT Flex
                initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX;
                multiplier = offer.getLengthInMonths();
            } else if (offersCalculation.isAssessed()) { //Assessed: empty is default (no Flex)
                initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_STANDARD;
                multiplier = 0;
            } else if (offersCalculation.isArrearsPlan()) {//Arrears Payment Plans: empty is End of SHORT Flex
                initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX;
                multiplier = offer.getLengthInMonths();
            }

        } else if (OffersUtil.isMeasuredFlexOffer(offer)) {
            initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX;
            String str = offer.getPlanVariant().replaceAll("\\D+", "");
            multiplier = Integer.parseInt(str);
        } else if (OffersUtil.isPPCOffer(offer)) {
            initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_PPC;
            String str = offer.getPlanVariant().replaceAll("\\D+", "");
            multiplier = Integer.parseInt(str);
        } else if (offersCalculation.isUnmeasured() && (OffersUtil.isUnMeasuredShortOffer(offer) || OffersUtil.isUnMeasuredLongOffer(offer))) {
            initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX;
            multiplier = offer.getLengthInMonths();
        } else if (offersCalculation.isArrearsPlan() && (OffersUtil.isArrearsPlanFlexShortOffer(offer) || OffersUtil.isArrearsPlanFlexLongOffer(offer))) {//Very similar to unMeasured, but want to keep it separate, in case further distinctions occrur.
            initialValue = OffersConstants.DISPLAY_ORDER_INIT_VALUE_FLEX;
            multiplier = offer.getLengthInMonths();
        }
        return initialValue + multiplier * OffersConstants.DISPLAY_ORDER_MULTIPLIER;
    }

    @Override
    public List<PaymentPlan> getPaymentPlansBasedOnArrearsAndMonth(final List<PaymentPlan> paymentPlans, final OffersCalculation offersCalculation) {
        BigDecimal totalArrears = offersCalculation.getBaseArrears().getTotalArrears();
        boolean isCustomerInArrears = (totalArrears.signum() == 1);
        // January is 1
        int offersCalculationStartMonth = getStartDate(offersCalculation).getMonthValue();

        // For Measured/Assessed -
        // if there are arrears, only payment plans with "Arrears"="Y" are valid.
        // if there are NO arrears, only payment plans with "Arrears"="N" are valid.
        // For Unmeasured only -
        // if there are arrears, only payment plans with "Arrears"="Y" are valid.
        // if there are NO arrears, only payment plans with "Arrears"="N" are valid.
        // plans for different calculation months are not valid.
        return paymentPlans.stream()
                .filter(paymentPlan -> {
                    // only want the plans that match the customers arrears state
                    boolean isArrearsPaymentPlan = PaymentPlan.ARREARS_YES.equalsIgnoreCase(paymentPlan.getArrears());
                    return isCustomerInArrears == isArrearsPaymentPlan;
                }).filter(paymentPlan -> {
                    // for plans that specify a month make sure matches calculation month
                    // January is 1, 0 means not specified
                    int paymentPlanMonth = paymentPlan.getMonth();

                    if (paymentPlanMonth == 0) {
                        // include all payment plans that are not month specific
                        return true;
                    } else {
                        // only unmeasured plans will currently have non-zero month value
                        return offersCalculationStartMonth == paymentPlanMonth;
                    }
                }).collect(Collectors.toList());
    }

    private BigDecimal calculateAmountFromWeeklyCharge(final PaymentPlan paymentPlan, final BigDecimal numOfInstallments) {
        BigDecimal result;
        String paymentFrequency = paymentPlan.getPaymentFrequency();
        BigDecimal variantAmount = paymentPlan.getVariantAmount();
        if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.MONTHLY.getCode())) {
            result = variantAmount.multiply(numOfInstallments).multiply(OffersConstants.NO_OF_WEEKS_PER_MONTH)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            result = variantAmount.multiply(numOfInstallments).multiply(OffersConstants.NO_OF_WEEKS_PER_FORTNIGHT)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.WEEKLY.getCode())) {
            result = variantAmount.multiply(numOfInstallments)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            result = variantAmount.multiply(numOfInstallments).multiply(new BigDecimal("4"))
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        } else {
            result = variantAmount.multiply(numOfInstallments)
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        }
        log.debug("OfferGeneratorImpl: calculateAmountFromWeeklyCharge for paymentPlan {} and amount = {} ", paymentPlan.getOfferId(), result);
        return result;
    }

    private BigDecimal calculateNumberOfInstallments(final PaymentPlan paymentPlan, final OffersCalculation offersCalculation) throws ServiceException {
        String paymentFrequency = paymentPlan.getPaymentFrequency();
        //If monthly , always get the length.
        if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.MONTHLY.getCode())) {
            return paymentPlan.getLength();
        }

        //If PPC other frequencies, then get relative
        if (OffersUtil.isPPCPlan(paymentPlan)) {
            return calculateFixedNumberOfInstallments(paymentPlan);
        }

        //All other Measured, Assessed, ArrearsPlans will have fixed number Of installments
        if (offersCalculation.isMeasured() || offersCalculation.isAssessed() || offersCalculation.isArrearsPlan()) {
            return calculateFixedNumberOfInstallments(paymentPlan);
        } else if (offersCalculation.isUnmeasured()) {//UnMeasured Flex
            return calculateRelativeNumberOfInstallments(paymentPlan, offersCalculation, true);
        }
        throw new ServiceException(
                OffersUtil.getErrorMessage(OffersCalculatorErrorCodes.UNABLE_TO_DETERMINE_NUMBER_OF_INSTALLMENTS(), paymentPlan.getOfferId()));

    }

    private BigDecimal calculateRelativeNumberOfInstallments(final PaymentPlan paymentPlan, final OffersCalculation offersCalculation, boolean isUnmeasuredFlex) throws ServiceException {
        int result;
        LocalDate startDate = getStartDate(offersCalculation);
        int length = paymentPlan.getLength().intValue();
        String paymentFrequency = paymentPlan.getPaymentFrequency();

        if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            result = OffersUtil.calculateNumberOfInstallmentsRelatively(startDate, length, OffersConstants.WEEKS_IN_FOUR_WEEKLY, isUnmeasuredFlex);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            result = OffersUtil.calculateNumberOfInstallmentsRelatively(startDate, length, OffersConstants.WEEKS_IN_FORNIGHTLY, isUnmeasuredFlex);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.WEEKLY.getCode())) {
            result = OffersUtil.calculateNumberOfInstallmentsRelatively(startDate, length, OffersConstants.WEEKS_IN_WEEKLY, isUnmeasuredFlex);
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }
        return new BigDecimal(result);
    }

    private BigDecimal calculateFixedNumberOfInstallments(final PaymentPlan paymentPlan) throws ServiceException {
        BigDecimal result;
        String paymentFrequency = paymentPlan.getPaymentFrequency();
        BigDecimal length = paymentPlan.getLength();

        if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.MONTHLY.getCode())) {
            result = length;
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            result = OffersConstants.AVERAGE_NO_OF_DAYS_IN_MONTH.multiply(length).divide(OffersConstants.NO_OF_DAYS_IN_FOUR_WEEKLY_FREQUENCY, OffersConstants.DECIMAL_PLACES_IN_DAYS, RoundingMode.FLOOR);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            result = OffersConstants.AVERAGE_NO_OF_DAYS_IN_MONTH.multiply(length).divide(OffersConstants.NO_OF_DAYS_IN_FORTNIGHTLY_FREQUENCY, OffersConstants.DECIMAL_PLACES_IN_DAYS, RoundingMode.FLOOR);
        } else if (paymentFrequency.equalsIgnoreCase(OfferPaymentFrequency.WEEKLY.getCode())) {
            result = OffersConstants.AVERAGE_NO_OF_DAYS_IN_MONTH.multiply(length).divide(OffersConstants.NO_OF_DAYS_IN_WEEKLY_FREQUENCY, OffersConstants.DECIMAL_PLACES_IN_DAYS, RoundingMode.FLOOR);
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }

        return result;
    }

    private LocalDate getStartDate(final OffersCalculation offersCalculation) {
        return (offersCalculation.getOffersCalculationRequest()
                .getPreferredPaymentDate() != null)
                ? offersCalculation.getOffersCalculationRequest().getPreferredPaymentDate()
                : offersCalculation.getTargetDate();
    }

}
