package uk.co.stwater.api.calculator.offers.service;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import uk.co.stwater.api.osgi.model.calculator.offers.AccountEventStatus;
import uk.co.stwater.api.osgi.model.calculator.offers.Invoice;
import uk.co.stwater.api.osgi.model.calculator.offers.InvoiceLine;

import javax.inject.Named;
import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@OsgiServiceProvider(classes = {InvoiceAnalyser.class})
@Transactional
@Named
public class InvoiceAnalyserImpl implements InvoiceAnalyser {

    public InvoiceAnalyserImpl() {
    }

    @Override
    public List<InvoiceLine> getInvoiceLinesOfLatestMoveIn(final List<InvoiceLine> invoiceLines, final LocalDate oldestServiceStartDate) {
        if (oldestServiceStartDate == null) {
            return new ArrayList<>();
        }
        return invoiceLines.stream()
                .filter(invoiceLine -> OffersUtil.isEqualOrAfter(invoiceLine.getBillPeriodStartDate(), oldestServiceStartDate))
                .collect(Collectors.toList());

    }

    /**
     * @param allInvoices: invoices of past 99 months will be passed.
     * @return : Will return past one years, non cancelled invoices.
     * Note: Last one year is checked with reference to targetDate and invoice.BillStartDate.
     * Ex:
     * Inv1: startDate1, endDate1,
     * Inv2: startDate2,endateDate2,
     * Inv3: startDate3 --> oneYearAgo --> endDate3,
     * Inv4: startDate4, endDate4,
     * Inv6: startDate5, endDate5
     * <p>
     * Result: PastOneYearInvoices = Inv3, Inv4, Inv5.
     */
    @Override
    public List<Invoice> getPastOneYearNonCancelledInvoices(final List<Invoice> allInvoices, final LocalDate targetDate) {
        LocalDate oneYearAgo = targetDate.minus(1, ChronoUnit.YEARS);

        List<Invoice> nonCancelledAndIssuedInvoices = getNonCancelledAndIssuedInvoices(allInvoices);

        Optional<Invoice> invoiceWithLatestStartDateOnOrBeforeOneYear = nonCancelledAndIssuedInvoices.stream()
                .filter(invoice -> OffersUtil.isEqualOrBefore(invoice.getBillStartDate(), oneYearAgo))
                .max(Comparator.comparing(Invoice::getBillStartDate));

        if (invoiceWithLatestStartDateOnOrBeforeOneYear.isPresent()) {
            LocalDate latestStartDateOnOrBeforeOneYear = invoiceWithLatestStartDateOnOrBeforeOneYear.get().getBillStartDate();
            return nonCancelledAndIssuedInvoices.stream()
                    .filter(invoice -> OffersUtil.isEqualOrAfter(invoice.getBillStartDate(), latestStartDateOnOrBeforeOneYear))
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }

    @Override
    public List<Invoice> getOrderedNonCancelledAndIssuedInvoices(final List<Invoice> allInvoices) {
        getNonCancelledAndIssuedInvoices(allInvoices)
                .sort(Comparator.comparing(Invoice::getBillEndDate));
        return allInvoices;
    }

    private List<Invoice> getNonCancelledAndIssuedInvoices(final List<Invoice> allInvoices) {
        return allInvoices.stream().filter(invoice ->
                invoice.getAccountStatus() == null || (!invoice.getAccountStatus().toUpperCase().equals(AccountEventStatus.CANCELLED.getStatus()))
        ).collect(Collectors.toList());
    }

    @Override
    public List<Invoice> getLatestNonCancelledInvoiceOfPastOneYear(final List<Invoice> allInvoices, final LocalDate targetDate) {
        List<Invoice> pastOneYearInvoices = getPastOneYearNonCancelledInvoices(allInvoices, targetDate);

        Optional<Invoice> latestInvoice = pastOneYearInvoices.stream()
                .max(Comparator.comparing(Invoice::getCreatedTime));

        List<Invoice> invoices = new ArrayList<>();
        if (latestInvoice.isPresent()) {
            invoices.add(latestInvoice.get());
        }
        return invoices;
    }

    @Override
    public boolean isLatestInvoiceOfPastOneYearCancelled(final List<Invoice> allInvoices, final LocalDate targetDate) {
        Optional<Invoice> invoiceOptional = getLatestInvoiceOfPastOneYear(allInvoices, targetDate);
        if (invoiceOptional.isPresent()) {
            Invoice invoice = invoiceOptional.get();
            String accountStatus = invoice.getAccountStatus();
            return accountStatus != null && accountStatus.toUpperCase().equals(AccountEventStatus.CANCELLED.getStatus());
        }
        return true; //Safe to return true, as this will raise an error during Measured calculation.
    }

    /**
     * @param allInvoices : Take all invoices for this analysis(irrespective of status). Find the latest invoice based on max invoice.createdTime
     * @param targetDate
     * @return : latest invoice of past one year
     */
    private Optional<Invoice> getLatestInvoiceOfPastOneYear(final List<Invoice> allInvoices, final LocalDate targetDate) {
        LocalDate oneYearAgo = targetDate.minus(1, ChronoUnit.YEARS);
        return allInvoices.stream()
                .filter(invoice -> invoice.getBillEndDate().isAfter(oneYearAgo))
                .max(Comparator.comparing(Invoice::getCreatedTime));
    }

    @Override
    public Optional<Invoice> getLatestNonCancelledInvoice(final List<Invoice> allInvoices) {
        return getNonCancelledAndIssuedInvoices(allInvoices).stream()
                .max(Comparator.comparing(Invoice::getCreatedTime));
    }

}
