package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.error.ErrorCode;
import uk.co.stwater.api.osgi.model.calculator.offers.Arrears;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OfferPaymentFrequency;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanVariant;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvision;
import uk.co.stwater.api.osgi.model.calculator.offers.WarningDTO;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

public class OffersUtil {
    static Logger log = LoggerFactory.getLogger(OffersUtil.class);

    private final static BigDecimal ROUNDING_INCREMENT_10_PENCE = new BigDecimal("0.10");
    private final static BigDecimal ROUNDING_INCREMENT_50_PENCE = new BigDecimal("0.50");
    private final static BigDecimal ROUNDING_INCREMENT_ONE_POUND = new BigDecimal("1.00");

    protected static BigDecimal roundingTo50Pence(final BigDecimal value, final RoundingMode roundingMode) {
        return roundingToTheIncrement(value, ROUNDING_INCREMENT_50_PENCE, roundingMode);
    }

    protected static BigDecimal roundingTo10Pence(final BigDecimal value, final RoundingMode roundingMode) {
        return roundingToTheIncrement(value, ROUNDING_INCREMENT_10_PENCE, roundingMode);
    }

    protected static BigDecimal roundingToOnePound(final BigDecimal value, final RoundingMode roundingMode) {
        return roundingToTheIncrement(value, ROUNDING_INCREMENT_ONE_POUND, roundingMode);
    }

    private static BigDecimal roundingToTheIncrement(final BigDecimal value, final BigDecimal increment, final RoundingMode roundingMode) {
        if (increment.signum() == 0) {
            return value;
        } else {
            BigDecimal divided = value.divide(increment, 0, roundingMode);
            return divided.multiply(increment);
        }
    }

    protected static ErrorCode getErrorMessage(final ErrorCode error, final String arg1, final String arg2) {
        String errorMessage = error.getMessage();
        error.setMessage(String.format(errorMessage, arg1, arg2));
        return error;
    }

    protected static ErrorCode getErrorMessage(final ErrorCode error, final String arg1, final String arg2, final String arg3) {
        String errorMessage = error.getMessage();
        error.setMessage(String.format(errorMessage, arg1, arg2, arg3));
        return error;
    }

    protected static ErrorCode getErrorMessage(final ErrorCode error, final String arg1) {
        String errorMessage = error.getMessage();
        error.setMessage(String.format(errorMessage, arg1));
        return error;
    }

    public static String getCurrencyFormat(final BigDecimal value) {
        NumberFormat df = NumberFormat.getCurrencyInstance(Locale.UK);
        return df.format(value);
    }

    public static boolean isBetweenExclusively(final BigDecimal input, final BigDecimal value1, final BigDecimal value2) {
        if (value1.compareTo(value2) > 0) {
            return isBetween(input, value2, value1);
        }
        return isBetween(input, value1, value2);
    }

    public static boolean isBetweenExclusivelyInGivenOrder(final BigDecimal input, final BigDecimal smallValue, final BigDecimal largeValue) {
        if (largeValue.compareTo(smallValue) > 0) {
            return isBetween(input, smallValue, largeValue);
        }
        return false;
    }

    private static boolean isBetween(final BigDecimal input, final BigDecimal small, final BigDecimal large) {
        return input.compareTo(small) > 0 && large.compareTo(input) > 0;
    }

    static protected int calculateNumberOfInstallmentsRelatively(final LocalDate startDate, final int length, final int lengthMultiplier, final boolean isUnmeasuredFlex) {
        LocalDate currentDate = LocalDate.from(startDate);
        LocalDate endDate = LocalDate.from(startDate);
        LocalDate lastMonthStartDate = LocalDate.from(startDate);
        lastMonthStartDate = lastMonthStartDate.plus((long) length - 1, ChronoUnit.MONTHS);

        endDate = endDate.plus(length, ChronoUnit.MONTHS).minus(1, ChronoUnit.DAYS);
        if (isUnmeasuredFlex && lastMonthStartDate.getMonth() == OffersConstants.TARGET_END_OF_BILLING_YEAR_MONTH) {
            endDate = LocalDate.of(endDate.getYear(), lastMonthStartDate.getMonth(), lastMonthStartDate.lengthOfMonth());
        }

        int count = 0;
        while (endDate.isAfter(currentDate) || endDate.isEqual(currentDate)) {
            count++;
            currentDate = getNextFrq(currentDate, 1, lengthMultiplier);
        }
        return count;
    }

    protected static LocalDate adjustForPreferredPaymentDay(final OffersCalculation offersCalculation, final LocalDate installmentDate, final Offer offer) {
        if (offer.getPaymentFrequency().equalsIgnoreCase(OfferPaymentFrequency.MONTHLY.getCode())) {
            return adjustForPreferredPaymentDay(offersCalculation.getOffersCalculationRequest().getPreferredPaymentDay(), installmentDate);
        } else {
            return adjustForPreferredPaymentDay(0, installmentDate);
        }
    }

    private static LocalDate adjustForPreferredPaymentDay(final int preferredPaymentDay, final LocalDate installmentDate) {
        LocalDate adjustedDate = LocalDate.from(installmentDate);
        if (preferredPaymentDay > 0) {
            int lengthOfMonth = adjustedDate.lengthOfMonth();
            if (preferredPaymentDay > lengthOfMonth) {
                adjustedDate = adjustedDate.plus(1, ChronoUnit.MONTHS).with(ChronoField.DAY_OF_MONTH, 1);
            } else {
                adjustedDate = adjustedDate.with(ChronoField.DAY_OF_MONTH, preferredPaymentDay);
            }
        }
        return adjustedDate;
    }

    static private LocalDate getNextFrq(final LocalDate date, final int length, final int lengthMultiplier) {
        return date.plus((long) length * lengthMultiplier, ChronoUnit.WEEKS);
    }

    static protected boolean isPPCPlan(final PaymentPlan paymentPlan) {
        return StringUtils.startsWithIgnoreCase(paymentPlan.getPlanVariant(), OffersConstants.PLAN_VARIANT_PPC_PATTERN);
    }

    static protected boolean isPPCOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), OffersConstants.PLAN_VARIANT_PPC_PATTERN);
    }

    public static boolean isBdsPlan(PaymentPlan paymentPlan) {
        return StringUtils.equalsIgnoreCase(paymentPlan.getPlanVariant(), OffersConstants.PLAN_VARIANT_BDS);
    }

    public static boolean isBdsOffer(Offer offer) {
        return StringUtils.equalsIgnoreCase(offer.getPlanVariant(), OffersConstants.PLAN_VARIANT_BDS);
    }

    static protected boolean isPPC3MonthsOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), OffersConstants.PLAN_VARIANT_PPC_PATTERN)
                && !StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), PaymentPlanVariant.PPC1.getPlanVariant());
    }

    static protected boolean isMeasuredFlexOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), OffersConstants.PLAN_VARIANT_FLEX_PATTERN);
    }

    static protected boolean isStandardOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), OffersConstants.PLAN_VARIANT_FLEX_PATTERN);
    }

    static protected boolean isUnMeasuredFlexOffer(final Offer offer) {//Even Standard is part of the Unmeasured Flex, and is the Default Flex.
        return isStandardOffer(offer) || isUnMeasuredShortOffer(offer) || isUnMeasuredLongOffer(offer);
    }

    static protected boolean isMeasuredFlexPlan(final PaymentPlan paymentPlan) {
        return StringUtils.startsWithIgnoreCase(paymentPlan.getPlanVariant(), OffersConstants.PLAN_VARIANT_FLEX_PATTERN);
    }

    static protected boolean isUnMeasuredShortOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), PaymentPlanVariant.FLEX_SHORT.getPlanVariant());
    }

    static protected boolean isUnMeasuredLongOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), PaymentPlanVariant.FLEX_LONG.getPlanVariant());
    }

    static protected boolean isArrearsPlanFlexOffer(final Offer offer) {
        return isStandardOffer(offer) || isArrearsPlanFlexShortOffer(offer) || isArrearsPlanFlexLongOffer(offer);
    }

    static protected boolean isArrearsPlanFlexShortOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), PaymentPlanVariant.FLEX_SHORT.getPlanVariant());
    }

    static protected boolean isArrearsPlanFlexLongOffer(final Offer offer) {
        return StringUtils.startsWithIgnoreCase(offer.getPlanVariant(), PaymentPlanVariant.FLEX_LONG.getPlanVariant());
    }

    static protected Arrears getArrearsClone(final Arrears arrearsSource) {
        Arrears arrears = new Arrears();
        try {
            BeanUtils.copyProperties(arrears, arrearsSource);
        } catch (Exception ex) {
            log.error("Error in OffersUtil.getArreasClone, {}", ex.getMessage(), ex);
            throw new STWTechnicalException(ex.getMessage(), ex);
        }
        return arrears;
    }

    static protected void adjustArrearsAndForecastForPPC(final Offer offer, final BigDecimal totalChargePaidTowardsArrears) {
        Arrears adjustedArrears = OffersUtil.getArrearsClone(offer.getBaseArrears());
        offer.setArrears(adjustedArrears);

        BigDecimal remainingBalance = totalChargePaidTowardsArrears;
        if (adjustedArrears.getThirdPartyCharges().signum() == 1) {
            if (remainingBalance.compareTo(adjustedArrears.getThirdPartyCharges()) > 0) {
                //3rdParty unchanged.
                remainingBalance = remainingBalance.subtract(adjustedArrears.getThirdPartyCharges());
            } else {
                adjustedArrears.setThirdPartyCharges(remainingBalance);
                remainingBalance = BigDecimal.ZERO;
            }
        }

        if (adjustedArrears.getAccountArrears().signum() == 1) {
            if (remainingBalance.compareTo(adjustedArrears.getAccountArrears()) > 0) {
                //AccountArreas unchanged
                remainingBalance = remainingBalance.subtract(adjustedArrears.getAccountArrears());
            } else {
                adjustedArrears.setAccountArrears(remainingBalance);
                remainingBalance = BigDecimal.ZERO;
            }
        }

        if (remainingBalance.signum() == 1) {
            BigDecimal forecast = offer.getForecast();
            offer.setForecast(forecast.add(remainingBalance));
        }
    }

    protected static boolean isAnyServiceProvisionWithNoHistory(List<ServiceProvision> serviceProvisions) {
        return serviceProvisions.stream()
                .map(ServiceProvision::getDays)
                .anyMatch(days -> days.signum() == 0);
    }

    /**
     * @param offersCalculation
     * @return During the basePeriodAnalyser.calculateForecastAndAccruedDetails, if No History based on previous invoices, warning 'NO_HISTORY' will be added.
     * use_case1: If 'NO_HISTORY' and no forecast , then exit, without calculating any offers.
     * use_case2: If 'NO_HISTORY' but with forecast , then calculate offers.
     * <p>
     * Note: forecast is passed via UI/consumption calculator or UI/Assessed calculator.
     */

    protected static boolean exitIfNoHistoryAndNoForecast(final OffersCalculation offersCalculation) {
        return isNoHisotryWarningExist(offersCalculation.getWarnings())
                && offersCalculation.getOffersCalculationRequest().getForecast().signum() < 1;
    }

    protected static boolean isNoHisotryWarningExist(final List<WarningDTO> warnings) {
        return !CollectionUtils.isEmpty(warnings)
                && warnings.stream().anyMatch(warning -> warning.getCategory().name().equalsIgnoreCase(WarningDTO.WarningCategory.NO_HISTORY.name()));
    }

    protected static boolean isEqualOrBefore(final LocalDate firstDate, final LocalDate secondDate) {
        return firstDate.isBefore(secondDate) || firstDate.isEqual(secondDate);
    }

    protected static boolean isEqualOrAfter(final LocalDate firstDate, final LocalDate secondDate) {
        return firstDate.isAfter(secondDate) || firstDate.isEqual(secondDate);
    }

}
