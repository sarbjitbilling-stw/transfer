package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;

import java.math.BigDecimal;
import java.util.List;

public interface InstallmentGenerator {
    void calculateAndSetInstallments(final List<Offer> offers, final OffersCalculation offersCalculation, final BigDecimal maxMeasuredFlexVariantAmount);

    void addPreferredPaymentInstallments(final OffersCalculation offersCalculation);

    void removeDuplicateMeasuredFlexOffers(final OffersCalculation offersCalculation);

    void checkOfferValidity(final OffersCalculation offersCalculation);

}
