/**
 * 
 */
package uk.co.stwater.api.calculator.paymentarrangement.service;

import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author zali
 *
 */
@Path("/paymentmethod")
@Named("paymentArrangementRestResource")
public class PaymentMethodRestResource {

			 // BuildMyString.com generated code. Please enjoy your string responsibly.
			private static final String JSON = "[" +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"R\"," +
			"\"paymentDetailsCode\": \"DD\"," +
			"\"paymentMethodText\": \"Direct Debit\"," +
			"\"paymentFrequencyText\": \"On Recipt of Bill\"," +
			"\"plan\": false," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"M\"," +
			"\"paymentDetailsCode\": \"DD\"," +
			"\"paymentMethodText\": \"Direct Debit\"," +
			"\"paymentFrequencyText\": \"Monthly\"," +
			"\"plan\": true," +
			"\"defaultt\": true," +
			"\"facilityCode\": {" +
			"\"code\": \"D\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"M\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"F\"," +
			"\"paymentDetailsCode\": \"DD\"," +
			"\"paymentMethodText\": \"Direct Debit\"," +
			"\"paymentFrequencyText\": \"Fortnightly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"D\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"F\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"R\"," +
			"\"paymentDetailsCode\": \"WC\"," +
			"\"paymentMethodText\": \"Water Card\"," +
			"\"paymentFrequencyText\": \"On Recipt of Bill\"," +
			"\"plan\": false," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"M\"," +
			"\"paymentDetailsCode\": \"WC\"," +
			"\"paymentMethodText\": \"Water Card\"," +
			"\"paymentFrequencyText\": \"Monthly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"PC\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"M\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"F\"," +
			"\"paymentDetailsCode\": \"WC\"," +
			"\"paymentMethodText\": \"Water Card\"," +
			"\"paymentFrequencyText\": \"Fortnightly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"PC\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"F\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"W\"," +
			"\"paymentDetailsCode\": \"WC\"," +
			"\"paymentMethodText\": \"Water Card\"," +
			"\"paymentFrequencyText\": \"Weekly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"PC\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"W\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"M\"," +
			"\"paymentDetailsCode\": \"PB\"," +
			"\"paymentMethodText\": \"Payment Booklet\"," +
			"\"paymentFrequencyText\": \"Monthly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"B\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"M\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"F\"," +
			"\"paymentDetailsCode\": \"PB\"," +
			"\"paymentMethodText\": \"Payment Booklet\"," +
			"\"paymentFrequencyText\": \"Fortnightly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"B\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"F\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"W\"," +
			"\"paymentDetailsCode\": \"PB\"," +
			"\"paymentMethodText\": \"Payment Booklet\"," +
			"\"paymentFrequencyText\": \"Weekly\"," +
			"\"plan\": true," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"B\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"W\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"R\"," +
			"\"paymentDetailsCode\": \"CD\"," +
			"\"paymentMethodText\": \"Credit/Debit Card\"," +
			"\"paymentFrequencyText\": \"On Recipt of Bill\"," +
			"\"plan\": false," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"R\"," +
			"\"paymentDetailsCode\": \"PI\"," +
			"\"paymentMethodText\": \"Pingit\"," +
			"\"paymentFrequencyText\": \"On Recipt of Bill\"," +
			"\"plan\": false," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"R\"," +
			"\"paymentDetailsCode\": \"VB\"," +
			"\"paymentMethodText\": \"Via Bank\"," +
			"\"paymentFrequencyText\": \"On Recipt of Bill\"," +
			"\"plan\": false," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}," +
			"{" +
			"\"eligible\": \"Y\"," +
			"\"eligibleText\": \"Text\"," +
			"\"paymentFrequencyCode\": \"R\"," +
			"\"paymentDetailsCode\": \"CH\"," +
			"\"paymentMethodText\": \"Cheque\"," +
			"\"paymentFrequencyText\": \"On Recipt of Bill\"," +
			"\"plan\": false," +
			"\"defaultt\": false," +
			"\"facilityCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"scheduleFreqCode\": {" +
			"\"code\": \"\"" +
			"}," +
			"\"minDate\": \"2017-05-17T10:04:47+01:00\"," +
			"\"maxDate\": \"2017-05-17T10:04:47+01:00\"" +
			"}" +
			"]";
					
	@GET
	@Path("/{accountnumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPaymentArrangements(@PathParam("accountnumber") String accountnumber) {

		return Response.status(200).entity(JSON).build();
	}

}
