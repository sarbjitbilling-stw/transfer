package uk.co.stwater.api.calculator.waterdirect.service;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationRequest;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationValue;

import javax.ws.rs.core.Response;

import static javax.servlet.http.HttpServletResponse.SC_OK;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class WaterDirectCalculatorServiceRestResourceTest {
    private WaterDirectCalculatorServiceRestResource restResource;

    private final static String BAD_REQUEST = "400";

    @Before
    public void setUp() throws Exception {
        this.restResource = new WaterDirectCalculatorServiceRestResource();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void calculate_should_returnOk() {
        CalculationRequest calculationRequest = new CalculationRequest();

        CalculationValue calculationValue = new CalculationValue();
        calculationValue.setDoesNotQualify(true);
        calculationValue.setArrearsAccrued(100.0);

        Calculation calculation = new Calculation();
        calculation.setCalculationValue(calculationValue);

        WaterDirectCalculatorService calculatorService = mock(WaterDirectCalculatorService.class);
        when(calculatorService.validate(calculationRequest)).thenReturn(true);
        when(calculatorService.calculate(calculationRequest)).thenReturn(calculation);
        this.restResource.setCalculatorService(calculatorService);

        Response response = this.restResource.calculate(calculationRequest);

        assertEquals("Expected ok response", response.getStatus(), SC_OK);

        Calculation result = (Calculation)response.getEntity();

        assertTrue("Expected correct result", result.getCalculationValue().getDoesNotQualify());
        assertEquals("Expected correct result", 100.0, result.getCalculationValue().getArrearsAccrued(), 0);
    }

    @Test
    public void calculate_should_notQualify() {
        CalculationRequest calculationRequest = new CalculationRequest();

        CalculationValue calculationValue = new CalculationValue();
        calculationValue.setDoesNotQualify(false);
        calculationValue.setArrearsAccrued(100.0);

        Calculation calculation = new Calculation();
        calculation.setCalculationValue(calculationValue);

        WaterDirectCalculatorService calculatorService = mock(WaterDirectCalculatorService.class);
        when(calculatorService.validate(calculationRequest)).thenReturn(true);
        when(calculatorService.calculate(calculationRequest)).thenReturn(calculation);
        this.restResource.setCalculatorService(calculatorService);

        Response response = this.restResource.calculate(calculationRequest);

        assertEquals("Expected ok response", response.getStatus(), SC_OK);

        Calculation result = (Calculation)response.getEntity();

        assertFalse("Expected correct result", result.getCalculationValue().getDoesNotQualify());
        assertEquals("Expected correct result", 100.0, result.getCalculationValue().getArrearsAccrued(), 0);
    }
}
