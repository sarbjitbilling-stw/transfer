package uk.co.stwater.api.calculator.waterdirect.model;

public enum ClaimType {
    SINGLE_UNDER_25,
    SINGLE_OVER_25,
    JOINT_UNDER_25,
    JOINT_OVER_25
}
