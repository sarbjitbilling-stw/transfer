package uk.co.stwater.api.calculator.waterdirect.service;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public abstract class AbstractMeasuredCalculator implements Calculator {
    protected MeasuredInputs inputs;
    protected Calculation calculation;
    protected LocalDate today;

    public BigDecimal calculateAverageDailyCharge(int decimalPlaces) {
        BigDecimal totalBillAmount = this.inputs.getBillAmountAsBigDecimal().add(this.inputs.getPreviousBillAmountAsBigDecimal());
        BigDecimal totalDaysInBill = this.inputs.getDaysInBillAsBigDecimal().add(this.inputs.getPreviousDaysInBillAsBigDecimal());
        return totalBillAmount.divide(totalDaysInBill, decimalPlaces, RoundingMode.HALF_UP);
    }
}
