package uk.co.stwater.api.calculator.waterdirect.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import uk.co.stwater.api.core.model.BaseModel;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Calculation extends BaseModel<Long> {
    private static final long serialVersionUID = -8706025954272168489L;

    @XmlElement
    private int daysInBill;

    @XmlElement
    private double accountBalance;

    @XmlElement
    private double billAmount;

    @XmlElement
    private LocalDate billDate;

    @XmlElement
    private LocalDate nextBillDate;

    @XmlElement
    private double previousBillAmount;

    @XmlElement
    private int previousDaysInBill;

    @XmlElement
    private ClaimType claimType;

    @XmlElement
    private CalculationValue calculationValue;

    public void setDaysInBill(int daysInBill) {
        this.daysInBill = daysInBill;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public void setBillAmount(double billAmount) {
        this.billAmount = billAmount;
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate = billDate;
    }

    public void setNextBillDate(LocalDate nextBillDate) {
        this.nextBillDate = nextBillDate;
    }

    public void setPreviousBillAmount(double previousBillAmount) {
        this.previousBillAmount = previousBillAmount;
    }

    public void setPreviousDaysInBill(int previousDaysInBill) {
        this.previousDaysInBill = previousDaysInBill;
    }

    public void setClaimType(ClaimType claimType) {
        this.claimType = claimType;
    }

    public void setCalculationValue(CalculationValue calculationValue) {
        this.calculationValue = calculationValue;
    }

    public CalculationValue getCalculationValue() {
        return this.calculationValue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("calculationValue", this.calculationValue)
                .toString();
    }
}
