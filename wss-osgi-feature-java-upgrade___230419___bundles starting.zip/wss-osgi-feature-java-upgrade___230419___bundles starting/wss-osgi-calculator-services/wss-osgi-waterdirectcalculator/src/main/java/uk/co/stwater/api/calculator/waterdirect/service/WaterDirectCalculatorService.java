package uk.co.stwater.api.calculator.waterdirect.service;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationRequest;

public interface WaterDirectCalculatorService {
    /**
     * Check lowest common denominator parameters (daysInBill, accountBalance, billAmount)
     * have been specified.
     *
     * @return true if the request contains mandatory parameters, false otherwise.
     */
    boolean validate(CalculationRequest request);

    Calculation calculate(CalculationRequest request);
}
