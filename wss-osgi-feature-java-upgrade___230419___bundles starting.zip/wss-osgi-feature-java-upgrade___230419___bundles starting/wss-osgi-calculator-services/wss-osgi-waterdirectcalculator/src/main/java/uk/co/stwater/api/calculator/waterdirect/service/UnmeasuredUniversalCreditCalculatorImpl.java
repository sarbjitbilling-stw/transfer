package uk.co.stwater.api.calculator.waterdirect.service;

import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.DAYS_IN_MONTH;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.INTERMEDIATE_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.TWO_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WHOLE_NUMBER;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationValue;
import uk.co.stwater.api.calculator.waterdirect.model.ClaimType;

public class UnmeasuredUniversalCreditCalculatorImpl extends AbstractUnmeasuredCalculator {
    private final CalculatorUtils calculatorUtils;
    private final UniversalCreditUtils universalCreditUtils;

    public UnmeasuredUniversalCreditCalculatorImpl(UnmeasuredInputs inputs,
            ClaimType claimType, Calculation calculation, LocalDate today) {
        this.inputs = inputs;
        this.calculation = calculation;
        this.today = today;

        calculation.setDaysInBill(inputs.getDaysInBill());
        calculation.setAccountBalance(inputs.getAccountBalance());
        calculation.setBillAmount(inputs.getBillAmount());
        calculation.setClaimType(claimType);

        this.calculatorUtils = new CalculatorUtils(today);

        this.universalCreditUtils = new UniversalCreditUtils(claimType);
    }

    @Override
    public void calculate() {
        LocalDate dateOfBill = this.calculatorUtils.getBillingEndDate()
                .minusDays((long) this.inputs.getDaysInBill() - 1);

        long daysSinceBill = ChronoUnit.DAYS.between(dateOfBill, this.today);

        BigDecimal averageDailyCharge = this.calculateAverageDailyCharge(INTERMEDIATE_DECIMAL_PLACES);

        BigDecimal chargesToDate = BigDecimal.valueOf(daysSinceBill).multiply(averageDailyCharge);

        BigDecimal chargesRemaining = this.inputs.getBillAmountAsBigDecimal().subtract(chargesToDate);

        BigDecimal arrearsAccrued = this.inputs.getAccountBalanceAsBigDecimal().subtract(chargesRemaining).setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP);

        CalculationValue calculationValue = new CalculationValue();

        calculationValue.setAverageDailyCharge(averageDailyCharge);

        calculationValue.setArrearsAccrued(arrearsAccrued.doubleValue());

        BigDecimal monthlyConsumption = averageDailyCharge.multiply(DAYS_IN_MONTH).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
        calculationValue.setMonthlyConsumption(monthlyConsumption.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        BigDecimal deductionRate = monthlyConsumption.add(this.universalCreditUtils.getDeductionAmount());
        calculationValue.setDeductionRate(deductionRate.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        if (this.inputs.getAccountBalance() < chargesRemaining.doubleValue() ||
                arrearsAccrued.doubleValue() < this.universalCreditUtils.getMinQualification().doubleValue()) {
            calculationValue.setDoesNotQualify(true);
            BigDecimal daysUntilQualification = this.universalCreditUtils.getMinQualification().subtract(arrearsAccrued).divide(averageDailyCharge, INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
            calculationValue.setDaysUntilQualification(daysUntilQualification.setScale(WHOLE_NUMBER, RoundingMode.HALF_UP));
        }

        this.calculation.setCalculationValue(calculationValue);
    }
}
