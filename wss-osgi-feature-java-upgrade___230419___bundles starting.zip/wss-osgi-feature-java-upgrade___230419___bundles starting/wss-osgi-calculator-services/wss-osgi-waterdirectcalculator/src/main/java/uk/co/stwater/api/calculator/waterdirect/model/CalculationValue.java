package uk.co.stwater.api.calculator.waterdirect.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

public class CalculationValue implements Serializable {
    private static final long serialVersionUID = -7654474060371781664L;

    private double averageDailyCharge;
    private double arrearsAccrued;
    private boolean doesNotQualify;
    private int daysUntilQualification;
    private double weeklyConsumption;
    private double deductionRateWeekly;
    private double deductionRateFortnightly;
    private double monthlyConsumption;
    private double deductionRate;
    private double chargesNotAsArrears;

    public double getAverageDailyCharge() {
        return this.averageDailyCharge;
    }

    public void setAverageDailyCharge(BigDecimal averageDailyCharge) {
        this.averageDailyCharge = averageDailyCharge.doubleValue();
    }

    public double getArrearsAccrued() {
        return this.arrearsAccrued;
    }

    public void setArrearsAccrued(double arrearsAccrued) {
        this.arrearsAccrued = arrearsAccrued;
    }

    public boolean getDoesNotQualify() {
        return this.doesNotQualify;
    }

    public void setDoesNotQualify(boolean doesNotQualify) {
        this.doesNotQualify = doesNotQualify;
    }

    public int getDaysUntilQualification() {
        return this.daysUntilQualification;
    }

    public void setDaysUntilQualification(BigDecimal daysUntilQualification) {
        this.daysUntilQualification = daysUntilQualification.intValue();
    }

    public double getWeeklyConsumption() {
        return this.weeklyConsumption;
    }

    public void setWeeklyConsumption(BigDecimal weeklyConsumption) {
        this.weeklyConsumption = weeklyConsumption.doubleValue();
    }

    public double getDeductionRateWeekly() {
        return this.deductionRateWeekly;
    }

    public void setDeductionRateWeekly(BigDecimal deductionRateWeekly) {
        this.deductionRateWeekly = deductionRateWeekly.doubleValue();
    }

    public double getDeductionRateFortnightly() {
        return this.deductionRateFortnightly;
    }

    public void setDeductionRateFortnightly(BigDecimal deductionRateFortnightly) {
        this.deductionRateFortnightly = deductionRateFortnightly.doubleValue();
    }

    public double getMonthlyConsumption() {
        return this.monthlyConsumption;
    }

    public void setMonthlyConsumption(BigDecimal monthlyConsumption) {
        this.monthlyConsumption = monthlyConsumption.doubleValue();
    }

    public double getDeductionRate() {
        return this.deductionRate;
    }

    public void setDeductionRate(BigDecimal deductionRate) {
        this.deductionRate = deductionRate.doubleValue();
    }

    public double getChargesNotAsArrears() {
        return this.chargesNotAsArrears;
    }

    public void setChargesNotAsArrears(BigDecimal chargesNotAsArrears) {
        this.chargesNotAsArrears = chargesNotAsArrears.doubleValue();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("averageDailyCharge", this.averageDailyCharge)
                .append("arrearsAccrued", this.arrearsAccrued)
                .append("doesNotQualify", this.doesNotQualify)
                .append("daysUntilQualification", this.daysUntilQualification)
                .append("weeklyConsumption", this.weeklyConsumption)
                .append("deductionRateWeekly", this.deductionRateWeekly)
                .append("deductionRateFortnightly", this.deductionRateFortnightly)
                .append("monthlyConsumption", this.monthlyConsumption)
                .append("deductionRate", this.deductionRate)
                .append("chargesNotAsArrears", this.chargesNotAsArrears)
                .toString();
    }
}
