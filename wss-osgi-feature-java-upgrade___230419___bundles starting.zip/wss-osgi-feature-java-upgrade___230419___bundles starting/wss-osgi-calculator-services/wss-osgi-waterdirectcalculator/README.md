WaterDirect Calculator
----------------------

This calculator determines whether the customer is eligible for credit.

There are are 4 distinct calculators:

- Unmeasured
  - WaterDirect
  - UniversalCredit

- Measured
  - WaterDirect
  - UniversalCredit

### Calculating average daily charge

WaterDirect calculators use 2 decimal places for calculating average daily charge.

UniversalCredit calculators use 10 decimal places for calculating average daily charge.
