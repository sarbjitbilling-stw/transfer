package uk.co.stwater.api.calculator.assessed.dao;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.assessed.model.AssessedCharge;
import uk.co.stwater.api.core.dao.AbstractCrudDao;

@OsgiServiceProvider(classes = { AssessedChargeDao.class })
@Transactional
@Named
public class AssessedChargeDaoImpl extends AbstractCrudDao<Long, AssessedCharge> implements AssessedChargeDao {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext(unitName = "wssPersistence-assessed")
	protected EntityManager entityManager;

	public AssessedChargeDaoImpl() {
	}

	public AssessedChargeDaoImpl(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public AssessedCharge findByCategory(String category) {

        log.debug("AssessedChargeDaoImpl findByCategory for category {}", category);

		CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
		CriteriaQuery<AssessedCharge> criteriaQuery = criteriaBuilder.createQuery(AssessedCharge.class);
		Root<AssessedCharge> adc = criteriaQuery.from(AssessedCharge.class);

		Predicate adcPredicate = criteriaBuilder.equal(adc.get("category"), category);
		Predicate selectPredicate = criteriaBuilder.and(adcPredicate);
		criteriaQuery.where(selectPredicate);

        TypedQuery<AssessedCharge> query = this.entityManager.createQuery(criteriaQuery);

		return (AssessedCharge) query.getSingleResult();
	}

	@Override
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

    @Override
    public AssessedCharge findByCategoryAndSupplier(String category, String supplier) {
        log.debug("AssessedChargeDaoImpl findByCategoryAndSupplier for category {} and supplier {}", category,
                supplier);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<AssessedCharge> criteriaQuery = criteriaBuilder.createQuery(AssessedCharge.class);
        Root<AssessedCharge> adc = criteriaQuery.from(AssessedCharge.class);

        Predicate adcPredicate = criteriaBuilder.equal(adc.get("category"), category);
        Predicate supplierPredicate = criteriaBuilder.equal(adc.get("supplierCode"), supplier);

        Predicate selectPredicate = criteriaBuilder.and(adcPredicate, supplierPredicate);
        criteriaQuery.where(selectPredicate);

        TypedQuery<AssessedCharge> query = this.entityManager.createQuery(criteriaQuery);

        return query.getSingleResult();

    }
}
