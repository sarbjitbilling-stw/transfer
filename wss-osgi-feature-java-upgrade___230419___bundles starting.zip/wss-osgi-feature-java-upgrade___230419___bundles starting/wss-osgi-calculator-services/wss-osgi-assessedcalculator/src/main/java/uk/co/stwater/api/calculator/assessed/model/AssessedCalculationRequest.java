package uk.co.stwater.api.calculator.assessed.model;

import java.time.LocalDate;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlAdapter;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import uk.co.stwater.api.osgi.model.CalculatorRequest;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AssessedCalculationRequest extends CalculatorRequest {

	@XmlElement(required=true)
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate startDate;
	
	@XmlElement(required=true)
	@XmlJavaTypeAdapter(value = LocalDateAdapter.class)
	private LocalDate endDate;

	@XmlElement(required=true)
	private PropertyType propertyType;
	
	@XmlElement
	private boolean singleOccupierAssessedVolume;
	
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
  public PropertyType getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(PropertyType propertyType) {
		this.propertyType = propertyType;
	}
	public boolean isSingleOccupierAssessedVolume() {
		return singleOccupierAssessedVolume;
	}
	public void setSingleOccupierAssessedVolume(boolean singleOccupierAssessedVolume) {
		this.singleOccupierAssessedVolume = singleOccupierAssessedVolume;
	}
	
  @Override
	public String toString() {
		return "AssessedCalculationRequest [startDate=" + startDate + ", endDate=" + endDate + ", waterService="
				+ isWaterService() + ", sewerageService=" + isSewerageService() + ", surfaceWaterService=" + isSurfaceWaterService()
				+ ", usedWaterService=" + isUsedWaterService() + ", highwaysDrainageService=" + isHighwaysDrainageService() 
				+ ", propertyType=" + propertyType + ", singleOccupierAssessedVolume=" + singleOccupierAssessedVolume + "]";
	}
}

class LocalDateAdapter extends XmlAdapter<String, LocalDate> {
    @Override
    public LocalDate unmarshal(String v) throws Exception {
        return LocalDate.parse(v);
    }

    @Override
    public String marshal(LocalDate v) throws Exception {
        return v.toString();
    }
}
