package uk.co.stwater.api.calculator.assessed.dao;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.assessed.model.SoacCharge;
import uk.co.stwater.api.core.dao.AbstractCrudDao;

@OsgiServiceProvider(classes = { SoacChargeDao.class })
@Transactional
@Named
public class SoacChargeDaoImpl extends AbstractCrudDao<Long, SoacCharge> implements SoacChargeDao {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext(unitName = "wssPersistence-assessed")
	protected EntityManager entityManager;

	public SoacChargeDaoImpl() {
	}

	public SoacChargeDaoImpl(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public SoacCharge findByCategory(String category) {

        log.debug("SoacChargeDaoImpl findByCategory for category {}", category);

		CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
		CriteriaQuery<SoacCharge> criteriaQuery = criteriaBuilder.createQuery(SoacCharge.class);
		Root<SoacCharge> adc = criteriaQuery.from(SoacCharge.class);

		Predicate adcPredicate = criteriaBuilder.equal(adc.get("category"), category);
		Predicate selectPredicate = criteriaBuilder.and(adcPredicate);
		criteriaQuery.where(selectPredicate);

        TypedQuery<SoacCharge> query = this.entityManager.createQuery(criteriaQuery);

        return query.getSingleResult();
	}

	@Override
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

    @Override
    public SoacCharge findByCategoryAndSupplier(String category, String supplier) {
        log.debug("SoacChargeDaoImpl findByCategory for category {} and supplier{}", category, supplier);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<SoacCharge> criteriaQuery = criteriaBuilder.createQuery(SoacCharge.class);
        Root<SoacCharge> adc = criteriaQuery.from(SoacCharge.class);

        Predicate adcPredicate = criteriaBuilder.equal(adc.get("category"), category);
        Predicate supplierPredicate = criteriaBuilder.equal(adc.get("supplierCode"), supplier);
        Predicate selectPredicate = criteriaBuilder.and(adcPredicate, supplierPredicate);

        criteriaQuery.where(selectPredicate);

        TypedQuery<SoacCharge> query = this.entityManager.createQuery(criteriaQuery);

        return query.getSingleResult();

    }
}
