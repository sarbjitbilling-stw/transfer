package uk.co.stwater.api.calculator.common.utils;

import java.util.ArrayList;
import java.util.List;

import uk.co.stwater.api.dao.ServiceSupplierMapping;
import uk.co.stwater.api.osgi.model.CalculatorRequest;

public class CalculatorRequestUtils {
    
    private static final String PROVIDES_HD = "providesHD";
    private static final String PROVIDES_SWD = "providesSWD";
    private static final String PROVIDES_WASTE_WATER = "providesWasteWater";
    private static final String PROVIDES_FRESH_WATER = "providesFreshWater";
    private static final String DEFAULT_SUPPLIER = "1";
    
    private CalculatorRequestUtils() {
        
    }

    public static void assignCalculationRequestDefaults(CalculatorRequest calculationRequest) {
        if(calculationRequest.isWaterService() && calculationRequest.getWaterSupplier()==null) {
            calculationRequest.setWaterSupplier(DEFAULT_SUPPLIER);
        }
        if(calculationRequest.isUsedWaterService() && calculationRequest.getUsedWaterSupplier()==null) {
            calculationRequest.setUsedWaterSupplier(DEFAULT_SUPPLIER);
        }
        if(calculationRequest.isSurfaceWaterService() && calculationRequest.getSurfaceWaterSupplier()==null) {
            calculationRequest.setSurfaceWaterSupplier(DEFAULT_SUPPLIER);
        }
        if(calculationRequest.isSewerageService() && calculationRequest.getSewerageSupplier()==null) {
            calculationRequest.setSewerageSupplier(DEFAULT_SUPPLIER);
        }
        if(calculationRequest.isHighwaysDrainageService() && calculationRequest.getHighwayDrainageSupplier()==null) {
            calculationRequest.setHighwayDrainageSupplier(DEFAULT_SUPPLIER);
        }
    }
    
    public static List<ServiceSupplierMapping> getServiceSuppliers(CalculatorRequest calculationRequest) {
        List<ServiceSupplierMapping> serviceSupplierMapping = new ArrayList<>();

        // adding this make it do the whole prep job
        assignCalculationRequestDefaults(calculationRequest);

        if(calculationRequest.isWaterService()) {
            serviceSupplierMapping.add(
                    new ServiceSupplierMapping(calculationRequest.getWaterSupplier(), PROVIDES_FRESH_WATER));
        }
        if(calculationRequest.isUsedWaterService()) {
            serviceSupplierMapping.add(new ServiceSupplierMapping(calculationRequest.getUsedWaterSupplier(),
                    PROVIDES_WASTE_WATER));
        }

        if(calculationRequest.isSewerageService()) {
            serviceSupplierMapping.add(new ServiceSupplierMapping(calculationRequest.getSewerageSupplier(),
                    PROVIDES_WASTE_WATER));
        }
        if(calculationRequest.isSurfaceWaterService()) {
            serviceSupplierMapping.add(
                    new ServiceSupplierMapping(calculationRequest.getSurfaceWaterSupplier(), PROVIDES_SWD));
        }
        if(calculationRequest.isHighwaysDrainageService()) {
            serviceSupplierMapping.add(
                    new ServiceSupplierMapping(calculationRequest.getHighwayDrainageSupplier(), PROVIDES_HD));
        }
        return serviceSupplierMapping;
    }
}
