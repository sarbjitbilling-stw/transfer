package uk.co.stwater.api.calculator.common.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.dao.CalculateServiceSuppliersDao;
import uk.co.stwater.api.dao.entity.CalculateServiceSuppliers;
import uk.co.stwater.api.osgi.model.CalculatorRequest;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CalculatorSuppliersServiceImplTest {

    private static final String CALC_TYPE = "assessedWorks";

    @InjectMocks
    private CalculatorSuppliersService calculatorSuppliersService = new CalculatorSuppliersServiceImpl();

    List<CalculateServiceSuppliers> daoList = new ArrayList<>();
    
    @Mock
    private CalculateServiceSuppliersDao calculateServiceSuppliersDao;
    
    private CalculatorRequest request;

    @Before
    public void setUp() throws Exception {
        request = new CalculatorRequest();
    }
    
    @Test
    public void testAllSuppliersMatch5Services() {

        // 5 services req'd
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(true);
        request.setHighwaysDrainageService(true);

        // 5 match
        initialiseMatchingDaoList(5);
        
        when(calculateServiceSuppliersDao.findAllMatchingRows(any(List.class), anyString())).thenReturn(daoList);
        
        boolean result = calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE);
        assertTrue(result);
    }
    
    @Test
    public void testAllSuppliersMatch4Services() {
        
        // 4 services req'd
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(false);
        request.setHighwaysDrainageService(true);

        // 4 match
        initialiseMatchingDaoList(4);
        
        when(calculateServiceSuppliersDao.findAllMatchingRows(any(List.class), anyString())).thenReturn(daoList);
        
        boolean result = calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE);
        assertTrue(result);
    }
    
    @Test
    public void testAllSuppliersNoMatch() {
        
        // 5 services req'd
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(true);
        request.setHighwaysDrainageService(true);

        // 4 match
        initialiseMatchingDaoList(4);
        
        when(calculateServiceSuppliersDao.findAllMatchingRows(any(List.class), anyString())).thenReturn(daoList);
        
        boolean result = calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE);
        assertFalse(result);
    }
    
    @Test
    public void testSuppliersDefaultAssignment() {
        
        // 4 services req'd
        request.setWaterService(true);
        request.setWaterSupplier("1");
        
        request.setUsedWaterService(true);
        request.setUsedWaterSupplier("2");
        
        request.setSurfaceWaterService(true);
        request.setSurfaceWaterSupplier(null);

        // non required service shouldn't have default set
        request.setSewerageService(false);
        request.setSewerageSupplier(null);
        
        request.setHighwaysDrainageService(true);
        request.setHighwayDrainageSupplier(null);

        // 4 match
        initialiseMatchingDaoList(4);
        
        when(calculateServiceSuppliersDao.findAllMatchingRows(any(List.class), anyString())).thenReturn(daoList);
        
        boolean result = calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE);
        assertTrue(result);
        
        // asssert defaults in place
        assertEquals("1", request.getWaterSupplier());
        assertEquals("2", request.getUsedWaterSupplier());
        assertEquals("1", request.getSurfaceWaterSupplier());
        assertNull(request.getSewerageSupplier());
        assertEquals("1", request.getHighwayDrainageSupplier());
    }

    @Test
    public void testGetAllSuppliers() {
        initialiseMatchingDaoList(13);
        when(calculateServiceSuppliersDao.findAllRows()).thenReturn(daoList);
        List<CalculateServiceSuppliers> allSuppliers = calculatorSuppliersService.getSuppliers();
        assertNotNull(allSuppliers);
        assertEquals(13, allSuppliers.size());
    }
    
    
    private void initialiseMatchingDaoList(int limit) {
        for (int i = 0; daoList.size() < limit; i++) {
            daoList.add(i, new CalculateServiceSuppliers());
        }
    }
}
