package uk.co.stwater.api.audit.exception;

import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

public class AuditException extends STWBusinessException {
    private static final long serialVersionUID = -7001456288096645922L;

    static final String DEFAULT_ERROR_CODE = "100";

    public AuditException(String msg) {
        this(DEFAULT_ERROR_CODE, msg);
    }

    public AuditException(String msg, Throwable t) {
        this(DEFAULT_ERROR_CODE, msg, t);
    }

    public AuditException(String errorCode, String msg) {
        super(msg, errorCode, ErrorCategory.AUDIT_SERVICES);
    }

    public AuditException(String errorCode, String msg, Throwable t) {
        super(msg, errorCode, ErrorCategory.AUDIT_SERVICES, t);
    }
}