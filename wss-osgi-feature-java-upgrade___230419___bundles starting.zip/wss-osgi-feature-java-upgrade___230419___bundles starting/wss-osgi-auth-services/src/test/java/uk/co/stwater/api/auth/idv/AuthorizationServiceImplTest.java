/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.auth.idv;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;
import uk.co.stwater.targetconnector.client.api.directdebit.GetDirectDebitClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsClient;

/**
 *
 * @author admzphili1
 */
//@RunWith(MockitoJUnitRunner.Silent.class)
public class AuthorizationServiceImplTest {

    @InjectMocks
    private AuthorizationService authorizationService;

    @Mock
    private PersonalDetailsClient personalDetails;

    @Mock
    private GetAccountSummaryClient accountSummary;

    @Mock
    private GetDirectDebitClient directDebit;

//    public void setUp() {
//        MockitoAnnotations.initMocks(authorizationService);
//    }

//    @Test(expected = AuthenticationException.class)
//    public void accountNumberNullThrowException() {
//        authorizationService.getQuestionAnswers(0, "CV1 2LZ", 12345678);
////        authenticationService.authenticate(token);
//    }
//    
//    @Test(expected = AuthenticationException.class)
//    public void legalEntityNullThrowException() {
////        UsernamePasswordToken token = new UsernamePasswordToken("admin","admin");
////        authenticationService.authenticate(token);
//    }
//    
//    @Test(expected = AuthenticationException.class)
//    public void postCodeNullThrowException() {
////        UsernamePasswordToken token = new UsernamePasswordToken("admin","admin");
////        authenticationService.authenticate(token);
//    }
}
