package uk.co.stwater.api.auth;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.ws.rs.core.Response;
import org.apache.cxf.binding.BindingFactoryManager;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSBindingFactory;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;
import org.apache.cxf.transport.local.LocalConduit;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import uk.co.stwater.api.osgi.model.resetpassword.ResetPassword;
import uk.co.stwater.api.osgi.util.TestUtil;

/**
 * Created by rtai on 02/03/2017.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
@Ignore
public class ResetPasswordResourceTest {

    private static final int RANDOM_PORT = TestUtil.getRandomPort();
    private static final String HTTP_LOCALHOST_API = String
        .format("http://localhost:%s/api/", RANDOM_PORT);
    private static final String ENDPOINT_ADDRESS = String
        .format("http://localhost:%s/api/WSSAccounts/Auth/ResetPassword", RANDOM_PORT);

    private static Server server;

    private AuthenticationService authenticationService;

    private static ResetPasswordResource resetPasswordResource = new ResetPasswordResource();

    @BeforeClass
    public static void initialize() {
        //Because of this scaffolding code to setup the JAX-RS server, we can't use the mockito annotations as
        //the AuthenticationResource needs to be static.
        JAXRSServerFactoryBean sf = new JAXRSServerFactoryBean();
        sf.setResourceClasses(ResetPasswordResource.class);
        sf.setResourceProvider(ResetPasswordResource.class,
            new SingletonResourceProvider(resetPasswordResource, true));
        sf.setAddress(HTTP_LOCALHOST_API);
        BindingFactoryManager manager = sf.getBus().getExtension(BindingFactoryManager.class);
        JAXRSBindingFactory factory = new JAXRSBindingFactory();
        factory.setBus(sf.getBus());
        manager.registerBindingFactory(JAXRSBindingFactory.JAXRS_BINDING_ID, factory);
        server = sf.create();
    }

    @Before
    public void init() {
        authenticationService = mock(AuthenticationService.class);
        resetPasswordResource.setAuthenticationService(authenticationService);
    }

    @AfterClass
    public static void tearDown() {
        server.stop();
        server.destroy();
    }

    @Test
    public void givenValidPostRequestThenReturnCreatedStatus() {
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("12345");
        when(authenticationService.forgottenPassword(anyString(), anyString()))
            .thenReturn(resetPassword);

        WebClient webClient = WebClient.create(ENDPOINT_ADDRESS);
        WebClient.getConfig(webClient).getRequestContext()
            .put(LocalConduit.DIRECT_DISPATCH, Boolean.TRUE);
        Response response = webClient.post("test@stwater.co.uk");
        assertNotNull(response);
        assertEquals(201, response.getStatus());
        assertNotNull(response.getLocation());

        verify(authenticationService, times(1)).forgottenPassword(anyString(), anyString());
    }

    @Test
    public void givenInvalidUsernameThenReturnBadRequest() {
        doThrow(AuthenticationException.class).when(authenticationService)
            .forgottenPassword(anyString(), anyString());
        WebClient webClient = WebClient.create(ENDPOINT_ADDRESS);
        WebClient.getConfig(webClient).getRequestContext()
            .put(LocalConduit.DIRECT_DISPATCH, Boolean.TRUE);
        Response response = webClient.post("test@stwater.co.uk");
        assertNotNull(response);
        assertEquals(400, response.getStatus());
        verify(authenticationService, times(1)).forgottenPassword(anyString(), anyString());
    }

    @Test
    public void givenValidGetRequestThenReturnResetPassword() {
        String token = "0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e";
        WebClient webClient = WebClient.create(ENDPOINT_ADDRESS + "/1?token=" + token);

        ResetPassword rp = new ResetPassword();
        rp.setToken(token);

        when(authenticationService.verifyForgottenPasswordLink(any())).thenReturn(rp);

        WebClient.getConfig(webClient).getRequestContext()
            .put(LocalConduit.DIRECT_DISPATCH, Boolean.TRUE);
        Response response = webClient.get();
        assertNotNull(response);
        ResetPassword resetPassword = response.readEntity(ResetPassword.class);
        assertNotNull(resetPassword);
        assertEquals(token, resetPassword.getToken());

    }

}
