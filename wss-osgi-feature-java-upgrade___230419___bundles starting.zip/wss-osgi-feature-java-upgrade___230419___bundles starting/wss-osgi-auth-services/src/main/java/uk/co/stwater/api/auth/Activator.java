package uk.co.stwater.api.auth;

/**
 *
 * @author tellis3
 */
import java.util.Dictionary;
import java.util.Hashtable;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.cm.ManagedService;

import static uk.co.stwater.api.auth.AuthenticationConfigServiceImpl.PID;


public class Activator implements BundleActivator {

    ServiceRegistration registration;

    public void start(BundleContext context) throws Exception {
        Dictionary properties = new Hashtable();
        properties.put("service.pid", PID);
        registration = context.registerService(ManagedService.class.getName(),
                new AuthenticationConfigServiceImpl(), properties);
    }

    public void stop(BundleContext context) throws Exception {
        if (registration != null) {
            registration.unregister();
            registration = null;
        }
    }

}
