package uk.co.stwater.api.auth;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Named;
import javax.inject.Singleton;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 *
 * @author tellis3
 */
@Named
@Singleton
@OsgiServiceProvider(classes = {AuthenticationConfigService.class})
public class AuthenticationConfigServiceImpl implements ManagedService, AuthenticationConfigService {

    static final String PID = "wss.osgi.authentication";
    private static final String HOURS_BEFORE_LINK_EXPIRES = PID + ".hours.before.link.expires";
    private static final String EMAIL_LINK_PREFIX = PID + ".link.prefix";
    private static final String SIGNING_SHARED_SECRET = PID + ".signing.shared.secret";
    private static final String ENDPOINT_SHARED_SECRET = PID + ".endpoint.shared.secret";
    private static final String ENDPOINT_SHARED_SECRET_ENABLED = PID + ".endpoint.shared.secret.enabled";
    
    private static final Map<String, String> config = new HashMap<>();

    Logger log = LoggerFactory.getLogger(this.getClass());
    

    @Override
    public synchronized void updated(Dictionary dctnrIn) throws ConfigurationException {
        //Add some type saftey !!
        
        log.info("updating auth config");

        if(dctnrIn!=null) {

        	log.info("In dictionary method of Auth");
            config.clear();
            Dictionary<String, String> dctnr = dctnrIn;

            String hoursBeforeLinkExpires = getValue(dctnr, HOURS_BEFORE_LINK_EXPIRES);
            String emailLinkPrefix = getValue(dctnr, EMAIL_LINK_PREFIX);
            String endpointSharedSecret = getValue(dctnr, ENDPOINT_SHARED_SECRET);

            log.info("After gettign the values from dictionary ");
            if (hoursBeforeLinkExpires == null){
                throw new ConfigurationException(hoursBeforeLinkExpires, "hoursBeforeLinkExpires Can't be null");
            }
            
            if (emailLinkPrefix == null){
            	throw new ConfigurationException(emailLinkPrefix, "emailLinkPrefix Can't be null");
            }

            if(endpointSharedSecret == null) {
                throw new ConfigurationException(endpointSharedSecret, "endpoint shared secret cannot be null");
            }

            Collections.list(dctnr.keys()).forEach(key -> config.put(key, dctnr.get(key)));
        }

    }
    
    private String getValue(Dictionary dctnr, String key) {
        return dctnr.get(key).toString();
    }

    @Override
    public int getHoursBeforeLinkExpires(){
        return Integer.parseInt(config.get(HOURS_BEFORE_LINK_EXPIRES));
    }
    
    @Override
    public String getEmailLinkPrefix() {
        return config.get(EMAIL_LINK_PREFIX);
    }  

    @Override
    public String getAgentLoginSharedSecret() {
        //use a runtime exception here as not all deployments will need to support agent login, 
        //so only fail if used and config is missing
        return Optional.ofNullable(config.get(SIGNING_SHARED_SECRET))
                .orElseThrow(()->new RuntimeException(SIGNING_SHARED_SECRET + " can not be null"));
    }

    @Override
    public String getEndpointSharedSecret() {
        return Optional.ofNullable(config.get(ENDPOINT_SHARED_SECRET))
                .orElseThrow(()->new RuntimeException(ENDPOINT_SHARED_SECRET + " can not be null"));
    }

    @Override
    public boolean isEndpointSharedSecretEnabled() {
        return Boolean.parseBoolean(config.get(ENDPOINT_SHARED_SECRET_ENABLED));
    }

}
