package uk.co.stwater.api.auth;

/**
 *
 * @author tellis3
 */
public interface AuthenticationConfigService {

    int getHoursBeforeLinkExpires();
    
    String getEmailLinkPrefix();
    
    String getAgentLoginSharedSecret();

    String getEndpointSharedSecret();

    boolean isEndpointSharedSecretEnabled();
}
