package uk.co.stwater.api.auth.idv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.auth.AuthenticationException;
import uk.co.stwater.api.dao.AccountEntityDao;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.AccountEntity;
import uk.co.stwater.api.dao.entity.LegalEntity;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.osgi.model.IDVStatus;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.QuestionAnswers;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.date.DateUtils;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;
import uk.co.stwater.targetconnector.client.api.directdebit.GetDirectDebitClient;
import uk.co.stwater.targetconnector.client.api.directdebit.PaymentMandate;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsResponse;
import uk.co.stwater.targetconnector.client.api.properties.GetPropertiesForPostcodeClient;

/**
 *
 * @author admzphili1
 */
@Named
@OsgiServiceProvider(classes = {AuthorizationService.class})
public class AuthorizationServiceImpl implements AuthorizationService {

	private static final int MAX_POSTCODE_LENGTH = 8;

	private static final String PARTIAL = "PARTIAL";

    private static final String GUEST = "GUEST";

    Logger log = LoggerFactory.getLogger(this.getClass());

	private static final String ERROR = "error";

	private static final Integer INITIAL_IDV_COUNT=1;
	
	private static final Integer ZERO_IDV_COUNT=0;
	
	private static final Integer MAX_IDV_COUNT = 2;

    private static final String IDVG = "IDVG";

	//  private QuestionAnswers questionAnswers;

	@Inject
	@OsgiService
	private PersonalDetailsClient personalDetails;

	@Inject
	@OsgiService
	private GetAccountSummaryClient accountSummary;

	@Inject
	@OsgiService
	private GetDirectDebitClient directDebit;

	@OsgiService
	@Inject
	GetPropertiesForAccountNumberClient propertiesByAccountNumber; 

	@OsgiService
	@Inject
	GetPropertiesForPostcodeClient propertiesForPostCode;

	@Inject
	@OsgiService
	private AccountEntityDao accountEntityDao;

	@Inject
	@OsgiService
	private UserDao userDao;    


	@Override
	public QuestionAnswers getQuestionAnswers(TargetAccountNumber accountNumber, String postcode, long legalEntity) {
		return getQuestionAnswers(accountNumber, postcode, legalEntity, null);
	}

	private QuestionAnswers getQuestionAnswers(TargetAccountNumber accountNumber, String postcode, long legalEntity, QuestionAnswers userResponse) {
		QuestionAnswers questionAnswers = new QuestionAnswers();
		try {
			//PersonalDetails for getting home telephone, mobile number and date of birth

			String strLegalEntity = Long.toString(legalEntity);

			// only make the Target call if we really need the answers
			if (userResponse == null || 
					userResponse.getHomeTelephoneNumber()!=null ||
					userResponse.getMobileNumber()!=null ||
					userResponse.getDateOfBirth()!=null){

				PersonalDetailsResponse response = personalDetails.getPersonalDetails(accountNumber, postcode, strLegalEntity);

				if (response.getTelNumMobile() != null) {
					questionAnswers.setHasMobileNumber(Boolean.TRUE);
					questionAnswers.setMobileNumber(response.getTelNumMobile());
				}

				if (response.getDateOfBirth() != null) {
					questionAnswers.setDateOfBirth(DateUtils.localDateFromUtilDate(response.getDateOfBirth()));
				}

				if (response.getTelNumHome() != null) {
					questionAnswers.setHasHomeTelephone(Boolean.TRUE);
					questionAnswers.setHomeTelephoneNumber(response.getTelNumHome());
				}
			}

			//GetDirectDebit for sort code, bank account and if payment plan setup

			if (userResponse == null || 
					userResponse.getHasActivePaymentPlan()!=null ||
					userResponse.getBankAccountNumber()!=null ||
					userResponse.getBankSortCode()!=null){                            
				PaymentMandate ddResponse = directDebit.getDirectDebit(accountNumber, postcode);
				if (ddResponse.getProperty(PaymentMandate.AUTO_PAY_ARRANGEMENT_STATUS) !=null) {
					questionAnswers.setHasActivePaymentPlan(Boolean.TRUE);
					questionAnswers.setBankAccountNumber(ddResponse.getAccountNumber());
					questionAnswers.setBankSortCode(ddResponse.getSortCode());
				}
			}

			if (userResponse == null ||  
					userResponse.getLastPaymentAmount()!=null ||
					userResponse.getLastPaymentDate()!=null){

				AccountSummaryResponse accountResponse = accountSummary.getAccountSummary(accountNumber, legalEntity);
				if (accountResponse != null) {
					// mutiply by -1 to turn CR amount into a positive value
                    if (accountResponse.getLastPaymentAmount() != null) {
                        questionAnswers.setLastPaymentAmount(accountResponse.getLastPaymentAmount().doubleValue() * -1);
                    }
					questionAnswers.setLastPaymentDate(DateUtils.localDateFromUtilDate(accountResponse.getLastPaymentDate()));
				}
			}

			if (userResponse == null ||  
					userResponse.getPreviousAddress()!=null){

				List<Property> properties = propertiesByAccountNumber.getPropertiesForAccountNumber(accountNumber, null);

				List<Property> previousAddresses = new ArrayList<>();

				for (Property property : properties) {
					if (property.getEndDate() != null && StringUtils.isNotEmpty(property.getPostcode())
							&& property.getPostcode().length() <= MAX_POSTCODE_LENGTH) {
						previousAddresses.add(property);
					}
				}

				if (previousAddresses != null && !previousAddresses.isEmpty()){
					//set list of valid previous addresses
					questionAnswers.setPreviousAddresses(previousAddresses);
					//set the first valid previous address from the list of valid previous addresses
					if(questionAnswers.getPreviousAddresses()!=null && !questionAnswers.getPreviousAddresses().isEmpty()){
						//check if end date is not null (if end date is null then it is current address)
						//first matching not null end date to find other properties
						//setProperty(property)
						//3 non valid after making service req
						questionAnswers.setPreviousAddress(questionAnswers.getPreviousAddresses().get(0));
						extractAddressLinesAndPostCode(questionAnswers);
						String previousAddressPostcode = questionAnswers.getPreviousAddresses().get(0).getPostcode();


                        try {
                            List<Property> previousPropertyList = (List<Property>) CollectionUtils.collect(
                                    propertiesForPostCode.getProperties(previousAddressPostcode),
                                    PreviousPropertyTransformer.SOAP_RESPONSE_TO_PROPERTY_ENTITY);
                            Collections.shuffle(previousPropertyList);

                            int counter = 0;
                            for (int i = 0; i < previousPropertyList.size();) {
                                while (counter < 3) {
                                    if (!previousPropertyList.get(counter).getAddressLine1()
                                            .equals(questionAnswers.getPreviousAddresses().get(0).getAddressLine1())) {
                                        previousAddresses.add(previousPropertyList.get(counter));
                                        counter++;
                                    }
                                }
                                break;

                            }

                            Collections.shuffle(previousAddresses);
                            questionAnswers.setPreviousAddresses(previousAddresses);
                        } catch (STWTechnicalException ex) {
                            questionAnswers.setPreviousAddresses(null);
                            java.util.logging.Logger.getLogger(AuthorizationServiceImpl.class.getName())
                                    .log(Level.SEVERE, null, ex);
                        }
					}
				}
			}

		} catch (AuthenticationException e) {
			log.error("Error setting questions and answers{}", e.getMessage());
		} catch (STWTechnicalException ex) {
			java.util.logging.Logger.getLogger(AuthorizationServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
		} catch (Exception ex) {
			java.util.logging.Logger.getLogger(AuthorizationServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
		}
		return questionAnswers;
	}

	private void extractAddressLinesAndPostCode(QuestionAnswers quesAnswers) {
		String previousCommaDelimitedAddress = quesAnswers.getPreviousAddresses().get(0).getAddress();
		String[] splitAddress = previousCommaDelimitedAddress.split(",");
		int numberOfAddressLines = splitAddress.length-1;
		if (splitAddress[0] !=null && numberOfAddressLines != 0) {
			quesAnswers.getPreviousAddresses().get(0).setAddressLine1(splitAddress[0]);
		}
		if (splitAddress[1] !=null && numberOfAddressLines != 1) {
			quesAnswers.getPreviousAddresses().get(0).setAddressLine2(splitAddress[1]); 
		}
		if (splitAddress[2] !=null && numberOfAddressLines != 2) {
			quesAnswers.getPreviousAddresses().get(0).setAddressLine3(splitAddress[2]); 
		}		
		quesAnswers.getPreviousAddresses().get(0).setPostcode(splitAddress[numberOfAddressLines]);
	}

	@Override
	public IDVStatus validateQuestions(QuestionAnswers userResponse, String idvRegistrationType)
	{
		QuestionAnswers questionAnswers = getQuestionAnswers(userResponse.getAccountNumber(), 
				userResponse.getPostcode(), 
				Long.valueOf(userResponse.getLegalEntity()), 
				userResponse);

		int totalCount= 0;
		int failedCount =0;
		IDVStatus idvStatus = new IDVStatus();
		if(!StringUtils.isEmpty(userResponse.getMobileNumber()))
		{
			totalCount++;
			if(!userResponse.getMobileNumber().equals(questionAnswers.getMobileNumber()))
			{
				failedCount++;
				log.debug("Mobile Number entered: {} doesnt match the stored : {}", userResponse.getMobileNumber(), questionAnswers.getMobileNumber());
			}
		}

		if(!StringUtils.isEmpty(userResponse.getHomeTelephoneNumber()))
		{
			totalCount++;
			if(!userResponse.getHomeTelephoneNumber().equals(questionAnswers.getHomeTelephoneNumber()))
			{
				failedCount++;
				log.debug("Home Telephone Number entered: {} doesnt match the stored : {}", userResponse.getHomeTelephoneNumber(), questionAnswers.getHomeTelephoneNumber());
			}
		}

		if(userResponse.getDateOfBirth()!= null)
		{
			totalCount++;
			if(userResponse.getDateOfBirth()!=null && !userResponse.getDateOfBirth().equals(questionAnswers.getDateOfBirth()))
			{
				failedCount++;
				log.debug("Date of birth entered : {} doesnt match the stored : {}", userResponse.getDateOfBirth(), questionAnswers.getDateOfBirth());
			}
		}

		if(!StringUtils.isEmpty(userResponse.getBankAccountNumber()))
		{
			totalCount++;

			String trimmedBankAccountNumber = questionAnswers.getBankAccountNumber().substring(questionAnswers.getBankAccountNumber().length() - 4);			

			if(userResponse.getBankAccountNumber()!=null && !userResponse.getBankAccountNumber().equals(trimmedBankAccountNumber))
			{
				failedCount++;
				log.debug("Bank Account Number entered: {} doesnt match the stored : {}", userResponse.getBankAccountNumber(), questionAnswers.getBankAccountNumber());
			}
		}

		if(!StringUtils.isEmpty(userResponse.getBankSortCode()))
		{
			totalCount++;
			if(!userResponse.getBankSortCode().equals(questionAnswers.getBankSortCode()))
			{
				failedCount++;
				log.debug("Bank Account Sort Code entered: {} doesnt match the stored : {}", userResponse.getBankSortCode(), questionAnswers.getBankSortCode());
			}
		}

		if(userResponse.getLastPaymentAmount()!= null)
		{
			totalCount++;
			//truncate the decimal
			int paymentAmount = userResponse.getLastPaymentAmount().intValue();
			//check range
            long minpaymentAmount = paymentAmount - 1L;
            long maxpaymentAmount = paymentAmount + 1L;
			if((questionAnswers.getLastPaymentAmount().intValue()< minpaymentAmount || questionAnswers.getLastPaymentAmount().intValue() > maxpaymentAmount))
			{
				failedCount++;
				log.debug("Last Payment Amount entered: {} doesnt match the stored : {}", userResponse.getLastPaymentAmount(), questionAnswers.getLastPaymentAmount());
			}
		}

		if(userResponse.getLastPaymentDate()!= null)
		{
			totalCount++;
			if(!userResponse.getLastPaymentDate().equals(questionAnswers.getLastPaymentDate()))
			{
				failedCount++;
				log.debug("Last Payment Date entered: {} doesnt match the stored : {}", userResponse.getLastPaymentDate(), questionAnswers.getLastPaymentDate());
			}
		}

		if(userResponse.getPreviousAddress()!=null && !StringUtils.isEmpty(userResponse.getPreviousAddress().getAddressLine1()))
		{
			totalCount++;
			if(!userResponse.getPreviousAddress().getAddressLine1().matches(questionAnswers.getPreviousAddress().getAddress()))
			{
				failedCount++;
				log.debug("Previous address entered: {} doesnt match the stored : {}", userResponse.getPreviousAddress().getAddressLine1(), questionAnswers.getPreviousAddress().getAddressLine1());
			}
		}

		if(totalCount == 2)
		{
			//first stage, both questions right, hence success
			if(failedCount == 0)
			{
				idvStatus.setStatus("success");
				setIdnvLockoutCountToZeroOnlyIfMaxCountHasNotExceeded(userResponse.getAccountNumber(),userResponse.getLegalEntity(), idvRegistrationType);
				return idvStatus;
			}

			//first stage, one question wrong, hence another chance to answer third question
			if (failedCount == 1)
			{
				idvStatus.setStatus("inProgress");
				return idvStatus;
			}

			//first stage, both questions wrong, hence STOP condition
			if(failedCount == 2 )
			{
				idvStatus.setStatus(ERROR);
				incrementIdnvLoginAttemptCount(userResponse.getAccountNumber(), userResponse.getLegalEntity(), idvRegistrationType, idvStatus);
				return idvStatus;
			}

		}

		//second stage, 2 questions wrong, hence STOP condition
		if(totalCount == 3)
		{
			// Second stage, all questions right or 1 question wrong
			if(failedCount == 0 || failedCount == 1)
			{
				idvStatus.setStatus("success");
				setIdnvLockoutCountToZeroOnlyIfMaxCountHasNotExceeded(userResponse.getAccountNumber(),userResponse.getLegalEntity(), idvRegistrationType);
				return idvStatus;
			}

			// Second stage,  2 or more questions wrong
			if(failedCount >= 2)
			{
				idvStatus.setStatus(ERROR);
				incrementIdnvLoginAttemptCount(userResponse.getAccountNumber(), userResponse.getLegalEntity(), idvRegistrationType, idvStatus);
				return idvStatus;
			}
		}

		//it shouldnt come here... as the code should return a value before
		idvStatus.setStatus(ERROR);
		incrementIdnvLoginAttemptCount(userResponse.getAccountNumber(), userResponse.getLegalEntity(), idvRegistrationType, idvStatus);
		return idvStatus;
	}

	private void incrementIdnvLoginAttemptCount(TargetAccountNumber targetAccountNumber, String legalEntity, String idvRegistrationType, IDVStatus idvStatus){
            
		List<AccountEntity> dbAccountList = accountEntityDao.
				getAccountsByTargetAccountId(targetAccountNumber); 
		
		if (!dbAccountList.isEmpty()){
            List<AccountEntity> filteredAccountEntityList = dbAccountList.stream().filter(filterAccountEntityPredicate(targetAccountNumber, legalEntity))
                    .collect(Collectors.toList());
		    
            if (!filteredAccountEntityList.isEmpty()) {
                // @formatter:off
                User wssUser = filteredAccountEntityStream(idvRegistrationType, filteredAccountEntityList)
                        .findFirst()
                        .map(AccountEntity::getLegalEntity)
                        .map(LegalEntity::getUser)
                        .orElseThrow(() -> new STWBusinessException("Unable to find WSS user for target account"));
                // @formatter:on

                if (wssUser.getIdnvLoginAttemptCount() == null) {
                    wssUser.setIdnvLoginAttemptCount(INITIAL_IDV_COUNT);
                    userDao.saveOrUpdate(wssUser);
                } else {
                    wssUser.setIdnvLoginAttemptCount(wssUser.getIdnvLoginAttemptCount() + 1);
                    userDao.saveOrUpdate(wssUser);
                }
				idvStatus.setLoginAttemptCount(wssUser.getIdnvLoginAttemptCount());
            }
		}        
	}

    private Stream<AccountEntity> filteredAccountEntityStream(String idvRegistrationType,
            List<AccountEntity> filteredAccountEntityList) {
        return filteredAccountEntityList.stream().filter(idvRegistrationTypePredicate(idvRegistrationType));
    }

    private Predicate<? super AccountEntity> idvRegistrationTypePredicate(String idvRegistrationType) {
        return account -> account.getLegalEntity().getUser().getRegistrationType()
                    .equalsIgnoreCase(idvRegistrationType);
    }
	
    private void setIdnvLockoutCountToZeroOnlyIfMaxCountHasNotExceeded(TargetAccountNumber targetAccountNumber,
            String legalEntity, String idvRegistrationType) {
        List<AccountEntity> dbAccountList = accountEntityDao.getAccountsByTargetAccountId(targetAccountNumber);
        if (!dbAccountList.isEmpty()) {
            List<AccountEntity> filteredAccountEntityList = dbAccountList.stream()
                    .filter(filterAccountEntityPredicate(targetAccountNumber, legalEntity))
                    .collect(Collectors.toList());
            if (!filteredAccountEntityList.isEmpty()) {
                // @formatter:off
                User wssUser = filteredAccountEntityStream(idvRegistrationType, filteredAccountEntityList)
                        .findFirst()
                        .map(AccountEntity::getLegalEntity)
                        .map(LegalEntity::getUser)
                        .orElseThrow(() -> new STWBusinessException("Unable to find WSS user for target account"));
                // @formatter:on

                if (wssUser.getIdnvLoginAttemptCount() < MAX_IDV_COUNT) {
                    wssUser.setIdnvLoginAttemptCount(ZERO_IDV_COUNT);
                    userDao.saveOrUpdate(wssUser);
                }
            }
        }
    }

    private Predicate<? super AccountEntity> filterAccountEntityPredicate(TargetAccountNumber targetAccountNumber,
            String legalEntity) {
        return account -> TargetAccountNumber.isSameAccount(account.getAccountNumber(), targetAccountNumber)
                && Long.parseLong(account.getLegalEntity().getLegalEntityId()) == Long.parseLong(legalEntity)
                && (account.getLegalEntity().getUser().getRegistrationType().equalsIgnoreCase(GUEST)
                        || account.getLegalEntity().getUser().getRegistrationType().equalsIgnoreCase(PARTIAL)
                        || account.getLegalEntity().getUser().getRegistrationType().equalsIgnoreCase(IDVG));
    }

}
