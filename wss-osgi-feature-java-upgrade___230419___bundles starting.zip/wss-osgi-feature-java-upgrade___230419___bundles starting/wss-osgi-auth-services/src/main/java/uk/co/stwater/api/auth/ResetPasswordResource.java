package uk.co.stwater.api.auth;

import java.net.URI;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.security.auth.login.AccountLockedException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.resetpassword.ResetPassword;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.Constants;
import uk.co.stwater.api.osgi.util.STWBusinessException;

/**
 * Created by rtai on 02/03/2017.
 */
@Named
@Consumes({ "application/json", "application/xml" })
@Produces({ "application/json", "application/xml" })
@Path("/WSSAccounts/Auth/ResetPassword")
public class ResetPasswordResource extends AbstractResource {

	private Logger logger = LoggerFactory.getLogger(ResetPasswordResource.class);	
	private static final String SELF_SERVICE_PASSWORD_RESET = "SSPR";

	@Inject
	private AuthenticationService authenticationService;

	void setAuthenticationService(AuthenticationService authenticationService) {
		this.authenticationService = authenticationService;
	}

    /**
     * Creates a ResetPassword resource with the generated token.
     * 
     * @param username
     * @return
     */
    @POST
    public Response forgottenPassword(
            ResetPassword forgottenPassword,
            @DefaultValue(Constants.STW) @HeaderParam(Constants.WSS_SITE) String site) {
        try {
            logger.info("Forgotten Password : username: {}", forgottenPassword.getUsername());

            ResetPassword resetPassword = authenticationService.forgottenPassword(forgottenPassword.getUsername(), site.toUpperCase());
            URI uri = UriBuilder.fromPath("/Auth/ResetPassword/{0}").build(resetPassword.getId());
            return Response.created(uri).entity(resetPassword).build();
        } catch (AuthenticationException authEx) {
            ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.AUTH_SERVICES, authEx.getCode(), authEx.getLocalizedMessage());
            return Response.status(Status.NOT_FOUND).entity(errorDto).build();
        }
    }

	/**
	 * Retrieves the ResetPassword resource.
	 * 
	 * @param id
	 * @param token
	 * @return
	 */
	@GET
	@Path("/{id}")
	public Response verifyResetPasswordLink(@PathParam("id") String id, @QueryParam("token") String token) {
		try {
			logger.info("verifyResetPasswordLink: id: {}, token:{}", id, token);
			ResetPassword resetPassword = new ResetPassword();
			resetPassword.setId(id);
			resetPassword.setToken(token);
			resetPassword = authenticationService.verifyForgottenPasswordLink(resetPassword);
			return Response.ok().entity(resetPassword).build();
		} catch (AuthenticationException ex) {
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.AUTH_SERVICES, ex.getCode(), ex.getLocalizedMessage());
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}
	}
	

    /**
     * Reset's the users password
     * @param resetPassword
     * @return
     * @throws AccountLockedException 
     * @throws AccountLockedForAnHrException 
     */
    @PUT
    public Response resetPassword(
            ResetPassword resetPassword,
            @DefaultValue(Constants.STW) @HeaderParam(Constants.WSS_SITE) String site) {
        try {
        	logger.info("Reset Password request received :{} / Href: {}", resetPassword.getAccountNumber(), resetPassword.getHref() );
        	if(resetPassword.getHref() != null && resetPassword.getHref().equals(SELF_SERVICE_PASSWORD_RESET)){
                Optional<ContactDto> contactDto = getContactDto();
                if (!contactDto.isPresent()) {
                    throw new STWBusinessException("Unable to find ContactDto");
                }
                authenticationService.updatePassword(resetPassword, contactDto.get(), site);
        	}else{
        		authenticationService.resetPassword(resetPassword);
        	}
        	logger.info("Reset Password end");
        	return Response.ok().entity(resetPassword).build();
        } catch (AuthenticationException e) {
        	if(!StringUtils.isEmpty(e.getMessage())){
        		ErrorDto errDto = null;
        		if(e.getMessage().equals("The current password entered does not match the one in our system")){
        			errDto = new ErrorDto("DM3.1", e.getMessage());
        		}else if(e.getMessage().equals("Provided username is not valid")){
        			errDto = new ErrorDto("", e.getMessage());
        		}else if(e.getCode().equals("DM3.1")){
					errDto = new ErrorDto("DM3.22", "The current password entered does not match the one in our system");
				}
        		return Response.status(Response.Status.BAD_REQUEST).entity(errDto).build();
        	}
        	else{
        		ErrorDto eDto = new ErrorDto(Response.Status.BAD_REQUEST.getStatusCode(), e.getLocalizedMessage());
        		return Response.status(Response.Status.BAD_REQUEST).entity(eDto).build();
        	}
        }
    }

}