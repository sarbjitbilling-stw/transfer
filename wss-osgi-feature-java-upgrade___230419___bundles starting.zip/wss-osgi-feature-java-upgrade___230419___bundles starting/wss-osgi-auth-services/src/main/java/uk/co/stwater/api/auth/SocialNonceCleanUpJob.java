package uk.co.stwater.api.auth;

import org.apache.aries.blueprint.annotation.service.Service;
import org.apache.aries.blueprint.annotation.service.ServiceProperty;
import org.apache.karaf.scheduler.Job;
import org.apache.karaf.scheduler.JobContext;
import org.apache.karaf.scheduler.Scheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.dao.SocialNonceDao;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.time.LocalDateTime;

//@formatter:off
@Service(classes = Job.class, properties = {
        @ServiceProperty(name = Scheduler.PROPERTY_SCHEDULER_NAME, values = "SocialNonceCleanUpJob"),
        // daily at midnight
        @ServiceProperty(name = Scheduler.PROPERTY_SCHEDULER_EXPRESSION, values = "0 0 0 * * ?")

})
//@formatter:on
@Singleton
public class SocialNonceCleanUpJob implements Job {
    private static final Logger LOG = LoggerFactory.getLogger(SocialNonceCleanUpJob.class);

    @Inject
    private SocialNonceDao socialNonceDao;

    @Override
    public void execute(JobContext context) {
        LOG.debug("Starting social nonce clean up job");
        int count = socialNonceDao.deleteNoncesOlderThan(LocalDateTime.now().minusMonths(1L));
        LOG.info("Deleted {} old social nonces.", count);
        LOG.debug("Social nonce clean up job finished");
    }
}
