package uk.co.stwater.api.osgi.account.contacts;

import uk.co.stwater.api.osgi.account.bean.AccountWebContactRefDataBean;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class WEB631DelContact extends AccountServicesContact implements CustomerContact {

	private static final String WEB631_CONTACT_TYPE = "WEB631";

	public WEB631DelContact(AccountRoles accountRole, String delReason, String failureData, String mainAccountName, String mainAccountEmail, AccountWebContactRefDataBean webContactRefData){
		super(mainAccountName, mainAccountEmail, webContactRefData);
		setRole(accountRole);
		setReason(delReason);
		setFailureDetail(failureData);
	}

	@Override
	public String getFormattedNote() {
		StringBuilder builder = new StringBuilder();
		builder.append(CUSTOMER_NAME_KEY).append(getMainAccountFullName());
		builder.append(NEW_LINE);
		builder.append(RELATIONSHIP_KEY).append(getWebContactRefData().getRelation());
		builder.append(NEW_LINE).append(NEW_LINE);
		builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
		builder.append("The following customer should be removed from this account: ").append(getRole().getLeTitleDesc()+" "+getRole().getLeFirstName()+" "+getRole().getLeSurname()).append(NEW_LINE);
		builder.append("Update to Target failed ").append(getFailureDetail()).append(NEW_LINE);
		builder.append("Email acknowledgment sent to ").append(getMainAccountEmail());
		return builder.toString();
	}

	@Override
	public String getContactType() {
		return WEB631_CONTACT_TYPE;
	}

	@Override
	public boolean isSubstantiveResponse() {
		return false;
	}

}