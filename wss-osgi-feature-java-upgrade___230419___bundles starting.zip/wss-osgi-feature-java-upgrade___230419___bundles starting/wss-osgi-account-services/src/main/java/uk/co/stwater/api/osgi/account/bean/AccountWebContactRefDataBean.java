package uk.co.stwater.api.osgi.account.bean;

public class AccountWebContactRefDataBean {

	private String relation;
	private String preferedTelNumInd;
	private String bankStatus;
	private String emplStatus;
	private String homeOwnStatus;
	
	public String getRelation() {
		return relation;
	}
	
	public void setRelation(String relation) {
		this.relation = relation;
	}
	
	public String getPreferedTelNumInd() {
		return preferedTelNumInd;
	}

	public void setPreferedTelNumInd(String preferedTelNumInd) {
		this.preferedTelNumInd = preferedTelNumInd;
	}

	public String getBankStatus() {
		return bankStatus;
	}
	
	public void setBankStatus(String bankStatus) {
		this.bankStatus = bankStatus;
	}
	
	public String getEmplStatus() {
		return emplStatus;
	}
	
	public void setEmplStatus(String emplStatus) {
		this.emplStatus = emplStatus;
	}
	
	public String getHomeOwnStatus() {
		return homeOwnStatus;
	}
	
	public void setHomeOwnStatus(String homeOwnStatus) {
		this.homeOwnStatus = homeOwnStatus;
	}	
}
