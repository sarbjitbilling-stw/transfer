package uk.co.stwater.api.osgi.account;

import java.util.List;
import java.util.Optional;

import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.AccountInfo;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Brand;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.user.UserLoginMethods;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

/**
 *
 * @author Mark
 */
public interface AccountService {

    Account getAccountSummary(TargetAccountNumber accountNumber, String postcode, long legalEntity, String authToken,
            Expands... expands) throws STWTechnicalException, STWBusinessException;

    List<AccountRoles> getAccountRoles(TargetAccountNumber accountNumber, Expands... expands)
            throws STWTechnicalException, STWBusinessException;

    AccountRoles addRoleToAccount(AccountRoles accountRole, String authToken, Optional<ContactDto> contactDto)
            throws STWTechnicalException, STWBusinessException;

    Boolean deleteAccountRole(Long roleId, TargetAccountNumber accountNumber, Long leNum, String authToken,
            Optional<ContactDto> contactDto) throws STWTechnicalException, STWBusinessException;

    List<AccountInfo> getAccountsByPropertyNumber(String propertyNumber)
            throws STWTechnicalException, STWBusinessException;

    List<Property> getPropertiesByAccountNumber(TargetAccountNumber accountNumber, String authToken)
            throws STWTechnicalException, STWBusinessException;

    Brand getBrandByAccount(TargetAccountNumber accountNumber, String authToken)
            throws STWTechnicalException, STWBusinessException;

    AccountBrand getAccountBrandForAccount(TargetAccountNumber accountNumber)
            throws STWTechnicalException, STWBusinessException;

    String getEmailAddressForLegalEntity(String legalEntityNumber);

    List<UserLoginMethods> getLoginMethods(TargetAccountNumber accountNumber, String legalEntityNo);

}
