package uk.co.stwater.api.osgi.account.contacts;

import uk.co.stwater.api.osgi.account.bean.AccountWebContactRefDataBean;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.constants.WebContactConstants;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class WEB629Contact extends AccountServicesContact implements CustomerContact {

	private static final String WEB629_CONTACT_TYPE = "WEB629";

	public WEB629Contact(AccountRoles accountRole, String changeReason, String mainAccountName, String mainAccountEmail, AccountWebContactRefDataBean webContactRefData){
		super(mainAccountName, mainAccountEmail, webContactRefData);
		setRole(accountRole);
		setReason(changeReason);
	}

	@Override
	public String getFormattedNote() {
		StringBuilder builder = new StringBuilder();
		builder.append(CUSTOMER_NAME_KEY).append(getMainAccountFullName());
		builder.append(NEW_LINE);
		builder.append(RELATIONSHIP_KEY).append(getWebContactRefData().getRelation());
		builder.append(NEW_LINE).append(NEW_LINE);
		builder.append(WebContactConstants.QUERY_DETAILS_KEY).append(NEW_LINE);
		builder.append("The following updates were made for ").append(getRole().getFullName()).append(NEW_LINE).append(NEW_LINE);
		builder = addPropertiesTable(builder);
		builder.append(NEW_LINE);
		builder.append("Reason for name change: ").append(getReason()).append(NEW_LINE);
		builder.append("Email 'Customer Details Provided' sent to ").append(getMainAccountEmail());
		return builder.toString();
	}

	@Override
	public String getContactType() {
		return WEB629_CONTACT_TYPE;
	}

	@Override
	public boolean isSubstantiveResponse() {
		return true;
	}
	
}