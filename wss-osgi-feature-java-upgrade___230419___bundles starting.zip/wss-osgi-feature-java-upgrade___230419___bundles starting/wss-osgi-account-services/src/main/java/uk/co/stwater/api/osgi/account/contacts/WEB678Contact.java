package uk.co.stwater.api.osgi.account.contacts;

import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

public class WEB678Contact extends AccountServicesContact implements CustomerContact {


	private final TargetAccountNumber accountNumber;

	public WEB678Contact(Customer customer, AccountRoles accountRole, TargetAccountNumber accountNumber, String relationshipToAccount){
		super(customer.getFullName(), relationshipToAccount, customer.getEmailAddress());
		this.accountNumber = accountNumber;
		setCustomer(customer);
		setRole(accountRole);
	}

	@Override
	public String getFormattedNote() {
	    return CUSTOMER_NAME_KEY +
                getRole().getLeTitleDesc() + " " + getRole().getLeFirstName() + " " + getRole().getLeSurname() +
                NEW_LINE +
                RELATIONSHIP_KEY + this.getMainAccountRel() +
                NEW_LINE +
                JOURNEY_KEY + SPACE + "Add account" +
                NEW_LINE + NEW_LINE +
                QUERY_DETAILS_KEY + NEW_LINE +
                "The customer has requested to switch to paperless billing. This option has been successfully added to the account. " +
				NEW_LINE+ ADITIONAL_INFORMATION_KEY + NEW_LINE +
                "Confirmation of the paperless billing request was sent to " + getCustomer().getEmailAddress() + ".";
	}

	@Override
	public String getContactType() {
		return ContactTypes.WEB678.toString();
	}

	@Override
	public boolean isSubstantiveResponse() {
		return false;
	}


	@Override
	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

}