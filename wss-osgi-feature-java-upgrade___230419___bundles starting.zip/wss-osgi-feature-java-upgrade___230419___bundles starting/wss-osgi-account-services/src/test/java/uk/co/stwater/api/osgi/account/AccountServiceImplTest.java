package uk.co.stwater.api.osgi.account;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.accountdetails.GetAccountDetsForAccAndPropertyClient;
import uk.co.stwater.targetconnector.client.api.accountinfo.GetBasicAccountInfoClient;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponseImpl;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AccountServiceImplTest {
    
    @Mock
    private GetAccountSummaryClient accountSummaryService;
    
    @Mock
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberClient;
    
    @Mock
    private GetAccountDetsForAccAndPropertyClient accountDetsForAccAndPropertyClient;
    
    @Mock
    private GetBasicAccountInfoClient basicAccountInfoClient;
    
    @InjectMocks
    AccountServiceImpl accountService  = new AccountServiceImpl();

	@Test
	public void relevanceComparatorTests(){
		Comparator<Property> priorityOrder = Collections.reverseOrder(Comparator.comparing(Property::getRelevenceScore))
        		.thenComparing(Comparator.comparing(Property::getEndDate, Comparator.nullsFirst(Comparator.reverseOrder())));
		
		// 4. If you have no property today, none in the future, but one in the past choose that.
		// A property started and ended in the past
		Property prop1 = new Property();
		prop1.setAddress("Carfax 1");
		prop1.setStartDate(LocalDate.now().minusMonths(2));
		prop1.setEndDate(LocalDate.now().minusDays(12));
		
		// 4. If you have no property today, none in the future, but one in the past choose that.
		// A property started in the past and open
		Property prop2 = new Property();
		prop2.setAddress("Carfax 2");
		prop2.setStartDate(LocalDate.now().minusDays(20));
		prop2.setEndDate(null);
		
		// 4. If you have no property today, none in the future, but one in the past choose that.
		// A property started in the past and ended in the present
		Property prop3 = new Property();
		prop3.setAddress("Carfax 3");
		prop3.setStartDate(LocalDate.now().minusDays(86));
		prop3.setEndDate(LocalDate.now());

		// 1. If you have a property that has a start date less than today and an end date after choose that one.
		// A property started in the past and ended in the future (> 3 < 15)
		Property prop4 = new Property();
		prop4.setAddress("Carfax 4");
		prop4.setStartDate(LocalDate.now().minusDays(20));
		prop4.setEndDate(LocalDate.now().plusDays(12));
		
		// 4. If you have no property today, none in the future, but one in the past choose that.
		Property prop5 = new Property();
		prop5.setAddress("Carfax 5");
		prop5.setStartDate(LocalDate.now().minusDays(20));
		prop5.setEndDate(LocalDate.now().minusDays(2));
		
		// 2. If you have multiple properties in category 1 choose a random one and then set the supply status to 'multiple'
		Property prop51 = new Property();
		prop51.setAddress("Carfax 51");
		prop51.setStartDate(LocalDate.now().minusDays(40));
		prop51.setEndDate(LocalDate.now().plusDays(22));
		
		// 3. If you have no property on the current date, but you have one starting in the future choose that
		// A property starting in the future
		Property prop6 = new Property();
		prop6.setAddress("Carfax 6");
		prop6.setStartDate(LocalDate.now().plusDays(20));
		prop6.setEndDate(null);
		
		// I will create an entry with two finalled accounts
		List<Property> propertiesFinalled = new ArrayList<Property>(Arrays.asList(prop1, prop5));
		propertiesFinalled.sort(priorityOrder);
    	Property propertyFinalled = propertiesFinalled.size()>0?propertiesFinalled.get(0):null;
    	assertNotNull(propertyFinalled.getAddress());
    	assertEquals("Carfax 5", propertyFinalled.getAddress());
    	
    	// I make the date later than propr1 and check again
    	prop5.setEndDate(LocalDate.now().minusDays(222));
    	List<Property> propertiesFinalled2 = new ArrayList<Property>(Arrays.asList(prop1, prop5));
    	propertiesFinalled2.sort(priorityOrder);
    	Property propertyFinalled2 = propertiesFinalled2.size()>0?propertiesFinalled2.get(0):null;
    	assertNotNull(propertyFinalled2.getAddress());
    	assertEquals("Carfax 1", propertyFinalled2.getAddress());
    	
    	// 1. If you have a property that has a start date less than today and an end date after choose that one.
    	// Only one with date in the future (date in the future + null dates)
    	List<Property> propertiesT1 = new ArrayList<Property>(Arrays.asList(prop1, prop5, prop51));
    	propertiesT1.sort(priorityOrder);
    	Property propertyT1 = propertiesT1.size()>0?propertiesT1.get(0):null;
    	assertNotNull(propertyT1.getAddress());
    	assertEquals("Carfax 51", propertyT1.getAddress());
    	
    	// 1. If you have a property that has a start date less than today and an end date after choose that one.
    	// Only one with date in the future (date in the future + null dates)
    	List<Property> propertiesT2 = new ArrayList<Property>(Arrays.asList(prop1, prop4, prop5));
    	propertiesT2.sort(priorityOrder);
    	Property propertyT2 = propertiesT2.size()>0?propertiesT2.get(0):null;
    	assertNotNull(propertyT2.getAddress());
    	assertEquals("Carfax 4", propertyT2.getAddress());
    	
    	// 2. If you have multiple properties in category 1 choose a random one (should get the one with latest end date)
    	List<Property> propertiesT3 = new ArrayList<Property>(Arrays.asList(prop1, prop4, prop5, prop51));
    	propertiesT3.sort(priorityOrder);
    	Property propertyT3 = propertiesT3.size()>0?propertiesT3.get(0):null;
    	assertNotNull(propertyT3.getAddress());
    	assertEquals("Carfax 51", propertyT3.getAddress());
    	
    	// 3. If you have no property on the current date, but you have one starting in the future choose that
    	List<Property> propertiesT4 = new ArrayList<Property>(Arrays.asList(prop1, prop5, prop6));
    	propertiesT4.sort(priorityOrder);
    	Property propertyT4 = propertiesT4.size()>0?propertiesT4.get(0):null;
    	assertNotNull(propertyT4.getAddress());
    	assertEquals("Carfax 6", propertyT4.getAddress());
    	
    	// 4. If you have no property today, none in the future, but one in the past choose that.
    	List<Property> propertiesT5 = new ArrayList<Property>(Arrays.asList(prop1, prop5));
    	propertiesT5.sort(priorityOrder);
    	Property propertyT5 = propertiesT5.size()>0?propertiesT5.get(0):null;
    	assertNotNull(propertyT5.getAddress());
    	assertEquals("Carfax 1", propertyT5.getAddress());
	}
	
    @Test
    public void shouldNotCallGetAccountDetailsFromAccountSummaryIfNoPropertyIdIsPresent() {
        Long legalEntityNumber = 1l;
        TargetAccountNumber targetAccountNumber = new TargetAccountNumber(6500733187l);
        String postcode = "CV49LY";
        Property property = new Property();
        String propertyId = "1";
        property.setPropertyId(propertyId);

        when(accountSummaryService.getAccountSummary(targetAccountNumber, legalEntityNumber)).thenReturn(any());
        when(propertiesForAccountNumberClient.getPropertiesForAccountNumber(targetAccountNumber, any(String.class)))
                .thenReturn(any(List.class));
        when(basicAccountInfoClient.getAccountInfo(targetAccountNumber)).thenReturn(any());

        Account account = accountService.getAccountSummary(targetAccountNumber, postcode, legalEntityNumber,
                StringUtils.EMPTY, Expands.basicInfo);

        assertNotNull(account);

        verify(accountDetsForAccAndPropertyClient, never()).getAccountDetails(targetAccountNumber,
                Long.parseLong(property.getPropertyId()));
    }
    
    @Test
    public void shouldCallAccountSummaryForSummaryExpand() {
        Long legalEntityNumber = 1l;
        TargetAccountNumber targetAccountNumber = new TargetAccountNumber(6500733187l);
        String postcode = "CV49LY";
        AccountSummaryResponseImpl response = new AccountSummaryResponseImpl(targetAccountNumber);

        when(accountSummaryService.getAccountSummary(targetAccountNumber, legalEntityNumber)).thenReturn(response);

        Account account = accountService.getAccountSummary(targetAccountNumber, postcode, legalEntityNumber,
                StringUtils.EMPTY, Expands.summary);

        assertNotNull(account);

        verify(accountSummaryService, times(1)).getAccountSummary(targetAccountNumber, legalEntityNumber);

    }

    @Test
    public void shouldCallPropertyForAccountNumberForPropertyExpand() {
        Long legalEntityNumber = 1l;
        TargetAccountNumber targetAccountNumber = new TargetAccountNumber(6500733187l);
        String postcode = "CV49LY";
        Property property = new Property();
        String propertyId = "1";
        property.setPropertyId(propertyId);
        List<Property> propertyList = new ArrayList<>();
        propertyList.add(property);

        when(propertiesForAccountNumberClient.getPropertiesForAccountNumber(any(TargetAccountNumber.class),
                any(String.class))).thenReturn(propertyList);

        Account account = accountService.getAccountSummary(targetAccountNumber, postcode, legalEntityNumber,
                StringUtils.EMPTY, Expands.property);

        assertNotNull(account);

        verify(propertiesForAccountNumberClient, times(1)).getPropertiesForAccountNumber(any(TargetAccountNumber.class),
                any(String.class));

    }
	
}
