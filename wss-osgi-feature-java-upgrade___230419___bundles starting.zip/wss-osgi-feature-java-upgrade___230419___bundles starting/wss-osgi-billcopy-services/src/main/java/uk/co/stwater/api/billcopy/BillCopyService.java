package uk.co.stwater.api.billcopy;

import uk.co.stwater.api.osgi.model.PaperCopyBillRequest;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.util.Optional;

public interface BillCopyService {
    void createPaperBillCopyRequest(PaperCopyBillRequest paperCopyBillRequest, Optional<ContactDto> contactDto) throws STWTechnicalException, STWBusinessException;
}
