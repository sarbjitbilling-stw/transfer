package uk.co.stwater.api.billcopy;

import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.setcopybillflag.PaperCopyBillRequest;

/**
 * Created by jagad on 20/07/2017.
 */
public class BillCopyContact implements CustomerContact {

    private static final String COPY_OF_BILL_DATE_KEY = "Copy of bill dated ";
    private static final String CONTACT_EMAIL_KEY = "Email acknowledgement sent to ";
    private static final String REQUESTED =" requested.";
    private static final String REQUEST_FAILED ="Copy bill request failed in Target.";
    private static final String ISSUED =" issued.";
    private static final String ERROR_CODE_KEY = "Error code: ";
    private static final String ERROR_DESCRIPTION_KEY = "Error description: ";
    private static final String ERROR_MESSAGE = "Email 'Copy Bill Request' sent to registered email address.";
    private static final String QUERY_KEY = "Query Details:";

    private static final String ERROR_CODE = "DM1.9";
    private static final String ERROR_DESCRIPTION = "Sorry, you are unable to complete this transaction at this time.  Please contact us on @@websupportTelephoneNumber@@ and we will help you. \n" +
                                                     "Our opening times are @@openingTimes@@";

    Exception exception;
 
    protected ContactNotesData contactNotesData;
    protected PaperCopyBillRequest paperCopyBillRequest;
    protected ContactTypes contactType;

    public BillCopyContact(ContactNotesData contactNotesData,PaperCopyBillRequest paperCopyBillRequest, ContactTypes contactType) {
        this(contactNotesData, paperCopyBillRequest, contactType, null);
    }

    public BillCopyContact(ContactNotesData contactNotesData, PaperCopyBillRequest paperCopyBillRequest, ContactTypes contactType,Exception ex) {
        this.contactNotesData = contactNotesData;
        this.paperCopyBillRequest = paperCopyBillRequest;
        this.contactType=contactType;
        this.exception =  ex;
    }

    @Override
    public TargetAccountNumber getAccountNumber() {
           return paperCopyBillRequest.getAccountNumber();
    }
    @Override
    public String getContactType() {
            return contactType.toString();
    }

    @Override
    public Long getPropertyNumber() {
        return null;
    }

    @Override
    public String getLegalEntityNumber() {
           return paperCopyBillRequest.getLeId();
    }

    @Override
    public String getFormattedNote() {
        StringBuilder builder = new StringBuilder();
        builder.append(CustomerContact.getFormattedCustomerDetails(contactNotesData)).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(QUERY_KEY).append(NEW_LINE);
        builder.append(COPY_OF_BILL_DATE_KEY).append(paperCopyBillRequest.getInvoiceDate()).append(REQUESTED).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(ACTION_TAKEN_KEY).append(NEW_LINE);       
        
        if (contactType.equals(ContactTypes.WEB618)) {
            builder.append(COPY_OF_BILL_DATE_KEY).append(paperCopyBillRequest.getInvoiceDate()).append(ISSUED).append(NEW_LINE);
            builder.append(NEW_LINE);
            builder.append(CONTACT_EMAIL_KEY).append(paperCopyBillRequest.getEmail()).append(NEW_LINE);          
        }
        else {
            builder.append(REQUEST_FAILED).append(NEW_LINE);
            builder.append(ERROR_CODE_KEY).append(ERROR_CODE).append(NEW_LINE);
            builder.append(ERROR_DESCRIPTION_KEY).append(ERROR_DESCRIPTION).append(NEW_LINE);
            builder.append(NEW_LINE);
            builder.append(ERROR_MESSAGE);
        }
        return builder.toString();
    }

    @Override
    public boolean isSubstantiveResponse() {
        return true;
    }

    @Override
    public String getPostcode() {
        return paperCopyBillRequest.getPostCode();
    }
}