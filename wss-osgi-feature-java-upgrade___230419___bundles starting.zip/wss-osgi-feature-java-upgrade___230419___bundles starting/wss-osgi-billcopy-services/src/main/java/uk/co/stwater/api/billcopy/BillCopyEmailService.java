package uk.co.stwater.api.billcopy;

import uk.co.stwater.api.osgi.model.common.ContactDto;

/**
 * Created by jagad on 20/07/2017.
 */
public interface BillCopyEmailService {

    void sendPaperCopyBillResponseEmail(String emailAddress, ContactDto contactDto);
}