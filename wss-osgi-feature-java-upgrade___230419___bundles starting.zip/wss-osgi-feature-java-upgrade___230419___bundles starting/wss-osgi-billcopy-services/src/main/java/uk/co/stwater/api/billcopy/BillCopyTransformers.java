package uk.co.stwater.api.billcopy;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.util.TransformerBase;
import uk.co.stwater.targetconnector.client.api.setcopybillflag.PaperCopyBillRequest;

public class BillCopyTransformers extends TransformerBase {

    public static final Transformer SOAP_RESPONSE_TO_BILLCOPY_RESPONSE_ENTITY = new Transformer() {
        @Override
        public PaperCopyBillRequest transform(Object input) {
        	return copy(input, new PaperCopyBillRequest());
        }
        
    };
}
