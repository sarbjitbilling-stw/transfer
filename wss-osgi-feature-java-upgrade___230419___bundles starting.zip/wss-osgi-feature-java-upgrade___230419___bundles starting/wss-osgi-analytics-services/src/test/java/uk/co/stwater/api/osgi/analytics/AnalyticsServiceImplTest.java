
package uk.co.stwater.api.osgi.analytics;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.severntrent.billing_service.types.getpersonaldetailsresponse.v1.CTypeResponseBody;
import uk.co.stwater.api.dao.AnalyticsDao;
import uk.co.stwater.api.dao.PostcodeDmaControlGroupDao;
import uk.co.stwater.api.dao.PostcodeDmaDao;
import uk.co.stwater.api.dao.entity.AnalyticsEntity;
import uk.co.stwater.api.dao.entity.PostcodeDmaControlgroup;
import uk.co.stwater.api.osgi.account.AccountService;
import uk.co.stwater.api.osgi.model.*;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.directdebit.DirectDebit;
import uk.co.stwater.api.osgi.model.payment.directdebit.PaymentDetails;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.payment.scheduled.ScheduledPaymentService;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsResponse;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.Silent.class)
public class AnalyticsServiceImplTest {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @InjectMocks
    private AnalyticsService analyticsService = new AnalyticsServiceImpl();

    @Mock
    private SpecialConditionService specialConditionService;

    @Mock
    private AnalyticsDao analyticsDao;

    @Mock
    private AccountService accountService;

    @Mock
    private PersonalDetailsClient personalDetailsClient;

    @Mock
    private ScheduledPaymentService scheduledPaymentService;

    @Mock
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberClient;

    @Mock
    private PostcodeDmaDao postcodeDmaDao;
    
    @Mock
    private PostcodeDmaControlGroupDao postcodeDmaControlGroupDao;

    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd/MM/yyyy");


    private AnalyticsEntity getDefaultAnalyticsEntity() {
        AnalyticsEntity analyticsEntity = new AnalyticsEntity();
        analyticsEntity.setAccountNumber(new TargetAccountNumber(123456786));
        analyticsEntity.setExternalLeId("123456789");
        return analyticsEntity;
    }

    private List<SpecialConditionAnalyticsCode> getDefaultSpecialConditionAnalyticsCodes(){
        List<SpecialConditionAnalyticsCode> specialConditionAnalyticsCodeList = new ArrayList<>();
        specialConditionAnalyticsCodeList.add(new SpecialConditionAnalyticsCode("SC001"));
        return specialConditionAnalyticsCodeList;
    }

    private Account getDefaultAccount() throws ParseException {
        Address address = new Address();
        address.setPostcode("CV22 6LS");

        Account account = new Account();
        account.setWssPaperlessBillFlag("Y");
        account.setAccountStatus("A");
        account.setPaymentPlanIndicator("D");
        account.setLastInvoiceIssueDate(DATE_FORMATTER.parse("09/04/1987"));
        account.setLastInvoiceAmount(new BigDecimal("242"));
        account.setAccountBalance(new BigDecimal("118"));
        account.setSupplyAddress(address);
        account.setSpecCondAlertFlag("Y");
        return account;
    }

    private PersonalDetailsResponse getDefaultPersonalDetails() throws ParseException, DatatypeConfigurationException {
        CTypeResponseBody personDetails = new CTypeResponseBody();
        GregorianCalendar c = new GregorianCalendar();
        c.setTime(DATE_FORMATTER.parse("07/10/1976"));
        personDetails.setDoB(DatatypeFactory.newInstance().newXMLGregorianCalendar(c));
        PersonalDetailsResponse personalDetailsResponse = new PersonalDetailsResponse("1232", personDetails);
        return personalDetailsResponse;
    }

    private DirectDebit getDefaultDirectDebit(){
        DirectDebit directDebit = new DirectDebit();
        PaymentDetails paymentDetails = new PaymentDetails();
        directDebit.setPaymentDetails(paymentDetails);
        RefData freq = new RefData();
        freq.setCode("M");
        RefData fac = new RefData();
        fac.setCode("PP");
        paymentDetails.setFacilityCode(fac);
        paymentDetails.setScheduleFreqCode(freq);
        return directDebit;
    }

    private List<Property> getDefaultProperty(){
        Property property = new Property();
        property.setStartDate(LocalDate.now().minusYears(10));
        property.setEndDate(null);
        RefData measured = new RefData();
        measured.setCode("M");
        property.setMeasuredIndicator(measured);
        property.setPostcode("CV22 6LS");
        List<Property> properties = new ArrayList<>();
        properties.add(property);
        return properties;
    }

    private List<PostcodeDmaControlgroup> getDefautDmas(){
    	PostcodeDmaControlgroup postcodeDmaControlgroup = new PostcodeDmaControlgroup();
    	postcodeDmaControlgroup.setDistrict("B12");
    	postcodeDmaControlgroup.setSector("B12 0");
    	postcodeDmaControlgroup.setOrignalDma("04671");
    	postcodeDmaControlgroup.setDma("04/671");
    	postcodeDmaControlgroup.setControlGroupId("CGEL01");
    	postcodeDmaControlgroup.setControlGroupname("Birmingham Low Level");
    	postcodeDmaControlgroup.setWqzcode("ZBR14");
    	postcodeDmaControlgroup.setWqzname("Small Heath");    	
    	postcodeDmaControlgroup.setPostcode("B120QR");
        List<PostcodeDmaControlgroup> dmas = new ArrayList<>();
        dmas.add(postcodeDmaControlgroup);
        return dmas;
    }

    private void setUpDefaultMocks() throws ParseException, DatatypeConfigurationException {
        when(analyticsDao.findByAnalyticsId(anyString())).thenReturn(Optional.of(getDefaultAnalyticsEntity()));
        when(specialConditionService.getSpecialConditionAnalyticsCodes(anyObject(), anyLong())).thenReturn(getDefaultSpecialConditionAnalyticsCodes());
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(getDefaultAccount());
        when(personalDetailsClient.getPersonalDetails(anyObject(), anyString(), anyLong())).thenReturn(getDefaultPersonalDetails());
        when(scheduledPaymentService.getDirectDebit(anyObject(), anyLong())).thenReturn(getDefaultDirectDebit());
        when(propertiesForAccountNumberClient.getPropertiesForAccountNumber(anyObject(), any())).thenReturn(getDefaultProperty());
        when(postcodeDmaControlGroupDao.findDmaControlgroupByPostcode(anyString())).thenReturn(getDefautDmas());
    }

    @Test
    public void accountBalance1() throws ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        Account account = getDefaultAccount();
        account.setAccountBalance(new BigDecimal("0"));
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(account);
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("A", analyticsMap.get("J"));
    }

    @Test
    public void accountBalance2() throws ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        Account account = getDefaultAccount();
        account.setAccountBalance(new BigDecimal("0.98"));
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(account);
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("B", analyticsMap.get("J"));
    }

    @Test
    public void accountBalance3() throws ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        Account account = getDefaultAccount();
        account.setAccountBalance(new BigDecimal("4.99"));
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(account);
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("C", analyticsMap.get("J"));
    }

    @Test
    public void accountBalance4() throws ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        Account account = getDefaultAccount();
        account.setAccountBalance(new BigDecimal("49"));
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(account);
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("0", analyticsMap.get("J"));
    }

    @Test
    public void accountBalance5() throws ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        Account account = getDefaultAccount();
        account.setAccountBalance(new BigDecimal("99"));
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(account);
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("1", analyticsMap.get("J"));
    }

    @Test
    public void accountBalance6() throws ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        Account account = getDefaultAccount();
        account.setAccountBalance(new BigDecimal("-17"));
        when(accountService.getAccountSummary(anyObject(), anyString(), anyLong(), any(), anyObject(), anyObject(), anyObject())).thenReturn(account);
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("A", analyticsMap.get("J"));
    }


    @Test
    public void getAnalytics() throws STWTechnicalException, STWBusinessException, ParseException, DatatypeConfigurationException {
        setUpDefaultMocks();
        AnalyticsSummary summary = analyticsService.getAnalytics("21113f49239e479e8d313d8518125955", null, null);
        Map<String, String> analyticsMap = summary.getAnalyticsMap();
        assertEquals("A", analyticsMap.get("A"));
        //removed as too slow - may be put back in later
        assertEquals("A", analyticsMap.get("B"));
        /*assertEquals("D", analyticsMap.get("C"));
        assertEquals("B", analyticsMap.get("D"));*/
        assertEquals("A", analyticsMap.get("E"));
        assertEquals("SC001", analyticsMap.get("F"));
        assertEquals("A", analyticsMap.get("G"));
        assertEquals("09/04/1987", analyticsMap.get("H"));
        assertEquals("4", analyticsMap.get("I"));
        assertEquals("2", analyticsMap.get("J"));
        assertEquals("G", analyticsMap.get("K"));
        assertEquals("04/671", analyticsMap.get("L"));
    }

    @Test
    public void getZoneAndDmaByPostcode(){
        when(postcodeDmaControlGroupDao.findDmaControlgroupByPostcode(anyString())).thenReturn(getDefautDmas());

        ZoneAndDma zoneAndDma = analyticsService.getZoneAndDmaByPostcode("B12 0QR");
   //     assertEquals("04/671", zoneAndDma.getDma());
        assertEquals("ZBR14", zoneAndDma.getZone());
    }



}
