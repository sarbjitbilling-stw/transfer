
package uk.co.stwater.api.osgi.analytics;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.dao.AnalyticsDao;
import uk.co.stwater.api.dao.PostcodeDmaControlGroupDao;
import uk.co.stwater.api.dao.PostcodeDmaDao;
import uk.co.stwater.api.dao.entity.AnalyticsEntity;
import uk.co.stwater.api.dao.entity.PostcodeDmaControlgroup;
import uk.co.stwater.api.osgi.account.AccountService;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AnalyticsSummary;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionAnalyticsCode;
import uk.co.stwater.api.osgi.model.ZoneAndDma;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.directdebit.DirectDebit;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.payment.scheduled.ScheduledPaymentService;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsResponse;


@Named
@OsgiServiceProvider(classes = {AnalyticsService.class})
public class AnalyticsServiceImpl implements AnalyticsService {

    private static final String UNKNOWN_POSTCODE = "POSTCODE";
    private static final String Y = "Y";
    private static final char SEPARATOR = ',';
    private static final String WEEKLY = "W";
    private static final String FORTNIGHTLY = "K";
    private static final String FOUR_WEEKLY = "T";
    private static final String MONTHLY = "M";
    private static final String DIRECT_DEBIT = "D";
    private static final String WATERCARD = "PP";
    private static final String BOOKLET = "B";
    private static final String CREDIT_DEBIT = "CD";
    private static final String VIA_BANK = "VB";
    private static final String RECURRING_CREDIT = "RC";
    private static final String PINGIT = "PI";
    private static final String DMA_FORMAT = "%s/%s";
    public static final char SPACE = ' ';

    private enum FRIENDLY_CODES{
        A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, Z
    }

    private enum ANALYTICS_REQUIREMENT{

        SERVICE_PROVISION("A"), PAYMENT_PLAN("B"), PAYMENT_PLAN_FREQUENCY("C"), PAYMENT_PLAN_METHOD("D"), PAPERLESS("E"), SPECIAL_CONDITIONS("F"), ACCOUNT_STATUS("G"),
        LAST_BILL_DATE("H"), LAST_BILL_AMOUNT("I"), ACCOUNT_BALANCE("J"), CURRENT_AGE("K"), PROPERTY_DMA("L");

        private String code;

        ANALYTICS_REQUIREMENT(String code){
            this.code = code;
        }

        String getCode(){
            return this.code;
        }
    }

    private static final String A = "A";
    private static final String F = "F";
    private static final String T = "T";
    private static final String N = "N";
    private final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
    private static final String MEASURED = "M";
    private static final String UNMEASURED = "U";
    private static final String ASSESSED = "A";
    private static final int BILL_AMOUNT_BAND_SIZE = 50;
    private static final BigDecimal ACCOUNT_BALANCE_BAND_SIZE = new BigDecimal("50");
    private static final BigDecimal NINETY_EIGHT_PENCE = new BigDecimal("0.98");
    private static final BigDecimal FOUR_POUNDS_NINETY_NINE = new BigDecimal("4.99");

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    @OsgiService
    private SpecialConditionService specialConditionService;

    @Inject
    @OsgiService
    private AnalyticsDao analyticsDao;

    @Inject
    @OsgiService
    private AccountService accountService;

    @OsgiService
    @Inject
    PersonalDetailsClient personalDetailsClient;

    @OsgiService
    @Inject
    private ScheduledPaymentService scheduledPaymentService;

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberClient;

    @Inject
    @OsgiService
    private PostcodeDmaDao postcodeDmaDao;
    
    @Inject
    @OsgiService
    private PostcodeDmaControlGroupDao postcodeDmaControlGroupDao;

    @Override
    public AnalyticsSummary getAnalytics(String analyticsId, String postcode, String authToken) throws STWTechnicalException, STWBusinessException {

        log.info("Getting analytics for analytics ID {} and postcode {}", analyticsId, postcode);
        Optional<AnalyticsEntity> analyticsEntity = analyticsDao.findByAnalyticsId(analyticsId);

        if(!analyticsEntity.isPresent()){
            log.warn("Analytics ID {} not found in database", analyticsId);
            throw new STWBusinessException("ID not found");
        } else {
            AnalyticsSummary analytics = new AnalyticsSummary();

            analyticsEntity.ifPresent(analyticsDb -> {
                TargetAccountNumber targetAccountNumber = analyticsDb.getAccountNumber();
                long legalEntityId = Long.parseLong(analyticsDb.getExternalLeId());
                addAccountAnalytics(analytics, targetAccountNumber, legalEntityId, postcode, authToken);
                addCurrentAgeBandAnalytics(analytics, targetAccountNumber, legalEntityId);
                //removed as too slow - may be put back in later
                //addPaymentPlanAnalytics(analytics, targetAccountNumber, legalEntityId);
                addPropertyAnalytics(analytics, targetAccountNumber, authToken);
            });
            log.debug("Analytics completed - returning {}", analytics);
            String hash = DigestUtils.md5Hex(analytics.getAnalyticsMap().toString());
            analytics.getAnalyticsMap().put("hash",hash);
            return analytics;
        }
    }

    private void addPaymentPlanAnalytics(AnalyticsSummary analytics, TargetAccountNumber targetAccountNumber, long legalEntityId){
        DirectDebit directDebit = scheduledPaymentService.getDirectDebit(targetAccountNumber, legalEntityId);

        addPaymentPlanFrequencyAnalytics(analytics, directDebit);
        addPaymentPlanMethodAnalytics(analytics, directDebit);
    }

    private void addPaymentPlanFrequencyAnalytics(AnalyticsSummary analytics, DirectDebit directDebit){
        if(directDebit != null && directDebit.getPaymentDetails() != null) {
            if (directDebit.getPaymentDetails().getScheduleFreqCode() != null) {
                FRIENDLY_CODES friendlyFrequencyCode;
                switch (directDebit.getPaymentDetails().getScheduleFreqCode().getCode()) {
                    case WEEKLY:
                        friendlyFrequencyCode = FRIENDLY_CODES.A;
                        break;
                    case FORTNIGHTLY:
                        friendlyFrequencyCode = FRIENDLY_CODES.B;
                        break;
                    case FOUR_WEEKLY:
                        friendlyFrequencyCode = FRIENDLY_CODES.C;
                        break;
                    case MONTHLY:
                        friendlyFrequencyCode = FRIENDLY_CODES.D;
                        break;
                    default:
                        friendlyFrequencyCode = FRIENDLY_CODES.Z;
                }
                analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.PAYMENT_PLAN_FREQUENCY.getCode(), friendlyFrequencyCode.toString());
            }
        }
    }

    private void addPaymentPlanMethodAnalytics(AnalyticsSummary analytics, DirectDebit directDebit){
        if(directDebit != null && directDebit.getPaymentDetails() != null) {
            if (directDebit.getPaymentDetails().getFacilityCode() != null) {
                FRIENDLY_CODES friendlyMethodCode;
                switch (directDebit.getPaymentDetails().getFacilityCode().getCode()) {
                    case DIRECT_DEBIT:
                        friendlyMethodCode = FRIENDLY_CODES.A;
                        break;
                    case WATERCARD:
                        friendlyMethodCode = FRIENDLY_CODES.B;
                        break;
                    case BOOKLET:
                        friendlyMethodCode = FRIENDLY_CODES.C;
                        break;
                    case CREDIT_DEBIT:
                        friendlyMethodCode = FRIENDLY_CODES.D;
                        break;
                    case VIA_BANK:
                        friendlyMethodCode = FRIENDLY_CODES.E;
                        break;
                    case RECURRING_CREDIT:
                        friendlyMethodCode = FRIENDLY_CODES.F;
                        break;
                    case PINGIT:
                        friendlyMethodCode = FRIENDLY_CODES.G;
                        break;
                    default:
                        friendlyMethodCode = FRIENDLY_CODES.Z;
                }
                analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.PAYMENT_PLAN_METHOD.getCode(), friendlyMethodCode.toString());
            }
        }
    }

    private void addAccountAnalytics(AnalyticsSummary analytics, TargetAccountNumber targetAccountNumber, long legalEntityId, String postcodeProvided, String authToken){
        Account account = accountService.getAccountSummary(targetAccountNumber, UNKNOWN_POSTCODE, legalEntityId, authToken,
                Expands.summary, Expands.detail, Expands.registration);

        addPaperlessAccountAnalytics(analytics, account);
        addAccountStatusAnalytics(analytics, account);
        addPaymentPlanAnalytics(analytics, account);
        addLastBillDateAnalytics(analytics, account);
        addLastBillAmountAnalytics(analytics, account);
        addAccountBalanceAnalytics(analytics, account);
        addDmaAnalytics(analytics, account, postcodeProvided);
        addSpecialConditionAnalytics(analytics, targetAccountNumber, legalEntityId);
    }

    private void addPropertyAnalytics(AnalyticsSummary analytics, TargetAccountNumber targetAccountNumber, String authToken){
        List<Property> onSupplyProperties = propertiesForAccountNumberClient.getPropertiesForAccountNumber(targetAccountNumber, authToken).stream()
                .filter((propertyData) -> propertyData.getSupplyStatus().equals(Property.SupplyStatus.ON_SUPPLY)).collect(Collectors.toList());

        addServiceProvisionAnalytics(analytics, onSupplyProperties);
    }

    private void addServiceProvisionAnalytics(AnalyticsSummary analytics, List<Property> onSupplyProperties){
        if(onSupplyProperties.size() > 0){
            List<String> codes = onSupplyProperties.stream().map(property -> {
                String code = property.getMeasuredIndicator().getCode();
                log.debug("Service provision code: {}", code);
                switch(code){
                    case MEASURED: return FRIENDLY_CODES.A.toString();
                    case UNMEASURED: return FRIENDLY_CODES.B.toString();
                    case ASSESSED: return FRIENDLY_CODES.C.toString();
                    default: return FRIENDLY_CODES.Z.toString();
                }
            }).collect(Collectors.toList());
            analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.SERVICE_PROVISION.getCode(), StringUtils.join(codes, SEPARATOR));
        }
    }

    private void addDmaAnalytics(AnalyticsSummary analytics, Account account, String providedPostcode){
        String postcode = providedPostcode;
        if(StringUtils.isEmpty(postcode)){
            log.debug("No postcode provided");
            if(account.getSupplyAddress() != null) {
                postcode = account.getSupplyAddress().getPostcode();
                log.debug("Using supply address postcode {}", postcode);
            }
        }

        if(StringUtils.isNotEmpty(postcode)){
            log.debug("Using postcode {}", postcode);
            postcode = StringUtils.remove(postcode, SPACE);
            List<PostcodeDmaControlgroup> dmas = postcodeDmaControlGroupDao.findDmaControlgroupByPostcode(postcode.toUpperCase());
            if(dmas.isEmpty()){
                log.debug("no dma found - trying for {}", postcode.substring(0, 4));
                dmas = postcodeDmaControlGroupDao.findDmaControlgroupByPostcode(postcode.substring(0, 4));
            }
            dmas.stream().findFirst().ifPresent(dma ->
                analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.PROPERTY_DMA.getCode(), dma.getDma())
            );
        } else {
            log.warn("Couldn't find postcode");
        }
    }

    private void addPaperlessAccountAnalytics(AnalyticsSummary analytics, Account account){
        analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.PAPERLESS.getCode(), Y.equals(account.getWssPaperlessBillFlag())? FRIENDLY_CODES.A.toString() :FRIENDLY_CODES.B.toString());
    }

    private void addAccountStatusAnalytics(AnalyticsSummary analytics, Account account){
        String accountStatus = account.getAccountStatus();
        log.debug("account status: {}", accountStatus);
        FRIENDLY_CODES friendlyAccountStatus;
        switch(accountStatus){
            case A: friendlyAccountStatus = FRIENDLY_CODES.A; break;
            case F: friendlyAccountStatus = FRIENDLY_CODES.B; break;
            case T: friendlyAccountStatus = FRIENDLY_CODES.C; break;
            default: friendlyAccountStatus = FRIENDLY_CODES.Z;
        }
        analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.ACCOUNT_STATUS.getCode(), friendlyAccountStatus.toString());
    }

    private void addPaymentPlanAnalytics(AnalyticsSummary analytics, Account account){
        String paymentPlanIndicator = account.getPaymentPlanIndicator();
        analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.PAYMENT_PLAN.getCode(), (paymentPlanIndicator != null && !N.equals(paymentPlanIndicator))?FRIENDLY_CODES.A.toString():FRIENDLY_CODES.B.toString());
    }

    private void addSpecialConditionAnalytics(AnalyticsSummary analytics, TargetAccountNumber targetAccountNumber, long legalEntityId){
        analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.SPECIAL_CONDITIONS.getCode(),
                StringUtils.join(specialConditionService.getSpecialConditionAnalyticsCodes(targetAccountNumber,
                        legalEntityId).stream().map(SpecialConditionAnalyticsCode::getCode).collect(Collectors.toList()), SEPARATOR));
    }

    private void addLastBillAmountAnalytics(AnalyticsSummary analytics, Account account){
        BigDecimal lastBillAmount = account.getLastInvoiceAmount();
        if(lastBillAmount != null) {
            log.debug("last bill amount: {}", lastBillAmount);
            analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.LAST_BILL_AMOUNT.getCode(), String.valueOf(lastBillAmount.intValue()/BILL_AMOUNT_BAND_SIZE));
        }
    }

    private void addAccountBalanceAnalytics(AnalyticsSummary analytics, Account account){
        BigDecimal accountBalance = account.getAccountBalance();

        if(accountBalance != null) {
            log.debug("account balance: {}", accountBalance);
            String analyticsValue;

            if(accountBalance.compareTo(BigDecimal.ZERO) < 1){
                analyticsValue = FRIENDLY_CODES.A.toString();
            } else if(accountBalance.compareTo(NINETY_EIGHT_PENCE) < 1){
                analyticsValue = FRIENDLY_CODES.B.toString();
            } else if(accountBalance.compareTo(FOUR_POUNDS_NINETY_NINE) < 1){
                analyticsValue = FRIENDLY_CODES.C.toString();
            } else {
                analyticsValue = accountBalance.divideToIntegralValue(ACCOUNT_BALANCE_BAND_SIZE).toBigInteger().toString();
            }
            analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.ACCOUNT_BALANCE.getCode(), analyticsValue);
        }
    }

    private void addLastBillDateAnalytics(AnalyticsSummary analytics, Account account){
        Date lastBillDate = account.getLastInvoiceIssueDate();
        if(lastBillDate != null) {
            synchronized (dateFormatter) {
                analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.LAST_BILL_DATE.getCode(),
                        dateFormatter.format(lastBillDate));
            }
        }
    }

    private void addCurrentAgeBandAnalytics(AnalyticsSummary analytics, TargetAccountNumber targetAccountNumber, long legalEntityId){

        PersonalDetailsResponse response = personalDetailsClient.getPersonalDetails(targetAccountNumber, UNKNOWN_POSTCODE, legalEntityId);

        FRIENDLY_CODES friendlyAgeCode;
        if(response.getDateOfBirth() != null){
            LocalDate dob = response.getDateOfBirth().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            int age = Period.between(dob, LocalDate.now()).getYears();
            log.debug("age: {}", age);
            if(isBetween(age, 16, 19)) {friendlyAgeCode = FRIENDLY_CODES.A;}
            else if(isBetween(age, 20, 24)) {friendlyAgeCode = FRIENDLY_CODES.B;}
            else if(isBetween(age, 25, 29)) {friendlyAgeCode = FRIENDLY_CODES.C;}
            else if(isBetween(age, 30, 34)) {friendlyAgeCode = FRIENDLY_CODES.D;}
            else if(isBetween(age, 35, 39)) {friendlyAgeCode = FRIENDLY_CODES.E;}
            else if(isBetween(age, 40, 44)) {friendlyAgeCode = FRIENDLY_CODES.F;}
            else if(isBetween(age, 45, 49)) {friendlyAgeCode = FRIENDLY_CODES.G;}
            else if(isBetween(age, 50, 54)) {friendlyAgeCode = FRIENDLY_CODES.H;}
            else if(isBetween(age, 55, 59)) {friendlyAgeCode = FRIENDLY_CODES.I;}
            else if(isBetween(age, 60, 64)) {friendlyAgeCode = FRIENDLY_CODES.J;}
            else if(isBetween(age, 65, 69)) {friendlyAgeCode = FRIENDLY_CODES.K;}
            else if(isBetween(age, 70, 74)) {friendlyAgeCode = FRIENDLY_CODES.L;}
            else if(isBetween(age, 75, 79)) {friendlyAgeCode = FRIENDLY_CODES.M;}
            else if(isBetween(age, 80, 84)) {friendlyAgeCode = FRIENDLY_CODES.N;}
            else if(isBetween(age, 85, 89)) {friendlyAgeCode = FRIENDLY_CODES.O;}
            else if(isBetween(age, 90, 94)) {friendlyAgeCode = FRIENDLY_CODES.P;}
            else if(isBetween(age, 95, 99)) {friendlyAgeCode = FRIENDLY_CODES.Q;}
            else {friendlyAgeCode = FRIENDLY_CODES.R;}
        } else {
            friendlyAgeCode = FRIENDLY_CODES.Z;
        }
        analytics.getAnalyticsMap().put(ANALYTICS_REQUIREMENT.CURRENT_AGE.getCode(), friendlyAgeCode.toString());
    }

    private boolean isBetween(int age, int lower, int higher){
        return age >= lower && age <= higher;
    }

    @Override
    public ZoneAndDma getZoneAndDmaByPostcode(String postcode){
        log.debug("Getting Zone and Dma by postcode {}", postcode);
        postcode = StringUtils.remove(postcode, SPACE);
        ZoneAndDma zoneAndDma = new ZoneAndDma();
        Optional<PostcodeDmaControlgroup> postcodedmacontrolgroup = postcodeDmaControlGroupDao.findDmaControlgroupByPostcode(postcode).stream().findFirst();
       
        if (postcodedmacontrolgroup.isPresent()) {
        	
        	zoneAndDma.setZone(postcodedmacontrolgroup.get().getWqzcode());
        	zoneAndDma.setDma(postcodedmacontrolgroup.get().getDma());
        	zoneAndDma.setControlGroup(postcodedmacontrolgroup.get().getControlGroupname());
        	
        }
        
        log.debug("Returning ZoneAndDma {}", zoneAndDma);
        return zoneAndDma;
    }

}
