
package uk.co.stwater.api.osgi.analytics;

import uk.co.stwater.api.osgi.model.AnalyticsSummary;
import uk.co.stwater.api.osgi.model.ZoneAndDma;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;


public interface AnalyticsService {

    AnalyticsSummary getAnalytics(String analyticsId, String postcode, String authToken) throws STWTechnicalException, STWBusinessException;

    ZoneAndDma getZoneAndDmaByPostcode(String postcode);
}
