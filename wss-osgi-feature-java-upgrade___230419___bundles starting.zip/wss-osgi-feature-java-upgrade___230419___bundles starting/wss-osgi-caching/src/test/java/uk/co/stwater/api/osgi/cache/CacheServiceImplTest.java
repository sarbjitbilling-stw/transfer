package uk.co.stwater.api.osgi.cache;

import uk.co.stwater.api.osgi.cache.CacheConfigurationService;
import uk.co.stwater.api.osgi.cache.CachingAspect;
import uk.co.stwater.api.osgi.cache.CacheService;
import uk.co.stwater.api.osgi.cache.CacheServiceImpl;
import uk.co.stwater.api.osgi.cache.CacheEntry;
import uk.co.stwater.api.osgi.cache.InvalidateCache;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.After;
import org.junit.AfterClass;


import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoJUnitRunner;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 *
 * @author Mark
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class CacheServiceImplTest {
    
    private static final int EXPECTED_PARAM_HASH = -1906036421;

    @Mock
    private CacheServiceImpl cacheService;
    
    @InjectMocks
    private CachingAspect testAspect;
    
    @Mock
    private JoinPoint joinPoint;
    
    @Mock
    private MethodSignature methodSignature;
    
    public CacheServiceImplTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {

    }
    
    @After
    public void tearDown() {
    }


    @Test
    public void testInvalidate1() {
        CacheEntry enitry = new CacheEntry(new Object(), Integer.MAX_VALUE);
        CacheServiceImpl realCacheService = new CacheServiceImpl();
        
        realCacheService.getCacheInstance().put(999, enitry);
        realCacheService.index(999, Arrays.asList(1, 2));
        realCacheService.index(998, Arrays.asList(2));
        realCacheService.index(999, Arrays.asList(5, 6));
        
        assertEquals(enitry, realCacheService.getCacheInstance().getIfPresent(999));
        realCacheService.invalidate(Arrays.asList(1));
        assertNull(realCacheService.getCacheInstance().getIfPresent(999));
        
        assertEquals(1, realCacheService.hashIndex.size());
        assertTrue( realCacheService.hashIndex.containsKey(2));
        assertTrue( realCacheService.hashIndex.get(2).contains(998));
    }
    
    @Test
    public void testInvalidate_2() {
        CacheEntry enitry = new CacheEntry(new Object(), Integer.MAX_VALUE);
        CacheServiceImpl realCacheService = new CacheServiceImpl();
        TargetAccountNumber tan = new TargetAccountNumber("5900057552");
        realCacheService.invalidate(tan, TargetAccountNumber.class, String.class);
        
        realCacheService.getCacheInstance().put(999, enitry);
        realCacheService.index(999, Arrays.asList(1, 2));
        realCacheService.index(998, Arrays.asList(2));
        realCacheService.index(999, Arrays.asList(5, 6));
        realCacheService.index(999, Arrays.asList(EXPECTED_PARAM_HASH));
        
        assertEquals(enitry, realCacheService.getCacheInstance().getIfPresent(999));
        realCacheService.invalidate(Arrays.asList(1));
        assertNull(realCacheService.getCacheInstance().getIfPresent(999));
        
        assertEquals(1, realCacheService.hashIndex.size());
        assertTrue( realCacheService.hashIndex.containsKey(2));
        assertTrue( realCacheService.hashIndex.get(2).contains(998));
    }
    
    @Mock
    private BundleContext  bundleContext;
    
    private InvalidateCache invalidateCacheAnotation;
    
    @Mock
    private CacheConfigurationService config;
    
    @Test
    public void testBeforeInvalidateCache() throws Throwable {
        /*testing -  @InvalidateCache
                     public String paymentTest(@CacheKey TargetAccountNumber tan)
        */
        TargetAccountNumber tan = new TargetAccountNumber("5900057552");
        Method testMethod = TestTarget.class.getMethod("paymentTest", TargetAccountNumber.class);
        setMocks(testMethod, new Object[]{tan} );

        ArgumentCaptor<List> parameterKeyHashesArgument = ArgumentCaptor.forClass(List.class);
 
        //testing -> public void beforeInvalidateCache(final JoinPoint joinPoint, final InvalidateCache invalidateCacheAnotation) 
        testAspect.beforeInvalidateCache(joinPoint, invalidateCacheAnotation);
        
        verify(cacheService).invalidate(parameterKeyHashesArgument.capture());
        assertTrue(EXPECTED_PARAM_HASH == (int)parameterKeyHashesArgument.getValue().get(0));
    }
    
    private void setMocks(Method testMethod, Object[] args){
        invalidateCacheAnotation = testMethod.getAnnotation(InvalidateCache.class);
        when(methodSignature.getMethod()).thenReturn(testMethod);
        when(methodSignature.getReturnType()).thenReturn(testMethod.getReturnType());
        when(methodSignature.toShortString()).thenReturn(testMethod.toGenericString());
        when(methodSignature.getParameterTypes()).thenReturn(testMethod.getParameterTypes());
        when(joinPoint.getArgs()).thenReturn(args);
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        
        //mocks for the call to get the ConfigurationService from the BundleContext
        ServiceReference reference2GeneralConfigurationService = Mockito.<ServiceReference>mock(ServiceReference.class);
        when(bundleContext.getServiceReference(CacheConfigurationService.class.getName())).thenReturn(reference2GeneralConfigurationService);
        when(bundleContext.getService(reference2GeneralConfigurationService)).thenReturn(config);
        when(config.isCacheServiceEnable()).thenReturn(Boolean.TRUE);
        
        //mocks for the call to get the CacheService from the BundleContext
        ServiceReference reference2CacheService = Mockito.<ServiceReference>mock(ServiceReference.class);
        when(bundleContext.getServiceReference(CacheService.class.getName())).thenReturn(reference2CacheService);
        when(bundleContext.getService(reference2CacheService)).thenReturn(cacheService);
    }

}
