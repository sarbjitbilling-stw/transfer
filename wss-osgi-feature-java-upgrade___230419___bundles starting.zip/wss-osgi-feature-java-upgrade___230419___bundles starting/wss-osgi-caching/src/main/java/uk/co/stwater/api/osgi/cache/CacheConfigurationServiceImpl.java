package uk.co.stwater.api.osgi.cache;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.inject.Named;
import javax.inject.Singleton;

import org.apache.commons.lang3.StringUtils;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Named
@Singleton
@Component(service = {CacheConfigurationService.class}, configurationPid = "wss.osgi.util")
public class CacheConfigurationServiceImpl implements CacheConfigurationService {

    Logger log = LoggerFactory.getLogger(this.getClass());

    // 0 means that all cache levels will be active
    private static final int DEFAULT_SYSTEM_CACHE_LEVEL = 0;

    public static final String PID = "wss.osgi.util";
    static final String CACHE_METHOD = PID + ".cache.method.";
    static final String CACHE_ENABLED = PID + ".cache.enabled";
    static final String CACHE_LEVEL = PID + ".cache.level";

    private boolean enableCacheService = true;

    private int systemCacheLevel = DEFAULT_SYSTEM_CACHE_LEVEL;

    private final Map<String, Long> cacheMethodTimeout = new HashMap<>();

    @Activate
    @Modified
    public synchronized void updated(Map<String, String> config) throws ConfigurationException {
        log.info("Loading configuration into instance {} : {}", this.hashCode(), config);

        if (config != null) {
            this.enableCacheService = getConfiguredBoolean(config, CACHE_ENABLED, true);

            this.systemCacheLevel = getConfiguredInteger(config, CACHE_LEVEL,
                    DEFAULT_SYSTEM_CACHE_LEVEL);
            if (this.systemCacheLevel < 0 || 100 < this.systemCacheLevel) {
                throw new ConfigurationException(CACHE_LEVEL,
                        String.format("System cache level should be in range 0-100 but is %d", this.systemCacheLevel));
            }

            cacheMethodTimeout.clear();
            // @formatter:off
            config.entrySet().stream()
                    .filter(entry -> entry.getKey().startsWith(CACHE_METHOD) 
                            && StringUtils.isNotBlank(entry.getValue()))
                    .forEach(entry -> {
                    	String methodReference = entry.getKey().replace(CACHE_METHOD, "").replace(" ", "");
                    	Long timeout = Long.parseLong(entry.getValue().trim());
                    	log.debug("Setting cache timeout to {} for method {}", timeout, methodReference);
                        cacheMethodTimeout.put(methodReference, timeout);
                    });
            // @formatter:on
        }

    }

    @Override
    public Optional<Long> getMethodCacheDuration(String methodName) {
        String methodNameFormatted = methodName.replace(" ", "");
        return Optional.ofNullable(cacheMethodTimeout.get(methodNameFormatted));
    }

    @Override
    public boolean isCacheServiceEnable() {
        return enableCacheService;
    }

    @Override
    public int getSystemCacheLevel() {
        return systemCacheLevel;
    }

    public boolean getConfiguredBoolean(Map<String, String> config, String key, boolean defaulValue) {
        String configuredValue = config.get(key);
        if (configuredValue == null) {
            return defaulValue;
        }

        return configuredValue.toLowerCase().equalsIgnoreCase("true");
    }

    public int getConfiguredInteger(Map<String, String> config, String key, int defaultValue) {
        String configuredValue = config.get(key);
        if (StringUtils.isBlank(configuredValue)) {
            return defaultValue;
        }

        try {
            return Integer.parseInt(configuredValue);
        } catch (NumberFormatException e) {
            log.error("Configuration value {} for property {} cannot be converted to an integer", configuredValue, key);
            return defaultValue;
        }
    }

}
