/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.cache;

import java.lang.annotation.Annotation;
import java.lang.annotation.IncompleteAnnotationException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.benmanes.caffeine.cache.Cache;

/**
 *
 * @author Mark
 */
@Aspect
public class CachingAspect {

    private static final String HEALTH_CHECK_SIGNATURE = "HealthCheckServiceImpl.doIntegrationHealthCheck()";
    Logger logger = LoggerFactory.getLogger(CachingAspect.class);

    private BundleContext bundleContext;

    @Pointcut("execution(* *(..))")
    public void atExecution() {
    }
    
    @Pointcut("@annotation(cacheableAnotation)")
    public void cacheablePointCutDefinition(Cacheable cacheableAnotation){
    }
        
    @Pointcut("@annotation(invalidateCacheAnotation)")
    public void invalidateCachePointCutDefinition(InvalidateCache invalidateCacheAnotation){
    }

    @Around("cacheablePointCutDefinition(cacheableAnotation) && atExecution()")
    public Object aroundCacheable(final ProceedingJoinPoint joinPoint, final Cacheable cacheableAnotation) throws Throwable {
        long start = 0;
        final String signatureShortString = joinPoint.getSignature().toShortString();
        try{
            if (logger.isTraceEnabled()) {
                start = System.currentTimeMillis();
                logger.trace("enter aroundCacheable() - {}", signatureShortString);
            }
            if(! isCacheEnabled()){
                logger.debug("Cache disabled by config so serving from underlying method - NOT cache: {}", signatureShortString);
                return joinPoint.proceed();
            }

            if (cacheableAnotation.level() < getSystemCacheLevel()) {
                logger.debug(
                        "Cache level lower than system cache level so serving from underlying method - NOT cache: {}",
                        signatureShortString);
                return joinPoint.proceed();
            }

            Cache<Integer, CacheEntry> cache = getCacheInstance();

            final AtomicBoolean wasCached = new AtomicBoolean(true);
            
            Class<?> targetClass = getTargetType(joinPoint, cacheableAnotation);
            int targetClassHash = targetClass.getName().hashCode();

            int methodHash = getMethodHash(joinPoint) + targetClassHash;
            // not using cache.get(key, mappingFunction) as it will result in a deadlock in
            // the case where one cacheable method calls another
            CacheEntry result = cache.getIfPresent(methodHash);
            if (result == null) {
                try {
                    logger.debug("Serving from underlying method - NOT cache: {}, {}", methodHash, signatureShortString);
                    wasCached.set(false);
                    long timeout = getMethodCacheDuration(joinPoint, cacheableAnotation);
                    CacheEntry retObj = new CacheEntry(joinPoint.proceed(), timeout);

                    //workout the param hashes to 'tag' this cache entry with and add them to the index
                    List<Integer> parameterKeyHashes = getParameterKeyHashes(joinPoint, targetClassHash);
                    getCacheService().index(methodHash, parameterKeyHashes);

                    result = retObj;
                    cache.put(methodHash, retObj);
                } catch (Throwable ex) {
                    logger.warn("Error reading from cache: {}, {}", methodHash, signatureShortString);
                    result = new CacheEntry(ex, 0L); // timeout exceptions immediately
                    cache.put(methodHash, result);
                }
            }

            if (wasCached.get() && !isHealthCheck(signatureShortString)) {
                logger.debug("Serving from cache: {}, {}", methodHash, signatureShortString);
            }

            if(result.isException()) {
                result.throwException();
            }

            return result.getPayload();
   
        } catch (IllegalStateException ex){
            logger.warn("Cache or hash index instance unavailable - so can't use cache");
            return joinPoint.proceed();
        } finally {
            if (logger.isTraceEnabled()) {
                long time = System.currentTimeMillis() - start;
                String msg = String.format("exit aroundCacheable() - %1$s after %2$dms\n", signatureShortString, time);
                logger.trace(msg);
            }
        }
    }
    
    @Before("invalidateCachePointCutDefinition(invalidateCacheAnotation) && atExecution()")
    public void beforeInvalidateCache(final JoinPoint joinPoint, final InvalidateCache invalidateCacheAnotation) throws Throwable {
          
        //1) determine object type - either from anotation or method signature
        //2) determine object keys - all params if no @CacheKey anotation
        //3) calculate ivalidation hash(s) ie. one for each key
        //4) get the cache hash keys which are 'tagged' with the ivalidation hashes 
                    
        long start = 0;
        final String signatureShortString = joinPoint.getSignature().toShortString();
        try{
            if (logger.isTraceEnabled()) {
                start = System.currentTimeMillis();
                logger.trace("enter beforeInvalidateCache() - {}", signatureShortString);
            }
            
            if(! isCacheEnabled()){
                logger.debug("Cache disabled by config : {}", signatureShortString);
                //nothing to do so just get out of here
                return;
            }

            Class targetType = getTargetType(joinPoint, invalidateCacheAnotation);
            int tagetClassHash = targetType.getName().hashCode();
            List<Integer> parameterKeyHashes = getParameterKeyHashes(joinPoint, tagetClassHash);

            getCacheService().invalidate(parameterKeyHashes);
            
        } catch (IllegalStateException ex){
            logger.warn("Unable to retrive hash index or cache from Cache Service - unable to invaliadte Cache");
        } finally {
            if (logger.isTraceEnabled()) {
                long time = System.currentTimeMillis() - start;
                String msg = String.format("exit beforeInvalidateCache() - %1$s after %2$dms\n", signatureShortString, time);
                logger.trace(msg);
            }
        }
     }   

    /**
     * Determine the type of this cache request, will use the type from the annotation if supplied
     * otherwise will use the method return type.  Will throw a IncompleteAnnotationException if the 
     * method return is a void type and no type is given in the annotation.
     * @param joinPoint
     * @param invalidateCacheAnotation
     * @return 
     * @throws IncompleteAnnotationException 
     */
    Class getTargetType(final JoinPoint joinPoint, final InvalidateCache invalidateCacheAnotation) throws IncompleteAnnotationException {
        return getTargetType(invalidateCacheAnotation.type(), joinPoint).orElseThrow(() -> new IncompleteAnnotationException(InvalidateCache.class, "type"));
    }
    
    /**
     * Determine the type of this cache request, will use the type from the annotation if supplied
     * otherwise will use the method return type.  Will throw a IncompleteAnnotationException if the 
     * method return is a void type and no type is given in the annotation.
     * @param joinPoint
     * @param cacheableAnotation
     * @return 
     * @throws IncompleteAnnotationException 
     */
    Class getTargetType(final JoinPoint joinPoint, final Cacheable cacheableAnotation) throws IncompleteAnnotationException {
        return getTargetType(cacheableAnotation.type(), joinPoint).orElseThrow(() -> new IncompleteAnnotationException(Cacheable.class, "type"));
    }

    private Optional<Class> getTargetType(Class targetType, final JoinPoint joinPoint) {
        //was the targetType passed in the void type?
        if(targetType.equals(void.class)){
            // if so use the value from the method signature return type
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            targetType = signature.getReturnType();
        }
        if(targetType.equals(void.class)){
            return Optional.empty();
        }
        return Optional.of(targetType);
    }
               
       
    /**
     * Calculate a list of parameter hash values for the method parameters of the JoinPoint.
     * A parameter hash is calculated from the parameter type + parameter value 
     * This method will prioritise the parameters annotated with a CacheKey annotation, if
     * no parameters are annotated with @CacheKey a hash for each parameter will be returned.
     * The parameter type (Class) used by the hash calculation is from the 'type' property of the 
     * CacheKey annotation if present otherwise the parameter type is used.
     * 
     * @param joinPoint
     * @return List<Integer> list of calculated hash values
     */
    List<Integer> getParameterKeyHashes(final JoinPoint joinPoint, int targetClassHash) {
        List<Integer> allArgs = new ArrayList<>();
        List<Integer> annotatedArgs = new ArrayList<>();
        
         MethodSignature signature = (MethodSignature) joinPoint.getSignature();
         
        for(int argPosition = 0; argPosition < joinPoint.getArgs().length; argPosition++){
            Object arg = joinPoint.getArgs()[argPosition];
            
            Optional<Annotation> opCacheKeyAnnotation = Arrays.stream(signature.getMethod().getParameterAnnotations()[argPosition]).filter((a)->a.annotationType().equals(CacheKey.class)).findFirst();
            
            Class argType = signature.getParameterTypes()[argPosition];
            
            //key hash is made up of arg type + arg value + targetClassHash
            int argHashValue = arg!=null?arg.hashCode():0;
            int keyHash = argType.getName().hashCode() + argHashValue + targetClassHash;
            allArgs.add(keyHash);
            
            //is parameter annotated with @CacheKey ?
            if(opCacheKeyAnnotation.isPresent()) {
                Class annotatedType = ((CacheKey)opCacheKeyAnnotation.get()).type();
                if(annotatedType.equals(void.class)){
                    annotatedArgs.add(keyHash);
                } else {
                    int altHash = annotatedType.getName().hashCode() + argHashValue + targetClassHash;
                    annotatedArgs.add(altHash);
                }
            }
        }
        
        return annotatedArgs.size()>0?annotatedArgs:allArgs;
    }


    /* 
        compute a hash for this method call, this is based
        on the method signature and the values 
        passed to the method call
    */
    private int getMethodHash(final ProceedingJoinPoint joinPoint) {
        int methodSignatureHash = joinPoint.getSignature().toString().hashCode();
        // using Arrays.hashCode to reduce chances of collisions (e.g. when same values
        // passes in different order)
        int argumentsHashCode = Arrays.hashCode(joinPoint.getArgs());
        int methodCallHash = methodSignatureHash + argumentsHashCode;

        if(!isHealthCheck(joinPoint.getSignature().toShortString())) {
            logger.debug("getMethodHash() = {}", methodCallHash);
        }
        return methodCallHash;
    }

    private boolean isHealthCheck(String signatureShortString) {
        return HEALTH_CHECK_SIGNATURE.equals(signatureShortString);
    }

    private Cache<Integer, CacheEntry> getCacheInstance(){
        return getService(CacheService.class).map(t->t.getCacheInstance()).orElseThrow(IllegalStateException::new);
    }
    
    private CacheService getCacheService(){
        return getService(CacheService.class).orElseThrow(IllegalStateException::new);
    }
    
    //look up duration from config - if not found return default from anotation
    private Long getMethodCacheDuration(ProceedingJoinPoint joinPoint, Cacheable cacheableAnotation){
        String methodSignature = getIdentifierString(joinPoint.getSignature());

        return getService(CacheConfigurationService.class)
                .flatMap(t -> t.getMethodCacheDuration(methodSignature))
                .map(l->l.longValue()*1_000_000) //convert ms to nano
                .orElse(cacheableAnotation.timeUnit().toNanos(cacheableAnotation.timeout()));
    }
    
    /**
     * Return {@code String} uniquely identifying a method.
     * 
     * <p>
     * e.g {@code "uk.co.stwater.some.package.ClassName.methodName(java.util.List)"}
     */
    private String getIdentifierString(Signature signature) {
        // e.g. "public synchronized java.lang.String
        // some.package.ClassName.methodName(java.util.List, java.lang.Long) throws
        // java.lang.Exception"
        String longSignature = signature.toLongString();
        int argsStart = longSignature.indexOf('(');
        int argsEnd = longSignature.indexOf(')', argsStart) + 1;
        int methodStart = longSignature.lastIndexOf(' ', argsStart) + 1;

        return longSignature.substring(methodStart, argsEnd);
    }

    private boolean isCacheEnabled(){
        return getCacheConfigurationService().isCacheServiceEnable();
    }

    private int getSystemCacheLevel() {
        return getCacheConfigurationService().getSystemCacheLevel();
    }

    private CacheConfigurationService getCacheConfigurationService() {
        return getService(CacheConfigurationService.class).orElseThrow(IllegalStateException::new);
    }
    
    // get OSGi service from framework - can't use Injection here :(
    private synchronized <T> Optional<T> getService(Class<T> clazz) {
        if(bundleContext == null){
            Bundle bundle = FrameworkUtil.getBundle(this.getClass());
            if(bundle==null){
                logger.warn("Unable to get bundle from FrameworkUtil - if this is a Unit Test please ignore");
                return Optional.empty();
            }
            bundleContext = bundle.getBundleContext();
        }
        ServiceReference<?> serviceReference = bundleContext.getServiceReference(clazz.getName());
        T service = (T) bundleContext.getService(serviceReference);
        return Optional.ofNullable(service);
    }
    
}
