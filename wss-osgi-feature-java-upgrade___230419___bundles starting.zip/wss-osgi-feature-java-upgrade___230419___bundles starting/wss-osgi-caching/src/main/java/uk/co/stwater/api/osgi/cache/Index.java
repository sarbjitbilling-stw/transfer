package uk.co.stwater.api.osgi.cache;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 *
 * @author Mark
 */
public class Index<K, V> {

    private final List<Pair<K, V>> index = Collections.synchronizedList(new ArrayList<>());
    
    public void put(K k, V v){
        index.add(new Pair<K,V>(k,v));
    }

    public boolean containsKey(K k) {
        List<V> list = get(k);
        return  list != null && !(list.isEmpty());
    }
    
    public List<V> get(K k){
       return index.stream().filter((Pair<K,V> p)->p.key.equals(k)).map((p)->p.value).collect(Collectors.<V>toList());
    }
    
    public List<V> get(List<K> kList){
        List<Pair<K, V>> clone = new ArrayList<>(index); // attempt to stop ConcurrentModificationException
        return clone.stream().filter((Pair<K,V> p)->kList.contains(p.key)).map((p)->p.value).collect(Collectors.<V>toList());
    }
    
    public void removeAllWithValue(V v){
        synchronized (index) {
            Iterator<Pair<K,V>> it = index.iterator();
            while(it.hasNext()){
               if(it.next().value.equals(v))it.remove();
            }
        }
    }

    void removeAllWithValue(List<V> values) {
        //might want to optermisse this if too slow - lets get it working first
        values.forEach((v)->removeAllWithValue(v));
    }
    
    public int size(){
        return index.size();
    }

    public void clear() {
        index.clear();
    }

    private static class Pair<K, V> {
        private final K key;
        private final V value;

        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public int hashCode() {
            int hash = 7;
            hash = 59 * hash + Objects.hashCode(this.key);
            hash = 59 * hash + Objects.hashCode(this.value);
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final Pair<?, ?> other = (Pair<?, ?>) obj;
            if (!Objects.equals(this.key, other.key)) {
                return false;
            }
            if (!Objects.equals(this.value, other.value)) {
                return false;
            }
            return true;
        }

    }

}
