package uk.co.stwater.api.osgi.cache;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Expiry;
import com.github.benmanes.caffeine.cache.stats.CacheStats;
import java.util.Collections;
import java.util.List;
import javax.inject.Named;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Mark
 */
@Named
@Component(service = {CacheService.class}, configurationPid = CacheService.PID)
public class CacheServiceImpl implements CacheService {
    Logger log = LoggerFactory.getLogger(CacheServiceImpl.class);
        
    private final Cache<Integer, CacheEntry> cache;
    
    //package scope to allow for testing
    final Index<Integer, Integer> hashIndex = new Index<>();
    
    public CacheServiceImpl() {
        cache = Caffeine.newBuilder()
                .expireAfter(new Expiry<Integer, CacheEntry>() {
                    @Override
                    public long expireAfterCreate(Integer key, CacheEntry entry, long currentTime) {
                        return entry.getTTL(currentTime);
                    }

                    @Override
                    public long expireAfterUpdate(Integer key, CacheEntry entry,
                            long currentTime, long currentDuration) {
                        return currentDuration;
                    }

                    @Override
                    public long expireAfterRead(Integer key, CacheEntry entry,
                            long currentTime, long currentDuration) {
                        return currentDuration;
                    }
                })
                .recordStats()
                .maximumSize(10_000)
                .build();
    }

    @Override
    public Cache<Integer, CacheEntry> getCacheInstance() {
        return cache;
    }
    
    public boolean isCacheEnabled(){
        return  getCacheInstance()!=null;
    }
    
    @Override
    public CacheStats getCacheStats() {
        return cache.stats();
    }

    @Override
    public void invalidateAll() {
        cache.invalidateAll();
    }
    
    @Override
    public void index(Integer methodHash, List<Integer> paramHashes) {
        paramHashes.stream().forEach((paramHash)-> hashIndex.put(paramHash, methodHash));
    }

    @Override
    public void invalidate(List<Integer> parmaterKeyHashes) {
        invalidateLocal(parmaterKeyHashes);
    }
    
    @Override
    public void invalidate(Object argValue, Class argClass, Class targetClass) {
        int argHashValue = argValue!=null?argValue.hashCode():0;
        int keyHash = argClass.getName().hashCode() + argHashValue + targetClass.getName().hashCode();
        log.debug("about to request invalidation of param hash{}", keyHash);
        invalidateLocal(Collections.singletonList(keyHash));
    }
    
    private void invalidateLocal(List<Integer> parmaterKeyHashes) {
        //get all of the cacheKeys that are 'tagged' by these parmaterKeyHashes
        //this will produce list of hash keys for the main cache
        List<Integer> evictionList = hashIndex.get(parmaterKeyHashes);
        
        log.debug("about to invlidate the following cash hashes {}", evictionList);
        cache.invalidateAll(evictionList);

        //now we need to remove all 'tags' from the index that point to the main cache
        //values we have just removed.
        hashIndex.removeAllWithValue(evictionList);
    }

}
