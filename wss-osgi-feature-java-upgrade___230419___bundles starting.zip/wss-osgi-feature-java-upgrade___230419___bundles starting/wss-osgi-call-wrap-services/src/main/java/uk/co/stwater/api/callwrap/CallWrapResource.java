package uk.co.stwater.api.callwrap;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.model.ContactEvent;
import uk.co.stwater.api.callwrap.model.AqContactEventRequest;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;
import uk.co.stwater.api.osgi.util.AbstractResource;

@Named("callWrapResource")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CallWrapResource extends AbstractResource {
    private static final Logger LOG = LoggerFactory.getLogger(CallWrapResource.class);

    @Inject
    private CallWrapService callWrapService;

    @GET
    @Path("/customer-contacts/{id}")
    public Response getCustomerContact(@PathParam("id") Long id) {
        CallWrapCustomerContact customerContact = callWrapService.getCustomerContact(id)
                .orElseThrow(() -> new CallWrapException(Status.NOT_FOUND, "CustomerContact not found for id"));

        return Response.ok(customerContact).build();
    }

    @GET
    @Path("/customer-contacts/{id}/incidents")
    public Response getCustomerContactIncidents(@PathParam("id") Long customerContactId) {

        List<CallWrapIncident> incidents = callWrapService.getIncidentsForCustomerContact(customerContactId);

        return Response.ok(incidents).build();
    }

    @POST
    @Path("/customer-contacts")
    public Response createCustomerContact(CallWrapCustomerContact customerContact) {
        customerContact.validate();

        String authToken = getTargetAuthToken();

        CallWrapCustomerContact createdCustomerContact = callWrapService.create(customerContact, authToken);

        return Response.ok(createdCustomerContact).build();
    }

    @PUT
    @Path("/customer-contacts/{id}")
    public Response updateCustomerContact(@PathParam("id") Long id, CallWrapCustomerContact customerContact) {
        customerContact.validate();
        if (!id.equals(customerContact.getId())) {
            throw new CallWrapException("customerContact.id does not match path id");
        }

        String authToken = getTargetAuthToken();

        CallWrapCustomerContact updatedCustomerContact = callWrapService.update(customerContact, authToken);

        return Response.ok(updatedCustomerContact).build();
    }

    @GET
    @Path("/incidents/{incidentId}")
    public Response getIncident(@PathParam("incidentId") Long incidentId) {
        LOG.info("GET incident for incidentId={}", incidentId);
        CallWrapIncident incident = callWrapService.getIncident(incidentId)
                .orElseThrow(() -> new CallWrapException(Status.NOT_FOUND, "Incident not found for id"));

        return Response.ok(incident).build();
    }

    @PUT
    @Path("/incidents/{incidentId}")
    public Response updateIncident(@PathParam("incidentId") Long incidentId,
            CallWrapIncident incident) {
        LOG.info("Update incendent for incidentId={}", incidentId);

        incident.validate();

        callWrapService.updateIncident(incident);

        return Response.ok().build();
    }

    @POST
    @Path("/incidents")
    public Response createIncident(CallWrapIncident incident) {
        LOG.info("CallWrap create incident");

        incident.validate();

        CallWrapIncident createdIncident = callWrapService.createIncident(incident);

        return Response.ok(createdIncident).build();
    }

    @POST
    @Path("/aq-contact-event")
    public Response createContactEventWithAq(AqContactEventRequest createAqContactEvent) {
        createAqContactEvent.validate();
        String authToken = getTargetAuthToken();
        ContactEvent createdContactEvent = callWrapService.createAqContactEvent(createAqContactEvent, authToken);

        return Response.ok(createdContactEvent).build();
    }

    String getTargetAuthToken() {
        return getUserIdentity().getUsername();
    }
}
