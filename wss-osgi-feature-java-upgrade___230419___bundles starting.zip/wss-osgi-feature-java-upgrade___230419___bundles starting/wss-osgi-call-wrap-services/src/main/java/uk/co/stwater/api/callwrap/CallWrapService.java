package uk.co.stwater.api.callwrap;

import java.util.List;
import java.util.Optional;

import io.swagger.model.ContactEvent;
import uk.co.stwater.api.callwrap.model.AqContactEventRequest;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;

public interface CallWrapService {

    Optional<CallWrapCustomerContact> getCustomerContact(Long id);

    CallWrapCustomerContact create(CallWrapCustomerContact customerContact, String authToken);

    CallWrapCustomerContact update(CallWrapCustomerContact customerContact, String authToken);

    List<CallWrapIncident> getIncidentsForCustomerContact(Long id);

    Optional<CallWrapIncident> getIncident(Long customerContactId);

    CallWrapIncident createIncident(CallWrapIncident incident);

    void updateIncident(CallWrapIncident incident);

    void deleteExpiredProcessedRequests();

    ContactEvent createAqContactEvent(AqContactEventRequest createAqContactEvent, String authToken);

}
