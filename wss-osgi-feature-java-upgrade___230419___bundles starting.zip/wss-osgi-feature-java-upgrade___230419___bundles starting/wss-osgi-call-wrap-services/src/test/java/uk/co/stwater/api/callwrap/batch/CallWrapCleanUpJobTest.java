package uk.co.stwater.api.callwrap.batch;

import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.callwrap.CallWrapService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CallWrapCleanUpJobTest {

    @Mock
    private CallWrapService callWrapService;

    @InjectMocks
    private CallWrapCleanUpJob callWrapCleanUpJob = new CallWrapCleanUpJob();

    @Test
    public void execute() {
        callWrapCleanUpJob.execute(null);

        verify(callWrapService).deleteExpiredProcessedRequests();
    }

}
