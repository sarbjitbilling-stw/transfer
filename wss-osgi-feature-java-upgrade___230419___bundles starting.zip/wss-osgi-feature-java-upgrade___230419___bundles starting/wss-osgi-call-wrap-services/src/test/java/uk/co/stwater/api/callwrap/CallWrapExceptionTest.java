package uk.co.stwater.api.callwrap;

import static org.junit.Assert.assertEquals;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.junit.Test;

import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;

public class CallWrapExceptionTest {
    private static final String EXCEPTION_MESSAGE = "Sample exception message";

    @Test
    public void constructorMessageDefaultValues() {
        CallWrapException e = new CallWrapException(EXCEPTION_MESSAGE);

        validatedException(e);
    }

    @Test
    public void constructorMessageExceptionDefaultValues() {
        CallWrapException e = new CallWrapException(EXCEPTION_MESSAGE, new Exception());

        validatedException(e);
    }

    @Test
    public void constructorMessageHttpStatus() {
        Status httpStatus = Status.GATEWAY_TIMEOUT;
        CallWrapException e = new CallWrapException(httpStatus, EXCEPTION_MESSAGE);

        validatedException(e, httpStatus);
    }

    @Test
    public void constructorMessageHttpStatusThrowable() {
        Status httpStatus = Status.CONFLICT;
        CallWrapException e = new CallWrapException(httpStatus, EXCEPTION_MESSAGE, new Exception());

        validatedException(e, httpStatus);
    }

    @Test
    public void constructorMessageErrorCodeDefaultValues() {
        String errorCode = "UNIT_TEST_353";
        CallWrapException e = new CallWrapException(errorCode, EXCEPTION_MESSAGE);

        validatedException(e, errorCode);
    }

    @Test
    public void constructorMessageErrorCodeExceptionDefaultValues() {
        String errorCode = "UNIT_TEST_444";
        CallWrapException e = new CallWrapException(errorCode, EXCEPTION_MESSAGE, new Exception());

        validatedException(e, errorCode);
    }

    private void validatedException(CallWrapException e) {
        validatedException(e, CallWrapException.DEFAULT_ERROR_CODE);
    }

    private void validatedException(CallWrapException e, String errorCode) {
        validatedException(e, Response.Status.BAD_REQUEST, errorCode);
    }

    private void validatedException(CallWrapException e, Status status) {
        validatedException(e, status, CallWrapException.DEFAULT_ERROR_CODE);
    }

    private void validatedException(CallWrapException e, Status status, String errorCode) {
        assertEquals(EXCEPTION_MESSAGE, e.getMessage());
        assertEquals(ErrorCategory.CALL_WRAP.toString(), e.getErrorCategory());
        assertEquals(status, e.getHttpStatusCode());
        assertEquals(errorCode, e.getErrorCode());
    }

}
