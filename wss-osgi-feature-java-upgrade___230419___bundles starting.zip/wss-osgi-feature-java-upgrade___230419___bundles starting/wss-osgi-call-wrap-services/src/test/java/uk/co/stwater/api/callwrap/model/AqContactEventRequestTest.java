package uk.co.stwater.api.callwrap.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

import io.swagger.model.ContactEvent;
import uk.co.stwater.api.callwrap.BaseContactEventBuilder;
import uk.co.stwater.api.callwrap.CallWrapException;
import uk.co.stwater.api.callwrap.CallWrapTestHelper;

public class AqContactEventRequestTest {

    @Test
    public void validateAccountNumber() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setAccountNumber(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("accountNumber is required", e.getMessage());
    }

    @Test
    public void validateLegalEntityNo() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setLegalEntityNo(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("legalEntityNo is required", e.getMessage());
    }

    @Test
    public void validatePropertId() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setPropertyId(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("propertId is required", e.getMessage());
    }

    @Test
    public void validateContactType() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setContactType(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("contactType is required", e.getMessage());
    }

    @Test
    public void validateContactMethod() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setContactMethod(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("contactMethod is required", e.getMessage());
    }

    @Test
    public void validateContactInitiatedBy() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setContactInitiatedBy(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("contactInitiatedBy is required", e.getMessage());
    }

    @Test
    public void validateContactSubTyped() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setContactSubType(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("contactSubType is required", e.getMessage());
    }

    @Test
    public void validatesOrganisationNumberNull() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setOrganisationNumber(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("organisationNumber is required", e.getMessage());
    }

    @Test
    public void validatesOrganisationNumberZero() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setOrganisationNumber(0L);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("organisationNumber is required", e.getMessage());
    }

    @Test
    public void validateActivityTypeCode() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setActivityTypeCode(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("activityTypeCode is required", e.getMessage());
    }

    @Test
    public void validateActivityPriority() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setActivityPriority("");

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("activityPriority is required", e.getMessage());
    }

    @Test
    public void validateDueDate() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setDueDate(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("dueDate is required", e.getMessage());
    }

    @Test
    public void validateRootCauseType() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setRootCauseType(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("rootCauseType is required", e.getMessage());
    }

    @Test
    public void validateContactPackageId() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setContactPackageId(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("contactPackageId is required", e.getMessage());
    }

    @Test
    public void validateNotes() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        aqContactEvent.setNotes(null);

        CallWrapException e = assertThrows(CallWrapException.class, () -> aqContactEvent.validate());
        assertEquals("notes is required", e.getMessage());
    }

    @Test
    public void validate() throws CallWrapException {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();

        aqContactEvent.validate();
    }

    @Test
    public void buildContactEvent() {
        buildContactEventTemplate("RESOLVED");
    }

    @Test
    public void buildContactEventNotResolved() {
        buildContactEventTemplate(BaseContactEventBuilder.RESOLUTION_NOT_RESOLVED);
    }

    private void buildContactEventTemplate(String resolution) {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();

        ContactEvent actual = aqContactEvent.build();

        assertEquals(aqContactEvent.getAccountNumber().getAccountNumberAsLong(), (long) actual.getAccountId());
        assertEquals(aqContactEvent.getLegalEntityNo(), actual.getLegalEntityNo());
        assertEquals(aqContactEvent.getContactType(), actual.getContactType().getCode());
        assertEquals(aqContactEvent.getContactMethod(), actual.getContactMethod());
        assertEquals(aqContactEvent.getContactInitiatedBy(), actual.getContactInitiatedBy().getCode());
        assertEquals(aqContactEvent.getContactSubType(), actual.getContactSubType().getCode());
        assertEquals(aqContactEvent.getOrganisationNumber(), actual.getOrgNum());
        assertEquals(aqContactEvent.getActivityTypeCode(), actual.getActTypeCode());
        assertEquals(aqContactEvent.getActivityPriority(), actual.getActPriority().getCode());
        assertEquals(aqContactEvent.getDueDate(), actual.getDueDate());
        assertEquals(aqContactEvent.getRootCauseType(), actual.getRootCauseType().getCode());
        assertEquals(aqContactEvent.getContactPackageId(), actual.getContactPackageId());
        assertNull(actual.getNotesDescription());

        if (BaseContactEventBuilder.RESOLUTION_NOT_RESOLVED.equals(resolution)) {
            assertFalse(actual.getIsPointOfContactResolved());
            assertEquals(BaseContactEventBuilder.ACTIVITY_QUEUE_SOURCE_CODE_CONTACT,
                    actual.getActQueueSourceCode().getCode());
            assertNull(actual.getResolution());
        }
    }

}
