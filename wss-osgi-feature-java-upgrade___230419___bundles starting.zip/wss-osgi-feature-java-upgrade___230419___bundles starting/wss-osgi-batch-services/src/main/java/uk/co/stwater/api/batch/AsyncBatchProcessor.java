package uk.co.stwater.api.batch;

import java.util.function.Consumer;

import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;

import uk.co.stwater.api.osgi.util.logging.LogChannel;
import uk.co.stwater.api.osgi.util.logging.LoggerFactory;

/**
 *
 * @author Mark
 */
public abstract class AsyncBatchProcessor implements BatchProcessor {

    private static final Logger logger = LoggerFactory.getLogger(LogChannel.BATCH, STWBatchServiceImpl.class);

    public abstract BatchItem createBatchItem(BatchJob batchJob, CSVRecord csvRecord);

    @Override
    public void process(BatchJob job, Iterable<CSVRecord> list, Consumer<BatchItem> saver) {
        new Thread(() -> {
            int count = 0;
            int errorCount = 0;
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            for (CSVRecord record : list) {
                logger.debug("processing record {}, {}", record.getRecordNumber(), record);
                if (this.canProcess(record)) {
                    BatchItem batchItem = this.createBatchItem(job, record);
                    if (batchItem == null) {
                        logger.error("Failed to create BatchItemEntity for record number {}", record.getRecordNumber());
                        errorCount++;
                    } else {
                        batchItem.setStatus(Status.QUEUED);
                        saver.accept(batchItem);
                        count++;
                        logger.debug("saved record {} for async sending", record.getRecordNumber());
                    }
                } else {
                    logger.warn("batch processor {} cannot process request {}", this.getClass().getName(), record);
                }
                job.setBatchSize(count);
            }
            stopWatch.stop();
            logger.debug("successfully completed loading {} records with {} records skipped, for batch processing in {} ms", count, errorCount, stopWatch.getTime());
        }).start();
    }

}

