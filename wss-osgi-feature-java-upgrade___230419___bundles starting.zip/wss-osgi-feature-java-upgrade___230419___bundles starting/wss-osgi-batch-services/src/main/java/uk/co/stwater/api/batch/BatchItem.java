package uk.co.stwater.api.batch;

import java.util.Date;

/**
 *
 * @author Mark
 */
public interface BatchItem {

    BatchJob getBatchJob();

    Date getDateCreated();

    Date getDateModified();

    String getFieldData();

    long getId();

    String getLockedBy();

    int getRetryCount();

    Status getStatus();

    String getTargetAccountNumber();

    void setLockedBy(String lockedBy);

    void setRetryCount(int retryCount);

    void setStatus(Status status);
    
}
