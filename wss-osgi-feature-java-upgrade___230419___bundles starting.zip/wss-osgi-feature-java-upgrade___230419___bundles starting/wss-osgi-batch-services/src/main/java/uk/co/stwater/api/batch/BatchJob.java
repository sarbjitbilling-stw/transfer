package uk.co.stwater.api.batch;

import java.util.Date;
import uk.co.stwater.api.osgi.model.WSSSite;

/**
 *
 * @author Mark
 */
public interface BatchJob {

    String getCommandName();

    Date getDateCreated();

    Date getDateModified();

    long getId();

    WSSSite getSite();

    Status getStatus();

    String getUserId();
    
    int getBatchSize();

    void setCommandName(String commandName);

    void setDateCreated(Date dateCreated);

    void setDateModified(Date dateModified);

    void setId(long id);

    void setSite(WSSSite site);

    void setStatus(Status status);

    void setUserId(String userId);
    
    void setBatchSize(int size);
}
