package uk.co.stwater.api.batch;

import java.util.Date;
import java.util.Objects;
import org.apache.commons.lang3.builder.EqualsBuilder;
import uk.co.stwater.api.batch.api.BatchJobDto;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.osgi.model.WSSSite;
import static uk.co.stwater.targetconnector.client.WsDateUtils.toLocalDate;

/**
 *
 * @author Mark
 */

public class BatchJobImpl implements BatchJob {

    private String commandName;
    private Date dateCreated;
    private Date dateModified;
    private Long id;
    private WSSSite site;
    private Status status;
    private String userId;
    private int batchSize;

    public static BatchJob fromEntity(BatchJobEntity entity){
        if(entity == null){
            return null;
        }
        BatchJob batchJob = new BatchJobImpl();
        batchJob.setCommandName(entity.getCommandName());
        batchJob.setDateCreated(entity.getDateCreated());
        batchJob.setDateModified(entity.getDateModified());
        batchJob.setId(entity.getId());
        batchJob.setSite(entity.getSite());
        batchJob.setStatus(entity.getStatus()!=null ? Status.valueOf(entity.getStatus().name()) : null);
        batchJob.setUserId(entity.getUserId());
        return batchJob;
    }
    
    public static BatchJobDto toBatchJobDto(BatchJob job){
        if(job == null) {
            return null;
        }
        BatchJobDto dto = new BatchJobDto();
        dto.setId(job.getId());
        dto.setStatus(job.getStatus()!=null ? Status.valueOf(job.getStatus().name()) : null);
        dto.setDateCreated(job.getDateCreated()!=null ? toLocalDate(job.getDateCreated()) : null);
        dto.setDateModified(job.getDateCreated()!=null ? toLocalDate(job.getDateModified()) : null);
        return dto;
    }

    public String getCommandName() {
        return commandName;
    }

    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public WSSSite getSite() {
        return site;
    }

    public void setSite(WSSSite site) {
        this.site = site;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.commandName);
        hash = 59 * hash + Objects.hashCode(this.dateCreated);
        hash = 59 * hash + Objects.hashCode(this.dateModified);
        hash = 59 * hash + Objects.hashCode(this.id);
        hash = 59 * hash + Objects.hashCode(this.site);
        hash = 59 * hash + Objects.hashCode(this.status);
        hash = 59 * hash + Objects.hashCode(this.userId);
        hash = 59 * hash + this.batchSize;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final BatchJobImpl other = (BatchJobImpl) obj;

        return new EqualsBuilder()
                .append(this.id, other.id)
                .append(this.batchSize, other.batchSize)
                .append(this.commandName, other.commandName)
                .append(this.userId, other.userId)
                .append(this.dateCreated, other.dateCreated)
                .append(this.dateModified, other.dateModified)
                .append(this.site, other.site)
                .append(this.status, other.status)
                .build();
    }
}
