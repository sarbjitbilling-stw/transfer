package uk.co.stwater.api.batch.psr;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import javax.inject.Named;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import io.swagger.model.Account;
import io.swagger.model.DataShareConsent;
import io.swagger.model.LegalEntitySpecialCondition;
import io.swagger.model.RefData;
import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.batch.BatchItem;
import uk.co.stwater.api.batch.BatchItemImpl;
import uk.co.stwater.api.batch.BatchJob;
import uk.co.stwater.api.batch.BatchProcessor;
import uk.co.stwater.api.batch.Status;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.SerializationManager;
import uk.co.stwater.api.osgi.util.logging.LogChannel;
import uk.co.stwater.api.osgi.util.logging.LoggerFactory;
import uk.co.stwater.api.specialconditions.psr.PsrSpecialConditionService;
import uk.co.stwater.api.specialconditions.psr.PsrSpecialConditionServiceImpl;
import uk.co.stwater.api.specialconditions.psr.model.PsrSpecialConditionDetails;
import uk.co.stwater.iib.client.api.accounts.IIBAccountsClient;
import uk.co.stwater.iib.client.api.common.TargetConfigurationRestService;
import uk.co.stwater.iib.client.api.common.TargetOffsetDateTimeDeSerializer;
import uk.co.stwater.iib.client.api.common.TargetOffsetDateTimeSerializer;
import uk.co.stwater.iib.client.api.employee.EmployeeService;
import uk.co.stwater.iib.client.api.refdata.GetReferenceDataClient;
import uk.co.stwater.iib.client.api.specialconditions.LegalEntitySpecialConditionClient;
import uk.co.stwater.iib.client.api.specialconditions.SpecialConditionTypesClient;

@Named
@Component(service = PsrSpecialConditionProcessor.class, name = "uk.co.stwater.api.batch.psr.PsrSpecialConditionProcessor")
public class PsrSpecialConditionProcessor implements BatchProcessor {
    private static Logger log = LoggerFactory.getLogger(LogChannel.BATCH, PsrSpecialConditionProcessor.class);

    private static final boolean IS_CONSENT_TO_SHARE_AUTO_ENROL = true;
    private static final String VULNERABLE_CAPTURE_SYSTEM_TARGET = "TA";
    private static final String VULNERABLE_CAPTURE_SOURCE_CAMPAIGN_AUTO_ENROL = "AE";

    private static final String REF_DATA_BILL_PRINT_MEDIUM = "57";
    private static final String REF_DATA_VULNERABLE_SUPPLY = "475";
    private static final String REF_DATA_OUT_OF_HOURS_CONTACT = "479";
    private static final String REF_DATA_EVACUATION_PLAN = "480";
    private static final String REF_DATA_VOICE_TEXT_SERVICE = "482";
    private static final String REF_DATA_VULNERABLE_TERM = "474";
    private static final String REF_DATA_LANGUAGE_LINE = "481";

    private PsrSpecialConditionService psrSpecialConditionService;
    private TargetConfigurationRestService targetConfigurationRestService;
    private EmployeeService employeeService;
    private GetReferenceDataClient referenceDataClient;
    private LegalEntitySpecialConditionClient legalEntitySpecialConditionClient;
    private SpecialConditionTypesClient specialConditionTypesClient;
    private IIBAccountsClient accountsClient;

    private final ObjectMapper objectMapper = getObjectMapper();

    @Reference
    public void setPsrSpecialConditionService(PsrSpecialConditionService psrSpecialConditionService) {
        this.psrSpecialConditionService = psrSpecialConditionService;
    }

    @Reference
    public void setTargetConfigurationRestService(TargetConfigurationRestService targetConfigurationRestService) {
        this.targetConfigurationRestService = targetConfigurationRestService;
    }

    @Reference
    public void setEmployeeService(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Reference
    public void setReferenceDataClient(GetReferenceDataClient referenceDataClient) {
        this.referenceDataClient = referenceDataClient;
    }

    @Reference
    public void setLegalEntitySpecialConditionClient(
            LegalEntitySpecialConditionClient legalEntitySpecialConditionClient) {
        this.legalEntitySpecialConditionClient = legalEntitySpecialConditionClient;
    }

    @Reference
    public void setSpecialConditionTypesClient(SpecialConditionTypesClient specialConditionTypesClient) {
        this.specialConditionTypesClient = specialConditionTypesClient;
    }

    @Reference
    public void setAccountsClient(IIBAccountsClient accountsClient) {
        this.accountsClient = accountsClient;
    }

    private ObjectMapper getObjectMapper() {
        SerializationManager serializationManager = new SerializationManager.Config()
                .with(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ISO_LOCAL_DATE),
                        new LocalDateDeserializer(DateTimeFormatter.ISO_LOCAL_DATE))
                .with(OffsetDateTime.class, new TargetOffsetDateTimeSerializer(),
                        new TargetOffsetDateTimeDeSerializer())
                .configure();

        return serializationManager.getObjectMapper();
    }

    @Override
    public void checkCSVFile(CSVParser csvParser) {
        validateColumnsExist(csvParser, PsrSpecialConditionCsvRecord.COLUMN_LEGAL_ENTITY_NUMBER,
                PsrSpecialConditionCsvRecord.COLUMN_FULL_ACCOUNT, PsrSpecialConditionCsvRecord.COLUMN_PROPERTY_ID);
        csvParser.iterator().forEachRemaining(record -> {
            PsrSpecialConditionCsvRecord psrRecord = new PsrSpecialConditionCsvRecord(record);
            if (!isValid(record.getRecordNumber(), psrRecord)) {
                log.error("Record %d is invalid, csvRecord={}", record);
                throw new BatchException(String.format("Record %d is invalid", record.getRecordNumber()));
            }
        });
    }

    private void validateColumnsExist(CSVParser csvParser, String... columnNames) {
        Map<String, Integer> headers = csvParser.getHeaderMap();
        for (String column : columnNames) {
            if (!headers.containsKey(column)) {
                throw new BatchException(String.format("Column %s is required", column));
            }
        }
    }

    @Override
    public boolean canProcess(CSVRecord csvRecord) {
        PsrSpecialConditionCsvRecord psrRecord = new PsrSpecialConditionCsvRecord(csvRecord);
        return isValid(csvRecord.getRecordNumber(), psrRecord);
    }

    private boolean isValid(long recordNumber, PsrSpecialConditionCsvRecord psrRecord) {
        boolean result = psrRecord.getLegalEntityNo() != null && psrRecord.getAccountNumber() != null
                && psrRecord.getPropertyId() != null && psrRecord.getSpecialConditionType() != null;

        // need extra fields when creating special conditions
        if (psrRecord.getEndDate() == null) {
            result = result && psrRecord.getStartDate() != null;
        }

        // @formatter:off
        return result
                && checkRefDataValueExists(recordNumber, REF_DATA_BILL_PRINT_MEDIUM, psrRecord.getBillPrintMedium())
                && checkRefDataValueExists(recordNumber, REF_DATA_VULNERABLE_SUPPLY, psrRecord.getVulnerableSupply())
                && checkRefDataValueExists(recordNumber, REF_DATA_OUT_OF_HOURS_CONTACT, psrRecord.getOutOfHoursContact())
                && checkRefDataValueExists(recordNumber, REF_DATA_EVACUATION_PLAN, psrRecord.getEvacuationPlan())
                && checkRefDataValueExists(recordNumber, REF_DATA_VOICE_TEXT_SERVICE, psrRecord.getVoiceTextService());
        // @formatter:on
    }

    private boolean checkRefDataValueExists(long recordNumber, String valueSetId, String expectedValue) {
        if (StringUtils.isBlank(expectedValue)) {
            return true;
        } else {
            List<RefData> refDataList = referenceDataClient.get(valueSetId);

            boolean containsRefData = refDataList.stream()
                    .anyMatch(refData -> refDataHasValue(refData, expectedValue));

            if (!containsRefData) {
                log.warn("RefData valueSetId={} does not contains value={}, recordNumber={}", valueSetId, expectedValue,
                        recordNumber);
            }

            return containsRefData;
        }
    }

    @Override
    public void process(BatchJob batchJob, Iterable<CSVRecord> csvRecords, Consumer<BatchItem> batchItemSaver) {
        // done asynchronously in case there a lots of records (batchItemSaver is db
        // create method)
        new Thread(() -> processSynchronously(batchJob, csvRecords, batchItemSaver)).start();
    }

    private void processSynchronously(BatchJob batchJob, Iterable<CSVRecord> csvRecords,
            Consumer<BatchItem> batchItemSaver) {
        log.info("Starting loading of records for batch job {}", batchJob.getId());
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        int count = 0;
        int errorCount = 0;

        // grouping to avoid errors that occur when multiple batch threads try to
        // add/update conditions for the same customer, account and property at the same
        // time
        log.debug("Grouping records by customer, account and property");
        Map<PsrRecordGroupIdentifier, List<PsrSpecialConditionCsvRecord>> groupedPsrRecords = new HashMap<>();

        for (CSVRecord record : csvRecords) {
            log.debug("Processing record {}, {}", record.getRecordNumber(), record);
            Optional<PsrSpecialConditionCsvRecord> psrRecordOpt = createPsrRecordSafe(record);
            boolean canProcessRecord = canProcess(record);
            if (psrRecordOpt.isPresent() && canProcessRecord) {
                PsrSpecialConditionCsvRecord psrRecord = psrRecordOpt.get();
                PsrRecordGroupIdentifier groupId = psrRecord.getBatchGroupId();
                List<PsrSpecialConditionCsvRecord> psrRecordList = groupedPsrRecords.computeIfAbsent(groupId,
                        k -> new ArrayList<>());

                log.debug("Adding record {} to PSR group {}, groupSize={}", record.getRecordNumber(), groupId,
                        psrRecordList.size());
                psrRecordList.add(psrRecord);
                count++;
            } else {
                log.warn("Cannot process record {}, psrRecord.isPresent={} canProcessRecord={}",
                        record.getRecordNumber(), psrRecordOpt.isPresent(), canProcessRecord);
                errorCount++;
            }
        }

        for (Map.Entry<PsrRecordGroupIdentifier, List<PsrSpecialConditionCsvRecord>> entry : groupedPsrRecords.entrySet()) {
            PsrRecordGroupIdentifier groupId = entry.getKey();
            List<PsrSpecialConditionCsvRecord> psrRecords = entry.getValue();
            log.debug("Creating BatchItem for PSR group {} with {} PSR special conditions", groupId, psrRecords.size());

            // build async batch item
            try {
                String batchItemData = objectMapper.writeValueAsString(psrRecords);
                BatchItemImpl batchItem = new BatchItemImpl(batchJob,
                        groupId.getAccountNumber().getAccountNumberWithCheckDigit(), batchItemData);
                batchItem.setStatus(Status.QUEUED);

                batchItemSaver.accept(batchItem);
            } catch (Exception e) {
                log.error("Failed to create BatchItem for PSR group {}", groupId, e);
                errorCount++;
            }
        }

        batchJob.setBatchSize(count);

        stopWatch.stop();
        log.info("Completed loading {} records with {} errors, for batch processing in {} ms", count,
                errorCount,
                stopWatch.getTime());
    }

    private Optional<PsrSpecialConditionCsvRecord> createPsrRecordSafe(CSVRecord csvRecord) {
        try {
            return Optional.of(new PsrSpecialConditionCsvRecord(csvRecord));
        } catch (Exception e) {
            log.error("Failed to create PsrSpecialConditionCsvRecord, recordNumber={}", csvRecord.getRecordNumber(), e);
            return Optional.empty();
        }
    }

    @Override
    public void execute(BatchItem item) {
        try {
            log.debug("Processing PSR special conditions BatchItem {}, accountNumber={}", item.getId(),
                    item.getTargetAccountNumber());
            List<PsrSpecialConditionCsvRecord> psrRecords = objectMapper.readValue(item.getFieldData(),
                    new TypeReference<List<PsrSpecialConditionCsvRecord>>() {
                    });
            PsrSpecialConditionDetails psrSpecialConditionDetails = buildPsrSpecialConditionDetails(item, psrRecords);

            log.debug("Applying PSR special conditions changes for BatchItem {}, accountNumber={}", item.getId(),
                    item.getTargetAccountNumber());
            psrSpecialConditionService.update(psrSpecialConditionDetails, null);
            log.debug("PSR special conditions changes applied for BatchItem {}, accountNumber={}", item.getId(),
                    item.getTargetAccountNumber());
        } catch (Exception e) {
            log.error("Error processing BatchItem {}, accountNumber={}", item.getId(), item.getTargetAccountNumber(),
                    e);
        }

    }

    private PsrSpecialConditionDetails buildPsrSpecialConditionDetails(BatchItem item,
            List<PsrSpecialConditionCsvRecord> psrRecordList) {
        validateGroupedPsrRecords(item, psrRecordList);
        PsrRecordGroupIdentifier groupId = psrRecordList.get(0).getBatchGroupId();

        // fetch Target employee number for system user
        String targetSystemUser = targetConfigurationRestService.getSystemUser();
        long employeeNumber = employeeService.get(targetSystemUser).getEmpNum();

        PsrSpecialConditionDetails psrSpecialConditionDetails = new PsrSpecialConditionDetails();

        // values are used in PSR service for logging
        psrSpecialConditionDetails.setLegalEntityNo(groupId.getLegalEntityNo());
        psrSpecialConditionDetails.setAccountNumber(groupId.getAccountNumber());
        psrSpecialConditionDetails.setPropertyId(Long.toString(groupId.getPropertyId()));

        // if bill print medium is required then update Account details
        String groupBillPrintMedium = getBillPrintMedium(item, psrRecordList);
        getRefDataIfValuePresent(REF_DATA_BILL_PRINT_MEDIUM, groupBillPrintMedium)
                .ifPresent(billPrintMedium -> {
                    Account accountDetails = accountsClient.getAccount(groupId.getAccountNumber(), targetSystemUser);
                    // @formatter:off
                    Account accountUpdates = new Account()
                            .accBillGroupNum(accountDetails.getAccBillGroupNum())
                            .accountVersionNum(accountDetails.getAccountVersionNum())
                            .billPrintMedium(billPrintMedium);
                    // @formatter:on
                    psrSpecialConditionDetails.setAccountDetails(accountUpdates);
                });

        // @formatter:off
        DataShareConsent dataShareIndicator = new DataShareConsent()
                .custId(groupId.getLegalEntityNo())
                .accountId(groupId.getAccountNumber().getAccountNumberAsLong())
                .propertyId(groupId.getPropertyId())
                .startDate(LocalDate.now())
                .isConsentToShare(IS_CONSENT_TO_SHARE_AUTO_ENROL)
                .vulnerableCaptureSystem(new RefData().code(VULNERABLE_CAPTURE_SYSTEM_TARGET))
                .vulnerableCaptureSource(new RefData().code(VULNERABLE_CAPTURE_SOURCE_CAMPAIGN_AUTO_ENROL))
                .createdByEmpNum((int) employeeNumber)
                .versionNum(0L);
        // @formatter:on
        psrSpecialConditionDetails.setDataShareIndicator(dataShareIndicator);

        List<LegalEntitySpecialCondition> vulnerableConditions = buildVulnerableConditions(psrRecordList,
                targetSystemUser, employeeNumber);
        psrSpecialConditionDetails.setVulnerableConditions(vulnerableConditions);

        return psrSpecialConditionDetails;
    }

    private void validateGroupedPsrRecords(BatchItem item, List<PsrSpecialConditionCsvRecord> psrRecordList) {
        if (psrRecordList.isEmpty()) {
            throw new BatchException("No PsrSpecialConditionCsvRecord's found in BatchItem " + item.getId());
        }
        PsrRecordGroupIdentifier groupId = psrRecordList.get(0).getBatchGroupId();
        for (PsrSpecialConditionCsvRecord psrRecord : psrRecordList) {
            if (!groupId.equals(psrRecord.getBatchGroupId())) {
                throw new BatchException("PSR records do not belong to the same group for BatchItem " + item.getId());
            }
        }

        getBillPrintMedium(item, psrRecordList);
    }

    public String getBillPrintMedium(BatchItem item, List<PsrSpecialConditionCsvRecord> psrRecordList) {
        // @formatter:off
        return psrRecordList.stream()
                .map(PsrSpecialConditionCsvRecord::getBillPrintMedium)
                .filter(StringUtils::isNotBlank)
                .distinct()
                // if multiple psrRecords for same group have different billPrintMedium's we
                // don't know which one we should set on the account
                .reduce((a, b) -> {
                    throw new BatchException("More than 1 billPrintMedium found for BatchItem " + item.getId());
                })
                .orElse(null);
        // @formatter:on
    }

    private List<LegalEntitySpecialCondition> buildVulnerableConditions(
            List<PsrSpecialConditionCsvRecord> psrRecordList, String targetSystemUser, long employeeNumber) {
        List<LegalEntitySpecialCondition> vulnerableConditions = new ArrayList<>();

        for (PsrSpecialConditionCsvRecord psrRecord : psrRecordList) {
            if (psrRecord.getEndDate() == null) {
                LegalEntitySpecialCondition createSpecialCondition = buildInsertVulnerableCondition(psrRecord,
                        targetSystemUser, employeeNumber);
                vulnerableConditions.add(createSpecialCondition);
            } else {
                List<LegalEntitySpecialCondition> endSpecialConditions = buildEndVulnerableConditions(psrRecord);
                vulnerableConditions.addAll(endSpecialConditions);
            }
        }

        return vulnerableConditions;
    }

    private LegalEntitySpecialCondition buildInsertVulnerableCondition(
            PsrSpecialConditionCsvRecord psrRecordDetails, String targetSystemUser, long employeeNumber) {
        log.debug("Building insert vulnerable conditions, legalEntityNo={} accountNumber={} propertyId={}",
                psrRecordDetails.getLegalEntityNo(), psrRecordDetails.getAccountNumber(),
                psrRecordDetails.getPropertyId());
        LocalDate reviewDate = psrRecordDetails.getReviewDate();
        if (reviewDate == null) {
            reviewDate = specialConditionTypesClient.calculateReviewDate(psrRecordDetails.getSpecialConditionType(),
                    targetSystemUser);
            log.debug("Calculated review date {} for specialConditionType={}", reviewDate,
                    psrRecordDetails.getSpecialConditionType());
        }

        // @formatter:off
        LegalEntitySpecialCondition vulnerableCondition = new LegalEntitySpecialCondition()
                .functionCode(PsrSpecialConditionServiceImpl.FUNCTION_CODE_INSERT)
                .legalEntityNo(psrRecordDetails.getLegalEntityNo())
                .accountId(psrRecordDetails.getAccountNumber().getAccountNumberAsLong())
                .propertyId(psrRecordDetails.getPropertyId())
                .specialConditionTypeCode(psrRecordDetails.getSpecialConditionType())
                .startDate(psrRecordDetails.getStartDate())
                .reviewDate(reviewDate)
                .empNum(employeeNumber)
                .vulnerableCaptureSystem(new RefData().code(VULNERABLE_CAPTURE_SYSTEM_TARGET))
                .vulnerableCaptureSource(new RefData().code(VULNERABLE_CAPTURE_SOURCE_CAMPAIGN_AUTO_ENROL))
                .vulnerableConsentDate(LocalDate.now());
        // @formatter:on

        getRefDataIfValuePresent(REF_DATA_VULNERABLE_SUPPLY, psrRecordDetails.getVulnerableSupply())
                .ifPresent(vulnerableCondition::setVulnerableSupply);
        getRefDataIfValuePresent(REF_DATA_OUT_OF_HOURS_CONTACT, psrRecordDetails.getOutOfHoursContact())
                .ifPresent(vulnerableCondition::setVulnerableOutOfHoursContact);
        getRefDataIfValuePresent(REF_DATA_EVACUATION_PLAN, psrRecordDetails.getEvacuationPlan())
                .ifPresent(vulnerableCondition::setEvacuationPlan);
        getRefDataIfValuePresent(REF_DATA_VOICE_TEXT_SERVICE, psrRecordDetails.getVoiceTextService())
                .ifPresent(vulnerableCondition::setVoiceTextService);
        getRefDataIfValuePresent(REF_DATA_VULNERABLE_TERM, psrRecordDetails.getVulnerableTerm())
                .ifPresent(vulnerableCondition::setVulnerableTerm);
        getRefDataIfValuePresent(REF_DATA_LANGUAGE_LINE, psrRecordDetails.getLanguageLine())
                .ifPresent(vulnerableCondition::setLanguageLine);

        return vulnerableCondition;
    }

    private List<LegalEntitySpecialCondition> buildEndVulnerableConditions(
            PsrSpecialConditionCsvRecord psrRecordDetails) {
        log.debug("Building end vulnerable conditions, legalEntityNo={} accountNumber={} propertyId={}",
                psrRecordDetails.getLegalEntityNo(), psrRecordDetails.getAccountNumber(),
                psrRecordDetails.getPropertyId());
        String customerId = Long.toString(psrRecordDetails.getLegalEntityNo());
        List<LegalEntitySpecialCondition> propertyVulnerableConditions = legalEntitySpecialConditionClient
                .getActiveVulnerableConditionsAccountProperty(customerId, psrRecordDetails.getAccountNumber(),
                        psrRecordDetails.getPropertyId(), null);

        return propertyVulnerableConditions.stream()
                .filter(specialCondition -> psrRecordDetails.getSpecialConditionType()
                        .equals(specialCondition.getSpecialConditionTypeCode()))
                .map(specialCondition -> specialCondition
                        .functionCode(PsrSpecialConditionServiceImpl.FUNCTION_CODE_UPDATE)
                        .endDate(psrRecordDetails.getEndDate()))
                .collect(Collectors.toList());
    }

    private Optional<RefData> getRefDataIfValuePresent(String valueSetId, String refDataValue) {
        if (StringUtils.isNotBlank(refDataValue)) {
            return Optional.of(getRefDataOrThrow(valueSetId, refDataValue));
        } else {
            return Optional.empty();
        }
    }

    private RefData getRefDataOrThrow(String valueSetId, String refDataValue) {
        return getRefData(valueSetId, refDataValue).orElseThrow(() -> {
            String errorMsg = String.format("Unable to find %s in RefData valueSetId=%s", refDataValue ,valueSetId);
            return new STWBusinessException(errorMsg);
        });
    }

    private Optional<RefData> getRefData(String valueSetId, String refDataValue) {
        List<RefData> refDataList = referenceDataClient.get(valueSetId);

        // @formatter:off
        return refDataList.stream()
                .filter(refData -> refDataHasValue(refData, refDataValue))
                .findFirst();
        // @formatter:on
    }

    private boolean refDataHasValue(RefData refData, String refDataValue) {
        return StringUtils.equalsIgnoreCase(StringUtils.trim(refData.getValue()), StringUtils.trim(refDataValue));
    }
    
}
