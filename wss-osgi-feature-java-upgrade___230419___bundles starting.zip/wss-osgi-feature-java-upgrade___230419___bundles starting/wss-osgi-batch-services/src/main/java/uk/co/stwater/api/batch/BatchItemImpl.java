package uk.co.stwater.api.batch;

import java.util.Date;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchStatus;

/**
 *
 * @author Mark
 */
public class BatchItemImpl implements BatchItem {

    private BatchJob batchJob;
    private Date dateCreated;
    private Date dateModified;
    private String fieldData;
    private Long id;
    private String lockedBy;
    private int retryCount;
    private Status status;
    private String targetAccountNumber;

    public BatchItemImpl(BatchJob batchJob, String targetAccountNumber, String fieldData) {
        this.batchJob = batchJob;
        this.targetAccountNumber = targetAccountNumber;
        this.fieldData = fieldData;
    }

    public BatchItemImpl(BatchJob batchJob, String targetAccountNumber, String fieldData, Status status) {
        this.batchJob = batchJob;
        this.targetAccountNumber = targetAccountNumber;
        this.fieldData = fieldData;
        this.status = status;
    }
    
    public static BatchItem fromEntity(BatchItemEntity entity) {
        if (entity == null) {
            return null;
        }
        BatchItemImpl batchItem = new BatchItemImpl(
                BatchJobImpl.fromEntity(entity.getBatchJob()),
                entity.getTargetAccountNumber(),
                entity.getFieldData());
        
        batchItem.setDateCreated(entity.getDateCreated());
        batchItem.setDateModified(entity.getDateModified());
        batchItem.setId(entity.getId());
        batchItem.setLockedBy(entity.getLockedBy());
        batchItem.setRetryCount(entity.getRetryCount());
        batchItem.setStatus(entity.getStatus() != null ? Status.valueOf(entity.getStatus().name()) : null);

        return batchItem;
    }

    public static BatchItemEntity toEntity(BatchJobEntity batchJobEntity, BatchItem batchItem) {
        BatchItemEntity batchItemEntity = new BatchItemEntity(batchJobEntity, batchItem.getTargetAccountNumber(), batchItem.getFieldData());
        batchItemEntity.setLockedBy(batchItem.getLockedBy());
        batchItemEntity.setRetryCount(batchItem.getRetryCount());
        batchItemEntity.setStatus(batchItem.getStatus() != null ? BatchStatus.valueOf(batchItem.getStatus().name()) : null);
        return batchItemEntity;
    }

    public BatchJob getBatchJob() {
        return batchJob;
    }

    public void setBatchJob(BatchJob batchJob) {
        this.batchJob = batchJob;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public String getFieldData() {
        return fieldData;
    }

    public void setFieldData(String fieldData) {
        this.fieldData = fieldData;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLockedBy() {
        return lockedBy;
    }

    public void setLockedBy(String lockedBy) {
        this.lockedBy = lockedBy;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getTargetAccountNumber() {
        return targetAccountNumber;
    }

    public void setTargetAccountNumber(String targetAccountNumber) {
        this.targetAccountNumber = targetAccountNumber;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(this.id)
                .append(this.retryCount)
                .append(this.fieldData)
                .append(this.lockedBy)
                .append(this.targetAccountNumber)
                .append(this.batchJob)
                .append(this.dateCreated)
                .append(this.dateModified)
                .append(this.status)
                .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final BatchItemImpl other = (BatchItemImpl) obj;

        return new EqualsBuilder()
                .append(this.id, other.id)
                .append(this.retryCount, other.retryCount)
                .append(this.fieldData, other.fieldData)
                .append(this.lockedBy, other.lockedBy)
                .append(this.targetAccountNumber, other.targetAccountNumber)
                .append(this.batchJob, other.batchJob)
                .append(this.dateCreated, other.dateCreated)
                .append(this.dateModified, other.dateModified)
                .append(this.status, other.status)
                .build();
    }

  

}
