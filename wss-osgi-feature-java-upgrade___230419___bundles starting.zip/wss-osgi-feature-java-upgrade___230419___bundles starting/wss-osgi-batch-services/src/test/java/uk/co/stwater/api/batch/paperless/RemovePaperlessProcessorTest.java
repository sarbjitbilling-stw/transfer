package uk.co.stwater.api.batch.paperless;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.targetconnector.client.api.accountroles.AccountRolesResponse;
import uk.co.stwater.targetconnector.client.api.accountroles.ListAccountRolesClient;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;
import uk.co.stwater.targetconnector.client.api.leregistration.GetLEDataForWSSClient;
import uk.co.stwater.targetconnector.client.api.leregistration.LERegistrationDataImpl;
import uk.co.stwater.targetconnector.client.api.leregistration.SetLEDataForWSSClient;

import java.io.FileReader;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import uk.co.stwater.api.batch.BatchItemImpl;
import static uk.co.stwater.api.batch.TestUtils.getBatchJobEntity;

// java17-t: fixme
@Ignore
@RunWith(MockitoJUnitRunner.Silent.class)
public class RemovePaperlessProcessorTest {

    @Mock
    private GetLEDataForWSSClient getLEDataForWSSClient;

    @Mock
    private SetLEDataForWSSClient setLEDataForWSSClient;

    @Mock
    private LERegistrationDataImpl leRegistrationData;

    @Mock
    private ListAccountRolesClient listAccountRolesClient;

    @Mock
    private ReferenceDataService referenceDataService;

    @Mock
    private CreateContactClient createContactClient;

    @InjectMocks
    private RemovePaperlessProcessor batchProcessor = new RemovePaperlessProcessor();

    private static final Long PRIMARY_LE_NUM = 650181817L;
    private static final Long CO_PRIMARY_LE_NUM = 659017758L;
    private static final TargetAccountNumber TARGET_ACCOUNT_NUMBER = new TargetAccountNumber(6502246986L);

    @Test
    public void givenValidCSVRecordWhenInvokingCanProcessThenReturnTrue() throws Exception {
        FileReader fileReader = new FileReader("src/test/resources/batch-test.csv");
        Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(fileReader);

        records.forEach(csvRecord -> assertTrue(batchProcessor.canProcess(csvRecord)));
    }

    @Test
    public void givenInvalidCSVRecordWhenInvokingCanProcessThenReturnFalse() throws Exception {
        FileReader fileReader = new FileReader("src/test/resources/batch-test-invalid-format.csv");
        Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(fileReader);

        records.forEach(csvRecord -> assertFalse(batchProcessor.canProcess(csvRecord)));
    }

    @Test(expected = BatchException.class)
    public void givenCSVFileWithoutHeadersWhenInvokingCheckCSVFileThenThrowException() throws Exception {
        FileReader fileReader = new FileReader("src/test/resources/batch-test-no-headers.csv");
        CSVParser csvParser = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(fileReader);

        batchProcessor.checkCSVFile(csvParser);

    }

    @Test(expected = BatchException.class)
    public void givenCSVFileWithInvalidRowWhenInvokingCheckCSVFileThenRejectFile() throws Exception {
        FileReader fileReader = new FileReader("src/test/resources/batch-test-invalid-row.csv");
        CSVParser csvParser = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(fileReader);

        batchProcessor.checkCSVFile(csvParser);
    }

    @Test
    public void givenBatchItemEntityWhenExecuteInvokedThenCallTargetAPI() {
        BatchItemEntity batchItemEntity = new BatchItemEntity(getBatchJobEntity(), TARGET_ACCOUNT_NUMBER.getAccountNumberWithCheckDigit(),
                "{\"legalEntityId\":\"650181817\"}");

        when(getLEDataForWSSClient.getLEData(any(TargetAccountNumber.class), anyLong())).thenReturn(leRegistrationData);
        when(listAccountRolesClient.getAccountRoles(any(TargetAccountNumber.class))).thenReturn(getAccountRoles());
        when(referenceDataService.getRefDataDesc(any(RefDataType.class), anyString(), anyString())).thenReturn("123");
        ContactNotesData contactNotesData = mock(ContactNotesData.class);
        when(createContactClient.getContactNotesData(any(TargetAccountNumber.class), anyLong())).thenReturn(contactNotesData);

        batchProcessor.execute(BatchItemImpl.fromEntity(batchItemEntity));

        verify(getLEDataForWSSClient).getLEData(eq(TARGET_ACCOUNT_NUMBER), anyLong());
        verify(leRegistrationData).setPaperlessBilling(eq(false));
        verify(setLEDataForWSSClient).update(any(LERegistrationDataImpl.class), eq(TARGET_ACCOUNT_NUMBER), anyString(),
                eq("U"));
        verify(listAccountRolesClient).getAccountRoles(eq(TARGET_ACCOUNT_NUMBER));
        verify(referenceDataService).getRefDataDesc(any(RefDataType.class), anyString(), anyString());
        verify(createContactClient, times(1)).getContactNotesData(any(TargetAccountNumber.class), anyLong());

    }

    private static List<AccountRolesResponse> getAccountRoles() {
        AccountRolesResponse accountRolesResponse = new AccountRolesResponse();
        accountRolesResponse.setLENum(PRIMARY_LE_NUM);
        accountRolesResponse.setStartDate(
                Date.from(LocalDate.of(2010, 1, 1).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
        accountRolesResponse.setCustAccountRoleType("P");
        accountRolesResponse.setCustAccountRoleNum(TARGET_ACCOUNT_NUMBER.getAccountNumberWithCheckDigitAsLong());
        AccountRolesResponse coPrimaryRole = new AccountRolesResponse();
        coPrimaryRole.setLENum(CO_PRIMARY_LE_NUM);
        coPrimaryRole.setStartDate(
                Date.from(LocalDate.of(2010, 1, 1).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
        coPrimaryRole.setCustAccountRoleType("C");
        coPrimaryRole.setCustAccountRoleNum(TARGET_ACCOUNT_NUMBER.getAccountNumberWithCheckDigitAsLong());
        return Arrays.asList(accountRolesResponse, coPrimaryRole);
    }

}
