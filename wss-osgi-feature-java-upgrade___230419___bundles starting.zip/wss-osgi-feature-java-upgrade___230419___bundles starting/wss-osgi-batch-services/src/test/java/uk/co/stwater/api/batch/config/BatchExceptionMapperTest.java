package uk.co.stwater.api.batch.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.batch.api.BatchExceptionMapper;
import uk.co.stwater.api.osgi.model.common.ErrorDto;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BatchExceptionMapperTest {
    @Mock
    private UriInfo uri;

    @Mock
    private Request request;

    @Mock
    private HttpHeaders headers;

    @InjectMocks
    private BatchExceptionMapper exceptionMapper = new BatchExceptionMapper();

    private BatchException batchException = new BatchException("Example message");
    @Test
    public void toRenderResponseStatusBadRequest() throws URISyntaxException {
        setupRequestMocks();

        Response response = exceptionMapper.toResponse(batchException);

        assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON, response.getHeaderString(HttpHeaders.CONTENT_TYPE));
    }

    @Test
    public void toRenderResponseContentTypeXml() throws URISyntaxException {
        setupRequestMocks(MediaType.APPLICATION_XML);
        BatchException ex = new BatchException("Example message", new Exception());

        Response response = exceptionMapper.toResponse(ex);

        assertEquals(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        assertEquals(MediaType.APPLICATION_XML, response.getHeaderString(HttpHeaders.CONTENT_TYPE));
    }

    @Test
    public void toRenderResponseContentTypeJson() throws URISyntaxException {
        setupRequestMocks(MediaType.APPLICATION_JSON);

        Response response = exceptionMapper.toResponse(batchException);

        assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON, response.getHeaderString(HttpHeaders.CONTENT_TYPE));
    }

    @Test
    public void toRenderResponseEntityErrorDtoValidation() throws URISyntaxException {
        setupRequestMocks();

        Response response = exceptionMapper.toResponse(batchException);
        Object responseEntity = response.getEntity();

        assertTrue(responseEntity instanceof ErrorDto);
        ErrorDto errorDto = (ErrorDto) responseEntity;

        assertEquals(ErrorDto.ErrorCategory.BATCH_SERVICES, errorDto.getCategory());
        assertEquals("DM50.1", errorDto.getCode());
        assertEquals(batchException.getMessage(), errorDto.getDescription());
    }

    private void setupRequestMocks() throws URISyntaxException {
        setupRequestMocks(MediaType.APPLICATION_JSON);
    }

    private void setupRequestMocks(String contentType) throws URISyntaxException {
        when(uri.getBaseUri()).thenReturn(new URI("/cxf/batch"));
        when(request.getMethod()).thenReturn("POST");
        when(headers.getHeaderString(HttpHeaders.CONTENT_TYPE)).thenReturn(contentType);
    }
}
