package uk.co.stwater.api.batch;

import uk.co.stwater.api.batch.config.BatchConfigService;
import org.apache.karaf.scheduler.JobContext;
import org.apache.karaf.scheduler.ScheduleOptions;
import org.apache.karaf.scheduler.Scheduler;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import uk.co.stwater.api.dao.batch.BatchItemEntityDao;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchStatus;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyObject;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.co.stwater.api.batch.TestUtils.getBatchItemEntity;
import static uk.co.stwater.api.batch.TestUtils.getBatchJobEntity;

@RunWith(MockitoJUnitRunner.Silent.class)
public class STWBatchJobSchedulerTest {

    @Mock
    private BatchItemEntityDao batchItemEntityDao;

    @Mock
    private BatchProcessor batchProcessor;

    @Mock
    private BatchConfigService batchConfigService;

    @Mock
    private JobContext jobContext;

    @Mock
    private Scheduler scheduler;

    @InjectMocks
    @Spy
    private BatchJobScheduler batchJobScheduler = new BatchJobScheduler();

    private static final String JOB_NAME = "uk.co.stwater.api.batch.BatchJobScheduler:7cbe89a2-02fa-4fc3-9d89-107ec5a17f69";

    @Before
    public void setUp() {
        when(batchJobScheduler.getJobName()).thenReturn(JOB_NAME);
        when(batchConfigService.getSchedulerThreadPoolSize()).thenReturn(10);
        when(batchConfigService.getBatchProcessor(anyString())).thenReturn(batchProcessor);
    }

    @Test(expected = IllegalArgumentException.class)
    public void givenInvalidCronExpressionWhenActivatedThenThrowException() throws Exception {
        String cronExp = "0 0/2 30 * * ?";
        when(batchConfigService.getCronExpression()).thenReturn(cronExp);
        ScheduleOptions scheduleOptions = mock(ScheduleOptions.class);
        when(scheduler.EXPR(anyString())).thenReturn(scheduleOptions);
        when(scheduleOptions.name(anyString())).thenReturn(scheduleOptions);
        doThrow(new IllegalArgumentException()).when(scheduler).schedule(anyObject(), any(ScheduleOptions.class));

        batchJobScheduler.reschedule();

        verify(scheduler).schedule(anyObject(), any(ScheduleOptions.class));
    }

    @Test
    public void givenNoExistingJobsWhenActivatedThenScheduleJobUsingConfig() throws Exception {
        String expr = "0 0/5 * * * ?";
        when(batchConfigService.getCronExpression()).thenReturn(expr);
        Map<String,ScheduleOptions> map = new HashMap<>();
        ScheduleOptions scheduleOptions = mock(ScheduleOptions.class);
        when(scheduler.EXPR(anyString())).thenReturn(scheduleOptions);
        when(scheduleOptions.name(anyString())).thenReturn(scheduleOptions);
        when(scheduleOptions.name()).thenReturn(JOB_NAME);
        map.put(batchJobScheduler.getJobName(), scheduleOptions);
        when(scheduler.getJobs()).thenReturn(Collections.emptyMap(),Collections.emptyMap(),map);

        batchJobScheduler.reschedule();

        assertEquals(expr, batchConfigService.getCronExpression());
        verify(scheduler, never()).unschedule(anyString());
        verify(scheduler, times(1)).schedule(anyObject(), any(ScheduleOptions.class));
        verify(scheduler,times(3)).getJobs();
    }

    @Test
    public void givenBatchJobsExistWhenExecutedThenInvokeBatchProcessor() throws Exception {
        BatchJobEntity job = getBatchJobEntity();

        when(batchItemEntityDao.findNextItemsForTask(anyInt(), anyString())).thenReturn(
                Arrays.asList(getBatchItemEntity(job, "111111118"),
                        getBatchItemEntity(job, "222222226"),
                        getBatchItemEntity(job, "333333334"),
                        getBatchItemEntity(job, "444444442"),
                        getBatchItemEntity(job, "555555556")));

        batchJobScheduler.execute(jobContext);

        verify(batchItemEntityDao, times(1)).findNextItemsForTask(anyInt(), anyString());
        ArgumentCaptor<BatchItemEntity> itemEntityArgumentCaptor = ArgumentCaptor.forClass(BatchItemEntity.class);
        verify(batchItemEntityDao, times(5)).update(itemEntityArgumentCaptor.capture());
        itemEntityArgumentCaptor.getAllValues().forEach(item -> assertEquals(BatchStatus.COMPLETED, item.getStatus()));
        verify(batchProcessor, times(5)).execute(any(BatchItem.class));
    }

    @Test
    public void testJobNameSubstring() {
        String owner = JOB_NAME.split(":")[1];
        assertEquals("7cbe89a2-02fa-4fc3-9d89-107ec5a17f69",owner);
    }



}
