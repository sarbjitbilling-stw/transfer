package uk.co.stwater.api.batch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.FileInputStream;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;

import junitx.util.PrivateAccessor;
import uk.co.stwater.api.batch.api.BatchJobDto;
import uk.co.stwater.api.batch.api.BatchRequestDto;
import uk.co.stwater.api.batch.config.BatchConfigService;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchItemEntityDao;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchJobEntityDao;
import uk.co.stwater.api.osgi.model.AccountBrand;

@RunWith(MockitoJUnitRunner.Silent.class)
public class STWBatchServiceImplTest {

    private static final String STW_BRAND = AccountBrand.SEVERN_TRENT.getSite();

    private static final String DEFAULT_PROCESSOR = "RemovePaperlessProcessor";

    @Mock
    private BatchItemEntityDao batchItemEntityDao;

    @Mock
    private BatchJobEntityDao batchJobEntityDao;

    @Mock
    private Logger logger;
    
    @Mock
    private BatchConfigService batchConfigService;

    @Mock
    private BundleContext bundleContext;

    @InjectMocks
    private STWBatchService stwBatchService = new STWBatchServiceImpl();

    @Before
    public void setUp() throws Exception {
        PrivateAccessor.setField(stwBatchService.getClass(), "logger", logger);
        ServiceReference serviceReference = mock(ServiceReference.class);
        when(bundleContext.getServiceReference(eq(BatchConfigService.class))).thenReturn(serviceReference);
        when(bundleContext.getService(eq(serviceReference))).thenReturn(batchConfigService);
    }
    
    @Test
    public void givenValidRequestWhenJobSubmittedThenCreateEntriesInDB() throws Exception {
        FileInputStream fileInputStream = new FileInputStream("src/test/resources/batch-test.csv");
        byte[] data = IOUtils.toByteArray(fileInputStream);
        BatchRequestDto emailBatchRequest = new BatchRequestDto();
        emailBatchRequest.setData(data);
        emailBatchRequest.setBrand(STW_BRAND);
        emailBatchRequest.setCommand(DEFAULT_PROCESSOR);
        ArgumentCaptor<BatchJobEntity> itemEntityArgumentCaptor = ArgumentCaptor.forClass(BatchJobEntity.class);
        AsyncBatchProcessor batchProcessor = spy(new TestBatchProcessor());
        when(batchConfigService.getBatchProcessor(anyString())).thenReturn(batchProcessor);
        when(batchConfigService.getBatchMaxFileSize()).thenReturn(1000000);
        doAnswer(invocation -> {
            BatchJobEntity entity = (BatchJobEntity)invocation.getArguments()[0];
            entity.setId(1L);
            return null;
        }).when(batchJobEntityDao).save(any(BatchJobEntity.class));
        doNothing().when(batchItemEntityDao).save(any(BatchItemEntity.class));

        BatchJobDto createdJob = stwBatchService.createJob(emailBatchRequest);

        assertNotNull(createdJob);
        assertEquals(1, createdJob.getId());
        assertEquals(0, createdJob.getBatchSize());
        verify(batchJobEntityDao, timeout(1000)).save(itemEntityArgumentCaptor.capture());
        verify(batchConfigService,timeout(1000).times(1)).getBatchProcessor(anyString());
        verify(batchProcessor, timeout(1000)).canProcess(any(CSVRecord.class));
        verify(batchProcessor, timeout(1000)).createBatchItem(any(BatchJob.class), any(CSVRecord.class));
        verify(batchItemEntityDao, timeout(1000)).save(any(BatchItemEntity.class));
     }

    @Test
    public void givenCSVFileWithoutHeaderRowWhenRequestProcessedThenReturnError() throws Exception {
        FileInputStream fileInputStream = new FileInputStream("src/test/resources/batch-test-no-headers.csv");
        byte[] data = IOUtils.toByteArray(fileInputStream);
        BatchRequestDto emailBatchRequest = new BatchRequestDto();
        emailBatchRequest.setData(data);
        emailBatchRequest.setBrand(STW_BRAND);
        emailBatchRequest.setCommand(DEFAULT_PROCESSOR);
        AsyncBatchProcessor batchProcessor = mock(AsyncBatchProcessor.class);
        when(batchConfigService.getBatchProcessor(anyString())).thenReturn(batchProcessor);
        doThrow(new BatchException("missing headers")).when(batchProcessor).checkCSVFile(any(CSVParser.class));
        BatchItem batchItem = mock(BatchItem.class);
        when(batchProcessor.createBatchItem(any(BatchJob.class), any(CSVRecord.class))).thenReturn(batchItem);
        when(batchConfigService.getBatchMaxFileSize()).thenReturn(1000000);

        try {
            BatchJobDto createdJob = stwBatchService.createJob(emailBatchRequest);
            fail("expected BatchException");
        } catch (BatchException e) {
        }

        verify(batchJobEntityDao, never()).save(any(BatchJobEntity.class));
        verify(batchProcessor, never()).canProcess(any(CSVRecord.class));

    }


    class TestBatchProcessor extends AsyncBatchProcessor implements BatchProcessor {

        @Override
        public void checkCSVFile(CSVParser csvParser) {
        }

        @Override
        public boolean canProcess(CSVRecord csvRecord) {
            return true;
        }

        @Override
        public BatchItem createBatchItem(BatchJob batchJob, CSVRecord csvRecord) {

            BatchItemImpl batchItem = mock(BatchItemImpl.class);
            //when(BatchItemImpl.fromEntiry(BatchItemEntity.NULL_ENTITY)).thenReturn(batchItem);
            return batchItem;
        }

        @Override
        public void execute(BatchItem batchItem) {
        }

    }
     
     
 }
