package uk.co.stwater.api.batch;

import uk.co.stwater.api.batch.api.BatchResource;
import uk.co.stwater.api.batch.api.BatchRequestDto;
import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.apache.commons.io.IOUtils;
import org.apache.cxf.binding.BindingFactoryManager;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSBindingFactory;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;
import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.util.JacksonContextResolver;
import uk.co.stwater.api.osgi.util.TestUtil;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.co.stwater.api.batch.TestUtils.getTestBatchJob;

@RunWith(MockitoJUnitRunner.Silent.class)
public class STWBatchResourceTest {

    private static Server server;
    private final static String ENDPOINT_ADDRESS = TestUtil
        .getUrlWithRandomPort("http://localhost:%s/batch");

    private static List<Object> providers;

    private static WebClient webClient;

    private static JAXRSServerFactoryBean serverFactoryBean;

    private static final String DEFAULT_PROCESSOR = "RemovePaperlessProcessor";

    @Mock
    private STWBatchService stwBatchService;

    @InjectMocks
    private BatchResource stwBatchResource = new BatchResource();

    private static final String STW_BRAND = AccountBrand.SEVERN_TRENT.getSite();

    @BeforeClass
    public static void init() {
        providers = Arrays.asList(JacksonJaxbJsonProvider.class, JacksonContextResolver.class);
        serverFactoryBean = new JAXRSServerFactoryBean();
        serverFactoryBean.setProviders(providers);
        serverFactoryBean.setAddress(ENDPOINT_ADDRESS);
        serverFactoryBean.getBus().setProperty("skip.default.json.provider.registration", true);
        BindingFactoryManager manager = serverFactoryBean.getBus()
            .getExtension(BindingFactoryManager.class);
        JAXRSBindingFactory factory = new JAXRSBindingFactory();
        factory.setBus(serverFactoryBean.getBus());
        manager.registerBindingFactory(JAXRSBindingFactory.JAXRS_BINDING_ID, factory);
        webClient = WebClient.create(ENDPOINT_ADDRESS, providers).type(MediaType.APPLICATION_JSON);
    }

    @Before
    public void initialize() {
        MockitoAnnotations.initMocks(stwBatchResource);
        serverFactoryBean.setServiceBean(stwBatchResource);
        serverFactoryBean.setResourceProvider(BatchResource.class,
            new SingletonResourceProvider(stwBatchResource, true));
        server = serverFactoryBean.create();
        webClient.reset();
    }

    @After
    public void tearDown() {
        server.stop();
        server.destroy();
    }

    @Test
    public void givenValidRequestWithBatchDataFromCSVThenReturnAcceptedURI()
        throws Exception {

        FileInputStream fileInputStream = new FileInputStream("src/test/resources/batch-test.csv");
        byte[] data = IOUtils.toByteArray(fileInputStream);
        BatchRequestDto stwBatchRequest = new BatchRequestDto();
        stwBatchRequest.setData(data);
        stwBatchRequest.setBrand(STW_BRAND);
        stwBatchRequest.setCommand(DEFAULT_PROCESSOR);
        when(stwBatchService.createJob(any(BatchRequestDto.class)))
            .thenReturn(getTestBatchJob(1L));

        Response response = webClient.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON).post(stwBatchRequest);

        assertNotNull(response);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatus());
        assertEquals("/batch/1", response.getLink("href").getUri().getPath());
        assertEquals("/batch/1", response.getLocation().getPath());
        verify(stwBatchService, times(1)).createJob(any(BatchRequestDto.class));
    }

    @Test
    public void givenMissingDataWhenCreatingBatchJobThenReturnBadRequest() throws Exception {
        BatchRequestDto stwBatchRequest = new BatchRequestDto();
        stwBatchRequest.setBrand(STW_BRAND);

        Response response = webClient.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON).post(stwBatchRequest);

        assertNotNull(response);
        assertEquals(400, response.getStatus());
        verify(stwBatchService, never()).createJob(any(BatchRequestDto.class));
    }

    @Test
    public void givenMissingBrandWhenCreatingBatchJobThenReturnBadRequest() throws Exception {
        FileInputStream fileInputStream = new FileInputStream("src/test/resources/batch-test.csv");
        byte[] data = IOUtils.toByteArray(fileInputStream);
        BatchRequestDto stwBatchRequest = new BatchRequestDto();
        stwBatchRequest.setData(data);
        Response response = webClient.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON).post(stwBatchRequest);

        assertNotNull(response);
        assertEquals(400, response.getStatus());
        verify(stwBatchService, never()).createJob(any(BatchRequestDto.class));
    }

    @Test
    public void givenMissingProcessorWhenCreatingBatchJobThenReturnBadRequest() throws Exception {
        FileInputStream fileInputStream = new FileInputStream("src/test/resources/batch-test.csv");
        byte[] data = IOUtils.toByteArray(fileInputStream);
        BatchRequestDto stwBatchRequest = new BatchRequestDto();
        stwBatchRequest.setData(data);
        stwBatchRequest.setBrand(STW_BRAND);
        Response response = webClient.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON).post(stwBatchRequest);

        assertNotNull(response);
        assertEquals(400, response.getStatus());
        verify(stwBatchService, never()).createJob(any(BatchRequestDto.class));
    }
}
