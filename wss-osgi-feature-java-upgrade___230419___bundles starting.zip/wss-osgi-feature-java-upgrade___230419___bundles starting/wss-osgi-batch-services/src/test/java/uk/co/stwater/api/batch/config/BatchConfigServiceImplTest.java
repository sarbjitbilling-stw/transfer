package uk.co.stwater.api.batch.config;

import org.apache.karaf.scheduler.Scheduler;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import uk.co.stwater.api.batch.paperless.RemovePaperlessProcessor;

import java.util.HashMap;
import java.util.Map;
import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.batch.BatchJobScheduler;
import uk.co.stwater.api.batch.BatchProcessor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;
import static uk.co.stwater.api.batch.config.BatchConfigServiceImpl.BATCH_JOB_ITEMS_MAXIMUM;
import static uk.co.stwater.api.batch.config.BatchConfigServiceImpl.BATCH_JOB_ITEMS_MINIMUM;
import static uk.co.stwater.api.batch.config.BatchConfigServiceImpl.BATCH_JOB_ITEMS_SIZE;
import static uk.co.stwater.api.batch.config.BatchConfigServiceImpl.BATCH_MAX_FILE_SIZE_BYTES;
import static uk.co.stwater.api.batch.config.BatchConfigServiceImpl.BATCH_SCHEDULER_THREAD_POOL_SIZE;


@RunWith(MockitoJUnitRunner.Silent.class)
public class BatchConfigServiceImplTest {

    @Mock
    private BundleContext bundleContext;

    @Mock
    private Scheduler scheduler;

    @Mock
    private BatchJobScheduler batchJobScheduler;

    @InjectMocks
    private BatchConfigServiceImpl batchConfigService = new BatchConfigServiceImpl();

    private Map<String,String> config = new HashMap<>();

    private static final String PAPERLESS_REMOVAL_ID = "paperless-removal";

    private static final String JOB_NAME = "uk.co.stwater.api.batch.BatchJobScheduler:7cbe89a2-02fa-4fc3-9d89-107ec5a17f69";

    @Test
    public void givenValidMaxFileSizeWhenReadingValueThenReturnValue() throws Exception {
        config.put(BATCH_MAX_FILE_SIZE_BYTES, "1000");
        batchConfigService.updated(config);

        assertEquals(1000, batchConfigService.getBatchMaxFileSize());
    }

    @Test
    public void givenMaxFileSizeConfigMissingWhenReadingValueThenReturnDefaultValue() throws Exception {
        batchConfigService.updated(config);

        assertEquals(1000000, batchConfigService.getBatchMaxFileSize());
    }

    @Test
    public void givenInvalidMaxFileSizeWhenReadingValueThenReturnDefaultValue() throws Exception {
        config.put(BATCH_MAX_FILE_SIZE_BYTES, "a");
        batchConfigService.updated(config);

        assertEquals(1000000, batchConfigService.getBatchMaxFileSize());
    }

    @Test
    public void givenCommandIdExistsInConfigThenReturnBatchCommand() throws Exception {
        config.put(PAPERLESS_REMOVAL_ID, RemovePaperlessProcessor.class.getName());
        batchConfigService.updated(config);
        ServiceReference serviceReference = Mockito.mock(ServiceReference.class);
        when(bundleContext.getServiceReference(eq(RemovePaperlessProcessor.class.getName()))).thenReturn(serviceReference);
        when(bundleContext.getService(any(ServiceReference.class))).thenReturn(new RemovePaperlessProcessor());
        BatchProcessor batchProcessor = batchConfigService.getBatchProcessor(PAPERLESS_REMOVAL_ID);

        assertNotNull(batchProcessor);
    }

    @Test(expected = BatchException.class)
    public void givenCommandIdNotExistsInConfigThenThrowException() throws Exception {
        batchConfigService.updated(config);

        batchConfigService.getBatchProcessor(PAPERLESS_REMOVAL_ID);

    }

    @Test
    public void testJobNameSubstring() {
        String owner = JOB_NAME.split(":")[1];
        assertEquals("7cbe89a2-02fa-4fc3-9d89-107ec5a17f69",owner);
    }

    @Test
    public void givenValidMinimumJobSizeWhenReadingValueThenReturnValue() throws Exception {
        config.put(BATCH_JOB_ITEMS_MINIMUM, "10");

        batchConfigService.updated(config);

        assertEquals(10, batchConfigService.getMinimumJobSize());
    }

    @Test
    public void givenInvalidMinimumJobSizeWhenReadingValueThenReturnDefault() throws Exception {
        config.put(BATCH_JOB_ITEMS_MINIMUM, "1");

        batchConfigService.updated(config);

        assertEquals(100, batchConfigService.getMinimumJobSize());
    }


    @Test
    public void givenValidMaximumJobSizeWhenReadingValueThenReturnValue() throws Exception {
        config.put(BATCH_JOB_ITEMS_MAXIMUM, "1000");

        batchConfigService.updated(config);

        assertEquals(1000, batchConfigService.getMaximumJobSize());
    }

    @Test
    public void givenInvalidMaximumJobSizeWhenReadingValueThenReturnDefault() throws Exception {
        config.put(BATCH_JOB_ITEMS_MAXIMUM, "500");

        batchConfigService.updated(config);

        assertEquals(10000, batchConfigService.getMaximumJobSize());
    }

    @Test
    public void givenJobItemsSizeWhenReadingValueThenReturnValue() throws Exception {
        config.put(BATCH_JOB_ITEMS_SIZE, "25");
        config.put(BATCH_JOB_ITEMS_MINIMUM, "10");
        config.put(BATCH_JOB_ITEMS_MAXIMUM, "1000");

        batchConfigService.updated(config);

        assertEquals(25, batchConfigService.getJobItemsSize());
    }

    @Test
    public void givenInvalidJobItemsSizeWhenReadingValueThenReturnDefaultValue() throws Exception {
        config.put(BATCH_JOB_ITEMS_SIZE, "5");
        config.put(BATCH_JOB_ITEMS_MINIMUM, "10");
        config.put(BATCH_JOB_ITEMS_MAXIMUM, "1000");

        batchConfigService.updated(config);

        assertEquals(1000, batchConfigService.getJobItemsSize());
    }

    @Test
    public void givenValidThreadPoolSizeWhenReadingValueThenReturnValue() throws Exception {
        config.put(BATCH_SCHEDULER_THREAD_POOL_SIZE, "10");

        batchConfigService.updated(config);

        assertEquals(10, batchConfigService.getSchedulerThreadPoolSize());
    }

    @Test
    public void givenInvalidThreadPoolSizeWhenReadingValueThenReturnDefaultValue() throws Exception {
        config.put(BATCH_SCHEDULER_THREAD_POOL_SIZE, "25");

        batchConfigService.updated(config);

        assertEquals(10, batchConfigService.getSchedulerThreadPoolSize());
    }
}
