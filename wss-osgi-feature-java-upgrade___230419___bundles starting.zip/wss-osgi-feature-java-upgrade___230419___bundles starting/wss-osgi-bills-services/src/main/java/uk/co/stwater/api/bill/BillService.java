package uk.co.stwater.api.bill;

import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

public interface BillService {

    String CREATE_ACTION = "create";

    String VALIDATE_ACTION = "validate";

    Bill create(Bill createBill, String authToken, String action, boolean multiSimBillAttemptsRequired) throws STWBusinessException, STWTechnicalException;

    Bill create(Bill createBill, String authToken, String action) throws STWBusinessException, STWTechnicalException;

    Bill simulate(Bill simulateBill, String authToken, String action, boolean multipleAttemptsRequired) throws STWBusinessException, STWTechnicalException;

    Bill simulate(Bill simulateBill, String authToken, String action) throws STWBusinessException, STWTechnicalException;

    Bill validate(Bill createBill, String authToken, String action) throws STWBusinessException, STWTechnicalException;
}
