package uk.co.stwater.api.bill.date.set;

import java.time.LocalDate;

import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.iib.client.api.meterread.get.IIBGetMeterReadResponse;

public interface EndDateSetupService {
    Bill setUpMeasuredAccountEndDate(Bill bill, boolean status, LocalDate moveInDate, LocalDate moveOutDate,
            IIBGetMeterReadResponse iibMeterReadResponse);

    Bill setUpUnmeasuredAccountEndDate(Bill bill, boolean status, LocalDate moveInDate, LocalDate moveOutDate);

    Bill setUpAssessedAccountEndDate(Bill bill, boolean status, LocalDate moveInDate, LocalDate moveOutDate);
}
