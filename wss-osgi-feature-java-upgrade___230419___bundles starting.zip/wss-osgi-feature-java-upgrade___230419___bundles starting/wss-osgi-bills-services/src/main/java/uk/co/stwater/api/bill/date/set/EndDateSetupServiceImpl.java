package uk.co.stwater.api.bill.date.set;

import java.time.LocalDate;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.feature.FeatureService;
import uk.co.stwater.iib.client.api.bill.status.AccountBillStatusClient;
import uk.co.stwater.iib.client.api.bill.status.NextBillStatusResponse;
import uk.co.stwater.iib.client.api.meterread.get.IIBGetMeterReadResponse;

@Named
@OsgiServiceProvider(classes = { EndDateSetupService.class })
public class EndDateSetupServiceImpl implements EndDateSetupService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EndDateSetupServiceImpl.class);
	
    @Inject
    @OsgiService
    private AccountBillStatusClient accountBillStatusClient;

    @Inject
    @OsgiService
    private FeatureService featureService;

    @Override
    public Bill setUpMeasuredAccountEndDate(Bill bill, boolean status, LocalDate moveInDate, LocalDate moveOutDate,
			IIBGetMeterReadResponse iibMeterReadResponse) {
        LOGGER.debug("About to setup end date for measured account, moveOutDate={}", moveOutDate);
		if (moveOutDate != null) {
            setBillEndDateAccountMovedOut(bill, moveOutDate);
		} else {
			if (iibMeterReadResponse != null && iibMeterReadResponse.getCapturedDate() != null) {
				//Measured ->Get last billable read date, use this (if none use today)
				LocalDate latestBillableReadDate = iibMeterReadResponse.getCapturedDate().toLocalDate();
				LOGGER.debug("Last billable read date is {} ", latestBillableReadDate);
				bill.setEndDate(latestBillableReadDate);
			} else {
				LocalDate today = LocalDate.now();
				LOGGER.debug("Move in date is {}", moveInDate);
				LOGGER.debug("Property is measured. Account is not moved out so end date will be {}",
						today);
				bill.setEndDate(today);
			}
		}
		return bill;
	}

    @Override
    public Bill setUpUnmeasuredAccountEndDate(Bill bill, boolean status, LocalDate moveInDate, LocalDate moveOutDate) {
        LOGGER.debug("About to setup end date for unmeasured account, moveOutDate={}", moveOutDate);
		if (moveOutDate != null) {
            setBillEndDateAccountMovedOut(bill, moveOutDate);
        } else {
            // done to remove check digit before sending request
            TargetAccountNumber accountNumber = new TargetAccountNumber(bill.getAccountNumber());
            Property property = new Property();
            property.setPropertyId(bill.getPropertyId());
            NextBillStatusResponse nextBillStatus = accountBillStatusClient.getNextBillStatus(accountNumber, property);

            LocalDate nextBillPeriodEndDate = nextBillStatus.getNextBillPeriodEndDate();
            LOGGER.debug("Next bill period end date is {}", nextBillPeriodEndDate);

            if (nextBillPeriodEndDate == null) {
                LOGGER.error("Target returned null next bill period end date for accountNumber={}, propertyId={}",
                        accountNumber, bill.getPropertyId());
                throw new STWTechnicalException("Unable to retrieve next bill period end date");
            }

            bill.setEndDate(nextBillPeriodEndDate);
        }
        return bill;

	}

    @Override
    public Bill setUpAssessedAccountEndDate(Bill bill, boolean status, LocalDate moveInDate, LocalDate moveOutDate) {
        LOGGER.debug("About to setup end date for assessed account, moveOutDate={}", moveOutDate);
		if (moveOutDate != null) {
            setBillEndDateAccountMovedOut(bill, moveOutDate);
		} else {
			LOGGER.debug("Move in date is {}", moveInDate);
			LocalDate today = LocalDate.now();
			LOGGER.debug("Property is assessed. Account is not moved out so end date will be {}", today);
			bill.setEndDate(today);
		}
		return bill;
	}

    private void setBillEndDateAccountMovedOut(Bill bill, LocalDate moveOutDate) {
        LOGGER.debug("Account moved out so end date will be set to move out date {}", moveOutDate);
        bill.setEndDate(moveOutDate);
    }

}
