package uk.co.stwater.api.bill;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.bill.date.set.EndDateSetupService;
import uk.co.stwater.api.metering.agent.MeterReadService;
import uk.co.stwater.api.osgi.cache.CacheService;
import uk.co.stwater.api.osgi.model.ProcessOutcomeList;
import uk.co.stwater.api.osgi.model.ProcessOutcome;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.model.payment.bill.BillEvent;
import uk.co.stwater.api.osgi.model.transaction.AccountEvent;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.payment.transactions.PaymentTransactionsService;
import uk.co.stwater.iib.client.api.bill.simulate.IIBSimulateBillClient;
import uk.co.stwater.iib.client.api.bill.simulate.IIBSimulateBillRequest;
import uk.co.stwater.iib.client.api.bill.simulate.IIBSimulateBillResponse;
import uk.co.stwater.iib.client.api.bill.simulate.SimulateBillResponseDTO;
import uk.co.stwater.iib.client.api.common.TargetError;
import uk.co.stwater.iib.client.api.meterread.get.IIBGetMeterReadResponse;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

@OsgiServiceProvider(classes = {BillService.class})
@Named
public class BillServiceImpl implements BillService {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMM yyyy");
    Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @OsgiService
    @Inject
    CacheService cacheService;

    @Inject
    @OsgiService
    private IIBSimulateBillClient iibSimulateBillClient;

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberClient;

    @Inject
    @OsgiService
    private PaymentTransactionsService paymentTransactionsService;

    @Inject
    @OsgiService
    private MeterReadService meterReadService;

    @Inject
    private EndDateSetupService endDateSetupService;

    @Override
    public Bill create(Bill bill, String authToken, String action, boolean multipleAttemptsRequired) throws STWBusinessException, STWTechnicalException {

        throwExceptionIfBillEmpty(bill, action);

        LOGGER.info("account number is {}, propertyId is {} and end date is {}", bill.getAccountNumber(),
                bill.getPropertyId(), bill.getEndDate());
        ProcessOutcome outcome = new ProcessOutcome();

        Bill createdBill = createBill(bill, authToken, outcome, multipleAttemptsRequired);

        if (createdBill.getAccountNumber() != null) {
            String path = String.format(BillEnum.CREATE_BILL.getPath(), createdBill.getAccountNumber());
            LOGGER.info("Path is {}", path);
            outcome.setPath(path);
            createdBill.setProcessOutcome(outcome);
        }
        return createdBill;
    }

    @Override
    public Bill create(Bill createBill, String authToken, String action) throws STWBusinessException,
            STWTechnicalException {
        return create(createBill, authToken, action, false);
    }

    @Override
    public Bill simulate(Bill bill, String authToken, String action, boolean multipleAttemptsRequired)
            throws STWBusinessException, STWTechnicalException {

        throwExceptionIfBillEmpty(bill, action);

        LOGGER.info("account number is {}, propertyId is {} and end date is {}", bill.getAccountNumber(),
                bill.getPropertyId(), bill.getEndDate());
        ProcessOutcome outcome = new ProcessOutcome();

        Bill simulatedBill = simulateBill(bill, authToken, outcome, multipleAttemptsRequired);

        if (simulatedBill.getAccountNumber() != null) {
            String path = String.format(BillEnum.SIMULATE_BILL.getPath(), simulatedBill.getAccountNumber());
            LOGGER.info("Path is {}", path);
            outcome.setPath(path);
            simulatedBill.setProcessOutcome(outcome);
        }
        return simulatedBill;
    }

    @Override
    public Bill simulate(Bill simulateBill, String authToken, String action) throws STWBusinessException, STWTechnicalException {
        return simulate(simulateBill, authToken, action, false);
    }

    private void throwExceptionIfBillEmpty(Bill bill, String action) {
        if (StringUtils.isNotEmpty(action)) {
            if (action.equalsIgnoreCase(BillConstant.CREATE) || action.equalsIgnoreCase(BillConstant.SIMULATE)) {
                if (StringUtils.isEmpty(bill.getAccountNumber()) || null == bill.getPropertyId()
                        || null == bill.getEndDate()) {
                    throw new STWBusinessException(String.format(
                            "account number is %s, propertyId is %s, endDate is %s. All of them are mandatory parameters and should not be empty or null.",
                            bill.getAccountNumber(), bill.getPropertyId(), bill.getEndDate()));
                }
            } else if (action.equalsIgnoreCase(BillConstant.VALIDATE)) {
                if (StringUtils.isEmpty(bill.getAccountNumber()) || null == bill.getPropertyId()) {
                    throw new STWBusinessException(String.format(
                            "account number is %s, propertyId is %s. All of them are mandatory parameters and should not be empty or null.",
                            bill.getAccountNumber(), bill.getPropertyId()));
                }
            }
        }
    }

    private Bill createBill(Bill createBill, String authToken, ProcessOutcome outcome, boolean multipleAttemptsRequired) {
        IIBSimulateBillRequest createBillRequest = new IIBSimulateBillRequest();
        // Needs account number, propertyId, endDate and function code X to simulate
        setBillRequest(createBill, createBillRequest);
        // invalidate cache for AccountSummaryResponse
        LOGGER.debug("invalidating cache before calling simulate bill");
        cacheService.invalidate(createBillRequest.getAccountNumber(), TargetAccountNumber.class,
                AccountSummaryResponse.class);
        LOGGER.debug("Before making call to simulateBill with function code {}", BillConstant.ACTION_SIMULATE);
        SimulateBillResponseDTO responseDTO = iibSimulateBillClient.simulateBill(createBillRequest, authToken, false, multipleAttemptsRequired);
        IIBSimulateBillResponse response = responseDTO.getIibSimulateBillResponse();
        if (response != null) {
            setUpdateBillrequest(createBillRequest, response);
            // Needs account number, propertyId, endDate function code U, billedRunAmount,
            // and combinedNum to create
            LOGGER.debug("Before making call to simulateBill with function code {}", BillConstant.ACTION_UPDATE);
            responseDTO = iibSimulateBillClient.simulateBill(createBillRequest, authToken, false, multipleAttemptsRequired);
            response = responseDTO.getIibSimulateBillResponse();
            if (response == null) {
                setTargetErrorAsWarningMessage(responseDTO.getTargetError(), BillEnum.CREATE_BILL.getErrorMessage(),
                        outcome);
            } else {
                setBillFromResponse(createBill, response);
            }

        } else {
            setTargetErrorAsWarningMessage(responseDTO.getTargetError(), BillEnum.CREATE_BILL.getErrorMessage(),
                    outcome);
        }
        return createBill;
    }

    private void setUpdateBillrequest(IIBSimulateBillRequest createBillRequest, IIBSimulateBillResponse response) {
        createBillRequest.setFunctionCode(BillConstant.ACTION_UPDATE);
        createBillRequest.setBilledRunAmount(response.getBilledRunAmount());
        createBillRequest.setCombinedNum(response.getCombinedNum());
    }

    private void setBillFromResponse(Bill bill, IIBSimulateBillResponse response) {
        bill.setCurrentBalAmount(response.getCurrentBalAmount());
        bill.setFinalBalAmount(response.getFinalBalAmount());
        LOGGER.debug("Current balance ammount is {} and final balance amount is {}", response.getCurrentBalAmount(),
                response.getFinalBalAmount());
        bill.setBillStartDate(response.getBillStartDate());
        bill.setBillEndDate(response.getBillEndDate());
        LOGGER.debug("Bill start date is {} and Bill end date is {}", response.getBillStartDate(),
                response.getBillEndDate());
        List<BillEvent> listOfBillEvents = new ArrayList<>();
        if (response.getBillEvents() != null && !response.getBillEvents().isEmpty()) {
            response.getBillEvents().forEach(ioBillEvent -> {
                setBill(new BillEvent(), ioBillEvent, listOfBillEvents);
            });
        }
        bill.setBillEvents(listOfBillEvents);
        LOGGER.debug("Bill events are {}", response.getBillEvents());
        bill.setBilledRunAmount(response.getBilledRunAmount());
        LOGGER.debug("Billed Run Amount is {}", response.getBilledRunAmount());
        bill.setNumOfDays(response.getNumOfDays());
        bill.setCombinedNum(response.getCombinedNum());
        LOGGER.debug("Num of days is/are {} and Combined Num is {}", response.getNumOfDays(),
                response.getCombinedNum());
    }

    private void setBill(BillEvent billEvent, io.swagger.model.BillEvent ioBillEvent, List<BillEvent> listOfBillEvents) {
        billEvent.setServiceProvisionNum(ioBillEvent.getServiceProvisionNum());
        billEvent.setServiceDescription(ioBillEvent.getServiceDescription());
        billEvent.setSerProvBilledAmount(ioBillEvent.getSerProvBilledAmount());
        billEvent.setAvgDailySpendAmount(ioBillEvent.getAvgDailySpendAmount());
        billEvent.setPropertyId(ioBillEvent.getPropertyId());
        billEvent.setServiceProvisionNum(ioBillEvent.getServiceProvisionNum());
        billEvent.setSubPeriodStartDate(ioBillEvent.getSubPeriodStartDate());
        billEvent.setSubPeriodEndDate(ioBillEvent.getSubPeriodEndDate());
        billEvent.setSubPeriodDays(ioBillEvent.getSubPeriodDays());
        listOfBillEvents.add(billEvent);
    }

    private void setBillRequest(Bill createBill, IIBSimulateBillRequest billRequest) {
        billRequest.setAccountNumber(new TargetAccountNumber(createBill.getAccountNumber()));
        if (StringUtils.isNotEmpty(createBill.getPropertyId())) {
            billRequest.setPropertyId(Long.valueOf(createBill.getPropertyId()));
        }
        billRequest.setEndDate(createBill.getEndDate());
        billRequest.setFunctionCode(BillConstant.ACTION_SIMULATE);
    }

    private Bill simulateBill(Bill simulateBill, String authToken, ProcessOutcome outcome, boolean multipleAttemptsRequired) {
        IIBSimulateBillRequest createBillRequest = new IIBSimulateBillRequest();
        setBillRequest(simulateBill, createBillRequest);
        LOGGER.debug("Before making call to simulateBill with function code {}", BillConstant.ACTION_SIMULATE);
        // Needs account number, propertyId, endDate and function code X to simulate
        SimulateBillResponseDTO responseDTO = iibSimulateBillClient.simulateBill(createBillRequest, authToken, false, multipleAttemptsRequired);
        IIBSimulateBillResponse response = responseDTO.getIibSimulateBillResponse();
        if (response != null) {
            response = responseDTO.getIibSimulateBillResponse();
            if (response == null) {
                setTargetErrorAsWarningMessage(responseDTO.getTargetError(), BillEnum.SIMULATE_BILL.getErrorMessage(),
                        outcome);
            } else {
                setBillFromResponse(simulateBill, response);
            }

        } else {
            setTargetErrorAsWarningMessage(responseDTO.getTargetError(), BillEnum.SIMULATE_BILL.getErrorMessage(),
                    outcome);
        }
        return simulateBill;
    }

    @Override
    public Bill validate(Bill bill, String authToken, String action)
            throws STWBusinessException, STWTechnicalException {

        throwExceptionIfBillEmpty(bill, action);

        IIBSimulateBillRequest billRequest = new IIBSimulateBillRequest();

        setBillRequest(bill, billRequest);

        List<Property> accountProperties = getAccountProperties(authToken, billRequest);
        if (accountProperties == null || accountProperties.isEmpty()) {
            LOGGER.warn("No Properties found for the account {}", billRequest.getAccountNumber());
            setUpProcessOutcomeList(bill, BillConstant.NO_PROPERTIES_FOUND_FOR_THE_ACCOUNT,
                    BillConstant.NO_PROPERTIES_FOR_ACCOUNT_STEP);
            return bill;
        }

        Property matchingProperty = getMatchingProperty(billRequest, accountProperties);

        if (matchingProperty == null) {
            LOGGER.warn("No matching properties found");
            setUpProcessOutcomeList(bill, BillConstant.NO_MATCHING_PROPERTIES_FOUND,
                    BillConstant.NO_MATCHING_PROPERTIES_STEP);
            return bill;
        }
        if (billRequest.getEndDate() == null) {
            // if no end date passed determine it
            bill = setUpEndDateAndReturnBill(bill, matchingProperty, authToken);
        }

        List<AccountEvent> transactions = getPaymentTransactions(billRequest);

        setUpBillEndDateOrErrorBasedOnTransactions(bill, matchingProperty, transactions, authToken);

        return bill;
    }

    private void setUpBillEndDateOrErrorBasedOnTransactions(Bill bill, Property matchingProperty,
                                                            List<AccountEvent> transactions, String authToken) {
        LOGGER.debug("Transactions available");
        LocalDate latestDate = setUpLatestDate(transactions);
        setUpError(bill, matchingProperty, latestDate, authToken);
    }

    private List<Property> getAccountProperties(String authToken, IIBSimulateBillRequest billRequest) {
        LOGGER.debug("Before getting properties for account number {}", billRequest.getAccountNumber());
        List<Property> accountProperties = propertiesForAccountNumberClient
                .getPropertiesForAccountNumber(billRequest.getAccountNumber(), authToken);
        return accountProperties;
    }

    private Property getMatchingProperty(IIBSimulateBillRequest billRequest, List<Property> accountProperties) {
        LOGGER.debug("Property to match and filtered is property with id {}", billRequest.getPropertyId());
        Property matchingProperty = null;
        Optional<Property> opMatchingProperty = accountProperties.stream()
                .filter(property -> StringUtils.isNotEmpty(property.getPropertyId())
                        && String.valueOf(billRequest.getPropertyId()).equals(property.getPropertyId()))
                .findFirst();
        if (opMatchingProperty.isPresent()) {
            matchingProperty = opMatchingProperty.get();
            LOGGER.debug(
                    "Matching property details are, \n\t PropertyId {}, \n\t Move Out Date {}, \n\t Move In Date {}, \n\t Measured Indicator {}",
                    new Object[]{matchingProperty.getPropertyId(), matchingProperty.getEndDate(),
                            matchingProperty.getStartDate(),
                            matchingProperty.getMeasuredIndicator() != null
                                    ? matchingProperty.getMeasuredIndicator().getCode()
                                    : ""});
        }
        return matchingProperty;
    }

    private List<AccountEvent> getPaymentTransactions(IIBSimulateBillRequest billRequest) {
        LOGGER.debug("Before calling payment transaction service");
        List<AccountEvent> transactions = paymentTransactionsService.getPaymentTransactions(
                billRequest.getAccountNumber(), BillConstant.LAST_TWENTY_FOUR_MONTHS, BillConstant.BILL);
        return transactions;
    }

    private LocalDate setUpLatestDate(List<AccountEvent> transactions) {
        LocalDate latestDate = null;
        if (transactions != null && !transactions.isEmpty()) {
            transactions = transactions.stream()
                    .filter(transaction -> transaction.getBillEndDate() != null
                            && !BillConstant.CANCELLED.equals(transaction.getAccountStatus())
                            && transaction.getAccountEventType() != null
                            && StringUtils.isNotEmpty(transaction.getAccountEventType().getCode())
                            && (transaction.getAccountEventType().getCode().equals(BillConstant.BILLI)
                            || transaction.getAccountEventType().getCode().equals(BillConstant.REBIL)))
                    .collect(Collectors.toList());
            Optional<LocalDate> optionalLatestDate = transactions.stream()
                    .filter(transaction -> transaction.getBillEndDate() != null).map(AccountEvent::getBillEndDate)
                    .max(LocalDate::compareTo);
            if (optionalLatestDate.isPresent()) {
                LOGGER.debug("Latest date is {}", optionalLatestDate);
                latestDate = optionalLatestDate.get();
            }
        }
        return latestDate;
    }

    private void setUpError(Bill bill, Property matchingProperty, LocalDate latestDate, String authToken) {
        if (bill.getEndDate() != null && latestDate != null && !bill.getEndDate().isAfter(latestDate)) {
            LOGGER.debug("Customer already billed until {}. Date selected {} is on or before this date.", latestDate, bill.getEndDate());

            setUpProcessOutcomeList(bill,
                    String.format(BillConstant.BILL_END_DATE_IS_BEFORE_LAST_BILL_DATE,
                            latestDate.format(formatter), bill.getEndDate().format(formatter)),
                    BillConstant.BILL_END_DATE_IS_BEFORE_LAST_BILL_DATE_STEP);
        } else if (matchingProperty.getEndDate() != null && bill.getEndDate() != null
                && bill.getEndDate().isAfter(matchingProperty.getEndDate())) {
            LOGGER.debug("Bill end date {} is after move out date {}", bill.getEndDate(),
                    matchingProperty.getEndDate());
            setUpProcessOutcomeList(bill,
                    String.format(BillConstant.BILL_END_DATE_IS_AFTER_MOVE_OUT_DATE,
                            bill.getEndDate().format(formatter),
                            matchingProperty.getEndDate().format(formatter)),
                    BillConstant.BILL_END_DATE_IS_AFTER_MOVE_OUT_DATE_STEP);
        } else if (bill.getEndDate().isBefore(matchingProperty.getStartDate())) {
            // bill end date should be after matchingProperty start date
            LOGGER.debug("Bill end date {} is before move in date {}", bill.getEndDate(),
                    matchingProperty.getStartDate());
            setUpProcessOutcomeList(bill,
                    String.format(BillConstant.BILL_END_DATE_IS_BEFORE_MOVE_IN_DATE,
                            bill.getEndDate().format(formatter),
                            matchingProperty.getStartDate().format(formatter)),
                    BillConstant.BILL_END_DATE_IS_BEFORE_MOVE_IN_DATE_STEP);
        } else {
            boolean isPropertyMeasured = isPropertyMeasured(matchingProperty);
            // measured and no billable meter read on bill.getEndDate()
            if (isPropertyMeasured) {

                IIBGetMeterReadResponse iibMeterReadResponse = getBillableNotBilledMeterReadOnDate(bill,
                        matchingProperty, bill.getEndDate(), authToken);
                if (iibMeterReadResponse == null) {
                    LOGGER.debug("Is measured and no billable meter read on bill end date {} ", bill.getEndDate());
                    setUpProcessOutcomeList(bill,
                            String.format(BillConstant.NO_BILLABLE_METER_READ_ON_BILL_END_DATE,
                                    bill.getEndDate().format(formatter)),
                            BillConstant.NO_BILLABLE_METER_READ_ON_BILL_END_DATE_STEP);
                }
            }
        }

    }

    private void setUpProcessOutcomeList(Bill bill, String errorDescription, String stepId) {
        ProcessOutcome processOutcome = new ProcessOutcome();
        processOutcome.setErrorDescription(errorDescription);
        processOutcome.setStepId(stepId);
        ProcessOutcomeList processOutComeList = new ProcessOutcomeList();
        processOutComeList.addOutcome(processOutcome);
        bill.setProcessOutcomeList(processOutComeList);
    }

    private Bill setUpEndDateAndReturnBill(Bill bill, Property matchingProperty, String authToken) {
        if (matchingProperty.getMeasuredIndicator() != null) {
            boolean isPropertyUnMeasured = isPropertyUnMeasured(matchingProperty);
            boolean isPropertyMeasured = isPropertyMeasured(matchingProperty);
            boolean isPropertyAssessed = isPropertyAssessed(matchingProperty);

            if (isPropertyUnMeasured) {
                LOGGER.debug("Set up end date for unmeasured property.");
                return endDateSetupService.setUpUnmeasuredAccountEndDate(bill, isPropertyUnMeasured,
                        matchingProperty.getStartDate(), matchingProperty.getEndDate());
            } else if (isPropertyMeasured) {
                LOGGER.debug("Set up end date for measured property.");
                IIBGetMeterReadResponse iibMeterReadResponse = getLastBillableMeterRead(bill, matchingProperty,
                        authToken);
                return endDateSetupService.setUpMeasuredAccountEndDate(bill, isPropertyMeasured,
                        matchingProperty.getStartDate(), matchingProperty.getEndDate(), iibMeterReadResponse);
            } else if (isPropertyAssessed) {
                LOGGER.debug("Set up end date for assessed property.");
                return endDateSetupService.setUpAssessedAccountEndDate(bill, isPropertyAssessed,
                        matchingProperty.getStartDate(), matchingProperty.getEndDate());
            }
        }
        return bill;
    }

    private IIBGetMeterReadResponse getLastBillableMeterRead(Bill bill, Property matchingProperty, String authToken) {
        IIBGetMeterReadResponse iibMeterReadResponse = meterReadService.getLastBillableMeterRead(
                new TargetAccountNumber(bill.getAccountNumber()), matchingProperty.getPropertyId(), authToken);
        return iibMeterReadResponse;
    }

    private IIBGetMeterReadResponse getBillableNotBilledMeterReadOnDate(Bill bill, Property matchingProperty, LocalDate readDate, String authToken) {
        IIBGetMeterReadResponse iibMeterReadResponse = meterReadService.getBillableNotBilledMeterReadOnDate(
                new TargetAccountNumber(bill.getAccountNumber()), matchingProperty.getPropertyId(), readDate, authToken);
        return iibMeterReadResponse;
    }

    private boolean isPropertyUnMeasured(Property matchingProperty) {
        return BillConstant.UNMEASURED.equals(matchingProperty.getMeasuredIndicator().getCode());
    }

    private boolean isPropertyAssessed(Property matchingProperty) {
        return BillConstant.ASSESSED.equals(matchingProperty.getMeasuredIndicator().getCode());
    }

    private boolean isPropertyMeasured(Property matchingProperty) {
        return BillConstant.MEASURED.equals(matchingProperty.getMeasuredIndicator().getCode());
    }

    private void setTargetErrorAsWarningMessage(TargetError targetError, String errorMessage, ProcessOutcome outcome) {
        String warningMessage = String.format(errorMessage, targetError.getReasonText());
        LOGGER.warn(warningMessage);
        outcome.setWarningDescription(warningMessage);
    }

}
