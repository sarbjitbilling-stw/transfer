- run jee server manually (with app deployment):
  
        mvn clean verify --activate-profiles embedded-server

        http://localhost:8091/sbweb/sbservlet
