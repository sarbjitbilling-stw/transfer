package sb;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class SimpleServlet extends HttpServlet {
    String credential = "eyJhbGciOiJSUzI1NiIsImtpZCI6Ijc0ODNhMDg4ZDRmZmMwMDYwOWYwZTIyZjNjMjJkYTVmZTM5MDZjY2MiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2NTUwNDU0NjEsImF1ZCI6IjE1NzA0MjY5NzY4OS10NzljZjg5dHZzOTA0Nmxhbm45Z2lzYnVnYzFhYWtoNC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjExNjk0Nzk4NjAyMzM3NjAwNTQwNyIsImVtYWlsIjoic2FyYmppdC5iaWxsaW5nQHNldmVybnRyZW50LmNvLnVrIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF6cCI6IjE1NzA0MjY5NzY4OS10NzljZjg5dHZzOTA0Nmxhbm45Z2lzYnVnYzFhYWtoNC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsIm5hbWUiOiJzYXJiaml0IGJpbGxpbmciLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUFUWEFKeVFYWjRBVDBtaUVHaHFfOUJsYXFzOVNPN1ljMVBxOTRTajJDTkY9czk2LWMiLCJnaXZlbl9uYW1lIjoic2FyYmppdCIsImZhbWlseV9uYW1lIjoiYmlsbGluZyIsImlhdCI6MTY1NTA0NTc2MSwiZXhwIjoxNjU1MDQ5MzYxLCJqdGkiOiJkZWQ3NGY2MTJlNjE0OTcyZWU2OWM5YzFlM2VmNmM2M2JmNjEzOTk4In0.DMyOSYYLlehxAyttn2jhtqGLZOlpHDutnghYjNQ9XW2j3TwyyNrF9Dg9XCELf56ReEGJFYpVbE96S3hOIHNeGRr7HQQztPISD7Km7dmeEkiOtS7qjN_V_68OAZroxYfv9hanqbqIU55YgLHhGmKu0N2TIcvfGA3MsJjBXy7_DKBsisY-RsuRnmexnWxRxmYU6SGgXcYxL2qvltAvukHxiLttFPxc4BncjsckeCrl3S8iBagd_-B_iXMn_hJaHm7ErVPO9xeRq87-57EJBmUQfOpqhVysKhSqIJ1Vw9uhiGBBYrWouX7MRXTwNL8vGzmlsKUECk2B_uC0kIEy44Oemw";
    String csrfToken = "v1";

    @Override
    public void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws IOException {
        response.setContentType("text/plain");
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        final String message = "server " + request.getServerName() + " said hello world at " + timestamp;
        response.getWriter().println(message);
        System.out.println(message);

        test1();
        test2();
        test3();
    }

    private void test1() {
        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = new GsonFactory();

        //
        // orig
        //
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier(transport, jsonFactory);
        GoogleIdToken idToken;
        try {
            idToken = verifier.verify(credential);
            System.out.println("### test1 idToken is " + idToken);
        } catch (Exception e) {
            System.out.println("### test1 e is " + e);
        }
    }

    private void test2() {
        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = new GsonFactory();

        //
        // as per doc
        //
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(transport, jsonFactory)
                       .setAudience(Arrays.asList("157042697689-t79cf89tvs9046lann9gisbugc1aakh4.apps.googleusercontent.com"))
                       .build();
        GoogleIdToken idToken;
        try {
            idToken = verifier.verify(credential);
            System.out.println("### test2 idToken is " + idToken);
        } catch (Exception e) {
            System.out.println("### test2 e is " + e);
        }
    }

    private void test3() {
        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = new GsonFactory();

        //
        // as per doc
        //
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(transport, jsonFactory)
                .setAudience(Arrays.asList("sarb42697689-t79cf89tvs9046lann9gisbugc1aakh4.apps.googleusercontent.com"))
                .build();
        GoogleIdToken idToken;
        try {
            idToken = verifier.verify(credential);
            System.out.println("### test3 idToken is " + idToken);
        } catch (Exception e) {
            System.out.println("### test3 e is " + e);
        }
    }
}
