
package uk.co.stwater.api.assembly;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

/**
 *
 * @author Mark
 */
public class PropertyFileFixerTest {


    /**
     * Test of unescapeColon method
     */
    @Test
    public void testUnescapeColon() throws Exception {
        String[] testData = {"line1=xxxxx,${env\\:WSS_ENV},yyyyy", "line2=mvn\\:xxxx/yyyy/123,mvn\\:aaaa/bbbb/999", "line3=http\\:host?prame\\=value"};

        Path testPath = Files.createTempFile("testConfig", ".cfg");
        testPath.toFile().deleteOnExit();
        Files.write(testPath, Arrays.asList(testData), StandardCharsets.UTF_8);
  
        PropertyFileFixer.unescapeChars(testPath.toString());
        
        List<String> fileLines = new ArrayList<>(Files.readAllLines(testPath, StandardCharsets.UTF_8));
        assertFalse(fileLines.stream().anyMatch(s -> s.contains("\\:")));
        assertFalse(fileLines.stream().anyMatch(s -> s.contains("\\=")));
    }

}
