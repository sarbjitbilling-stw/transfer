package uk.co.stwater.api.assembly;


import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * work around for incompatibility between karaf-maven-plugin propertyFileEdits & InterpolationConfigurationPlugin
 * where colon gets escaped in output file values i.e. ":" becomes "\:" and "=" becomes "\="
 *
 * @author M Beer
 */
public class PropertyFileFixer {
    private static final Logger log = LoggerFactory.getLogger(PropertyFileFixer.class);

    public static void main(String[] args) throws IOException{
        String configFileName = args[0];
        PropertyFileFixer.unescapeChars(configFileName);
    }
    
    static void unescapeChars(String configFileName) throws IOException{
        log.debug("unescape chars in  file {}", configFileName);
      
        Path path = Paths.get(configFileName);
        List<String> fileLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        List<String> newFileLines = fileLines.stream()
                .map(line -> line.replace("\\:", ":").replace("\\=", "="))
                .collect(Collectors.toList());
        Files.write(path, newFileLines, StandardCharsets.UTF_8);
    }
}
