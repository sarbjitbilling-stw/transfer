package uk.co.stwater.api.osgi.analytics;

import org.drools.core.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.AnalyticsSummary;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Named
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class AnalyticsServiceRest extends AbstractResource {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Inject
	AnalyticsService analyticsService;

	@GET
	@Path("/{analyticsId}")
	public Response getAnalyticsById(@PathParam("analyticsId") String analyticsId, @QueryParam("postcode") String postcode) {
		log.debug("getAnalyticsById start: {}", analyticsId);
		try {
			AnalyticsSummary analytics = analyticsService.getAnalytics(analyticsId, postcode, getUserIdentity().getUsername());
			log.debug("getAnalyticsById returning {} values", analytics.getAnalyticsMap().size());
			return Response.status(Status.OK.getStatusCode()).entity(analytics).build();
		} catch (STWTechnicalException e) {
			log.error(e.getMessage(), e);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		} catch (STWBusinessException ex) {
			log.warn(ex.getMessage());
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.ANALYTICS_SERVICES, Status.BAD_REQUEST.getStatusCode(), ex.getMessage());
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

	@GET
	@Path("/zoneAndDma")
	public Response getZoneAndDmaByPostcode(@QueryParam("postcode") String postcode){
		log.debug("getZoneAndDmaByPostcode start: {}", postcode);

		if(StringUtils.isEmpty(postcode)){
			log.warn("Missing postcode");
			return Response.status(Status.BAD_REQUEST).build();
		}

		try {
			return Response.status(Status.OK.getStatusCode()).entity(analyticsService.getZoneAndDmaByPostcode(postcode)).build();
		} catch (STWTechnicalException e) {
			log.error(e.getMessage(), e);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		} catch (STWBusinessException ex) {
			log.warn(ex.getMessage());
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.ANALYTICS_SERVICES, Status.BAD_REQUEST.getStatusCode(), ex.getMessage());
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

}
