package uk.co.stwater.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.dao.UserAuditDao;
import uk.co.stwater.api.audit.AuditService;
import uk.co.stwater.api.audit.AuditServiceImpl;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.dao.entity.UserAudit;
import uk.co.stwater.api.osgi.model.LoginType;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.WSSAccount;
import uk.co.stwater.api.osgi.model.WSSLegalEntityAccount;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.encryption.EncryptionService;
import uk.co.stwater.api.registration.WSSAccountService;

/**
 * Created by pnayak1 on 09/10/2019.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class AuditServiceImplTest {

    @InjectMocks
    private AuditService auditService = new AuditServiceImpl();

    @Mock
    private UserAuditDao auditDao;
    
    @Mock
    private UserDao userDao;
    
    @Mock
    private WSSAccountService wssAccountService;

    @Mock
    private EncryptionService encryptionService;
    
    private static final  String STW = "STW";
    private static final String LOGIN_JOURNEY = "LOGIN";
    private static final String DEFAULT_SERVER = "";
    private static final String DM = "DM13.1";

  
    @Test
    public void givenUserLoginWithWrongPasswordThenLogTheJourneyInAuditTable() {
        
        UsernamePasswordToken token = new UsernamePasswordToken("90000267", "Password123", LoginType.FULL, STW);
        
        WSSAccount expected = new WSSAccount();
        expected.setId("9999");

        WSSLegalEntityAccount wssLegalEntityAccount = new WSSLegalEntityAccount(new TargetAccountNumber("1234567893"));
        expected.addWssLegalEntityAccounts(wssLegalEntityAccount);

        User user = new User();
        user.setPassword("6a08895250adfe83237e64b904cef4feaed20929286959f402b34011e51af958");
        user.setSite(User.Site.STW);
        user.setId(123l);
        user.setUsername("90000267");   
        
        ArgumentCaptor<UserAudit> argumentCaptor = ArgumentCaptor.forClass(UserAudit.class);
        
        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.of(user));
        when(userDao.findById(eq(Long.valueOf(token.getUsername())))).thenReturn(Optional.of(user));
        when(userDao.findUserByEmailOrUsernameForSiteFilteredByUserRegistrationType(anyString(), anyString())).thenReturn(Optional.of(user));
        when(wssAccountService.getAccountByUsername(anyString(), anyString()))
                .thenReturn(Collections.singletonList(expected));
        when(wssAccountService.isAccountValidForLoginType(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(encryptionService.decrypt(anyString())).thenReturn("Password123");
        
        auditService.audit(token, DM , "Sorry, Invalid password");
       
        verify(auditDao, times(1)).log(argumentCaptor.capture());
        assertEquals(LOGIN_JOURNEY, argumentCaptor.getValue().getJourney());
        assertEquals(DEFAULT_SERVER, argumentCaptor.getValue().getServer());
        assertEquals("DM13.1-Sorry, Invalid password", argumentCaptor.getValue().getDm());
        assertEquals("123", argumentCaptor.getValue().getUserId());
        
    }
    
 }
