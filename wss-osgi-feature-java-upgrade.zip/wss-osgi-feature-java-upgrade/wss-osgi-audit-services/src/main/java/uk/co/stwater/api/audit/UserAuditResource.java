package uk.co.stwater.api.audit;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;

import uk.co.stwater.api.audit.exception.AuditException;
import uk.co.stwater.api.dao.entity.UserAudit;
import uk.co.stwater.api.osgi.util.AbstractResource;

/**
 * RESTful API for Authentication
 *
 * Created by pnayak1 on 30/09/2019.
 */
@Named
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/user")
public class UserAuditResource extends AbstractResource {

    @Inject
    private AuditService auditService;

    @GET
    public Response getUserAudits(@QueryParam("username") String username) {
        if (StringUtils.isBlank(username)) {
            throw new AuditException("username is required");
        }

        List<UserAudit> userAudits = auditService.getUserAudits(username);
        return Response.ok(userAudits).build();
    }

}
