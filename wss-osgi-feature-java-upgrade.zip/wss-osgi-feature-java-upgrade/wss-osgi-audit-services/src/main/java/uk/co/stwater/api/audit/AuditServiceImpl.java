package uk.co.stwater.api.audit;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.NonUniqueResultException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.dao.UserAuditDao;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.dao.entity.UserAudit;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.STWBusinessException;


/**
 * Created by pnayak1 on 03/10/2017.
 */
@Named
@OsgiServiceProvider(classes = {AuditService.class})
public class AuditServiceImpl implements AuditService {

    @Inject
    @OsgiService
    private UserAuditDao auditDao;
    
    @Inject
    @OsgiService
    private UserDao userDao;
    
    Logger log = LoggerFactory.getLogger(this.getClass());
    
    private static final String DEFAULT_SERVER = "";
    private static final String LOGIN_JOURNEY = "LOGIN";
    
    @Override
    public void audit(UsernamePasswordToken usernamePasswordToken, String errorCode, String errorMsg) {
        log.debug("auditing start");
        if(StringUtils.isEmpty(usernamePasswordToken.getUsername())) {
            log.debug("Social login failed due to code {} with message {}.  No username recovered not recorded in user audit.", errorCode, errorMsg);
            return;
        }
        Optional<User> optionalUser;
        try {
            if (NumberUtils.isNumber(usernamePasswordToken.getUsername())) {
                optionalUser = userDao.findById(Long.valueOf(usernamePasswordToken.getUsername()));
            } else {
                optionalUser = userDao.findUserByEmailOrUsernameForSiteFilteredByUserRegistrationType(
                        usernamePasswordToken.getUsername(), usernamePasswordToken.getSite());
            }
        } catch (NonUniqueResultException nue) {
            throw new STWBusinessException("Multiple users found", "DM3.15", ErrorDto.ErrorCategory.AUTH_SERVICES);
        }

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            UserAudit userAudit = new UserAudit();
            userAudit.setUserId(user.getId().toString());
            userAudit.setUsername(usernamePasswordToken.getUsername());
            userAudit.setDate(new Date());
            userAudit.setJourney(LOGIN_JOURNEY + (usernamePasswordToken.isSocialAuth() ? ("_" + usernamePasswordToken.getSocialAuth().getSocialProvider()) : ""));
            userAudit.setDm(errorCode.concat("-").concat(errorMsg));
            userAudit.setOutcome(UserAudit.LoginOutcome.LOGIN_FAILURE);
            userAudit.setServer(DEFAULT_SERVER);
            auditDao.log(userAudit);
        } else {
            log.warn("User not found errorCode={}", errorCode);
            UserAudit userAudit = new UserAudit();
            userAudit.setUsername(usernamePasswordToken.getUsername());
            userAudit.setDate(new Date());
            userAudit.setJourney(LOGIN_JOURNEY);
            userAudit.setDm(errorCode.concat("-").concat(errorMsg));
            userAudit.setOutcome(UserAudit.LoginOutcome.LOGIN_FAILURE);
            userAudit.setServer(DEFAULT_SERVER);
            auditDao.log(userAudit);
        }
    }

    @Override
    public List<UserAudit> getUserAudits(String username) {
        return auditDao.getByUsername(username);
    }

 }
