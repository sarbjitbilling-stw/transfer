package uk.co.stwater.api.audit;

import java.util.List;

import uk.co.stwater.api.dao.entity.UserAudit;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;

public interface AuditService {

    void audit(UsernamePasswordToken usernamePasswordToken, String dmCode, String errorMsg);
    
    List<UserAudit> getUserAudits(String username);

 }
