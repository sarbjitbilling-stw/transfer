package uk.co.stwater.api.osgi.account.contacts;

import java.text.SimpleDateFormat;
import java.util.Date;

import uk.co.stwater.api.osgi.account.bean.AccountWebContactRefDataBean;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class WEB630Contact extends AccountServicesContact implements CustomerContact {

	private static final String WEB630_CONTACT_TYPE = "WEB630";
	
	public WEB630Contact(AccountRoles accountRole, String mainAccountName, String mainAccountEmail, AccountWebContactRefDataBean webContactRefData){
		super(mainAccountName, mainAccountEmail, webContactRefData);
		setRole(accountRole);
	}
	
	@Override
	public String getFormattedNote() {
		Date dNow = new Date( );
		SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy");
		StringBuilder builder = new StringBuilder();
		builder.append(CUSTOMER_NAME_KEY).append(getMainAccountFullName());
		builder.append(NEW_LINE);
		builder.append(RELATIONSHIP_KEY).append(getWebContactRefData().getRelation());
		builder.append(NEW_LINE).append(NEW_LINE);
		builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
		builder.append("Changes have been made to the details for this access registered customer."
				+ " You may need to review their special condition and the services provided.").append(NEW_LINE).append(NEW_LINE);
		builder.append("For details of the change see the contact message of ").append(ft.format(dNow));
		return builder.toString();
	}

	@Override
	public String getContactType() {
		return WEB630_CONTACT_TYPE;
	}

	@Override
	public boolean isSubstantiveResponse() {
		return false;
	}

}