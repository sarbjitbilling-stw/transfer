package uk.co.stwater.api.osgi.account.contacts;

import uk.co.stwater.api.osgi.model.SocialProviderType;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class WEB629LinkSocialContact implements CustomerContact {

	private static final String WEB629_CONTACT_TYPE = "WEB629";
	private SocialProviderType socialProviderType;
	private Action action;
	private ContactDto contactDto;

	public enum Action {
		LINK,
		UNLINK
	}


	public WEB629LinkSocialContact(ContactDto contactDto, SocialProviderType providerType, Action action){
		this.contactDto = contactDto;
		this.socialProviderType = providerType;
		this.action = action;
	}

	@Override
	public TargetAccountNumber getAccountNumber() {
		return contactDto.getAccountNumber();
	}

	@Override
	public String getLegalEntityNumber() {
		return contactDto.getLeId();
	}

	@Override
	public String getPostcode() {
		return null;
	}

	@Override
	public String getFormattedNote() {
		StringBuilder builder = new StringBuilder();
		builder.append(CUSTOMER_NAME_KEY).append(contactDto.getFullName());
		builder.append(NEW_LINE);
		if(action == Action.LINK) {
			builder.append("Customer linked social login provider " + socialProviderType.getDescription() + " to their WSS account.");
		} else {
			builder.append("Customer unlinked social login provider " + socialProviderType.getDescription() + " from their WSS account.");
		}
		return builder.toString();
	}

	@Override
	public String getContactType() {
		return WEB629_CONTACT_TYPE;
	}

	@Override
	public Long getPropertyNumber() {
		return null;
	}

	@Override
	public boolean isSubstantiveResponse() {
		return true;
	}
	
}