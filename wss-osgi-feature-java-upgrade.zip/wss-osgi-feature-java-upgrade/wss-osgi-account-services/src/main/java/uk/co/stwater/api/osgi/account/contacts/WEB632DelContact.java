package uk.co.stwater.api.osgi.account.contacts;

import uk.co.stwater.api.osgi.account.bean.AccountWebContactRefDataBean;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class WEB632DelContact extends AccountServicesContact implements CustomerContact {

	private static final String WEB632_CONTACT_TYPE = "WEB632";

	public WEB632DelContact(AccountRoles accountRole, String mainAccountName, String mainAccountEmail, AccountWebContactRefDataBean webContactRefData){
		super(mainAccountName, mainAccountEmail, webContactRefData);
		setRole(accountRole);
	}

	@Override
	public String getFormattedNote() {
		StringBuilder builder = new StringBuilder();
		builder.append(CUSTOMER_NAME_KEY).append(getMainAccountFullName());
		builder.append(NEW_LINE);
		builder.append(RELATIONSHIP_KEY).append(getWebContactRefData().getRelation());
		builder.append(NEW_LINE).append(NEW_LINE);
		builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
		builder.append("The following customer should be removed from this account:")
			.append(getRole().getFullName()).append(NEW_LINE);
		builder.append("Not completed as TPCS special condition exists on account.").append(NEW_LINE);
		builder.append("Email 'Customer Details Provided' sent to ").append(getMainAccountEmail());
		return builder.toString();
	}

	@Override
	public String getContactType() {
		return WEB632_CONTACT_TYPE;
	}

	@Override
	public boolean isSubstantiveResponse() {
		return false;
	}

}
