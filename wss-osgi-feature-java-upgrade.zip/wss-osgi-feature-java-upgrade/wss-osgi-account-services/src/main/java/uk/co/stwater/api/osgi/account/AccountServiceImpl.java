/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.account;

import static uk.co.stwater.api.osgi.account.AccountServiceRest.validAccountExpands;
import static uk.co.stwater.targetconnector.client.WsDateUtils.toLocalDate;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import javax.ws.rs.core.Response;

import org.apache.commons.collections.Transformer;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.dao.AmiTrialDao;
import uk.co.stwater.api.dao.LegalEntityDao;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.LegalEntity;
import uk.co.stwater.api.dao.entity.SocialLogin;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.email.service.EmailService;
import uk.co.stwater.api.osgi.account.bean.AccountWebContactRefDataBean;
import uk.co.stwater.api.osgi.account.contacts.WEB629Contact;
import uk.co.stwater.api.osgi.account.contacts.WEB629DelContact;
import uk.co.stwater.api.osgi.account.contacts.WEB630Contact;
import uk.co.stwater.api.osgi.account.contacts.WEB631Contact;
import uk.co.stwater.api.osgi.account.contacts.WEB631DelContact;
import uk.co.stwater.api.osgi.account.contacts.WEB632Contact;
import uk.co.stwater.api.osgi.account.contacts.WEB632DelContact;
import uk.co.stwater.api.osgi.customer.CustomerService;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.AccountInfo;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Brand;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SocialProviderType;
import uk.co.stwater.api.osgi.model.SpecialCondition;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.WSSLERegistrationData;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.model.constants.GlobalConstants;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.osgi.model.user.UserLoginMethods;
import uk.co.stwater.api.osgi.util.Expandable;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.api.osgi.util.NotFoundException;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionChannel;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.iib.client.api.accounts.AccountDTO;
import uk.co.stwater.iib.client.api.accounts.GetAccountsForPropertyNumberClient;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.WsDateUtils;
import uk.co.stwater.targetconnector.client.api.accountdetails.AccountDetailsResponse;
import uk.co.stwater.targetconnector.client.api.accountdetails.GetAccountDetsForAccAndPropertyClient;
import uk.co.stwater.targetconnector.client.api.accountinfo.AccountInfoResponse;
import uk.co.stwater.targetconnector.client.api.accountinfo.GetBasicAccountInfoClient;
import uk.co.stwater.targetconnector.client.api.accountroles.AccountRolesResponse;
import uk.co.stwater.targetconnector.client.api.accountroles.ListAccountRolesClient;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;
import uk.co.stwater.targetconnector.client.api.addaccountrole.AccountRoleResp;
import uk.co.stwater.targetconnector.client.api.addaccountrole.AddAccountRoleClient;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;
import uk.co.stwater.targetconnector.client.api.deleteaccountrole.DeleteAccountRoleClient;
import uk.co.stwater.targetconnector.client.api.deleteaccountrole.DeleteAccountRoleRequest;
import uk.co.stwater.targetconnector.client.api.leregistration.GetLEDataForWSSClient;
import uk.co.stwater.targetconnector.client.api.leregistration.LERegistrationData;

/**
 *
 * @author Mark
 */
@Named
@OsgiServiceProvider(classes = {AccountService.class})
public class AccountServiceImpl implements AccountService {

    private static final String INVALID_INPUT_SUPPLIED = "Invalid input supplied: ";
    public static final String FOREIGN__ADDRESS_RETRIEVED = "Foreign Address retrieved";

    Logger log = LoggerFactory.getLogger(this.getClass());

    @OsgiService
    @Inject
    private GetAccountSummaryClient accountSummaryService;

    @OsgiService
    @Inject
    private GetAccountsForPropertyNumberClient accountsForPropertyNumberClient;

    @OsgiService
    @Inject
    private GetAccountDetsForAccAndPropertyClient accountDetsForAccAndPropertyClient;
    
    @Inject
    @OsgiService
    private UserDao userDao;

    @Inject
    @OsgiService
    private LegalEntityDao legalEntityDao;

    @Inject
    @OsgiService
    private ListAccountRolesClient listAccountRolesClient;

    @Inject
    @OsgiService
    private AddAccountRoleClient addAccountRoleClient;

    @Inject
    @OsgiService
    private DeleteAccountRoleClient deleteAccountRoleClient;

    @Inject
    @OsgiService
    private GetLEDataForWSSClient getLEDataForWSSClient;

    @Inject
    @OsgiService
    private CreateContactClient createContactClient;

    @Inject
    @OsgiService
    private CustomerService customerService;

    @Inject
    @OsgiService
    private EmailService emailService;

    @Inject
    @OsgiService
    private SpecialConditionService specialConditionService;

    @Inject
    @OsgiService
    private ReferenceDataService referenceDataService;

    @Inject
    @OsgiService
    private GetBasicAccountInfoClient basicAccountInfoClient;

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberClient;

    @Inject
    @OsgiService
    private AmiTrialDao amiTrialDao;
    
    private static final String INDIVIDUAL_ROLE = "I";
    private static final String EMAIL_0151_REQUEST_SUCCESS = "E15.1";
    private static final String EMAIL_0152_REQUEST_SUCCESS = "E15.2";
    private static final String EMAIL_0153_REQUEST_SUCCESS = "E15.3";

    private static final String MULTIPLE_SUPPLY_ADDRESSES = "Multiple Supply addresses";
    
    private static final String ERROR_DESCRIPTION_FOR_NO_PROPERTY_FOUND_FOR_ACCOUNT_NUMBER = "No property found for the account number %1$s";
    
    private static final String ERROR_CONTACTDTO_NO_LEGAL_ENTITY = "LE missing from contactDto";

    private static final String ERROR_CODE_FOR_NO_PROPERTY_FOUND_FOR_ACCOUNT_NUMBER = "DM1.22";
    
    private static final String MAXIMUM_ROLES_MESSAGE = "Sorry, you aren't able to add more than 4 "+
			"names through your online account. If you want to add another name you can remove names"+
			" from the list or call us on 0345 604 0785";
    
    private static final String MAXIMUM_ROLES_CODE = "DM15.4"; 
    private static final String REVERSED_ACCOUNT= "R";

    @Override
    public Account getAccountSummary(TargetAccountNumber targetAccountNumber, String postcode, long legalEntity, String authToken, Expands... expands) throws STWTechnicalException, STWBusinessException {
        Account account = null;
        log.debug("getAccountSummary start");
        log.debug("Parameters= {} / postcode: {} / LE: {} ", targetAccountNumber, postcode, legalEntity);
        
        List<Expands> expandList = getValidExpands(expands);
        
        try {
        	AccountSummaryResponse accountSummary = null;
        	if(Expandable.hasOptionOrEmptyList(expandList, Expands.summary, Expands.class) || Expandable.hasOptionOrEmptyList(expandList, Expands.property, Expands.class)){
        		accountSummary
                    = accountSummaryService.getAccountSummary(targetAccountNumber, legalEntity);
        	}
        	
        	Property property = null;
        	long onSupplyCount = 0;
        	if(Expandable.hasOptionOrEmptyList(expandList, Expands.property, Expands.class) || Expandable.hasOptionOrEmptyList(expandList, Expands.detail, Expands.class)){
	            List<Property> accountProperties = propertiesForAccountNumberClient
	                    .getPropertiesForAccountNumber(targetAccountNumber, authToken);
	            if (accountProperties != null && accountProperties.isEmpty()) {
	            	STWBusinessException be = new STWBusinessException(String.format(ERROR_DESCRIPTION_FOR_NO_PROPERTY_FOUND_FOR_ACCOUNT_NUMBER,
	                                targetAccountNumber.getAccountNumber()),
	                        ERROR_CODE_FOR_NO_PROPERTY_FOUND_FOR_ACCOUNT_NUMBER, ErrorCategory.ACCOUNT_SERVICES);
	            	log.warn("A business error occurred trying to get account summary: {}", be.getDescription());
	            	throw be;
	            }
                accountProperties = accountProperties.stream()
                        .filter(accountProperty -> accountProperty != null && accountProperty.getStatus() != null
                                && !REVERSED_ACCOUNT.equals(accountProperty.getStatus().getCode()))
                        .collect(Collectors.toList());

                    onSupplyCount = accountProperties.stream()
                       .filter((propertyData) -> propertyData.getSupplyStatus().equals(Property.SupplyStatus.ON_SUPPLY))
                       .count();
                    
                    // get the 1st property in the list as that should be the most relevant
                Comparator<Property> priorityOrder = Collections
                        .reverseOrder(Comparator.comparing(Property::getRelevenceScore)).thenComparing(Comparator
                                .comparing(Property::getEndDate, Comparator.nullsFirst(Comparator.reverseOrder())));
                accountProperties.sort(priorityOrder);
                property = accountProperties.size() > 0 ? accountProperties.get(0) : null;
	            }
        	
            AccountDetailsResponse accountDetails = null;
            if (Expandable.hasOptionOrEmptyList(expandList, Expands.detail, Expands.class) && property != null
                    && property.getPropertyId() != null) {
                accountDetails = accountDetsForAccAndPropertyClient.getAccountDetails(targetAccountNumber,
                        Long.parseLong(property.getPropertyId()));
            }

            //transform the 3 bits of target data into our Account model object
            account = AccountTransformers.SOAP_RESPONSE_TO_ACCOUNT.apply(accountSummary, accountDetails, property);

            //if there were multiple properties we need to 'override' the property selection at the Account level
            if(onSupplyCount > 1){
                account.setSupplyStatus(Property.SupplyStatus.MULTIPLE);
                account.setServAddress(MULTIPLE_SUPPLY_ADDRESSES);
            }
           
            if(Expandable.hasOptionOrEmptyList(expandList, Expands.registration, Expands.class)){
	            LERegistrationData leRegData = getLEDataForWSSClient.getLEData(targetAccountNumber, legalEntity);
	            if (leRegData != null) {
	                account.setLeRegistrationData(toWssleRegistrationData(leRegData));
	            }
            }

            if(Expandable.hasOptionOrEmptyList(expandList, Expands.roles, Expands.class)){
	            List<AccountRoles> accountRoles = getAccountRoles(targetAccountNumber);
	            account.setAccountRoles(accountRoles);
            }

            if(Expandable.hasOptionOrEmptyList(expandList, Expands.basicInfo, Expands.class)){
	            AccountInfoResponse accountInfoResponse = basicAccountInfoClient.getAccountInfo(targetAccountNumber);
	            if (accountInfoResponse != null) {
	                account.setAccountStartDate(toLocalDate(accountInfoResponse.getAccountCreateDt()));
	            }
            }
        } catch (STWBusinessException stwBe)   {
            //special case GetAccountDetsForAccAndProperty returns error for Foreign addresses
            //the service call needs to be changed in target or a diffrent Target service used
            //until then we will return an known error DM1.28
            if (stwBe.getErrorCode().equals("99999") && stwBe.getDescription().endsWith(FOREIGN__ADDRESS_RETRIEVED)){
                throw new STWBusinessException(FOREIGN__ADDRESS_RETRIEVED, "DM1.28", ErrorCategory.TARGET);
            } else {
                throw stwBe;
            }
        } catch (IllegalArgumentException e) {
            String msg = INVALID_INPUT_SUPPLIED;
            log.error(e.getMessage(), e);
            throw new STWBusinessException(msg, e);
        }
        log.debug("getAccountSummary end");
       return account;
    }

    private List<Expands> getValidExpands(Expands[] expands) {
        //remove any Expands not supported by the Account service
        List<Expands> expandList = Arrays.asList(expands).stream().filter(ex -> validAccountExpands.contains(ex)).collect(Collectors.toList());
        return expandList;
    }
    
    private WSSLERegistrationData toWssleRegistrationData(LERegistrationData regData) {
        WSSLERegistrationData wssRegData = new WSSLERegistrationData();
        wssRegData.setWssPaperlessBillFlag(regData.isPaperlessBilling());
        wssRegData.setWssPaperlessBillFlagTmstmp(regData.getWssPaperlessBillFlagTmstmp());
        wssRegData.setWssRegFlag(regData.isWssRegistered());
        wssRegData.setWssRegFlagTmstmp(regData.getWssRegFlagTmstmp());
        return wssRegData;
    }

    @Override
    public String getEmailAddressForLegalEntity(String legalEntityNumber) {
        String email = null;
        List<LegalEntity> legalEntities = legalEntityDao.findLegalEntityByLegalEntityNumber(legalEntityNumber);
        for (LegalEntity le : legalEntities) {
            if (le.getUser() != null) {
                email = le.getUser().getEmail();
            }
        }
        return email;
    }

    /**
     * Get WSS login methods for all users linked to {@code accountNumber} and
     * {@code legalEntityNo}.
     * 
     * <p>
     * Returns a list as there can be multiple {@link User}s for an
     * {@code accountNumber} and {@code legalEntityNo} combination. Each
     * {@link UserLoginMethods} returned contains the available login options for one
     * {@code User}. In almost all cases (except ~6,000) this will return a list of
     * one element.
     */
    @Override
    public List<UserLoginMethods> getLoginMethods(TargetAccountNumber accountNumber, String legalEntityNo) {
        List<User> users = userDao.findUsersByLegalEntityIdAndAccountNumber(legalEntityNo, accountNumber);
        // @formatter:off
        return users.stream()
                .map(this::getUserLoginMethods)
                .collect(Collectors.toList());
        // @formatter:on
    }

    private UserLoginMethods getUserLoginMethods(User user) {
        Set<SocialProviderType> socialLoginProviders;
        if (user.getSocialLogins() != null) {
            // @formatter:off
            socialLoginProviders = user.getSocialLogins().stream()
                    .map(SocialLogin::getProvider)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());
            // @formatter:on
        } else {
            socialLoginProviders = Collections.emptySet();
        }
        // don't want to show username for EAUN (email as username) registration type
        // as they have auto generated usernames
        String username = User.EAUN.equals(user.getRegistrationType()) ? null : user.getUsername();

        return new UserLoginMethods(username, user.getEmail(), socialLoginProviders);
    }

    @Override
    public List<AccountRoles> getAccountRoles(TargetAccountNumber accountId, Expands... expands) throws STWTechnicalException, STWBusinessException {
    	log.debug("getAccountRoles start : accountId:{}", accountId);
       
        List<Expands> expandList = getValidExpands(expands);
       
        List<AccountRolesResponse> accountRolesResponse = listAccountRolesClient.getAccountRoles(accountId);
        List<AccountRoles> accountRoles = new ArrayList<>();
        for (AccountRolesResponse acRole : accountRolesResponse) {
            AccountRoles accountRole = (AccountRoles) AccountTransformers.SOAP_RESPONSE_TO_ACCOUNT_ROLES_ENTITY.transform(acRole);
            accountRole.setAccountNumber(accountId);
            if(Expandable.hasOption(expandList, Expands.roledetail, Expands.class)){
                log.debug("customer expand given - adding customer");
                Optional<Customer> opCustomer = customerService.getLegalEntity(accountRole.getLeNum());
                opCustomer.ifPresent((cust) -> accountRole.setCustomer(cust));
            }
            accountRoles.add(accountRole);
            log.debug("RoleNum: {} / RoleType: {}",accountRole.getCustAccountRoleNum(), accountRole.getCustAccountRoleType());
        }

    	log.debug("getAccountRoles end");
        return accountRoles;
    }

    @Override
    public AccountRoles addRoleToAccount(AccountRoles accountRole, String authToken, Optional<ContactDto> contactDto) throws STWTechnicalException, STWBusinessException {
        try {
        	log.trace("addRoleToAccount start");
        	log.debug("AccountRole:{}", accountRole);
        	contactDto.ifPresent(contact->log.debug(contact.toString()));
        	
        	String fullAccountNumber = accountRole.getAccountNumber().getAccountNumberWithCheckDigit();
        	// I check if more than 4 contacts are trying tobe added once again
        	List<AccountRoles> currentRoleList = getAccountRoles(accountRole.getAccountNumber());
        	if(currentRoleList != null && !currentRoleList.isEmpty() && currentRoleList.size()>=4){
        		throw new STWBusinessException(MAXIMUM_ROLES_MESSAGE, MAXIMUM_ROLES_CODE, ErrorCategory.ACCOUNT_SERVICES);
        	}
        	String currentLeId = (contactDto.isPresent())?contactDto.get().getLeId():ERROR_CONTACTDTO_NO_LEGAL_ENTITY;
        	AccountWebContactRefDataBean webContactRefData = getRefDataDescriptions(getRoleType(contactDto.get()), accountRole, authToken);
            List<SpecialCondition> fullRestrictions = specialConditionService.getSpecialConditions(accountRole.getAccountNumber(), accountRole.getCustAccountRoleNum());
            log.trace("The complete list of restrictions that apply to LE {} running the process with account {} have been retrieved!", currentLeId, fullAccountNumber);
            log.trace("Checking {} restrictions to add a new name to account {} by LE {}", 
            		SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION.getName(), fullAccountNumber, currentLeId);

            List<SpecialConditionRestriction> type2Restrictions = specialConditionService.checkSpecialConditions(fullRestrictions, 
            		SpecialConditionChannel.WSS, SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION);
            if(type2Restrictions != null && !type2Restrictions.isEmpty()){
            	log.debug("{} restrictions apply to LE {} when adding a new name to account {}",
                		SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION.getName(), currentLeId, fullAccountNumber);
                WEB632Contact contact632 = new WEB632Contact(accountRole, contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
                createContactClient.createContact(contact632);
                log.info("WebContact 632 created while adding a name to account {}", fullAccountNumber);
                sendEmail014Content(contactDto.get(), accountRole.getAccountNumber(), String.valueOf(accountRole.getLeNum()));
                log.info("Email 014 (E15.1) sent when adding a new LE to account {} by LE {}", fullAccountNumber, currentLeId);
                return new AccountRoles();
            }else{
            	log.info("No {} restrictions apply to LE {} when adding a new name to account {}",
            		SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION.getName(), currentLeId, fullAccountNumber);
	            AccountRoleResp accountRolesResp = addAccountRoleClient.addAccountRole(accountRole, accountRole.getAccountNumber());
	            Transformer t = AccountTransformers.SOAP_RESPONSE_TO_ACCOUNT_ROLES_RESP_ENTITY;
	            AccountRoles returnedAccountRole = (AccountRoles) t.transform(accountRolesResp);
	            returnedAccountRole.setAccountNumber(accountRole.getAccountNumber());
	
	            WEB629Contact contact629 = new WEB629Contact(accountRole, GlobalConstants.ADD_ROLE_REASON, contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
	            createContactClient.createContact(contact629);
	            log.info("WebContact 629 created while adding a name to account {}", fullAccountNumber);
	            sendEmail016Content(contactDto.get(), accountRole.getAccountNumber(), String.valueOf(accountRole.getLeNum()));
	            log.info("Email 016 (E15.2) sent when adding a new LE to account {} by LE {}", fullAccountNumber, currentLeId);

	            log.trace("Checking {} restrictions after adding name with LE {} to account {} by LE {}", 
		            	SpecialConditionAction.MANAGE_NAMES_TYPE3_SPECIAL_CONDITION_ACTION.getName(), returnedAccountRole.getLeNum(), 
		            	fullAccountNumber, currentLeId);
	            List<SpecialConditionRestriction> type3Restrictions = specialConditionService.checkSpecialConditions(fullRestrictions, 
	            		SpecialConditionChannel.WSS, SpecialConditionAction.MANAGE_NAMES_TYPE3_SPECIAL_CONDITION_ACTION);
	            if(type3Restrictions != null && !type3Restrictions.isEmpty()){
	                WEB630Contact contact630 = new WEB630Contact(accountRole, contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
	                createContactClient.createContact(contact630);
	                log.info("WebContact 630 created after adding name with LE {} to account {} by LE {} due to {} restrictions", 
	                		returnedAccountRole.getLeNum(), fullAccountNumber, 
	                		currentLeId, SpecialConditionAction.MANAGE_NAMES_TYPE3_SPECIAL_CONDITION_ACTION.getName());
	            }
	           	log.debug("addRoleToAccount end");
	           	return returnedAccountRole;
            }
        } catch (STWTechnicalException technicalException) {
            log.info("A technical error occurred while attempting to add a role to the account", technicalException);
        	generateAddRoleContactAndMail(accountRole, authToken, technicalException, contactDto);
        	throw technicalException;
        } catch (STWBusinessException businessException) {
            log.warn("A business error occurred while attempting to add a role to the account", businessException);
        	generateAddRoleContactAndMail(accountRole, authToken, businessException, contactDto);
        	throw businessException;
        } catch (Exception e) {
            log.error("An error occurred while attempting to add a role to the account", e);
            generateAddRoleContactAndMail(accountRole, authToken, e, contactDto);
            if (e instanceof NotFoundException) {
                throw new NotFoundException(e.getMessage());
            }
            throw e;
        }
    }

    private void generateAddRoleContactAndMail(AccountRoles accountRole, String authToken, Exception e, Optional<ContactDto> contactDto) {
        if (!contactDto.isPresent()) {
            throw new STWTechnicalException(
                    "Unable to generate add role contact and mail, as contactDto is not present");
        }

        AccountWebContactRefDataBean webContactRefData = getRefDataDescriptions(getRoleType(contactDto.get()), accountRole, authToken);
        WEB631Contact contact631 = new WEB631Contact(accountRole, GlobalConstants.ADD_ROLE_REASON, e.getLocalizedMessage(), contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
        createContactClient.createContact(contact631);
		log.info("WebContact 631 created while adding a name to account {}", accountRole.getAccountNumber().getAccountNumberWithCheckDigit());
        sendEmail014Content(contactDto.get(), accountRole.getAccountNumber(), String.valueOf(accountRole.getLeNum()));
        log.info("Email 014 (E15.1) sent when adding a new LE to account {} by LE {}", 
            	accountRole.getAccountNumber().getAccountNumberWithCheckDigit(), contactDto.get().getLeId());
    }
    
    private AccountWebContactRefDataBean getRefDataDescriptions(String custAccountRoleType, AccountRoles accountRole, String authToken) {
        AccountWebContactRefDataBean refData = new AccountWebContactRefDataBean();
        String relationDesc = referenceDataService.getRefDataDesc(RefDataType.ACCOUNT_ROLE, custAccountRoleType, authToken);
        String preferedTelNumIndDesc = referenceDataService.getRefDataDesc(RefDataType.TELEPHONE_LOCATION, accountRole.getPrefTelNumInd(), authToken);
        String bankStatusDesc = referenceDataService.getRefDataDesc(RefDataType.BANK_ACCOUNT_STATUS, accountRole.getLeBankStatus(), authToken);
        String empStatusDesc = referenceDataService.getRefDataDesc(RefDataType.EMPLOYMENT_STATUS, accountRole.getEmploymStat(), authToken);
        String homeOwnStatusDesc = referenceDataService.getRefDataDesc(RefDataType.HOME_OWNERSHIP_STATUS, accountRole.getHomeOwnStat(), authToken);
        refData.setRelation(relationDesc);
        refData.setPreferedTelNumInd(preferedTelNumIndDesc);
        refData.setBankStatus(bankStatusDesc);
        refData.setEmplStatus(empStatusDesc);
        refData.setHomeOwnStatus(homeOwnStatusDesc);
        return refData;
    }

    private void sendEmail014Content(ContactDto contactDto, TargetAccountNumber accountNumber, String leNumber) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put("${fullName}", contactDto.getFullName());
        fieldData.put("${four_digits_accNum}", accountNumber.getAccountNumberWithCheckDigit());
        emailService.mailMergeAndSend(EMAIL_0151_REQUEST_SUCCESS, fieldData, contactDto.getEmail(), accountNumber, leNumber);
    }

    private void sendEmail016Content(ContactDto contactDto, TargetAccountNumber accountNumber, String leNumber) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put("${fullName}", contactDto.getFullName());
        fieldData.put("${four_digits_accNum}", accountNumber.getAccountNumberWithCheckDigit());
        emailService.mailMergeAndSend(EMAIL_0152_REQUEST_SUCCESS, fieldData, contactDto.getEmail(), accountNumber, leNumber);
    }

    @Override
    @Transactional
    public Boolean deleteAccountRole(Long roleId, TargetAccountNumber targetAccountNum, Long leNum, String authToken, Optional<ContactDto> contactDto) throws NotFoundException, STWTechnicalException {
        AccountRoles role = null;
        
        log.debug("deleteAccountRole start");
        log.debug("roleId:{} / {} / LE:{}", roleId, targetAccountNum, leNum);
        if (contactDto.isPresent() && log.isDebugEnabled()) {
            log.debug(contactDto.get().toString());
        } else {
            throw new STWTechnicalException("contactDto is not present");
        }
       
        List<AccountRolesResponse> accountRoles = null;
        try {
        	String fullAccountNumber = targetAccountNum.getAccountNumberWithCheckDigit();
        	String currentLeId = contactDto.get().getLeId();
        	log.trace("Retrieving all the LEs in the account in order to obtain the one with primary role in the account {} and the one with "
        			+ "LE {} who is executing the operation", fullAccountNumber, leNum);
            accountRoles = listAccountRolesClient.getAccountRoles(targetAccountNum);

            Optional<AccountRolesResponse> accountRole = accountRoles.stream().filter(fRole -> roleId.equals(fRole.getLENum())).findFirst();
            if (!accountRole.isPresent()) {
                throw new NotFoundException("Role to be deleted not found");
            }
            AccountRolesResponse rolesResp = accountRole.get();

            log.trace("Role identifier provided to identify the name to be deleted was found in target!");
            Account account = getAccountSummary(targetAccountNum, GlobalConstants.UNKNOWN_POSTCODE, roleId, authToken);
            role = getAccountRole(account, roleId);
            if (role == null) {
                log.error("Unable to find role {} for account {}", roleId, account.getAccountNumber());
                throw new STWTechnicalException("Unable to find account role");
            }
            role.setLeType(INDIVIDUAL_ROLE);
            
            log.trace("Complete data of the name to be deleted recovered from target");
            AccountWebContactRefDataBean webContactRefData = getRefDataDescriptions(getRoleType(contactDto.get()), role, authToken);
            List<SpecialCondition> fullRestrictions = specialConditionService.getSpecialConditions(targetAccountNum, role.getLeNum());
            log.trace("The complete list of restrictions that apply to LE {} running the process with account {} have been retrieved!",
            		currentLeId, fullAccountNumber);
            log.trace("Checking {} restrictions to remove a name from account {} by LE {}", 
            	SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION.getName(), fullAccountNumber, currentLeId);
            List<SpecialConditionRestriction> type2Restrictions = specialConditionService.checkSpecialConditions(fullRestrictions, 
            		SpecialConditionChannel.WSS, SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION);
            if(type2Restrictions != null && !type2Restrictions.isEmpty()){
				log.debug("{} restrictions apply to LE {} when removing a name from account {}",
					SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION.getName(), currentLeId, fullAccountNumber);
                WEB632DelContact contact632 = new WEB632DelContact(role, contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
                createContactClient.createContact(contact632);
                log.info("WebContact 632 created while removing LE {} from account {}", role.getLeNum(), fullAccountNumber);
                sendEmail014Content(contactDto.get(), role.getAccountNumber(), String.valueOf(role.getLeNum()));
                log.info("Email 014 (E15.1) sent when removing LE {} from account {} by LE {}", role.getLeNum(), fullAccountNumber, currentLeId);
                return false;
            }else{
            	log.info("No {} restrictions apply to LE {} when removing a name from account {}",
            		SpecialConditionAction.MANAGE_NAMES_TYPE2_SPECIAL_CONDITION_ACTION.getName(), 
            		currentLeId, fullAccountNumber);
	            // Move the code of check special conditions type3 up here because of technical issue
	            // We must check this after deletion is completed, but special conditions will not be
	            // checked if the role is deleted as special conditions can not find it
	            // So I just move the call to get the result before the deletion of the role
	            // even though the check is done afterwards.
	            List<SpecialConditionRestriction> type3Restrictions = specialConditionService.checkSpecialConditions(fullRestrictions, 
	            		SpecialConditionChannel.WSS, SpecialConditionAction.MANAGE_NAMES_TYPE3_SPECIAL_CONDITION_ACTION);
	
	            DeleteAccountRoleRequest deleteAccountRoleRequest = new DeleteAccountRoleRequest();
	            deleteAccountRoleRequest.setAccountNum(targetAccountNum);
	            deleteAccountRoleRequest.setCustAccountRoleNum(rolesResp.getCustAccountRoleNum());
	            deleteAccountRoleRequest.setCustAccountRoleType(rolesResp.getCustAccountRoleType());
	            deleteAccountRoleRequest.setLeNum(rolesResp.getLENum());
	            if (rolesResp.getStartDate() != null) {
	                deleteAccountRoleRequest.setStartDate(WsDateUtils.toYyyyMMDdXmlDate(rolesResp.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
	            }
	            deleteAccountRoleRequest.setDebtActivityType(rolesResp.getDebtActivityType());
	            if (rolesResp.getResponsibilityCeaseDate() != null) {
	                deleteAccountRoleRequest.setResponsibilityCeaseDate(WsDateUtils.toYyyyMMDdXmlDate(rolesResp.getResponsibilityCeaseDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
	            } else {
	                Calendar today = Calendar.getInstance();
	                Calendar roleCreationDate = Calendar.getInstance();
	                roleCreationDate.setTime(rolesResp.getStartDate());
	                if (today.get(Calendar.YEAR) == roleCreationDate.get(Calendar.YEAR)
	                        && today.get(Calendar.DAY_OF_YEAR) == roleCreationDate.get(Calendar.DAY_OF_YEAR)) {
	                    deleteAccountRoleRequest.setResponsibilityCeaseDate(WsDateUtils.toYyyyMMDdXmlDate(today.getTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
	                } else {
	                    // Use yesterday as the date
	                    Calendar yesterday = Calendar.getInstance();
	                    yesterday.add(Calendar.DATE, -1);
	                    deleteAccountRoleRequest.setResponsibilityCeaseDate(WsDateUtils.toYyyyMMDdXmlDate(yesterday.getTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
	                }
	            }
	
	            deleteAccountRoleRequest.setBillCopiesNum(rolesResp.getBillCopiesNum());
	            deleteAccountRoleRequest.setAcceptInsertsFlag(rolesResp.getAcceptInsertsFlag());
	            deleteAccountRoleRequest.setPrintRole(rolesResp.getPrintRole());
	            deleteAccountRoleRequest.setCyclicConcurrencyCheckNum(rolesResp.getCyclicConcurrencyCheckNum());
	            deleteAccountRoleRequest.setLeResponsibilityRoleNum(rolesResp.getLEResponsibilityRoleNum());
	            deleteAccountRoleRequest.setPriorityRequiredFlag(rolesResp.getPriorityRequiredFlag());
	            deleteAccountRoleRequest.setRequestorRelation(rolesResp.getRequestorRelation());
	            if (rolesResp.getDocReceivedDate() != null) {
	                deleteAccountRoleRequest.setDocReceivedDate(WsDateUtils.toYyyyMMDdXmlDate(rolesResp.getDocReceivedDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
	            }
	
	            deleteAccountRoleClient.deleteAccountRole(deleteAccountRoleRequest, targetAccountNum);
	            log.info("Role with LE {} removed successfully from account {} in target by LE {}", rolesResp.getLENum(), fullAccountNumber, currentLeId);
	
	            WEB629DelContact contact629 = new WEB629DelContact(role, contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
	            createContactClient.createContact(contact629);
				log.info("WebContact 629 created while removing name with LE {} from account {}", rolesResp.getLENum(), fullAccountNumber);
	            sendEmail037Content(targetAccountNum, contactDto.get(), role.getAccountNumber(), String.valueOf(role.getLeNum()));
	            log.info("Email 037 (E15.3) sent when removing LE {} to account {} by LE {}", role.getLeNum(), fullAccountNumber, currentLeId);
	            log.trace("Checking {} restrictions while removing name with LE {} from account {} by LE {}", 
	            	SpecialConditionAction.MANAGE_NAMES_TYPE3_SPECIAL_CONDITION_ACTION.getName(), rolesResp.getLENum(), fullAccountNumber, currentLeId);
	            if(type3Restrictions != null && !type3Restrictions.isEmpty()) {
	                WEB630Contact contact630 = new WEB630Contact(role, contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
	                createContactClient.createContact(contact630);
	                log.info("WebContact 630 created after removing name with LE {} from account {} by LE {} due to {} restrictions", 
	                		rolesResp.getLENum(), fullAccountNumber, currentLeId, SpecialConditionAction.MANAGE_NAMES_TYPE3_SPECIAL_CONDITION_ACTION.getName());
	            }
	            log.debug("deleteAccountRole end");
	            return true;
            }
        } catch (STWTechnicalException technicalException) {
            log.error("A technical error occurred while attempting to delete a role to the account",
                    technicalException);
        	generateDeleteRoleContactAndMail(accountRoles, targetAccountNum, role, leNum, technicalException, authToken, contactDto);
        	throw technicalException;
        } catch (STWBusinessException businessException) {
            log.warn("A business error occurred while attempting to add a role to the account", businessException);
        	generateDeleteRoleContactAndMail(accountRoles, targetAccountNum, role, leNum, businessException, authToken, contactDto);
        	throw businessException;
        } catch (Exception e) {
            log.error("An error occurred while attempting to add a role to the account", e);
        	generateDeleteRoleContactAndMail(accountRoles, targetAccountNum, role, leNum, e, authToken, contactDto);
        	if (e instanceof NotFoundException) {
                throw new NotFoundException(e.getMessage());
            }
        	throw e;
        }
    }

    private void generateDeleteRoleContactAndMail(List<AccountRolesResponse> accountRoles, TargetAccountNumber targetAccountNum, AccountRoles role, Long leNum, Exception ex, String authToken, Optional<ContactDto> contactDto){
        if (!contactDto.isPresent()) {
            throw new STWTechnicalException(
                    "Unable to generate delete role contact and mail, as contactDto is not present");
        }
        AccountWebContactRefDataBean webContactRefData = getRefDataDescriptions(getRoleType(contactDto.get()), role, authToken);
        WEB631DelContact contact631 = new WEB631DelContact(role, GlobalConstants.DELETE_ROLE_REASON, ex.getLocalizedMessage(), contactDto.get().getFullName(), contactDto.get().getEmail(), webContactRefData);
        createContactClient.createContact(contact631);
        log.info("WebContact 631 created while removing name with LE {} from account {}", role.getLeNum(), targetAccountNum.getAccountNumberWithCheckDigit());
        sendEmail014Content(contactDto.get(), role.getAccountNumber(), String.valueOf(role.getLeNum()));
        log.info("Email 014 (E15.1) sent when removing LE {} from account {} by LE {}", 
        	role.getLeNum(), targetAccountNum.getAccountNumberWithCheckDigit(), contactDto.get().getLeId());
    }

    private AccountRoles getAccountRole(Account account, Long roleId) {
        AccountRoles selRole = null;
        if (account != null) {
            for (AccountRoles role : account.getAccountRoles()) {
                if (role.getLeNum() == roleId) {
                    selRole = role;
                    selRole.setAccountNumber(account.getAccountNumber());
                    break;
                }
            }
        }
        return selRole;
    }

    private void sendEmail037Content(TargetAccountNumber deletedAccountNumber, ContactDto contactDto, TargetAccountNumber accountNumber, String leNumber) {

        Map<String, String> fieldData = new HashMap<>();
        fieldData.put("${fullName}", contactDto.getFullName());
        fieldData.put("${four_digits_accNum}", deletedAccountNumber.getAccountNumberWithCheckDigit());
        emailService.mailMergeAndSend(EMAIL_0153_REQUEST_SUCCESS, fieldData, contactDto.getEmail(), accountNumber, leNumber);
    }

    /* Accounts by propertyId*/
    @Override
    public List<AccountInfo> getAccountsByPropertyNumber(String propertyId)
            throws STWTechnicalException, STWBusinessException {
        try {
            AccountDTO accountInfoResponse = new AccountDTO();
            List<AccountInfo> accountInfoList = new ArrayList<>();
            String newPaginationKey = null;

            accountInfoResponse = accountsForPropertyNumberClient.getAccountsForPropertyNumberClient(propertyId, newPaginationKey);
            accountInfoList = accountInfoResponse.getAccountInfo();
            newPaginationKey = accountInfoResponse.getPaginationKey();
            while (newPaginationKey != null) {
                accountInfoResponse = accountsForPropertyNumberClient.getAccountsForPropertyNumberClient(propertyId, newPaginationKey);
                accountInfoList.addAll(accountInfoResponse.getAccountInfo());
                newPaginationKey = accountInfoResponse.getPaginationKey();
            }
            return accountInfoList;
        } catch (Exception ex) {
            throw new STWTechnicalException("Get Accounts By Property number failed", ex);
        }

    }

    @Override
    public List<Property> getPropertiesByAccountNumber(TargetAccountNumber accountNumber, String authToken) throws STWTechnicalException, STWBusinessException {
        List<Property> accountProperties = propertiesForAccountNumberClient.getPropertiesForAccountNumber(accountNumber, authToken);
        return accountProperties;
    }
    
    private String getRoleType(ContactDto contactDto){
        List<AccountRolesResponse> rolesList = listAccountRolesClient.getAccountRoles(contactDto.getAccountNumber());
        Optional<AccountRolesResponse> optionalSelectedRole = rolesList.stream()
                //only look at roles for this LE
                .filter((accountRolesResponse)-> accountRolesResponse.getLENum()== Long.parseLong(contactDto.getLeId()))
                //only get roles that have started & not ended
                .filter((accountRolesResponse) -> {
                    return accountRolesResponse.getResponsibilityCeaseDate() == null  && 
                           accountRolesResponse.getStartDate().before(new Date()); })
                //get the 1st one there can only be one
                .findFirst();

        // an exception should not be possible here if calling from WSS
        AccountRolesResponse selectedRole = optionalSelectedRole.orElseThrow(() ->
                new STWBusinessException("User has no vaild roles ", Response.Status.BAD_REQUEST));

        return selectedRole.getCustAccountRoleType();
    }

	@Override
	public Brand getBrandByAccount(TargetAccountNumber targetAccount, String authToken) {
		log.debug("GET getAccountByBrand start");
		Brand brand = propertiesForAccountNumberClient.getBrandForAccount(targetAccount, authToken);
		log.debug("retrieved brand {}", brand.getAccountBrand());
		log.debug("GET getAccountByBrand end");
		return brand;
	}
	
	@Override
	public AccountBrand getAccountBrandForAccount(TargetAccountNumber accountNumber) {
		log.debug("GET getAccountByBrand start");
		AccountBrand accountBrand = propertiesForAccountNumberClient.getAccountBrandForAccount(accountNumber);
		log.debug("retrieved brand {}", accountBrand);
		log.debug("GET getAccountByBrand end");
		return accountBrand;
	}
	
    
    
}
