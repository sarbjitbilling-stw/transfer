package uk.co.stwater.api.osgi.account.contacts;

import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;

import uk.co.stwater.api.osgi.account.bean.AccountWebContactRefDataBean;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.RoleType;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.constants.WebContactConstants;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public abstract class AccountServicesContact implements CustomerContact{

	private String postcode;
	private AccountRoles role;
	private String reason;
	private Customer customer;
	private String failureDetail;
	private String mainAccountFullName;
	private String mainAccountRel;
	private String mainAccountEmail;
	private AccountWebContactRefDataBean webContactRefData;
	
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	
	private final static String TABULATION = "%-50s";
	
	public AccountServicesContact(String mainAccountName, String mainAccountEmail, AccountWebContactRefDataBean webContactRefData) {
		setWebContactRefData(webContactRefData);
		setMainAccountFullName(mainAccountName);
		setMainAccountEmail(mainAccountEmail);
	}
	
	public AccountServicesContact(String mainAccountName, String mainAccountRel, String mainAccountEmail) {
		setMainAccountFullName(mainAccountName);
		setMainAccountRel(mainAccountRel);
		setMainAccountEmail(mainAccountEmail);
	}
	
	@Override
	public TargetAccountNumber getAccountNumber() {
		return role.getAccountNumber();
	}

	@Override
	public String getLegalEntityNumber() {
		return String.valueOf(role.getCustAccountRoleNum());
	}

	@Override
	public String getPostcode() {
		return postcode;
	}

	public AccountRoles getRole() {
		return role;
	}

	public void setRole(AccountRoles role) {
		this.role = role;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getFailureDetail(){
		return failureDetail;
	}
	
	public void setFailureDetail(String failureDetail) {
		this.failureDetail = failureDetail;
	}

	@Override
	public Long getPropertyNumber() {
		return null;
	}

	public String getMainAccountFullName() {
		return mainAccountFullName;
	}

	public void setMainAccountFullName(String mainAccountFullName) {
		this.mainAccountFullName = mainAccountFullName;
	}

	public String getMainAccountRel() {
		return mainAccountRel;
	}

	public void setMainAccountRel(String mainAccountRel) {
		this.mainAccountRel = mainAccountRel;
	}

	public String getMainAccountEmail() {
		return mainAccountEmail;
	}

	public void setMainAccountEmail(String mainAccountEmail) {
		this.mainAccountEmail = mainAccountEmail;
	}

	public AccountWebContactRefDataBean getWebContactRefData() {
		return webContactRefData;
	}

	public void setWebContactRefData(AccountWebContactRefDataBean webContactRefData) {
		this.webContactRefData = webContactRefData;
	}

	protected StringBuilder addPropertiesTable(StringBuilder builder) {
		builder.append(String.format(TABULATION, WebContactConstants.ITEM));
		builder.append(String.format(TABULATION, ""));
		builder.append(NEW_LINE);
		
		builder.append(String.format(TABULATION, WebContactConstants.TITLE));
		builder.append(String.format(TABULATION, role.getLeTitleDesc()));
		builder.append(NEW_LINE);
		
		builder.append(String.format(TABULATION, WebContactConstants.FIRST_NAME));
		builder.append(String.format(TABULATION, role.getLeFirstName()));
		builder.append(NEW_LINE);
		
		builder.append(String.format(TABULATION, WebContactConstants.LAST_NAME));
		builder.append(String.format(TABULATION, role.getLeSurname()));
		builder.append(NEW_LINE);
		
		if(role.getCustAccountRoleType() != null && role.getCustAccountRoleType().equals(RoleType.PRIMARY.getValue())){
			builder.append(String.format(TABULATION, WebContactConstants.EMAIL));
			builder.append(String.format(TABULATION, role.getLeEmail()));
			builder.append(NEW_LINE);
		}
		
		builder.append(String.format(TABULATION, WebContactConstants.DATE_OF_BIRTH));
        builder.append(String.format(TABULATION, role.getDob() != null ? formatter.format(role.getDob()) : SPACE));
		builder.append(NEW_LINE);
		
		
		if(StringUtils.isNotEmpty(role.getTelNumMobile())){
			builder.append(String.format(TABULATION, WebContactConstants.MOBILE_PHONE));
			builder.append(String.format(TABULATION, role.getTelNumMobile()));
			builder.append(NEW_LINE);
		}
		
		if(StringUtils.isNotEmpty(role.getTelNumWork())){
			builder.append(String.format(TABULATION, WebContactConstants.WORK_PHONE));
			builder.append(String.format(TABULATION, role.getTelNumWork()));
			builder.append(NEW_LINE);
		}
		
		if(StringUtils.isNotEmpty(role.getTelNumHome())){
			builder.append(String.format(TABULATION, WebContactConstants.HOME_PHONE));
			builder.append(String.format(TABULATION, role.getTelNumHome()));
			builder.append(NEW_LINE);
		}
		
		builder.append(String.format(TABULATION, WebContactConstants.PREFERRED_CONTACT));
		builder.append(String.format(TABULATION, webContactRefData.getPreferedTelNumInd()));
		builder.append(NEW_LINE);
		
		builder.append(String.format(TABULATION, WebContactConstants.BANK_ACCOUNT));
		builder.append(String.format(TABULATION, webContactRefData.getBankStatus()));
		builder.append(NEW_LINE);
		
		builder.append(String.format(TABULATION, WebContactConstants.EMPLOYMENT));
		builder.append(String.format(TABULATION, webContactRefData.getEmplStatus()));
		builder.append(NEW_LINE);
		
		builder.append(String.format(TABULATION, WebContactConstants.HOME_OWNERSHIP));
		builder.append(String.format(TABULATION, webContactRefData.getHomeOwnStatus()));
		builder.append(NEW_LINE);
		
		if(role.getCustAccountRoleType() != null && role.getCustAccountRoleType().equals(RoleType.PRIMARY.getValue())){
			builder.append(String.format(TABULATION, WebContactConstants.MARKETING_CONSENT));
			builder.append(String.format(TABULATION, ""));
			builder.append(NEW_LINE);
		}
		return builder;
	}
}
