package uk.co.stwater.api.osgi.account;

import java.util.function.BiFunction;

import org.apache.commons.collections.Transformer;
import org.apache.commons.lang3.StringUtils;

import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.util.TransformerBase;
import uk.co.stwater.api.osgi.util.TriFunction;
import uk.co.stwater.targetconnector.client.api.accountdetails.AccountDetailsResponse;
import uk.co.stwater.targetconnector.client.api.accountroles.AccountRolesResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponseImpl;
import uk.co.stwater.targetconnector.client.api.addaccountrole.AccountRoleResp;
import uk.co.stwater.targetconnector.client.model.LegalEntityTitle;

/**
 *
 * @author Mark
 */
public class AccountTransformers extends TransformerBase {

    public static final BiFunction<uk.co.stwater.targetconnector.client.api.accountdetails.Address, Property, uk.co.stwater.api.osgi.model.Address> SOAP_ADDRESS_TO_MODEL_ADDRESS
	= (soapAddress, property) -> {
                    Address address = copy(soapAddress, new Address());
                    address.setStartDate(property.getStartDate());
                    address.setEndDate(property.getEndDate());
                    return address;
                };

    public static final TriFunction<AccountSummaryResponse, AccountDetailsResponse, Property, Account> SOAP_RESPONSE_TO_ACCOUNT
            = (accountSummary, accountDetails, property ) -> {
            	Account account = new Account();
            	if(accountSummary !=null){
	                account = copy(accountSummary, new Account());
	                account.setAccountNumber(accountSummary.getAccountNumber());
	                account.setWssPaperlessBillFlag(accountSummary.isIsPaperless()? "Y" : "N");
					account.setHasAmiMeterFlag(accountSummary.hasAmiMeterFlag());
	                account.setOutstandingAQFlag(accountSummary.isOutstandingAQFlag());
	                account.setOutstandingAQOrg(accountSummary.getOutstandingAQOrg());
	                account.setPaymentPlanIndicator(accountSummary.getPayPlanStatus());
	                account.setDemandDirectDebit(accountSummary.hasDemandDirectDebit());
					if(accountSummary instanceof AccountSummaryResponseImpl) {
						account.setBusinessLE(((AccountSummaryResponseImpl) accountSummary).isIsBusinessLE());
					}
            	}
                if(accountDetails!=null){
                    account.setLastInvoiceDueDate(accountDetails.getLastInvoiceDueDate().toGregorianCalendar().getTime());
                    account.setSupplyAddress(SOAP_ADDRESS_TO_MODEL_ADDRESS.apply(accountDetails.getSupplyAddress(), property));
                }
                if(property!=null){
                    account.setServAddress(property.getAddress());
                    account.setPropertyNum(Long.parseLong(property.getPropertyId()));
                    account.setSupplyStatus(property.getSupplyStatus());
                }
                
                
            return account;
            };


	public static final Transformer SOAP_RESPONSE_TO_ACCOUNT_ROLES_ENTITY = new Transformer() {
		@Override
		public AccountRoles transform(Object input) {

			AccountRoles accountRole = copy(input, new AccountRoles());
			if(input instanceof AccountRolesResponse){
				AccountRolesResponse accountRolesResponse = (AccountRolesResponse)input;
				accountRole.setLeNum(accountRolesResponse.getLENum());
				accountRole.setLeFirstName(accountRolesResponse.getLEFirstName());
				accountRole.setLeIndicator(accountRolesResponse.getLEIndicator());
				accountRole.setLeMiddleIntials(accountRolesResponse.getLEMiddleIntials());
				accountRole.setLeSurname(accountRolesResponse.getLESurname());
				accountRole.setLeTitleCode(accountRolesResponse.getLETitleCode());
				if (StringUtils.isNotEmpty(accountRolesResponse.getLEIndicator())) {
					String titleDescription = accountRolesResponse.getLEIndicator().equals("B") ? ""
							: LegalEntityTitle.getDisplayValueByCode(accountRolesResponse.getLETitleCode());
					accountRole.setLeTitleDesc(titleDescription);
				}
				accountRole.setCustAccountRoleNum(accountRolesResponse.getCustAccountRoleNum());
				accountRole.setAcceptInsertsFlag(accountRolesResponse.getAcceptInsertsFlag());
				accountRole.setAddressCode(accountRolesResponse.getAddressCode());
				accountRole.setAddressIndicator(accountRolesResponse.getAddressIndicator());
				accountRole.setBillCopiesNum(accountRolesResponse.getBillCopiesNum());
				accountRole.setDebtActivityType(accountRolesResponse.getDebtActivityType());
				accountRole.setCustAccountRoleType(accountRolesResponse.getCustAccountRoleType());
				accountRole.setDocReceivedDate(accountRolesResponse.getDocReceivedDate());
				accountRole.setLeResponsibilityRoleNum(accountRolesResponse.getLEResponsibilityRoleNum());
				accountRole.setOneLineAddress(accountRolesResponse.getOneLineAddress());
				accountRole.setPriorityRequiredFlag(accountRolesResponse.getPriorityRequiredFlag());
				accountRole.setResponsibilityCeaseDate(accountRolesResponse.getResponsibilityCeaseDate());
				accountRole.setStartDate(accountRolesResponse.getStartDate());
			}
			return accountRole;

		}

	};

	public static final Transformer SOAP_RESPONSE_TO_ACCOUNT_ROLES_RESP_ENTITY = new Transformer() {
		@Override
		public AccountRoles transform(Object input) {

			AccountRoles accountRole = copy(input, new AccountRoles());
			if(input instanceof AccountRoleResp){
				AccountRoleResp accountRolesResponse = (AccountRoleResp)input;
				accountRole.setCustAccountRoleNum(accountRolesResponse.getCustAccRoleNum());
				accountRole.setLeNum(accountRolesResponse.getLeNum());
			}
			return accountRole;

		}

	};
}
