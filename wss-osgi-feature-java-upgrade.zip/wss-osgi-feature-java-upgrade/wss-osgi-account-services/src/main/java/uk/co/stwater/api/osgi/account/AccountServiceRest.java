package uk.co.stwater.api.osgi.account;

import static org.apache.commons.lang3.StringUtils.isEmpty;
import static uk.co.stwater.api.osgi.util.Expandable.EXPAND_PARAM;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.model.ServicesAndTariff;
import uk.co.stwater.api.email.service.EmailService;
import uk.co.stwater.api.osgi.customer.CustomerService;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountInfo;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Brand;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.user.UserLoginMethods;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.Expandable;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.api.osgi.util.NotFoundException;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.ServiceStatus;
import uk.co.stwater.iib.client.api.accounts.IIBAccountsClient;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;

@Named
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class AccountServiceRest extends AbstractResource {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Inject
	AccountServiceImpl accountService;

	@Context
	UriInfo uri;

	@Inject
	@OsgiService
	private CreateContactClient createContactClient;

	@Inject
	@OsgiService
	private CustomerService customerService;

	@Inject
	@OsgiService
	EmailService emailService;

    @Inject
    @OsgiService
    private IIBAccountsClient accountsClient;

	static final List<Expands> validAccountExpands = Arrays.asList(Expands.summary, Expands.property, Expands.detail, Expands.registration, Expands.roles, Expands.basicInfo, Expands.roledetail);
        
	private static final String INACTIVE_ACCOUNT_CODE = "DM1.1";
	private static final String ROLE_OP_FAILURE_REGISTERED_CODE = "DM15.1";

	private static final String HEADER_DM = "DM";
	private static final String DM15_1 = "DM15.1";
	private static final String DM15_2 = "DM15.2";
	private static final String DM15_3 = "DM15.3";
	private static final String ACCOUNTS_URI = "/accounts";
	private static final String SLASH = "/";
	private static final String ACCOUNTS_ROLES_SUBPATH = "/Roles";
	
	@GET
	public Response getAccountSummary(@QueryParam("accountNumber") String accountNumber,
			@QueryParam("postcode") String postcode, @QueryParam("legalEntityNumber") String legalEntityNumber,
			@QueryParam(EXPAND_PARAM) List<String> requestedExpands) {
		log.debug("GET getAccountSummary start");

        // if so build list of Expands
        Expands[] expands = getValidExpands(requestedExpands);
		
        log.debug("Parameteres= accountNumber:{} / postcode: {} / LE: {}", accountNumber, postcode, legalEntityNumber);
		if(isEmpty(accountNumber) || isEmpty(legalEntityNumber)) {
			log.warn("ERROR: accountNumber and legalEntityNumber required: accountNumber:{} / LE: {}",accountNumber, legalEntityNumber);
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.ACCOUNT_SERVICES, "100","accountNumber and legalEntityNumber required");
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		} else {
			Account accountEntity = null;
				Long legalEntity = 0L;
				if (legalEntityNumber != null && !legalEntityNumber.isEmpty()) {
					legalEntity = Long.parseLong(legalEntityNumber);
				}
				TargetAccountNumber accountId = new TargetAccountNumber(accountNumber);
				accountEntity = accountService.getAccountSummary(accountId, postcode, legalEntity, getUserIdentity().getUsername(), expands);
			log.debug("Returning account entity");
			return Response.ok().entity(accountEntity).build();
		}
	}

	@GET
	@Path("/properties/{propertyNumber}/accounts")
	public Response getAccountsByPropertyNumber(@PathParam("propertyNumber") String propertyNumber) {
		log.debug("getAccountsByPropertyNumber start: {}", propertyNumber);
		try {
			List<AccountInfo> methods = accountService.getAccountsByPropertyNumber(propertyNumber);
			log.debug("getAccountsByPropertyNumber returning {} values", methods.size());
			GenericEntity<List<AccountInfo>> accountInfo = new GenericEntity<List<AccountInfo>>(methods) {};
			return Response.status(Status.OK.getStatusCode()).entity(accountInfo).build();
		} catch (STWTechnicalException e) {
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.ACCOUNT_SERVICES, Status.INTERNAL_SERVER_ERROR.getStatusCode(), e.getMessage());
			log.error(e.getMessage(), e);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(errorDto).build();
		} catch (STWBusinessException ex) {
			log.warn(ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}

	@GET
	@Path("/legal-entity/{leId}/email")
	public Response getEmailForLegalEntity(@PathParam("leId") String legalEntityNumber) {
		log.debug("getEmailForLegalEntity start: {}", legalEntityNumber);
		String emailAddress = null;
		if (StringUtils.isNotEmpty(legalEntityNumber)) {
			emailAddress = accountService.getEmailAddressForLegalEntity(legalEntityNumber);
			log.debug("Found email address {}", emailAddress);
			if (StringUtils.isNotEmpty(emailAddress)) {
				return Response.status(200).entity(emailAddress).build();
			} else {
				log.warn("Not found");
				ErrorDto errorDto = new ErrorDto(404, "Email address for legal entity not found");
				return Response.status(Status.NOT_FOUND).entity(errorDto)
						.build();
			}
		} else {
			ErrorDto errorDto = new ErrorDto(104, "Email is empty");
			log.warn(errorDto.getDescription());
			return Response.status(Status.BAD_REQUEST).entity(errorDto)
					.build();
		}
	}

    // returns a list as legalEntityNo can be linked to multiple WSS users in the DB
    @GET
    @Path("/{accountNumber}/legal-entity/{legalEntityNo}/user/login-method")
    public List<UserLoginMethods> getLoginMethodsForLegalEntity(@PathParam("accountNumber") String accountNumberStr,
            @PathParam("legalEntityNo") String legalEntityNo) {
        if (StringUtils.isBlank(legalEntityNo)) {
            throw new STWBusinessException("legalEntityNo required");
        }
        if (StringUtils.isBlank(accountNumberStr)) {
            throw new STWBusinessException("accountNumber required");
        }
        TargetAccountNumber accountNumber = new TargetAccountNumber(accountNumberStr);

        return accountService.getLoginMethods(accountNumber, legalEntityNo);
    }

	@GET
	@Path("/{accountNumber}/properties")
	public Response getPropertiesByAccountNumber(@PathParam("accountNumber") String accountNumber) {
		log.debug("getPropertiesByAccountNumber start: {}", accountNumber);
		try{
			TargetAccountNumber accountId = new TargetAccountNumber(accountNumber);
			List<Property> properties = accountService.getPropertiesByAccountNumber(accountId, getUserIdentity().getUsername());
			log.debug("getPropertiesByAccountNumber returning {} values", properties.size());
			return Response.status(Response.Status.OK).entity(new GenericEntity<List<Property>>(properties){}).build();
		} catch(STWBusinessException e) {
			log.warn(e.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).build();
		} catch(STWTechnicalException e) {
			log.error(e.getMessage(), e);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
	}
        
    @GET
    @Path("/{accountNumber}/{a:Roles|roles}")
    public Response getAccountRoles(
            @QueryParam(EXPAND_PARAM) List<String> requestedExpands,
            @PathParam("accountNumber") TargetAccountNumber accountNumber) {
        
        log.debug("getAccountRoles start: {}", accountNumber);
        
        Expands[] expands = getValidExpands(requestedExpands);

        List<AccountRoles> roles = accountService.getAccountRoles(accountNumber, expands);
        return Response.status(Response.Status.OK).entity(new GenericEntity<List<AccountRoles>>(roles) {
        }).build();
    }

	@PUT
	@Path("/{accountNumber}/{a:Roles|roles}")
	public Response addRoleToAccount(@PathParam("accountNumber") TargetAccountNumber accountNumber, AccountRoles accountRole) {
		log.debug("addRoleToAccount start: {}", accountNumber);
		try {
			String authToken = getUserIdentity().getUsername();
			if (accountRole.getAccountNumber() != null) {
				if (accountNumber != null && TargetAccountNumber.isSameAccount(accountRole.getAccountNumber(), accountNumber)) {
					log.trace("Calling account service to add a new role with fullname {} into account {}", 
							new Object[]{accountRole.getFullName(), accountNumber.getAccountNumberWithCheckDigit()});
					AccountRoles returnedRole = accountService.addRoleToAccount(accountRole , authToken, getContactDto());
					log.debug("Call to account service to add a new role with fullname {} to the account {} "
							+ "completed without errors", new Object[]{accountRole.getFullName(), accountNumber.getAccountNumberWithCheckDigit()});
					URI uri = UriBuilder.fromPath(
						ACCOUNTS_URI.concat(SLASH).concat(accountRole.getAccountNumber().getAccountNumberWithCheckDigit())
						.concat(ACCOUNTS_ROLES_SUBPATH)
					).build();
					if(returnedRole.getAccountNumber()==null) {
						log.info("The call to the service to add the role with fullname {} was completed successfully but "
								+ "the role was not added to the account {} due to unsatisfied conditions. Return code: {}",
								accountRole.getFullName(), accountNumber.getAccountNumberWithCheckDigit(), DM15_1);
						return Response.created(uri).entity(returnedRole).header(HEADER_DM, DM15_1).build();
					}else{
						log.info("The call to the service to add the role with fullname {} was completed successfully and "
								+ "the role was added to the account {} in target. Return code: {}",
								accountRole.getFullName(), accountNumber.getAccountNumberWithCheckDigit(), DM15_2);
						return Response.created(uri).entity(returnedRole).header(HEADER_DM, DM15_2).build();
					}
				} else {
					log.warn("The account number passed in the call {} and the account number in the role {} do not match", 
						new Object[]{accountNumber, accountRole.getAccountNumber()});
					ErrorDto errorDto = new ErrorDto(100, "Acccount number not correct.");
					log.warn(errorDto.getDescription());
					return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
				}
			} else {
				log.warn("No account number was specified in the role sent in the request");
				ErrorDto errorDto = new ErrorDto(100, "Acccount number must be provided.");
				log.warn(errorDto.getDescription());
				return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
			}
		} catch (NotFoundException e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = new ErrorDto(Response.Status.NOT_FOUND.getStatusCode(), e.getMessage());
			return Response.status(Response.Status.NOT_FOUND).entity(eDto).build();
		} catch (STWBusinessException e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = null;
			if(StringUtils.isEmpty(e.getErrorCode())){
				eDto = new ErrorDto(Response.Status.BAD_REQUEST.getStatusCode(), e.getMessage());
			}else{
				eDto = new ErrorDto(e.getErrorCode(), e.getMessage());
			}
			return Response.status(Response.Status.BAD_REQUEST).entity(eDto).build();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = new ErrorDto(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), e.getMessage());
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(eDto).build();
		}
	}
	
	@DELETE
	@Path("/{accountNumber}/{a:Roles|roles}/{roleId}")
	public Response deleteAccountRole(@PathParam("accountNumber") TargetAccountNumber accountNumber,
			@PathParam("roleId") Long roleId,
			@QueryParam("leNum") Long leNum) {
		log.debug("deleteAccountRole started: {}, {}, {}", accountNumber, roleId, leNum);
		try {
			String authToken = getUserIdentity().getUsername();
			log.trace("Calling account service to remove the role with LE {} from account {}", 
					new Object[]{roleId, accountNumber.getAccountNumberWithCheckDigit()});
			Boolean deleted = accountService.deleteAccountRole(roleId, accountNumber, leNum, authToken, getContactDto());
			log.debug("Call to the account service to remove the role with LE {} from account {} completed successfully", 
				new Object[]{roleId, accountNumber.getAccountNumberWithCheckDigit()});
			if(!deleted){
				URI uri = UriBuilder.fromPath(
					ACCOUNTS_URI.concat(SLASH).concat(accountNumber.getAccountNumberWithCheckDigit())
					.concat(ACCOUNTS_ROLES_SUBPATH).concat(SLASH).concat(String.valueOf(roleId))
				).build();
				log.info("The call to the service to remove the role with LE {} was completed successfully but "
						+ "the role was not removed from the account {} due to unsatisfied conditions. Return code: {}",
						roleId, accountNumber.getAccountNumberWithCheckDigit(), DM15_1);
				return Response.status(Status.OK).location(uri).entity(deleted).header(HEADER_DM, DM15_1).build();
			}else{
				log.info("The call to the service to remove the role with LE {} was completed successfully and "
						+ "the role was successfully removed from the account {}. Return code: {}",
						roleId, accountNumber.getAccountNumberWithCheckDigit(), DM15_3);
				return Response.status(Status.OK).entity(deleted).header(HEADER_DM, DM15_3).build();
			}
		} catch (NotFoundException e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = new ErrorDto(Response.Status.NOT_FOUND.getStatusCode(), e.getMessage());
			return Response.status(Response.Status.NOT_FOUND).entity(eDto).build();
		} catch (STWBusinessException e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = new ErrorDto(Response.Status.BAD_REQUEST.getStatusCode(), e.getMessage());
			return Response.status(Response.Status.BAD_REQUEST.getStatusCode()).entity(eDto).build();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = new ErrorDto(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), e.getMessage());
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(eDto).build();
		}
	}

	@Override
	public ServiceStatus getServiceStatus() {
		ServiceStatus status = new ServiceStatus();
		status.addDependencyStatus("accountService", accountService != null);
		status.addDependencyStatus("emailService", emailService != null);
		status.addDependencyStatus("createContactClient", createContactClient != null);
		status.addDependencyStatus("customerService", customerService != null);
		status.addDependencyStatus("accountService.invoke", testAccountService());
		return status;
	}

	private boolean testAccountService() {
		if (accountService == null) {
			return false;
		}
		try {
			accountService.getEmailAddressForLegalEntity("000000001");
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	@GET
	@Produces({ "text/xml" })
	@Path("/status/xml")
	public Response status1() {
		return Response.ok().entity(getServiceStatus()).build();
	}
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/{accountNumber}/brands")
	public Response getBrandByAccount(@PathParam("accountNumber") TargetAccountNumber targetAccount) {
		log.debug("GET getAccountByBrand start");
		try {
			String authToken = getUserIdentity().getUsername();
			log.debug("accountId and authToken are {} and {}", targetAccount.getAccountNumberAsLong(), authToken);
			Brand brand = accountService.getBrandByAccount(targetAccount, authToken);
			log.debug("GET getAccountByBrand end");
				return Response.ok().entity(brand).build();
		} catch (STWBusinessException | STWTechnicalException e) {
			log.error(e.getMessage(), e);
			ErrorDto eDto = new ErrorDto(Response.Status.NOT_FOUND.getStatusCode(), e.getMessage());
			return Response.status(Response.Status.NOT_FOUND).entity(eDto).build();
		}
	}
        
        
    private Expands[] getValidExpands(List<String> requestedExpands) throws STWBusinessException {
        // check only valid expand options have been given
        if (!Expandable.isValidOptionList(requestedExpands, validAccountExpands)) {
            log.error("Invalid expand option supplied");
            throw new STWBusinessException("Invalid expand option supplied", Response.Status.BAD_REQUEST);
        }
        // if so build list of Expands
        return Expandable.getExpands(requestedExpands, Expands.class);
    }

    @GET
    @Consumes({ MediaType.APPLICATION_JSON })
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/{accountNumber}/services-and-tariffs")
    public List<ServicesAndTariff> getServicesAndTariff(@PathParam("accountNumber") TargetAccountNumber accountNumber,
            @QueryParam("propertyId") String propertyId) {
        String authToken = getUserIdentity().getUsername();
        return accountsClient.getServicesAndTariff(accountNumber, propertyId, authToken);
    }

}
