package uk.co.stwater.api.batch.paperless;

import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class WEB715Contact implements CustomerContact {

    private static final String UNKNOWN_POSTCODE = "UNKNOWN";
    private ContactNotesData contactNotesData;
    private TargetAccountNumber accountNumber;
     
    public WEB715Contact(TargetAccountNumber accountNumber,ContactNotesData contactNotesData) {
        this.accountNumber = accountNumber;
        this.contactNotesData = contactNotesData;
    }
    
    @Override
    public String getFormattedNote() {
        StringBuilder builder = new StringBuilder();
        builder.append(CustomerContact.getFormattedCustomerDetails(contactNotesData)).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append("Query Details: ").append(NEW_LINE);
        builder.append("Paperless flag removal completed, this could be due to two consecutive email failures for the same reason or " + 
                "in response to a campaign where the customer has opted out or the email address we held was invalid when the campaign was sent. " + 
                "Please check contact history for letter of removal or campaign contact being added. ").append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append("Updates completed in Target.").append(NEW_LINE);
        builder.append("").append(NEW_LINE);
        return builder.toString();
    }
    
    public String getContactType() {
        return ContactTypes.WEB715.toString();
    }

    public boolean isSubstantiveResponse() {
        return true;
    }

    @Override
    public TargetAccountNumber getAccountNumber() {
         return accountNumber;
    }

    @Override
    public String getLegalEntityNumber() {
        return null;
    }

    @Override
    public String getPostcode() {
        return UNKNOWN_POSTCODE;
    }

    @Override
    public Long getPropertyNumber() {
        return null;
    }
}
