package uk.co.stwater.api.batch;

import java.util.function.Consumer;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public interface BatchProcessor {

    void checkCSVFile(CSVParser csvParser);

    boolean canProcess(CSVRecord csvRecord);

    void execute(BatchItem batchItem);

    void process(BatchJob batchJob, Iterable<CSVRecord> csvRecords, Consumer<BatchItem> batchItemSaver);

}
