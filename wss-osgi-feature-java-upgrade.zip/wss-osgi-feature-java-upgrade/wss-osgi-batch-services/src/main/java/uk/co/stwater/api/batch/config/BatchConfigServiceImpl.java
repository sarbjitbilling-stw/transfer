package uk.co.stwater.api.batch.config;

import org.apache.commons.lang3.Range;
import org.apache.commons.lang3.math.NumberUtils;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.batch.BatchProcessor;

import static java.lang.Integer.parseInt;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * @author rtaixx2
 */
@Component(service = BatchConfigService.class, configurationPid = BatchConfigServiceImpl.PID)
public class BatchConfigServiceImpl implements BatchConfigService {
    
    public static final String PID = "wss.osgi.batch";

    static final String BATCH_MAX_FILE_SIZE_BYTES = PID + ".max.filesize.bytes";

    static final String BATCH_CRON_EXPR = PID + ".cron.expr";

    static final String BATCH_JOB_ITEMS_SIZE = PID + ".job.items.size";

    static final String BATCH_JOB_ITEMS_MINIMUM = PID + ".job.items.minimum";

    static final String BATCH_JOB_ITEMS_MAXIMUM = PID + ".job.items.maximum";

    static final String BATCH_SCHEDULER_THREAD_POOL_SIZE = PID + ".scheduler.threadpool.size";

    static final String EXECUTOR_NODE_FLAG = PID + ".executor";

    static final String MAXIMUM_RETRY_COUNT = PID + ".maximum.retry.count";

    private static final int DEFAULT_MAXIMUM_RETRY_COUNT = 3;

    private static final int DEFAULT_JOB_ITEMS_SIZE = 1000;

    private static final int DEFAULT_MIN_JOB_ITEMS_SIZE = 100;

    private static final int DEFAULT_MAX_JOB_ITEMS_SIZE = 10000;

    private static final int DEFAULT_THREAD_POOL_SIZE = 10;

    private static final String DEFAULT_BATCH_CRON_EXPR = "0 0/2 * * * ?";

    private static final int DEFAULT_BATCH_MAX_FILE_SIZE = 1000000;

    private static Range<Integer> minimumValuesRange = Range.between(10, DEFAULT_MIN_JOB_ITEMS_SIZE);

    private static Range<Integer> maximumValuesRange = Range.between(DEFAULT_JOB_ITEMS_SIZE, DEFAULT_MAX_JOB_ITEMS_SIZE);

    private static Range<Integer> threadPoolValuesRange = Range.between(1, 20);

    private static final Logger logger = LoggerFactory.getLogger(BatchConfigServiceImpl.class);

    private Map<String, String> config = new HashMap<>();

    private String cronExpression;

    private int jobItemsSize;

    private int minimumJobSize;

    private int maximumJobSize;

    private int schedulerThreadPoolSize;

    private int maximumRetryCount;

    private boolean executorNode;

    private BundleContext bundleContext;

    private static AtomicInteger instanceCounter = new AtomicInteger();

    private final int instanceId;

    public BatchConfigServiceImpl() {
        instanceId = instanceCounter.incrementAndGet();
        logger.debug("instance id {} created", instanceId);
    }

    @Activate
    @Modified
    public void updated(Map<String, String> dctnrIn) {
        logger.info("updating batch config for instance id {}", instanceId);
        if (dctnrIn != null) {
            config = dctnrIn;
        }

        logger.info("Loading configuration into instance {} : {}", this.hashCode(), config);

        this.minimumJobSize = getMinimumJobSize(config);
        this.maximumJobSize = getMaximumJobSize(config);
        this.jobItemsSize = getBatchJobItemsSize(config);
        this.schedulerThreadPoolSize = getSchedulerThreadPoolSize(config);
        this.executorNode = Boolean.parseBoolean(config.getOrDefault(EXECUTOR_NODE_FLAG, "false"));
        this.maximumRetryCount = NumberUtils.toInt(config.get(MAXIMUM_RETRY_COUNT), DEFAULT_MAXIMUM_RETRY_COUNT);
        this.cronExpression = config.getOrDefault(BATCH_CRON_EXPR, DEFAULT_BATCH_CRON_EXPR);

    }

    @Override
    public BatchProcessor getBatchProcessor(String command) {
        logger.debug("getBatchProcessor from instance id {}", instanceId);
        String msg = String.format("No class mapped for batch command %s", command);
        if (config.containsKey(command)) {
            String processorName = config.get(command);
            if (processorName != null) {
                ServiceReference<?> serviceReference = getBundleContext().getServiceReference(processorName);
                if (serviceReference != null) {
                    BatchProcessor batchProcessor = (BatchProcessor) getBundleContext().getService(serviceReference);
                    if (batchProcessor != null) {
                        return batchProcessor;
                    }
                }
            }
        } else {
            logger.error(msg);
            throw new BatchException(msg);
        }
        throw new BatchException(msg);
    }

    protected BundleContext getBundleContext() {
        if (bundleContext == null) {
            Bundle bundle = FrameworkUtil.getBundle(this.getClass());
            if (bundle == null) {
                logger.warn("Unable to get bundle from FrameworkUtil - if this is a Unit Test please ignore");
                return null;
            }
            bundleContext = bundle.getBundleContext();
        }
        return bundleContext;
    }

    @Override
    public int getBatchMaxFileSize() {
        logger.debug("getBatchMaxFileSize from instance id {}", instanceId);
        if (isEmpty(config.get(BATCH_MAX_FILE_SIZE_BYTES))) {
            logger.warn("{} not found in config, using default value {}",BATCH_MAX_FILE_SIZE_BYTES, DEFAULT_BATCH_MAX_FILE_SIZE);
            return DEFAULT_BATCH_MAX_FILE_SIZE;
        } else {
            try {
                return parseInt(config.get(BATCH_MAX_FILE_SIZE_BYTES));
            } catch (NumberFormatException e) {
                logger.warn("{} cannot be parsed into integer, using default value {}", BATCH_MAX_FILE_SIZE_BYTES,
                        DEFAULT_BATCH_MAX_FILE_SIZE);
                return DEFAULT_BATCH_MAX_FILE_SIZE;
            }
        }
    }

    public String getCronExpression() {
        return cronExpression != null ? cronExpression : DEFAULT_BATCH_CRON_EXPR;
    }

    public int getSchedulerThreadPoolSize() {
        return this.schedulerThreadPoolSize;
    }

    public int getMinimumJobSize() {
        return (minimumJobSize == 0 ? DEFAULT_MIN_JOB_ITEMS_SIZE : minimumJobSize);
    }

    public int getMaximumJobSize() {
        return (maximumJobSize == 0 ? DEFAULT_MAX_JOB_ITEMS_SIZE : maximumJobSize);
    }

    public int getMaximumRetryCount() {
        return maximumRetryCount;
    }

    public boolean isExecutorNode() {
        return this.executorNode;
    }

    public int getJobItemsSize() {
        return this.jobItemsSize;
    }

    private int getBatchJobItemsSize(Map<String, String> config) {
        int value = NumberUtils.toInt(config.get(BATCH_JOB_ITEMS_SIZE), DEFAULT_JOB_ITEMS_SIZE);
        Range<Integer> range = Range.between(getMinimumJobSize(), getMaximumJobSize());
        if (range.contains(value)) {
            return value;
        } else {
            logger.warn("{} is outside of the range {} for job items size, using default {}", config.get(BATCH_JOB_ITEMS_SIZE), range, DEFAULT_JOB_ITEMS_SIZE);
            return DEFAULT_JOB_ITEMS_SIZE;
        }
    }

    private static int getSchedulerThreadPoolSize(Map<String, String> config) {
        int value = NumberUtils.toInt(config.get(BATCH_SCHEDULER_THREAD_POOL_SIZE), DEFAULT_THREAD_POOL_SIZE);
        if (threadPoolValuesRange.contains(value)) {
            return value;
        } else {
            logger.error("{} is not a valid thread pool size, using default size {}", config.get(BATCH_SCHEDULER_THREAD_POOL_SIZE), DEFAULT_THREAD_POOL_SIZE);
            return DEFAULT_THREAD_POOL_SIZE;
        }
    }

    private static int getMinimumJobSize(Map<String, String> config) {
        int minimum = NumberUtils.toInt(config.get(BATCH_JOB_ITEMS_MINIMUM), DEFAULT_MIN_JOB_ITEMS_SIZE);
        if (minimumValuesRange.contains(minimum)) {
            return minimum;
        } else {
            logger.warn("{} is outside of the range {} for minimum job items, using default {}", config.get(BATCH_JOB_ITEMS_MINIMUM), minimumValuesRange, DEFAULT_MIN_JOB_ITEMS_SIZE);
            return DEFAULT_MIN_JOB_ITEMS_SIZE;
        }
    }

    private static int getMaximumJobSize(Map<String, String> config) {
        int maximum = NumberUtils.toInt(config.get(BATCH_JOB_ITEMS_MAXIMUM), DEFAULT_MAX_JOB_ITEMS_SIZE);
        if (maximumValuesRange.contains(maximum)) {
            return maximum;
        } else {
            logger.warn("{} is outside of the range {} for maximum job items, using default {}", config.get(BATCH_JOB_ITEMS_MAXIMUM), maximumValuesRange, DEFAULT_MAX_JOB_ITEMS_SIZE);
            return DEFAULT_MAX_JOB_ITEMS_SIZE;
        }
    }
}
