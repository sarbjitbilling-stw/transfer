package uk.co.stwater.api.batch.api;

import java.util.Collections;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ExceptionMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.osgi.model.common.ErrorDto;

public class BatchExceptionMapper implements ExceptionMapper<BatchException> {

    private static final Logger logger = LoggerFactory.getLogger(BatchExceptionMapper.class);

    private static final String BATCH_PROCESSING_ERROR_CODE = "DM50.1";
    private static final String BATCH_VALIDATION_ERROR_CODE = "DM50.2";

    @Context
    private UriInfo uri;

    @Context
    private Request request;

    @Context
    private HttpHeaders headers;

    @Override
    public Response toResponse(BatchException exception) {
        logger.warn("Exception when processing request={} {}", request.getMethod(), uri.getBaseUri(), exception);
        
        ErrorDto errorDto = null;
        if (exception.getErrors().isEmpty()){
            errorDto = new ErrorDto(ErrorDto.ErrorCategory.BATCH_SERVICES, BATCH_PROCESSING_ERROR_CODE,
                    exception.getMessage());
        } else {
            errorDto = new ErrorDto(ErrorDto.ErrorCategory.BATCH_SERVICES, BATCH_VALIDATION_ERROR_CODE,
                    exception.getMessage());
            errorDto.setDetails(Collections.singletonMap("Errors", exception.getErrors()));
        }
        String requestContentType = headers.getHeaderString(HttpHeaders.CONTENT_TYPE);
        Response.Status status = exception.getCause() != null ? Response.Status.INTERNAL_SERVER_ERROR : Response.Status.BAD_REQUEST;
        return Response.status(status)
                .header(HttpHeaders.CONTENT_TYPE, requestContentType)
                .entity(errorDto)
                .build();
    }
}
