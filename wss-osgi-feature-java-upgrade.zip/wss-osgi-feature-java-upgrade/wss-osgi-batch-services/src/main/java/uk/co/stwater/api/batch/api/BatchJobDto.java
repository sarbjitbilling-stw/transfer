package uk.co.stwater.api.batch.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.time.LocalDate;
import java.util.List;
import uk.co.stwater.api.batch.Status;

@XmlRootElement(name = "STWBatchJob")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BatchJobDto {

    @XmlElement(name = "id")
    private long id;
    @XmlElement(name = "batchSize")
    private int batchSize;

    @XmlElement(name = "batchItems")
    private List<BatchItemDto> batchItems;

    @XmlElement(name = "status")
    private Status status;

    @XmlElement(name = "queuedItemsCount")
    private int queuedItemsCount;

    @XmlElement(name = "lockedItemsCount")
    private int lockedItemsCount;

    @XmlElement(name = "completedItemsCount")
    private int completedItemsCount;

    @XmlElement(name = "failedItemsCount")
    private int failedItemsCount;

    @XmlElement(name = "cancelledItemsCount")
    private int cancelledItemsCount;

    @XmlElement(name = "dateCreated")
    private LocalDate dateCreated;

    @XmlElement(name = "dateModified")
    private LocalDate dateModified;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }

    public List<BatchItemDto> getBatchItems() {
        return batchItems;
    }

    public void setBatchItems(List<BatchItemDto> batchItems) {
        this.batchItems = batchItems;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public int getQueuedItemsCount() {
        return queuedItemsCount;
    }

    public void setQueuedItemsCount(int queuedItemsCount) {
        this.queuedItemsCount = queuedItemsCount;
    }

    public int getLockedItemsCount() {
        return lockedItemsCount;
    }

    public void setLockedItemsCount(int lockedItemsCount) {
        this.lockedItemsCount = lockedItemsCount;
    }

    public int getCompletedItemsCount() {
        return completedItemsCount;
    }

    public void setCompletedItemsCount(int completedItemsCount) {
        this.completedItemsCount = completedItemsCount;
    }

    public int getFailedItemsCount() {
        return failedItemsCount;
    }

    public void setFailedItemsCount(int failedItemsCount) {
        this.failedItemsCount = failedItemsCount;
    }

    public LocalDate getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public LocalDate getDateModified() {
        return dateModified;
    }

    public void setDateModified(LocalDate dateModified) {
        this.dateModified = dateModified;
    }

    public int getCancelledItemsCount() {
        return cancelledItemsCount;
    }

    public void setCancelledItemsCount(int cancelledItemsCount) {
        this.cancelledItemsCount = cancelledItemsCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }
   
        BatchJobDto that = (BatchJobDto) o;

        return new EqualsBuilder()
                .append(id, that.id)
                .append(batchSize, that.batchSize)
                .append(status, that.status)
                .append(dateCreated, that.dateCreated)
                .append(dateModified, that.dateModified)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(batchSize)
                .append(status)
                .append(dateCreated)
                .append(dateModified)
                .toHashCode();
    }
    
}
