package uk.co.stwater.api.batch;

import static org.apache.commons.lang3.StringUtils.isEmpty;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.EnumUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;

import uk.co.stwater.api.batch.api.BatchItemDto;
import uk.co.stwater.api.batch.api.BatchJobDto;
import uk.co.stwater.api.batch.api.BatchRequestDto;
import uk.co.stwater.api.batch.config.BatchConfigService;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchItemEntityDao;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchJobEntityDao;
import uk.co.stwater.api.dao.batch.BatchStatus;
import uk.co.stwater.api.osgi.model.WSSSite;
import uk.co.stwater.api.osgi.util.logging.LogChannel;
import uk.co.stwater.api.osgi.util.logging.LoggerFactory;

@Named
public class STWBatchServiceImpl implements STWBatchService {

    private static Logger logger = LoggerFactory.getLogger(LogChannel.BATCH, STWBatchServiceImpl.class);

    private static final String AUTHOR = "author";

    @Inject
    @OsgiService
    private BatchItemEntityDao batchItemEntityDao;

    @Inject
    @OsgiService
    private BatchJobEntityDao batchJobEntityDao;

    @Inject
    @OsgiService
    private BatchConfigService batchConfigService;

    @Override
    public BatchJobDto createJob(BatchRequestDto stwBatchRequest) {
        BatchProcessor batchProcessor = batchConfigService.getBatchProcessor(stwBatchRequest.getCommand());
        validateRequest(batchProcessor, stwBatchRequest);
        BatchJobEntity batchJobEntity = createBatchJob(stwBatchRequest);
        BatchJobDto stwBatchJob = fromEntity(batchJobEntity);
        loadData(batchProcessor, stwBatchRequest, batchJobEntity);
        return stwBatchJob;
    }

    @Override
    @Transactional
    public BatchJobDto queryJob(long jobId) {
        try {
            BatchJobEntity batchJobEntity = batchJobEntityDao.findById(jobId);
            return getBatchJobFromEntity(batchJobEntity, true);
        } catch (EntityNotFoundException e) {
            throw new BatchException(e.getMessage(), e);
        }
    }

    @Override
    @Transactional
    public List<BatchJobDto> listJobs() {
        List<BatchJobEntity> list = batchJobEntityDao.findAll();
        return list.stream().map(batchJobEntity -> getBatchJobFromEntity(batchJobEntity, false)).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void cancelJob(long jobId) {
        try {
            BatchJobEntity batchJobEntity = batchJobEntityDao.findById(jobId);
            batchJobEntity.setStatus(BatchStatus.CANCELLED);
            batchJobEntityDao.update(batchJobEntity);
            batchItemEntityDao.cancelByJobId(batchJobEntity.getId());
        } catch (EntityNotFoundException e) {
            throw new BatchException(e.getMessage(), e);
        }
    }
    
    private void validateRequest(BatchProcessor batchProcessor, BatchRequestDto stwBatchRequest) {
        if (stwBatchRequest == null || ArrayUtils.isEmpty(stwBatchRequest.getData()) || isEmpty(stwBatchRequest.getBrand()) || isEmpty(stwBatchRequest.getCommand())) {
            throw new BatchException("mandatory parameters are missing, data, brand and command");
        }
        if (stwBatchRequest.getData().length > getMaxFileSize()) {
            throw new BatchException(String.format("file size %s too large, maximum %s supported", stwBatchRequest.getData().length, getMaxFileSize()));
        }

        try (ByteArrayInputStream bais = new ByteArrayInputStream(stwBatchRequest.getData())) {
            InputStreamReader reader = new InputStreamReader(bais);
            CSVParser parser = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(reader);
            batchProcessor.checkCSVFile(parser);
        } catch (IOException ex) {
            throw new BatchException("cannot read csv file", ex);
        }
    }

    private BatchJobDto loadData(BatchProcessor batchProcessor, BatchRequestDto stwBatchRequest, BatchJobEntity batchJobEntity) {
        logger.debug("loading data for batch processing ...");
        try (ByteArrayInputStream bais = new ByteArrayInputStream(stwBatchRequest.getData())) {
            InputStreamReader reader = new InputStreamReader(bais);
            Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(reader);
            BatchJob batchJob = BatchJobImpl.fromEntity(batchJobEntity);

            batchProcessor.process(
                    batchJob,
                    records,
                    record -> saveBatchItem(batchJobEntity, record));

            return BatchJobImpl.toBatchJobDto(batchJob);
        } catch (IOException e) {
            throw new BatchException("Failed to create BatchJob", e);
        }
    }

    private void saveBatchItem(BatchJobEntity batchJob, BatchItem batchItem) {
        BatchItemEntity batchItemEntity = BatchItemImpl.toEntity(batchJob, batchItem);
        batchItemEntityDao.save(batchItemEntity);
        logger.debug("Created BatchItem {} for BatchJob {}, accountNumber={}", batchItemEntity.getId(),
                batchJob.getId(), batchItem.getTargetAccountNumber());
    }

    private BatchJobDto getBatchJobFromEntity(BatchJobEntity batchJobEntity, boolean returnItems) {
        int queued = 0;
        int locked = 0;
        int completed = 0;
        int failed = 0;
        int cancelled = 0;
        List<BatchItemEntity> entities = batchItemEntityDao.findByJobId(batchJobEntity.getId());
        List<BatchItemDto> batchItemList = new ArrayList<>();

        for (BatchItemEntity item : entities) {
            switch (item.getStatus()) {
                case QUEUED:
                    queued++;
                    break;
                case LOCKED:
                    locked++;
                    break;
                case FAILED:
                    failed++;
                    break;
                case COMPLETED:
                    completed++;
                    break;
                case CANCELLED:
                    cancelled++;
                    break;
            }
            if (returnItems) {
                batchItemList.add(fromEntity(item));
            }
        }
        BatchJobDto job = fromEntity(batchJobEntity);
        job.setQueuedItemsCount(queued);
        job.setLockedItemsCount(locked);
        job.setCompletedItemsCount(completed);
        job.setFailedItemsCount(failed);
        job.setCancelledItemsCount(cancelled);
        job.setBatchSize(entities.size());
        job.setBatchItems(batchItemList);
        setStatus(job);
        return job;
    }

    private void setStatus(BatchJobDto job) {
        int batchSize = job.getBatchSize();
        boolean statusUpdated = false;
        if (batchSize == job.getCompletedItemsCount()) {
            job.setStatus(Status.COMPLETED);
            statusUpdated = true;
        }
        if (job.getCompletedItemsCount() + job.getFailedItemsCount() == batchSize) {
            job.setStatus(Status.COMPLETED);
            statusUpdated = true;
        }
        if (batchSize == job.getFailedItemsCount()) {
            job.setStatus(Status.FAILED);
            statusUpdated = true;
        }
        if (batchSize == job.getCancelledItemsCount()) {
            job.setStatus(Status.CANCELLED);
            statusUpdated = true;
        }
        if (!statusUpdated) {
            job.setStatus(Status.QUEUED);
        }
    }

    private BatchJobEntity createBatchJob(BatchRequestDto batchRequest) {
        BatchJobEntity batchJobEntity = new BatchJobEntity();
        batchJobEntity.setStatus(BatchStatus.QUEUED);
        batchJobEntity.setUserId(AUTHOR);
        batchJobEntity.setCommandName(batchRequest.getCommand());
        Date date = new Date();
        batchJobEntity.setDateCreated(date);
        batchJobEntity.setDateModified(date);
        if (EnumUtils.isValidEnum(WSSSite.class, batchRequest.getBrand())) {
            batchJobEntity.setSite(WSSSite.valueOf(batchRequest.getBrand()));
        }
        batchJobEntityDao.save(batchJobEntity);

        return batchJobEntity;
    }

    private int getMaxFileSize() {
        return batchConfigService.getBatchMaxFileSize();
    }

    private static BatchItemDto fromEntity(BatchItemEntity entity) {
        return new BatchItemDto(entity.getBatchJob().getId(), entity.getTargetAccountNumber(), entity.getFieldData(), Status.valueOf(entity.getStatus().name()),
                toLocalDate(entity.getDateCreated()));
    }

    private static BatchJobDto fromEntity(BatchJobEntity entity) {
        BatchJobDto stwBatchJob = new BatchJobDto();
        stwBatchJob.setId(entity.getId());
        stwBatchJob.setStatus(Status.valueOf(entity.getStatus().name()));
        stwBatchJob.setDateCreated(toLocalDate(entity.getDateCreated()));
        stwBatchJob.setDateModified(toLocalDate(entity.getDateModified()));
        return stwBatchJob;
    }

    private static LocalDate toLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

}
