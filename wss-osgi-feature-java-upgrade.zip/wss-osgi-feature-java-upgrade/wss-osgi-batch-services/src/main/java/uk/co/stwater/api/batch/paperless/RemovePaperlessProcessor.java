package uk.co.stwater.api.batch.paperless;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import uk.co.stwater.api.batch.BatchException;
import uk.co.stwater.api.osgi.model.RoleType;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.osgi.util.logging.LogChannel;
import uk.co.stwater.api.osgi.util.logging.LoggerFactory;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.targetconnector.client.api.accountroles.AccountRolesResponse;
import uk.co.stwater.targetconnector.client.api.accountroles.ListAccountRolesClient;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;
import uk.co.stwater.targetconnector.client.api.leregistration.GetLEDataForWSSClient;
import uk.co.stwater.targetconnector.client.api.leregistration.LERegistrationDataImpl;
import uk.co.stwater.targetconnector.client.api.leregistration.SetLEDataForWSSClient;

import javax.inject.Named;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import uk.co.stwater.api.batch.AsyncBatchProcessor;
import uk.co.stwater.api.batch.BatchItem;
import uk.co.stwater.api.batch.BatchItemImpl;
import uk.co.stwater.api.batch.BatchJob;

@Named
@Component(service = RemovePaperlessProcessor.class, name = "uk.co.stwater.api.batch.paperless.RemovePaperlessProcessor")
public class RemovePaperlessProcessor extends AsyncBatchProcessor {

    private static Logger logger = LoggerFactory.getLogger(LogChannel.BATCH, RemovePaperlessProcessor.class);

    private static final String FULL_ACCOUNT = "FULL_ACCOUNT";
    private static final String LEGAL_ENTITY = "LEGAL_ENTITY";
    private static final String UNKNOWN_POSTCODE = "UNKNOWN";
    private static final String UPDATE = "U";
    private GetLEDataForWSSClient getLEDataForWSSClient;

    private SetLEDataForWSSClient setLEDataForWSSClient;

    private CreateContactClient createContactClient;

    private ListAccountRolesClient listAccountRolesClient;

    private ReferenceDataService referenceDataService;

    private ObjectMapper objectMapper = new ObjectMapper();
    
    @Reference
    public void setGetLEDataForWSSClient(GetLEDataForWSSClient getLEDataForWSSClient) {
        this.getLEDataForWSSClient = getLEDataForWSSClient;
    }

    @Reference
    public void setSetLEDataForWSSClient(SetLEDataForWSSClient setLEDataForWSSClient) {
        this.setLEDataForWSSClient = setLEDataForWSSClient;
    }

    @Reference
    public void setCreateContactClient(CreateContactClient createContactClient) {
        this.createContactClient = createContactClient;
    }

    @Reference
    public void setListAccountRolesClient(ListAccountRolesClient listAccountRolesClient) {
        this.listAccountRolesClient = listAccountRolesClient;
    }

    @Reference
    public void setReferenceDataService(ReferenceDataService referenceDataService) {
        this.referenceDataService = referenceDataService;
    }

    @Override
    public void checkCSVFile(CSVParser csvParser) {
        Map<String, Integer> headers = csvParser.getHeaderMap();
        if(!headers.containsKey(FULL_ACCOUNT) || !headers.containsKey(LEGAL_ENTITY)) {
            String msg = String.format("required headers missing %s and %s", FULL_ACCOUNT, LEGAL_ENTITY);
            throw new BatchException(msg);
        }
        csvParser.iterator().forEachRemaining(csvRecord -> {
            if(!canProcess(csvRecord) || csvRecord.get(FULL_ACCOUNT).length() != 10) {
                String msg = String.format("record %s found to be invalid", csvRecord.getRecordNumber());
                throw new BatchException(msg);
            }
        });
    }

    @Override
    public boolean canProcess(CSVRecord csvRecord) {
        boolean valid = csvRecord.isMapped(FULL_ACCOUNT) && csvRecord.isMapped(LEGAL_ENTITY);
        if (valid) {
            return (isNotEmpty(csvRecord.get(FULL_ACCOUNT)) && isNotEmpty(csvRecord.get(LEGAL_ENTITY)));
        }
        return valid;
    }

    @Override
    public BatchItem createBatchItem(BatchJob batchJob, CSVRecord csvRecord) {
        try {
            String fieldData = toJson(csvRecord);
            return new BatchItemImpl(batchJob, csvRecord.get(FULL_ACCOUNT), fieldData);
        } catch (JsonProcessingException e) {
            logger.error("Failed to serialize field data", e);
            return null;
        }
    }

    @Override
    public void execute(BatchItem item) {
        Long legalEntityId = getLegalEntityId(item.getFieldData());
        if (legalEntityId != 0L) {
            LERegistrationDataImpl leData = (LERegistrationDataImpl) getLEDataForWSSClient
                    .getLEData(new TargetAccountNumber(item.getTargetAccountNumber()), legalEntityId);
            leData.setPaperlessBilling(false);
            setLEDataForWSSClient.update(leData, new TargetAccountNumber(item.getTargetAccountNumber()),
                    UNKNOWN_POSTCODE, UPDATE);

            AccountRolesResponse accountRolesResponse = getAccountRole(
                    new TargetAccountNumber(item.getTargetAccountNumber()), legalEntityId);
            if(accountRolesResponse != null) {
                referenceDataService.getRefDataDesc(RefDataType.ACCOUNT_ROLE,
                        accountRolesResponse.getCustAccountRoleType(), leData.getUserName());

                createPaperlessRemovalContact(new TargetAccountNumber(item.getTargetAccountNumber()), legalEntityId);
            } else {
                logger.error("failed to create contact for paperless removal of {}", item.getTargetAccountNumber());
            }
        }
    }

    private AccountRolesResponse getAccountRole(TargetAccountNumber accountNumber, Long legalEntityId) {
        List<AccountRolesResponse> names = getAccountRoles(accountNumber);
        Optional<AccountRolesResponse> name = names.stream().filter(n -> n.getLENum() == legalEntityId).findFirst();
        return name.orElse(null);
    }

    private List<AccountRolesResponse> getAccountRoles(TargetAccountNumber accountNumber) {
        List<AccountRolesResponse> names = listAccountRolesClient.getAccountRoles(accountNumber);
        return names.stream().sorted()
                .filter(name -> !RoleType.P_COL_PRE_CLM.getValue().equalsIgnoreCase(name.getCustAccountRoleType()))
                .filter(name -> !RoleType.P_COL_POST_JDG.getValue().equalsIgnoreCase(name.getCustAccountRoleType()))
                .collect(Collectors.toList());
    }

    private void createPaperlessRemovalContact(TargetAccountNumber accountNumber,Long legalEntityNumber) {
        ContactNotesData contactNotesData = createContactClient.getContactNotesData(accountNumber, legalEntityNumber);
        CustomerContact customerContact = new WEB715Contact(accountNumber,contactNotesData);
        createContactClient.createContact(customerContact);
    }
    
    private Long getLegalEntityId(String json) {
        try {
            Content content = objectMapper.readValue(json, Content.class);
            return content.getLegalEntityId();
        } catch (Exception e) {
            String msg = String.format("Failed to deserialize json %s", json);
            logger.error(msg, e);
            return 0L;
        }
    }

    private String toJson(CSVRecord csvRecord) throws JsonProcessingException {
        Content content = new Content();
        content.legalEntityId = Long.parseLong(csvRecord.get(LEGAL_ENTITY));
        return objectMapper.writeValueAsString(content);
    }

    static class Content {
        @JsonProperty
        private long legalEntityId;

        long getLegalEntityId() {
            return legalEntityId;
        }
    }
}
