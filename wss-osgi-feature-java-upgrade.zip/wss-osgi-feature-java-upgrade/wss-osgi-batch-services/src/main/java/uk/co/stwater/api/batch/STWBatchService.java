package uk.co.stwater.api.batch;

import uk.co.stwater.api.batch.api.BatchJobDto;
import uk.co.stwater.api.batch.api.BatchRequestDto;
import java.util.List;

public interface STWBatchService {

    BatchJobDto createJob(BatchRequestDto stwBatchRequest);

    BatchJobDto queryJob(long jobId);

    List<BatchJobDto> listJobs();

    void cancelJob(long jobId);

}
