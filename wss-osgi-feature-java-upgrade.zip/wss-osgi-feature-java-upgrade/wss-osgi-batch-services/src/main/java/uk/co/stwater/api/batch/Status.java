package uk.co.stwater.api.batch;

public enum Status {
    QUEUED,
    LOCKED,
    COMPLETED,
    FAILED,
    CANCELLED
}
