package uk.co.stwater.api.batch.api;

import org.apache.commons.lang3.ArrayUtils;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import uk.co.stwater.api.batch.STWBatchService;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Named
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class BatchResource extends AbstractResource {

    private static final String HREF = "href";

    private static final String REQUEST_PARAMS_ERROR_CODE = "DM50.1";

    @Inject
    private STWBatchService stwBatchService;

    @POST
    public Response createBatch(BatchRequestDto stwBatchRequest, @Context HttpServletRequest httpServletRequest) {
        if (!isRequestValid(stwBatchRequest)) {
            ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.BATCH_SERVICES, REQUEST_PARAMS_ERROR_CODE,
                    "Missing required parameters, file, brand and command");
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }

        BatchJobDto stwBatchJob = stwBatchService.createJob(stwBatchRequest);
        URI location = UriBuilder.fromUri(URI.create("/batch")).path(Long.toString(stwBatchJob.getId())).build();
        URI link = UriBuilder.fromUri(URI.create(httpServletRequest.getPathInfo()))
                .path(Long.toString(stwBatchJob.getId())).build();
        return Response.accepted().location(location).link(link, HREF).build();
    }

    private static boolean isRequestValid(BatchRequestDto stwBatchRequest) {
        return (stwBatchRequest != null && ArrayUtils.isNotEmpty(stwBatchRequest.getData()) && isNotEmpty(stwBatchRequest.getBrand())
                && isNotEmpty(stwBatchRequest.getCommand()));
    }

}
