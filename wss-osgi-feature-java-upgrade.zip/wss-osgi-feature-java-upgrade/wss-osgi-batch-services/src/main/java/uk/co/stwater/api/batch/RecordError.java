package uk.co.stwater.api.batch;

import java.io.Serializable;
import java.util.List;
import java.util.function.Supplier;

/**
 *
 * @author Mark
 */
public class RecordError implements Serializable{

    private final long lineNumber;
    private final List<String> fields;
    private final transient  Supplier<String> messageFormatter;

    public RecordError(Supplier<String> messageFormatter, long lineNumber, List<String> fields) {
        this.messageFormatter = messageFormatter;
        this.lineNumber = lineNumber;
        this.fields = fields;
    }

    public String getMessage() {
        return messageFormatter.get();
    }

    public long getLineNumber() {
        return lineNumber;
    }

    public List<String> getFields() {
        return fields;
    }
    
    
}
