package uk.co.stwater.api.batch.config;

import uk.co.stwater.api.batch.BatchProcessor;

/**
 *
 * @author rtai
 */
public interface BatchConfigService {

    BatchProcessor getBatchProcessor(String command);

    int getBatchMaxFileSize();

    int getJobItemsSize();

    int getMinimumJobSize();

    int getMaximumJobSize();

    String getCronExpression();

    int getSchedulerThreadPoolSize();

    boolean isExecutorNode();

    int getMaximumRetryCount();
}
