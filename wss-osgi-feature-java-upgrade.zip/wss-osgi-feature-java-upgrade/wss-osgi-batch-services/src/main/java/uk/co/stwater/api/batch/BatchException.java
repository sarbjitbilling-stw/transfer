package uk.co.stwater.api.batch;

import java.util.ArrayList;
import java.util.List;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

/**
 * BatchException to represent exceptions thrown by the {@link STWBatchService}
 */
public class BatchException extends STWBusinessException {

    private final List<RecordError> errors = new ArrayList<>();

    public BatchException(String msg) {
        super(msg, DEFAULT_ERROR_CODE, ErrorCategory.BATCH_SERVICES);
    }
    
    public BatchException(String msg, List<RecordError> errors) {
        super(msg, DEFAULT_ERROR_CODE, ErrorCategory.BATCH_SERVICES);
        this.errors.addAll(errors);
    }

    public BatchException(String msg, Throwable ex) {
        super(msg, DEFAULT_ERROR_CODE, ErrorCategory.BATCH_SERVICES, ex);
    }

    public List<RecordError> getErrors() {
        return errors;
    }

    public void addAllErrors(List<RecordError> errors) {
        this.errors.addAll(errors);
    }

}
