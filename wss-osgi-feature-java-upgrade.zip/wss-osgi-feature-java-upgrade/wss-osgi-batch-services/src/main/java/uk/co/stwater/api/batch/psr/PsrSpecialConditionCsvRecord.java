package uk.co.stwater.api.batch.psr;

import java.time.LocalDate;
import java.util.Optional;

import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

@Data
public class PsrSpecialConditionCsvRecord {
    public static final String COLUMN_LEGAL_ENTITY_NUMBER = "LEGAL_ENTITY_NUMBER";
    public static final String COLUMN_FULL_ACCOUNT = "FULL_ACCOUNT";
    public static final String COLUMN_PROPERTY_ID = "PROPERTY_ID";
    public static final String COLUMN_START_DATE = "START_DATE";
    public static final String COLUMN_REVIEW_DATE = "REVIEW_DATE";
    public static final String COLUMN_END_DATE = "END_DATE";
    public static final String COLUMN_SPECIAL_CONDITION_TYPE = "SPECIAL_CONDITION_TYPE";
    public static final String COLUMN_BILL_PRINT_MEDIUM = "BILL_PRINT_MEDIUM";
    public static final String COLUMN_VULNERABLE_SUPPLY = "VULNERABLE_SUPPLY";
    public static final String COLUMN_VOICE_TEXT_SERVICE = "VOICE_TEXT_SERVICE";
    public static final String COLUMN_OUT_OF_HOURS_CONTACT = "OUT_OF_HOURS_CONTACT";
    public static final String COLUMN_EVACUATION_PLAN = "EVACUATION_PLAN";
    // also known as Duration
    public static final String COLUMN_VULNERABLE_TERM = "VULNERABLE_TERM";
    public static final String COLUMN_LANGUAGE_LINE = "LANGUAGE_LINE";

    private Long legalEntityNo;
    private TargetAccountNumber accountNumber;
    private Long propertyId;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate reviewDate;
    private String specialConditionType;
    private String billPrintMedium;
    private String vulnerableSupply;
    private String voiceTextService;
    private String outOfHoursContact;
    private String evacuationPlan;
    private String vulnerableTerm;
    private String languageLine;

    public PsrSpecialConditionCsvRecord() {
    }

    public PsrSpecialConditionCsvRecord(CSVRecord record) {
        legalEntityNo = getColumnValueTrimmed(record, COLUMN_LEGAL_ENTITY_NUMBER).map(this::toLong).orElse(null);
        accountNumber = getColumnValueTrimmed(record, COLUMN_FULL_ACCOUNT).map(this::toTargetAccountNumber).orElse(null);
        propertyId = getColumnValueTrimmed(record, COLUMN_PROPERTY_ID).map(this::toLong).orElse(null);
        startDate = getColumnValueTrimmed(record, COLUMN_START_DATE).map(this::toLocalDate).orElse(null);
        endDate = getColumnValueTrimmed(record, COLUMN_END_DATE).map(this::toLocalDate).orElse(null);
        reviewDate = getColumnValueTrimmed(record, COLUMN_REVIEW_DATE).map(this::toLocalDate).orElse(null);
        specialConditionType = getColumnValueTrimmed(record, COLUMN_SPECIAL_CONDITION_TYPE).orElse(null);
        billPrintMedium = getColumnValueTrimmed(record, COLUMN_BILL_PRINT_MEDIUM).orElse(null);
        vulnerableSupply = getColumnValueTrimmed(record, COLUMN_VULNERABLE_SUPPLY).orElse(null);
        voiceTextService = getColumnValueTrimmed(record, COLUMN_VOICE_TEXT_SERVICE).orElse(null);
        outOfHoursContact = getColumnValueTrimmed(record, COLUMN_OUT_OF_HOURS_CONTACT).orElse(null);
        evacuationPlan = getColumnValueTrimmed(record, COLUMN_EVACUATION_PLAN).orElse(null);
        vulnerableTerm = getColumnValueTrimmed(record, COLUMN_VULNERABLE_TERM).orElse(null);
        languageLine = getColumnValueTrimmed(record, COLUMN_LANGUAGE_LINE).orElse(null);
    }

    private Long toLong(String str) {
        return StringUtils.isNotBlank(str) ? Long.parseLong(str) : null;
    }

    private TargetAccountNumber toTargetAccountNumber(String str) {
        return StringUtils.isNotBlank(str) ? new TargetAccountNumber(str) : null;
    }

    private LocalDate toLocalDate(String str) {
        return StringUtils.isNotBlank(str) ? LocalDate.parse(str) : null;
    }

    private Optional<String> getColumnValueTrimmed(CSVRecord record, String columnName) {
        return getColumnValue(record, columnName).map(String::trim);
    }

    private Optional<String> getColumnValue(CSVRecord record, String columnName) {
        if (record.isMapped(columnName)) {
            return Optional.ofNullable(record.get(columnName));
        } else {
            return Optional.empty();
        }
    }

    @JsonIgnore
    public PsrRecordGroupIdentifier getBatchGroupId() {
        return new PsrRecordGroupIdentifier(legalEntityNo, accountNumber, propertyId);
    }

}
