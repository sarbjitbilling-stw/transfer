package uk.co.stwater.api.batch;

import uk.co.stwater.api.batch.config.BatchConfigService;
import org.apache.karaf.scheduler.Job;
import org.apache.karaf.scheduler.JobContext;
import org.apache.karaf.scheduler.ScheduleOptions;
import org.apache.karaf.scheduler.Scheduler;
import org.apache.karaf.scheduler.SchedulerError;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchItemEntityDao;
import uk.co.stwater.api.dao.batch.BatchStatus;
import uk.co.stwater.api.osgi.util.logging.LogChannel;
import uk.co.stwater.api.osgi.util.logging.LoggerFactory;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import uk.co.stwater.api.batch.config.BatchConfigServiceImpl;

@Named
@Singleton
@Component(service = {Job.class}, configurationPid = BatchConfigServiceImpl.PID, property = {
        Scheduler.PROPERTY_SCHEDULER_NAME + "=BatchJobScheduler"
})
public class BatchJobScheduler implements Job {

    private static final String SCHEDULER_NAME = "BatchJobScheduler";

    private static final Logger logger = LoggerFactory.getLogger(LogChannel.BATCH, BatchJobScheduler.class);

    private BatchItemEntityDao batchItemEntityDao;

    private BatchConfigService batchConfigService;

    private Scheduler scheduler;

    private String jobName;

    private int poolSize = 0;

    private ExecutorService executorService;

    @Reference
    public void setBatchItemEntityDao(BatchItemEntityDao bulkUploadBatchJobDao) {
        this.batchItemEntityDao = bulkUploadBatchJobDao;
    }

    @Reference
    public void setBatchConfigService(BatchConfigService batchConfigService) {
        this.batchConfigService = batchConfigService;
    }

    @Reference
    public void setScheduler(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    @Activate
    @Modified
    public void reschedule() {
        logger.debug("rescheduling after service modification");
        try {
            unscheduleExistingJobs();
            initializeSchedule();
        } catch (SchedulerError e) {
            logger.error("Unable to setup BatchJobScheduler schedule", e);
        }
    }

    @Override
    @Transactional
    public void execute(JobContext jobContext) {
        String lockOwner = getJobName().split(":")[1];
        List<BatchItemEntity> batchItemList = batchItemEntityDao
                .findNextItemsForTask(batchConfigService.getJobItemsSize(), lockOwner);

        if (batchItemList.isEmpty()) {
            logger.info("No batch items to process");
        } else {
            logger.info("Found {} batch items to process", batchItemList.size());
            // for each item, execute in a thread.
            List<Callable<BatchItemEntity>> tasks = new ArrayList<>();
            batchItemList.forEach(item -> tasks.add(() -> {
                String commandName = item.getBatchJob().getCommandName();
                BatchProcessor processor = batchConfigService.getBatchProcessor(commandName);
                processor.execute(BatchItemImpl.fromEntity(item));
                item.setStatus(BatchStatus.COMPLETED);
                batchItemEntityDao.update(item);
                return item;
            }));
            logger.debug("successfully scheduled {} records for batch processing", batchItemList.size());
            try {
                ExecutorService service = getExecutorService();
                service.invokeAll(tasks);
            } catch (Exception e) {
                logger.error("Exception during batch processing", e);
            }
        }
    }

    private ExecutorService getExecutorService() {
        if(executorService == null || poolSize != batchConfigService.getSchedulerThreadPoolSize()) {
            if (executorService != null) {
                executorService.shutdown();
            }
            poolSize = batchConfigService.getSchedulerThreadPoolSize();
            executorService = Executors.newFixedThreadPool(poolSize);
        }
        return executorService;
    }

    String getJobName() {
        return this.jobName;
    }

    private void unscheduleExistingJobs() throws SchedulerError {
        scheduler.getJobs().entrySet().stream()
                .filter(entry -> entry.getValue().name().contains(SCHEDULER_NAME))
                .forEach(entry -> {
                    logger.debug("unscheduling {}", entry.getValue().name());
                    scheduler.unschedule(entry.getValue().name());
                });
    }

    private void initializeSchedule() {
        try {
            boolean jobScheduled = scheduler.getJobs().entrySet().stream().anyMatch(entry -> entry.getKey().equals(this.jobName));
            if (!jobScheduled) {
                this.jobName = getClass().getName() + ':' + UUID.randomUUID();
                scheduler.schedule(this, scheduler.EXPR(batchConfigService.getCronExpression()).name(jobName));
                Optional<Map.Entry<String, ScheduleOptions>> optionsEntry =
                        scheduler.getJobs().entrySet().stream().filter(entry -> entry.getKey().equals(this.jobName)).findAny();
                if (optionsEntry.isPresent()) {
                    Map.Entry<String, ScheduleOptions> entry = optionsEntry.get();
                    this.jobName = entry.getValue().name();
                    String schedule =  entry.getValue().schedule();
                    logger.debug("scheduled job {} with schedule {}", this.jobName, schedule);
                }
            }
        } catch (SchedulerError schedulerError) {
            logger.error("Failed to schedule job", schedulerError);
        }
    }
}
