package uk.co.stwater.api.batch.api;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.time.LocalDate;
import uk.co.stwater.api.batch.Status;

@XmlRootElement(name = "BatchItem")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BatchItemDto {

    @XmlElement(name = "batchJobId")
    private long batchJobId;

    @XmlElement(name = "creationDateTime")
    private LocalDate creationDateTime;

    @XmlElement(name = "targetAccountNumber")
    private String targetAccountNumber;

    @XmlElement(name = "fieldData")
    private String fieldData;

    @XmlElement(name = "status")
    private Status status;

    private BatchItemDto() {}

    public BatchItemDto(long batchJobId, String targetAccountNumber, String fieldData, Status status,
                     LocalDate created) {
        this.batchJobId = batchJobId;
        this.targetAccountNumber = targetAccountNumber;
        this.fieldData = fieldData;
        this.status = status;
        this.creationDateTime = created;
    }

    public long getBatchJobId() {
        return batchJobId;
    }

    public void setBatchJobId(long batchJobId) {
        this.batchJobId = batchJobId;
    }

    public LocalDate getCreationDateTime() {
        return creationDateTime;
    }

    public void setCreationDateTime(LocalDate creationDateTime) {
        this.creationDateTime = creationDateTime;
    }

    public String getTargetAccountNumber() {
        return targetAccountNumber;
    }

    public void setTargetAccountNumber(String targetAccountNumber) {
        this.targetAccountNumber = targetAccountNumber;
    }

    public String getFieldData() {
        return fieldData;
    }

    public void setFieldData(String fieldData) {
        this.fieldData = fieldData;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
