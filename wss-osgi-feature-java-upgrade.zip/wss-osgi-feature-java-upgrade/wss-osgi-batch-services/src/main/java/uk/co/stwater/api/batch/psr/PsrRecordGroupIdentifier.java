package uk.co.stwater.api.batch.psr;

import lombok.Data;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

/**
 * Identifier for groups that {@code PsrSpecialConditionCsvRecord}'s will be
 * split into when creating {@code BatchItem}'s.
 * 
 * <p>
 * {@code PsrSpecialConditionCsvRecord} need to be grouped so that to avoid
 * Target data integrity constraint issues when multiple threads are processing
 * records.
 */
@Data
public class PsrRecordGroupIdentifier {
    private final Long legalEntityNo;
    private final TargetAccountNumber accountNumber;
    private final Long propertyId;
}
