package uk.co.stwater.api.batch;

import uk.co.stwater.api.batch.api.BatchJobDto;
import uk.co.stwater.api.batch.api.BatchItemDto;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchStatus;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class TestUtils {

    static BatchJobDto getTestBatchJob(long id) {
        BatchJobDto stwBatchJob = new BatchJobDto();
        stwBatchJob.setId(id);
        stwBatchJob.setStatus(Status.QUEUED);
        return stwBatchJob;
    }

    static List<BatchItemDto> getBatchItems(long jobId) {
        return Arrays.asList(getBatchItem(jobId, "111111111"),
                getBatchItem(jobId, "222222222"),
                getBatchItem(jobId, "333333333"),
                getBatchItem(jobId, "444444444"),
                getBatchItem(jobId, "555555555"));
    }

    static BatchItemDto getBatchItem(long id, String accountNumber) {
        return new BatchItemDto(id, accountNumber,"{\"foo\":\"bar\"}",Status.QUEUED, LocalDate.now());
    }

    public static BatchJobEntity getBatchJobEntity() {
        BatchJobEntity batchJobEntity = new BatchJobEntity();
        batchJobEntity.setUserId("author");
        batchJobEntity.setStatus(BatchStatus.QUEUED);
        batchJobEntity.setCommandName("remove-paperless");
        Date date = new Date();
        batchJobEntity.setDateCreated(date);
        batchJobEntity.setDateModified(date);
        return batchJobEntity;
    }

    public static BatchItemEntity getBatchItemEntity(BatchJobEntity job, String accountNumber) {
        return new BatchItemEntity(job, accountNumber,"{\"foo\":\"bar\"}");
    }
}
