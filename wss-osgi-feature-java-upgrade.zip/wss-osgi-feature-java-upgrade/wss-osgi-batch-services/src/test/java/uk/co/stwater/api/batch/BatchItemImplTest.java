package uk.co.stwater.api.batch;

import org.junit.Test;
import static org.junit.Assert.*;
import uk.co.stwater.api.dao.batch.BatchItemEntity;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchStatus;

/**
 *
 * @author Mark
 */
public class BatchItemImplTest {

    @Test
    public void testFromEntityWithNullStatus() {
        BatchJobEntity batchJobEntity = new BatchJobEntity();
        batchJobEntity.setId(1L);
        BatchItemEntity entity = new BatchItemEntity(batchJobEntity, "123", "Some data");

        BatchItem result = BatchItemImpl.fromEntity(entity);

        assertEquals("123", result.getTargetAccountNumber());
        assertEquals("Some data", result.getFieldData());
        assertEquals(Status.QUEUED, result.getStatus()); // defaults to QUEUED in BatchItemEntity constructor
    }
    
    @Test
    public void testFromEntity() {
        BatchJobEntity batchJobEntity = new BatchJobEntity();
        batchJobEntity.setId(1L);
        BatchItemEntity entity = new BatchItemEntity(batchJobEntity, "123", "Some data");
        entity.setStatus(BatchStatus.COMPLETED);
        
        BatchItem result = BatchItemImpl.fromEntity(entity);

        assertEquals("123", result.getTargetAccountNumber());
        assertEquals("Some data", result.getFieldData());
        assertEquals(Status.COMPLETED, result.getStatus());
    }
    
    @Test
    public void testToEntity() {
        BatchJobEntity batchJobEntity = new BatchJobEntity();
        BatchJob batchJob = new BatchJobImpl();
        BatchItemImpl batchItem = new BatchItemImpl(batchJob, "123", "Some data");
        batchItem.setStatus(Status.COMPLETED);
        
        BatchItemEntity result = BatchItemImpl.toEntity(batchJobEntity, batchItem);

        assertEquals("123", result.getTargetAccountNumber());
        assertEquals("Some data", result.getFieldData());
        assertEquals(BatchStatus.COMPLETED, result.getStatus()); 
    }

    @Test
    public void testToEntityWithNullStatus() {
        BatchJobEntity batchJobEntity = new BatchJobEntity();
        BatchJob batchJob = new BatchJobImpl();
        BatchItemImpl batchItem = new BatchItemImpl(batchJob, "123", "Some data");
        
        BatchItemEntity result = BatchItemImpl.toEntity(batchJobEntity, batchItem);

        assertEquals("123", result.getTargetAccountNumber());
        assertEquals("Some data", result.getFieldData());
        assertNull(result.getStatus());
    }

}
