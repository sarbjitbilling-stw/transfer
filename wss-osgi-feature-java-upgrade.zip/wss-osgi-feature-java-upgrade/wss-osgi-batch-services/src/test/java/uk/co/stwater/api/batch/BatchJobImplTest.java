package uk.co.stwater.api.batch;

import java.time.LocalDate;
import java.util.Date;
import org.junit.Test;
import static org.junit.Assert.*;
import uk.co.stwater.api.batch.api.BatchJobDto;
import uk.co.stwater.api.dao.batch.BatchJobEntity;
import uk.co.stwater.api.dao.batch.BatchStatus;
import uk.co.stwater.api.osgi.model.WSSSite;

/**
 *
 * @author Mark
 */
public class BatchJobImplTest {

    @Test
    public void testFromEntity() {
        
        Date now = new Date();
        
        BatchJobEntity entity = new BatchJobEntity();
        entity.setId(1L);
        entity.setDateCreated(now);
        entity.setCommandName("My Command");
        entity.setSite(WSSSite.STW);
        entity.setStatus(BatchStatus.FAILED);

        BatchJob result = BatchJobImpl.fromEntity(entity);

        assertEquals(1L, result.getId());
        assertEquals("My Command", result.getCommandName());
        assertEquals(Status.FAILED , result.getStatus() );
    }
    
    @Test
    public void testToBatchJobDto() {
        Date dateNow = new Date();
        LocalDate  localDateNow = new java.sql.Date(dateNow.getTime()).toLocalDate();
        
        BatchJob job = new BatchJobImpl();
        job.setId(1L);
        job.setDateModified(dateNow);
        job.setDateCreated(dateNow);

        BatchJobDto result = BatchJobImpl.toBatchJobDto(job);
        
        assertEquals(1L, result.getId());
        assertEquals(localDateNow, result.getDateCreated());
        assertEquals(localDateNow, result.getDateModified());
    }

    @Test
    public void testToBatchJobDtoWithNullDates() {
        BatchJob job = new BatchJobImpl();
        job.setId(1L);

        BatchJobDto result = BatchJobImpl.toBatchJobDto(job);
        
        assertEquals(1L, result.getId());
        assertNull(result.getDateCreated());
        assertNull(result.getDateModified());
        
    }

}
