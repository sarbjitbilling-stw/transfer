# wss-osgi

## Setting up development environment

To setup a local development environment make sure you have; _Java 8_, _Maven 3.5.x_ (or higher, Jenkins uses 3.8.7), _Karaf 4.2.15_ (http://archive.apache.org/dist/karaf/4.2.15/) and MySQL installed.

All ports used below can be changed in the relevant Karaf config files (inside the Karaf _/etc/_ directory).

### Building code with Maven
1. Download source code.
2. Run a `mvn clean install` in the root directory.

### Conecting to Datapower (Target/SAP)

We need a private key to connect to Target/SAP via DataPower. WSS goes directly to DataPower whereas CMP uses the Stunnel proxy that the CMP Billing UI uses to connect to Target (though you can also use DataPower for CMP too).

#### Conecting to Datapower directly (WSS way)

1. Get the keystore.jks + truststore.jks from a team member.
2. Configure Karaf startup script to use the keystore and truststore.

Example of updating the bash version of the Karaf startup script;

```bash
...

CLIENT_CERT=/Users/appsquad3/dev/apps/apache-karaf-4.1.1/etc/keystores/keystore.jks
SERVER_CERT=/Users/appsquad3/dev/apps/apache-karaf-4.1.1/etc/keystores/truststore.jks

EXTRA_JAVA_OPTS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.keyStore=${CLIENT_CERT} -Djavax.net.ssl.keyStorePassword=password -Djavax.net.ssl.trustStore=${SERVER_CERT} -Djavax.net.ssl.trustStorePassword=password"

main "$@"
```

#### Conecting to Datapower via Stunnel (CMP way)
1. Install Stunnel (https://www.stunnel.org/downloads.html).
2. Get the keystore.pem file from a team member.
3. Configure STunnel to use the PEM certificate to connect to DataPower.

Stunnel is a proxy that we configure to accept HTTP request on _localhost:8072_ (`accept = 127.0.0.1:8072`) and forward them onto DataPower _dpaopex.stwportal.co.uk:7000_ with HTTPS (`connect = dpaopex.stwportal.co.uk:7000`) using our client key (`cert = /Users/appsquad3/dev/keystores/keystore.pem`). We will then connect to _localhost:8072_ with Karaf in order to get to DataPower (Target/SAP).

Sample of Stunnel configuration (`foreground = yes` is not necessary);

```
foreground = yes

[target/sap client]
client = yes
accept = 127.0.0.1:8072
connect = dpaopex.stwportal.co.uk:7000
cert = /Users/appsquad3/dev/keystores/keystore.pem
```

### Karaf config files
Copy built config files from _wss-osgi-config/target/config/managed/local-dev/{CMP|WSS}_ to Karaf _/etc/_ config directory. CMP config files will use the Stunnel whereas the WSS ones use the direct connection to DataPower.

### Setting up database
Setup database with empty schema WSS running on _localhost:3306/WSS_ (the _wss-osgi-database-setup_ module will setup the schema when it is deployed to Karaf).

### Deploying bundle to Karaf
Start Karaf with `karaf clean debug`. This will clean Karaf's data directory as well as opening up a debug port to connect to as well.

The following lines inside the _org.apache.karaf.features.cfg_ config file mean that Karaf will automatically install all the wss-osgi bundles on start-up. If you run into some problems with this, removing _wss-osgi-application-dependencies_ and _wss-osgi-application-bundles_ from _featuresBoot_ and installing them manually with `feature:install {bundle-name}` instead might help.

```
#
# Comma separated list of features repositories to register by default
#
featuresRepositories = \
    ...
    mvn:uk.co.stwater.api/wss-osgi-karaf-features/LATEST/xml

#
# Comma separated list of features to install at startup
#
featuresBoot = \
    ...
    wss-osgi-application-dependencies, \
    wss-osgi-application-bundles
```

You should see some output in the console as Karaf sets up the database, using liquibase. It should end with something like;

```
...
INFO 11/02/20 15:15: liquibase: Reading from WSS.DATABASECHANGELOG
INFO 11/02/20 15:15: liquibase: Successfully released change log lock
INFO 11/02/20 15:15: liquibase: Successfully acquired change log lock
INFO 11/02/20 15:15: liquibase: Reading from WSS.DATABASECHANGELOG
INFO 11/02/20 15:15: liquibase: Successfully released change log lock
```

Run `list | grep wss` in the Karaf console to see which bundles are _Active_. After a bit you should see that every wss-osgi bundle becomes _Active_.

If quite a few bundles have failed to become _Active_ wait a little bit then try restarting the database bundle with the command `bundle:restart wss-osgi-userdb-provider`. Then wait after a bit after the command completes and if it has worked all the bundles should no be _Active_.

### Karaf watching local Maven repo for updates
Karaf picks up the wss-osgi bundles from the local Maven repository. If you run `bundle:watch *` Karaf will watch your local Maven repository for updates (see https://karaf.apache.org/manual/latest/#_watch), so if you run `mvn install` on a bundle Karaf will automatically pick it up and redeploy it. This command needs to be run each time you start Karaf.

### Partial builds
To build only the module that have been affect by changes you've made you can use the _gitflow-incremental-builder_ Maven plugin (see https://github.com/vackosar/gitflow-incremental-builder/). This Maven plugin compares you local changes to _origin/develop_ and build only the Maven modules that have been affect by you changes. By default this plugin is disabled but can be easily enabled. Some sample usages below but see the GitHub page (https://github.com/vackosar/gitflow-incremental-builder/tree/614ac5568dab2e0b223c617f656a93198db9df5b) for a full details (we use an old version for Intellij compatibility).

Safe incremental build including running tests of modules dependent on your changes;

```
mvn clean install -Dgib.enabled=true
```

Incremental build skipping tests of modules dependent on your changes;

```
mvn clean install -Dgib.enabled=true -Dgib.skipTestsForNotImpactedModules=true
```

