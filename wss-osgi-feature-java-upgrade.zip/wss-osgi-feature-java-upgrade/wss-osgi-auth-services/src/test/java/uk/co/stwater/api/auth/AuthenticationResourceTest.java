package uk.co.stwater.api.auth;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.anyString;

import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import java.util.Arrays;
import java.util.List;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.cxf.binding.BindingFactoryManager;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSBindingFactory;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.audit.AuditService;
import uk.co.stwater.api.osgi.model.LoginType;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.account.WSSIdentity;
import uk.co.stwater.api.osgi.util.JacksonContextResolver;
import uk.co.stwater.api.osgi.util.TestUtil;

/**
 * Created by rtai on 13/02/2017.
 */
// java17-t: fixme
@Ignore
@RunWith(MockitoJUnitRunner.Silent.class)
public class AuthenticationResourceTest {

    private static Server server;
    private final static String ENDPOINT_ADDRESS = TestUtil
        .getUrlWithRandomPort("http://localhost:%s/rest-auth/");
    private final static String STW = "STW";
    private static List<Object> providers;
    private static WebClient webClient;
    private static JAXRSServerFactoryBean serverFactoryBean;
   
    @Mock
    private AuthenticationService authenticationService;
    
    @Mock
    private AuditService auditService;
    
    @InjectMocks
    private AuthenticationResource authenticationResource = new AuthenticationResource();

    @BeforeClass
    public static void init() {
        providers = Arrays.asList(JacksonJaxbJsonProvider.class, JacksonContextResolver.class);
        serverFactoryBean = new JAXRSServerFactoryBean();
        serverFactoryBean.setProviders(providers);
        serverFactoryBean.setAddress(ENDPOINT_ADDRESS);
        serverFactoryBean.getBus().setProperty("skip.default.json.provider.registration", true);
        BindingFactoryManager manager = serverFactoryBean.getBus()
            .getExtension(BindingFactoryManager.class);
        JAXRSBindingFactory factory = new JAXRSBindingFactory();
        factory.setBus(serverFactoryBean.getBus());
        manager.registerBindingFactory(JAXRSBindingFactory.JAXRS_BINDING_ID, factory);
        webClient = WebClient.create(ENDPOINT_ADDRESS, providers).type(MediaType.APPLICATION_JSON);
    }

    @Before
    public void initialize() throws Exception {
        MockitoAnnotations.initMocks(authenticationResource);
        serverFactoryBean.setServiceBean(authenticationResource);
        serverFactoryBean.setResourceProvider(AuthenticationResource.class,
            new SingletonResourceProvider(authenticationResource, true));
        server = serverFactoryBean.create();
        webClient.reset();
    }

    @After
    public void tearDown() {
        server.stop();
        server.destroy();
    }

    @Test
    public void givenValidRequestThenAuthenticateSuccessfully() throws AuthenticationException {
        WSSIdentity wssIdentity = new WSSIdentity();
        wssIdentity.setWssUsername("admin");
        when(authenticationService.authenticate(any(UsernamePasswordToken.class)))
            .thenReturn(wssIdentity);

        UsernamePasswordToken usernamePasswordToken = new UsernamePasswordToken("admin",
            "Password123", LoginType.FULL, STW);
        Response response = webClient.type(MediaType.APPLICATION_JSON_TYPE).path("WSSAccounts")
            .path("Auth").put(usernamePasswordToken);
        assertNotNull(response);
        assertEquals(200, response.getStatus());

        verify(authenticationService, times(1)).authenticate(any(UsernamePasswordToken.class));
    }

    @Test
    public void givenInvalidRequestThenReturn401() throws AuthenticationException {
        doThrow(new AuthenticationException("Invalid Credentials")).
            when(authenticationService).authenticate(any(UsernamePasswordToken.class));

        UsernamePasswordToken usernamePasswordToken = new UsernamePasswordToken("admin",
            "Password123", LoginType.FULL, STW);
           
        Response response = webClient.type(MediaType.APPLICATION_JSON_TYPE).path("WSSAccounts")
            .path("Auth").put(usernamePasswordToken);
        assertNotNull(response);
        assertEquals(400, response.getStatus());

        verify(authenticationService, times(1)).authenticate(any(UsernamePasswordToken.class));
        verify(auditService, times(1)).audit(any(UsernamePasswordToken.class),anyString(),anyString());
        

    }
}
