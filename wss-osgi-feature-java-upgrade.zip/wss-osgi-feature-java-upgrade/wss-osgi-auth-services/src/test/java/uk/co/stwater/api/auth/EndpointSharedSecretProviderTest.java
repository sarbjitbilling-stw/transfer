package uk.co.stwater.api.auth;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.container.ContainerRequestContext;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EndpointSharedSecretProviderTest {

    @InjectMocks
    private EndpointSharedSecretProvider endpointSharedSecretProvider = new EndpointSharedSecretProvider();

    @Mock
    private AuthenticationConfigService authenticationConfigService;

    @Test
    public void callWithoutCorrectHeader() {
        ContainerRequestContext containerRequestContext = mock(ContainerRequestContext.class);
        when(authenticationConfigService.isEndpointSharedSecretEnabled()).thenReturn(true);
        when(authenticationConfigService.getEndpointSharedSecret()).thenReturn("hello");
        when(containerRequestContext.getHeaderString(anyString())).thenReturn(null);

        endpointSharedSecretProvider.filter(containerRequestContext);

        verify(containerRequestContext, times(1)).abortWith(any());
    }

    @Test
    public void callWithoutCorrectHeaderValue() {
        ContainerRequestContext containerRequestContext = mock(ContainerRequestContext.class);
        when(authenticationConfigService.isEndpointSharedSecretEnabled()).thenReturn(true);
        when(authenticationConfigService.getEndpointSharedSecret()).thenReturn("hello");
        when(containerRequestContext.getHeaderString(anyString())).thenReturn("goodbye");

        endpointSharedSecretProvider.filter(containerRequestContext);

        verify(containerRequestContext, times(1)).abortWith(any());
    }

    @Test
    public void callWithoutCorrectHeaderValueDisabled() {
        ContainerRequestContext containerRequestContext = mock(ContainerRequestContext.class);
        when(authenticationConfigService.isEndpointSharedSecretEnabled()).thenReturn(false);
        when(containerRequestContext.getHeaderString(anyString())).thenReturn("goodbye");

        endpointSharedSecretProvider.filter(containerRequestContext);

        verify(authenticationConfigService, times(0)).getEndpointSharedSecret();
        verify(containerRequestContext, times(0)).abortWith(any());
    }

    @Test
    public void callWithCorrectHeaderValue() {
        ContainerRequestContext containerRequestContext = mock(ContainerRequestContext.class);
        when(authenticationConfigService.isEndpointSharedSecretEnabled()).thenReturn(true);
        when(authenticationConfigService.getEndpointSharedSecret()).thenReturn("hello");
        when(containerRequestContext.getHeaderString(anyString())).thenReturn("hello");

        endpointSharedSecretProvider.filter(containerRequestContext);

        verify(containerRequestContext, times(0)).abortWith(any());
    }

}
