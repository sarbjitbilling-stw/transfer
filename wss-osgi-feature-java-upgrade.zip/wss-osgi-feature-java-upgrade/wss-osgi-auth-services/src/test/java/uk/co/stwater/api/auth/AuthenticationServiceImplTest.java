package uk.co.stwater.api.auth;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import uk.co.stwater.api.dao.EmailLinkDao;
import uk.co.stwater.api.dao.PersistentLoginDao;
import uk.co.stwater.api.dao.SocialLoginDao;
import uk.co.stwater.api.dao.SocialNonceDao;
import uk.co.stwater.api.dao.UserAuditDao;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.EmailLink;
import uk.co.stwater.api.dao.entity.LegalEntity;
import uk.co.stwater.api.dao.entity.PersistentLoginEntity;
import uk.co.stwater.api.dao.entity.SocialLogin;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.dao.entity.User.Site;
import uk.co.stwater.api.dao.entity.UserAudit;
import uk.co.stwater.api.dao.entity.UserProfile;
import uk.co.stwater.api.email.service.EmailConfigService;
import uk.co.stwater.api.email.service.EmailService;
import uk.co.stwater.api.osgi.model.LoginType;
import uk.co.stwater.api.osgi.model.RememberMeToken;
import uk.co.stwater.api.osgi.model.SocialAuth;
import uk.co.stwater.api.osgi.model.SocialProviderType;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.WSSAccount;
import uk.co.stwater.api.osgi.model.WSSLegalEntityAccount;
import uk.co.stwater.api.osgi.model.WSSSite;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.account.WSSIdentity;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.resetpassword.ResetPassword;
import uk.co.stwater.api.osgi.util.encryption.EncryptionService;
import uk.co.stwater.api.registration.SocialAuthGeneralException;
import uk.co.stwater.api.registration.SocialLoginResponse;
import uk.co.stwater.api.registration.SocialLoginService;
import uk.co.stwater.api.registration.SocialPermissionsException;
import uk.co.stwater.api.registration.WSSAccountService;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.anyVararg;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.co.stwater.api.auth.AuthenticationServiceImpl.INVALID_SOCIAL_LOGIN_CREDENTIALS_MESSAGE;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.PROVIDER_DM_PARAMETER;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.SOCIAL_AUTH_FAILURE_CODE;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.SOCIAL_AUTH_PERMISSIONS_CODE;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.SOCIAL_AUTH_PERMISSIONS_MSG;

/**
 * Created by rtai on 13/02/2017.
 */
// java17-t: fixme
@Ignore
@RunWith(MockitoJUnitRunner.Silent.class)
public class AuthenticationServiceImplTest {

    @InjectMocks
    private AuthenticationService authenticationService = new AuthenticationServiceImpl();

    @Mock
    private UserDao userDao;

    @Mock
    private EmailLinkDao emailLinkDao;

    @Mock
    private EmailService emailService;

    @Mock
    private EmailConfigService configService;

    @Mock
    private AuthenticationConfigService authenticationConfigService;

    @Mock
    private WSSAccountService wssAccountService;

    @Mock
    private EncryptionService encryptionService;

    @Mock
    private CreateContactClient createContactClient;

    @Mock
    private UserAuditDao auditDao;

    @Mock
    private PersistentLoginDao persistentLoginDao;

    @Mock
    private SocialLoginDao socialLoginDao;

    @Mock
    private SpecialConditionService specialConditionService;

    @Mock
    private SocialLoginService socialLoginService;

    @Mock
    private SocialNonceDao socialNonceDao;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Captor
    public ArgumentCaptor<String> stringArgumentCaptor;

    private final static String STW = "STW";
    private static final String LOGIN_JOURNEY = "LOGIN";
    private static final String DEFAULT_SERVER = "";
    private static final String DEFAULT_DM = "";

    @Before
    public void beforeEach() {
        when(specialConditionService.hasRestrictions(any(), any())).thenReturn(false);
    }

    @Test(expected = AuthenticationException.class)
    public void givenValidCredentialsThenAuthenticateSuccessfully() {

        UsernamePasswordToken token = new UsernamePasswordToken("90000267", "Password123", LoginType.FULL, STW);
        WSSAccount expected = new WSSAccount();
        expected.setId("9999");

        WSSLegalEntityAccount wssLegalEntityAccount = new WSSLegalEntityAccount(new TargetAccountNumber("1234567893"));
        wssLegalEntityAccount.setSmartBillsSpecialCondition(true);
        wssLegalEntityAccount.setWelshSpecialCondition(true);
        wssLegalEntityAccount.setSalaryDeduBillsSpecialCondition(true);
        expected.addWssLegalEntityAccounts(wssLegalEntityAccount);

        User user = new User();
        ArgumentCaptor<UserAudit> argumentCaptor = ArgumentCaptor.forClass(UserAudit.class);

        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.empty());
        when(userDao.findById(Long.valueOf(token.getUsername()))).thenReturn(Optional.of(user));
        when(wssAccountService.getAccountByUsername(anyString(), anyString()))
                .thenReturn(Collections.singletonList(expected));

        WSSIdentity wssIdentity = authenticationService.authenticate(token);
        
        assertEquals(expected.getId(), wssIdentity.getId());
        verify(auditDao, times(1)).log(argumentCaptor.capture());
        assertEquals(LOGIN_JOURNEY, argumentCaptor.getValue().getJourney());
        assertEquals(DEFAULT_SERVER, argumentCaptor.getValue().getServer());
        assertEquals(DEFAULT_DM, argumentCaptor.getValue().getDm());
        assertEquals("90000016", argumentCaptor.getValue().getUserId());
    }
    
    @Test(expected = AuthenticationException.class)
    public void givenInvalidCredentialsThenThrowAuthenticationException() throws AuthenticationException {
        UsernamePasswordToken token = new UsernamePasswordToken("admin", "admin", null, STW);
        authenticationService.authenticate(token);
    }

    @Test(expected = AuthenticationException.class)
    public void givenNoCredentialsThenThrowAuthenticationException() throws AuthenticationException {
        UsernamePasswordToken token = null;
        authenticationService.authenticate(token);
    }

    @Test(expected = AuthenticationException.class)
    public void givenEmptyCredentialsThenThrowAuthenticationException() throws AuthenticationException {
        UsernamePasswordToken token = new UsernamePasswordToken("", "", null, STW);
        authenticationService.authenticate(token);
    }

    @Test(expected = AuthenticationException.class)
    public void givenNullUsernameThenThrowAuthenticationException() throws AuthenticationException {
        UsernamePasswordToken token = new UsernamePasswordToken(null, "", LoginType.GUEST, STW);
        authenticationService.authenticate(token);
    }

    @Test(expected = AuthenticationException.class)
    public void givenNullPasswordThenThrowAuthenticationException() throws AuthenticationException {
        UsernamePasswordToken token = new UsernamePasswordToken("admin", null, LoginType.GUEST, STW);
        authenticationService.authenticate(token);
    }


    public void givenValidUsernameThenReturnInstanceOnForgottenPassword(SocialLogin socialLogin) {
        User user = new User();
        user.setEmail("test@severntrent.co.uk");
        user.setId(1L);
        user.setCount(1);
        user.setPassword("131fc4cef1fb954a15b425494ac6a478fa3b3dc0c425b15f3f1798145d5be9b4");
        user.setSecurityQuestion("What is yiur first car?");
        user.setSecurityAnswer("Opel");
        user.setRequiresPasswordReset(true);
        user.setFailedLoginAttemptCount(0);
        user.setAccountLockedUntil(new Date());
        user.setRegistrationType("full");
        user.setLoginWithEmail(true);
        user.setProfileUpdatedDate(new Date());
        user.setLegalEntities(new HashSet<>(Arrays.asList(new LegalEntity("1234", null))));

        if(socialLogin !=null) {
            user.getSocialLogins().add(socialLogin);
        }

        UserProfile userProfile = new UserProfile();
        user.setUserProfile(userProfile);
        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.of(user));

        String emailLinkPrefixValue = "https://myaccount.stwater.co.uk/wss/paperless";
        int hoursBeforeLinkExpires = 48;

        EmailLink emailLink = new EmailLink();
        emailLink.setId(12345L);
        emailLink.setToken("0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e");
        emailLink.setEmailLinkPrefix(emailLinkPrefixValue);
        when(wssAccountService.getAccountByWSSAccountId(eq(user.getId()), anyVararg())).thenReturn(Optional.empty());
        when(emailService.createEmailLink(any(User.class), anyString(), any(),
                any())).thenReturn(emailLink);
        when(authenticationConfigService.getEmailLinkPrefix()).thenReturn(emailLinkPrefixValue);
        when(authenticationConfigService.getHoursBeforeLinkExpires()).thenReturn(hoursBeforeLinkExpires);
        authenticationService.forgottenPassword(user.getUsername(), "STW");
        verify(emailService, times(1)).mailMergeAndSend(stringArgumentCaptor.capture(), any(), any(), any(), any());
    }

    @Test
    public void givenValidUsernameThenSendE25_1() {
        givenValidUsernameThenReturnInstanceOnForgottenPassword(null);
        assertEquals(AuthenticationServiceImpl.EMAIL_251_REQUEST_SUCCESS, stringArgumentCaptor.getValue());
    }

    @Test
    public void givenValidSocialAccountThenSendE32() {
        givenValidUsernameThenReturnInstanceOnForgottenPassword(new SocialLogin(SocialProviderType.FACEBOOK, "id", null));
        assertEquals(AuthenticationServiceImpl.EMAIL_33_SOCIAL_REQUEST_SUCCESS, stringArgumentCaptor.getValue());
    }

    @Test(expected = AuthenticationException.class)
    public void givenUnknownUsernameThenThrowAuthenticationException() {
        String emailLinkPrefixValue = "https://myaccount.%1$s.co.uk/my-account/reset-password";
        when(authenticationConfigService.getEmailLinkPrefix()).thenReturn(emailLinkPrefixValue);
        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.empty());
        authenticationService.forgottenPassword("test@stwater.co.uk", "STW");
    }

    @Test
    public void givenValidTokenThenReturnResetPassword() {
        String validToken = "0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e";
        EmailLink emailLink = new EmailLink();
        emailLink.setToken(validToken);
        emailLink.setId(1L);
        emailLink.setUser(new User());
        LocalDate localDate = LocalDate.now().plusDays(1L);
        emailLink.setExpiryDateTime(Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        when(emailLinkDao.find(anyLong())).thenReturn(Optional.of(emailLink));
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setToken(validToken);
        ResetPassword rv = authenticationService.verifyForgottenPasswordLink(resetPassword);
        assertNotNull(rv);
        assertEquals(resetPassword.getToken(), rv.getToken());
        verify(emailLinkDao, times(1)).find(anyLong());
    }

    @Test(expected = AuthenticationException.class)
    public void givenInvalidTokenThenThrowException() {
        String validToken = "0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e";
        EmailLink emailLink = new EmailLink();
        emailLink.setToken(validToken);
        emailLink.setId(1L);
        emailLink.setUser(new User());
        LocalDate localDate = LocalDate.now().plusDays(1L);
        emailLink.setExpiryDateTime(Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        when(emailLinkDao.find(anyLong())).thenReturn(Optional.of(emailLink));
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setToken(validToken + "3sdft");
        authenticationService.verifyForgottenPasswordLink(resetPassword);
        verify(emailLinkDao, times(1)).find(anyLong());
    }

    @Test(expected = AuthenticationException.class)
    public void givenExpiredTokenThenThrowException() {
        String validToken = "0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e";
        EmailLink emailLink = new EmailLink();
        emailLink.setToken(validToken);
        emailLink.setId(1L);
        emailLink.setUser(new User());
        LocalDate localDate = LocalDate.now().minusDays(1L);
        emailLink.setExpiryDateTime(Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        when(emailLinkDao.find(anyLong())).thenReturn(Optional.of(emailLink));
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setToken(validToken);
        authenticationService.verifyForgottenPasswordLink(resetPassword);
        verify(emailLinkDao, times(1)).find(anyLong());

    }

    @Test
    public void validateEmailLinkTokenAndIncrementGoodClickCountAndDisable() {
        EmailLink emailLink = new EmailLink();
        emailLink.setToken("0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e");
        emailLink.setId(1L);
        User user = new User();
        emailLink.setUser(user);
        LocalDate localDate = LocalDate.now().plusDays(1L);
        emailLink.setExpiryDateTime(Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        when(emailLinkDao.find(anyLong())).thenReturn(Optional.of(emailLink));

        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setToken("0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e");

        resetPassword = authenticationService.verifyForgottenPasswordLink(resetPassword);

        ArgumentCaptor<EmailLink> argumentCaptor = ArgumentCaptor.forClass(EmailLink.class);
        verify(emailLinkDao, times(1)).save(argumentCaptor.capture());
        assertEquals(0, (int) argumentCaptor.getValue().getGoodClickCount());
        assertEquals(0, (int) argumentCaptor.getValue().getBadClickCount());
    }

    @Test
    public void invalidateEmailLinkTokenAndIncrementBadClickCount() {
        EmailLink emailLink = new EmailLink();
        emailLink.setToken("0e13ff335f93d0d5ec1e84699d4d5328328c7b2151e4dbf2e3dd8a45138ebc1e");
        emailLink.setId(1L);
        User user = new User();
        emailLink.setUser(user);
        LocalDate localDate = LocalDate.now().plusDays(1L);
        emailLink.setExpiryDateTime(Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        when(emailLinkDao.find(anyLong())).thenReturn(Optional.of(emailLink));

        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setToken("0e13ff335f93d0d5ec1e84699d4d5328328c7b211e4dbf2e3dd8a45138ebc1e");

        try {
            resetPassword = authenticationService.verifyForgottenPasswordLink(resetPassword);
        } catch (AuthenticationException e) {
            // exception expected
        }

        ArgumentCaptor<EmailLink> argumentCaptor = ArgumentCaptor.forClass(EmailLink.class);
        verify(emailLinkDao, times(1)).save(argumentCaptor.capture());
        assertEquals(0, (int) argumentCaptor.getValue().getGoodClickCount());
        assertEquals(1, (int) argumentCaptor.getValue().getBadClickCount());

    }

    @Test
    /*
     * Given a the same email for HD and STW check correct one when authenticating
     */
    public void givenSameEmailForStwAndHdThenAuthenticateSuccessfully() {
        UsernamePasswordToken token = new UsernamePasswordToken("90000267", "Password123", LoginType.FULL, STW);
        User user = getUser("2671521d88b09a2109925d0f7758b368958e93ccbf68b683a3a973ba147c6fc0", User.Site.STW, 123l);

        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.of(user));
        when(userDao.findById(Long.valueOf(token.getUsername()))).thenReturn(Optional.of(user));
        when(wssAccountService.isAccountValidForLoginType(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(encryptionService.decrypt(anyString())).thenReturn("Password123");

        WSSIdentity wssIdentity = authenticationService.authenticate(token);
        assertEquals(user.getId(), wssIdentity.getId());
    }

    @Test
    public void givenDataforSTWUpdatePasswordSuccessfully() {
        long leId = 12345L;
        
        User user = getUser("2671521d88b09a2109925d0f7758b368958e93ccbf68b683a3a973ba147c6fc0", User.Site.STW, 123l);
        
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setUsername("1234567893");
        resetPassword.setPassword("2671521d88b09a2109925d0f7758b368958e93ccbf68b683a3a973ba147c6fc0");

        String accountNumber = "1234567893";
        TargetAccountNumber tan = new TargetAccountNumber(accountNumber);
        resetPassword.setAccountNumber(tan);
        resetPassword.setLegalEntityId(String.valueOf(leId));
        ContactDto contactDto = new ContactDto();
        contactDto.setFullName("MR John Smith");
        contactDto.setLeId("123456");
        contactDto.setEmail("test@test.com");
        contactDto.setAccountNumber(tan);

        ContactNotesData contactNotesData = mock(ContactNotesData.class);

        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.of(user));
        when(userDao.findById(Long.valueOf(resetPassword.getUsername()))).thenReturn(Optional.of(user));
        when(wssAccountService.isAccountValidForLoginType(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(encryptionService.decrypt(anyString())).thenReturn("Password123");
        when(createContactClient.getContactNotesData(any(TargetAccountNumber.class), anyLong()))
                .thenReturn(contactNotesData);

        resetPassword = authenticationService.updatePassword(resetPassword, contactDto, STW);

        assertNotNull(resetPassword);
    }

    @Test(expected = AuthenticationException.class)
    public void givenDataforHDUpdatePasswordUserNotFoundAuthenticationException() {
        long leId = 12345L;
        
        User user = getUser("2671521d88b09a2109925d0f7758b368958e93ccbf68b683a3a973ba147c6fc0", User.Site.HD, 123l);
        
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setId("1");
        resetPassword.setUsername("1234567893");
        resetPassword.setPassword("2671521d88b09a2109925d0f7758b368958e93ccbf68b683a3a973ba147c6fc0");

        String accountNumber = "1234567893";
        TargetAccountNumber tan = new TargetAccountNumber(accountNumber);
        resetPassword.setAccountNumber(tan);
        resetPassword.setLegalEntityId(String.valueOf(leId));
        ContactDto contactDto = new ContactDto();
        contactDto.setFullName("MR John Smith");
        contactDto.setLeId("123456");
        contactDto.setEmail("test@test.com");
        contactDto.setAccountNumber(tan);

        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.empty());
        when(userDao.findById(Long.valueOf(resetPassword.getUsername()))).thenReturn(Optional.of(user));
        when(wssAccountService.isAccountValidForLoginType(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(encryptionService.decrypt(anyString())).thenReturn("Password123");

        resetPassword = authenticationService.updatePassword(resetPassword, contactDto, STW);

    }
    
    @Test
    public void givenUserWithNoSmartConditionLoggedInSuccessfullyThenLogTheJourneyAuditTable() {
        
        UsernamePasswordToken token = new UsernamePasswordToken("90000267", "Password123", LoginType.FULL, STW);
        
        WSSAccount expected = new WSSAccount();
        expected.setId("9999");

        WSSLegalEntityAccount wssLegalEntityAccount = new WSSLegalEntityAccount(new TargetAccountNumber("1234567893"));
        expected.addWssLegalEntityAccounts(wssLegalEntityAccount);

        User user = getUser("6a08895250adfe83237e64b904cef4feaed20929286959f402b34011e51af957", User.Site.HD, 123l);
        user.setUsername("90000267");   
        
        ArgumentCaptor<UserAudit> argumentCaptor = ArgumentCaptor.forClass(UserAudit.class);
        
        when(userDao.findUserByEmailOrUsernameForSite(anyString(), anyString())).thenReturn(Optional.of(user));
        when(userDao.findById(eq(Long.valueOf(token.getUsername())))).thenReturn(Optional.of(user));
        when(wssAccountService.getAccountByUsername(anyString(), anyString()))
                .thenReturn(Collections.singletonList(expected));
        when(wssAccountService.isAccountValidForLoginType(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), any(LoginType.class))).thenReturn(Boolean.TRUE);
        when(encryptionService.decrypt(anyString())).thenReturn("Password123");
        
        WSSIdentity wssIdentity = authenticationService.authenticate(token);
       
        assertEquals(user.getId(), wssIdentity.getId());
        verify(auditDao, times(1)).log(argumentCaptor.capture());
        assertEquals(LOGIN_JOURNEY, argumentCaptor.getValue().getJourney());
        assertEquals(DEFAULT_SERVER, argumentCaptor.getValue().getServer());
        assertEquals(DEFAULT_DM, argumentCaptor.getValue().getDm());
        assertEquals("123", argumentCaptor.getValue().getUserId());
        
    }
    
    @Test
    public void authenticateUsernamePasswordBlokedByLoginSpecialConditionRestriction() {
        UsernamePasswordToken token = new UsernamePasswordToken("wssUsername", "Password123", LoginType.FULL, STW);
        User user = getUser("Password1111", User.Site.STW, 56432345L);
        user.setUsername(token.getUsername());

        when(userDao.findUserByEmailOrUsernameForSiteFilteredByUserRegistrationType(token.getUsername(),
                token.getSite())).thenReturn(Optional.of(user));
        when(wssAccountService.isAccountValidForLoginType(any(), any())).thenReturn(true);
        when(wssAccountService.hasActiveAccount(any(), any())).thenReturn(true);
        when(specialConditionService.hasRestrictions(user, SpecialConditionAction.LOGIN_CHECK)).thenReturn(true);

        AuthenticationException actual = assertThrows(AuthenticationException.class,
                () -> authenticationService.authenticate(token));

        assertEquals("Login blocked by special condition restriction", actual.getMessage());
    }

    @Test
    public void authenticateRememberMeBlokedByLoginSpecialConditionRestriction() {
        Long userId = 24652L;
        String username = "customerUsername";
        String series = "series-12543";
        String token = "6a08895250badfe83237e64b90";
        RememberMeToken rememberMetoken = new RememberMeToken(series, token, username);
        User user = getUser("Password123", User.Site.STW, userId);
        user.setUsername(username);
        PersistentLoginEntity persistentLogin = new PersistentLoginEntity(username, userId);
        persistentLogin.setToken(token);
        Date invalidatedDate = java.sql.Date.valueOf(LocalDate.now().plusDays(4));
        persistentLogin.setInvalidatedDate(invalidatedDate);

        when(persistentLoginDao.findPersistentLoginEntity(series)).thenReturn(persistentLogin);
        when(userDao.findById(userId)).thenReturn(Optional.of(user));
        when(wssAccountService.isAccountValidForLoginType(userId, LoginType.FULL)).thenReturn(true);
        when(wssAccountService.hasActiveAccount(userId, LoginType.FULL)).thenReturn(true);
        when(specialConditionService.hasRestrictions(user, SpecialConditionAction.LOGIN_CHECK)).thenReturn(true);

        AuthenticationException actual = assertThrows(AuthenticationException.class,
                () -> authenticationService.authenticate(rememberMetoken));

        assertEquals("Login blocked by special condition restriction", actual.getMessage());
        assertEquals(AuthenticationServiceImpl.DM_CODE_LOGIN_BLOCKED_BY_SPECIAL_CONDITION_RESTRICTION,
                actual.getCode());
    }

    @Test
    public void testFailedGoogleLogin() {
        UsernamePasswordToken token = new UsernamePasswordToken("wssUsername", null, LoginType.FULL, STW);
        SocialAuth socialAuth = new SocialAuth();
        socialAuth.setSocialProvider(SocialProviderType.GOOGLE);
        socialAuth.setJwt("something");
        token.setSocialAuth(socialAuth);

        when(socialLoginService.authenticate(any(), any())).thenThrow(new SocialAuthGeneralException(SocialProviderType.GOOGLE, "Unable to authorise social login"));

        AuthenticationException actual = assertThrows(AuthenticationException.class,  () -> authenticationService.authenticate(token));

        verify(socialLoginService).authenticate(socialAuth, WSSSite.STW);
        assertEquals("Unable to authorise social login", actual.getMessage());
    }

    @Test
    public void testFailedFacebookLogin() {
        UsernamePasswordToken token = new UsernamePasswordToken("wssUsername", null, LoginType.FULL, STW);
        SocialAuth socialAuth = new SocialAuth();
        socialAuth.setSocialProvider(SocialProviderType.FACEBOOK);
        socialAuth.setSocialId("something");
        socialAuth.setAccessToken("something");
        token.setSocialAuth(socialAuth);

        when(socialLoginService.authenticate(any(), any())).thenThrow(
                new SocialAuthGeneralException(SocialProviderType.FACEBOOK, "Unable to authorise social login"));

        AuthenticationException actual = assertThrows(AuthenticationException.class,  () -> authenticationService.authenticate(token));

        verify(socialLoginService).authenticate(socialAuth, WSSSite.STW);
        assertEquals("Unable to authorise social login", actual.getMessage());
        assertEquals(SOCIAL_AUTH_FAILURE_CODE, actual.getErrorCode());
        assertEquals(SocialProviderType.FACEBOOK.getDescription(), actual.getErrorDto().getFieldData().get(PROVIDER_DM_PARAMETER));
    }

    @Test
    public void testFailedPermissionsFacebookLogin() {
        UsernamePasswordToken token = new UsernamePasswordToken("wssUsername", null, LoginType.FULL, STW);
        SocialAuth socialAuth = new SocialAuth();
        socialAuth.setSocialProvider(SocialProviderType.FACEBOOK);
        socialAuth.setAccessToken("something");
        socialAuth.setSocialId("something");
        token.setSocialAuth(socialAuth);

        when(socialLoginService.authenticate(any(), any())).thenThrow(new SocialPermissionsException(SocialProviderType.FACEBOOK, SOCIAL_AUTH_PERMISSIONS_MSG));

        AuthenticationException actual = assertThrows(AuthenticationException.class,  () -> authenticationService.authenticate(token));

        verify(socialLoginService).authenticate(socialAuth, WSSSite.STW);
        assertEquals(SOCIAL_AUTH_PERMISSIONS_MSG, actual.getMessage());
        assertEquals(SOCIAL_AUTH_PERMISSIONS_CODE, actual.getErrorCode());
        assertEquals(SocialProviderType.FACEBOOK.getDescription(), actual.getErrorDto().getFieldData().get(PROVIDER_DM_PARAMETER));
    }

    @Test
    public void testFailedAppleLogin() {
        UsernamePasswordToken token = new UsernamePasswordToken("wssUsername", null, LoginType.FULL, STW);
        SocialAuth socialAuth = new SocialAuth();
        socialAuth.setSocialProvider(SocialProviderType.APPLE);
        socialAuth.setAccessToken("acctoken");
        socialAuth.setJwt("thejwt");
        token.setSocialAuth(socialAuth);

        when(socialLoginService.authenticate(any(), any()))
                .thenThrow(new SocialAuthGeneralException(SocialProviderType.APPLE, "Unable to authorise social login"));

        AuthenticationException actual = assertThrows(AuthenticationException.class,  () -> authenticationService.authenticate(token));

        verify(socialLoginService).authenticate(socialAuth, WSSSite.STW);
        assertEquals(SOCIAL_AUTH_FAILURE_CODE, actual.getErrorCode());
        assertEquals(SocialProviderType.APPLE.getDescription(), actual.getErrorDto().getFieldData().get(PROVIDER_DM_PARAMETER));
    }

    @Test
    public void testValidSocialLoginButNotRegistered() {
        UsernamePasswordToken token = new UsernamePasswordToken("90000267", null, LoginType.FULL, STW);
        SocialAuth socialAuth = new SocialAuth();
        socialAuth.setSocialProvider(SocialProviderType.GOOGLE);
        socialAuth.setJwt("something");
        token.setSocialAuth(socialAuth);

        when(wssAccountService.isAccountValidForLoginType(anyLong(), eq(LoginType.FULL))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), eq(LoginType.FULL))).thenReturn(Boolean.TRUE);
        when(socialLoginDao.findUser(SocialProviderType.GOOGLE, "socialid", WSSSite.STW)).thenReturn(Optional.empty());

        when(socialLoginService.authenticate(any(), any())).thenReturn(new SocialLoginResponse("ident", "socialid", "nonce"));

        thrown.expect(AuthenticationException.class);
        thrown.expectMessage(INVALID_SOCIAL_LOGIN_CREDENTIALS_MESSAGE);
        authenticationService.authenticate(token);
    }

    @Test
    public void testValidSocialLoginSaveNonce() {
        UsernamePasswordToken token = new UsernamePasswordToken("90000267", null, LoginType.FULL, STW);
        SocialAuth socialAuth = new SocialAuth();
        socialAuth.setSocialProvider(SocialProviderType.GOOGLE);
        socialAuth.setJwt("something");
        token.setSocialAuth(socialAuth);

        User user = getUser(null, Site.STW, 1233L);

        when(wssAccountService.isAccountValidForLoginType(anyLong(), eq(LoginType.FULL))).thenReturn(Boolean.TRUE);
        when(wssAccountService.hasActiveAccount(anyLong(), eq(LoginType.FULL))).thenReturn(Boolean.TRUE);
        when(userDao.findUserByEmailOrUsernameForSite(any(), any())).thenReturn(Optional.of(user));
        when(socialLoginDao.findUser(SocialProviderType.GOOGLE, "socialid", WSSSite.STW))
                .thenReturn(Optional.of(new SocialLogin(SocialProviderType.FACEBOOK, "id", user)));

        when(socialLoginService.authenticate(any(), any())).thenReturn(new SocialLoginResponse("ident", "socialid", "nonce"));

        authenticationService.authenticate(token);
        verify(socialNonceDao, times(1)).save(any());
    }

    private User getUser(String password, Site site, Long id) {
        User user = new User();
        user.setPassword(password);
        user.setSite(site);
        user.setId(id);
        return user;
    }

}
