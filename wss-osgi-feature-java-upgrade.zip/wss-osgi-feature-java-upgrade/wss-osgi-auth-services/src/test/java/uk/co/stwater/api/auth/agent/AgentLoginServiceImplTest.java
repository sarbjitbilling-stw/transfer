/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.auth.agent;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.apache.commons.codec.digest.DigestUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mark
 */
public class AgentLoginServiceImplTest {
    
    public AgentLoginServiceImplTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSampleFromUSD() throws UnsupportedEncodingException {
        String expextedResult = "15efdc3bc2367f58d3400144bc388dcfcb10021e";
        String payload = "{id: \"123\", name: \"test\"}";
        payload = URLEncoder.encode(payload, "UTF-8");
        String secret = "We Ar3 The Ch4mp1ons";
        String actualResult = DigestUtils.sha1Hex(secret + payload);
        assertEquals(expextedResult, actualResult);
    }
    
   
}
