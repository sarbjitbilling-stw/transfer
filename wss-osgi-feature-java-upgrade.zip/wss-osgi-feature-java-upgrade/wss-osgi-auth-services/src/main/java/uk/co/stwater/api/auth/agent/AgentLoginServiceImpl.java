/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.auth.agent;

import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response.Status;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;

import uk.co.stwater.api.osgi.model.LoginType;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.WSSAccount;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.logging.LogManager;
import uk.co.stwater.api.registration.UsernameService;
import uk.co.stwater.api.registration.WSSAccountFilter;
import uk.co.stwater.api.registration.WSSAccountService;

/**
 *
 * @author Mark
 */
@Named
@OsgiServiceProvider(classes = {AgentLoginService.class})
public class AgentLoginServiceImpl implements AgentLoginService {
    
    private static final String DEFAULT_SURNAME = "Agent";
    private static final String DEFAULT_FIRSTNAME = "STW";
    
    Logger log = LogManager.classLogger();
    
    @Inject
    @OsgiService
    WSSAccountService wssAccountService;
    
    @Inject
    @OsgiService
    private UsernameService usernameService;
    
    @Override
    public UsernamePasswordToken getAgentLogin(long wssAccountId) {
        
        //get WSSAccount we want to impersonate
        WSSAccount wssAccount = getWSSAccount(wssAccountId);
     
        //update values so we can create a new guest login from existing wssAccount
        wssAccount.setId(null);
        wssAccount.setWssPassword(null);
        //does not realy matter which surname we pick here we just need a surname
        wssAccount.setSurname(wssAccount.getWssLegalEntities().get(0).getCustomer().getLastName());
        //We use guest here coz we want a GUEST type login created
        wssAccount.setRegistrationType("GUEST");
        wssAccount.setPartialRegistration(true);
         //get new one time username & password to compleat guest registration
        String userName = generateUaername();
        wssAccount.setWssUsername(userName);
        wssAccount = createGuestAccount(wssAccount);
        
        wssAccount.setPartialRegistration(false);
        wssAccount = completeGuestRegistration(wssAccount);
        return new UsernamePasswordToken(wssAccount.getId(), wssAccount.getWssPassword(), LoginType.AGENT, wssAccount.getSite().name());
    }
    
    private WSSAccount getWSSAccount(final long wssAccountId){
                Optional<WSSAccount> optionalWssAccount
                    = wssAccountService.getAccountByWSSAccountId(wssAccountId,
                            WSSAccountFilter.FULL,
                            Expands.customer, Expands.account);
                
        return optionalWssAccount.orElseThrow(() -> {
            String msg = String.format("Unable to retive account info for WSSAccount %1$d", wssAccountId);
            return new STWBusinessException(msg, Status.NOT_FOUND);
        });
    }
    
    private WSSAccount createGuestAccount(WSSAccount wssAccount){
        return wssAccountService.createAccount(wssAccount);
    }
    
    private WSSAccount completeGuestRegistration(WSSAccount wssAccount){
        return wssAccountService.updateWSSAccount(wssAccount, null);
    }
    
    private String generateUaername(){
        //this will be deleted as soon as login is compleat 
        return usernameService.getUniqueUserName(DEFAULT_FIRSTNAME, DEFAULT_SURNAME);
    }

}