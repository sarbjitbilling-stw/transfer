package uk.co.stwater.api.auth;

import uk.co.stwater.api.osgi.model.RememberMeToken;
import uk.co.stwater.api.osgi.model.ResetUsername;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.account.WSSIdentity;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.resetpassword.ResetPassword;
import uk.co.stwater.api.osgi.model.wss.authentication.WSSContext;

/**
 * AuthenticationService for authenticating users into WSS application Created
 * by rtai on 09/02/2017.
 */
public interface AuthenticationService {

    /**
     * Validates the given {@link UsernamePasswordToken} and returns a
     * {@link WSSContext} if successful. Otherwise throws an
     * {@link AuthenticationException}.
     *
     * @param usernamePasswordToken
     * @return WSSAccount if authentication is successful.
     * @throws AuthenticationException
     */
    WSSIdentity authenticate(UsernamePasswordToken usernamePasswordToken) throws AuthenticationException;

    WSSIdentity authenticate(RememberMeToken rememberMeTokenToken) throws AuthenticationException;

    ResetPassword forgottenPassword(String username, String site) throws AuthenticationException;

    ResetPassword verifyForgottenPasswordLink(ResetPassword resetPassword) throws AuthenticationException;

    ResetPassword updatePassword(ResetPassword resetPassword, ContactDto contactDto, String site) throws AuthenticationException;

    ResetPassword resetPassword(ResetPassword resetPassword) throws AuthenticationException;

    ResetUsername forgottenEmail(String email, String site) throws AuthenticationException;

    RememberMeToken generateRememberMeToken(Long wssUserId) throws AuthenticationException;

    void invalidateRememberMeToken(RememberMeToken rememberMeTokenToken) throws AuthenticationException;
}
