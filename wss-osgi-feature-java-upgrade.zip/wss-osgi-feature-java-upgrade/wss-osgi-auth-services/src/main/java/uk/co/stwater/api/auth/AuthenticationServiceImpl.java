package uk.co.stwater.api.auth;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.auth.contact.PasswordChangeContact;
import uk.co.stwater.api.dao.EmailLinkDao;
import uk.co.stwater.api.dao.PasswordEncoder;
import uk.co.stwater.api.dao.PersistentLoginDao;
import uk.co.stwater.api.dao.SocialLoginDao;
import uk.co.stwater.api.dao.SocialNonceDao;
import uk.co.stwater.api.dao.UserAuditDao;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.AccountEntity;
import uk.co.stwater.api.dao.entity.EmailLink;
import uk.co.stwater.api.dao.entity.LegalEntity;
import uk.co.stwater.api.dao.entity.PersistentLoginEntity;
import uk.co.stwater.api.dao.entity.SocialLogin;
import uk.co.stwater.api.dao.entity.SocialNonceEntity;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.dao.entity.UserAudit;
import uk.co.stwater.api.email.service.EmailService;
import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.LoginType;
import uk.co.stwater.api.osgi.model.RememberMeToken;
import uk.co.stwater.api.osgi.model.ResetUsername;
import uk.co.stwater.api.osgi.model.SocialAuth;
import uk.co.stwater.api.osgi.model.SocialProviderType;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.WSSAccount;
import uk.co.stwater.api.osgi.model.WSSSite;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.account.WSSIdentity;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.resetpassword.ResetPassword;
import uk.co.stwater.api.osgi.util.Constants;
import uk.co.stwater.api.osgi.util.Expands;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.encryption.EncryptionService;
import uk.co.stwater.api.registration.SocialLoginResponse;
import uk.co.stwater.api.registration.SocialLoginService;
import uk.co.stwater.api.registration.SocialPermissionsException;
import uk.co.stwater.api.registration.SocialTokenExpiredException;
import uk.co.stwater.api.registration.WSSAccountService;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.NonUniqueResultException;
import javax.transaction.Transactional;
import javax.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static uk.co.stwater.api.osgi.model.RememberMeToken.getSeriesFromEncodedValue;
import static uk.co.stwater.api.osgi.model.RememberMeToken.getTokenFromEncodedValue;
import static uk.co.stwater.api.registration.WSSAccountResource.TOKEN_EXPIRED_CODE;
import static uk.co.stwater.api.registration.WSSAccountService.MAX_ATTEMPT_UNTIL_LOCKED;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.PROVIDER_DM_PARAMETER;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.SOCIAL_AUTH_FAILURE_CODE;
import static uk.co.stwater.api.registration.WSSAccountServiceImpl.SOCIAL_AUTH_PERMISSIONS_CODE;

/**
 * Created by rtai on 09/02/2017.
 */
@Named
@OsgiServiceProvider(classes = { AuthenticationService.class })
public class AuthenticationServiceImpl implements AuthenticationService {
    private static Logger log = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

    private static final String NO_CREDENTIALS_MESSAGE = "No credentials supplied";

    private static final String INVALID_CREDENTIALS_MESSAGE = "Invalid Credentials supplied";

    public static final String INVALID_SOCIAL_LOGIN_CREDENTIALS_MESSAGE = "Invalid Social Login Credentials supplied";
    private static final String INVALID_SOCIAL_LOGIN_CREDENTIALS_DM = "DM1.46";

    private static final String ACCOUNT_LOCKED_CODE_MESSAGE = "Your account has been locked, please try again in an hour";

    private static final String ACCOUNT_LOCKED_CODE = "DM3.14";

    private static final String INVALID_CREDENTIAL_CODE = "DM3.1";

    private static final String DM3_13 = "DM3.13";

    protected static final String EMAIL_251_REQUEST_SUCCESS = "E25.1";
    protected static final String EMAIL_33_SOCIAL_REQUEST_SUCCESS = "E33";
    private static final String EMAIL_252_REQUEST_SUCCESS = "E25.2";
    public static final String FULLNAME_KEY = "${fullName}";
    public static final String URL_TEMPLATE_KEY = "https://emailLink";

    public static final String SPACE = "";

    private static final String LOGIN_JOURNEY = "LOGIN";
    private static final String DEFAULT_SERVER = "";
    private static final String DEFAULT_DM = "";
    private static final int REMEMBER_ME_MONTHS = 1;


    @Inject
    @OsgiService
    private UserDao userDao;

    @Inject
    @OsgiService
    private SocialLoginDao socialLoginDao;

    @Inject
    @OsgiService
    private UserAuditDao auditDao;

    @Inject
    @OsgiService
    private PersistentLoginDao persistentLoginDao;

    @Inject
    @OsgiService
    private EmailLinkDao emailLinkDao;

    @Inject
    @OsgiService
    private EmailService emailService;

    @Inject
    private AuthenticationConfigService authenticationConfigService;

    @Inject
    @OsgiService
    private WSSAccountService wssAccountService;

    @Inject
    @OsgiService
    private EncryptionService encryptionService;

    @Inject
    @OsgiService
    private CreateContactClient createContactClient;

    @Inject
    @OsgiService
    private SpecialConditionService specialConditionService;

    @Inject
    @OsgiService
    private SocialLoginService socialLoginService;


    @OsgiService
    @Inject
    private SocialNonceDao socialNonceDao;

    private static final String DONT_REPLY_EMAIL = "donotreply@severntrent.co.uk";

    private static final String USER_REQUESTED_REASON = "User requested a password reset from within the Online Account Management of Web Self Service";

    private static final String FULL = "FULL";

    private static final String GUEST = "GUEST";

    private static final String AGENT = "AGENT";

    private static final String DEFAULT_ERROR_CODE = "DM1.00";

    private static final int MAX_ATTEMPT = 5;

    private static final long lockDuration = 3600000; // = 1hour in milies ie (60min*60sec*1000ms);

    private static final String DM31_CODE = "DM31";
    private static final String DM31_MESSAGE = "Sorry, you cannot log into this account as you're no longer responsibility for it. If you need help with this call us on 0345 604 0785. We're here from 8am until 8pm Monday to Friday and 8am until 1pm on Saturdays to help.";

    private static final String DM3_11_CODE = "DM3.11";

    private static final String EAUN = "EAUN";

    private static final String DM_3_21_CODE = "DM3.21";
    private static final String DM_3_21_MESSAGE = "DM3.21";

    static final String DM_CODE_LOGIN_BLOCKED_BY_SPECIAL_CONDITION_RESTRICTION = "DM8";

    @Override
    public WSSIdentity authenticate(UsernamePasswordToken usernamePasswordToken) throws AuthenticationException {
        log.debug("authenticate start");

        if (!isValid(usernamePasswordToken)) {
            log.warn(NO_CREDENTIALS_MESSAGE);
            throw new AuthenticationException(DEFAULT_ERROR_CODE, NO_CREDENTIALS_MESSAGE);
        }

        boolean isSocialLogin = usernamePasswordToken.isSocialAuth();
        Optional<User> optionalUser;

        if (isSocialLogin) {
            log.debug("Verify social login");
            SocialLoginResponse socialLoginResponse = verifyCredentials(usernamePasswordToken);
            // email address:
            usernamePasswordToken.setUsername(socialLoginResponse.getIdentifier());
            // some domainspecific identifier like 123323121311243123 :
            usernamePasswordToken.setSocialId(socialLoginResponse.getSocialId());

            log.debug("### performing social login");
            User user = findSocialUser(usernamePasswordToken);

            if (user != null) {
                log.debug("### login via social id success, user found, set full user details, continue login flow as normal");
                usernamePasswordToken.setUsername(user.getUsername());
                usernamePasswordToken.setPassword(user.getPassword());
            } else {
                log.debug("### login via social id failed, reject login");
                log.warn(INVALID_SOCIAL_LOGIN_CREDENTIALS_MESSAGE);
                ErrorDto errorDto = new ErrorDto(INVALID_SOCIAL_LOGIN_CREDENTIALS_DM, INVALID_SOCIAL_LOGIN_CREDENTIALS_MESSAGE);
                errorDto.addFieldData(PROVIDER_DM_PARAMETER, usernamePasswordToken.getSocialAuth().getSocialProvider().getDescription());
                throw new AuthenticationException(errorDto);
            }

            socialLoginResponse.getNonce().ifPresent(nonce ->
                    socialNonceDao.save(new SocialNonceEntity(nonce, LocalDateTime.now(),
                            usernamePasswordToken.getSocialAuth().getSocialProvider())));
            optionalUser = Optional.of(user);
        } else {
            if (NumberUtils.isNumber(usernamePasswordToken.getUsername())) {
                optionalUser = userDao.findById(Long.parseLong(usernamePasswordToken.getUsername()));
            } else {
                try {
                    optionalUser = userDao.findUserByEmailOrUsernameForSiteFilteredByUserRegistrationType(
                            usernamePasswordToken.getUsername(), usernamePasswordToken.getSite());
                } catch (NonUniqueResultException nue) {
                    throw new AuthenticationException("DM3.15", "Multiple users found");
                }
            }
        }

        if (!optionalUser.isPresent()) {
            log.warn("User not found {}", usernamePasswordToken.getUsername());
            throw new AuthenticationException(INVALID_CREDENTIAL_CODE, INVALID_CREDENTIALS_MESSAGE);
        }

        User user = optionalUser.get();
        // check account validity ie. user has a valid role on at least one account
        if (!wssAccountService.isAccountValidForLoginType(user.getId(), usernamePasswordToken.getLoginType())) {
            log.warn(DM31_MESSAGE);
            throw new AuthenticationException(DM31_CODE, DM31_MESSAGE);
        }

        if (!wssAccountService.hasActiveAccount(user.getId(), usernamePasswordToken.getLoginType())) {
            log.warn(DM_3_21_MESSAGE);
            throw new AuthenticationException(DM_3_21_CODE, DM_3_21_MESSAGE);
        }

        validateUserLoginSpecialConditionRestriction(user);


        boolean valid = isSocialLogin;
        // if it was a failed social login we wouldn't have got here
        if (!isSocialLogin) {
            String salt = user.getUsername();
            String hash;
            try {
                hash = PasswordEncoder.hash(encryptionService.decrypt(usernamePasswordToken.getPassword()), salt);
            } catch (Exception e) {
                throw new AuthenticationException("Decryption Failed",
                        String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            }
            log.info("Hash for user {} is {} ", user.getUsername(), hash);
            String loginType = usernamePasswordToken.getLoginType().toString();
            if (usernamePasswordToken.getLoginType() != null && FULL.equalsIgnoreCase(loginType)) {
                log.info("About to login with user {} and login type {} ", user.getUsername(), loginType);
                valid = hash.equals(user.getPassword());
            } else if (usernamePasswordToken.getLoginType() != null
                    && (GUEST.equalsIgnoreCase(loginType) || AGENT.equalsIgnoreCase(loginType))) {
                log.info("About to login with user {} and login type {} ", user.getUsername(), loginType);
                valid = hash.equals(user.getOnetimePassword());
            }
        }

        if (!valid) {
            log.info("Password is invalid, proceed locking user account");
            lockUserAccount(user);
        } else {
            if (!loginTimeAboveThreshold(user) && user.getFailedLoginAttemptCount() != null
                    && user.getFailedLoginAttemptCount().equals(MAX_ATTEMPT_UNTIL_LOCKED)) {
                log.info(
                        "Login time not above threshold, failed login attempt count is not null and equals {}, then lock account. ",
                        MAX_ATTEMPT_UNTIL_LOCKED);
                log.warn(ACCOUNT_LOCKED_CODE_MESSAGE);
                throw new AuthenticationException(ACCOUNT_LOCKED_CODE, ACCOUNT_LOCKED_CODE_MESSAGE);
            } else {
                log.info("Password is valid then set failed login attempt count to 0 and account locked until to null");
                user.setFailedLoginAttemptCount(0);
                user.setAccountLockedUntil(null);
            }
            userDao.saveOrUpdate(user);
            UserAudit userAudit = new UserAudit();
            userAudit.setUserId(user.getId().toString());
            // store either email or userId depending on what the customer used to login with
            userAudit.setUsername(usernamePasswordToken.getUsername());
            userAudit.setDate(new Date());
            userAudit.setJourney(LOGIN_JOURNEY + (isSocialLogin ? ("_" + usernamePasswordToken.getSocialAuth().getSocialProvider()) : ""));
            userAudit.setDm(DEFAULT_DM);
            userAudit.setOutcome(UserAudit.LoginOutcome.LOGIN_SUCCESS);
            userAudit.setServer(DEFAULT_SERVER);
            auditDao.log(userAudit);
        }
        log.debug("authenticate end");

        return new WSSIdentity(user.getId(), user.getUsername(), user.getEmail(), user.getSite().name());
    }

    private User findSocialUser(UsernamePasswordToken usernamePasswordToken) throws AuthenticationException {
        User result = null;
        Optional<SocialLogin> optionalUser = socialLoginDao.findUser(usernamePasswordToken.getSocialAuth().getSocialProvider(), usernamePasswordToken.getSocialId(),
                WSSSite.valueOf(usernamePasswordToken.getSite()));
        if (optionalUser.isPresent()) {
            SocialLogin socialUser = optionalUser.get();
            log.debug("### social login, found user");
            result = socialUser.getUser();
        } else {
            log.debug("### social login, user not found");
        }
        return result;
    }

    @Override
    public WSSIdentity authenticate(RememberMeToken rememberMeTokenToken) throws AuthenticationException {
        if (rememberMeTokenToken == null || StringUtils.isEmpty(rememberMeTokenToken.getValue())) {
            throw new AuthenticationException("Invalid or missing token");
        }
        String series = getSeriesFromEncodedValue(rememberMeTokenToken.getValue());
        String token = getTokenFromEncodedValue(rememberMeTokenToken.getValue());

        PersistentLoginEntity persistentLoginEntity = persistentLoginDao.findPersistentLoginEntity(series);

        // if the entity doesn't exist, or the token values don't match OR the db token has an InvalidatedDate and
        // that date is in the past
        if (persistentLoginEntity == null || !persistentLoginEntity.getToken().equals(token) ||
                (persistentLoginEntity.getInvalidatedDate() != null
                && persistentLoginEntity.getInvalidatedDate().before(new Date()))) {
            throw new AuthenticationException("Invalid token");
        }

        // update usage data in the db
        persistentLoginEntity.setLastUsed(new Date());
        persistentLoginEntity.setUsedCount(persistentLoginEntity.getUsedCount() + 1);
        if(persistentLoginEntity.getInvalidatedDate() == null) {
            // this is to catch old login tokens that were created without an invalidation date
            // to make tokens perpetual, remove the null check above
            persistentLoginEntity.setInvalidatedDateMonthsFromNow(REMEMBER_ME_MONTHS);
        }
        persistentLoginDao.edit(persistentLoginEntity);

        User user = userDao.findById(persistentLoginEntity.getUserId())
                .orElseThrow(() -> new AuthenticationException("User does not exist in db"));

        // check account validity ie. user has a valid role on at least one account
        if (!wssAccountService.isAccountValidForLoginType(user.getId(), LoginType.FULL)) {
            throw new AuthenticationException(DM31_CODE, DM31_MESSAGE);
        }

        if (!wssAccountService.hasActiveAccount(user.getId(), LoginType.FULL)) {
            log.warn(DM_3_21_MESSAGE);
            throw new AuthenticationException(DM_3_21_CODE, DM_3_21_MESSAGE);
        }

        validateUserLoginSpecialConditionRestriction(user);

        return new WSSIdentity(user.getId(), user.getUsername(), user.getEmail(), user.getSite().name());
    }

    private void validateUserLoginSpecialConditionRestriction(User user) {
        boolean hasLoginRestriction = specialConditionService.hasRestrictions(user, SpecialConditionAction.LOGIN_CHECK);
        if (hasLoginRestriction) {
            throw new AuthenticationException(DM_CODE_LOGIN_BLOCKED_BY_SPECIAL_CONDITION_RESTRICTION,
                    "Login blocked by special condition restriction");
        }
    }

    @Override
    public RememberMeToken generateRememberMeToken(Long wssUserId) throws AuthenticationException {

        Optional<User> optionalUser = userDao.findById(wssUserId);
        if (!optionalUser.isPresent()) {
            throw new AuthenticationException("Invalid wssUserd - not found");
        }

        PersistentLoginEntity persistentLoginEntity = new PersistentLoginEntity(optionalUser.get().getUsername(),
                wssUserId);
        persistentLoginEntity.setInvalidatedDateMonthsFromNow(REMEMBER_ME_MONTHS);

        try {
            // persist the new Entity
            persistentLoginDao.create(persistentLoginEntity);
        } catch (STWBusinessException | STWTechnicalException ex) {
            log.error(ex.getLocalizedMessage(), ex);
            throw new AuthenticationException(ex.getLocalizedMessage());
        }
        return new RememberMeToken(persistentLoginEntity.getSeries(), persistentLoginEntity.getToken(),
                persistentLoginEntity.getUsername());
    }

    @Override
    public void invalidateRememberMeToken(RememberMeToken rememberMeTokenToken) throws AuthenticationException {
        if (rememberMeTokenToken == null || StringUtils.isEmpty(rememberMeTokenToken.getValue())) {
            throw new AuthenticationException("Invalid or missing token");
        }
        String series = getSeriesFromEncodedValue(rememberMeTokenToken.getValue());
        PersistentLoginEntity persistentLoginEntity = persistentLoginDao.findPersistentLoginEntity(series);
        // set invalidation datetime to now
        persistentLoginEntity.setInvalidatedDate(new Date());
        persistentLoginDao.edit(persistentLoginEntity);
    }

    private boolean userHasValidRole(WSSAccount wssAccount) {
        return CollectionUtils.isNotEmpty(wssAccount.getWssLegalEntityAccounts());
    }

    private void lockUserAccount(User user) {
        AuthenticationException authenticationException;
        incrementLoginFailureCount(user);
        // login time above threshold and is user already locked out
        if (loginTimeAboveThreshold(user) && user.getFailedLoginAttemptCount() >= MAX_ATTEMPT - 1) {
            // To allow just one more attempt in next hr even if credentials are wrong
            log.info("allow one more attempt in next hr even if credentials are wrong.");
            int oneAttemptInNextHour = MAX_ATTEMPT - 1;
            user.setFailedLoginAttemptCount(oneAttemptInNextHour);
            user.setAccountLockedUntil(new Date());
            authenticationException = new AuthenticationException(INVALID_CREDENTIAL_CODE, INVALID_CREDENTIALS_MESSAGE);
            log.warn(INVALID_CREDENTIALS_MESSAGE);
        } else {
            if (user.getFailedLoginAttemptCount().equals(MAX_ATTEMPT_UNTIL_LOCKED)) {
                log.warn(ACCOUNT_LOCKED_CODE_MESSAGE);
                log.debug(
                        "Failed login attempt count equals {} then lock the account. Set account locked until to currennt date/time",
                        MAX_ATTEMPT_UNTIL_LOCKED);
                user.setAccountLockedUntil(new Date());
                authenticationException = new AuthenticationException(ACCOUNT_LOCKED_CODE, ACCOUNT_LOCKED_CODE_MESSAGE);
            } else {
                log.warn(INVALID_CREDENTIALS_MESSAGE);
                authenticationException = new AuthenticationException(INVALID_CREDENTIAL_CODE,
                        INVALID_CREDENTIALS_MESSAGE);
            }
        }
        userDao.saveOrUpdate(user);
        throw authenticationException;
    }

    private boolean loginTimeAboveThreshold(User user) {
        if (user.getAccountLockedUntil() != null) {
            // time it was locked + 1 hour = unlock time, if unlock time is in the past then
            // account status is unlocked
            return user.getAccountLockedUntil().getTime() + lockDuration < System.currentTimeMillis();
        } else {
            return false;
        }

    }

    private void incrementLoginFailureCount(User user) {
        if (user.getFailedLoginAttemptCount() != null && user.getFailedLoginAttemptCount() >= 0
                && user.getFailedLoginAttemptCount() < MAX_ATTEMPT) {
            log.info(
                    "Increment login failure count if the failed login attempt count is >=0 but is less than MAX_ATTEMPT {} ",
                    MAX_ATTEMPT);
            user.setFailedLoginAttemptCount(user.getFailedLoginAttemptCount() + 1);
        }
    }

    @Override
    @Transactional
    public ResetPassword forgottenPassword(String username, String site) throws AuthenticationException {
        Optional<User> optionalUser = Optional.empty();
        try {
            optionalUser = userDao.findUserByEmailOrUsernameForSite(username, site);
        } catch (NonUniqueResultException nue) {
            throw new AuthenticationException("DM3.16", "Multiple users found");
        }

        String emailLinkPrefix = authenticationConfigService.getEmailLinkPrefix();
        String emailLinkPrefixUrl = String.format(emailLinkPrefix, Constants.STWATER);

        if (Constants.HD.equalsIgnoreCase(site)) {
            emailLinkPrefixUrl = String.format(emailLinkPrefix, Constants.HDCYMRU);
        }

        int hoursBeforeLinkExpires = authenticationConfigService.getHoursBeforeLinkExpires();
        Date expirationDateForJourney = DateUtils.addHours(new Date(), hoursBeforeLinkExpires);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            if (!StringUtils.isEmpty(user.getEmail())) {
                EmailLink emailLink = emailService.createEmailLink(user, emailLinkPrefixUrl,
                        EmailLink.Journey.reset_password_email, expirationDateForJourney);
                sendEmail(user, emailLink);
                ResetPassword resetPassword = new ResetPassword();
                resetPassword.setId(Long.toString(emailLink.getId()));
                resetPassword.setToken(emailLink.getToken());
                return resetPassword;
            } else {
                log.warn("User: {} does not have an email address", username);
                throw new AuthenticationException(DM3_11_CODE, "User does not have an email address");
            }
        } else {
            log.warn("Username not found ({})", username);
            throw new AuthenticationException(DM3_11_CODE, "Username not found");
        }
    }

    @Override
    @Transactional
    public ResetPassword verifyForgottenPasswordLink(ResetPassword resetPassword) throws AuthenticationException {
        log.debug("verifyForgottenPasswordLink start");
        Optional<User> user = findUserAndValidateLink(resetPassword);
        if (user.isPresent()) {
            resetPassword.setUsername(user.get().getUsername());
            return resetPassword;
        } else {
            log.warn("Link is invalid or expired: {}", resetPassword.getHref());
            throw new AuthenticationException(DM3_13, "The link you clicked is invalid or has expired");
        }
    }

    private Optional<User> findUserAndValidateLink(ResetPassword resetPassword) {
        Optional<User> user = Optional.empty();
        long linkId;
        try {
            linkId = Long.parseLong(resetPassword.getId());
        } catch (NumberFormatException e) {
            throw new AuthenticationException("Link ID is not a number");
        }
        Optional<EmailLink> emailLinkOpt = emailLinkDao.find(linkId);
        if (emailLinkOpt.isPresent()) {
            EmailLink emailLink = emailLinkOpt.get();
            if (!emailLink.getToken().equals(resetPassword.getToken())) {
                emailLink.incremementBadClickCount();
            } else if (emailLink.getExpiryDateTime().before(new Date())) {
                emailLink.incremementBadClickCount();
            } else {
                user = Optional.of(emailLink.getUser());
            }
            emailLinkDao.save(emailLink);
        } else {
            throw new AuthenticationException("Email link not valid");
        }
        return user;
    }

    private Optional<User> findUserAndInvalidateLink(ResetPassword resetPassword) {
        log.debug("findUserAndInvalidateLink start: {}", resetPassword.getId());
        Optional<User> user = Optional.empty();
        long linkId;
        try {
            linkId = Long.parseLong(resetPassword.getId());
        } catch (NumberFormatException e) {
            log.warn("Link ID is not a number({})", resetPassword.getId());
            throw new AuthenticationException("Link ID is not a number");
        }

        Optional<EmailLink> emailLinkOpt = emailLinkDao.find(linkId);
        if (emailLinkOpt.isPresent()) {
            EmailLink emailLink = emailLinkOpt.get();
            if (!emailLink.getToken().equals(resetPassword.getToken())) {
                emailLink.incremementBadClickCount();
            } else if (emailLink.getExpiryDateTime().before(new Date())) {
                emailLink.incremementBadClickCount();
            } else {
                emailLink.incremementGoodClickCount();
                emailLink.disable();
                user = Optional.of(emailLink.getUser());
            }
            emailLinkDao.save(emailLink);
        } else {
            log.warn("Link ID is not found ({})", resetPassword.getId());
            throw new AuthenticationException("Email link not valid");
        }
        user.ifPresent(u -> log.debug("User: {}", u.getUsername()));
        log.debug("findUserAndInvalidateLink end");

        return user;
    }

    @Override
    @Transactional
    public ResetPassword updatePassword(ResetPassword resetPassword, ContactDto contactDto, String site)
            throws AuthenticationException {
        log.debug("updatePassword start");

        UsernamePasswordToken token = new UsernamePasswordToken(resetPassword.getUsername(),
                resetPassword.getPassword(), LoginType.FULL, site);

        Optional<User> maybeUser = userDao.findUserByEmailOrUsernameForSite(resetPassword.getUsername(), site);
        if (maybeUser.isPresent()) {
            User user = maybeUser.get();
            if (StringUtils.isEmpty(user.getPassword()) || authenticate(token) != null) {
                user.setPassword(encryptionService.decrypt(resetPassword.getNewPassword()));
                user.setRequiresPasswordReset(false);
                wssAccountService.updateUser(user, false, !user.isRequiresPasswordReset(), null);
                // If we reach this it means that it was updated correctly.
                // We must create a contact of type WEB695
                ContactNotesData contactNotesData = createContactClient.getContactNotesData(
                        resetPassword.getAccountNumber(), Long.valueOf(resetPassword.getLegalEntityId()));
                PasswordChangeContact contact = new PasswordChangeContact(resetPassword, ContactTypes.WEB695,
                        USER_REQUESTED_REASON, contactNotesData);
                createContactClient.createContact(contact);
                // and send an email to the user following template Email022.
                sendEmail0252(user, resetPassword.getAccountNumber(), resetPassword.getLegalEntityId(), contactDto);
                log.debug("updatePassword end");
                return resetPassword;
            } else {
                log.warn("The current password entered does not match the one in our system");
                throw new AuthenticationException("The current password entered does not match the one in our system");
            }
        } else {
            log.warn("Provided username is not valid");
            throw new AuthenticationException("Provided username is not valid");
        }
    }

    private void sendEmail0252(User user, TargetAccountNumber accountNumber, String legalEntityId,
            ContactDto contactDto) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put("${fullName}", contactDto.getFullName());
        emailService.mailMergeAndSend(EMAIL_252_REQUEST_SUCCESS, fieldData, user.getEmail(), accountNumber,
                legalEntityId);
    }

    @Override
    @Transactional
    public ResetPassword resetPassword(ResetPassword resetPassword) throws AuthenticationException {
        log.debug("resetPassword start");
        Optional<User> maybeUser = findUserAndInvalidateLink(resetPassword);
        if (maybeUser.isPresent()) {
            User user = maybeUser.get();
            user.setPassword(encryptionService.decrypt(resetPassword.getPassword()));
            wssAccountService.createUser(user, false, true, null);
            resetPassword.setUsername(user.getUsername());
            log.debug("resetPassword end");
            return resetPassword;
        } else {
            log.warn("Email link not valid");
            throw new AuthenticationException("Email link not valid");
        }
    }

    /*
     * Note - this will use a url as template once email template authoring is
     * implemented. The url will be injected from configuration.
     */
    private void sendEmail(User user, EmailLink emailLink) {
        Map<String, String> fieldData = new HashMap<>();
        TargetAccountNumber accountNumber = null;
        fieldData.put(URL_TEMPLATE_KEY, emailLink.getUrl());
        fieldData.put(FULLNAME_KEY, SPACE);

        // find full name from customer if exists and add to fieldData
        Optional<WSSAccount> opWssAccount = wssAccountService.getAccountByWSSAccountId(user.getId(), Expands.account,
                Expands.customer, Expands.roles);
        opWssAccount.ifPresent(wssAccount -> wssAccount.getWssLegalEntities().stream().findFirst().ifPresent(le -> {
            Customer customer = le.getCustomer();
            fieldData.put(FULLNAME_KEY, (customer != null) ? customer.getFullName() : SPACE);
        }));

        LegalEntity legalEntity = user.getLegalEntities().iterator().next();
        if (legalEntity != null && legalEntity.getAccounts() != null) {
            AccountEntity account = legalEntity.getAccounts().iterator().next();
            if (account != null) {
                 accountNumber = account.getAccountNumber();
            }
        }
        log.debug("Account Number :{}", accountNumber);

        String emailTemplate = user.getSocialLogins().isEmpty() ?
                EMAIL_251_REQUEST_SUCCESS :
                EMAIL_33_SOCIAL_REQUEST_SUCCESS;
        emailService.mailMergeAndSend(emailTemplate, fieldData, user.getEmail(), accountNumber, null);
    }

    private boolean isValid(UsernamePasswordToken usernamePasswordToken) {
        // Token non existent or invalid
        if (usernamePasswordToken == null || usernamePasswordToken.getLoginType() == null) {
            return false;
        } else if (
            // Token for normal login.
            usernamePasswordToken.getSocialAuth() == null &&
                    (StringUtils.isEmpty(usernamePasswordToken.getUsername())
                            || StringUtils.isEmpty(usernamePasswordToken.getPassword())
                            || StringUtils.isEmpty(usernamePasswordToken.getLoginType().toString()))) {
            return false;
        } else {
                return usernamePasswordToken.getSocialAuth() == null ||
                        (usernamePasswordToken.getSocialAuth().getSocialProvider() != null);
            }
    }

    @Override
    public ResetUsername forgottenEmail(String emailAsUsername, String site) throws AuthenticationException {
        List<User> users = userDao.findUsersByEmailAndSite(emailAsUsername, site);
        ResetUsername resetUsername = null;
        List<String> userNames = new ArrayList<>();
        Optional<User> userOpt = users.stream().findFirst();
        if (userOpt.isPresent()) {
            log.info("List Usernames found :{}", emailAsUsername);
            resetUsername = new ResetUsername();
            resetUsername.setEmail(emailAsUsername);
            User user = userOpt.get();
            if (users.stream().count() == 1 && StringUtils.isNotEmpty(user.getRegistrationType())
                    && user.getRegistrationType().equalsIgnoreCase(EAUN)) {
                resetUsername.setLoginWithEmail(user.isLoginWithEmail());
            }
            resetUsername.setEmailAddressLocated(true);
            for (User userFound : users) {
                userNames.add(userFound.getUsername());
                log.debug(userFound.getUsername());
            }
            resetUsername.setUsernames(userNames);
            return resetUsername;
        } else {
            log.debug("User not found for:{}", emailAsUsername);
            resetUsername = new ResetUsername();
            resetUsername.setEmail("");
            resetUsername.setEmailAddressLocated(false);
            return resetUsername;
        }
    }

    private SocialLoginResponse verifyCredentials(UsernamePasswordToken usernamePasswordToken) {

        SocialAuth socialLoginRequest = usernamePasswordToken.getSocialAuth();
        log.debug("request: {}", socialLoginRequest);

        SocialProviderType provider = socialLoginRequest.getSocialProvider();

        try {
            return socialLoginService.authenticate(socialLoginRequest, WSSSite.valueOf(usernamePasswordToken.getSite()));
        } catch (SocialTokenExpiredException e) {
            throw new AuthenticationException(new ErrorDto(TOKEN_EXPIRED_CODE,
                    e.getMessage()).addFieldData(PROVIDER_DM_PARAMETER, provider.getDescription()), e);
        } catch (SocialPermissionsException e) {
            throw new AuthenticationException(new ErrorDto(SOCIAL_AUTH_PERMISSIONS_CODE,
                    e.getMessage()).addFieldData(PROVIDER_DM_PARAMETER, provider.getDescription()), e);
        } catch (Exception e) {
            throw new AuthenticationException(new ErrorDto(SOCIAL_AUTH_FAILURE_CODE,
                    e.getMessage()).addFieldData(PROVIDER_DM_PARAMETER, provider.getDescription()), e);
        }
    }
}
