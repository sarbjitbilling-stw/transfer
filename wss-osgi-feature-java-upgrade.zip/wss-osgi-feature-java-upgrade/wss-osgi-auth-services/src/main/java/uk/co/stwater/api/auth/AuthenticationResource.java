package uk.co.stwater.api.auth;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import uk.co.stwater.api.audit.AuditService;
import uk.co.stwater.api.osgi.model.RememberMeToken;
import uk.co.stwater.api.osgi.model.UsernamePasswordToken;
import uk.co.stwater.api.osgi.model.account.WSSIdentity;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * RESTful API for Authentication
 *
 * Created by rtai on 09/02/2017.
 */
@Named
@Consumes({"application/json", "application/xml"})
@Produces({"application/json", "application/xml"})
@Path("/WSSAccounts")
public class AuthenticationResource extends AbstractResource {
    private static final String LOCK_CODE = "DM3.14";

    private static final String DEFAULT_ERROR_CODE = "DM1.00";
    
    @Inject
    private AuthenticationService authenticationService;
    
    @Inject
    @OsgiService
    private AuditService auditService;
    
    @GET
    @Path("/Auth")
    public Response notAllowed() {
        return Response.status(Response.Status.METHOD_NOT_ALLOWED).build();
    }

    @GET
    @Path("/Token/{wssUserId}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON})
    public Response getRememberMeToken(@PathParam("wssUserId") Long wssUserId) {
        try {
            RememberMeToken rememberMeToken = authenticationService.generateRememberMeToken(wssUserId);
            return Response.ok().entity(rememberMeToken).build();
        } catch (AuthenticationException authEx) {
            ErrorDto errorDto = null;
            if (StringUtils.isNotEmpty(authEx.getCode())) {
                errorDto = new ErrorDto(authEx.getCode(), authEx.getLocalizedMessage());
                if (authEx.getCode().equalsIgnoreCase(LOCK_CODE)) {
                return Response.status(Response.Status.UNAUTHORIZED).entity(errorDto).build();
                }
            } else if (StringUtils.isEmpty(authEx.getCode())) {
                errorDto = new ErrorDto(DEFAULT_ERROR_CODE, authEx.getLocalizedMessage());
            }
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }
    }
    
    @DELETE
    @Path("/Token/{token}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON})
    public Response deleteRememberMeToken(@PathParam("token") String tokenValue) 
            throws STWBusinessException, STWTechnicalException{
        RememberMeToken token = new RememberMeToken(tokenValue);
        authenticationService.invalidateRememberMeToken(token);  
        return Response.noContent().build();
    }

    @PUT
    @Path("/Token")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response authenticate(RememberMeToken rememberMeTokenToken) {

        try {
            WSSIdentity wssIdentity = authenticationService.authenticate(rememberMeTokenToken);
            return Response.ok().entity(wssIdentity).build();
        } catch (AuthenticationException authEx) {
            ErrorDto errorDto = null;
            if (StringUtils.isNotEmpty(authEx.getCode())) {
                errorDto = new ErrorDto(authEx.getCode(), authEx.getLocalizedMessage());
                return Response.status(Response.Status.UNAUTHORIZED).entity(errorDto).build();
            } else if (StringUtils.isEmpty(authEx.getCode())) {
                errorDto = new ErrorDto(DEFAULT_ERROR_CODE, authEx.getLocalizedMessage());
            }
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }
    }

    @PUT
    @Path("/Auth")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response authenticate(UsernamePasswordToken usernamePasswordToken) {

        try {
            WSSIdentity wssIdentity = authenticationService.authenticate(usernamePasswordToken);
            return Response.ok().entity(wssIdentity).build();
        } catch (AuthenticationException authEx) {
            auditService.audit(usernamePasswordToken, authEx.getCode(), authEx.getMessage());
            ErrorDto errorDto = authEx.getErrorDto();
            if(errorDto == null) {
                if (StringUtils.isNotEmpty(authEx.getCode())) {
                    errorDto = new ErrorDto(authEx.getCode(), authEx.getLocalizedMessage());
                    return Response.status(Response.Status.UNAUTHORIZED).entity(errorDto).build();
                } else if (StringUtils.isEmpty(authEx.getCode())) {
                    errorDto = new ErrorDto(DEFAULT_ERROR_CODE, authEx.getLocalizedMessage());
                }
            }
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }
    }
}
