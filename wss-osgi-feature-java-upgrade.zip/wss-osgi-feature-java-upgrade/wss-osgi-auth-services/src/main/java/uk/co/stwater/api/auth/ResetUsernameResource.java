package uk.co.stwater.api.auth;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.ResetUsername;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.resetusername.Username;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.Constants;

/**
 * Created by .
 */
@Named
@Consumes({"application/json", "application/xml"})
@Produces({"application/json", "application/xml"})
@Path("/WSSAccounts/Auth/ResetUsername")
public class ResetUsernameResource extends AbstractResource {

    private static final Logger log = LoggerFactory.getLogger(ResetUsernameResource.class);	
    private static final String DM4_2 = "DM4.2";

    
	@Inject
    private AuthenticationService authenticationService;

    void setAuthenticationService(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

	/**
	 * Creates a ResetUsername resource with the generated token.
	 * 
	 * @param emailAsUsername
	 * @return
	 */
	@POST
	public Response forgottenEmail(Username emailAsUsername, @DefaultValue(Constants.STW) @HeaderParam(Constants.WSS_SITE) String site) {
		ResetUsername resetUsername = null;
		log.info("ForgottenEmail Address : {}", emailAsUsername.getUsername());
		try {
			resetUsername = authenticationService.forgottenEmail(emailAsUsername.getUsername(), site.toUpperCase());
			if (resetUsername.isEmailAddressLocated()) {
				log.info("Username returned :{}", resetUsername);
				return Response.ok().entity(resetUsername).build();
			} else {
				log.warn("Sorry, the username and/or password provided don't seem to match our records");
				ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.AUTH_SERVICES, DM4_2,
						"Sorry, the username and/or password you've  provided don't seem to match our records. Please check and try again.");
				return Response.status(Status.NOT_FOUND).entity(errorDto).build();
			}

		} catch (AuthenticationException e) {
			log.warn("Authentication error :{}", e.getDescription());
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.AUTH_SERVICES, DM4_2, e.getLocalizedMessage());
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}

	}
    
    /**
     * Reset's the users resetUsername
     * @param resetUsername
     * @return
     */
    @PUT
    public Response resetUsername(ResetUsername resetUsername) {
    	log.warn("Reset username has not been implemented yet");
        return Response.ok().build();
    }

}
