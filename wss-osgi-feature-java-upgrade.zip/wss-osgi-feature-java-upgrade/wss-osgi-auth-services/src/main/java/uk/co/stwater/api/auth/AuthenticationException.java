package uk.co.stwater.api.auth;

import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.STWBusinessException;

/**

 * 
 * 
 * 
 * 
 * Created by rtai on 09/02/2017.
 */
public class AuthenticationException extends STWBusinessException {
	
	private String code;
	
    public AuthenticationException(String msg) {
        super(msg);
    }
    
    public AuthenticationException(String code, String message) {
        super(message);
        this.code = code;
    }

    public AuthenticationException(ErrorDto errorDto, Throwable t) {
        super(errorDto, t);
    }

    public AuthenticationException(ErrorDto errorDto) {
        super(errorDto);
    }

	public String getCode() {
        return code != null ? code : getErrorCode();
	}

	public void setCode(String code) {
		this.code = code;
	}
    
}
