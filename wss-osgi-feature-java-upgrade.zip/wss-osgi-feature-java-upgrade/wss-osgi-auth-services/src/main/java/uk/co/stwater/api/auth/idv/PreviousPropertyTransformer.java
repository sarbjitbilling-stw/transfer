/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.auth.idv;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.util.TransformerBase;
import static uk.co.stwater.api.osgi.util.TransformerBase.copy;
import uk.co.stwater.targetconnector.client.model.GetPropertyResponse;

/**
 *
 * @author 
 */
public class PreviousPropertyTransformer extends TransformerBase {
    
    public static final Transformer SOAP_RESPONSE_TO_PROPERTY_ENTITY = new Transformer() {
        @Override
        public Property transform(Object input) {
           GetPropertyResponse propertyResponse = (GetPropertyResponse)input;
           Property property = copy(propertyResponse, new Property());
           property.setAccountNumber(propertyResponse.getAccountNumber());
           return property;
        }
        
    };

}
