package uk.co.stwater.api.auth.contact;

import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.resetpassword.ResetPassword;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class PasswordChangeContact implements CustomerContact {

	private ContactTypes type;
	private ResetPassword passwordReset;
	private ContactNotesData contactNotesData;
	private String changeReason;
	
	private final String QUERY_DETAILS_KEY = "Query Details: ";
	private final String REASON_KEY = "Reason for  Account Password Change ";
	
	public PasswordChangeContact(ResetPassword resetPassword, ContactTypes contactType, String passChangeReason, ContactNotesData contactNotes) {
		passwordReset = resetPassword;
		contactNotesData = contactNotes;
		type = contactType;
		changeReason = passChangeReason;
	}
	
	@Override
	public TargetAccountNumber getAccountNumber() {
		return passwordReset.getAccountNumber();
	}

	@Override
	public String getLegalEntityNumber() {
		return passwordReset.getLegalEntityId();
	}

	@Override
	public String getPostcode() {
		return "UNKNOWN POSTCODE";
	}

	@Override
	public String getFormattedNote() {
		StringBuilder builder = new StringBuilder();
		builder.append(CustomerContact.getFormattedCustomerDetails(contactNotesData)).append(NEW_LINE);
		builder.append(NEW_LINE);
		builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
		builder.append(NEW_LINE);
		builder.append(REASON_KEY).append(changeReason).append(NEW_LINE);
		builder.append(NEW_LINE);
		return builder.toString();
	}

	@Override
	public String getContactType() {
		return type.toString();
	}

	@Override
	public Long getPropertyNumber() {
		return null;
	}

	@Override
	public boolean isSubstantiveResponse() {
		return false;
	}

}
