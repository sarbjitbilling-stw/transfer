package uk.co.stwater.api.auth.idv;

import uk.co.stwater.api.osgi.model.IDVStatus;
import uk.co.stwater.api.osgi.model.QuestionAnswers;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

/**
 *
 * @author admzphili1
 */
public interface AuthorizationService {
    
    QuestionAnswers getQuestionAnswers(TargetAccountNumber accountNumber, String postcode, long legalEntity);
    
    IDVStatus validateQuestions(QuestionAnswers questionAnswers, String idvRegistrationType);
    
}
