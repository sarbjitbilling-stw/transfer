package uk.co.stwater.api.auth.agent;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Base64;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.digest.DigestUtils;

import uk.co.stwater.api.auth.AuthenticationConfigService;
import uk.co.stwater.api.osgi.util.AbstractResource;

@Named
public class AgentAuthenticationResource extends AbstractResource {
    
    @Inject
    AgentLoginService agentLoginService;
    
    @Inject
    private AuthenticationConfigService configService;

    @GET
    @Path("/agent/{wssUserId}")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response getAgentLogin(@PathParam("wssUserId") long wssUserId) {

        return Response.status(Response.Status.OK)
                .entity(agentLoginService.getAgentLogin(wssUserId))
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .build();
    }
    
    @POST
    @Path("/agent")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response getAgentLogin(@HeaderParam("digest") String digest, AgentLoginRequest request) {
        
        if(! request.isValid(configService.getAgentLoginSharedSecret())){
            return Response.status(Response.Status.FORBIDDEN).build();
        }

        return Response.status(Response.Status.OK)
                .entity(agentLoginService.getAgentLogin(request.getWssUserId()))
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .build();
    }
    
    //AEM will CORS pre-fligth the calls so we have to support the Options method
    @OPTIONS
    @Path("/agent/{wssUserId}")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response corsPreFlight1() {
        return CORS;
    }
    
    @OPTIONS
    @Path("/sign")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response corsPreFlight2() {
        return CORS;
    }
    
    @OPTIONS
    @Path("/agent")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response corsPreFlight3() {
        return CORS;
    }
    
    private static final Response CORS = Response.status(Response.Status.OK)
                .allow("POST", "GET", "PUT", "UPDATE", "OPTIONS", "HEAD")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Methods", "POST, GET, PUT, UPDATE, OPTIONS, HEAD")
                .header("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With, digest")
                .build();
    
       
    @PUT
    @Path("/sign")
    @Consumes({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response sign(String data2sign) throws UnsupportedEncodingException {

        //String expextedResult = "15efdc3bc2367f58d3400144bc388dcfcb10021e";
        String payload = URLEncoder.encode(data2sign, "UTF-8");
        String secret = "We Ar3 The Ch4mp1ons";
        String digestHex = DigestUtils.sha1Hex(secret + payload);
        
        Base64.Encoder encoder = Base64.getEncoder();
        String digestBase64 = encoder.encodeToString(DigestUtils.sha1(secret + payload));

        DigestResponse resp = new DigestResponse(200, null, digestHex, digestBase64);
        return Response.ok().entity(resp)
                                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Methods", "POST, GET, PUT, UPDATE, OPTIONS, HEAD")
                .header("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With")
                
                
                .build();

    }

    private static class DigestResponse{
        /*
            {"code": 200,
            "errorMessage": "",
            "hexHash": "15EFDC3BC2367F58D3400144BC388DCFCB10021E",
            "base64Hash": "Fe/cO8I2f1jTQAFEvDiNz8sQAh4=" }
        */
        
        public final int code;
        public final String errorMessage;
        public final String hexHash;
        public final String base64Hash;

        private DigestResponse(int code, String errorMessage, String hexHash, String base64Hash) {
            this.code = code;
            this.errorMessage = errorMessage;
            this.hexHash = hexHash;
            this.base64Hash = base64Hash;
        }
        

    }
    

}
