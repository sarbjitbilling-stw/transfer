package uk.co.stwater.api.auth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.EncryptionKey;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.encryption.EncryptionService;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * Created by tellis3 on 28/02/2018.
 */
@Named
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Path("/keys")
public class EncryptionResource extends AbstractResource {

	Logger logger = LoggerFactory.getLogger(EncryptionResource.class);

	@Inject
	@OsgiService
	private EncryptionService encryptionService;

	/**
	 * Retrieves the Public Key with which to encrypt passwords.
	 *
	 * @return
	 */
	@GET
	@Path("/public")
	public Response getPublicKey() {
		logger.info("getPublicKey");
		return Response.ok().entity(new EncryptionKey(encryptionService.getPublicKey())).build();
	}

                
    @XmlRootElement(name = "credentials")
    @XmlAccessorType(XmlAccessType.FIELD)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CredentialsDto {
        @XmlElement
        private String username;
        @XmlElement
        private String passwordText;
        @XmlElement
        private String passwordCrypt;
        @XmlElement
        private String passwordHash;
    }

}