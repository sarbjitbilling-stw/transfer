package uk.co.stwater.api.auth;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Priority;
import javax.inject.Named;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.Response;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;


@PreMatching
@Priority(Priorities.AUTHENTICATION)
@Named
@OsgiServiceProvider(classes = { EndpointSharedSecretProvider.class })
public class EndpointSharedSecretProvider implements ContainerRequestFilter {

    private static final String ENDPOINT_SHARED_SECRET_HEADER = "X-Endpoint-Shared-Secret";

    Logger log = LoggerFactory.getLogger(this.getClass());

    private AuthenticationConfigService authenticationConfigService;

    @Override
    public void filter(ContainerRequestContext containerRequestContext) {
        getConfigService();
        if(authenticationConfigService == null || !isSecretValid(containerRequestContext)) {
            containerRequestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
        }
    }

    private boolean isSecretValid(ContainerRequestContext containerRequestContext) {
        String headerSharedSecret = containerRequestContext.getHeaderString(ENDPOINT_SHARED_SECRET_HEADER);
        if(authenticationConfigService.isEndpointSharedSecretEnabled()) {
            String sharedSecret = authenticationConfigService.getEndpointSharedSecret();
            return isNotEmpty(sharedSecret) && sharedSecret.equals(headerSharedSecret);
        } else {
            return true;
        }
    }

    private void getConfigService() {
        try {
            if (authenticationConfigService == null) {
                BundleContext bundleContext = FrameworkUtil.getBundle(AuthenticationConfigService.class).getBundleContext();
                Optional<ServiceReference<AuthenticationConfigService>> serviceReference =
                        bundleContext.getServiceReferences(AuthenticationConfigService.class, null).stream().findFirst();
                serviceReference.ifPresent(authenticationConfigServiceServiceReference ->
                        authenticationConfigService = bundleContext.getService(authenticationConfigServiceServiceReference));
            }
        } catch(Exception e) {
            log.error("Unable to find authenticationConfigService", e);
        }
    }
}
