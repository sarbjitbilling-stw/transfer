
package uk.co.stwater.api.auth.agent;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Objects;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;

import uk.co.stwater.api.osgi.util.logging.LogManager;

/**
 *
 * @author Mark
 */
@XmlRootElement(name = "AgentLoginRequest")
public class AgentLoginRequest implements Serializable {
    Logger log = LogManager.classLogger();

    @XmlElement(name = "wssUserId")
    private long wssUserId;

    @XmlElement(name = "timestamp")
    private long timestamp;

    @XmlElement(name = "digest")
    private String digest;

    public AgentLoginRequest() {
    }

    public AgentLoginRequest(long wssUserId, long timestamp, String digest) {
        this.wssUserId = wssUserId;
        this.timestamp = timestamp;
        this.digest = digest;
    }
    
    public long getWssUserId() {
        return wssUserId;
    }

    public void setWssUserId(long wssUserId) {
        this.wssUserId = wssUserId;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getDigest() {
        return digest;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + (int) (this.wssUserId ^ (this.wssUserId >>> 32));
        hash = 59 * hash + (int) (this.timestamp ^ (this.timestamp >>> 32));
        hash = 59 * hash + Objects.hashCode(this.digest);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AgentLoginRequest other = (AgentLoginRequest) obj;
        if (this.wssUserId != other.wssUserId) {
            return false;
        }
        if (this.timestamp != other.timestamp) {
            return false;
        }
        if (!Objects.equals(this.digest, other.digest)) {
            return false;
        }
        return true;
    }
    
    //check that the digest is valid and the request has not timedout
    public boolean isValid(String sharedSecret){
        try {
            String payload = URLEncoder.encode(toSignedString(), "UTF-8");
            
            boolean digestIsValid =  DigestUtils.sha1Hex(sharedSecret + payload).equalsIgnoreCase(digest) ;
            boolean tooOld = System.currentTimeMillis() - timestamp > 300_000;
            log.debug("AgentLoginRequest toOld {}, validDigest {}", tooOld, digestIsValid);
            
            // not to old and digest is valid?
            return !tooOld && digestIsValid;
        } catch (UnsupportedEncodingException ex) {
            return false;
        }
    }
    
    // doing it this way coz the string needs to be exact (ie propety order etc is importent!)
    public String toSignedString(){
        return String.format("%1$s%2$d", wssUserId, timestamp);
    }
}
