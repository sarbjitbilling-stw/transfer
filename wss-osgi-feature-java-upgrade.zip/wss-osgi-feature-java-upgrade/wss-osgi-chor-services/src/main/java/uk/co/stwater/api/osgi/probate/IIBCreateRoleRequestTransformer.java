package uk.co.stwater.api.osgi.probate;

import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.model.AccountRole;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.roles.create.IIBCreateRoleRequest;

import javax.inject.Named;

@Named
public class IIBCreateRoleRequestTransformer implements Transformer {

    @Override
    public Object transform(Object source) {
        IIBCreateRoleRequest iibCreateRoleRequest = null;
        if (null == source) {
            throw new STWBusinessException("source is a required parameter");
        }

        if (source instanceof AccountRole) {
            AccountRole role = (AccountRole) source;
            iibCreateRoleRequest = new IIBCreateRoleRequest();
            iibCreateRoleRequest.setAcccountNumber(role.getAccountNumber());
            RefData theRole = new RefData();

            if (role.getRole() != null) {
                theRole.setCode(role.getRole().getCode());
                theRole.setValue(role.getRole().getValue());
            }

            iibCreateRoleRequest.setRole(theRole);
            iibCreateRoleRequest.setLegalEntityNo(role.getLegalEntityId());
            iibCreateRoleRequest.setStartDate(role.getStartDate());
        }

        return iibCreateRoleRequest;
    }

}
