package uk.co.stwater.api.osgi.chor;

public class StateContextHolder {

    private static final ThreadLocal<StateContext> contextHolder = new ThreadLocal<>();

    public static StateContext getContext() {
        StateContext stateContext = contextHolder.get();
        if (stateContext == null) {
            stateContext = new StateContext();
            contextHolder.set(stateContext);
        }
        return stateContext;
    }

    public static void setContext(StateContext stateContext) {
        contextHolder.set(stateContext);
    }

    public static void clearContext() {
        contextHolder.remove();
    }

}
