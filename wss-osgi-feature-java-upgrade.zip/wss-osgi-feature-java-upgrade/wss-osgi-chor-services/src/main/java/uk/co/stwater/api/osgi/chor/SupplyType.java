package uk.co.stwater.api.osgi.chor;

public enum SupplyType {
    ASSESSED("A"),
    MEASURED("M"),
    UNMEASURED("U");

    private String code;

    SupplyType(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
