package uk.co.stwater.api.osgi.probate;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.model.PaperlessDetails;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesResponse;
import uk.co.stwater.iib.client.api.roles.patch.IIBPatchRoleRequest;

import javax.inject.Named;

@Named
public class IIBPatchRoleRequestTransformer implements Transformer {

    @Override
    public Object transform(Object source) {
        IIBPatchRoleRequest iibPatchRoleRequest = null;
        if (null == source) {
            throw new STWBusinessException("source is a required parameter");
        }

        try {
            if (source instanceof IIBGetRolesResponse) {
                IIBGetRolesResponse rolesResponse = (IIBGetRolesResponse) source;
                iibPatchRoleRequest = new IIBPatchRoleRequest();

                iibPatchRoleRequest.setAcceptsInserts(rolesResponse.getAcceptsInserts());
                iibPatchRoleRequest.setDocCopiesNo(rolesResponse.getDocCopiesNo());
                iibPatchRoleRequest.setDocRefNum(rolesResponse.getDocRefNum());
                iibPatchRoleRequest.setEndDate(rolesResponse.getEndDate());
                iibPatchRoleRequest.setFirstName(rolesResponse.getFirstName());
                iibPatchRoleRequest.setLastName(rolesResponse.getLastName());
                iibPatchRoleRequest.setLegalEntityNo(rolesResponse.getLegalEntityNo());
                iibPatchRoleRequest.setMiddleInitial(rolesResponse.getMiddleInitial());
                iibPatchRoleRequest.setPartyReq(rolesResponse.getPartyReq());
                iibPatchRoleRequest.setPrintOnBill(rolesResponse.getPrintOnBill());
                iibPatchRoleRequest.setRequestorRel(rolesResponse.getRequestorRel());
                iibPatchRoleRequest.setRoleId(rolesResponse.getRoleId());
                if (rolesResponse.getRole() != null) {
                    RefData refDataRoleClone = new RefData();
                    BeanUtils.copyProperties(refDataRoleClone, rolesResponse.getRole());
                    iibPatchRoleRequest.setRole(refDataRoleClone);
                }
                iibPatchRoleRequest.setStartDate(rolesResponse.getStartDate());
                if (rolesResponse.getTitle() != null) {
                    RefData refDataTitleClone = new RefData();
                    BeanUtils.copyProperties(refDataTitleClone, rolesResponse.getTitle());
                    iibPatchRoleRequest.setTitle(refDataTitleClone);
                }
                iibPatchRoleRequest.setVersionNo(rolesResponse.getVersionNo());

                if (rolesResponse.getWebSelfServe() != null) {
                    PaperlessDetails paperlessDetailsClone = new PaperlessDetails();
                    BeanUtils.copyProperties(paperlessDetailsClone, rolesResponse.getWebSelfServe());
                    iibPatchRoleRequest.setWebSelfServe(rolesResponse.getWebSelfServe());
                }

            } else {
                throw new STWBusinessException("source must be an instance of IIBGetRolesResponse");
            }

        } catch (Exception e) {
            throw new STWTechnicalException(e.getMessage(), e);
        }

        return iibPatchRoleRequest;
    }

}
