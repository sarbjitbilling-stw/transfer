package uk.co.stwater.api.osgi.chor;

import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Named;
import javax.inject.Singleton;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author tellis3
 */
@Named
@Singleton
@OsgiServiceProvider(classes = {ChorConfigService.class})
public class ChorConfigServiceImpl implements ManagedService, ChorConfigService {

    public static final String PID = "wss.osgi.chor";
    static final String MONTHS_IN_PAST_EVIDENCE_REQUIRED_NOT_BILL_PAYER = PID + ".months.past.evidence.required.not.bill.payer";
    static final String MONTHS_IN_PAST_EVIDENCE_REQUIRED_BILL_PAYER = PID + ".months.past.evidence.required.bill.payer";
    static final String DAYS_IN_FUTURE_CHOR_ALLOWED_FOR = PID + ".days.in.future.chor.allowed.for";
    static final String MONTHS_IN_PAST_BEFORE_METER_READ_REQUIRED_NEW_CUSTOMER = PID + ".months.in.part.before.meter.read.required.new.customer";

    private static final Map<String, String> config = new HashMap<>();

    Logger log = LoggerFactory.getLogger(this.getClass());


    @Override
    public synchronized void updated(Dictionary dctnrIn) throws ConfigurationException {
        //Add some type saftey !!

        log.info("updating chor config");

        Dictionary<String, String> dctnr = dctnrIn;

        String evidenceRequiredNotBillPayer = getValue(dctnr, MONTHS_IN_PAST_EVIDENCE_REQUIRED_NOT_BILL_PAYER);
        String evidenceRequiredBillPayer = getValue(dctnr, MONTHS_IN_PAST_EVIDENCE_REQUIRED_BILL_PAYER);
        String daysInFutureChorAllowedFor = getValue(dctnr, DAYS_IN_FUTURE_CHOR_ALLOWED_FOR);
        String monthsInPastBeforeMeterReadRequiredNewCustomer = getValue(dctnr, MONTHS_IN_PAST_BEFORE_METER_READ_REQUIRED_NEW_CUSTOMER);

        if(evidenceRequiredNotBillPayer == null ) throw new ConfigurationException(MONTHS_IN_PAST_EVIDENCE_REQUIRED_NOT_BILL_PAYER, "Can't be null");
        if(evidenceRequiredBillPayer == null ) throw new ConfigurationException(MONTHS_IN_PAST_EVIDENCE_REQUIRED_BILL_PAYER, "Can't be null");
        if(daysInFutureChorAllowedFor == null ) throw new ConfigurationException(DAYS_IN_FUTURE_CHOR_ALLOWED_FOR, "Can't be null");
        if(monthsInPastBeforeMeterReadRequiredNewCustomer == null ) throw new ConfigurationException(MONTHS_IN_PAST_BEFORE_METER_READ_REQUIRED_NEW_CUSTOMER, "Can't be null");

        if(!StringUtils.isNumeric(evidenceRequiredNotBillPayer)) throw new ConfigurationException(MONTHS_IN_PAST_EVIDENCE_REQUIRED_NOT_BILL_PAYER, "Must be numeric");
        if(!StringUtils.isNumeric(evidenceRequiredBillPayer)) throw new ConfigurationException(MONTHS_IN_PAST_EVIDENCE_REQUIRED_BILL_PAYER, "Must be numeric");
        if(!StringUtils.isNumeric(daysInFutureChorAllowedFor)) throw new ConfigurationException(DAYS_IN_FUTURE_CHOR_ALLOWED_FOR, "Must be numeric");
        if(!StringUtils.isNumeric(monthsInPastBeforeMeterReadRequiredNewCustomer)) throw new ConfigurationException(MONTHS_IN_PAST_BEFORE_METER_READ_REQUIRED_NEW_CUSTOMER, "Must be numeric");

        config.clear();
        Collections.list(dctnr.keys()).stream().forEach((key)->config.put(key, dctnr.get(key)));

    }

    private String getValue(Dictionary dctnr, String key) {
        return dctnr.get(key).toString();
    }

    @Override
    public int getMonthsInPastEvidenceRequiredForNonBillPayer() {
        return Integer.parseInt(config.get(MONTHS_IN_PAST_EVIDENCE_REQUIRED_NOT_BILL_PAYER));
    }

    @Override
    public int getMonthsInPastEvidenceRequiredForBillPayer() {
        return Integer.parseInt(config.get(MONTHS_IN_PAST_EVIDENCE_REQUIRED_BILL_PAYER));
    }

    @Override
    public int getDaysInFutureChorAllowedFor() {
        return Integer.parseInt(config.get(DAYS_IN_FUTURE_CHOR_ALLOWED_FOR));
    }

    @Override
    public int getMonthsInPastBeforeMeterReadRequiredNewCustomer() {
        return Integer.parseInt(config.get(MONTHS_IN_PAST_BEFORE_METER_READ_REQUIRED_NEW_CUSTOMER));
    }

}