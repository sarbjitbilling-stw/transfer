package uk.co.stwater.api.osgi.chor;

/**
 * ChorPostProcessor provides the functionality that should be executed after a {@link ChorStateProcessor} has done its work.
 */
public interface ChorPostProcessor {

    void postProcess(ChorContext chorContext);

}
