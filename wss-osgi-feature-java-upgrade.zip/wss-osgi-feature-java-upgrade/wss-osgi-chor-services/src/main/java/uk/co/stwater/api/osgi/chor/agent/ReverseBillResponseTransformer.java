package uk.co.stwater.api.osgi.chor.agent;

import javax.inject.Named;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.osgi.model.ReverseBillResponse;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.bill.cancel.IIBCancelBillResponse;

@Named
public class ReverseBillResponseTransformer implements Transformer {

	@Override
	public Object transform(Object source) {
	    ReverseBillResponse reverseBillResponse = new ReverseBillResponse();
		if(null == source)
		{
			throw new STWBusinessException("source is a mandatory parameter");
		}
		
		if(source instanceof IIBCancelBillResponse)
		{
			IIBCancelBillResponse cancelBillResponse = (IIBCancelBillResponse) source;
			TargetAccountNumber accountNumber = new TargetAccountNumber(cancelBillResponse.getAccountNumber(), null);
			reverseBillResponse.setAccountId(accountNumber);
			reverseBillResponse.setAlternateId(cancelBillResponse.getAlternateId());
			reverseBillResponse.setPropertyAddress(cancelBillResponse.getPropertyAddress());
			reverseBillResponse.setPropertyId(cancelBillResponse.getPropertyId());
			reverseBillResponse.setServiceProvisionDes(cancelBillResponse.getServiceProvisionDes());
			reverseBillResponse.setServiceProvisionNum(cancelBillResponse.getServiceProvisionNum());
		
		} else {
			throw new STWBusinessException("source must be an instance of IIBCancelBillResponse");
		}
		return reverseBillResponse;
	}

}
