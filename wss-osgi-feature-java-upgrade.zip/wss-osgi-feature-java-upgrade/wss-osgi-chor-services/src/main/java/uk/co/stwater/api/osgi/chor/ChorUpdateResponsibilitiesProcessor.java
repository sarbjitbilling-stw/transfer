package uk.co.stwater.api.osgi.chor;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.targetconnector.client.api.setchor.Chor;

import java.util.List;

public class ChorUpdateResponsibilitiesProcessor extends AbstractChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorUpdateResponsibilitiesProcessor.class);

    ChorUpdateResponsibilitiesProcessor(ServiceFacade serviceFacade, ChorStateManager chorStateManager, ChorStateProcessor nextStateProcessor) {
        super(serviceFacade, chorStateManager, nextStateProcessor);
    }

    @Override
    public boolean canProcess(ChorState chorState) {
        return false;
    }

    @Override
    protected void processState(ChorContext chorContext) {
        logger.debug("processState entry");
        List<Customer> newResponsibilities = chorContext.getResponsibilities();
        if (CollectionUtils.isEmpty(newResponsibilities)) {
            logger.info("3 - SetChor (ON) : New occupant unknown so no turnOn required, service not called.");
            chorStateManager.moveOutChorOn(ChorProgressMonitor.Progress.NOT_ATTEMPTED)
                    .moveOutRole(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
            // do not call the SETCHOR service, this will put the account into void
        } else {
            Customer newCustomer = newResponsibilities.get(0);
            TargetAccountNumber newAccountNumber = doChorIn(newCustomer, chorContext.getMovingOutDetails());
            chorStateManager.moveOutChorOn(ChorProgressMonitor.Progress.COMPLETED);
            // now create an LE for each person listed under 'new responsibilities' barring the first which is setup as primary
                for (int count=1;count<newResponsibilities.size();count++) {
                    Customer newResponsibility = newResponsibilities.get(count);
                logger.info("4 - AddAccountRole : For each additional Legal Entity");
                serviceFacade.getAddAccountRoleClient().addAccountRole(createAccountRole(newAccountNumber, newResponsibility), newAccountNumber);
            }
            chorStateManager.moveOutRole(ChorProgressMonitor.Progress.COMPLETED);
        }
        logger.debug("processState exit");
    }

    private TargetAccountNumber doChorIn(Customer newCustomer, MoveRequestDetail movingOutDetails) {
        Chor chorIn = new Chor(null, // this is a new customer so a new account number is returned
                // from Target
                newCustomer, movingOutDetails.getDate(), ChorAction.ON.toString(),
                movingOutDetails.getAddress().getPropertyNum(), getFirstReading(movingOutDetails));

        return serviceFacade.getChorClient().setChor(chorIn.getAccountNum(), chorIn).getNewAccountNumber();
    }

    private ChorMeterRead getFirstReading(MoveRequestDetail move) {
        ChorMeterRead firstReadingOut = null;

        if (move.getMeterReadings() != null && !move.getMeterReadings().isEmpty()) {
            firstReadingOut = move.getMeterReadings().get(0);
        }
        return firstReadingOut;
    }

    private static AccountRoles createAccountRole(TargetAccountNumber accountNumber, Customer newCustomer) {
        AccountRoles role = new AccountRoles();
        role.setAccountNumber(accountNumber);
        role.setLeFirstName(newCustomer.getFirstName());
        role.setLeMiddleIntials(newCustomer.getMiddleInitial());
        role.setLeSurname(newCustomer.getLastName());
        role.setLeTitleCode(newCustomer.getTitleRef().getCode());
        role.setLeType(newCustomer.getIsIndividual() ? Indicator.INDIVIDUAL.getCode() : Indicator.BUSINESS.getCode());
        return role;
    }
}
