package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.targetconnector.client.api.setchor.ChorClientResponse;

import java.io.Serializable;

public class StateContext implements Serializable {

    private ChorClientResponse chorClientResponse;

    void setChorResponse(ChorClientResponse chorClientResponse) {
        this.chorClientResponse = chorClientResponse;
    }

    ChorClientResponse getChorClientResponse() {
        return this.chorClientResponse;
    }

}
