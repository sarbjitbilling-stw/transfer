package uk.co.stwater.api.osgi.rechor.memo;

import org.apache.commons.lang3.builder.ToStringBuilder;
import uk.co.stwater.api.osgi.model.rechor.ReChorRequest;

public class ReChorMemoRequest {
    ReChorRequest reChorRequest;
    String propertyAddress;

    public ReChorRequest getReChorRequest() {
        return reChorRequest;
    }

    public void setReChorRequest(final ReChorRequest reChorRequest) {
        this.reChorRequest = reChorRequest;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public void setPropertyAddress(final String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("reChorRequest", reChorRequest)
                .append("propertyAddress", propertyAddress)
                .toString();
    }
}
