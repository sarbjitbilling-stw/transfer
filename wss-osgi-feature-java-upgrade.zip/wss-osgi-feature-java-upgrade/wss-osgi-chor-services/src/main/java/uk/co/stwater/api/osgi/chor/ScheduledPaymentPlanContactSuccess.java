package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.payment.common.PaymentPlan;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;
import uk.co.stwater.targetconnector.client.api.payplan.PaymentPlan.Frequency;

public class ScheduledPaymentPlanContactSuccess implements CustomerContact {

    private static final String WEB_CREATE_CONTACT_TYPE = "WEB";
    private static final String PAYMENT_PLAN_CREATED_KEY = "Payment Plan Created:";
    private static final String OLD_PAYMENT_PLAN_METHOD_KEY = "Old Payment Plan Method: ";
    private static final String OLD_PAYMENT_PLAN_FREQUENCY_KEY = "Old Payment Plan Frequency: ";
    private static final String OLD_PAYMENT_PLAN_DATE_KEY = "Old Payment Plan Date: ";
    private static final String OLD_NO_OF_INSTALLMENT_KEY = "Number of Instalments: ";
    private static final String WAS_OLD_PAYMENTPLAN_PPC_KEY = "Was Old Plan a PPC: ";
    private static final String NEW_PAYMENT_PLAN_METHOD_KEY = "New Payment Plan Method: ";
    private static final String NEW_PAYMENT_PLAN_FREQUENCY_KEY = "New Payment Plan Frequency: ";
    private static final String NEW_PAYMENT_PLAN_DATE_KEY = "New Payment Plan Date: ";
    private static final String NEW_NO_OF_INSTALLMENT_KEY = "Number of Instalments: ";
    private static final String NEW_PLAN_FUTURE_START_KEY = "New Plan A Future Start (Yes/No): ";
    private static final String UPDATE_COMPLETED_TARGET_KEY = "Updates completed in Target:";
    private static final String COMPLETED_CHOR_PAYMENT_KEY = "CHOR completed.  Payment plan has been reset.";
    // Cancelled Contract 707
    private static final String CANCELLED_PLAN_KEY = "Customer has cancelled Payment Plan";
    private static final String CANCELLED_PLAN_SUCCESS_KEY = "CHOR completed.  Payment plan has been cancelled.";
    // Cancelled Contract 708
    private static final String PAYMENT_PLAN_FAIL_KEY = "Pay Plan Creation Failed in Target:";
    private static final String PAYMENT_PLAN_NEED_SET_KEY = "CHOR completed.  Payment plan needs to be reset.";
    // Cancelled Contract 709
    private static final String PAYMENT_PLAN_CANCELLED_SUCCESS_KEY = "Customer has requested to cancel the Payment Plan.";
    private static final String CHOR_COMPLETED_KEY = "CHOR completed. ";
    private static final String PAYMENT_PLAN_FAILED_IN_TARGET_KEY = "Payment plan cancellation failed in Target: ";
    private static final String PAYMENT_PLAN_NEED_TO_CANCEL_KEY = "Payment plan needs to be cancelled.";
    private static final String MOVING_HOME_EMAIL_KEY = "Email Moving House sent to : ";
    private static final String PAYMENT_PLAN_SUCCESS = "705";
    private static final String PAYMENT_PLAN_CANCEL_SUCCESS = "707";
    private static final String PAYMENT_PLAN_FAIL = "708";
    private static final String PAYMENT_PLAN_CANCEL_FAIL = "709";
    private static final String SETUP_PAYMENTPLAN_CANCEL_FAIL = "714";
    private static final String UNKNOW_POST_CODE_KEY = "Unkown Post Code";
    protected static final String PAYMENT_FREQUENCY_MONTHLY = "monthly";
    protected static final String PAYMENT_FREQUENCY_FORTNIGHTLY = "every 2 weeks";
    protected static final String PAYMENT_FREQUENCY_WEEKLY = "weekly";
    protected static final String PAYMENT_FREQUENCY_FOUR_WEEKLY = "every 4 weeks";
    private static final String CREATE_QUERY_VALUE = "Payment Plan Requested";
    // Cancelled Contract 714
    private static final String PP_METHOD_KEY = "Payment Plan Method: ";
    private static final String PP_FREQUENCY_KEY = "Payment Plan Frequency: ";
    private static final String PP_DATE_KEY = "Payment Plan Date: ";
    private static final String PP_PPC_KEY = "Was Plan a PPC ";
    private static final String PP_YES_KEY = "Yes";
    private static final String BILL_FAILED_TO_BE_PRODUCED = "Bill Failed To Be Produced: ";

    protected ChorRequest chorRequest;

    protected ChorResponse chorResponse;

    protected ContactNotesData contactNotesData;

    protected String postcode;

    protected TargetAccountNumber accountNumber;

    protected String legalEntityId;

    protected String contactNumber;

    protected String failureReason;

    protected String userName;

    protected ReferenceDataService referenceDataClientService;

    private boolean isSubstantiveResponse;

    public ScheduledPaymentPlanContactSuccess(ChorRequest chorRequest, ChorResponse chorResponse,
            TargetAccountNumber accountNumber, ContactNotesData contactNotesData, String contactNumber,
            String failureReason, String userName, ReferenceDataService referenceDataClientService) {
        this.chorRequest = chorRequest;
        this.chorResponse = chorResponse;
        this.contactNotesData = contactNotesData;
        this.contactNumber = contactNumber;
        this.accountNumber = accountNumber;
        this.failureReason = failureReason;
        this.userName = userName;
        this.referenceDataClientService = referenceDataClientService;
    }

    @Override
    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    @Override
    public String getLegalEntityNumber() {
        return legalEntityId;
    }

    @Override
    public String getPostcode() {
        if (chorRequest.getMovingInDetails() == null || chorRequest.getMovingInDetails().getAddress() == null
                || chorRequest.getMovingInDetails().getAddress().getPostcode() == null) {
            return UNKNOW_POST_CODE_KEY;
        } else {
            return chorRequest.getMovingInDetails().getAddress().getPostcode();
        }
    }

    @Override
    public String getFormattedNote() {
        StringBuilder builder = new StringBuilder();
        builder.append(CustomerContact.getFormattedCustomerDetails(contactNotesData)).append(NEW_LINE);
        if (PAYMENT_PLAN_SUCCESS.equals(contactNumber)) {
            buildFormattedNoteForCreateOnSuccessPlan(builder);
            isSubstantiveResponse = true;
        } else if (PAYMENT_PLAN_CANCEL_SUCCESS.equals(contactNumber)) {
            buildFormattedNoteForCreateOnSuccessCancel(builder);
            isSubstantiveResponse = true;
        } else if (PAYMENT_PLAN_FAIL.equals(contactNumber)) {
            buildFormattedNoteForCreateOnFailPlan(builder);
            isSubstantiveResponse = false;
        } else if (PAYMENT_PLAN_CANCEL_FAIL.equals(contactNumber)) {
            buildFormattedNoteForCreateOnFailCancel(builder);
            isSubstantiveResponse = false;
        } else if (SETUP_PAYMENTPLAN_CANCEL_FAIL.equals(contactNumber)) {
            buildFormattedNoteForPaymentPlanFailInSetupplanOption(builder);
            isSubstantiveResponse = false;
        }
        return builder.toString();
    }

    private void buildFormattedNoteForPaymentPlanFailInSetupplanOption(StringBuilder builder) {
        builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(CREATE_QUERY_VALUE).append(NEW_LINE);

        if (chorResponse.getChorProgressMonitor().getOldPaymentPlan() != null) {
            builder.append(PP_METHOD_KEY)
                    .append(referenceDataClientService.getRefDataDesc(RefDataType.FACILITY_CODE,
                            chorResponse.getChorProgressMonitor().getOldPaymentPlan().getFacilityCode(), userName))
                    .append(NEW_LINE);
            builder.append(PP_FREQUENCY_KEY)
                    .append(getFrequencyDescription(Frequency
                            .of(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getScheduleFreqCode())
                            .toString()))
                    .append(NEW_LINE);
            builder.append(PP_DATE_KEY).append(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getStartDate())
                    .append(NEW_LINE);
            builder.append(OLD_NO_OF_INSTALLMENT_KEY)
                    .append(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getInstallmentNumber())
                    .append(NEW_LINE);
            builder.append(PP_PPC_KEY)
                    .append(PaymentPlan.BudgetType.PPC
                            .equals(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getBudgetType()))
                    .append(NEW_LINE).append(NEW_LINE).append(NEW_LINE);
        } else {
            builder.append(PP_METHOD_KEY).append(NEW_LINE);
            builder.append(PP_FREQUENCY_KEY).append(NEW_LINE);
            builder.append(PP_DATE_KEY).append(NEW_LINE);
            builder.append(OLD_NO_OF_INSTALLMENT_KEY).append(NEW_LINE);
            builder.append(WAS_OLD_PAYMENTPLAN_PPC_KEY).append(NEW_LINE);
        }

        builder.append(NEW_LINE);
        builder.append(UPDATE_COMPLETED_TARGET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(BILL_FAILED_TO_BE_PRODUCED).append(NO).append(NEW_LINE);
        builder.append(PAYMENT_PLAN_FAILED_IN_TARGET_KEY).append(PP_YES_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(PAYMENT_PLAN_NEED_SET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(MOVING_HOME_EMAIL_KEY).append(chorRequest.getEmailAddress());
        builder.append(NEW_LINE);
    }

    private void buildFormattedNoteForCreateOnFailCancel(StringBuilder builder) {

        builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(PAYMENT_PLAN_CANCELLED_SUCCESS_KEY).append(NEW_LINE);

        builder.append(UPDATE_COMPLETED_TARGET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(CHOR_COMPLETED_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(PAYMENT_PLAN_FAILED_IN_TARGET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(PAYMENT_PLAN_NEED_TO_CANCEL_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(MOVING_HOME_EMAIL_KEY).append(chorRequest.getEmailAddress());
    }

    private void buildFormattedNoteForCreateOnFailPlan(StringBuilder builder) {

        builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(PAYMENT_PLAN_CREATED_KEY).append(NEW_LINE);

        if (chorResponse.getChorProgressMonitor().getOldPaymentPlan() != null) {
            builder.append(OLD_PAYMENT_PLAN_METHOD_KEY)
                    .append(referenceDataClientService.getRefDataDesc(RefDataType.FACILITY_CODE,
                            chorResponse.getChorProgressMonitor().getOldPaymentPlan().getFacilityCode(), userName))
                    .append(NEW_LINE);
            builder.append(OLD_PAYMENT_PLAN_FREQUENCY_KEY)
                    .append(getFrequencyDescription(Frequency
                            .of(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getScheduleFreqCode())
                            .toString()))
                    .append(NEW_LINE);
            builder.append(OLD_PAYMENT_PLAN_DATE_KEY)
                    .append(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getStartDate()).append(NEW_LINE);
            builder.append(OLD_NO_OF_INSTALLMENT_KEY)
                    .append(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getInstallmentNumber())
                    .append(NEW_LINE);
            builder.append(WAS_OLD_PAYMENTPLAN_PPC_KEY)
                    .append(PaymentPlan.BudgetType.PPC
                            .equals(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getBudgetType()))
                    .append(NEW_LINE).append(NEW_LINE).append(NEW_LINE);
        }
        if (chorResponse.getChorProgressMonitor().getNewPaymentPlan() != null) {
            builder.append(NEW_PAYMENT_PLAN_METHOD_KEY)
                    .append(referenceDataClientService.getRefDataDesc(RefDataType.FACILITY_CODE,
                            chorResponse.getChorProgressMonitor().getNewPaymentPlan().getFacilityCode(), userName))
                    .append(NEW_LINE);
            builder.append(NEW_PAYMENT_PLAN_FREQUENCY_KEY)
                    .append(getFrequencyDescription(Frequency
                            .of(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getScheduleFreqCode())
                            .toString()))
                    .append(NEW_LINE);
            builder.append(NEW_PAYMENT_PLAN_DATE_KEY)
                    .append(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getStartDate()).append(NEW_LINE);
            builder.append(NEW_NO_OF_INSTALLMENT_KEY)
                    .append(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getInstallmentNumber())
                    .append(NEW_LINE);
            builder.append(NEW_PLAN_FUTURE_START_KEY)
                    .append(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getSchedule().isEmpty())
                    .append(NEW_LINE);
        }

        builder.append(UPDATE_COMPLETED_TARGET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(PAYMENT_PLAN_FAIL_KEY).append(failureReason);
        builder.append(NEW_LINE);

        builder.append(PAYMENT_PLAN_NEED_SET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(MOVING_HOME_EMAIL_KEY).append(chorRequest.getEmailAddress());
    }

    private void buildFormattedNoteForCreateOnSuccessCancel(StringBuilder builder) {

        builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(CANCELLED_PLAN_KEY).append(NEW_LINE);

        builder.append(UPDATE_COMPLETED_TARGET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(CANCELLED_PLAN_SUCCESS_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(MOVING_HOME_EMAIL_KEY).append(chorRequest.getEmailAddress());
    }

    private void buildFormattedNoteForCreateOnSuccessPlan(StringBuilder builder) {

        builder.append(QUERY_DETAILS_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);
        builder.append(PAYMENT_PLAN_CREATED_KEY).append(NEW_LINE);

        if (chorResponse.getChorProgressMonitor().getOldPaymentPlan() != null) {

            builder.append(OLD_PAYMENT_PLAN_METHOD_KEY)
                    .append(referenceDataClientService.getRefDataDesc(RefDataType.FACILITY_CODE,
                            chorResponse.getChorProgressMonitor().getOldPaymentPlan().getFacilityCode(), userName))
                    .append(NEW_LINE);
            builder.append(OLD_PAYMENT_PLAN_FREQUENCY_KEY)
                    .append(getFrequencyDescription(Frequency
                            .of(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getScheduleFreqCode())
                            .toString()))
                    .append(NEW_LINE);
            builder.append(OLD_PAYMENT_PLAN_DATE_KEY)
                    .append(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getStartDate()).append(NEW_LINE);
            builder.append(OLD_NO_OF_INSTALLMENT_KEY)
                    .append(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getInstallmentNumber())
                    .append(NEW_LINE);
            builder.append(WAS_OLD_PAYMENTPLAN_PPC_KEY)
                    .append(PaymentPlan.BudgetType.PPC
                            .equals(chorResponse.getChorProgressMonitor().getOldPaymentPlan().getBudgetType()))
                    .append(NEW_LINE).append(NEW_LINE).append(NEW_LINE);
        }
        if (chorResponse.getChorProgressMonitor().getNewPaymentPlan() != null) {

            builder.append(NEW_PAYMENT_PLAN_METHOD_KEY)
                    .append(referenceDataClientService.getRefDataDesc(RefDataType.FACILITY_CODE,
                            chorResponse.getChorProgressMonitor().getNewPaymentPlan().getFacilityCode(), userName))
                    .append(NEW_LINE);
            builder.append(NEW_PAYMENT_PLAN_FREQUENCY_KEY)
                    .append(getFrequencyDescription(Frequency
                            .of(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getScheduleFreqCode())
                            .toString()))
                    .append(NEW_LINE);
            builder.append(NEW_PAYMENT_PLAN_DATE_KEY)
                    .append(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getStartDate()).append(NEW_LINE);
            builder.append(NEW_NO_OF_INSTALLMENT_KEY)
                    .append(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getInstallmentNumber())
                    .append(NEW_LINE);
            builder.append(NEW_PLAN_FUTURE_START_KEY)
                    .append(chorResponse.getChorProgressMonitor().getNewPaymentPlan().getSchedule().isEmpty())
                    .append(NEW_LINE);
        }

        builder.append(UPDATE_COMPLETED_TARGET_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(COMPLETED_CHOR_PAYMENT_KEY).append(NEW_LINE);
        builder.append(NEW_LINE);

        builder.append(MOVING_HOME_EMAIL_KEY).append(chorRequest.getEmailAddress());
    }

    @Override
    public String getContactType() {
        return WEB_CREATE_CONTACT_TYPE + contactNumber;
    }

    @Override
    public Long getPropertyNumber() {
        return null;
    }

    @Override
    public boolean isSubstantiveResponse() {
        return isSubstantiveResponse;
    }

    private String getFrequencyDescription(String fCode) {
        switch (fCode) {
        case "MONTHLY":
            return PAYMENT_FREQUENCY_MONTHLY;
        case "FORTNIGHTLY":
            return PAYMENT_FREQUENCY_FORTNIGHTLY;
        case "WEEKLY":
            return PAYMENT_FREQUENCY_WEEKLY;
        case "FOUR_WEEKLY":
            return PAYMENT_FREQUENCY_FOUR_WEEKLY;
        default:
            return fCode;
        }

    }
}
