package uk.co.stwater.api.osgi.chor.contact;

import java.text.ParseException;

import uk.co.stwater.api.osgi.chor.ChorContext;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;

/**
 * Created by tellis3 on 05/05/2017.
 */
public interface ChorContactFormatter {

    String formatExistingCustomerFailed(ContactType contactType, ChorContext chorContext, String errorMessage, ContactNotesData contactNotesData);

    String formatExistingCustomerSuccessful(ContactType contactType, ChorContext chorContext, ContactNotesData contactNotesData, TargetAccountNumber targetAccountNumber);

    String formatNewCustomerSuccessful(ContactType contactType, ChorContext chorContext, ContactNotesData contactNotesData) throws ParseException;

    String formatNewCustomerFailed(ContactType contactType, ChorContext chorContext, String errorMessage) throws ParseException;

}
