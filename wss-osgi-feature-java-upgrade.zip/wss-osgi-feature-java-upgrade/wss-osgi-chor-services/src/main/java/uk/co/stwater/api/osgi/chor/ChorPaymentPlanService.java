package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.common.ContactDto;

public interface ChorPaymentPlanService {

    ChorResponse createPaymentPlan(TargetAccountNumber accountNumber, String legalEntityNumber,
                                          ContactDto contactDto, String username, ChorRequest chorRequest);

    ChorResponse cancelPaymentPlan(TargetAccountNumber accountNumber, String legalEntityNumber, ContactDto contactDto,
                                          String username, ChorRequest chorRequest) throws ChorException;
}
