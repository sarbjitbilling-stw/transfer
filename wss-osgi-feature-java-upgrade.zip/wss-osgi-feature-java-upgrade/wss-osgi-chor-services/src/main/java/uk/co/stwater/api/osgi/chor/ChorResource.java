
package uk.co.stwater.api.osgi.chor;

import static org.apache.cxf.common.util.StringUtils.isEmpty;

import java.net.URI;
import java.util.Optional;
import java.util.function.Supplier;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import org.apache.http.HttpStatus;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.bill.BillService;
import uk.co.stwater.api.osgi.account.AccountService;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorDTO;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.Constants;
import uk.co.stwater.api.osgi.util.STWBaseException;

@Named
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public class ChorResource extends AbstractResource {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final String ACCOUNTS_URI = "wss/Accounts";
	private static final String ACCOUNTS_QUERY_ACCOUNT_NUMBER = "accountNumber";
	private static final String ACCOUNTS_QUERY_LEGAL_ENTITY_NUMBER = "legalEntityNumber";
	private static final String INVALID_REQUEST = "Invalid request.";

	@Inject
	ChorService chorService;

	@Inject
	ChorPaymentPlanService chorPaymentPlanService;
	
    @Inject
    @OsgiService
    private AccountService accountService;

    @Inject
	@OsgiService
    private BillService billService;

	@PUT
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/{accountNumber}/legal-entity/{legalEntity}")
	public Response submitChorExisting(@PathParam("accountNumber") TargetAccountNumber accountNumber,
			@PathParam("legalEntity") long legalEntityId, ChorRequest chorRequest) {

		if (isValidExisting(chorRequest) && accountNumber != null) {
			if (!TargetAccountNumber.isSameAccount(chorRequest.getAccountNumber(), accountNumber)
					|| legalEntityId != chorRequest.getCustomer().getLeNum()) {
				return Response.status(Status.CONFLICT).build();
			}
			try {
                ChorResponse response = chorService.moveHouseExisting(chorRequest, getContactDtoOrElseThrow(),
                        getUserIdentity().getUsername());
				return Response.status(Status.CREATED).entity(createChorDTO(response))
						.header(HEADER_DM, response.getStatus().getDisplayedMessage()).build();
			} catch (ServiceUnavailableException e) {
				ErrorDto errorDto = new ErrorDto(Response.Status.SERVICE_UNAVAILABLE.getStatusCode(), e.getMessage());
				return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(errorDto).build();
			} catch (ChorException ex) {
                logger.error("Failed to perform chor with input {} and error {}", chorRequest, ex.getMessage());
				ErrorDto errorDto = new ErrorDto(100, ex.getMessage());
				return Response.status(Status.SERVICE_UNAVAILABLE).entity(errorDto).build();
			}
		} else {
			ErrorDto errorDto = new ErrorDto(100, "ChorRequest data incomplete.");
			logger.warn(errorDto.getDescription());
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

	@PUT
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/{accountNumber}/legal-entity/{legalEntity}/payment-plans")
	public Response createPaymentPlan(@PathParam("accountNumber") TargetAccountNumber accountNumber,
									  @PathParam("legalEntity") String legalEntity, ChorRequest chorRequest) {
		Supplier<ChorResponse> createOperation = () -> chorPaymentPlanService.createPaymentPlan(accountNumber, legalEntity,
				getContactDto().get(), getUserIdentity().getUsername(), chorRequest);
		return processPaymentPlan(accountNumber, legalEntity, createOperation, Status.CREATED);
	}

	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/{accountNumber}/legal-entity/{legalEntity}/payment-plans")
	public Response cancelPaymentPlan(@PathParam("accountNumber") TargetAccountNumber accountNumber,
									  @PathParam("legalEntity") String legalEntity) {

		ChorRequest chorRequest = new ChorRequest();
		chorRequest.setAccountNumber(accountNumber);
		Optional<ContactDto> optionalContactDto = getContactDto();
		if (optionalContactDto.isPresent()) {
			chorRequest.setEmailAddress(optionalContactDto.get().getEmail());
			Supplier<ChorResponse> cancelOperation = () -> chorPaymentPlanService.cancelPaymentPlan(accountNumber, legalEntity,
					optionalContactDto.get(), getUserIdentity().getUsername(), chorRequest);
			return processPaymentPlan(accountNumber, legalEntity, cancelOperation, Status.OK);
		} else {
			ErrorDto errorDto = new ErrorDto(100, "ContactDto required for cancelling payment plan.");
			logger.warn(errorDto.getDescription());
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

	private Response processPaymentPlan(TargetAccountNumber accountNumber, String legalEntity,
										Supplier<ChorResponse> operation, Status status) {
		if (accountNumber != null || legalEntity != null) {
			try {
				ChorResponse response = operation.get();
				return Response.status(status).entity(createChorDTO(response))
						.header(HEADER_DM, response.getStatus().getDisplayedMessage()).build();
			} catch (ServiceUnavailableException e) {
				ErrorDto errorDto = new ErrorDto(Response.Status.SERVICE_UNAVAILABLE.getStatusCode(), e.getMessage());
				return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(errorDto).build();
			} catch (ChorException ex) {
				logger.error("Failed to perform chor payment plan with error {}", ex.getMessage());
				ErrorDto errorDto = new ErrorDto(100, ex.getMessage());
				return Response.status(Status.SERVICE_UNAVAILABLE).entity(errorDto).build();
			}
		} else {
			ErrorDto errorDto = new ErrorDto(100, "Chor Payment plan Request data incomplete.");
			logger.warn(errorDto.getDescription());
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

	@GET
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getChorDaysParameters() {
		ChorRequest chorRequest = chorService.getChorDaysParameters();
		return Response.status(Status.OK).entity(chorRequest).build();
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response createChorNew(ChorRequest chorRequest, @DefaultValue(Constants.STW) @HeaderParam(Constants.WSS_SITE) String site) {

		if (isValidNew(chorRequest)) {
			try {
				ChorResponse response;
				AccountBrand accountBrand =  AccountBrand.resolveBySite(site);
				if (getRequestHeaders(CONTACT_INFO_HEADER) != null) {					
                    response = chorService.moveHouseNew(chorRequest, getContactDtoOrElseThrow(),
                            getUserIdentity().getUsername(), accountBrand);
				} else {
					response = chorService.moveHouseNew(chorRequest, getUserIdentity().getUsername(), accountBrand);
				}
				if (response.getNewLegalEntityId() != null && response.getNewAccountNumber() != null) {
					URI uri = UriBuilder.fromPath(ACCOUNTS_URI)
							.queryParam(ACCOUNTS_QUERY_ACCOUNT_NUMBER, response.getNewAccountNumber())
							.queryParam(ACCOUNTS_QUERY_LEGAL_ENTITY_NUMBER, response.getNewLegalEntityId()).build();
					return Response.created(uri).entity(createChorDTO(response))
							.header(HEADER_DM, response.getStatus().getDisplayedMessage()).build();
				}
				return Response.status(Status.CREATED).entity(createChorDTO(response))
						.header(HEADER_DM, response.getStatus().getDisplayedMessage()).build();
			} catch (ServiceUnavailableException e) {
				ErrorDto errorDto = new ErrorDto(Response.Status.SERVICE_UNAVAILABLE.getStatusCode(), e.getMessage());
				return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(errorDto).build();
			} catch (ChorException ex) {
                logger.error("Failed to perform chor with input {}", chorRequest, ex);
				ErrorDto errorDto = new ErrorDto(100, ex.getMessage());
				return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(errorDto).build();
			}
		} else {
			ErrorDto errorDto = new ErrorDto(100, "ChorRequest data incomplete.");
			logger.warn(errorDto.getDescription());
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/bills")
	public Response createBill(ChorDTO chorDTO) {
		logger.debug("createBill invoked {}", chorDTO);
		try {
			if(isValidRequestForSimBill(chorDTO.getChorRequest())) {
				ChorResponse chorResponse = chorService.createBill(chorDTO, getUserIdentity().getUsername());
				logger.debug("successfully completed sim-bill {}", chorResponse);
				return Response.status(Response.Status.CREATED).entity(createChorDTO(chorResponse)).build();
			}
		} catch (ChorException e) {
			ErrorDto errorDto = getErrorDTO(e);
            logger.warn("A response exception occurred {}", errorDto);
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		}
		ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.CHOR_SERVICES, HttpStatus.SC_BAD_REQUEST, INVALID_REQUEST);
        logger.warn("An exception occurred {}", errorDto);
		return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
	}

	private boolean isValidExisting(ChorRequest request) {

		return !(request.getAccountNumber() == null || isEmpty(request.getContactNumber())
				|| isEmpty(request.getEmailAddress()) || request.getCustomer() == null
				|| isEmpty(request.getCustomer().getLastName()) || request.getCustomer().getLeNum() == null
				|| request.getMovingOutDetails() == null || request.getMovingOutDetails().getAddress() == null
				|| request.getMovingOutDetails().getAddress().getPropertyNum() == null
				|| request.getMovingOutDetails().getDate() == null || request.getMovingInDetails() == null);
	}

	private boolean isValidNew(ChorRequest request) {

		return !(isEmpty(request.getContactNumber()) || isEmpty(request.getEmailAddress())
				|| request.getMovingInDetails() == null || request.getMovingInDetails().getDate() == null
				|| request.getMovingInDetails().getAddress() == null);
	}

	private static ChorDTO createChorDTO(ChorResponse chorResponse) {
		ChorDTO chorDTO = new ChorDTO();
		chorDTO.setNewAccountNumber(chorResponse.getNewAccountNumber());
		chorDTO.setNewLegalEntityId(chorResponse.getNewLegalEntityId());
		chorDTO.setEmailAlreadyExists(chorResponse.getEmailAlreadyExists());
		chorDTO.setMonthLimitRequiringDocumentation(chorResponse.getMonthLimitRequiringDocumentation());
		chorDTO.setMoveInCharges(chorResponse.getMoveInCharges());
		chorDTO.setMoveOutCharges(chorResponse.getMoveOutCharges());
		chorDTO.setMeterReadRequired(chorResponse.isMeterReadRequired());
		chorDTO.setHavePaymentPlan(chorResponse.isPaymentPlan());
		chorDTO.setSupplyType(chorResponse.getSupplyType());
		chorDTO.setPaymentPlan(chorResponse.getChorProgressMonitor().getNewPaymentPlan());
		ChorState chorState = chorResponse.getChorProgressMonitor().getChorStateManager().getChorState();
		if(chorState == ChorState.CREATE_PAYMENT_PLAN_FAILED) {
			chorDTO.setPlanCreationFailed(true);
		}
		if (chorResponse.isExceptionOccurred()) {
			chorDTO.setErrorMessage(chorResponse.getErrorMessage());
		}
		chorDTO.setChorSuccess(chorResponse.isSuccess());
		return chorDTO;
	}

	private static ErrorDto getErrorDTO(STWBaseException e) {
		ErrorDto errorDto = null;
		if(e.getHttpStatusCode() != null && e.getHttpStatusCode().getStatusCode() >= 0) {
			errorDto = new ErrorDto(ErrorDto.ErrorCategory.CHOR_SERVICES, e.getHttpStatusCode().getStatusCode(), e.getMessage());
		}else {
			errorDto = new ErrorDto(ErrorDto.ErrorCategory.CHOR_SERVICES, HttpStatus.SC_BAD_REQUEST, e.getMessage());
		}
		return errorDto;
	}

	private static boolean isValidRequestForSimBill(ChorRequest chorRequest) {
    	if(chorRequest != null && chorRequest.getMovingOutDetails() != null) {
			MoveRequestDetail moveRequestDetail = chorRequest.getMovingOutDetails();
			return (moveRequestDetail.getAddress() != null && moveRequestDetail.getAddress().getPropertyNum() != null &&
					moveRequestDetail.getDate() != null);
		}
		return false;
	}
}