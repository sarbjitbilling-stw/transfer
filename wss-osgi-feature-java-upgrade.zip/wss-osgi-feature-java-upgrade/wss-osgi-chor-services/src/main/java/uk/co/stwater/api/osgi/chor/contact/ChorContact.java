package uk.co.stwater.api.osgi.chor.contact;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;

public class ChorContact implements CustomerContact {

    private TargetAccountNumber accountNumber;
    private String legalEntityNumber;
    private String postcode;
    private String contactType;
    private String note;
    private Long propertyNumber;
    private boolean substantiveResponse;


    public ChorContact(TargetAccountNumber accountNumber, Long legalEntityNumber, String postcode,
                       String contactType, String note, boolean substantiveResponse, Long propertyNumber) {
       
        this.accountNumber = accountNumber;
        if(legalEntityNumber!=null){
            this.legalEntityNumber = legalEntityNumber.toString();
        }
        this.postcode = postcode;
        this.contactType = contactType;
        this.note = note;
        this.substantiveResponse = substantiveResponse;
        this.propertyNumber = propertyNumber;
    }

    @Override
    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    @Override
    public String getLegalEntityNumber() {
        return legalEntityNumber;
    }

    @Override
    public String getPostcode() {
        return postcode;
    }

    @Override
    public String getFormattedNote() {
        return note;
    }

    @Override
    public String getContactType() {
        return this.contactType;
    }

    @Override
    public Long getPropertyNumber() {
        return propertyNumber;
    }

    @Override
    public boolean isSubstantiveResponse() {
        return this.substantiveResponse;
    }

    @Override
    public String toString() {
        return "ChorContact{" +
                "accountNumber='" + accountNumber + '\'' +
                ", postcode='" + postcode + '\'' +
                ", contactType='" + contactType + '\'' +
                ", note='" + note + '\'' +
                ", substantiveResponse=" + substantiveResponse +
                '}';
    }
}


