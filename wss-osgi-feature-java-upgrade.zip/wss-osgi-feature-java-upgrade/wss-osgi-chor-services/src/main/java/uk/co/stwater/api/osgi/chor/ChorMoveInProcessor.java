package uk.co.stwater.api.osgi.chor;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.targetconnector.client.api.insertmailingaddress.MailingAddress;
import uk.co.stwater.targetconnector.client.api.setchor.Chor;
import uk.co.stwater.targetconnector.client.api.setchor.ChorClientResponse;

import java.time.LocalDate;

import static uk.co.stwater.api.osgi.model.constants.GlobalConstants.UNKNOWN_ACCOUNT_NUMBER;

public class ChorMoveInProcessor extends AbstractChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorMoveInProcessor.class);

    ChorMoveInProcessor(ServiceFacade serviceFacade, ChorStateManager chorStateManager, ChorStateProcessor nextStateProcessor) {
        super(serviceFacade, chorStateManager, nextStateProcessor);
    }

    @Override
    public boolean canProcess(ChorState chorState) {
        return false;
    }

    @Override
    protected void processState(ChorContext chorContext) {
        logger.debug("processState entry");
        if (chorContext.isBillPayerAtMovingInAddress() && chorContext.getMovingInDetails().getDate() != null) {
            // JH TD1576 added the move in date check as it was not getting set for an out
            // of area customer
            // and falling over in the set chor.
            logger.info("Run method to perfom common 1 and 2");
            ChorClientResponse chorClientResponse = moveIn(chorContext.getAccountNumber(), chorContext.getCustomer(),
                    chorContext.getMovingInDetails(), chorContext.getNewAddressPreviousCustomer(), chorStateManager);
            chorContext.getChorResponse().setForcedOutAccountNumber(chorClientResponse.getForcedOutAccountNumber());
            StateContext stateContext = new StateContext();
            stateContext.setChorResponse(chorClientResponse);
            StateContextHolder.setContext(stateContext);
        } else {
            chorStateManager.moveInChorOn(ChorProgressMonitor.Progress.NOT_ATTEMPTED)
                    .moveInAddress(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
        }
        logger.info("Move out - move in chor successfully completed - creating contact");
        chorContext.getChorResponse().setSuccess(true);
        logger.debug("processState exit");
    }

    private ChorClientResponse moveIn(TargetAccountNumber movingOutAccountNumber, Customer customer,
                                      MoveRequestDetail movingInDetails, Address newAddressPreviousCustomer,
                                      ChorStateManager chorStateManager) throws STWTechnicalException, STWBusinessException {

        ChorMeterRead firstReadingIn = null;
        if (movingInDetails.getMeterReadings() != null && !movingInDetails.getMeterReadings().isEmpty()) {
            firstReadingIn = movingInDetails.getMeterReadings().get(0);
        }

        Address movingInAddress = movingInDetails.getAddress();

        /*
         * need to set account number to null, otherwise chor request fails for new customer
         * https://stwater-cms.atlassian.net/browse/FW-4479
         */
        if (movingOutAccountNumber.equals(UNKNOWN_ACCOUNT_NUMBER)) {
            movingOutAccountNumber = null;
        }
        Chor chorIn = new Chor(movingOutAccountNumber, customer, movingInDetails.getDate(), ChorAction.ON.toString(),
                movingInAddress.getPropertyNum() == null ? NO_PROPERTY_NUMBER : movingInAddress.getPropertyNum(),
                firstReadingIn);

        logger.info("Common 1 - SetChor (ON) : for moving in to new property");
        ChorClientResponse chorClientResponse = serviceFacade.getChorClient().setChor(chorIn.getAccountNum(), chorIn);
        chorStateManager.moveInChorOn(ChorProgressMonitor.Progress.COMPLETED);

        Long newLegalEntityId = chorClientResponse.getNewLegalEntityId();
        if (newLegalEntityId != null) {
            customer.setId(String.valueOf(newLegalEntityId));
        }

        if (newAddressPreviousCustomer != null
                && StringUtils.isNotEmpty(newAddressPreviousCustomer.getAddressDescription())) {
            logger.info("Common 2 - InsertMailingAddress : for person 'forced out' of property");
            // NA QC1682 Only insert the mail address if the address entry is not a manual
            // entry
            if (MailingAddress.USER_DEFINED.equals(newAddressPreviousCustomer.getId())
                    || chorClientResponse.getForcedOutAccountNumber().getAccountNumberAsLong() == 0) {
                // not attempted an insert Mailing Address
                chorStateManager.moveInAddress(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
            } else {
                insertMailingAddress(chorClientResponse.getForcedOutAccountNumber(), movingInDetails.getDate(),
                        newAddressPreviousCustomer, chorStateManager);
            }
        }
        chorStateManager.moveInAddress(ChorProgressMonitor.Progress.COMPLETED);
        return chorClientResponse;
    }

    private void insertMailingAddress(TargetAccountNumber accountNumber, LocalDate date, Address address,
                                      ChorStateManager chorStateManager) {
        if (address.getAddressCode() != NO_ADDRESS_CODE) {
            MailingAddress mailingAddress = new MailingAddress(accountNumber, date, address);
            serviceFacade.getMailingAddressClient().insertMailingAddress(mailingAddress);
            chorStateManager.forcedOutMailingAddress(ChorProgressMonitor.Progress.COMPLETED);
        } else {
            chorStateManager.forcedOutMailingAddress(ChorProgressMonitor.Progress.NOT_ATTEMPTED);
        }

    }
}
