package uk.co.stwater.api.osgi.chor.agent;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.LegalEntityReuseRequest;
import uk.co.stwater.api.osgi.model.LegalEntityReuseResponse;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.propertyaccount.get.IIBGetPropertyAccountClient;
import uk.co.stwater.iib.client.api.propertyaccount.get.IIBGetPropertyAccountResponse;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesForAccountClient;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesResponse;

@Named
@OsgiServiceProvider(classes = { LegalEntityService.class })
public class LegalEntityServiceImpl implements LegalEntityService {
	private Logger log = LoggerFactory.getLogger(LegalEntityServiceImpl.class);
	@Inject
	@OsgiService
	private IIBGetRolesForAccountClient rolesClient;
	
	@Inject
	@OsgiService
	private IIBGetPropertyAccountClient propertyAccountClient;

	@Override
	public LegalEntityReuseResponse checkLegalEntityReuse (
			final LegalEntityReuseRequest legalEntityReuseRequest, 
			final String authToken) {
		log.debug("checkLegalEntityReuse start");

		validateRequest(legalEntityReuseRequest);
		
		final AccountLegalEntityHolder providedLegalEntities = makeLegalEntityHolder (legalEntityReuseRequest);
		
		final LegalEntityReuseResponse responseContent = makeCheckResponse();
		
		final List<IIBGetPropertyAccountResponse> accountsForPrimary = 
				propertyAccountClient.getPropertyAccountsForCustomer(providedLegalEntities.getPrimaryLegalEntity(), authToken);
		if (log.isDebugEnabled()) {
			log.debug("retrieved property accounts : {}", 
					accountsForPrimary.stream()
						.map(IIBGetPropertyAccountResponse::getNumber)
						.collect(Collectors.toList()));
		}

		accountsForPrimary
			.stream()
			.filter(Objects::nonNull)
			.map(IIBGetPropertyAccountResponse::getNumber)
			.filter(Objects::nonNull)
			.forEach(accountNumber -> {
				if (responseContent.getReuseLE()) {
					final TargetAccountNumber targetAccountNumber = new TargetAccountNumber(accountNumber, null); 
					final List<IIBGetRolesResponse> rolesForAccount = rolesClient.getRolesForAccount(targetAccountNumber, authToken);
					log.debug("obtained {} roles for account {} ", rolesForAccount.size(), targetAccountNumber);
					final AccountLegalEntityHolder resolvedLegalEntityHolder = makeAccountLegalEntityHolder(rolesForAccount);
					if (resolvedLegalEntityHolder.getPrimaryLegalEntity() == null) {
						log.trace("no legal entity discovered for account, skipping it");
					} else {
						if (isIncompatibleLegalEntityList(providedLegalEntities, resolvedLegalEntityHolder)) {
							log.debug("found incompatible account ({}) for specified primary legal entity {} ", accountNumber, providedLegalEntities.getPrimaryLegalEntity());
							updateResponseWithIncompatibleAccount(responseContent, accountNumber);
						}
					}
				}
			});
		if (responseContent.getReuseLE()) {
			log.debug("No incompatible accounts discovered - primaryLE {} can be reused", providedLegalEntities.getPrimaryLegalEntity());
		}
		return responseContent;
	}

	private void updateResponseWithIncompatibleAccount (
			final LegalEntityReuseResponse response,
			final Long accountId) {
		response.setAccountId(accountId);
		response.setReuseLE(false);
	}

	/**
	 * Determines if the specified legal entities are incompatible.<br/>
	 * In this context, incompatibility is considered to be where
	 * <ul>
	 * <li>The primary role legal entity is equal on both sets of provided entities</li>
	 * <li>AND the list of co-primary roles in the specified entities are not identical</li>   
	 * </lu>
	 *
	 * @param providedLegalEntities
	 * @param resolvedLegalEntities
	 * @return true for incompatible sets of entities.
	 */
	private boolean isIncompatibleLegalEntityList (
			final AccountLegalEntityHolder providedLegalEntities,
			final AccountLegalEntityHolder resolvedLegalEntities) {
		boolean isIncompatible = false;
		if (resolvedLegalEntities.getPrimaryLegalEntity() != null) {
			if (resolvedLegalEntities.getPrimaryLegalEntity().equals(providedLegalEntities.getPrimaryLegalEntity())) {
				if (resolvedLegalEntities.getCoPrimaryLegalEntities().size() != providedLegalEntities.getCoPrimaryLegalEntities().size()) {
					log.debug("incompatible account due to different coprimary list length");
					isIncompatible = true;
				} else {
					isIncompatible = (!resolvedLegalEntities.getCoPrimaryLegalEntities().containsAll(providedLegalEntities.getCoPrimaryLegalEntities()));
					if (isIncompatible) {
						log.debug("incompatible account due to distinct co-primary legal entities");
					}
				}
			}
		}
		return isIncompatible;
	}

	private AccountLegalEntityHolder makeAccountLegalEntityHolder (final List<IIBGetRolesResponse> rolesForAccount) {
		final AccountLegalEntityHolder resolvedLegalEntities = new AccountLegalEntityHolder();
		for (IIBGetRolesResponse role : rolesForAccount) {
			final Long legalEntityForRole = role.getLegalEntityNo();
			if (role.getRole() != null && role.getRole().getCode() != null && legalEntityForRole != null) {
				final String roleCode = role.getRole().getCode();
				if (roleCode.equals(MovePropertyServiceImpl.ROLE_PRIMARY)) {
					resolvedLegalEntities.setPrimaryLegalEntity(legalEntityForRole);	
				}
				else if (roleCode.equals(MovePropertyServiceImpl.ROLE_CO_PRIMARY)) {
					resolvedLegalEntities.getCoPrimaryLegalEntities().add(legalEntityForRole);
				}
			}
		}
		return resolvedLegalEntities;
	}
	
	private LegalEntityReuseResponse makeCheckResponse () {
		final LegalEntityReuseResponse responseContent = new LegalEntityReuseResponse();
		responseContent.setReuseLE(true);
		return responseContent;
	}
	
	private void validateRequest (final LegalEntityReuseRequest legalEntityCheck) {
		if (legalEntityCheck.getPrimary() == null) {
			log.debug("The specified legal entity ID is mandatory");
			throw new STWBusinessException("The specified legal entity ID is mandatory");
		}
	}
	
	private AccountLegalEntityHolder makeLegalEntityHolder (final LegalEntityReuseRequest request) {
		final AccountLegalEntityHolder holder = new AccountLegalEntityHolder();
		holder.setPrimaryLegalEntity(request.getPrimary());
		holder.getCoPrimaryLegalEntities().addAll(request.getCoPrimary());
		return holder;
	}

	/**
	 * Container class for incoming requests and resolved legal entities.
	 *
	 * @author Andrew Landeg
	 *
	 */
	private static class AccountLegalEntityHolder {
		private Long primaryLegalEntity;
		private final Set<Long> coPrimaryLegalEntities = new HashSet<>();

		public Long getPrimaryLegalEntity() {
			return primaryLegalEntity;
		}

		public void setPrimaryLegalEntity(Long primaryLegalEntity) {
			this.primaryLegalEntity = primaryLegalEntity;
		}
		
		public Set<Long> getCoPrimaryLegalEntities() {
			return coPrimaryLegalEntities;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("AccountLegalEntityHolder [primaryLegalEntity=");
			builder.append(primaryLegalEntity);
			builder.append(", coPrimaryLegalEntities=");
			builder.append(coPrimaryLegalEntities);
			builder.append("]");
			return builder.toString();
		}
	}
}
