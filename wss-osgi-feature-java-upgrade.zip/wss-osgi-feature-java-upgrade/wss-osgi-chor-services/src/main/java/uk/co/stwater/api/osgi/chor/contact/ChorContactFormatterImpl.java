/*
 *
 *  * Copyright (c) Severn Trent Systems. All Rights Reserved.
 *  *
 *  * This software is the confidential and proprietary information
 *  * of Severn Trent Systems ("Confidential Information").  You shall
 *  * not disclose such Confidential Information and shall use it only
 *  * in accordance with the terms of your license agreement.
 *  *
 *  * SEVERN TRENT SYSTEMS MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT
 *  * THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 *  * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 *  * NON-INFRINGEMENT. SEVERN TRENT SYSTEMS SHALL NOT BE LIABLE FOR
 *  * ANY DAMAGES SUFFERED BY THE LICENSEE AS A RESULT OF USING,
 *  * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package uk.co.stwater.api.osgi.chor.contact;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.chor.ChorConfigService;
import uk.co.stwater.api.osgi.chor.ChorContext;
import uk.co.stwater.api.osgi.chor.ChorProgressMonitor;
import uk.co.stwater.api.osgi.chor.ChorResponse;
import uk.co.stwater.api.osgi.chor.ChorState;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.model.payment.common.PaymentPlan;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.payment.scheduled.ScheduledPaymentService;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.targetconnector.client.api.addresses.UKPostcode;
import uk.co.stwater.targetconnector.client.api.addresses.UKPostcodeParser;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContact;
import uk.co.stwater.targetconnector.client.api.directdebit.PaymentMandate;


@Named
@OsgiServiceProvider(classes = {ChorContactFormatterImpl.class})
public class ChorContactFormatterImpl implements ChorContactFormatter {

    public static final String FACILITY_CODE_DIRECT_DEBIT = "D";
    public static final String FREQUENCY_CODE_MONTHLY = "M";
    public static final String YES = "Yes";
    public static final String NO = "No";
    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String EMPTY_STRING = "";
    private static final String QUERY_DETAILS = "Query Details:";
    private static final String EMAIL_MOVING_HOUSE_SENT_TO = "Email Moving House sent to ";
    private static final String PERIOD = ".";
    private static final String ADDITIONAL_INFORMATION = "Additional Information";
    private static final String NONE_PROVIDED = "None provided";
    private static final String METER_READING = "Meter Reading: ";
    private static final String N_A = "N/A";
    private static final String LONG_FORMAT = "###########0";
    private static final String Y = "Y";
    private static final String CANCEL_FAIL_QUERY_VALUE1 = "Customer requested to cancel payment plan";
    private static final String FAILURE_VALUE = "Update to Target failed. Action needs to be taken. ";
    private static final String CANCEL_FAIL_QUERY_VALUE2 = "Plan needs to be cancelled";
    private static final String TARGET_NOT_UPDATED1 = "Payment plan creation failed in Target ";
    private static final String TARGET_NOT_UPDATED2 = "Payment plan needs to be set up.";
    private static final String CREATE_QUERY_VALUE = "Payment Plan Requested";
    private static final String PREFERRED_PAYMENT_DATE = "Preferred payment date ";
    private static final String FREQUENCY_KEY = "Frequency ";
    private static final String NUMBER_OF_PAYMENTS = "Number of payments ";
    private static final String DIRECT_DEBIT_KEY = "Direct Debit ";
    private static final String BANK_ACCOUNT_KEY = "Bank account number ";
    private static final String BANK_SORT_CODE_KEY = "Bank sort code ";
    private static final String BANK_ACCOUNT_HOLDER_KEY = "Bank account holders name ";
    private static final String CREATE_EMAIL_KEY = "Email 'Payment Plan Request' sent to ";
    private static final String START_DATE = "Start date ";
    private static final Long NO_PAYMENT_NUMBER_FOUND = 0L;
    private static final String CANCEL_EMAIL_KEY = "Email 'Payment Plan Cancelled' sent to ";
    DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final String NEW_LINE = System.getProperty("line.separator");
    private static final String UPDATE_COMPLETED_TARGET_KEY = "Updates completed in Target:";
    private static final String CHOR_COMPLETED_KEY = "CHOR completed. Bill To Be Issued, Payment Plan Check Required.";
    private static final String MOVING_HOME_EMAIL_KEY = "Email Moving House sent to : ";
    protected static final String PAYMENT_FREQUENCY_MONTHLY = "monthly";
    protected static final String PAYMENT_FREQUENCY_FORTNIGHTLY = "every 2 weeks";
    protected static final String PAYMENT_FREQUENCY_WEEKLY = "weekly";
    protected static final String PAYMENT_FREQUENCY_FOUR_WEEKLY = "every 4 weeks";
    private static final String BILL_FAILED_TO_BE_PRODUCED = "Bill Failed To Be Produced: ";
    private static final String BILL_REQUESTED = "Bill Requested: ";
    
    @Inject
    private ChorConfigService configService;

    @OsgiService
    @Inject
    private ReferenceDataService referenceDataClientService;
    
	@Inject
	@OsgiService
	private ScheduledPaymentService scheduledPaymentService;

    @Override
    public String formatExistingCustomerSuccessful(ContactType contactType, ChorContext chorContext, ContactNotesData contactNotesData, TargetAccountNumber targetAccountNumber){
        StringBuffer note = new StringBuffer();
        ContactTypes type = contactType.getType();

        // Probate contact type. Refer to main contact for details
        if (ContactTypes.WEB667.equals(type)){
            note.append(CustomerContact.getFormattedCustomerDetails(contactNotesData));
            note.append(NEW_LINE);
            note.append(QUERY_DETAILS).append(NEW_LINE);
            note.append("Change of responsibility has been completed.  See CHOR contact for full details.").append(NEW_LINE);
            note.append("PROBATE special condition exists on account").append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(getSuccessfulSharedEnding(contactType.getType(), chorContext.getEmailAddress()));
        }
        //QC1718 - The format of this contact needs to be updated to reflect what the contact template specifies.
        else if (ContactTypes.WEB650.equals(type))
        {
            note.append(CustomerContact.getFormattedCustomerDetails(contactNotesData));
            note.append(NEW_LINE);
            note.append(QUERY_DETAILS).append(NEW_LINE);
            note.append("Changes have been made to the responsibility for this account and ");
            note.append("you may need to review their special condition and the waterservices provided.").append(NEW_LINE);
            note.append("For details of the change see the contact message of "+ LocalDate.now().format(DATE_FORMATTER)).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(getSuccessfulSharedEnding(contactType.getType(), chorContext.getEmailAddress()));
        }
        else if(ContactTypes.WEB675.equals(type)){
            //QC1682 - check if the contact is for the previous occupier and set the forwarding address
            //as a new contact on the previous customers account
            return formatPreviousOccupantAddressAQ(chorContext.getNewAddressPreviousCustomer()).toString();
        }
        else if(ContactTypes.WEB623.equals(type)){
            note.append(CustomerContact.getFormattedCustomerDetails(contactNotesData));
            note.append(NEW_LINE);
            note.append(QUERY_DETAILS).append(NEW_LINE);
            note.append(CANCEL_FAIL_QUERY_VALUE1).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(FAILURE_VALUE).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(CANCEL_FAIL_QUERY_VALUE2).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(CANCEL_EMAIL_KEY).append(chorContext.getEmailAddress()).append(NEW_LINE);
            note.append(NEW_LINE);
        }
        else if(ContactTypes.WEB714.equals(type)){        	
        	note.append(CustomerContact.getFormattedCustomerDetails(contactNotesData));
            note.append(NEW_LINE);
            note.append(QUERY_DETAILS).append(NEW_LINE);
            note.append(BILL_REQUESTED).append(YES).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(UPDATE_COMPLETED_TARGET_KEY).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(BILL_FAILED_TO_BE_PRODUCED).append(YES).append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(NEW_LINE);
            note.append(CHOR_COMPLETED_KEY).append(NEW_LINE);            
            note.append(NEW_LINE);
            note.append(MOVING_HOME_EMAIL_KEY).append(chorContext.getEmailAddress()).append(NEW_LINE);
            note.append(NEW_LINE);
        }
        else if(ContactTypes.WEB626.equals(type)){

            PaymentPlan oldPaymentPlan = chorContext.getChorResponse().getChorProgressMonitor().getOldPaymentPlan();
            PaymentMandate oldPaymentMandate = chorContext.getChorResponse().getChorProgressMonitor().getOldPaymentMandate();

            note.append(CustomerContact.getFormattedCustomerDetails(contactNotesData));
            note.append(NEW_LINE);
            note.append(QUERY_DETAILS).append(NEW_LINE);
            note.append(CREATE_QUERY_VALUE).append(NEW_LINE);
            if(FREQUENCY_CODE_MONTHLY.equals(oldPaymentPlan.getScheduleFreqCode())) {
                note.append(PREFERRED_PAYMENT_DATE).append(oldPaymentPlan.getPaymentDay()).append(NEW_LINE);
            } else {
                if(oldPaymentPlan.getStartDate() != null) {
                    note.append(START_DATE).append(oldPaymentPlan.getStartDate().format(DATE_FORMATTER)).append(NEW_LINE);
                }
            }
            note.append(FREQUENCY_KEY).append(referenceDataClientService.getRefDataDesc(RefDataType.SCHEDULED_FREQUENCY_CODE, oldPaymentPlan.getScheduleFreqCode(), chorContext.getUsername())).append(NEW_LINE);
            note.append(NUMBER_OF_PAYMENTS).append(oldPaymentPlan.getInstallmentNumber() != null ? oldPaymentPlan.getInstallmentNumber() : NO_PAYMENT_NUMBER_FOUND).append(NEW_LINE);
            if(oldPaymentPlan.getFacilityCode().equals(FACILITY_CODE_DIRECT_DEBIT)) {
                note.append(DIRECT_DEBIT_KEY).append(YES).append(NEW_LINE);
                note.append(BANK_ACCOUNT_KEY).append(oldPaymentMandate.getBankNumber()).append(NEW_LINE);
                note.append(BANK_SORT_CODE_KEY).append(oldPaymentMandate.getSortCode()).append(NEW_LINE);
                note.append(BANK_ACCOUNT_HOLDER_KEY).append(oldPaymentMandate.getAccountHolderName()).append(NEW_LINE);
            } else {
                note.append(DIRECT_DEBIT_KEY).append(NO);
            }
            note.append(NEW_LINE);
            note.append(NEW_LINE).append(TARGET_NOT_UPDATED1).append(chorContext.getChorResponse().getChorProgressMonitor().getCreateNewPaymentPlanErrorReason()).append(NEW_LINE);
            note.append(NEW_LINE).append(TARGET_NOT_UPDATED2).append(NEW_LINE);
            note.append(CREATE_EMAIL_KEY).append(chorContext.getEmailAddress()).append(NEW_LINE);
            note.append(NEW_LINE);
        }
        else
        {
            note.append(formatChangeResponsibility(
                    contactNotesData,
                    chorContext.getMovingOutDetails(),
                    chorContext.getMovingInDetails(),
                    chorContext.isBillPayerAtMovingInAddress(),
                    chorContext.getResponsibilities(),
                    chorContext.getNewAddressPreviousCustomer(),
                    chorContext.getContactNumber()));
            note.append(formatMoveOutProgress(chorContext.getChorResponse().getChorProgressMonitor()));
            note.append(formatMoveInProgress(false, chorContext.getChorResponse().getChorProgressMonitor()));
            note.append(getSuccessfulSharedEnding(contactType.getType(), chorContext.getEmailAddress()));
        }
        return note.toString();

    }

    @Override
    public String formatNewCustomerSuccessful(ContactType contactType, ChorContext chorContext, ContactNotesData contactNotesData) throws ParseException{

        StringBuilder note = new StringBuilder();

        if(ContactTypes.WEB675.equals(contactType.getType())){
            //QC1682 - check if the contact is for the previous occupier and set the forwarding address
            //as a new contact on the previous customers account
            return formatPreviousOccupantAddressAQ(chorContext.getNewAddressPreviousCustomer()).toString();

        }else{

            note.append(formatNewCustomer(
                    chorContext.getMovingInDetails(),
                    chorContext.getResponsibilities(),
                    chorContext.getNewAddressPreviousCustomer(),
                    chorContext.getContactNumber()
            ));
            note.append(formatMoveInProgress(true,  chorContext.getChorResponse().getChorProgressMonitor()));
        }
        note.append(getSuccessfulSharedEnding(contactType.getType(), chorContext.getEmailAddress()));
        return note.toString();
    }


    private String getSuccessfulSharedEnding(ContactTypes type, String emailAddress) {
        StringBuilder note = new StringBuilder();
        //JH td1206 for web665 and web668 we need to update the comment on the contact.
        //because chor was a success but the pp needs reviewing
        if (type != null) {
            if (ContactTypes.WEB665.equals(type) || (ContactTypes.WEB668.equals(type))) {
                note.append(NEW_LINE);
                note.append("CHOR completed. Payment plan needs to be reviewed. ").append(NEW_LINE);
                note.append(NEW_LINE);
            }
        }
        note.append(EMAIL_MOVING_HOUSE_SENT_TO).append(emailAddress).append(PERIOD);
        return note.toString();
    }


    @Override
    public String formatExistingCustomerFailed(ContactType contactType, ChorContext chorContext, String errorMessage, ContactNotesData contactNotesData) {
        StringBuilder note = new StringBuilder();

        ContactTypes type = contactType.getType();

        note.append(formatChangeResponsibility(
                contactNotesData,
                chorContext.getMovingOutDetails(),
                chorContext.getMovingInDetails(),
                chorContext.isBillPayerAtMovingInAddress(),
                chorContext.getResponsibilities(),
                chorContext.getNewAddressPreviousCustomer(),
                chorContext.getContactNumber()
        ));

        //QC1718 - The format of this contact needs to be updated to reflect what the contact template specifies.
        if (ContactTypes.WEB650.equals(type)) {
            note.append(CustomerContact.getFormattedCustomerDetails(contactNotesData));
            note.append(NEW_LINE);
            note.append(QUERY_DETAILS).append(NEW_LINE);
            note.append("Changes have been made to the responsibility for this account and ");
            note.append("you may need to review their special condition and the waterservices provided.").append(NEW_LINE);
            note.append("For details of the change see the contact message of " + LocalDate.now().format(DATE_FORMATTER)).append(NEW_LINE);
            note.append(NEW_LINE);
        } else if (ContactTypes.WEB651.equals(type)) {
            note.append("CHOR not completed as customer entered forwarding address manually.").append(NEW_LINE);
            note.append(NEW_LINE);
        } else if (ContactTypes.WEB652.equals(type)) {
            int limitForBillPayer = configService.getMonthsInPastEvidenceRequiredForBillPayer();
            int limitForNonBillPayer = configService.getMonthsInPastEvidenceRequiredForNonBillPayer();
            note.append("Move out date is greater than " + limitForNonBillPayer + "/" + limitForBillPayer + " months prior to current date. Customer asked to provide documentary evidence of vacation date.").append(NEW_LINE);
            note.append(NEW_LINE);
        } else {
            if (ContactTypes.WEB655.equals(type)) {
                note.append("Target not updated as account is post judgement.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB656.equals(type)) {
                note.append("Reading failed validation and CHOR not completed.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB657.equals(type)) {
                note.append("Target not updated as non-tariff account.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB658.equals(type)) {
                note.append("Target not updated as no tariff assigned to the account.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB661.equals(type)) {
                note.append("Target not updated as network special condition exists.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB662.equals(type)) {
                note.append("Target not updated as aggregate special condition exists.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB663.equals(type)) {
                note.append("Target not updated as vulnerable special condition exists.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if(ContactTypes.WEB700.equals(type)) {
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
            }
            //JH td1206
            //change to contacts raised if account has a payment plan with dd or not
            else if (ContactTypes.WEB665.equals(type)) {
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
                note.append("CHOR completed. Payment plan needs to be reviewed. ").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB668.equals(type)) {
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
                note.append("CHOR completed. Payment plan needs to be reviewed.").append(NEW_LINE);
                note.append(NEW_LINE);

            }
            //JH td1465
            //change to contacts raised if special conditions exist on account
            else if (ContactTypes.WEB669.equals(type)) {    //One of the setChor calls could have failed but not necessarily both.
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
                note.append("CHOR not completed as SOAC special condition exists on account.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB694.equals(type)) {    //One of the setChor calls could have failed but not necessarily both.
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
                note.append("CHOR not completed as SOCIALTAR special condition exists on account.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB670.equals(type)) {    //QC 1773
                //One of the setChor calls could have failed but not necessarily both.
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append("Target not updated as account has a special condition of: Temp Discon. Non Pay .").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB671.equals(type)) {    //QC 1773
                //One of the setChor calls could have failed but not necessarily both.
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());
                note.append("CHOR not completed as forced out account is Post Claim in CARMS.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB677.equals(type)) {
                note.append("Target not updated as move in address is non-property.").append(NEW_LINE);
                if(chorContext.getMovingInDetails() != null && chorContext.getMovingInDetails().getPropertyBrand() != null) {
                    if (!chorContext.getAccountBrand().equals(chorContext.getMovingInDetails().getPropertyBrand())) {
                        note.append("Property is marked as an HD property")
                                .append(NEW_LINE);
                    }
                }
            } else {
                //TD1526 JH use this reusable method now as contact note also needs updating for web665 and web668 contacts.
                updateNoteMoveInMoveOut(note, chorContext.getChorResponse());

                if (errorMessage != null) {
                    note.append(errorMessage);
                    note.append(NEW_LINE);
                }
            }
        }

        note.append(EMAIL_MOVING_HOUSE_SENT_TO).append(chorContext.getEmailAddress()).append(PERIOD);
        return note.toString();

    }

    @Override
    public String formatNewCustomerFailed(ContactType contactType, ChorContext chorContext, String errorMessage) throws ParseException {

        StringBuilder note = new StringBuilder();

        note.append(formatNewCustomer(
                    chorContext.getMovingInDetails(),
                    chorContext.getResponsibilities(),
                    chorContext.getNewAddressPreviousCustomer(),
                    chorContext.getContactNumber()
            ));

            ContactTypes type = contactType.getType();

            if (ContactTypes.WEB655.equals(type))
            {
                note.append("Target not updated as account is post judgement.").append(NEW_LINE);
                note.append(NEW_LINE);
            }
            else if (ContactTypes.WEB656.equals(type))
            {	//QC 1773 
            	updateNoteMoveIn(note, chorContext.getChorResponse());
                note.append("Reading failed validation and CHOR not completed.").append(NEW_LINE);
                note.append(NEW_LINE);
            }
            //JH td1206 
            //change to contacts raised if account has a payment plan with dd or not
            else if (ContactTypes.WEB665.equals(type))
            {
            	//JH TD1526 for this type of contact we also have to update the contact notes with 
                // chor service call results
            	//We have to update the notes for these contacts and not the others as the chor was successful but the pp needs reviewing
                updateNoteMoveIn(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
            	note.append("CHOR completed. Payment plan needs to be reviewed.").append(NEW_LINE);
                note.append(NEW_LINE);
            } else if (ContactTypes.WEB668.equals(type)) {
            	//JH TD1526 for this type of contact we also have to update the contact notes with 
                // chor service call results
            	//We have to update the notes for these contacts and not the others as the chor was successful but the pp needs reviewing
                updateNoteMoveIn(note, chorContext.getChorResponse());
                note.append(NEW_LINE);
            	note.append("CHOR completed. Payment plan needs to be reviewed.").append(NEW_LINE);
                note.append(NEW_LINE);
            } 
          //JH td1469
            //change to contacts raised if special conditions exist on account
            else if (ContactTypes.WEB669.equals(type))
            {	updateNoteMoveIn(note, chorContext.getChorResponse());
            	note.append("CHOR not completed as SOAC special condition exists on account.").append(NEW_LINE);
                note.append(NEW_LINE);
            }
            else if (ContactTypes.WEB694.equals(type))
            {	updateNoteMoveIn(note, chorContext.getChorResponse());
            	note.append("CHOR not completed as SOCIALTAR special condition exists on account.").append(NEW_LINE);
                note.append(NEW_LINE);
            }
            else if (ContactTypes.WEB670.equals(type))
            {	//QC 1773 
            	updateNoteMoveIn(note, chorContext.getChorResponse());
            	note.append("CHOR not completed as DISCTNONP on forced out account").append(NEW_LINE);
                note.append(NEW_LINE);
            }
            else if (ContactTypes.WEB671.equals(type))
            {	//QC 1773 
            	updateNoteMoveIn(note, chorContext.getChorResponse());
                note.append("CHOR not completed as forced out account is Post Claim in CARMS.").append(NEW_LINE);
                note.append(NEW_LINE);
            }
            else {
            	updateNoteMoveIn(note, chorContext.getChorResponse());
            	
            	if (StringUtils.isNotEmpty(errorMessage))
            	{
            		note.append(errorMessage);
                    note.append(NEW_LINE);
            	}
        }
        note.append(EMAIL_MOVING_HOUSE_SENT_TO).append(chorContext.getEmailAddress()).append(PERIOD);

        return note.toString();
    }


    
    private void updateNoteMoveIn(StringBuilder note, ChorResponse result ){
    	// Used to update the contact note with chor service call results
        if (result != null && result.getChorProgressMonitor()!=null) {
            note.append(formatMoveInProgress(true,  result.getChorProgressMonitor()));
        } else {
        	log.info("No chor progress monitor available after move in") ;
        }
    }
    
    private void updateNoteMoveInMoveOut(StringBuilder note, ChorResponse result){
    	// Used to update the contact note with chor service call results
        if (result!=null && result.getChorProgressMonitor()!=null) {
            note.append(formatMoveOutProgress(result.getChorProgressMonitor()));
            note.append(formatMoveInProgress(false, result.getChorProgressMonitor()));
        } else {
        	log.info("No chor progress monitor available after move in move out") ;
        }
    }

    private StringBuilder formatChangeResponsibility(ContactNotesData contactNotesData,
                                                    MoveRequestDetail movingOutDetails,
                                                    MoveRequestDetail movingInDetails,
                                                    Boolean billPayerAtMovingInAddress,
                                                    List<Customer> newResponsibilities,
                                                    Address newAddressPreviousCustomer,
                                                    String contactNumber){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CustomerContact.getFormattedCustomerDetails(contactNotesData)).append(NEW_LINE);
        stringBuilder.append(QUERY_DETAILS).append(NEW_LINE);
        stringBuilder.append("Moving House - Address being vacated").append(NEW_LINE);
        stringBuilder.append(formatAddressReallyLong(movingOutDetails.getAddress())).append(NEW_LINE);
        stringBuilder.append("Move out Date: ").append(movingOutDetails.getDate().format(DATE_FORMATTER)).append(NEW_LINE);
        stringBuilder.append(formatMeterReadings(movingOutDetails.getMeterReadings()));
        stringBuilder.append("Forwarding address: ").append(formatMailingAddress(movingInDetails.getAddress())).append(NEW_LINE);
        stringBuilder.append("Responsible at new address: ").append(billPayerAtMovingInAddress ? "Yes" : "No").append(NEW_LINE);
        stringBuilder.append(NEW_LINE);

        if (billPayerAtMovingInAddress && movingInDetails.getAddress().getAddressCode()!=0L) {
            stringBuilder.append(formatNewAddress(movingInDetails));
        }

        stringBuilder.append(ADDITIONAL_INFORMATION).append(NEW_LINE);
        if ( (newResponsibilities==null || newResponsibilities.isEmpty() ) && (newAddressPreviousCustomer == null || (newAddressPreviousCustomer.getAddressDescription() == null && newAddressPreviousCustomer.getStreetName() == null))) {
            stringBuilder.append(NONE_PROVIDED).append(NEW_LINE);
            stringBuilder.append(NEW_LINE);
        } else {
            stringBuilder.append("New Occupier(s) at ").append(formatAddressReallyLong(movingOutDetails.getAddress())).append(NEW_LINE);
            if (newResponsibilities==null || newResponsibilities.isEmpty()) {
                stringBuilder.append("- The Occupier").append(NEW_LINE);
            } else {
                for (Customer newResponsibility : newResponsibilities) {
                    stringBuilder.append("- ").append(formatName(newResponsibility)).append(NEW_LINE);
                }
            }
            stringBuilder.append(formatNewAddressPreviousOccupier(newAddressPreviousCustomer, movingInDetails.getAddress()));
        }
        return stringBuilder;
    }    

    private StringBuilder formatNewCustomer(MoveRequestDetail movingInDetails,
                                           List<Customer> newResponsibilities,
                                           Address newAddressPreviousCustomer,
                                           String contactNumber) throws ParseException {

        StringBuilder newCustomerStringBuilder = new StringBuilder();
        newCustomerStringBuilder.append(QUERY_DETAILS).append(NEW_LINE);
        newCustomerStringBuilder.append(formatNewAddress(movingInDetails));

        for(Customer newCustomer : newResponsibilities) {
            newCustomerStringBuilder.append("New Customer Details:").append(NEW_LINE);
            newCustomerStringBuilder.append("Name:").append(formatName(newCustomer)).append(NEW_LINE);
            String dateOfBirth = newCustomer.getDateOfBirth();
            if (StringUtils.isEmpty(dateOfBirth)){
                newCustomerStringBuilder.append("Date Of Birth: ").append(N_A).append(NEW_LINE);
            } else {
            	SimpleDateFormat innerFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date birthDate = innerFormat.parse(dateOfBirth);
                SimpleDateFormat contactFormat = new SimpleDateFormat("dd-MM-yyyy");
                dateOfBirth = contactFormat.format(birthDate);
                
                newCustomerStringBuilder.append("Date Of Birth: ").append(dateOfBirth).append(NEW_LINE);
            }
            newCustomerStringBuilder.append("Mobile Telephone Number: ").append(newCustomer.getTelNumMobile()==null? EMPTY_STRING :newCustomer.getTelNumMobile()).append(NEW_LINE);
            newCustomerStringBuilder.append("Home Telephone Number: ").append(newCustomer.getTelNumHome()==null? EMPTY_STRING :newCustomer.getTelNumHome()).append(NEW_LINE);
            newCustomerStringBuilder.append("Work Telephone Number: ").append(newCustomer.getTelNumWork()==null? EMPTY_STRING :newCustomer.getTelNumWork()).append(NEW_LINE);

            newCustomerStringBuilder.append("Preferred Contact Number: ");

            if (Y.equals(newCustomer.getPreferredTelNumHome())){
                newCustomerStringBuilder.append("Home telephone");
            } else if (Y.equals(newCustomer.getPreferredTelNumMobile())){
                newCustomerStringBuilder.append("Mobile telephone");
            } else if (Y.equals(newCustomer.getPreferredTelNumWork())){
                newCustomerStringBuilder.append("Work telephone");
            }

            newCustomerStringBuilder.append(NEW_LINE);

            newCustomerStringBuilder.append("Bank Account Status:");
            RefData bankAccountStatus = newCustomer.getBankAccountStatus();
            if(bankAccountStatus!=null && StringUtils.isNotEmpty(bankAccountStatus.getValue())){
                newCustomerStringBuilder.append(bankAccountStatus.getValue());
            }
            newCustomerStringBuilder.append(NEW_LINE);

            newCustomerStringBuilder.append("Employment Status: ");
            RefData empStatus = newCustomer.getEmploymentStatus();
            if(empStatus != null && StringUtils.isNotEmpty(empStatus.getValue())){
                newCustomerStringBuilder.append(empStatus.getValue());
            }
            newCustomerStringBuilder.append(NEW_LINE);

            newCustomerStringBuilder.append("Household responsibility: ");
            RefData homeOwnerStatus = newCustomer.getHomeOwnerStatus();
            if(homeOwnerStatus!=null && StringUtils.isNotEmpty(homeOwnerStatus.getValue())){
                newCustomerStringBuilder.append(homeOwnerStatus.getValue());
            }
            newCustomerStringBuilder.append(NEW_LINE);
            newCustomerStringBuilder.append(NEW_LINE);
        }

        newCustomerStringBuilder.append(ADDITIONAL_INFORMATION).append(NEW_LINE);
        if (newAddressPreviousCustomer == null || (newAddressPreviousCustomer.getAddressDescription() == null && newAddressPreviousCustomer.getStreetName() == null)) {
            newCustomerStringBuilder.append(NONE_PROVIDED).append(NEW_LINE);
        } else {
            newCustomerStringBuilder.append(formatNewAddressPreviousOccupier(newAddressPreviousCustomer, movingInDetails.getAddress()));
        }

        log.info("NewCustomerFormatterImpl.formatNewCustomer end");
        return newCustomerStringBuilder;
    }

    private StringBuilder formatMeterReadings(List<ChorMeterRead> meterReadings) {
        StringBuilder meterReadingsStringBuilder = new StringBuilder();
        if (meterReadings == null || meterReadings.isEmpty()) {
            meterReadingsStringBuilder.append(METER_READING).append(N_A).append(NEW_LINE);
        } else {
            for (ChorMeterRead meterRead : meterReadings) {
                if (StringUtils.isEmpty(meterRead.getReading())) {
                    meterReadingsStringBuilder.append(METER_READING).append("Estimated").append(NEW_LINE);
                } else {
                    Long reading = Long.parseLong(meterRead.getReading());
                    meterReadingsStringBuilder.append(METER_READING).append(formatLong(reading)).append(NEW_LINE);
                }
            }
        }
        return meterReadingsStringBuilder;
    }

    private StringBuilder formatNewAddress(MoveRequestDetail moveDetail)
    {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Move in address: ").append(formatMailingAddress(moveDetail.getAddress())).append(NEW_LINE);
        //TD1554 JH
        //Catch move in date not being set, if out of area and 'yes i'm responsible' checked it will not ask for move in date.
        if(moveDetail.getDate() != null){
        	stringBuilder.append("Move in Date: ").append(moveDetail.getDate().format(DATE_FORMATTER)).append(NEW_LINE);
        }        
        stringBuilder.append(formatMeterReadings(moveDetail.getMeterReadings()));
        stringBuilder.append(NEW_LINE);
        return stringBuilder;
    }

    private StringBuilder formatNewAddressPreviousOccupier(Address newAddressPreviousCustomer, Address movingInAddress)
    {
        StringBuilder stringBuilder = new StringBuilder();
        if (newAddressPreviousCustomer != null)
        {
            stringBuilder.append("Forwarding address for old occupier at ").append(formatMailingAddress(movingInAddress)).append(": ");
            stringBuilder.append(formatMailingAddress(newAddressPreviousCustomer)).append(NEW_LINE);
        }
        stringBuilder.append(NEW_LINE);
        return stringBuilder;
    }

    private StringBuilder formatMoveOutProgress(ChorProgressMonitor progress)
    {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Updates completed in Target:").append(NEW_LINE);
        stringBuilder.append("Move out property: ").append(NEW_LINE);
        stringBuilder.append("Set CHOR | Turn Off: ");
        stringBuilder.append(progress.getProgressForState(ChorState.MOVE_OUT_CHOR_OFF).getDesc()).append(NEW_LINE);
        stringBuilder.append("Insert Mailing Address: ");
        stringBuilder.append(progress.getProgressForState(ChorState.MOVE_OUT_NEW_MAILING_ADDRESS).getDesc()).append(NEW_LINE);
        stringBuilder.append("Set CHOR | Turn On: ");
        stringBuilder.append(progress.getProgressForState(ChorState.MOVE_OUT_CHOR_ON).getDesc()).append(NEW_LINE);
        if(progress.isMoveOutMeterRead()){
            stringBuilder.append("Meter reading passed validation").append(NEW_LINE);
        }
        stringBuilder.append(NEW_LINE);
        return stringBuilder;
    }

    private StringBuffer formatMoveInProgress(boolean newCustomer, ChorProgressMonitor progress) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("Move in property: ").append(NEW_LINE);
        stringBuffer.append("Set CHOR | Turn On / Force Out: ");
        stringBuffer.append(progress.getProgressForState(ChorState.MOVE_IN_CHOR_ON).getDesc()).append(NEW_LINE);
        stringBuffer.append("Insert Mailing Address: ");
        stringBuffer.append(progress.getProgressForState(ChorState.MOVE_IN_ADDRESS).getDesc()).append(NEW_LINE);
        if (newCustomer) {
            stringBuffer.append("Add Account Role: ");
            stringBuffer.append(progress.getProgressForState(ChorState.MOVE_IN_ADD_ROLE).getDesc()).append(NEW_LINE);
        }
        if(progress.isMoveInMeterRead()) {
            stringBuffer.append("Meter reading passed validation").append(NEW_LINE);
        }
        stringBuffer.append(NEW_LINE);
        return stringBuffer;
    }

    /**
     * QC1682 - A new AQ should be raised against the previous occupants accounts if the address has been entered manually. 
     * @param newAddressPreviousCustomer
     * @return
     */
    private StringBuffer formatPreviousOccupantAddressAQ(Address newAddressPreviousCustomer)
    {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(NEW_LINE);
        stringBuffer.append(QUERY_DETAILS).append(NEW_LINE);
        stringBuffer.append("Change of responsibility has been completed.  See CHOR contact for full details.").append(NEW_LINE);
        stringBuffer.append(NEW_LINE);
        stringBuffer.append("The following forwarding address was entered manually:").append(NEW_LINE);
        stringBuffer.append(NEW_LINE);
        stringBuffer.append(formatMailingAddress(newAddressPreviousCustomer)).append(NEW_LINE);
        stringBuffer.append(NEW_LINE);	
        return stringBuffer;
    }

    private String formatLong(Long aLong)
    {
        return new DecimalFormat(LONG_FORMAT).format(aLong);
    }

    private String formatAddressReallyLong(Address address) {
        String addressStr = internalFormatAddress(address, ", ");
        return addressStr.substring(0, Math.min(addressStr.length(), 130));
    }

    private String formatMailingAddress(Address address) {
        return internalFormatAddress(address, NEW_LINE);
    }

    private String internalFormatAddress(Address address, String seperator) {
        StringBuffer stringBuffer = new StringBuffer();

        if(StringUtils.isNotEmpty(address.getAddressDescription())){
            stringBuffer.append(address.getAddressDescription());
        }else {
            String streetName = address.getStreetName();
            String line1 = address.getLine1();
            String line2 = address.getLine2();
            String line3 = address.getLine3();
            String city = address.getCity();
            String county = address.getCounty();
            String country = address.getCountry();
            String zip = address.getPostcode();
            if (!StringUtils.isEmpty(line1)) {
                stringBuffer.append(seperator);
                stringBuffer.append(line1.trim());
            }
            if (!StringUtils.isEmpty(streetName)) {
                stringBuffer.append(seperator);
                stringBuffer.append(streetName.trim());
            }
            if (!StringUtils.isEmpty(line2)) {
                stringBuffer.append(seperator);
                stringBuffer.append(line2.trim());
            }
            if (!StringUtils.isEmpty(line3)) {
                stringBuffer.append(seperator);
                stringBuffer.append(line3.trim());
            }
            if (!StringUtils.isEmpty(city)) {
                stringBuffer.append(seperator);
                stringBuffer.append(city.trim());
            }
            if (!StringUtils.isEmpty(county)) {
                stringBuffer.append(seperator);
                stringBuffer.append(county.trim());
            }
            if (!StringUtils.isEmpty(country)) {
                stringBuffer.append(seperator);
                stringBuffer.append(country.trim());
            }
            if (!StringUtils.isEmpty(zip)) {
                stringBuffer.append(seperator);
                stringBuffer.append(formatPostcode(zip).trim());
            }
        }
        return stringBuffer.toString().toLowerCase();
    }

    private String formatPostcode(String postcodeStr) {
        if (StringUtils.isEmpty(postcodeStr)) {
            return EMPTY_STRING;
        }else {
            UKPostcodeParser parser = new UKPostcodeParser();
            UKPostcode postcode = parser.parse(StringUtils.replace(postcodeStr, " ", EMPTY_STRING));
            if (postcode == null) {
                return postcodeStr;
            } else {
                StringBuffer stringBuffer = new StringBuffer();
                stringBuffer.append(postcode.getArea()).append(postcode.getDistrict()).append(" ");
                stringBuffer.append(postcode.getSection()).append(postcode.getUnit());
                return stringBuffer.toString();
            }
        }
    }

    private String formatName(Customer legalEntity) {
        String name = EMPTY_STRING;
        if(legalEntity == null){
            return name;
        }else{
            if (legalEntity.getTitleRef() != null) {
                name = legalEntity.getTitleRef().getValue() + " ";
            } if (legalEntity.getFirstName() != null && legalEntity.getLastName() != null) {
                return name + legalEntity.getFirstName() + " " + legalEntity.getLastName();
            } else if (legalEntity.getLastName() != null) {
                return name + legalEntity.getLastName();
            }else {
                return name;
            }
        }
    }
    
    private String getFrequencyDescription(String fCode) {
		switch (fCode) {
		case "MONTHLY": return PAYMENT_FREQUENCY_MONTHLY;
		case "FORTNIGHTLY": return PAYMENT_FREQUENCY_FORTNIGHTLY;
		case "WEEKLY": return PAYMENT_FREQUENCY_WEEKLY;
		case "FOUR_WEEKLY": return PAYMENT_FREQUENCY_FOUR_WEEKLY;
		default: return fCode;
		}

	}


}
