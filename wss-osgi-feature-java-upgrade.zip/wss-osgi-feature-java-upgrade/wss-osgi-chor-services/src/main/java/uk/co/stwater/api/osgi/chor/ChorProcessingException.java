package uk.co.stwater.api.osgi.chor;

public class ChorProcessingException extends ChorException {

    public ChorProcessingException(String msg) {
        super(msg);
    }
}
