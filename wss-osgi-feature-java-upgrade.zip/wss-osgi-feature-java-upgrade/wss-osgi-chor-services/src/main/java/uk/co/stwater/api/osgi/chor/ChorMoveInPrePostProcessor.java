package uk.co.stwater.api.osgi.chor;

import static uk.co.stwater.api.osgi.chor.AbstractChorStateProcessor.UNKNOWN_POSTCODE;
import static uk.co.stwater.api.osgi.chor.ChorStateProcessor.Indicator.BUSINESS;
import static uk.co.stwater.api.osgi.chor.ChorStateProcessor.Indicator.INDIVIDUAL;
import static uk.co.stwater.api.osgi.chor.ChorStateProcessor.PhoneType.HOME;
import static uk.co.stwater.api.osgi.chor.ChorStateProcessor.PhoneType.MOBILE;
import static uk.co.stwater.api.osgi.chor.ChorStateProcessor.PhoneType.WORK;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.AccountRoles;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.targetconnector.client.api.addaccountrole.AccountRoleResp;
import uk.co.stwater.targetconnector.client.api.legalentityvo.BankDetailsImpl;
import uk.co.stwater.targetconnector.client.api.legalentityvo.DataShareIndicatorDetailsImpl;
import uk.co.stwater.targetconnector.client.api.legalentityvo.EmploymentDetailsImpl;
import uk.co.stwater.targetconnector.client.api.legalentityvo.HomeOwnershipDetailsImpl;
import uk.co.stwater.targetconnector.client.api.legalentityvo.LegalEntityAttributesImpl;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsResponse;
import uk.co.stwater.targetconnector.client.api.setchor.ChorClientResponse;

public class ChorMoveInPrePostProcessor implements ChorPreProcessor, ChorPostProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorMoveInPrePostProcessor.class);

    private static final String DOB_PATTERN = "yyyy-MM-dd";

    private static final String N = "N";

    private static final String Y = "Y";

    private static final String YES = "Yes";

    private ServiceFacade serviceFacade;

    ChorMoveInPrePostProcessor(ServiceFacade serviceFacade) {
        this.serviceFacade = serviceFacade;
    }

    @Override
    public void preProcess(ChorContext chorContext) {
        logger.debug("processState entry");
        /*
         * The ChorMoveInProcessor expects the ChorContext.customer as the primary LE. For double-sided chor this is fine,
         * but for new customer moving in, the customer doesn't exist and we must use the first item in the list of
         * new responsibilities.
         */
        if(CollectionUtils.isEmpty(chorContext.getResponsibilities())) {
            throw new ChorProcessingException("New Responsibilities should not be null");
        }
        Customer customer = chorContext.getResponsibilities().get(0);
        chorContext.setCustomer(customer);
        logger.debug("processState exit");
    }

    @Override
    public void postProcess(ChorContext chorContext) {
        logger.debug("processState entry");
        ChorResponse chorResponse = chorContext.getChorResponse();
        ChorClientResponse chorClientResponse = getStateContext().getChorClientResponse();
        if(chorClientResponse ==  null) {
            throw new ChorProcessingException("ChorClientResponse not found for new customer");
        }

        boolean isPrimaryProcessed = false;
        for (Customer newResponsibility : chorContext.getResponsibilities()) {
            PersonalDetailsResponse personalDetails;
            if (!isPrimaryProcessed) { // i.e. the first iteration
                chorResponse.setNewAccountNumber(chorClientResponse.getNewAccountNumber());
                chorResponse.setForcedOutAccountNumber(chorClientResponse.getForcedOutAccountNumber());
                chorResponse.setNewLegalEntityId(chorClientResponse.getNewLegalEntityId());
                String newLegalEntityId = chorClientResponse.getNewLegalEntityId().toString();
                personalDetails = serviceFacade.getPersonalDetailsClient()
                        .getPersonalDetails(null, UNKNOWN_POSTCODE, newLegalEntityId);
                isPrimaryProcessed = true;
            } else {
                // now create an LE for each person listed under 'new responsibilities'
                AccountRoleResp newRole = serviceFacade.getAddAccountRoleClient().addAccountRole(
                        createNewAccountRole(chorClientResponse.getNewAccountNumber(), newResponsibility),
                        chorClientResponse.getNewAccountNumber());
                personalDetails = serviceFacade.getPersonalDetailsClient().getPersonalDetails(null, UNKNOWN_POSTCODE,
                        Long.toString(newRole.getLeNum()));
            }
            updatePersonalDetails(personalDetails, newResponsibility);
            serviceFacade.getPersonalDetailsClient().setPersonalDetails(chorClientResponse
                            .getNewAccountNumber(), UNKNOWN_POSTCODE, personalDetails);
        }
        StateContextHolder.clearContext();
        chorContext.getChorStateManager().moveInRole(ChorProgressMonitor.Progress.COMPLETED);
        chorResponse.setSuccess(true);
        logger.debug("processState exit");
    }

    protected StateContext getStateContext() {
        return StateContextHolder.getContext();
    }

    private void updatePersonalDetails(PersonalDetailsResponse personalDetails, Customer newResponsibility) {
        LegalEntityAttributesImpl personalDetailsLegalEntity = (LegalEntityAttributesImpl) personalDetails
                .getLegalEntity();
        personalDetailsLegalEntity.setLeTitle(newResponsibility.getTitleRef().getCode());
        personalDetailsLegalEntity.setForename(newResponsibility.getFirstName());
        personalDetailsLegalEntity.setLeName(newResponsibility.getLastName());
        if (StringUtils.isNotEmpty(newResponsibility.getDateOfBirth())) {
            try {
                personalDetails
                        .setDateOfBirth(new SimpleDateFormat(DOB_PATTERN).parse(newResponsibility.getDateOfBirth()));
            } catch (ParseException e) {
                logger.error("Could not parse date of birth {}", newResponsibility.getDateOfBirth());
            }
        }
        personalDetails.setTelNumMobile(newResponsibility.getTelNumMobile());
        personalDetails.setTelNumHome(newResponsibility.getTelNumHome());
        personalDetails.setTelNumWork(newResponsibility.getTelNumWork());
        personalDetails.setPreferredHomeTelephone(newResponsibility.getPreferredTelNumHome());
        personalDetails.setPreferredWorkTelephone(newResponsibility.getPreferredTelNumWork());
        personalDetails.setPreferredMobileTelephone(newResponsibility.getPreferredTelNumMobile());

        personalDetails.setPreferredNumIsHome(newResponsibility.getPreferredTelNumHome());
        personalDetails.preferredNumIsMobile(newResponsibility.getPreferredTelNumMobile());
        personalDetails.preferredNumIsWork(newResponsibility.getPreferredTelNumHome());

        if (newResponsibility.getEmploymentStatus() != null) {
            EmploymentDetailsImpl employmentDetails = (EmploymentDetailsImpl) personalDetails.getEmpDetails();
            if (employmentDetails == null) {
                employmentDetails = new EmploymentDetailsImpl();
                personalDetails.setEmpDetails(employmentDetails);
            }
            employmentDetails.setStatus(newResponsibility.getEmploymentStatus().getCode());
            employmentDetails.setCyclicNum(0L);
        }
        if (newResponsibility.getHomeOwnerStatus() != null) {
            HomeOwnershipDetailsImpl homeOwnershipDetails = (HomeOwnershipDetailsImpl) personalDetails
                    .getHomeOwnership();
            if (homeOwnershipDetails == null) {
                homeOwnershipDetails = new HomeOwnershipDetailsImpl();
                personalDetails.setHomeOwnership(homeOwnershipDetails);
            }
            homeOwnershipDetails.setStatus(newResponsibility.getHomeOwnerStatus().getCode());
            homeOwnershipDetails.setCyclicNum(0L);
        }

        if (newResponsibility.getDataShareIndicatorDetails() != null) {
            DataShareIndicatorDetailsImpl dataShareIndicatorDetails = (DataShareIndicatorDetailsImpl) personalDetails
                    .getDataShareIndicator();
            if (dataShareIndicatorDetails == null) {
                dataShareIndicatorDetails = new DataShareIndicatorDetailsImpl();
                personalDetails.setDataShareIndicator(dataShareIndicatorDetails);
            }
            String flag = newResponsibility.getDataShareIndicatorDetails().getFlag();
            if (YES.equals(flag)) {
                dataShareIndicatorDetails.setFlag(Y);
            } else {
                dataShareIndicatorDetails.setFlag(N);
            }
            dataShareIndicatorDetails.setCyclicNum(0L);
        }
        if (newResponsibility.getBankAccountStatus() != null) {
            BankDetailsImpl bankDetails = (BankDetailsImpl) personalDetails.getBankDetails();
            if (bankDetails == null) {
                bankDetails = new BankDetailsImpl();
                personalDetails.setBankDetails(bankDetails);
            }
            bankDetails.setIndicator(newResponsibility.getBankAccountStatus().getCode());
            bankDetails.setCyclicNum(0L);
        }
    }

    public static AccountRoles createNewAccountRole(TargetAccountNumber accountNumber, Customer newCustomer) {
        AccountRoles role = createAccountRole(accountNumber, newCustomer);
        if (newCustomer.getBankAccIndicatorDetails() != null) {
            role.setBankAccountInd(newCustomer.getBankAccIndicatorDetails().getIndicator());
        }
        role.setTelNumHome(newCustomer.getTelNumHome());
        role.setTelNumMobile(newCustomer.getTelNumMobile());
        role.setTelNumWork(newCustomer.getTelNumWork());
        if (Y.equals(newCustomer.getPreferredTelNumHome())) {
            role.setPrefTelNumInd(HOME.getCode());
        } else if (Y.equals(newCustomer.getPreferredTelNumMobile())) {
            role.setPrefTelNumInd(MOBILE.getCode());
        } else if (Y.equals(newCustomer.getPreferredTelNumWork())) {
            role.setPrefTelNumInd(WORK.getCode());
        }
        if (newCustomer.getHomeOwnershipDetails() != null) {
            role.setHomeOwnStat(newCustomer.getHomeOwnershipDetails().getStatus());
        }
        if (newCustomer.getEmpStatusDetails() != null) {
            role.setEmploymStat(newCustomer.getEmpStatusDetails().getStatus());
        }
        return role;
    }

    private static AccountRoles createAccountRole(TargetAccountNumber accountNumber, Customer newCustomer) {
        AccountRoles role = new AccountRoles();
        role.setAccountNumber(accountNumber);
        role.setLeFirstName(newCustomer.getFirstName());
        role.setLeMiddleIntials(newCustomer.getMiddleInitial());
        role.setLeSurname(newCustomer.getLastName());
        role.setLeTitleCode(newCustomer.getTitleRef().getCode());
        role.setLeType(newCustomer.getIsIndividual() ? INDIVIDUAL.getCode() : BUSINESS.getCode());
        return role;
    }
}
