package uk.co.stwater.api.osgi.probate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.chor.ChorResource;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.probate.ProbateDTO;
import uk.co.stwater.api.osgi.model.probate.ProbateRequest;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Named("agentProbateResource")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class AgentProbateResource extends ChorResource {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    private ProbateService probateService;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/probate")
    public Response probate(ProbateRequest probateRequest) {
        Response response;
        try {
            final String authToken = getUserIdentity().getUsername();
            final ProbateDTO probateDTO = probateService.probate(probateRequest, authToken);
            response = Response
                    .status(Status.ACCEPTED)
                    .entity(probateDTO)
                    .build();
        } catch (IllegalArgumentException iae) {
            ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.PROBATE_SERVICES, Status.BAD_REQUEST.getStatusCode(), iae.getMessage());
            response = Response.status(Status.BAD_REQUEST).entity(errorDto).build();
        } catch (STWBusinessException be) {
            ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.PROBATE_SERVICES, be.getHttpStatusCode().getStatusCode(), be.getMessage());
            response = Response.status(be.getHttpStatusCode()).entity(errorDto).build();
        } catch (STWTechnicalException te) {
            ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.PROBATE_SERVICES, te.getHttpStatusCode().getStatusCode(), te.getMessage());
            response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(errorDto).build();
        }
        return response;

    }
}
