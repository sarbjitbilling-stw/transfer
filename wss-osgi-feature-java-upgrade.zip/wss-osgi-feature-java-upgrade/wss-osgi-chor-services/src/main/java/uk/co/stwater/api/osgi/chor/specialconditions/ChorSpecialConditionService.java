package uk.co.stwater.api.osgi.chor.specialconditions;

import java.util.List;

import uk.co.stwater.api.osgi.model.Move;
import uk.co.stwater.api.osgi.model.ProcessOutcome;

public interface ChorSpecialConditionService {
    /**
     * Processing that needs to be done before a move in to handle special
     * conditions on the accounts, customers or property.
     */
    List<ProcessOutcome> beforeMoveIn(Move move, boolean isNewAccountCreatedForMoveIn, String authToken);

    /**
     * Processing that needs to be done after a move out to handle special
     * conditions on the accounts, customers or property.
     */
    List<ProcessOutcome> afterMoveOut(Move move, String authToken);
}
