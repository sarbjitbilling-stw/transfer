package uk.co.stwater.api.osgi.chor.agent.memo;

import org.apache.commons.lang3.builder.ToStringBuilder;

import uk.co.stwater.api.osgi.model.Move;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

/**
 * Container object for force move out memo tasks.
 *
 * @author Andrew Landeg
 *
 */
public class ForceMoveOutMemoTaskDescriptor {
	private Long propertyId;
	private Long legalEntityNo; 
	private TargetAccountNumber accountNumber;
	private Move move;
	
	public Long getPropertyId() {
		return propertyId;
	}
	public Long getLegalEntityNo() {
		return legalEntityNo;
	}
	public TargetAccountNumber getAccountNumber() {
		return accountNumber;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public void setLegalEntityNo(Long legalEntityNo) {
		this.legalEntityNo = legalEntityNo;
	}
	public void setAccountNumber(TargetAccountNumber accountId) {
		this.accountNumber = accountId;
	}
	public Move getMove() {
		return move;
	}
	public void setMove(Move move) {
		this.move = move;
	}
	@Override
	public String toString() {
		return new ToStringBuilder(this)
				.append("propertyId", propertyId)
				.append("legalEntityNo", legalEntityNo)
				.append("accountNumber", accountNumber)
				.append("move", move)
				.build();
	}
}
