package uk.co.stwater.api.osgi.chor.agent;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.chor.ChorResource;
import uk.co.stwater.api.osgi.model.ClientReverseBillRequest;
import uk.co.stwater.api.osgi.model.LegalEntityReuseRequest;
import uk.co.stwater.api.osgi.model.LegalEntityReuseResponse;
import uk.co.stwater.api.osgi.model.MoveProperty;
import uk.co.stwater.api.osgi.model.ReverseBillResponse;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

@Named
@Consumes({ "application/json" })
@Produces({ "application/json" })
public class AgentChorResource extends ChorResource {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Inject
	private MovePropertyService movePropertyService;

	@Inject
	private ReverseBillService reverseBillService;

	@Inject
	private LegalEntityService legalEntityService;

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/move")
	public Response moveProperty(MoveProperty moveProperty) {

		try {

			String authToken = getUserIdentity().getUsername();

			MoveProperty theMoveProperty = movePropertyService.moveProperty(moveProperty, authToken);

			return Response.status(Status.OK).entity(theMoveProperty).build();

		} catch (STWBusinessException e) {
			ErrorDto errorDto = new ErrorDto(100, "ChorRequest data incomplete.");
			log.error("ChorRequest data incompete");
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		} catch (STWTechnicalException e) {
			ErrorDto errorDto = new ErrorDto(100, "ChorRequest data incomplete.");
			log.error("ChorRequest data incompete");
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		}
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/reversebill")
	public Response reverseBill(ClientReverseBillRequest clientReverseBillRequest) {

		try {
			String authToken = getUserIdentity().getUsername();
			
			List<ReverseBillResponse> lstReverseBill = reverseBillService.reverseBill(clientReverseBillRequest, authToken);
			return Response.status(Status.OK).entity(lstReverseBill).build();
		} catch (STWBusinessException e) {
			ErrorDto errorDto = new ErrorDto(Response.Status.BAD_REQUEST.getStatusCode(), e.getLocalizedMessage());
			log.error("ChorRequest data incompete");
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		} catch (STWTechnicalException e) {
			ErrorDto errorDto = new ErrorDto(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
					e.getLocalizedMessage());
			log.error("ChorRequest data incompete");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(errorDto).build();
		}
	}

	/**
	 * Determines if the specified primary legal entity can be reused.
	 * This call is not restful. The PE/CPE numbers in the incoming
	 * payload are compared against PE/CPE on associated, existing accounts. 
	 * The response will indicate the re-usability of the specified primary LE together
	 * with the first instance of an incompatible account.
	 *  
	 * @param request payload containing PE/CPE numbers. 
	 * @return
	 */
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/legal-entities/primary")
	public Response legalEntityReuse (final LegalEntityReuseRequest request) {
		try {
			log.debug("checkLegalEntityReuse {}", request);
			String authToken = getUserIdentity().getUsername();
			final LegalEntityReuseResponse response = legalEntityService.checkLegalEntityReuse(request, authToken);
			return Response.ok().entity(response).build();
		} catch (STWBusinessException e) {
			ErrorDto errorDto = new ErrorDto(Response.Status.BAD_REQUEST.getStatusCode(), e.getLocalizedMessage());
			log.error("Unable to check legal entity {} ", request);
			return Response.status(Status.BAD_REQUEST).entity(errorDto).build();
		} catch (STWTechnicalException e) {
			ErrorDto errorDto = new ErrorDto(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), e.getLocalizedMessage());
			log.error("Technical expception while checking legal entity {} ", request);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(errorDto).build();
		}
	}
}
