package uk.co.stwater.api.osgi.chor.agent;

import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.ClientReverseBillRequest;
import uk.co.stwater.api.osgi.model.ReverseBillReason;
import uk.co.stwater.api.osgi.model.ReverseBillRequest;
import uk.co.stwater.api.osgi.model.ReverseBillResponse;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.calculator.offers.AccountEventStatus;
import uk.co.stwater.api.osgi.model.calculator.offers.AccountEventType;
import uk.co.stwater.api.osgi.model.transaction.AccountEvent;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.accountevent.AccountTransactionsClient;
import uk.co.stwater.iib.client.api.bill.cancel.IIBCancelBillClient;
import uk.co.stwater.iib.client.api.bill.cancel.IIBCancelBillRequest;
import uk.co.stwater.iib.client.api.bill.cancel.IIBCancelBillResponse;
import uk.co.stwater.iib.client.api.offers.OffersTargetService;

@Named
@OsgiServiceProvider(classes = {ReverseBillService.class})
public class ReverseBillServiceImpl implements ReverseBillService {
    Logger log = LoggerFactory.getLogger(this.getClass());

    public static final String BILLREASON_CODE = "TOFF";
    public static final String BILLREASON_VALUE = "Turn Off";
    public static final String BILLREASON_VALUE_SET = "88";
    private static final int BILL_CANCEL_BATCH_SIZE = 3; // Average time to cancel a bill is approx 2 secs, and IIB timeout is 15sec.

    @Inject
    @OsgiService
    private IIBCancelBillClient cancelBillClient;

    @Inject
    private ReverseBillRequestTransfromer reverseBillRequestTransfromer;

    @Inject
    private ReverseBillResponseTransformer reverseBillResponseTransfromer;

    @Inject
    @OsgiService
    private AccountTransactionsClient accountTransactionsClient;

    @OsgiService
    @Inject
    private OffersTargetService offersTargetService;

    @Override
    public List<AccountEvent> reChorBillsToReverse(final ClientReverseBillRequest clientReverseBillRequest, final String authToken)
            throws STWBusinessException, STWTechnicalException {

        TargetAccountNumber accountNumber = new TargetAccountNumber(clientReverseBillRequest.getAccountId(), null);
        List<AccountEvent> accountList = accountTransactionsClient.getAllTransactionsForAccountNumber(accountNumber,
                String.valueOf(clientReverseBillRequest.getMoveDate().getYear()));

        return accountList.stream()
                .filter(acc -> acc.getBillEndDate() != null)
                .filter(acc -> acc.getAccountStatus() != null)
                .filter(acc -> acc.getAccountEventType() != null)
                .filter(acc -> !acc.getAccountStatus().toUpperCase().equals(AccountEventStatus.CANCELLED.getStatus()))
                .filter(acc -> acc.getAccountEventType().getCode().equals(AccountEventType.BILLI.name())
                        || acc.getAccountEventType().getCode().equals(AccountEventType.REBIL.name()))
                .filter(acc -> !acc.getBillEndDate().isBefore(clientReverseBillRequest.getMoveDate()))
                .filter(acc -> hasInvoiceBilledGivenProperty(accountNumber, acc.getCreatedDateTime(), clientReverseBillRequest.getPropertyId(), authToken))
                .collect(toList());
    }

    @Override
    public List<ReverseBillResponse> reverseBill(final ClientReverseBillRequest clientReverseBillRequest, final String authToken)
            throws STWBusinessException, STWTechnicalException {
        ReverseBillRequest reverseBillRequest = createReverseBillRequest(clientReverseBillRequest);
        return reverseBill(clientReverseBillRequest, reverseBillRequest, false, authToken);
    }

    @Override
    public List<ReverseBillResponse> reverseBill(final ClientReverseBillRequest clientReverseBillRequest, final boolean retryAfterTimeout, final String authToken)
            throws STWBusinessException, STWTechnicalException {
        ReverseBillRequest reverseBillRequest = createReverseBillRequest(clientReverseBillRequest);
        return reverseBill(clientReverseBillRequest, reverseBillRequest, retryAfterTimeout, authToken);
    }

    @Override
    public List<ReverseBillResponse> reverseBill(ClientReverseBillRequest clientReverseBillRequest, ReverseBillRequest reverseBillRequestInfo, final boolean retryAfterTimeout, final String authToken) {
        if (!retryAfterTimeout) {
            return reverseBillForShortPeriods(clientReverseBillRequest, reverseBillRequestInfo, authToken);
        }
        return reverseBillsOfLongPeriods(clientReverseBillRequest, reverseBillRequestInfo, authToken);

    }

    /**
     * To check if Invoice is billed for a given property,
     * 1) retrive all invoice lines for the said Invoice.
     * 2) check if any invoice line has the relevant propertyId.
     */
    private boolean hasInvoiceBilledGivenProperty(final TargetAccountNumber accountNumber, final LocalDateTime invoiceCreatedDateTime, final Long propertyId, final String authToken) {
        return offersTargetService.getInvoiceLines(accountNumber, invoiceCreatedDateTime, authToken).stream()
                .anyMatch(invoiceLine -> invoiceLine.getPropertyId().equals(propertyId));
    }

    private List<ReverseBillResponse> reverseBillsOfLongPeriods(ClientReverseBillRequest clientReverseBillRequest, ReverseBillRequest reverseBillRequestInfo, final String authToken) {
        TargetAccountNumber accountNumber = new TargetAccountNumber(clientReverseBillRequest.getAccountId(), null);
        List<AccountEvent> accountList = accountTransactionsClient.getAllTransactionsForAccountNumber(accountNumber,
                String.valueOf(clientReverseBillRequest.getMoveDate().getYear()));

        List<AccountEvent> accountEvents = accountList.stream()
                .filter(acc -> acc.getBillEndDate() != null)
                .filter(acc -> acc.getAccountStatus() != null)
                .filter(acc -> acc.getAccountEventType() != null)
                .filter(acc -> !acc.getAccountStatus().toUpperCase().equals(AccountEventStatus.CANCELLED.getStatus()))
                .filter(acc -> acc.getAccountEventType().getCode().equals(AccountEventType.BILLI.name())
                        || acc.getAccountEventType().getCode().equals(AccountEventType.REBIL.name()))
                .filter(acc -> !acc.getBillEndDate().isBefore(clientReverseBillRequest.getMoveDate()))
                .filter(acc -> hasInvoiceBilledGivenProperty(accountNumber, acc.getCreatedDateTime(), clientReverseBillRequest.getPropertyId(), authToken))
                .sorted(Comparator.comparing(AccountEvent::getBillStartDate).reversed())
                .collect(toList());

        List<ReverseBillResponse> listReverseBillResponse = new ArrayList<>();

        List<Integer> pointerList = getListIndexAtGivenInterval(BILL_CANCEL_BATCH_SIZE, accountEvents.size());
        for (Integer ptr : pointerList) {
            AccountEvent accountEvent = accountEvents.get(ptr);
            listReverseBillResponse = cancelBill(accountEvent, reverseBillRequestInfo, authToken);
        }


        return listReverseBillResponse;
    }

    private List<ReverseBillResponse> reverseBillForShortPeriods(ClientReverseBillRequest clientReverseBillRequest, ReverseBillRequest reverseBillRequestInfo, final String authToken) {
        TargetAccountNumber accountNumber = new TargetAccountNumber(clientReverseBillRequest.getAccountId(), null);
        List<AccountEvent> accountList = accountTransactionsClient.getAllTransactionsForAccountNumber(accountNumber,
                String.valueOf(clientReverseBillRequest.getMoveDate().getYear()));

        Optional<AccountEvent> accountEvent = accountList.stream()
                .filter(acc -> acc.getBillEndDate() != null)
                .filter(acc -> acc.getAccountStatus() != null)
                .filter(acc -> acc.getAccountEventType() != null)
                .filter(acc -> !acc.getAccountStatus().toUpperCase().equals(AccountEventStatus.CANCELLED.getStatus()))
                .filter(acc -> acc.getAccountEventType().getCode().equals(AccountEventType.BILLI.name())
                        || acc.getAccountEventType().getCode().equals(AccountEventType.REBIL.name()))
                .filter(acc -> !acc.getBillEndDate().isBefore(clientReverseBillRequest.getMoveDate()))
                .filter(acc -> hasInvoiceBilledGivenProperty(accountNumber, acc.getCreatedDateTime(), clientReverseBillRequest.getPropertyId(), authToken))
                .min((AccountEvent a, AccountEvent b) -> a.getBillEndDate().compareTo(b.getBillEndDate()));

        List<ReverseBillResponse> listReverseBillResponse = new ArrayList<>();

        if (accountEvent.isPresent()) {
            listReverseBillResponse = cancelBill(accountEvent.get(), reverseBillRequestInfo, authToken);
        } else {
            log.info("No bills to reverse for  " + clientReverseBillRequest.toString());
        }
        return listReverseBillResponse;
    }

    /**
     * if batchSize =3, and listSize =8, requires ==> 2,5,7
     * if batchSize =3, and listSize =7, requires ==> 2,5,6  - note: needs the last item always.
     */
    private List<Integer> getListIndexAtGivenInterval(final int batchSize, final int listSize) {
        if (batchSize <= 0) {
            throw new STWBusinessException("Invalid batchSize");
        }
        return IntStream.range(0, listSize)
                .filter(i ->
                        (i + 1) % batchSize == 0 // to capture every repeating interval of batchSize
                                || i == listSize - 1 // to capture the final item in the list
                )
                .boxed()
                .collect(toList());
    }

    private List<ReverseBillResponse> cancelBill(final AccountEvent accountEvent, final ReverseBillRequest reverseBillRequestInfo, final String authToken) {
        List<ReverseBillResponse> listReverseBillResponse = new ArrayList<>();
        ReverseBillRequest reverseBillRequest = updateReverseBillRequest(reverseBillRequestInfo, accountEvent);
        IIBCancelBillRequest cancelBillRequest = (IIBCancelBillRequest) reverseBillRequestTransfromer.transform(reverseBillRequest);

        List<IIBCancelBillResponse> listCancelBillResponse = cancelBillClient.cancelBill(cancelBillRequest, authToken);
        listCancelBillResponse.forEach(e -> listReverseBillResponse.add((ReverseBillResponse) reverseBillResponseTransfromer.transform(e)));
        return listReverseBillResponse;
    }

    private ReverseBillRequest createReverseBillRequest(ClientReverseBillRequest clientReverseBillRequest) {

        ReverseBillRequest request = new ReverseBillRequest();
        TargetAccountNumber accountNumber = new TargetAccountNumber(clientReverseBillRequest.getAccountId(), null);

        request.setAccountId(accountNumber);
        request.setPropertyId(clientReverseBillRequest.getPropertyId());

        // set default values for the rest of the attributes
        ReverseBillReason billReason = new ReverseBillReason();
        billReason.setCode(BILLREASON_CODE);
        billReason.setValue(BILLREASON_VALUE);
        billReason.setValueSet(BILLREASON_VALUE_SET);

        request.setBillCancelReason(billReason);
        request.setIsCancelAllReads(true);
        request.setServiceProvisionNum((long) 0);
        request.setShowOnBill(true);
        request.setCheckMultiSPFlag(true);
        request.setPrintAdjustNoteFlag(false);
        request.setRebillFlag(true);
        request.setShowOnBill(true);
        return request;

    }

    private ReverseBillRequest updateReverseBillRequest(final ReverseBillRequest reverseBillRequestInfo,
            final AccountEvent accountEvent) {
        reverseBillRequestInfo.setCreatedTime(accountEvent.getCreatedDateTime());
        if (accountEvent.getDateOfIssue() != null) {
            reverseBillRequestInfo.setDateOfIssue(accountEvent.getDateOfIssue().atStartOfDay());
        }
        return reverseBillRequestInfo;
    }

}
