/*
 *
 *  * Copyright (c) Severn Trent Systems. All Rights Reserved.
 *  *
 *  * This software is the confidential and proprietary information
 *  * of Severn Trent Systems ("Confidential Information").  You shall
 *  * not disclose such Confidential Information and shall use it only
 *  * in accordance with the terms of your license agreement.
 *  *
 *  * SEVERN TRENT SYSTEMS MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT
 *  * THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 *  * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 *  * NON-INFRINGEMENT. SEVERN TRENT SYSTEMS SHALL NOT BE LIABLE FOR
 *  * ANY DAMAGES SUFFERED BY THE LICENSEE AS A RESULT OF USING,
 *  * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package uk.co.stwater.api.osgi.chor.contact;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.chor.ChorConfigService;
import uk.co.stwater.api.osgi.chor.ChorProgressMonitor;
import uk.co.stwater.api.osgi.chor.ChorResponse;
import uk.co.stwater.api.osgi.chor.ChorUtils;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.targetconnector.client.api.insertmailingaddress.MailingAddress;

@Named
@OsgiServiceProvider(classes = {ChorContactTypeResolver.class})
public class ChorContactTypeResolverService implements ChorContactTypeResolver {

    Logger log = LoggerFactory.getLogger(this.getClass());
    private static final String ASSESSED = "A";
    private static final String UNMEASURED = "U";
    private static final String MEASURED = "M";

    public static final String NON_ACTIVE_PAYMENT_PLAN_INDICATOR = "N";

    // PRB2022
    private static final List<String> ERROR_LIST = Arrays
            .asList(new String[]{"513030", "513130", "513630", "513530", "512930", "512530"});

    enum RestrictionCode {
        PROBATE(ContactTypes.WEB667), NETWORK(ContactTypes.WEB661), VULNERABLE(ContactTypes.WEB663), SOAC(ContactTypes.WEB669),
        BULK_OWN_UNM(ContactTypes.WEB700), POST_CLAIM(ContactTypes.WEB671), POST_JUDGEMENT(ContactTypes.WEB655), SOCIAL_TARIFF(ContactTypes.WEB694);

        private ContactType contactType;

        RestrictionCode(ContactTypes contactType) {
            this.contactType = new ContactType(contactType, false);
        }
        ContactType getContactType() {
            return contactType;
        }
    }

    enum ErrorCode {
        NON_TARIFF("512830",ContactTypes.WEB657),
        NO_TARIFF_ASSIGNED("513330", ContactTypes.WEB658),
        SOAC("513830", ContactTypes.WEB669),
        SOCIAL_TARIFF("514330", ContactTypes.WEB694),
        WATERSURE("514230", ContactTypes.WEB663),
        TEMP_DISCONNECTION("513730", ContactTypes.WEB670),
        NO_TARIFF_ASSIGNED_2("513230", ContactTypes.WEB658),
        ERROR_514130("514130", ContactTypes.WEB679),
        ERROR_510830("510830", ContactTypes.WEB659),
        ERROR_513530("513530", ContactTypes.WEB659),
        ERROR_513630("513630", ContactTypes.WEB659),
        POST_CLAIM("513930", ContactTypes.WEB671),
        POST_JUDGEMENT("514030", ContactTypes.WEB655);

        private String code;
        private ContactType contactType;

        ErrorCode(String code, ContactTypes contactTypes) {
            this.code = code;
            this.contactType = new ContactType(contactTypes, false);
        }

        String getCode() {
            return this.code;
        }

        ContactType getContactType() {
            return this.contactType;
        }

        static ErrorCode fromCode(String code) {
            for(ErrorCode errorCode: ErrorCode.values()) {
                if(errorCode.getCode().equals(code)) {
                    return errorCode;
                }
            }
            throw new IllegalArgumentException("Cannot find ErrorCode for "+ code);
        }
    }

    private static final List<RestrictionCode> CONTACT_TYPE_RESTRICTIONS = Arrays.asList(RestrictionCode.NETWORK,
            RestrictionCode.VULNERABLE, RestrictionCode.SOAC, RestrictionCode.BULK_OWN_UNM, RestrictionCode.POST_CLAIM,
            RestrictionCode.POST_JUDGEMENT,RestrictionCode.SOCIAL_TARIFF);

    @Inject
    private ChorConfigService configService;

    @OsgiService
    @Inject
    private SpecialConditionService specialConditionService;

    @Override
    public List<ContactType> getContactTypes(ChorResponse response, Long legalEntityId, Account account,
                                             TargetAccountNumber targetAccountNumber, MoveRequestDetail movingOutDetails,
                                             MoveRequestDetail movingInDetails, Address newAddressPreviousCustomer, boolean billPayerAtMovingInAddress, AccountBrand accountBrand)
            throws STWTechnicalException, STWBusinessException {

        final boolean successful = response.isSuccess();
        final String errorCode = response.getErrorCode();
        final boolean exceptionOccurred = response.isExceptionOccurred();
        final ChorProgressMonitor chorProgressMonitor = response.getChorProgressMonitor();

        List<ChorMeterRead> movingInMeterReads = new ArrayList<>();
        List<ChorMeterRead> movingOutMeterReads = new ArrayList<>();
        Address movingInAddress = null;
        LocalDate movingOutDate = null;

        if (movingInDetails != null) {
            movingInMeterReads = movingInDetails.getMeterReadings();
            movingInAddress = movingInDetails.getAddress();
        }

        if (movingOutDetails != null) {
            movingOutMeterReads = movingOutDetails.getMeterReadings();
            movingOutDate = movingOutDetails.getDate();
        }

        List<ContactType> results = new ArrayList<>();

        List<SpecialConditionRestriction> restrictions = new ArrayList<>();

        if (successful) {
            if (account != null && legalEntityId != null) {
                restrictions = specialConditionService.checkSpecialConditions(targetAccountNumber, legalEntityId, StringUtils.EMPTY,
                        SpecialConditionAction.MOVING_HOUSE_CHECK_3);
            }
            // Great the CHOR service has been a success lets decide what kind of contact to
            // raise....
            log.debug("Chor service successfull - now decide what type of contact to raise");
            // if calculation of Move in or move out will not completed than create a
            // contract

            if (ChorUtils.isDoubleSidedChor(movingInDetails, movingOutDetails, billPayerAtMovingInAddress)) {
                log.debug("Chor is double sided");
                if (ChorUtils.hasSimBillFailed(chorProgressMonitor)) {
                    addWebContact714(results);
                }
                if (!ChorUtils.hasActivePaymentPlan(account)) {
                    log.debug("has no active payment plan");
                    // they didn't have an existing payment plan, and still don't
                    addWebContactForSpecialRestrictions(results, restrictions);
                } else {
                    log.debug("has active payment plan.");
                    if (account == null) {
                        throw new STWTechnicalException("Unable to add contact for actiave plan as account is null");
                    }
                    switch (response.getSupplyType()) {
                        // When the move in date property is Unmeasured
                        case UNMEASURED:
                            addWebContactForUnmeasuredSupplyType(account, movingOutDetails, results, restrictions);
                            break;
                        case MEASURED:
                            addWebContactForMeasuredSupplyType(account, movingOutMeterReads, results, restrictions);
                            break;
                        case ASSESSED:
                            addAssessedWebContact(account, results);
                            break;
                    }
                }
            } else if (ChorUtils.isMoveInOnly(movingInDetails, movingOutDetails, billPayerAtMovingInAddress)
                    || ChorUtils.isMoveOutOnly(movingInDetails, movingOutDetails, billPayerAtMovingInAddress)) {
                log.debug("Chor is move in or move out only");
                if (ChorUtils.hasSimBillFailed(chorProgressMonitor)) {
                    addWebContact714(results);
                } else {
                    addWebContactForSpecialRestrictions(results, restrictions);
                }
            }
            // Raise a PROBATE contact where special condition exists regardless of PP
            if (hasRestriction(restrictions, RestrictionCode.PROBATE.toString())) {
                results.add(new ContactType(ContactTypes.WEB667, false));
                log.debug("account has probate special conditions: raise PROBATE_CONTACT_TYPE");
            }

            // Raise a manual address entry contact where previous occupants mailing address
            // has been set by using the manual entry form.
            if (newAddressPreviousCustomer != null
                    && MailingAddress.USER_DEFINED.equals(newAddressPreviousCustomer.getId())) {
                results.add(new ContactType(ContactTypes.WEB675, false));
                log.debug(
                        "Previous occupants mailing address has been defined using manual entry: raise PREVIOUS_OCCUPANT_MANUAL_ADDRESS_CONTACT_TYPE");
            }
        } else {
            if (account != null && legalEntityId != null) {
                restrictions = specialConditionService.checkSpecialConditions(targetAccountNumber, legalEntityId, StringUtils.EMPTY,
                        SpecialConditionAction.MOVING_HOUSE_CHECK_2);
            }
            // the chor service has failed, decide what type of contact /aq to raise
            log.debug("Chor service not successfull");

            // Something failed in the CHOR service.

            log.debug("property is {}", movingInDetails.getPropertyBrand());
            log.debug("Account Brand is {}", accountBrand);
            final boolean isValidBrand = accountBrand == movingInDetails.getPropertyBrand();
            boolean isMoreThanXmonths = isMovingOutDateTooOld(movingOutDate, false);
            boolean isMoreThanMoveOutXmonths = isMovingOutDateTooOld(movingOutDate, true);
            boolean isNonProperty = movingInAddress == null || movingInAddress.getPropertyNum() == null || !isValidBrand;
            log.debug("Is too old {}", isMoreThanXmonths);
            log.debug("Is Non Property {}", isNonProperty);


            // 4.6.5:
            // modified for CR3436
            boolean isPriorityError = false;
            if (isMoreThanMoveOutXmonths && billPayerAtMovingInAddress && StringUtils.isNotEmpty(errorCode)) {
                if (ERROR_LIST.contains(errorCode)) {
                    isPriorityError = true;
                }
            }

            if (isPriorityError) {
                // PRB2022: 4.6.5
                results.add(new ContactType(ContactTypes.WEB659, false));
                log.debug("contact type to raise: 1 * EXCEPTION_CONTACT_TYPE");
            } else if (ChorUtils.isForcedMeterReading(movingOutMeterReads, movingInMeterReads)) {
                // td1526 this check is now performed when chor success = false.
                // Forced Meter Reading
                results.add(new ContactType(ContactTypes.WEB656, false));
                log.debug("contact type to raise: INVALID_METER_READING_CONTACT_TYPE");
            } else if (!restrictions.isEmpty()) {
                restrictions.stream().filter(restriction -> CONTACT_TYPE_RESTRICTIONS.contains(RestrictionCode.valueOf(restriction.getTypeName()))).forEach(restriction -> {
                    RestrictionCode restrictionCode = RestrictionCode.valueOf(restriction.getTypeName());
                    results.add(restrictionCode.getContactType());
                    log.debug("raise contact: {} ", restriction.getTypeName());
                });
            } else if (isMoreThanMoveOutXmonths && !exceptionOccurred
                    && (isNonProperty || !billPayerAtMovingInAddress)) {
                // PRB191: 4.6.2:
                results.add(new ContactType(ContactTypes.WEB652, true));
                log.debug("raise contact: X_MONTHS_CONTACT_TYPE ");
            } else if (isNonProperty && billPayerAtMovingInAddress) { // QC 1721 Create AQ for a non property
                results.add(new ContactType(ContactTypes.WEB677, false));
                log.debug("raise contact: NON_PROPERTY_MOVE_IN_ADDRESS ");
            } else if (movingInAddress == null || movingInAddress.getAddressCode() == 0L) {
                // No Forwarding Address
                results.add(new ContactType(ContactTypes.WEB651, false));
                log.debug("raise contact: NO_FORWARDING_ADDRESS_CONTACT_TYPE ");
            }
            // changed for CR3436
            else if (isMoreThanXmonths && !exceptionOccurred) {
                results.add(new ContactType(ContactTypes.WEB652, true));
                log.debug("raise contact: X_MONTHS_CONTACT_TYPE ");
            } else if (ChorUtils.isPreValidationCheckFailed(movingOutMeterReads, movingInMeterReads)) {
                // Meter Reading Valid Pre Validation
                results.add(new ContactType(ContactTypes.WEB656, false));
                log.debug("raise contact: INVALID_METER_READING_CONTACT_TYPE ");
            } else if (exceptionOccurred) {
                log.debug("getContactTypes, an exception was thrown");

                if (StringUtils.isNotEmpty(errorCode)) {
                    try {
                        ErrorCode errorCodeType = ErrorCode.fromCode(errorCode);
                        results.add(errorCodeType.getContactType());
                        log.debug("raise contact: {}", errorCodeType);
                    } catch (IllegalArgumentException e) {
                        results.add(new ContactType(ContactTypes.WEB659, false));
                        log.debug("raise contact: 2 * EXCEPTION_CONTACT_TYPE ");
                    }
                } else {
                    // Exception Occurred
                    results.add(new ContactType(ContactTypes.WEB659, false));
                    log.debug("raise contact: 3 * EXCEPTION_CONTACT_TYPE ");
                }
            } else {
                // Exception Occurred
                results.add(new ContactType(ContactTypes.WEB659, false));
                log.debug("raise contact: 4 * EXCEPTION_CONTACT_TYPE ");
            }
        }

        return results;
    }


    private void addWebContact714(List<ContactType> results) {
        log.debug("Sim Bill Failed: raise COMPLETED_SIMBILL_FAILED");
        results.add(new ContactType(ContactTypes.WEB714, false));
    }

    private void addWebContactForSpecialRestrictions(List<ContactType> results,
                                                     List<SpecialConditionRestriction> restrictions) {
        results.add(new ContactType(ContactTypes.WEB649, true));
        if (restrictions.size() > 0) {
            log.debug("account has special conditions: raise SPECIAL_CONDITION_CONTACT_TYPE");
            results.add(new ContactType(ContactTypes.WEB650, false));
        }
    }

    private void addWebContactForMeasuredSupplyType(Account account, List<ChorMeterRead> movingOutMeterReads,
                                                    List<ContactType> results, List<SpecialConditionRestriction> restrictions) {
        // When the move in property has meter read
        if (!CollectionUtils.isEmpty(movingOutMeterReads)) {
            log.debug("Measured Move Out: Raised Chor completed and payment plan copied!");
            addWebContactForSpecialRestrictions(results, restrictions);
        } else {
            // If date is in future and have DD and NON - DD
            if (account.isDemandDirectDebit()) {
                // assumption: if the account being chor'd has an active pp then if
                // isPaymentPlanPaidByDirectDebit returns true
                // it is for this account and therefore paid by dd.
                // paid by dd = create web668
                results.add(new ContactType(ContactTypes.WEB668, false));
                log.debug(
                        "payment plan paid by direct debit: raise ACTIVE_PAYMENT_PLAN_WITH_DD_CONTACT_TYPE with measured Property moved out");
            } else {
                // !paid by dd = create web665
                results.add(new ContactType(ContactTypes.WEB665, false));
                log.debug(
                        "payment plan not paid by direct debit: raise ACTIVE_PAYMENT_PLAN_CONTACT_TYPE with measured Property moved out");
            }
        }
    }

    private void addAssessedWebContact(Account account, List<ContactType> results) {
        log.debug("Measured Move Out: ");
        if (account.isDemandDirectDebit()) {
            // assumption: if the account being chor'd has an active pp then if
            // isPaymentPlanPaidByDirectDebit returns true
            // it is for this account and therefore paid by dd.
            // paid by dd = create web668
            results.add(new ContactType(ContactTypes.WEB668, false));
            log.debug(
                    "payment plan paid by direct debit: raise ACTIVE_PAYMENT_PLAN_WITH_DD_CONTACT_TYPE with Assessed property move out");
        } else {
            // !paid by dd = create web665
            results.add(new ContactType(ContactTypes.WEB665, false));
            log.debug(
                    "payment plan not paid by direct debit: raise ACTIVE_PAYMENT_PLAN_CONTACT_TYPE with Assessed property move out");
        }
    }

    private void addWebContactForUnmeasuredSupplyType(Account account, MoveRequestDetail movingOutDetails,
                                                      List<ContactType> results, List<SpecialConditionRestriction> restrictions) {
        if (movingOutDetails.isFuture() && movingOutDetails.isMeasured()) {
            // If mo property is measured and the move-out date is in future and have DD and
            // Non - DD
            if (account.isDemandDirectDebit()) {
                // assumption: if the account being chor'd has an active pp then if
                // isPaymentPlanPaidByDirectDebit returns true
                // it is for this account and therefore paid by dd.
                // paid by dd = create web668
                results.add(new ContactType(ContactTypes.WEB668, false));
                log.debug(
                        "payment plan paid by direct debit: raise ACTIVE_PAYMENT_PLAN_WITH_DD_CONTACT_TYPE with Unmeasured Property moved out");
            } else {
                // !paid by dd = create web665
                results.add(new ContactType(ContactTypes.WEB665, false));
                log.debug(
                        "payment plan not paid by direct debit: raise ACTIVE_PAYMENT_PLAN_CONTACT_TYPE with Unmeasured Property moved out");
            }
        } else {
            log.debug("UnMeasured Move Out: Raised Chor completed and payment plan copied!");
            addWebContactForSpecialRestrictions(results, restrictions);
        }
    }

    // added for CR3436
    private boolean isMovingOutDateTooOld(LocalDate movingOutDate, boolean moveOutOnly) {

        LocalDate today = LocalDate.now();

        LocalDate limitForBillPayer = today.minusMonths(configService.getMonthsInPastEvidenceRequiredForBillPayer());
        LocalDate limitForNonBillPayer = today
                .minusMonths(configService.getMonthsInPastEvidenceRequiredForNonBillPayer());

        if (movingOutDate == null) {
            return false;
        } else {
            if (moveOutOnly) {
                return movingOutDate.isBefore(limitForNonBillPayer);
            } else {
                return movingOutDate.isBefore(limitForBillPayer);
            }
        }
    }

    private boolean hasRestriction(List<SpecialConditionRestriction> restrictions, String restrictionCode) {
        return restrictions.stream().anyMatch(t -> t.getTypeName().equals(restrictionCode));
    }

}
