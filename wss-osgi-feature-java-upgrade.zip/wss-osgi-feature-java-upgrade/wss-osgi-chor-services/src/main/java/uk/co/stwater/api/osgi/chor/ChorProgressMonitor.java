package uk.co.stwater.api.osgi.chor;

import org.apache.commons.lang3.builder.ToStringBuilder;
import uk.co.stwater.api.osgi.model.payment.common.PaymentPlan;
import uk.co.stwater.targetconnector.client.api.directdebit.PaymentMandate;

import java.util.Iterator;

/**
 * Created by tellis3 on 27/04/2017.
 */
public class ChorProgressMonitor {

    public enum Progress {
        COMPLETED("Completed"), FAILED("Failed"), NOT_ATTEMPTED("Not attempted");

        String desc;

        Progress(String desc){
            this.desc = desc;
        }
        public String getDesc(){
            return desc;
        }

    }
    private boolean moveOutMeterRead;

    private boolean moveInMeterRead;
    private PaymentPlan oldPaymentPlan;
    private PaymentMandate oldPaymentMandate;
    private PaymentPlan newPaymentPlan;
    private String createNewPaymentPlanErrorReason;
    private ChorStateManager chorStateManager;

    private ChorProgressMonitor() {}

    public ChorProgressMonitor(ChorStateManager chorStateManager, boolean moveOutMeterRead, boolean moveInMeterRead) {
        this.chorStateManager = chorStateManager;
        this.moveOutMeterRead = moveOutMeterRead;
        this.moveInMeterRead = moveInMeterRead;
    }

    public ChorProgressMonitor(ChorStateManager chorStateManager, boolean moveInMeterRead) {
        this.chorStateManager = chorStateManager;
        this.moveInMeterRead = moveInMeterRead;
    }

    public ChorStateManager getChorStateManager() {
        return this.chorStateManager;
    }

    public Progress getProgressForState(ChorState state) {
        Iterator<ChorState> stateIterator = chorStateManager.getStateIterator();
        Progress progress = Progress.NOT_ATTEMPTED;
        while(stateIterator.hasNext()) {
            if(stateIterator.next() == state) {
                ChorState nextState = stateIterator.next();
                if(nextState.name().endsWith(Progress.FAILED.name())) {
                    progress = Progress.FAILED;
                }
                if(nextState.name().endsWith(Progress.COMPLETED.name())) {
                    progress = Progress.COMPLETED;
                }
            }
        }
        return progress;
    }

    public PaymentMandate getOldPaymentMandate() {
        return oldPaymentMandate;
    }

    public void setOldPaymentMandate(PaymentMandate oldPaymentMandate) {
        this.oldPaymentMandate = oldPaymentMandate;
    }

    public String getCreateNewPaymentPlanErrorReason() {
        return createNewPaymentPlanErrorReason;
    }

    public void setCreateNewPaymentPlanErrorReason(String createNewPaymentPlanErrorReason) {
        this.createNewPaymentPlanErrorReason = createNewPaymentPlanErrorReason;
    }

    public boolean isMoveOutMeterRead() {
        return moveOutMeterRead;
    }

    public boolean isMoveInMeterRead() {
        return moveInMeterRead;
    }

    public PaymentPlan getOldPaymentPlan() {
        return oldPaymentPlan;
    }

    public void setOldPaymentPlan(PaymentPlan oldPaymentPlan) {
        this.oldPaymentPlan = oldPaymentPlan;
    }

    public PaymentPlan getNewPaymentPlan() {
        return newPaymentPlan;
    }

    public void setNewPaymentPlan(PaymentPlan newPaymentPlan) {
        this.newPaymentPlan = newPaymentPlan;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("moveOutMeterRead", moveOutMeterRead)
                .append("moveInMeterRead", moveInMeterRead)
                .append("chorStateManager", chorStateManager)
                .toString();
    }
}