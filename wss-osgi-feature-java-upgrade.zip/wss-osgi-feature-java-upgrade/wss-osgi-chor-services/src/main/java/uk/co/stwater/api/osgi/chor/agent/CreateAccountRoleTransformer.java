package uk.co.stwater.api.osgi.chor.agent;

import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.customer.exception.STWBusinessCustomerException;
import uk.co.stwater.api.osgi.model.AccountRole;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.iib.client.api.roles.create.IIBCreateRoleRequest;

import javax.inject.Named;

@Named
public class CreateAccountRoleTransformer implements Transformer {

    @Override
    public Object transform(Object source) {
        IIBCreateRoleRequest request = null;

        if (null == source) {
            throw new STWBusinessCustomerException("source is a required parameter");

        }

        if (source instanceof AccountRole) {

            AccountRole role = (AccountRole) source;

            request = new IIBCreateRoleRequest();
            request.setAcccountNumber(role.getAccountNumber());
            RefData theRole = new RefData();

            if (role.getRole() != null) {
                theRole.setCode(role.getRole().getCode());
                theRole.setValue(role.getRole().getValue());
            }
            request.setRole(theRole);
            request.setLegalEntityNo(role.getLegalEntityId());
            request.setStartDate(role.getStartDate());

        }

        return request;
    }

}
