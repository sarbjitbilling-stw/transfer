package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.targetconnector.client.api.setchor.ChorClientResponse;

import java.util.List;

import static org.apache.commons.collections.CollectionUtils.isEmpty;
import static uk.co.stwater.api.osgi.model.constants.GlobalConstants.UNKNOWN_ACCOUNT_NUMBER;
import static uk.co.stwater.api.osgi.model.constants.GlobalConstants.UNKNOWN_ACCOUNT_NUMBER_FOR_CONTACT;

public class ChorContext {

    private ChorRequest chorRequest;

    private String username;

    private ChorResponse chorResponse;

    private ChorClientResponse chorClientResponse;

    private ChorProgressMonitor chorProgressMonitor;

    private ChorStateManager chorStateManager;

    private Account movingOutAccount;

    private AccountBrand accountBrand;

    private boolean existingCustomer;

    public static ChorContext existingCustomer(ChorRequest chorRequest, String username, Account movingOutAccount, ChorStateManager chorStateManager) {
        validateRequest(chorRequest, chorStateManager);
        if (movingOutAccount == null) {
            throw new IllegalArgumentException("moving out account cannot be null");
        }
        ChorContext chorContext = new ChorContext();
        chorContext.existingCustomer = true;
        chorContext.chorRequest = chorRequest;
        if (chorRequest.getMovingInDetails() != null) {
            chorContext.accountBrand = chorRequest.getMovingInDetails().getPropertyBrand();
        } else {
            chorContext.accountBrand = chorRequest.getMovingOutDetails().getPropertyBrand();
        }
        chorContext.username = username;
        chorContext.chorResponse = new ChorResponse(false);
        chorContext.chorProgressMonitor = new ChorProgressMonitor(chorStateManager,
                isEmpty(chorRequest.getMovingOutDetails().getMeterReadings()),
                isEmpty(chorRequest.getMovingInDetails().getMeterReadings()));
        chorContext.chorResponse.setChorProgressMonitor(chorContext.chorProgressMonitor);
        chorContext.chorStateManager = chorContext.chorProgressMonitor.getChorStateManager();
        if (movingOutAccount != null) {
            chorContext.movingOutAccount = movingOutAccount;
        }
        return chorContext;
    }

    public static ChorContext existingCustomer(ChorRequest chorRequest, String username, Account movingOutAccount, ChorStateManager chorStateManager, ChorResponse chorResponse) {
        ChorContext chorContext = existingCustomer(chorRequest, username, movingOutAccount, chorStateManager);
        chorContext.chorResponse = chorResponse;
        return chorContext;
    }

    public static ChorContext newCustomer(ChorRequest chorRequest, String username, ChorStateManager chorStateManager) {
        validateRequest(chorRequest, chorStateManager);
        ChorContext chorContext = new ChorContext();
        chorContext.existingCustomer = false;
        chorContext.chorRequest = chorRequest;
        chorContext.accountBrand = chorRequest.getMovingInDetails().getPropertyBrand();
        chorContext.username = username;
        chorContext.chorResponse = new ChorResponse(false);
        chorContext.chorProgressMonitor = new ChorProgressMonitor(chorStateManager,
                chorRequest.getMovingInDetails().getMeterReadings() != null && chorRequest.getMovingInDetails().getMeterReadings().size() > 0);
        chorContext.chorResponse.setChorProgressMonitor(chorContext.chorProgressMonitor);
        chorContext.chorStateManager = chorContext.chorProgressMonitor.getChorStateManager();
        return chorContext;
    }

    public MoveRequestDetail getMovingInDetails() {
        return chorRequest.getMovingInDetails();
    }

    public MoveRequestDetail getMovingOutDetails() {
        return chorRequest.getMovingOutDetails();
    }

    public TargetAccountNumber getAccountNumberForContact() {
        return getAccountNumber(true);
    }

    public TargetAccountNumber getAccountNumber() {
        return getAccountNumber(false);
    }

    public Account getAccount() {
        return existingCustomer ? this.movingOutAccount : new Account();
    }

    public Customer getCustomer() {
        return chorRequest.getCustomer();
    }

    void setCustomer(Customer customer) {
        this.chorRequest.setCustomer(customer);
    }

    public boolean isBillPayerAtMovingInAddress() {
        return chorRequest.isBillPayerAtMovingInAddess();
    }

    public String getUsername() {
        return username;
    }

    public List<Customer> getResponsibilities() {
        return chorRequest.getNewResponsibilities();
    }

    public Address getNewAddressPreviousCustomer() {
        return chorRequest.getNewAddressPreviousCustomer();
    }

    public ChorResponse getChorResponse() {
        return this.chorResponse;
    }

    public Account getMovingOutAccount() {
        return movingOutAccount;
    }

    public void setMovingOutAccount(Account movingOutAccount) {
        this.movingOutAccount = movingOutAccount;
    }

    public ChorStateManager getChorStateManager() {
        return chorStateManager;
    }

    public void setAccountBrand(AccountBrand accountBrand) {
        this.accountBrand = accountBrand;
    }

    public AccountBrand getAccountBrand() {
        return accountBrand;
    }

    public boolean isExistingCustomer() {
        return this.existingCustomer;
    }

    public String getEmailAddress() {
        return this.chorRequest.getEmailAddress();
    }

    public String getContactNumber() {
        return this.chorRequest.getContactNumber();
    }

    private TargetAccountNumber getAccountNumber(boolean forContact) {
        return existingCustomer ? chorRequest.getAccountNumber() : getNewCustomerAccountNumber(chorResponse, forContact);
    }

    private static void validateRequest(ChorRequest chorRequest, ChorStateManager chorStateManager) {
        if (chorRequest == null) {
            throw new IllegalArgumentException("chorRequest cannot be null");
        }
        if (chorStateManager == null) {
            throw new IllegalArgumentException("chorStateManager cannot be null");
        }
    }

    private static TargetAccountNumber getNewCustomerAccountNumber(ChorResponse chorResponse, boolean forContact) {
        if (chorResponse.isSuccess()) {
            return chorResponse.getNewAccountNumber();
        } else {
            return forContact ? UNKNOWN_ACCOUNT_NUMBER_FOR_CONTACT : UNKNOWN_ACCOUNT_NUMBER;
        }
    }
}
