package uk.co.stwater.api.osgi.chor.agent;

import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.customer.create.IIBCreateCustomerRequest;

import javax.inject.Named;

@Named
public class CreateCustomerRequestTranformer implements Transformer {

    @Override
    public Object transform(Object source) {

        IIBCreateCustomerRequest request = null;
        if (null == source) {
            throw new STWBusinessException("source is a mandatory parameter");
        }

        if (source instanceof Customer) {
            Customer customer = (Customer) source;
            request = new IIBCreateCustomerRequest();

            RefData benefitType = new RefData();
            benefitType.setCode(customer.getBenefitType().getCode());
            request.setBenefitType(benefitType);

            request.setBenefitTypeVersion(customer.getBenefitTypeVersion());
            request.setDateOfBirth(customer.getDateOfBirth());
            request.setEmailAddress(customer.getEmailAddress());

            RefData employmentStatus = new RefData();
            employmentStatus.setCode(customer.getEmploymentStatus().getCode());
            request.setEmploymentStatusVersion("1");

            request.setEmploymentStatus(employmentStatus);
            request.setFirstName(customer.getFirstName());
            request.setLastName(customer.getLastName());

            request.setFacebookHandle(customer.getFacebookHandle());
            request.setFacebookHandleId(request.getFacebookHandleId());
            request.setFacebookHandleVersion(request.getFacebookHandleVersion());

            RefData homeOwnerStatus = new RefData();
            homeOwnerStatus.setCode(customer.getHomeOwnerStatus().getCode());
            request.setHomeOwnerStatus(homeOwnerStatus);
            request.setHomeOwnerStatusVersion(customer.getHomeOwnerStatusVersion());

            request.setId(customer.getId());
            request.setIsIndividual(customer.getIsIndividual());

            request.setIsWSSRegistered(customer.getIsWSSRegistered());
            request.setNiNumber(customer.getNiNumber());
            request.setNiNumberVersion(customer.getNiNumberVersion());
            request.setPreferredName(customer.getPreferredName());

            RefData sicCode = new RefData();
            sicCode.setCode(customer.getSicCode().getCode());
            request.setSicCode(sicCode);

            request.setTradingName(customer.getTradingName());
            request.setTwitterHandle(customer.getTwitterHandle());
            request.setTwitterHandleId(customer.getTwitterHandleId());
            request.setTwitterHandleVersion(customer.getTwitterHandleVersion());

            RefData waterMarketingValue = new RefData();
            waterMarketingValue.setCode(customer.getWaterMarketingValue().getCode());
            request.setWaterMarketingValue(waterMarketingValue);
        } else {
            throw new STWBusinessException("source must be an instance of Customer");
        }

        return request;
    }

}
