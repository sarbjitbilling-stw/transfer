package uk.co.stwater.api.osgi.chor.specialconditions;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.model.LegalEntitySpecialCondition;
import io.swagger.model.PropertySpecCond;
import uk.co.stwater.api.osgi.chor.agent.MovePropertyServiceImpl;
import uk.co.stwater.api.osgi.chor.agent.ProcessOutcomeEnum;
import uk.co.stwater.api.osgi.model.AccountRole;
import uk.co.stwater.api.osgi.model.Move;
import uk.co.stwater.api.osgi.model.MoveDetails;
import uk.co.stwater.api.osgi.model.ProcessOutcome;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.ServiceProvisionTariff;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.STWBaseException;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.specialconditions.LegalEntitySpecialConditionClient;
import uk.co.stwater.iib.client.api.specialconditions.PropertySpecialConditionClient;

@Named
public class ChorSpecialConditionServiceImpl implements ChorSpecialConditionService {
    private static final Logger LOG = LoggerFactory.getLogger(ChorSpecialConditionServiceImpl.class);

    static final String TYPE_CODE_SOAC = "SOAC";
    static final String TYPE_CODE_SOAC_PROPERTY = "SOACPROP";
    static final String TYPE_CODE_BDS_SOCIAL_TARIFF = "SOCIALTAR";
    static final String TYPE_CODE_BDS_PROPERTY = "BDS VOID";

    static final Set<String> PROPERTY_BLOCKING_CODES = buildPropertyBlockingCodes();
    static final Set<String> ACCOUNT_NON_CARRY_CODES = buildAccountNonCarryCodes();
    static final Set<String> ACCOUNT_NON_CARRY_OUTSIDE_SERVICED_AREA_CODES = buildAccountNonCarryOutsideServicedAreaCodes();

    static final Map<String, String> ACCOUNT_TO_PROPERTY_CODE_MAPPING = buildAccountToPropertyCodeMapping();

    @Inject
    @OsgiService
    private LegalEntitySpecialConditionClient legalEntitySpecialConditionClient;

    @Inject
    @OsgiService
    private PropertySpecialConditionClient propertySpecialConditionClient;

    private static final Set<String> buildPropertyBlockingCodes() {
        Set<String> blockingCodes = new HashSet<>();
        blockingCodes.add(TYPE_CODE_SOAC_PROPERTY);
        blockingCodes.add(TYPE_CODE_BDS_PROPERTY);
        return Collections.unmodifiableSet(blockingCodes);
    }

    private static final Set<String> buildAccountNonCarryCodes() {
        Set<String> nonCarryCodes = new HashSet<>();
        nonCarryCodes.add(TYPE_CODE_SOAC);
        return Collections.unmodifiableSet(nonCarryCodes);
    }

    private static final Set<String> buildAccountNonCarryOutsideServicedAreaCodes() {
        Set<String> nonCarryOutsideServiceAreaCodes = new HashSet<>();
        nonCarryOutsideServiceAreaCodes.add(TYPE_CODE_BDS_SOCIAL_TARIFF);
        return Collections.unmodifiableSet(nonCarryOutsideServiceAreaCodes);
    }

    private static final Map<String, String> buildAccountToPropertyCodeMapping() {
        Map<String, String> codeMapping = new HashMap<>();
        codeMapping.put(TYPE_CODE_SOAC, TYPE_CODE_SOAC_PROPERTY);
        codeMapping.put(TYPE_CODE_BDS_SOCIAL_TARIFF, TYPE_CODE_BDS_PROPERTY);
        return Collections.unmodifiableMap(codeMapping);
    }

    @Override
    public List<ProcessOutcome> beforeMoveIn(Move move, boolean isNewAccountCreatedForMoveIn, String authToken) {
        List<ProcessOutcome> outcomes = new ArrayList<>();

        if (hasBlockingSpecialConditions(move)) {
            LOG.debug("Handling blocking special conditions before move in");
            outcomes.addAll(endBlockingPropertySpecialConditions(move, authToken));

            // when a customer is moving in to a new property but not moving out of the the
            // old one we do not want to end the special conditions on the old account
            if (!isNewAccountCreatedForMoveIn) {
                outcomes.addAll(endAccountNonCarrySpecialConditions(move.getIncomingMoveDetails(), authToken));
            }
        } else {
            LOG.debug("No blocking special conditions found for move in");
        }

        return outcomes;
    }

    @Override
    public List<ProcessOutcome> afterMoveOut(Move move, String authToken) {
        List<ProcessOutcome> outcomes = new ArrayList<>();

        if (hasBlockingSpecialConditions(move)) {
            LOG.debug("Handling blocking special conditions after move out");
            // needs to be done before ending account special conditions as this step needs
            // to know which account special condition were open before the move out
            outcomes.addAll(transferOutgoingAccountSpecialConditionsToProperty(move, authToken));

            outcomes.addAll(endAccountNonCarrySpecialConditions(move.getOutgoingMoveDetails(), authToken));

            if (move.isMovingOutsideServicedArea()) {
                outcomes.addAll(
                        endAccountNonCarryOutsideStwAreaSpecialConditions(move.getOutgoingMoveDetails(), authToken));
            }
        } else {
            LOG.debug("No blocking special conditions found for move out");
        }

        return outcomes;
    }

    boolean hasBlockingSpecialConditions(Move move) {
        return hasBlockingSpecialConditions(move.getIncomingMoveDetails())
                || hasBlockingSpecialConditions(move.getOutgoingMoveDetails());
    }

    boolean hasBlockingSpecialConditions(MoveDetails moveDetails) {
        return moveDetails != null && moveDetails.isBlockedBySpecialCondition();
    }

    /**
     * Ends property special conditions that would otherwise block the Target chor
     * request but that can be handled by {@code ChorSpecialConditionServiceImpl}.
     *
     * <p>
     * See {@link #PROPERTY_BLOCKING_CODES} for the list of special condition codes
     * that can be handled.
     */
    List<ProcessOutcome> endBlockingPropertySpecialConditions(Move move, String authToken) {
        return endPropertySpecialConditions(move, PROPERTY_BLOCKING_CODES, authToken);
    }

    private List<ProcessOutcome> endPropertySpecialConditions(Move move, Set<String> typeCodes, String authToken) {
        Property property = move.getProperty();
        List<PropertySpecCond> blockingSpecialConditions = propertySpecialConditionClient
                .getAllActive(property.getPropertyId(), typeCodes, authToken);

        // ensure extra request data exists for required data for
        for (PropertySpecCond specialCondition : blockingSpecialConditions) {
            String typeCode = specialCondition.getSpecialConditionTypeCode();
            if (TYPE_CODE_BDS_PROPERTY.equals(typeCode)) {
                ensureServiceProvisionsIncludeRevenueClass(move.getIncomingMoveDetails());
            }
        }

        return endPropertySpecialConditions(move, blockingSpecialConditions, authToken);
    }

    private void ensureServiceProvisionsIncludeRevenueClass(MoveDetails moveDetails) {
        for (ServiceProvisionTariff tariff : moveDetails.getServiceProvisionTariffs()) {
            if (StringUtils.isBlank(tariff.getRevenueClassCode())) {
                throw new STWBusinessException(String.format("Revenue class not present for service provision %s",
                        tariff.getServiceProvisionNum()));
            }
        }
    }

    List<ProcessOutcome> endPropertySpecialConditions(Move move, List<PropertySpecCond> specialConditions,
            String authToken) {
        List<ProcessOutcome> outcomes = new ArrayList<>();

        for (PropertySpecCond specialCondition : specialConditions) {
            LocalDate endDate = getSpecialConditionEndDate(move.getIncomingMoveDetails());
            specialCondition.setEndDate(endDate);

            ProcessOutcome processOutcome = ProcessOutcomeEnum.END_PROPERTY_SPECIAL_CONDITION
                    .buildProcessOutcome(specialCondition.getSpecialConditionTypeCode());

            LOG.debug("Ending property special condition {} with end date {} for property {}",
                    specialCondition.getPropertySpecialConditionId(), specialCondition.getEndDate(),
                    specialCondition.getPropertyId());
            try {
                propertySpecialConditionClient.put(specialCondition, authToken);
            } catch (STWBaseException e) {
                LOG.error("Failed to end special condition {} for property {}",
                        specialCondition.getPropertySpecialConditionId(), specialCondition.getPropertyId(), e);

                String errorMessage = String.format(ProcessOutcomeEnum.END_PROPERTY_SPECIAL_CONDITION.getErrorMessage(),
                        specialCondition.getSpecialConditionTypeCode());
                processOutcome.setErrorDescription(errorMessage);
                processOutcome.setExceptionMessage(e.getMessage());
            }

            outcomes.add(processOutcome);
        }

        return outcomes;
    }

    /**
     * Ends account special conditions that cannot be carried after a move (i.e.
     * special conditions that are tied to the property too, such as SOAC).
     *
     * <p>
     * See {@link #ACCOUNT_NON_CARRY_CODES} for the list of special condition codes
     * that cannot be carried by account after move.
     */
    List<ProcessOutcome> endAccountNonCarrySpecialConditions(MoveDetails moveDetails, String authToken) {
        return endAccountSpecialConditions(moveDetails, ACCOUNT_NON_CARRY_CODES, authToken);
    }

    /**
     * Ends account special conditions that cannot be carried after a move to a
     * property outside the STW area (e.g. BDS).
     *
     * <p>
     * See {@link #ACCOUNT_NON_CARRY_OUTSIDE_SERVICED_AREA_CODES} for the list of
     * special condition codes that cannot be carried by account after move to a
     * property outside of the STW area.
     */
    List<ProcessOutcome> endAccountNonCarryOutsideStwAreaSpecialConditions(MoveDetails moveDetails, String authToken) {
        return endAccountSpecialConditions(moveDetails, ACCOUNT_NON_CARRY_OUTSIDE_SERVICED_AREA_CODES, authToken);
    }

    List<ProcessOutcome> endAccountSpecialConditions(MoveDetails moveDetails, Set<String> typeCodes, String authToken) {
        List<LegalEntitySpecialCondition> nonCarrySpecialConditions = getAccountSpecialConditions(moveDetails,
                typeCodes, authToken);

        if (nonCarrySpecialConditions.isEmpty()) {
            LOG.debug("No blocking special conditions found for account");
            return Collections.emptyList();
        }

        LocalDate endDate = getSpecialConditionEndDate(moveDetails);
        return endLegalEntitySpecialConditions(nonCarrySpecialConditions, endDate, authToken);
    }

    private List<LegalEntitySpecialCondition> getAccountSpecialConditions(MoveDetails moveDetails,
            Set<String> searchTypeCodes, String authToken) {
        // @formatter:off
        List<AccountRole> specialConditionRelatedRoles = moveDetails.getLegalEntityList().stream()
                .filter(this::isSpecialConditionRelatedAccountRole)
                .collect(Collectors.toList());
        // @formatter:on

        if (specialConditionRelatedRoles.isEmpty()) {
            throw new STWBusinessException("Special condition related roles not found in MoveDetails");
        }

        List<LegalEntitySpecialCondition> accountSpecialConditions = new ArrayList<>();

        for (AccountRole accountRole : specialConditionRelatedRoles) {
            String customerId = Long.toString(accountRole.getLegalEntityId());
            TargetAccountNumber accountNumber = accountRole.getAccountNumber();

            List<LegalEntitySpecialCondition> roleAccountSpecialConditions = legalEntitySpecialConditionClient
                    .getAllActiveAccount(customerId, accountNumber, searchTypeCodes, authToken);

            accountSpecialConditions.addAll(roleAccountSpecialConditions);
        }

        return accountSpecialConditions;
    }

    private boolean isSpecialConditionRelatedAccountRole(AccountRole accountRole) {
        String roleCode = accountRole.getRole().getCode();
        return MovePropertyServiceImpl.ROLE_PRIMARY.equals(roleCode)
                || MovePropertyServiceImpl.ROLE_CO_PRIMARY.equals(roleCode);
    }

    List<ProcessOutcome> endLegalEntitySpecialConditions(List<LegalEntitySpecialCondition> specialConditions,
            LocalDate endDate, String authToken) {
        List<ProcessOutcome> outcomes = new ArrayList<>();

        for (LegalEntitySpecialCondition specialCondition : specialConditions) {
            if (specialCondition.getLegalEntityNo() == null) {
                throw new STWTechnicalException("Special condition legal entity number is null");
            }
            String customerId = Long.toString(specialCondition.getLegalEntityNo());
            specialCondition.setEndDate(endDate);

            ProcessOutcome processOutcome = ProcessOutcomeEnum.END_LEGAL_ENTITY_SPECIAL_CONDITION
                    .buildProcessOutcome(specialCondition.getSpecialConditionTypeCode());

            LOG.debug("Ending legal entity special condition {} with end date {} for customer {} account {}",
                    specialCondition.getSpecialConditionTypeCode(), specialCondition.getEndDate(), customerId,
                    specialCondition.getAccountId());
            try {
                legalEntitySpecialConditionClient.put(customerId, specialCondition, authToken);
            } catch (STWBaseException e) {
                LOG.error("Failed to end {} special condition for customer {} account {}",
                        specialCondition.getSpecialConditionTypeCode(), customerId, specialCondition.getAccountId(), e);

                String errorMessage = String.format(
                        ProcessOutcomeEnum.END_LEGAL_ENTITY_SPECIAL_CONDITION.getErrorMessage(),
                        specialCondition.getSpecialConditionTypeCode());
                processOutcome.setErrorDescription(errorMessage);
                processOutcome.setExceptionMessage(e.getMessage());
            }

            outcomes.add(processOutcome);
        }

        return outcomes;
    }

    LocalDate getSpecialConditionEndDate(MoveDetails moveDetails) {
        return moveDetails.getMoveDate();
    }

    /**
     * Handles copying of account special conditions to property after they have
     * moved out. These are added as a blocker to another customer moving in via a
     * normal chor. Future move in's will need extra steps to be performed
     * beforehand.
     * 
     * <p>
     * Newly created property special condition will use the start date from the
     * corresponding account special condition. If an active property special
     * condition already exists for the same type then a new one will not be
     * created.
     *
     * <p>
     * See {@link #ACCOUNT_TO_PROPERTY_CODE_MAPPING} for the mapping of account to
     * property special condition codes.
     */
    List<ProcessOutcome> transferOutgoingAccountSpecialConditionsToProperty(Move move, String authToken) {
        List<ProcessOutcome> outcomes = new ArrayList<>();

        List<LegalEntitySpecialCondition> accountSpecialConditions = getAccountSpecialConditions(
                move.getOutgoingMoveDetails(), ACCOUNT_TO_PROPERTY_CODE_MAPPING.keySet(), authToken);

        // @formatter:off
        Set<String> accountTypeCodesToTransfer = accountSpecialConditions.stream()
                .map(LegalEntitySpecialCondition::getSpecialConditionTypeCode)
                .collect(Collectors.toSet());
        // @formatter:on

        // remove property special condition type codes that are superseded by others
        if (accountTypeCodesToTransfer.contains(TYPE_CODE_BDS_SOCIAL_TARIFF)) {
            LOG.debug("Not adding property special condition SOAC as adding BDS which supersededs it");
            accountTypeCodesToTransfer.remove(TYPE_CODE_SOAC);
        }

        List<LegalEntitySpecialCondition> accountSpecialConditionsToTransfer = accountSpecialConditions.stream().filter(
                specialCondition -> accountTypeCodesToTransfer.contains(specialCondition.getSpecialConditionTypeCode()))
                .collect(Collectors.toList());

        outcomes.addAll(transferOutgoingAccountSpecialConditionsToProperty(move, accountSpecialConditionsToTransfer,
                authToken));

        return outcomes;
    }

    List<ProcessOutcome> transferOutgoingAccountSpecialConditionsToProperty(Move move,
            List<LegalEntitySpecialCondition> accountSpecialConditionsToTransfer, String authToken) {
        Property property = move.getProperty();
        if (accountSpecialConditionsToTransfer.isEmpty()) {
            LOG.debug("No special condition required to be added to property {}", property.getPropertyId());
            return Collections.emptyList();
        }

        List<ProcessOutcome> outcomes = new ArrayList<>();

        // @formatter:off
        Set<String> requiredPropertyTypeCodes = accountSpecialConditionsToTransfer.stream()
                .map(LegalEntitySpecialCondition::getSpecialConditionTypeCode)
                .map(ACCOUNT_TO_PROPERTY_CODE_MAPPING::get)
                .collect(Collectors.toSet());
        // @formatter:on

        // get type codes for all active property special conditions
        List<PropertySpecCond> activeSpecialConditions = propertySpecialConditionClient
                .getAllActive(property.getPropertyId(), requiredPropertyTypeCodes, authToken);
        // @formatter:off
        Set<String> activePropertyTypeCodes = activeSpecialConditions.stream()
                .map(PropertySpecCond::getSpecialConditionTypeCode)
                .collect(Collectors.toSet());
        // @formatter:on

        // used to log message if multiple special conditions exist with same type code
        Set<String> transferedAccountTypeCodes = new HashSet<>();

        // add required property special conditions that do not already exist
        for (LegalEntitySpecialCondition accountSpecialCondition : accountSpecialConditionsToTransfer) {
            if (accountSpecialCondition.getAccountId() == null) {
                throw new STWTechnicalException("Special condition account number is null");
            }
            if (accountSpecialCondition.getLegalEntityNo() == null) {
                throw new STWTechnicalException("Special condition legal entity number is null");
            }


            String accountTypeCode = accountSpecialCondition.getSpecialConditionTypeCode();
            String propertyTypeCode = ACCOUNT_TO_PROPERTY_CODE_MAPPING.get(accountTypeCode);

            if (activePropertyTypeCodes.contains(propertyTypeCode)) {
                LOG.debug("Special condition with {} type already exists for property {}", propertyTypeCode,
                        property.getPropertyId());
            } else if (transferedAccountTypeCodes.contains(accountTypeCode)) {
                LOG.warn("Customer {} account {} has more than one active special condition of type {}",
                        accountSpecialCondition.getLegalEntityNo(), accountSpecialCondition.getAccountId(),
                        accountSpecialCondition.getSpecialConditionTypeCode());
            } else {
                ProcessOutcome processOutcome = transferOutgoingAccountSpecialConditionToProperty(property,
                        accountSpecialCondition, authToken);
                if (!processOutcome.hasError()) {
                    transferedAccountTypeCodes.add(accountTypeCode);
                }
                outcomes.add(processOutcome);
            }
        }

        return outcomes;
    }

    ProcessOutcome transferOutgoingAccountSpecialConditionToProperty(Property property,
            LegalEntitySpecialCondition accountSpecialCondition, String authToken) {
        // new property special condition will use same start date as the corresponding
        // account special condition
        PropertySpecCond specialCondition = buildSpecialCondition(property, accountSpecialCondition);

        ProcessOutcome processOutcome = ProcessOutcomeEnum.ADD_PROPERTY_SPECIAL_CONDITION
                .buildProcessOutcome(specialCondition.getSpecialConditionTypeCode());

        LOG.info("Adding {} special condition to property {} with start date {}",
                specialCondition.getSpecialConditionTypeCode(), specialCondition.getPropertyId(),
                specialCondition.getStartDate());
        try {
            propertySpecialConditionClient.post(specialCondition, authToken);
        } catch (STWBaseException e) {
            LOG.error("Failed to add {} special condition to property {}",
                    specialCondition.getSpecialConditionTypeCode(), specialCondition.getPropertyId(), e);

            String errorMessage = String.format(ProcessOutcomeEnum.ADD_PROPERTY_SPECIAL_CONDITION.getErrorMessage(),
                    specialCondition.getSpecialConditionTypeCode());
            processOutcome.setErrorDescription(errorMessage);
            processOutcome.setExceptionMessage(e.getMessage());
        }

        return processOutcome;
    }

    private PropertySpecCond buildSpecialCondition(Property property,
            LegalEntitySpecialCondition legalEntitySpecialCondition) {
        String propertyTypeCode = ACCOUNT_TO_PROPERTY_CODE_MAPPING
                .get(legalEntitySpecialCondition.getSpecialConditionTypeCode());

        PropertySpecCond propertySpecialCondition = new PropertySpecCond();
        propertySpecialCondition.setSpecialConditionTypeCode(propertyTypeCode);
        Long propertyId;
        try {
            propertyId = Long.parseLong(property.getPropertyId());
        } catch (NumberFormatException e) {
            throw new STWBusinessException(
                    String.format("Cannot convert property id  %s to number", property.getPropertyId()), e);
        }
        propertySpecialCondition.setPropertyId(propertyId);
        propertySpecialCondition.setStartDate(legalEntitySpecialCondition.getStartDate());

        return propertySpecialCondition;
    }
}
