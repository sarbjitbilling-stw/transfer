package uk.co.stwater.api.osgi.probate;

import uk.co.stwater.api.osgi.model.probate.ProbateDTO;
import uk.co.stwater.api.osgi.model.probate.ProbateRequest;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

public interface ProbateService {
    ProbateDTO probate(ProbateRequest probateRequest, String authToken) throws STWBusinessException, STWTechnicalException;
}
