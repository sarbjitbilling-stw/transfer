package uk.co.stwater.api.osgi.chor;

public interface ChorStateProcessor {

    enum ChorAction {
        ON, OF
    }

    enum Indicator {
        INDIVIDUAL("I"), BUSINESS("B");

        private String code;

        Indicator(String code) {
            this.code = code;
        }

        String getCode() {
            return code;
        }
    }

    enum PhoneType {
        HOME("H"), MOBILE("M"), WORK("W");

        private String code;

        PhoneType(String code) {
            this.code = code;
        }

        String getCode() {
            return code;
        }
    }

    boolean canProcess(ChorState chorState);

    void process(ChorContext chorContext);

}
