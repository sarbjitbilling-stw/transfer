package uk.co.stwater.api.osgi.probate;

public enum ProcessOutcomeEnum {
    PROBATE_CANCEL_ACTIVE_PAYMENT_PLANS(
            "probateCancelActivePaymentPlans",
            "Payment Plan cancelled successfully",
            "Unable to cancel payment plan, due to error message: %s",
            ""),

    PROBATE_CANCEL_DEMAND_DIRECT_DEBIT(
            "probateCancelDemandDirectDebit",
            "Demand direct debit cancelled successfully",
            "Unable to cancel demand direct debit, due to error message: %s",
            ""),

    DATASHARE_OFF_DECEASED_CUSTOMER("deceasedCustomerDatashareOff",
            "Removed datashare of deceased customer",
            "Unable to remove datashare of deceased customer, due to error message: %s",
            ""),

    REMOVE_TELEPHONE_DECEASED_CUSTOMER("removePhoneOfDeceasedCustomer",
            "Removed deceased customer's phone number",
            "Unable to remove deceased customer's phone number, due to error message: %s",
            ""),

    ADD_EXECUTOR_TELEPHONE_TO_DECEASED_CUSTOMER("addExecutorPhoneToDeceasedCustomer",
            "Added Executor Phone number",
            "Unable to add Executor Phone number, due to error message: %s",
            ""),

    DE_REGISTER_DECEASED_CUSTOMER("deRegisterDeceasedCustomer",
            "Removed paperless on deceased customer",
            "Unable to remove paperless on deceased customer, due to error message: %s",
            ""),

    REMOVE_DECEASED_ROLE("removeDeceasedRole",
            "Deceased customer %s removed from account on %s",
            "Unable to remove deceased from account role, due to error message: %s",
            ""),

    UPDATE_ROLE_INFO("updateRoleInfo",
            "Update role information",
            "Unable to update role information, due to error message: %s",
            ""),

    ADD_CALLER_AS_PRIMARY("addCallerAsPrimary",
            "Caller %s added as Primary from %s",
            "Unable to add caller as Primary to the account, due to error message: %s",
            ""),

    // @formatter:off
    END_PRIMARY_PSR_SPECIAL_CONDITIONS("endPrimaryPsrSpecialConditions", 
            "Ended Primary's PSR special conditions",
            "Unable to end Primary's PSR special conditions, due to error message: %s", 
            ""),
    // @formatter:on

    MODIFIED_CALLER_AS_PRIMARY("modifiedCallerAsPrimary",
            "Caller %s is modified as Primary to the account from %s",
            "Unable to modify caller as Primary to the account, due to error message: %s",
            ""),

    ADD_CALLER_AS_CO_PRIMARY("addCallerAsCoPrimary",
            "Caller is added as Co-Primary to the account",
            "Unable to add caller as Co-Primary to the account, due to error message: %s",
            ""),

    CREATE_BILL(
            "createBill",
            "Created bill successfully",
            "Unable to create bill, due to error message: %s",
            ""),

    UPDATE_CORRESPONDENCE_ADDRESS(
            "updateCorrespondenceAddress",
            "Update correspondence address",
            "Correspondence Address update unsuccessful, due to error message: %s",
            ""),

    PROBATE_ERROR(
            "probateError",
            "Probate journey successful",
            "Probate journey unsuccessful due to error message: %s",
            "");

    String stepId;
    String description;
    String alternateDescription;
    String errorMessage;
    boolean isForCallWrap;
    String path;

    ProcessOutcomeEnum(String stepId, String description, String errorMessage, String path) {
        this.stepId = stepId;
        this.description = description;
        this.errorMessage = errorMessage;
        this.path = path;
    }

    ProcessOutcomeEnum(final String stepId, final String description, final String errorMessage, final String path, final String alternateDescription, final boolean isForCallWrap) {
        this.stepId = stepId;
        this.description = description;
        this.errorMessage = errorMessage;
        this.path = path;
        this.alternateDescription = alternateDescription;
        this.isForCallWrap = isForCallWrap;
    }

    public String getAlternateDescription() {
        return alternateDescription;
    }

    public boolean isForCallWrap() {
        return isForCallWrap;
    }

    public String getDescription() {

        return description;
    }

    public String getStepId() {
        return stepId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getPath() {
        return path;
    }

}
