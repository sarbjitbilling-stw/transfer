package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.chor.ChorDTO;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.common.ContactDto;

public interface ChorService {


    ChorResponse moveHouseExisting(ChorRequest chorRequest, ContactDto contactDto, String username);

    ChorResponse moveHouseNew(ChorRequest chorRequest, ContactDto contactDto, String username, AccountBrand accountBrand);

    ChorResponse moveHouseNew(ChorRequest chorRequest, String username, AccountBrand accountBrand);

    ChorResponse createBill(ChorDTO chorDTO, String authToken);

    ChorRequest getChorDaysParameters();
}
