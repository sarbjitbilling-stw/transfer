package uk.co.stwater.api.osgi.chor;

/**
 * Created by tellis3 on 25/04/2017.
 */
public interface ChorConfigService {

    int getMonthsInPastEvidenceRequiredForNonBillPayer();

    int getMonthsInPastEvidenceRequiredForBillPayer();

    int getDaysInFutureChorAllowedFor();

    int getMonthsInPastBeforeMeterReadRequiredNewCustomer();

}
