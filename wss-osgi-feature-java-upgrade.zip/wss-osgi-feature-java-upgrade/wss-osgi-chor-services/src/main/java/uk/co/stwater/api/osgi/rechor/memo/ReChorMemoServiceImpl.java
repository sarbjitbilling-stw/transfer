package uk.co.stwater.api.osgi.rechor.memo;

import io.swagger.model.RefData;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.memo.RefDataDefinition;
import uk.co.stwater.api.osgi.model.rechor.ReChorOperation;
import uk.co.stwater.api.osgi.model.rechor.ReChorRequest;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.contactevent.patch.IIBPatchContactEventClient;
import uk.co.stwater.iib.client.api.contactevent.patch.IIBPatchContactEventRequest;
import uk.co.stwater.iib.client.api.contactevent.patch.IIBPatchContactEventResponse;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;

import static uk.co.stwater.api.osgi.rechor.ReChorUtil.getReverseBillMoveDateFormatted;

@Named
public class ReChorMemoServiceImpl implements ReChorMemoService {
    private static final String CONTACT_PACKAGE_ID = "131";
    private static final String CE_FLAG_N = "N";
    private static final String CE_FLAG_Y = "Y";
    private static final String MSG_MEMO_CONTENT = "Manual Homemove Adjustment done for %s";
    private static final String FIELD_RE_CHOR_OPERATION = "Operation";
    private static final String FIELD_POINT_OF_CONTACT = "Point of Contact left on caller account %S";

    private Logger log = LoggerFactory.getLogger(ReChorMemoService.class);

    @Inject
    @OsgiService
    private IIBPatchContactEventClient patchClient;

    @Override
    public boolean createReChorMemo(final ReChorMemoRequest reChorMemoRequest, final String authToken) {
        final IIBPatchContactEventRequest createContactRecordRequest = makeCreateContactRecordPatchRequest(
                reChorMemoRequest);
        final IIBPatchContactEventResponse createContactRecordResponse = patchClient
                .createContactRecord(createContactRecordRequest, authToken);

        if ((createContactRecordResponse == null) || (createContactRecordResponse.getContactId() == null)) {
            log.error("Unable to retrieve contact ID for existing occupier : {}", reChorMemoRequest);
            throw new STWBusinessException("Unable to retrieve contact ID for existing occupier",
                    Response.Status.NOT_FOUND);
        }
        final String contactId = createContactRecordResponse.getContactId();
        log.debug("initial patch request successful, obtained contactId {}",
                createContactRecordResponse.getContactId());

        // we should now have the contact id in the response - build the memo request
        final String notesDescription = buildMemoDescription(reChorMemoRequest);
        log.debug("memo notesDescription {}", notesDescription);
        final IIBPatchContactEventRequest createMemoRequest = makeMoveOutMemo(contactId, notesDescription);
        try {
            patchClient.setContactEventMemo(createMemoRequest, authToken);
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error("Setting notes description for contactId {} failed {}", contactId, e.getLocalizedMessage());
            throw e;
        }
        return true;
    }

    private IIBPatchContactEventRequest makeCreateContactRecordPatchRequest(
            final ReChorMemoRequest reChorMemoRequest) {
        final IIBPatchContactEventRequest request = new IIBPatchContactEventRequest();
        final ReChorRequest reChorRequest = reChorMemoRequest.getReChorRequest();
        request.setPropertyId(reChorRequest.getPropertyId());
        request.setAccountNumber(reChorRequest.getAccountNumber());
        request.setLegalEntityNo(Long.valueOf(reChorRequest.getLegalEntityId()));
        request.setContactPackageId(CONTACT_PACKAGE_ID);
        request.setComplaintReceivedFlag(CE_FLAG_N);
        request.setRepeatReqFlag(CE_FLAG_N);
        request.setSubstituteRespFlag(CE_FLAG_Y);
        request.setResolution(makeResolution());
        request.setRootCauseType(makeRootCauseType());
        request.setContactInitiatedBy(makeContactInitiatedRefData());
        request.setContactType(makeContactTypeRefData());
        request.setContactSubType(makeRefData(RefDataDefinition.CONTACT_SUB_TYPE));
        return request;
    }

    private IIBPatchContactEventRequest makeMoveOutMemo(
            final String contactId,
            final String memoContent) {
        final IIBPatchContactEventRequest request = new IIBPatchContactEventRequest();
        request.setNotesType(makeNotesTypeRefData());
        request.setContactId(contactId);
        request.setNotesDescription(memoContent);
        return request;
    }

    private String buildMemoDescription(
            final ReChorMemoRequest reChorMemoRequest) {
        log.debug("buildMemoDescription");

        final ReChorRequest reChorRequest = reChorMemoRequest.reChorRequest;
        final MemoBuilder builder = new MemoBuilder();
        builder
                .appendLine(String.format(MSG_MEMO_CONTENT, reChorMemoRequest.getPropertyAddress()))
                .appendDataField(FIELD_RE_CHOR_OPERATION, getOperationText(reChorRequest))
                .appendLine(String.format(FIELD_POINT_OF_CONTACT, reChorRequest.getCallerAccountNumber().getAccountNumber()));

        return builder.toString();
    }

    private String getOperationText(final ReChorRequest reChorRequest) {
        return String.format("%s dated %s", ReChorOperation.findByCode(reChorRequest.getOperation()).getDescription(), getReverseBillMoveDateFormatted(reChorRequest));

    }

    private RefData makeResolution() {
        return makeRefData(RefDataDefinition.RESOLUTION);
    }

    private RefData makeRootCauseType() {
        return makeRefData(RefDataDefinition.ROOT_CAUSE_TYPE);
    }

    private RefData makeNotesTypeRefData() {
        return makeRefData(RefDataDefinition.NOTES_TYPE);
    }

    private RefData makeContactTypeRefData() {
        return makeRefData(RefDataDefinition.CONTACT_TYPE);
    }

    private RefData makeContactInitiatedRefData() {
        return makeRefData(RefDataDefinition.CONTACT_INIT);
    }

    private RefData makeRefData(final RefDataDefinition refDataDef) {
        final RefData refData = new RefData();
        refData.setValue(refDataDef.getValue());
        refData.setCode(refDataDef.getCode());
        refData.setValueSet(refDataDef.getValueSet());
        return refData;
    }

    private static class MemoBuilder {
        private static final String LINE_BREAK = System.lineSeparator();
        private final StringBuilder builder = new StringBuilder();

        public MemoBuilder append(final String str) {
            builder.append(str);
            return this;
        }

        public MemoBuilder appendLine(final String str) {
            append(str);
            append(LINE_BREAK);
            return this;
        }

        public MemoBuilder appendDataField(final String field, final String value) {
            builder.append(field)
                    .append("  : ")
                    .append(value)
                    .append(LINE_BREAK);
            return this;
        }

        public String toString() {
            return builder.toString();
        }

    }
}
