package uk.co.stwater.api.osgi.rechor.operation;

import uk.co.stwater.api.osgi.model.ProcessOutcome;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.rechor.ReChorDTO;
import uk.co.stwater.api.osgi.model.rechor.ReChorRequest;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.util.List;
import java.util.Optional;

public interface BasicOperation {
    ReChorDTO performReChor(ReChorRequest reChorRequest, String authToken) throws STWBusinessException, STWTechnicalException;

    List<ProcessOutcome> reChorValidation(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome getBillsToReverse(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome reverseBills(final ReChorRequest reChorRequest, final String authToken);

    List<ProcessOutcome> performTargetValidation(final ReChorRequest reChorRequest, final String authToken);

    Optional<Property> getProperty(final ReChorRequest reChorRequest, final String authToken);

    String getPropertyAddress(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome paymentPlanCheck(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome cancelPaymentPlans(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome performChor(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome createMemo(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome getMeterRead(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome updateMeterRead(final ReChorRequest reChorRequest, final String authToken);

    ProcessOutcome getMeterRead(final ReChorRequest reChorRequest, final boolean isChorReadingType, final String authToken);

    ProcessOutcome updateMeterRead(final ReChorRequest reChorRequest, final boolean isChorReadingType, final String authToken);

    boolean isMeasuredProperty(final ReChorRequest reChorRequest, final String authToken);

    boolean isMeasuredProperty(final ReChorRequest reChorRequest, final boolean isCreateMoveIn, final String authToken);

}
