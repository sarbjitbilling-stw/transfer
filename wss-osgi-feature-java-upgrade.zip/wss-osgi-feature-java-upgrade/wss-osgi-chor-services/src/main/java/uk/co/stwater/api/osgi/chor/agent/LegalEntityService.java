package uk.co.stwater.api.osgi.chor.agent;

import uk.co.stwater.api.osgi.model.LegalEntityReuseRequest;
import uk.co.stwater.api.osgi.model.LegalEntityReuseResponse;

public interface LegalEntityService {

	LegalEntityReuseResponse checkLegalEntityReuse(LegalEntityReuseRequest legalEntityCheck, String authToken);

}
