package uk.co.stwater.api.osgi.chor.contact;

import uk.co.stwater.api.osgi.model.ContactTypes;

/**
 * Created by tellis3 on 03/05/2017.
 */
public class ContactType {

    private ContactTypes type;
    private boolean substantiveResponse;

    public ContactType(ContactTypes type, boolean substResponse) {
        this.type = type;
        this.substantiveResponse = substResponse;
    }

    public ContactTypes getType(){
        return type;
    }

    public boolean getSubstantiveResponse(){
        return substantiveResponse;
    }


}
