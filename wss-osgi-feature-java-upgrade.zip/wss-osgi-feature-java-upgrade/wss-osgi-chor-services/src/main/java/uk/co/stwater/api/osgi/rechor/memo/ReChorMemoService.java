package uk.co.stwater.api.osgi.rechor.memo;

public interface ReChorMemoService {
    boolean createReChorMemo(ReChorMemoRequest reChorMemoRequest, String authToken);
}
