package uk.co.stwater.api.osgi.chor;

/**
 * @author tellis3
 */

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.cm.ManagedService;
import uk.co.stwater.api.osgi.chor.ChorConfigServiceImpl;

import java.util.Dictionary;
import java.util.Hashtable;

import static uk.co.stwater.api.osgi.chor.ChorConfigServiceImpl.PID;

public class Activator implements BundleActivator {

    ServiceRegistration registration;

    public void start(BundleContext context) throws Exception {
        Dictionary properties = new Hashtable();
        properties.put("service.pid", PID);
        registration = context.registerService(ManagedService.class.getName(),
                new ChorConfigServiceImpl(), properties);
    }

    public void stop(BundleContext context) throws Exception {
        if (registration != null) {
            registration.unregister();
            registration = null;
        }
    }

}