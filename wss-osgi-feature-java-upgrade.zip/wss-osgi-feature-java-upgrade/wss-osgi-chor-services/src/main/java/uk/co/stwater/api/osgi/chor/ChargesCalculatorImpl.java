package uk.co.stwater.api.osgi.chor;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.bill.BillService;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.MoveCharges;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;

import javax.inject.Inject;
import javax.inject.Named;
import java.time.LocalDate;
import java.util.Optional;

@Named
public class ChargesCalculatorImpl implements ChargesCalculator {

    private static Logger logger = LoggerFactory.getLogger(ChargesCalculatorImpl.class);

    private static final String NON_ACTIVE_PAYMENT_PLAN_INDICATOR = "N";
    private static final String ASSESSED = "A";

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberService;

    @OsgiService
    @Inject
    private BillService billService;

    public void calculateChargesForExistingCustomer(ChorContext chorContext,
                                                    String authToken,
                                                    boolean isSingleSidedMoveOutOnlyInPast) {

        MoveRequestDetail movingInDetails = chorContext.getMovingInDetails();
        MoveRequestDetail movingOutDetails = chorContext.getMovingOutDetails();
        boolean billPayerAtMovingInAddress = chorContext.isBillPayerAtMovingInAddress();
        String username = chorContext.getUsername();
        ChorResponse chorResponse = chorContext.getChorResponse();
        Account movingOutAccount = chorContext.getMovingOutAccount();

        // chor was successful. Therefore, at the very least they must have moved out.
        // So we should do the move-out sim bill
        // if they are single-sided (move out) and not measured future OR if they are
        // double-sided unmeasured to unmeasured

        // if there is a move-in property, check whether it is assessed
        boolean doubleSided = ChorUtils.isDoubleSidedChor(movingInDetails, movingOutDetails,
                billPayerAtMovingInAddress);

        if (chorContext.getMovingOutDetails().isMeasured() && chorContext.getMovingOutDetails().isFuture()) {
            logger.debug("skipping sim bill");
        } else {
            doMoveOutSimBill(movingOutAccount, movingOutDetails, username, chorResponse);
            if (doubleSided) {
                if (movingOutAccount.getPaymentPlanIndicator() != null
                    && !NON_ACTIVE_PAYMENT_PLAN_INDICATOR.equalsIgnoreCase(movingOutAccount.getPaymentPlanIndicator())) {
                    logger.info("Customer had PP so creating new one");
                    chorResponse.setPaymentPlan(true);
                }
                if (isPropertyUnmeasured(chorContext.getMovingInDetails(), chorContext.getAccountNumber(), chorContext.getUsername())) {
                    calculateChargesForNewCustomer(chorContext.getMovingInDetails(), chorContext.getUsername(),
                            chorContext.getChorResponse(), movingOutAccount.getAccountNumber());
                }
            }
        }
    }

    @Override
    public void calculateChargesForNewCustomer(MoveRequestDetail movingInDetails,
                                               String username, ChorResponse chorResponse, TargetAccountNumber newAccountNumber) {
        // first, call for moving out account (if a forced-out account number was
        // returned from target)
        if (movingInDetails.isMeasured() && movingInDetails.isFuture()) {
            logger.debug("move in is future dated and measured - skipping sim bill");
        } else {
            if (chorResponse.getForcedOutAccountNumber() != null
                    && chorResponse.getForcedOutAccountNumber().getAccountNumberAsLong() != 0) {
                createBill(chorResponse.getForcedOutAccountNumber(), movingInDetails.getAddress(),
                        movingInDetails.getDate(), username).ifPresent(bill -> {
                    chorResponse.getChorProgressMonitor().getChorStateManager().forcedOutSimBill(ChorProgressMonitor.Progress.COMPLETED);
                    logger.info("Generated bill for forced out account {}", chorResponse.getForcedOutAccountNumber());
                });

            } else {
                logger.info("No forced out account so not generating bill");
                chorResponse.getChorProgressMonitor().getChorStateManager().forcedOutSimBill(ChorProgressMonitor.Progress.FAILED);
            }
            // now create bill for moving in account
            Optional<Bill> optionalBill = createBill(newAccountNumber, movingInDetails.getAddress(), null, username);
            if (optionalBill.isPresent()) {
                Bill bill = optionalBill.get();
                chorResponse.setMoveInCharges(MoveCharges.from(bill));
                logger.info("Generated bill for new account {}", newAccountNumber);
                chorResponse.getChorProgressMonitor().getChorStateManager().moveInSimBill(ChorProgressMonitor.Progress.COMPLETED);
            } else {
                chorResponse.getChorProgressMonitor().getChorStateManager().moveInSimBill(ChorProgressMonitor.Progress.FAILED);
            }
        }
    }

    private void doMoveOutSimBill(Account movingOutAccount, MoveRequestDetail movingOutDetails, String username, ChorResponse chorResponse) {
        Optional<Bill> optionalBill = createBill(movingOutAccount.getAccountNumber(), movingOutDetails.getAddress(), movingOutDetails.getDate(),
                username);
        if (optionalBill.isPresent()) {
            Bill bill = optionalBill.get();
            logger.info("Created bill for move out account");
            chorResponse.setMoveOutCharges(MoveCharges.from(bill));
            chorResponse.getChorProgressMonitor().getChorStateManager().moveOutSimBill(ChorProgressMonitor.Progress.COMPLETED);
        } else {
            chorResponse.getChorProgressMonitor().getChorStateManager().moveOutSimBill(ChorProgressMonitor.Progress.FAILED);
        }
    }

    private boolean isPropertyAssessed(MoveRequestDetail movingInDetails, TargetAccountNumber accountNumber,
                                       String authToken) {
        boolean isAssessed = false;
        Optional<Property> property = getProperty(accountNumber, movingInDetails.getAddress().getPropertyNum(),
                authToken);
        if (property.isPresent()) {
            isAssessed = property.get().getMeasuredIndicator() != null
                    && ASSESSED.equalsIgnoreCase(property.get().getMeasuredIndicator().getCode());
        }
        return isAssessed;
    }

    private Optional<Property> getProperty(TargetAccountNumber accountNumber, long propertyNum, String authToken) {
        return propertiesForAccountNumberService.getPropertiesForAccountNumber(accountNumber, authToken).stream()
                .filter(property -> property.getPropertyId().equals(String.valueOf(propertyNum))).findFirst();
    }

    private Optional<Bill> createBill(TargetAccountNumber accountNumber, Address address, LocalDate endDate,
                                      String authToken) {
        Optional<Bill> createdBill = Optional.empty();
        try {
            Bill bill = new Bill();
            bill.setAccountNumber(accountNumber.getAccountNumberWithCheckDigit());
            bill.setPropertyId(address.getPropertyNum() == null ? StringUtils.EMPTY : String.valueOf(address.getPropertyNum()));
            if (endDate == null) {
                bill = billService.validate(bill, authToken, BillService.VALIDATE_ACTION);
            } else {
                bill.setEndDate(endDate);
            }
            bill = billService.create(bill, authToken, BillService.CREATE_ACTION);
            createdBill = Optional.of(bill);
        } catch (STWBusinessException | STWTechnicalException e) {
            logger.error("Failed to create bill for {}", accountNumber, e);
        }
        return createdBill;
    }

    private boolean isPropertyUnmeasured(MoveRequestDetail moveRequestDetail, TargetAccountNumber targetAccountNumber, String authToken) {
        if (moveRequestDetail.getAddress() == null) {
            String msg = String.format("address is null from %s", moveRequestDetail.toString());
            throw new ChorException(msg);
        }
        return !(moveRequestDetail.isMeasured() || isPropertyAssessed(moveRequestDetail, targetAccountNumber, authToken));
    }

}
