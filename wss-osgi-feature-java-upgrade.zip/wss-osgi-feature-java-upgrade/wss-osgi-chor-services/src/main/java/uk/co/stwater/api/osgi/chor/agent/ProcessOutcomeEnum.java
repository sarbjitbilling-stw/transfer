package uk.co.stwater.api.osgi.chor.agent;

import org.apache.commons.lang3.StringUtils;

import uk.co.stwater.api.osgi.model.ProcessOutcome;

public enum ProcessOutcomeEnum {

    // @formatter:off
    STATUS_ACTIVATED("setServiceStatusActive", "Perform CHOR service in target for property %s",
            "Move In unsuccessful at %s due to error message %s",
            "/property/%s/active/"),
    STATUS_INACTIVE("setServiceStatusInactive", "Perform CHOR service in target for property %s",
            "Move Out unsuccessful at %s, due to error message %s", "/property/%s/inactive"),
    STATUS_INACTIVE_SUCCESS_CHECK_FAILED("setServiceStatusInactive", "Perform CHOR service in target for property %s",
            "Move Out unsuccessful at %s - immediate check of service turn off was not successful.", "/property/%s/inactive"),
    INTRODUCE_DELAY("introduceDelay", "Introduce Delay",
            "Introduce 1 Second Delay Between CHOR turn off and Online Bill - Error Occured", ""),
    CREATE_ROLE(
            "createAccountRole", "Created role for legal entity %s", "Unable to assign LE Number %s to account",
            "/role/%s"),
    PREFERRED_NAME("determinePreferredName", "Determine Preferred Name",
            "Unable to determine preferred name",
            "/account/preferredName"),
    CREATE_ACCOUNT("createAccount", "Create account and linked primary legal entity %s",
            "Unable to create new account number/Unable to reuse account number",
            "/account/%s"),
    FIRST_BILL("firstBillAccount", "Produce first bill",
            "Unable to ‘Produce First Bill’ – Unsuccessful due to Target error %s",
            "/account/{}"),
    FINAL_BILL("finalBillAccount", "Final Bill account",
            "Unable to ‘Produce Final Bill’ – Unsuccessful due to Target error %s",
            "/account/%s"), MEMO("CreateMemo", "CreateMemo",

            "Memo creation unsuccessful",
            ""),
    UPDATE_LEGAL_ENTITY("UpdateLegalEntity",
            "UpdateLegalEntity preferred name to %s", "",
            "/legalEntity/%s"),
    UPDATE_CORRESPONDENCE_ADDRESS(
            "updateCorrespondenceAddress",
            "Update correspondence address",
            "Correspondence Address update unsuccessful",
            "/account/address/%s"),

    ADD_LEGAL_ENTITY_SPECIAL_CONDITION(
            "addLegalEntitySpecialCondtion",
            "Add %s legal entity special condition",
            "Failed to add %s legal entity special condition",
            ""),
    END_LEGAL_ENTITY_SPECIAL_CONDITION(
            "endLegalEntitySpecialCondtion",
            "End %s legal entity special condition",
            "Failed to end %s legal entity special condition",
            ""),
    ADD_PROPERTY_SPECIAL_CONDITION(
            "addPropertySpecialCondtion",
            "Add %s property special condition",
            "Failed to add %s property special condition",
            ""),
    END_PROPERTY_SPECIAL_CONDITION(
            "endPropertySpecialCondtion",
            "End %s property special condition",
            "Failed to end %s property special condition",
            ""), 

    RECHOR_ERROR(
            "reChorError",
            "Re-CHOR successful",
            "Re-CHOR unsuccessful due to error message: %s",
            ""),

    RECHOR_NO_OF_BILLS_TO_REVERSE(
            "reChorNoOfBillsToReverse",
            "Number of bills to reverse is %s",
            "Unable to find number of bills to reverse, due to error message: %s",
            "",
            "",
            true),

    RECHOR_REVERSE_BILLS(
            "reChorReverseBills",
            "Reverse bills successful",
            "Reverse bills unsuccessful, due to error message: %s",
            "",
            "",
            true),

    RECHOR_VALIDATION(
            "reChorValidation",
            "Re-CHOR validation successful",
            "Re-CHOR validation unsuccessful, due to error message: %s",
            "",
            "",
            false),

    RECHOR_FETCH_PROPERTY(
            "reChorPropertyNotFound",
            "Property: %s found in account: %s",
            "Property: %s not found in account: %s",
            "",
            "",
            false),

    RECHOR_PROPERTY_IS_ACTIVE(
            "reChorPropertyIsActive",
            "Property is active",
            "Property is not active",
            "",
            "",
            false),

    RECHOR_PROPERTY_HAS_MOVED_OUT_DATE(
            "reChorPropertyHasMovedOutDate",
            "Property has a move-out date",
            "Property is not moved out",
            "",
            "",
            false),

    RECHOR_TARGET_VALIDATION(
            "reChorTargetValidation",
            "Validation successful",
            "Validation unsuccessful due to %s",
            "",
            "",
            true),

    RECHOR_VALIDATION_CHOR_WITH_CLAIM_FLAG(
            "chorWithClaimFlag",
            "",
            "Claim costs affecting Home Move. Please raise an AQ to the relevant team",
            "",
            "",
            true),

    RECHOR_VALIDATION_INVALID_DATE_FLAG(
            "invalidDateFlag",
            "",
            "Invalid date",
            ""),

    RECHOR_VALIDATION_MISSING_METER_FLAG(
            "missingMetersFlag",
            "",
            "Water Meter not yet assigned to the property. Complete required fields and raise AQ to the relevant team",
            ""),

    RECHOR_VALIDATION_SPL_CONDITION_BLOCKER_FLAG(
            "splConditionBlockerFlag",
            "Special Condition Blocker Flag",
            "%s",
            ""),

    RECHOR_ACTIVE_PAYMENT_PLANS(
            "reChorActivePaymentPlans",
            "Existing payment plan will be cancelled",
            "Unable to find payment plan details, due to error message: %s",
            "",
            "No payment plan to cancel",
            false
    ),

    RECHOR_CANCEL_ACTIVE_PAYMENT_PLANS(
            "reChorCancelActivePaymentPlans",
            "Payment Plan cancelled successfully",
            "Unable to cancel payment plan, due to error message: %s",
            ""),

    RECHOR_CREATE_MOVE_IN("createMoveIn",
            "Move-in on %s successful",
            "Unable to create Move-in for property %s in account %s, due to error message: %s",
            ""),

    RECHOR_CREATE_MOVE_OUT("createMoveOut",
            "Move-out on %s successful",
            "Unable to create Move-out for property: %s in account: %s, due to error message: %s",
            ""),


    RECHOR_REVERSE_MOVE_IN("reverseMoveIn",
            "Move-in on %s successfully reversed",
            "Unable to perform reverse Move-in for property: %s in account: %s, due to error message: %s",
            ""),

    RECHOR_REVERSE_MOVE_OUT("reverseMoveOut",
            "Move-out on %s successfully reversed",
            "Unable to perform Reverse Move-out for property: %s in account: %s, due to error message: %s",
            ""),
    RECHOR_CREATE_MEMO("createMemo",
            "Memo created successfully for account: %s",
            "Unable to create a memo for account: %s, due to error message: %s",
            ""),
    RECHOR_METER_READ_EXIST("meterReadExist",
            "Meter read of %s will be used for the %s",
            "",
            ""),

    RECHOR_NON_BILLABLE_METER_READ_EXIST("nonBillableMeterReadExist",
            "Meter read of %s on move date of %s will be made billable",
            "",
            ""),

    RECHOR_MAKE_NON_BILLABLE_TO_BILLABLE("makeNonBillableToBillable",
            "Read of %s on move date of %s made billable",
            "",
            ""),

    RECHOR_METER_READ_NOT_FOUND("noMeterReadExist",
            "No Meter read found for %s on %s",
            "Meter read search failed for %s on %s, due to error message: %s",
            ""),

    RECHOR_MAKE_BILLABLE_TO_NON_BILLABLE("makeBillableToNonBillable",
            "Read of %s on move date of %s made non-billable",
            "",
            ""),

    RECHOR_BILLABLE_READ_ALREADY_BILLED("billableReadIsAlreadyBilled",
            "Read of %s on date of %s will not be made non-billable as it is billed.",
            "",
            ""),

    RECHOR_BILLABLE_METER_READ_EXIST("billableMeterReadExist",
            "Read of %s on date of %s will be made non-billable",
            "",
            ""),

    RECHOR_BILLABLE_METER_READ_NOT_FOUND("noBillableMeterReadExist",
            "No read found on move date of %s to be made non-billable",
            "Meter read search failed for %s on %s, due to error message: %s",
            ""),

    RECHOR_CHAIN_ERROR(
            "reChorChainError",
            "Re-CHOR Chaining Successful",
            "Re-CHOR Chaining unsuccessful due to error message: %s",
            "");
    // @formatter:on

    String stepId;
    String description;
    String alternateDescription;
    String errorMessage;
    boolean isForCallWrap;
    String path;

    ProcessOutcomeEnum(String stepId, String description, String errorMessage, String path) {
        this.stepId = stepId;
        this.description = description;
        this.errorMessage = errorMessage;
        this.path = path;
    }

    ProcessOutcomeEnum(final String stepId, final String description, final String errorMessage, final String path, final String alternateDescription, final boolean isForCallWrap) {
        this.stepId = stepId;
        this.description = description;
        this.errorMessage = errorMessage;
        this.path = path;
        this.alternateDescription = alternateDescription;
        this.isForCallWrap = isForCallWrap;
    }

    public String getAlternateDescription() {
        return alternateDescription;
    }

    public boolean isForCallWrap() {
        return isForCallWrap;
    }

    public String getDescription() {

        return description;
    }

    public String getStepId() {
        return stepId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getPath() {
        return path;
    }

    public ProcessOutcome buildProcessOutcome(Object... descriptionParameters) {
        ProcessOutcome processOutcome = new ProcessOutcome();

        String formattedDescription = String.format(description, descriptionParameters);
        processOutcome.setDescription(formattedDescription);
        processOutcome.setStepId(stepId);
        processOutcome.setPath(StringUtils.isNotBlank(path) ? path : stepId);

        return processOutcome;
    }

}
