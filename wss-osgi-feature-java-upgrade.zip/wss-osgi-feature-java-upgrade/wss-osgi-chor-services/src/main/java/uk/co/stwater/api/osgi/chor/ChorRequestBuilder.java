package uk.co.stwater.api.osgi.chor;

import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;

import java.util.List;

public class ChorRequestBuilder {

    private ChorRequest chorRequest;

    public ChorRequestBuilder(TargetAccountNumber targetAccountNumber) {
        chorRequest = new ChorRequest();
        chorRequest.setAccountNumber(targetAccountNumber);
    }

    public ChorRequestBuilder withCustomer(Customer customer) {
        chorRequest.setCustomer(customer);
        return this;
    }

    public ChorRequestBuilder withMovingOut(MoveRequestDetail movingOutDetails) {
        chorRequest.setMovingOutDetails(movingOutDetails);
        return this;
    }

    public ChorRequestBuilder withMovingIn(MoveRequestDetail movingInDetails) {
        chorRequest.setMovingInDetails(movingInDetails);
        return this;
    }

    public ChorRequestBuilder withBillPayerAtMoveIn(boolean billPayer) {
        chorRequest.setBillPayerAtMovingInAddess(billPayer);
        return this;
    }

    public ChorRequestBuilder withNewResponsibilities(List<Customer> newResponsibilities) {
        chorRequest.setNewResponsibilities(newResponsibilities);
        return this;
    }

    public ChorRequestBuilder withNewAddressForPreviousCustomer(Address address) {
        chorRequest.setNewAddressPreviousCustomer(address);
        return this;
    }

    public ChorRequestBuilder withContactNumber(String contactNumber) {
        chorRequest.setContactNumber(contactNumber);
        return this;
    }

    public ChorRequestBuilder withEmail(String email) {
        chorRequest.setEmailAddress(email);
        return this;
    }

    public ChorRequest build() {
        return chorRequest;
    }

}
