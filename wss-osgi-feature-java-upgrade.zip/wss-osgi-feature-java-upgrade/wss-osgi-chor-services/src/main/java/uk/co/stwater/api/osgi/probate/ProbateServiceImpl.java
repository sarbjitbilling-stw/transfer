package uk.co.stwater.api.osgi.probate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.model.LegalEntitySpecialCondition;
import uk.co.stwater.api.bill.BillService;
import uk.co.stwater.api.osgi.chor.agent.UpdateGeneralCustomerInfoRequestTransformer;
import uk.co.stwater.api.osgi.model.AccountRole;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.PaperlessDetails;
import uk.co.stwater.api.osgi.model.ProcessOutcome;
import uk.co.stwater.api.osgi.model.ProcessOutcomeList;
import uk.co.stwater.api.osgi.model.RoleType;
import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.model.payment.directdebit.DirectDebitResponse;
import uk.co.stwater.api.osgi.model.probate.CallerType;
import uk.co.stwater.api.osgi.model.probate.ProbateDTO;
import uk.co.stwater.api.osgi.model.probate.ProbateRequest;
import uk.co.stwater.api.osgi.model.rechor.ReChorDTO;
import uk.co.stwater.api.osgi.model.rechor.ReChorOperation;
import uk.co.stwater.api.osgi.model.rechor.ReChorRequest;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.model.referencedata.RefDataDefinition;
import uk.co.stwater.api.osgi.model.referencedata.RefDataType;
import uk.co.stwater.api.osgi.rechor.operation.CreateMoveOut;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.payment.paymentplan.PaymentPlanService;
import uk.co.stwater.api.refdata.ReferenceDataService;
import uk.co.stwater.api.specialconditions.psr.PsrSpecialConditionService;
import uk.co.stwater.iib.client.api.accounts.patch.IIBPatchAccountClient;
import uk.co.stwater.iib.client.api.accounts.patch.IIBPatchAccountRequest;
import uk.co.stwater.iib.client.api.customer.get.CustomerResponse;
import uk.co.stwater.iib.client.api.customer.get.GetCustomerClient;
import uk.co.stwater.iib.client.api.customer.update.IIBUpdateCustomerClient;
import uk.co.stwater.iib.client.api.customer.update.IIBUpdateCustomerRequest;
import uk.co.stwater.iib.client.api.roles.create.IIBCreateRoleClient;
import uk.co.stwater.iib.client.api.roles.create.IIBCreateRoleRequest;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesForAccountClient;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesResponse;
import uk.co.stwater.iib.client.api.roles.patch.IIBPatchRoleClient;
import uk.co.stwater.iib.client.api.roles.patch.IIBPatchRoleRequest;
import uk.co.stwater.iib.client.api.roles.update.IIBUpdateRoleClient;
import uk.co.stwater.iib.client.api.roles.update.IIBUpdateRoleRequest;
import uk.co.stwater.iib.client.api.telephone.IIBTelephoneClientUtil;
import uk.co.stwater.iib.client.api.telephone.create.IIBCreateTelephoneClient;
import uk.co.stwater.iib.client.api.telephone.create.IIBCreateTelephoneRequest;

@Named
public class ProbateServiceImpl implements ProbateService {

    private static final String PAYMENT_PLAN_TERMINATION_REASON_SP_TERMINATED = "T";  // Customer has moved property
    private final String DATE_FORMATTER = "d MMM yyyy";
    private final String WHITESPACE = " ";

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    @OsgiService
    private PaymentPlanService paymentPlanService;

    @Inject
    @OsgiService
    private GetCustomerClient iibGetCustomerclient;

    @Inject
    @OsgiService
    private IIBUpdateCustomerClient iibUpdateCustomerClient;

    @Inject
    private UpdateGeneralCustomerInfoRequestTransformer updateGeneralCustomerInfoRequestTransformer;

    @Inject
    @OsgiService
    private IIBTelephoneClientUtil iibTelephoneClientUtil;

    @Inject
    @OsgiService
    private IIBUpdateRoleClient iibUpdateRoleClient;

    @Inject
    @OsgiService
    private IIBPatchRoleClient iibPatchRoleClient;

    @Inject
    @OsgiService
    private IIBGetRolesForAccountClient iibGetRolesForAccountClient;

    @Inject
    @OsgiService
    private IIBCreateRoleClient iibCreateRoleClient;

    @Inject
    private IIBUpdateRoleRequestTransformer iibUpdateRoleRequestTransformer;

    @Inject
    private IIBPatchRoleRequestTransformer iibPatchRoleRequestTransformer;

    @Inject
    private IIBCreateRoleRequestTransformer iibCreateRoleRequestTransformer;

    @Inject
    private CreateMoveOut createMoveOut;

    @OsgiService
    @Inject
    private BillService billService;

    @Inject
    @OsgiService
    private IIBPatchAccountClient iibPatchAccountClient;

    @Inject
    @OsgiService
    private IIBCreateTelephoneClient iibCreateTelephoneClient;

    @Inject
    @OsgiService
    private ReferenceDataService referenceDataService;

    @Inject
    @OsgiService
    private PsrSpecialConditionService psrSpecialConditionService;

    @Override
    public ProbateDTO probate(final ProbateRequest probateRequest, final String authToken)
            throws STWBusinessException, STWTechnicalException {
        ProbateDTO probateDTO = new ProbateDTO();
        probateDTO.setProbateRequest(probateRequest);
        ProcessOutcomeList processOutComeList = new ProcessOutcomeList();
        probateDTO.setOutcome(processOutComeList);
        ProcessOutcome outcome;
        List<ProcessOutcome> outcomeList;
        try {
            validateRequest(probateRequest);

            if (probateRequest.getHomeMove() != null &&
                    probateRequest.getHomeMove().getOutgoingMoveDetails() != null &&
                    probateRequest.getHomeMove().getOutgoingMoveDetails().getMoveDate() != null) {
                ReChorDTO reChorDTO = createMoveOut.performReChor(constructReChorRequest(probateRequest), authToken);
                outcomeList = reChorDTO.getOutcome().getItems();
                processOutComeList.addOutcomes(outcomeList);

                if (processOutComeList.hasErrors() || processOutComeList.hasWarnings()) { // if no meter read, program will raise warning, therefore reChor/HomeMove is not completed yet.
                    return probateDTO;
                }

                outcomeList = cancelDemandDirectDebit(probateRequest, authToken);
                processOutComeList.addOutcomes(outcomeList);

                outcome = createBill(probateRequest, authToken);
                processOutComeList.addOutcome(outcome);

            } else {
                if (paymentPlanService.hasActivePaymentPlans(probateRequest.getAccountNumber(), authToken)) {
                    outcome = cancelPaymentPlans(probateRequest, authToken);
                    processOutComeList.addOutcome(outcome);
                } else {
                    outcomeList = cancelDemandDirectDebit(probateRequest, authToken);
                    processOutComeList.addOutcomes(outcomeList);
                }
            }

            outcome = updateDeceasedCustomer(probateRequest, authToken);
            processOutComeList.addOutcome(outcome);

            outcome = deleteDeceasedTelephone(probateRequest, authToken);
            processOutComeList.addOutcome(outcome);

            if (probateRequest.isCallerExecutor()) {
                outcome = addTelephoneToDeceasedCustomer(probateRequest, authToken);
                processOutComeList.addOutcome(outcome);
            }

            outcome = deregisterPaperlessOfDeceased(probateRequest, authToken);
            processOutComeList.addOutcome(outcome);

            if (probateRequest.isCallerExecutor()) {
                outcome = updateCorrespondenceAddress(probateRequest, authToken);
                processOutComeList.addOutcome(outcome);
            } else {
                outcomeList = updateRoleInfo(probateRequest, authToken);
                processOutComeList.addOutcomes(outcomeList);
            }

        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome = new ProcessOutcome();
            outcome.setStepId(ProcessOutcomeEnum.PROBATE_ERROR.getStepId());
            outcome.setDescription(ProcessOutcomeEnum.PROBATE_ERROR.getDescription());
            String errorMessage = String.format(ProcessOutcomeEnum.PROBATE_ERROR.getErrorMessage(),
                    e.getMessage());
            outcome.setErrorDescription(errorMessage);
            processOutComeList.addOutcome(outcome);

        }
        return probateDTO;
    }

    private ProcessOutcome createBill(final ProbateRequest probateRequest, String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.CREATE_BILL.getStepId());
        try {
            Bill bill = new Bill();
            bill.setAccountNumber(probateRequest.getAccountNumber().getAccountNumberWithCheckDigit());
            bill.setPropertyId(probateRequest.getHomeMove().getProperty().getPropertyId());
            bill.setEndDate(probateRequest.getHomeMove().getOutgoingMoveDetails().getMoveDate());
            billService.create(bill, authToken, "create", true);
            outcome.setDescription(ProcessOutcomeEnum.CREATE_BILL.getDescription());
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error("Probate:Failed to create bill for {}",
                    probateRequest.getAccountNumber().getAccountNumber(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.CREATE_BILL.getErrorMessage(),
                    e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return outcome;
    }

    private ReChorRequest constructReChorRequest(final ProbateRequest probateRequest) {
        ReChorRequest reChorRequest = new ReChorRequest();
        reChorRequest.setOperation(ReChorOperation.CREATE_MOVE_OUT.getCode());
        reChorRequest.setAccountNumber(probateRequest.getAccountNumber());
        reChorRequest.setCallerAccountNumber(probateRequest.getAccountNumber());
        reChorRequest.setLegalEntityId(String.valueOf(probateRequest.getDeceasedCustomer().getLegalEntityId()));
        reChorRequest.setPropertyId(Long.valueOf(probateRequest.getHomeMove().getProperty().getPropertyId()));
        reChorRequest.setUpdate(true);
        reChorRequest.setNewMoveOutDate(probateRequest.getHomeMove().getOutgoingMoveDetails().getMoveDate());
        reChorRequest.setChaining(false);
        return reChorRequest;
    }

    private Optional<IIBGetRolesResponse> findRole(final AccountRole accountRole,
                                                   final List<IIBGetRolesResponse> iibGetRolesResponses) {
        return iibGetRolesResponses.stream()
                .filter(iibGetRolesResponse -> iibGetRolesResponse.getLegalEntityNo().equals(accountRole.getLegalEntityId()))
                .findFirst();
    }

    private ProcessOutcome deregisterPaperlessOfDeceased(final ProbateRequest probateRequest, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        try {
            List<IIBGetRolesResponse> iibGetRolesResponses =
                    iibGetRolesForAccountClient.getCurrentAndFutureActiveRolesForAccount(probateRequest.getAccountNumber(), authToken);
            Optional<IIBGetRolesResponse> deceasedOptional = findRole(probateRequest.getDeceasedCustomer(), iibGetRolesResponses);
            if (deceasedOptional.isPresent()) {
                IIBGetRolesResponse deceasedIIBGetRolesResponse = deceasedOptional.get();
                if (deceasedIIBGetRolesResponse.getWebSelfServe() != null && deceasedIIBGetRolesResponse.getWebSelfServe().getPaperless() != null && deceasedIIBGetRolesResponse.getWebSelfServe().getPaperless()) {
                    PaperlessDetails paperlessDetails = deceasedIIBGetRolesResponse.getWebSelfServe();
                    paperlessDetails.setPaperless(false);
                    LocalDate roleEndDate = probateRequest.getDeceasedDate() != null ?
                            probateRequest.getDeceasedDate() : probateRequest.getHomeMove().getOutgoingMoveDetails().getMoveDate();
                    paperlessDetails.setPaperlessStatusDate(LocalDateTime.from(roleEndDate.atStartOfDay()));
                    IIBPatchRoleRequest deceasedIIBPatchRoleRequest =
                            (IIBPatchRoleRequest) iibPatchRoleRequestTransformer.transform(deceasedIIBGetRolesResponse);
                    deceasedIIBPatchRoleRequest.setAcccountNumber(probateRequest.getAccountNumber());
                    iibPatchRoleClient.patchRole(deceasedIIBPatchRoleRequest, authToken);
                    outcome.setStepId(ProcessOutcomeEnum.DE_REGISTER_DECEASED_CUSTOMER.getStepId());
                    outcome.setDescription(ProcessOutcomeEnum.DE_REGISTER_DECEASED_CUSTOMER.getDescription());
                }
            }
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setStepId(ProcessOutcomeEnum.DE_REGISTER_DECEASED_CUSTOMER.getStepId());
            String errorMessage = String.format(ProcessOutcomeEnum.DE_REGISTER_DECEASED_CUSTOMER.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return outcome;
    }

    private List<ProcessOutcome> updateRoleInfo(final ProbateRequest probateRequest, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        List<ProcessOutcome> processOutcomeList = new ArrayList<>();

        try {
            List<IIBGetRolesResponse> iibGetRolesResponses =
                    iibGetRolesForAccountClient.getCurrentAndFutureActiveRolesForAccount(probateRequest.getAccountNumber(), authToken);
            boolean isDeceasedCurrentPrimary = probateRequest.getDeceasedCustomer().getRole().getCode().equals(RoleType.PRIMARY.getValue());
            if (isDeceasedCurrentPrimary) {
                processOutcomeList = updateRoleInfoWhenPrimaryDeceased(probateRequest, iibGetRolesResponses, authToken);
            } else {
                processOutcomeList = updateRoleInfoWhenCoPrimaryDeceased(probateRequest, iibGetRolesResponses, authToken);
            }
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setStepId(ProcessOutcomeEnum.UPDATE_ROLE_INFO.getStepId());
            String errorMessage = String.format(ProcessOutcomeEnum.UPDATE_ROLE_INFO.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return processOutcomeList;
    }

    private List<ProcessOutcome> updateRoleInfoWhenPrimaryDeceased(final ProbateRequest probateRequest,
                                                                   final List<IIBGetRolesResponse> iibGetRolesResponses, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        List<ProcessOutcome> processOutcomeList = new ArrayList<>();

        try {
            // A primary role cannot be ended if it has existing special conditions
            List<LegalEntitySpecialCondition> endedSpecialConditions = psrSpecialConditionService.end(
                    probateRequest.getAccountNumber(), probateRequest.getDeceasedCustomer().getLegalEntityId(),
                    probateRequest.getDeceasedDate(), authToken);
            int numberOfEndedSpecialConditions = endedSpecialConditions != null ? endedSpecialConditions.size() : 0;
            log.info("Ended {} PSR special conditions for accountNumber={} legalEntityNo={}",
                    numberOfEndedSpecialConditions, probateRequest.getAccountNumber(),
                    probateRequest.getDeceasedCustomer().getLegalEntityId());
            if (numberOfEndedSpecialConditions > 0) {
                ProcessOutcome endPsrConditionsOutcome = new ProcessOutcome();
                endPsrConditionsOutcome.setStepId(ProcessOutcomeEnum.END_PRIMARY_PSR_SPECIAL_CONDITIONS.getStepId());
                String endPsrConditionsDescription = String
                        .format(ProcessOutcomeEnum.END_PRIMARY_PSR_SPECIAL_CONDITIONS.getDescription());
                endPsrConditionsOutcome.setDescription(endPsrConditionsDescription);
                processOutcomeList.add(endPsrConditionsOutcome);
            }

            Optional<IIBGetRolesResponse> callerOptional = findRole(probateRequest.getCaller(), iibGetRolesResponses);
            //Add caller as Primary, this will auto remove/end Deceased Primary
            if (callerOptional.isPresent()) {
                IIBGetRolesResponse callerIIBGetRolesResponse = callerOptional.get();
                IIBUpdateRoleRequest callerIIBUpdateRoleRequest =
                        (IIBUpdateRoleRequest) iibUpdateRoleRequestTransformer.transform(callerIIBGetRolesResponse);
                callerIIBUpdateRoleRequest.setRole(makePrimaryRole()); // set as Primary
                callerIIBUpdateRoleRequest.setAcccountNumber(probateRequest.getAccountNumber());
                callerIIBUpdateRoleRequest.setStartDate(probateRequest.getDeceasedDate());
                iibUpdateRoleClient.updateRole(callerIIBUpdateRoleRequest, authToken);

                outcome = new ProcessOutcome();
                outcome.setStepId(ProcessOutcomeEnum.MODIFIED_CALLER_AS_PRIMARY.getStepId());
                String description = String.format(ProcessOutcomeEnum.MODIFIED_CALLER_AS_PRIMARY.getDescription(),
                        constructCombinedName(callerIIBGetRolesResponse, authToken),
                        formatDate(probateRequest.getDeceasedDate()));
                outcome.setDescription(description);
                processOutcomeList.add(outcome);

            } else {
                AccountRole callerAccountRole = probateRequest.getCaller();
                IIBCreateRoleRequest callerIIBCreateRoleRequest =
                        (IIBCreateRoleRequest) iibCreateRoleRequestTransformer.transform(callerAccountRole);
                callerIIBCreateRoleRequest.setRole(makePrimaryRole()); // set as Primary
                callerIIBCreateRoleRequest.setAcccountNumber(probateRequest.getAccountNumber());
                callerIIBCreateRoleRequest.setStartDate(probateRequest.getDeceasedDate());
                Long roleId = iibCreateRoleClient.createRole(callerIIBCreateRoleRequest, authToken);
                callerAccountRole.setAccountRoleId(roleId); // is this required?

                outcome = new ProcessOutcome();
                outcome.setStepId(ProcessOutcomeEnum.ADD_CALLER_AS_PRIMARY.getStepId());
                String description = String.format(ProcessOutcomeEnum.ADD_CALLER_AS_PRIMARY.getDescription(),
                        constructCombinedName(callerAccountRole.getCustomer(), authToken),
                        formatDate(probateRequest.getDeceasedDate()));
                outcome.setDescription(description);
                processOutcomeList.add(outcome);
            }

            processOutcomeList.add(constructRemoveDeceasedRoleOutcome(probateRequest.getDeceasedCustomer().getCustomer(),
                    probateRequest.getDeceasedDate(), authToken));

        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setStepId(ProcessOutcomeEnum.UPDATE_ROLE_INFO.getStepId());
            String errorMessage = String.format(ProcessOutcomeEnum.UPDATE_ROLE_INFO.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
            processOutcomeList.add(outcome);
        }
        return processOutcomeList;
    }

    private List<ProcessOutcome> updateRoleInfoWhenCoPrimaryDeceased(final ProbateRequest probateRequest,
                                                                     final List<IIBGetRolesResponse> iibGetRolesResponses, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        List<ProcessOutcome> processOutcomeList = new ArrayList<>();

        try {
            Optional<IIBGetRolesResponse> deceasedOptional = findRole(probateRequest.getDeceasedCustomer(), iibGetRolesResponses);
            if (deceasedOptional.isPresent()) {
                IIBGetRolesResponse deceasedIIBGetRolesResponse = deceasedOptional.get();
                LocalDate roleEndDate = probateRequest.getDeceasedDate() != null ?
                        probateRequest.getDeceasedDate() :
                        probateRequest.getHomeMove().getOutgoingMoveDetails().getMoveDate();
                deceasedIIBGetRolesResponse.setEndDate(roleEndDate);
                IIBUpdateRoleRequest deceasedIIBUpdateRoleRequest =
                        (IIBUpdateRoleRequest) iibUpdateRoleRequestTransformer.transform(deceasedIIBGetRolesResponse);
                deceasedIIBUpdateRoleRequest.setAcccountNumber(probateRequest.getAccountNumber());
                iibUpdateRoleClient.updateRole(deceasedIIBUpdateRoleRequest, authToken);

                processOutcomeList.add(constructRemoveDeceasedRoleOutcome(probateRequest.getDeceasedCustomer().getCustomer(),
                        probateRequest.getDeceasedDate(), authToken));
            }

            if (probateRequest.getCallerType().equalsIgnoreCase(CallerType.NEW_CO_PRIMARY.getCode())) {
                AccountRole callerAccountRole = probateRequest.getCaller();
                IIBCreateRoleRequest callerIIBCreateRoleRequest = (IIBCreateRoleRequest) iibCreateRoleRequestTransformer.transform(callerAccountRole);
                callerIIBCreateRoleRequest.setRole(makeCoPrimaryRole()); // set as Co-Primary
                callerIIBCreateRoleRequest.setAcccountNumber(probateRequest.getAccountNumber());
                Long roleId = iibCreateRoleClient.createRole(callerIIBCreateRoleRequest, authToken);
                callerAccountRole.setAccountRoleId(roleId); // is this required?

                outcome = new ProcessOutcome();
                outcome.setStepId(ProcessOutcomeEnum.ADD_CALLER_AS_CO_PRIMARY.getStepId());
                outcome.setDescription(ProcessOutcomeEnum.ADD_CALLER_AS_CO_PRIMARY.getDescription());
                processOutcomeList.add(outcome);
            }

        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setStepId(ProcessOutcomeEnum.UPDATE_ROLE_INFO.getStepId());
            String errorMessage = String.format(ProcessOutcomeEnum.UPDATE_ROLE_INFO.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
            processOutcomeList.add(outcome);
        }
        return processOutcomeList;
    }

    private ProcessOutcome deleteDeceasedTelephone(final ProbateRequest probateRequest, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.REMOVE_TELEPHONE_DECEASED_CUSTOMER.getStepId());
        try {
            iibTelephoneClientUtil.deleteCustomerTelephones(probateRequest.getDeceasedCustomer().getLegalEntityId(), authToken);
            outcome.setDescription(ProcessOutcomeEnum.REMOVE_TELEPHONE_DECEASED_CUSTOMER.getDescription());
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.REMOVE_TELEPHONE_DECEASED_CUSTOMER.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return outcome;
    }

    private ProcessOutcome addTelephoneToDeceasedCustomer(final ProbateRequest probateRequest, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.ADD_EXECUTOR_TELEPHONE_TO_DECEASED_CUSTOMER.getStepId());
        try {

            IIBCreateTelephoneRequest iibCreateTelephoneRequest =
                    new IIBCreateTelephoneRequest(
                            probateRequest.getExecutorPhoneNumber(),
                            String.valueOf(probateRequest.getDeceasedCustomer().getLegalEntityId()),
                            makeExecutorTelLocation(), makeVoiceTelephoneType(),
                            true);
            iibCreateTelephoneClient.createTelephone(iibCreateTelephoneRequest, authToken);
            outcome.setDescription(ProcessOutcomeEnum.ADD_EXECUTOR_TELEPHONE_TO_DECEASED_CUSTOMER.getDescription());
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.ADD_EXECUTOR_TELEPHONE_TO_DECEASED_CUSTOMER.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return outcome;
    }

    private ProcessOutcome updateDeceasedCustomer(final ProbateRequest probateRequest, final String authToken) {
        AccountRole accountRole = probateRequest.getDeceasedCustomer();
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setDescription(ProcessOutcomeEnum.DATASHARE_OFF_DECEASED_CUSTOMER.getDescription());
        outcome.setStepId(ProcessOutcomeEnum.DATASHARE_OFF_DECEASED_CUSTOMER.getStepId());

        try {

            Optional<CustomerResponse> customerResponse = iibGetCustomerclient
                    .getCustomer(accountRole.getLegalEntityId());

            if (customerResponse.isPresent()) {
                CustomerResponse customer = customerResponse.get();
                IIBUpdateCustomerRequest request = (IIBUpdateCustomerRequest) updateGeneralCustomerInfoRequestTransformer
                        .transform(customer);

                request.setDataShareIndicator(makeNoShareIndicator());
                request.setDataShareIndicatorId(customer.getDataShareIndicatorId());
                request.setDataShareIndicatorVersion(customer.getDataShareIndicatorVersion());

                request.setDataShareDateNotified(LocalDate.now());
                request.setDataShareDateNotifiedId(customer.getDataShareDateNotifiedId());
                request.setDataShareDateNotifiedVersion(customer.getDataShareDateNotifiedVersion());

                request.setDeathDate(probateRequest.getDeceasedDate());
                request.setDeathDateId(customer.getDeathDateId());
                request.setDeathDateVersion(customer.getDeathDateVersion());

                if (probateRequest.isCallerExecutor()) {
                    request.setPreferredName(probateRequest.getExecutorCombinedName());
                    request.setDataShareSource(makeInformationRequestsDataShareSource());
                    request.setDataShareSourceId(customer.getDataShareSourceId());
                    request.setDataShareSourceVersion(customer.getDataShareSourceVersion());
                } else {
                    request.setDataShareSource(makeBlankDataShareSource());
                    request.setDataShareSourceId(customer.getDataShareSourceId());
                    request.setDataShareSourceVersion(customer.getDataShareSourceVersion());
                }

                iibUpdateCustomerClient.updateCustomer(request, authToken);
            }
        } catch (STWBusinessException | STWTechnicalException e) {
            String errorMessage = String.format(ProcessOutcomeEnum.DATASHARE_OFF_DECEASED_CUSTOMER.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
            log.error(e.getMessage(), e);
        }
        return outcome;
    }

    private ProcessOutcome updateCorrespondenceAddress(final ProbateRequest probateRequest, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setDescription(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getDescription());
        outcome.setStepId(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getStepId());

        try {
            IIBPatchAccountRequest request = new IIBPatchAccountRequest();
            request.setAccountNumber(probateRequest.getAccountNumber());
            request.setRoleId(String.valueOf(probateRequest.getDeceasedCustomer().getAccountRoleId()));
            request.setBillingAddress(probateRequest.getBillAddress());
            iibPatchAccountClient.patchAccount(request, authToken);

        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            String errorMessage = String.format(ProcessOutcomeEnum.UPDATE_CORRESPONDENCE_ADDRESS.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return outcome;

    }

    private ProcessOutcome cancelPaymentPlans(final ProbateRequest probateRequest, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        try {
            outcome.setStepId(ProcessOutcomeEnum.PROBATE_CANCEL_ACTIVE_PAYMENT_PLANS.getStepId());
            paymentPlanService.findAndDeleteExistingPaymentPlans(probateRequest.getAccountNumber(), authToken, PAYMENT_PLAN_TERMINATION_REASON_SP_TERMINATED);
            outcome.setDescription(ProcessOutcomeEnum.PROBATE_CANCEL_ACTIVE_PAYMENT_PLANS.getDescription());
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setStepId(ProcessOutcomeEnum.PROBATE_CANCEL_ACTIVE_PAYMENT_PLANS.getStepId());
            String errorMessage = String.format(ProcessOutcomeEnum.PROBATE_CANCEL_ACTIVE_PAYMENT_PLANS.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
        }
        return outcome;
    }

    private List<ProcessOutcome> cancelDemandDirectDebit(final ProbateRequest probateRequest, final String authToken) {
        List<ProcessOutcome> processOutcomeList = new ArrayList<>();
        ProcessOutcome outcome = new ProcessOutcome();
        try {
            if (paymentPlanService.isOnDemandDirectDebit(probateRequest.getAccountNumber())) {
                DirectDebitResponse directDebitResponse =
                        paymentPlanService.deactivateBankAccount(probateRequest.getAccountNumber(), authToken);

                if (CollectionUtils.isNotEmpty(directDebitResponse.getWarnings())) {
                    processOutcomeList.addAll(extractWarnings(directDebitResponse));
                } else {
                    outcome.setStepId(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getStepId());
                    outcome.setDescription(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getDescription());
                    processOutcomeList.add(outcome);
                }

            }
        } catch (STWBusinessException | STWTechnicalException e) {
            log.error(e.getMessage(), e);
            outcome.setStepId(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getStepId());
            String errorMessage = String.format(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getErrorMessage(), e.getMessage());
            outcome.setErrorDescription(errorMessage);
            processOutcomeList.add(outcome);
        }
        return processOutcomeList;
    }

    private List<ProcessOutcome> extractWarnings(final DirectDebitResponse directDebitResponse) {
        return directDebitResponse.getWarnings().stream().map(warningDTO -> {
            ProcessOutcome outcome = new ProcessOutcome();
            outcome.setStepId(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getStepId());
            outcome.setDescription(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getDescription());
            String warningMessage =
                    String.format(ProcessOutcomeEnum.PROBATE_CANCEL_DEMAND_DIRECT_DEBIT.getErrorMessage(), warningDTO.getDescription());
            outcome.setWarningDescription(warningMessage);
            outcome.setTargetReturnCode(warningDTO.getTargetReturnCode());
            outcome.setTargetReasonText(warningDTO.getTargetReasonText());
            return outcome;
        }).collect(Collectors.toList());
    }

    private void validateRequest(final ProbateRequest probateRequest) {
        if (probateRequest.getAccountNumber() == null) {
            throw new STWBusinessException("Invalid Probate Request : Invalid Account Number");
        }

        if (probateRequest.getDeceasedCustomer() == null) {
            throw new STWBusinessException("Invalid Probate Request : Invalid Deceased customer details");
        }
    }

    private String formatDate(LocalDate date) {
        return date != null ? date.format(DateTimeFormatter.ofPattern(DATE_FORMATTER)) : "";
    }

    private String constructCombinedName(final String title, final String firstName, final String lastName) {
        StringBuilder combinedName = new StringBuilder();
        combinedName.append(title);
        if (StringUtils.isNotEmpty(title)) {
            combinedName.append(WHITESPACE);
        }
        combinedName.append(firstName);
        if (StringUtils.isNotEmpty(firstName)) {
            combinedName.append(WHITESPACE);
        }
        combinedName.append(lastName);
        return combinedName.toString();
    }

    private String constructCombinedName(final Customer customer, final String authToken) {
        if (customer == null) {
            return "";
        }

        String title = customer.getTitle();
        if (title == null) {
            title = createTitle(customer.getTitleRef(), authToken);
        }
        return constructCombinedName(StringUtils.defaultIfEmpty(title, ""),
                StringUtils.defaultIfEmpty(customer.getFirstName(), ""),
                customer.getLastName());
    }

    private String getRefDataTitleDescription(String titleCode, String authToken) {
        return referenceDataService.getRefDataDesc(RefDataType.TITLE, titleCode, authToken);
    }

    private String createTitle(final RefData refDataTitle, final String authToken) {
        String title = null;
        if (refDataTitle != null) {
            title = refDataTitle.getValue();
            if (title == null && refDataTitle.getCode() != null) {
                title = getRefDataTitleDescription(refDataTitle.getCode(), authToken);
            }
        }
        return StringUtils.defaultIfEmpty(title, "");
    }

    private String constructCombinedName(final IIBGetRolesResponse iibGetRolesResponse, final String authToken) {
        if (iibGetRolesResponse == null) {
            return "";
        }

        return constructCombinedName(createTitle(iibGetRolesResponse.getTitle(), authToken),
                StringUtils.defaultIfEmpty(iibGetRolesResponse.getFirstName(), ""),
                iibGetRolesResponse.getLastName());
    }


    private ProcessOutcome constructRemoveDeceasedRoleOutcome(final Customer customer, final LocalDate deceasedDate, final String authToken) {
        ProcessOutcome outcome = new ProcessOutcome();
        outcome.setStepId(ProcessOutcomeEnum.REMOVE_DECEASED_ROLE.getStepId());
        String description = String.format(ProcessOutcomeEnum.REMOVE_DECEASED_ROLE.getDescription(),
                constructCombinedName(customer, authToken),
                formatDate(deceasedDate));
        outcome.setDescription(description);
        return outcome;
    }

    private RefData makeRefData(final RefDataDefinition refDataDef) {
        final RefData refData = new RefData();
        refData.setValue(refDataDef.getValue());
        refData.setCode(refDataDef.getCode());
        refData.setSet(refDataDef.getValueSet());
        return refData;
    }

    private RefData makeVoiceTelephoneType() {
        return makeRefData(RefDataDefinition.VOICE_TELEPHONE_TYPE);
    }

    private RefData makeExecutorTelLocation() {
        return makeRefData(RefDataDefinition.EXECUTOR_TEL_LOCATION);
    }

    private RefData makeNoShareIndicator() {
        return makeRefData(RefDataDefinition.DATA_SHARE_INDICATOR_NO);
    }

    private RefData makeBlankDataShareSource() {
        return makeRefData(RefDataDefinition.DATA_SHARE_SOURCE_BLANK);
    }

    private RefData makeInformationRequestsDataShareSource() {
        return makeRefData(RefDataDefinition.DATA_SHARE_SOURCE_INFORMATION_REQUESTS);
    }

    private RefData makePrimaryRole() {
        return makeRefData(RefDataDefinition.PRIMARY_ROLE);
    }

    private RefData makeCoPrimaryRole() {
        return makeRefData(RefDataDefinition.CO_PRIMARY_ROLE);
    }

}
