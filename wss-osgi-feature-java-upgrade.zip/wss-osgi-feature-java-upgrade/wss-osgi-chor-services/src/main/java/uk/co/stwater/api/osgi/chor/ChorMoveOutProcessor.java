package uk.co.stwater.api.osgi.chor;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Brand;
import uk.co.stwater.api.osgi.model.Customer;
import uk.co.stwater.api.osgi.model.SpecialCondition;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.util.STWBaseException;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionChannel;
import uk.co.stwater.targetconnector.client.api.insertmailingaddress.MailingAddress;
import uk.co.stwater.targetconnector.client.api.setchor.Chor;

import java.time.LocalDate;
import java.util.List;

public class ChorMoveOutProcessor extends AbstractChorStateProcessor {

    private static Logger logger = LoggerFactory.getLogger(ChorMoveOutProcessor.class);

    ChorMoveOutProcessor(ServiceFacade serviceFacade, ChorStateManager chorStateManager, ChorStateProcessor nextStateProcessor) {
        super(serviceFacade, chorStateManager, nextStateProcessor);
    }

    @Override
    protected void processState(ChorContext chorContext) {
        logger.debug("processState entry");
        //TODO: check current state before processing.

        MoveRequestDetail movingInDetails = chorContext.getMovingInDetails();
        MoveRequestDetail movingOutDetails = chorContext.getMovingOutDetails();
        boolean billPayerAtMovingInAddress = chorContext.isBillPayerAtMovingInAddress();
        Customer movingOutCustomer = chorContext.getCustomer();
        ChorResponse chorResponse = chorContext.getChorResponse();

        addPropertyBrandIfNeeded(chorContext);
        AccountBrand accountBrand = getAccountBrand(chorContext.getAccountNumber());
        chorContext.setAccountBrand(accountBrand);

        Account movingOutAccount = chorContext.getMovingOutAccount();

        boolean movingToInAreaAndResponsible = (movingInDetails != null)
                && (movingInDetails.getAddress().getPropertyNum() != null) && billPayerAtMovingInAddress;
        if (movingToInAreaAndResponsible && movingInDetails.getDate() == null) {
            logger.info("Moving In Date should not be null");
        } else {

            // check movingOutAccount has permission to move out - i.e. use permission
            // manager to check special conditions etc
            if (isMovingHouseAllowed(movingOutAccount, movingOutCustomer.getLeNum())) {
                // if we don't have the exact destination property information,
                // we just persist a contact request (done by AOP elsewhere) and simply discard
                // the transaction request.
                // the same happens if the customer is not responsible for paying the bill
                if (!canPerformChor(movingOutDetails, movingInDetails, billPayerAtMovingInAddress, chorResponse,
                        accountBrand)) {
                    logger.info("Chor request not performed as failed validation.");
                    chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.FAILED);
                    throw new ChorProcessingException("Chor request failed validation");
                } else if (ChorUtils.isPreValidationCheckFailed(movingInDetails.getMeterReadings(),
                        movingOutDetails.getMeterReadings())) {
                    // i.e. pre validation checks failed
                    logger.info("Chor request not performed, since readings failed pre-validation checks.");
                    chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.FAILED);
                    throw new ChorProcessingException("Chor request failed pre-validation checks");
                } else if (ChorUtils.isForcedMeterReading(movingInDetails.getMeterReadings(),
                        movingOutDetails.getMeterReadings())) {
                    // i.e. over ride flag has been set
                    // i.e the user has confirmed the meter reading entered is correct even though
                    // it has failed hi lo validation.
                    logger.info(
                            "Chor request not performed, since meter reading has been forced for either the move in or move out property.");
                    chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.FAILED);
                    throw new ChorProcessingException("Chor request failed due to forced meter reading");
                } else {
                    // Service Transfer is accomplished with the following web service calls:
                    // 1 - InsertMeterReading, For Moving Out
                    // 2 - SetChor (OF) : for moving out of old property
                    // 3 - InsertMailingAddress : For movingOutAccount you have just moved out
                    // 4 - SetChor (ON) : for old property with new legal entity or occupier
                    // (88888888) if one was not specified
                    // 5 - AddAccountRole : For each additional Legal Entity
                    // Common 1 - InsertMeterReading, For Moving In
                    // Common 2 - SetChor (ON) : for moving in to new property
                    // 6 - InsertMailingAddress : for person "forced out" of property

                    logger.info("1 - SetChor (OF) : for moving out of old property");
                    // If a registered customer moves out of their property and moves into another
                    // then SetCHOR should be called twice.
                    // The first would be an 'OF' call for their move out property and an 'ON' call
                    // for their new property.
                    // Note: if there is a customer already in their new property then they will be
                    // forced out by the 'ON' call.
                    // In this case SetCHOR will return the force out movingOutAccount number for
                    // use if a mailing address is provided.

                    try {
                        doChorOut(movingOutDetails, movingOutAccount, movingOutCustomer);
                    } catch (Exception e) {
                        chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.FAILED);
                        throw e;
                    }
                    chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.COMPLETED);
                }
            } else {
                chorStateManager.moveOutChorOff(ChorProgressMonitor.Progress.FAILED);
                throw new ChorProcessingException("Chor request failed due special conditions");
            }
        }
        logger.debug("processState exit");
    }

    @Override
    public boolean canProcess(ChorState chorState) {
        return ChorState.MOVE_OUT_CHOR_OFF == chorState;
    }

    private boolean isMovingHouseAllowed(Account accountSummary, long legalEntity)
            throws STWTechnicalException, STWBusinessException {
        return !hasRestrictions(accountSummary.getAccountNumber(), legalEntity);
    }

    private void addPropertyBrandIfNeeded(ChorContext chorContext) {
        try {
            // currently, the property brand may not be set - set it if we need to.
            if (chorContext != null && chorContext.getMovingInDetails() != null
                    && chorContext.getMovingInDetails().getAddress() != null
                    && chorContext.getMovingInDetails().getPropertyBrand() == null) {
                Long propertyNumber = chorContext.getMovingInDetails().getAddress().getPropertyNum();
                logger.debug("attempting to set property brand for property number {}", propertyNumber);
                if (propertyNumber != null) {
                    final Brand propertyBrand = serviceFacade.getPropertiesService().getPropertyBrand(propertyNumber, chorContext.getUsername());
                    logger.debug("setting brand {} for property id {}", propertyBrand, propertyNumber);
                    if (propertyBrand != null) {
                        chorContext.getMovingInDetails().setPropertyBrand(propertyBrand.getAccountBrand());
                    }
                } else {
                    logger.debug("property id is null, assuming out of area");
                }
            }
        } catch (STWBaseException e) {
            throw new ChorException("Couldn't retrieve property brand", e);
        }
    }

    private AccountBrand getAccountBrand(TargetAccountNumber accountNumber) {
        if (accountNumber == null) {
            return AccountBrand.SEVERN_TRENT;
        } else {
            return serviceFacade.getAccountService().getBrandByAccount(accountNumber, StringUtils.EMPTY).getAccountBrand();
        }
    }

    private boolean hasRestrictions(TargetAccountNumber accountId, long legalEntityId)
            throws STWTechnicalException, STWBusinessException {
        // if they have a check_one or check_two, quit at this point and raise
        // appropriate contact - Target should not be updated
        // note that no-one should actually reach here with a check_one
        List<SpecialCondition> conditions = serviceFacade.getSpecialConditionService().getSpecialConditions(accountId, legalEntityId);
        return serviceFacade.getSpecialConditionService().hasRestrictions(conditions, SpecialConditionChannel.WSS,
                SpecialConditionAction.MOVING_HOUSE_CHECK_1)
                || serviceFacade.getSpecialConditionService().hasRestrictions(conditions, SpecialConditionChannel.WSS,
                SpecialConditionAction.MOVING_HOUSE_CHECK_2);
    }

    private boolean canPerformChor(MoveRequestDetail movingOutDetails, MoveRequestDetail movingInDetails,
                                   Boolean billPayerAtMovingInAddress, ChorResponse response, AccountBrand accountBrand)
            throws STWTechnicalException, STWBusinessException {

        LocalDate today = LocalDate.now();
        LocalDate limitForBillPayer = today.minusMonths(serviceFacade.getConfigService().getMonthsInPastEvidenceRequiredForBillPayer());
        LocalDate limitForNonBillPayer = today
                .minusMonths(serviceFacade.getConfigService().getMonthsInPastEvidenceRequiredForNonBillPayer());

        LocalDate movingOutDate = movingOutDetails.getDate();
        Address movingInAddress = movingInDetails.getAddress();
        List<ChorMeterRead> movingOutMeterReadings = movingOutDetails.getMeterReadings();
        List<ChorMeterRead> movingInMeterReadings = movingInDetails.getMeterReadings();

        final boolean isValidBrand = accountBrand == movingInDetails.getPropertyBrand();

        if ((!billPayerAtMovingInAddress && movingOutDate.isBefore(limitForNonBillPayer))
                || (billPayerAtMovingInAddress && movingOutDate.isBefore(limitForBillPayer))) {
            logger.info("Moving out date is too long ago");
            if (!billPayerAtMovingInAddress) {
                response.setMonthLimitRequiringDocumentation(
                        serviceFacade.getConfigService().getMonthsInPastEvidenceRequiredForNonBillPayer());
            } else {
                response.setMonthLimitRequiringDocumentation(
                        serviceFacade.getConfigService().getMonthsInPastEvidenceRequiredForBillPayer());
            }
            return false;
        } else if ((billPayerAtMovingInAddress && movingInAddress.getPropertyNum() == null)
                || (billPayerAtMovingInAddress && !isValidBrand)
                || (!billPayerAtMovingInAddress && (movingInAddress.getAddressCode() == NO_ADDRESS_CODE
                && !MailingAddress.USER_DEFINED.equals(movingInAddress.getId())))) {
            logger.info("Moving in property not specified");
            return false;
        } else if (movingOutMeterReadings != null && movingOutMeterReadings.size() > 1) {
            logger.info("Moving out meter readings greater than 1 ");
            return false;
        } else if (movingInMeterReadings != null && movingInMeterReadings.size() > 1) {
            logger.info("Moving in meter readings greater than 1");
            return false;
        }
        return true;
    }

    private Chor doChorOut(MoveRequestDetail movingOutDetails, Account movingOutAccount, Customer movingOutCustomer) {

        Address movingOutAddress = movingOutDetails.getAddress();
        movingOutCustomer.setIsIndividual(!movingOutAccount.isBusinessLE());
        logger.debug("isIndividual = {}, leIndicator = {}, isBusinessLE = {}", movingOutCustomer.getIsIndividual(), movingOutCustomer.getLeIndicator(), movingOutAccount.isBusinessLE());
        Chor chorOut = new Chor(movingOutAccount.getAccountNumber(), movingOutCustomer, movingOutDetails.getDate(),
                ChorAction.OF.toString(),
                movingOutAddress.getPropertyNum() == null ? NO_PROPERTY_NUMBER : movingOutAddress.getPropertyNum(),
                getFirstReading(movingOutDetails));

        serviceFacade.getChorClient().setChor(chorOut.getAccountNum(), chorOut);
        return chorOut;
    }

    private ChorMeterRead getFirstReading(MoveRequestDetail move) {
        ChorMeterRead firstReadingOut = null;

        if (move.getMeterReadings() != null && !move.getMeterReadings().isEmpty()) {
            firstReadingOut = move.getMeterReadings().get(0);
        }
        return firstReadingOut;
    }

}