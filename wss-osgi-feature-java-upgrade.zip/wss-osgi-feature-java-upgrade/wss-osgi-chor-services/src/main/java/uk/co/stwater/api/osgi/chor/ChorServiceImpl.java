package uk.co.stwater.api.osgi.chor;

import org.apache.commons.lang3.BooleanUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.dao.UserDao;
import uk.co.stwater.api.dao.entity.User;
import uk.co.stwater.api.email.service.EmailService;
import uk.co.stwater.api.metering.MeteringConfigService;
import uk.co.stwater.api.osgi.chor.contact.ChorContact;
import uk.co.stwater.api.osgi.chor.contact.ChorContactFormatter;
import uk.co.stwater.api.osgi.chor.contact.ChorContactTypeResolver;
import uk.co.stwater.api.osgi.chor.contact.ContactType;
import uk.co.stwater.api.osgi.model.Account;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Address;
import uk.co.stwater.api.osgi.model.Brand;
import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.SendEmailRequest;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.chor.ChorDTO;
import uk.co.stwater.api.osgi.model.chor.ChorMeterRead;
import uk.co.stwater.api.osgi.model.chor.ChorRequest;
import uk.co.stwater.api.osgi.model.chor.MoveCharges;
import uk.co.stwater.api.osgi.model.chor.MoveRequestDetail;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.util.Constants;
import uk.co.stwater.api.osgi.util.STWBaseException;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;
import uk.co.stwater.targetconnector.client.api.createcontact.CustomerContactException;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.ParseException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.apache.commons.collections.CollectionUtils.isEmpty;
import static uk.co.stwater.api.osgi.chor.ChorProgressMonitor.Progress.COMPLETED;
import static uk.co.stwater.api.osgi.chor.ChorProgressMonitor.Progress.FAILED;
import static uk.co.stwater.api.osgi.chor.ChorProgressMonitor.Progress.NOT_ATTEMPTED;

@Named
@OsgiServiceProvider(classes = {ChorService.class})
public class ChorServiceImpl implements ChorService {

    Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String UNKNOWN_POSTCODE = "POSTCODE";
    private static final TargetAccountNumber UNKNOWN_ACCOUNT_NUMBER = new TargetAccountNumber(0L, null);
    private static final String EMAIL_0184_REQUEST_SUCCESS = "E18.4";
    private static final String EMAIL_0182_REQUEST_SUCCESS = "E18.2";
    private static final String EMAIL_0181_REQUEST_SUCCESS = "E18.1";
    private static final String EMAIL_0185_REQUEST_SUCCESS = "E18.5";
    private static final String CREATE = "create";
    private static final String BRAND_KEY = "${brand}";
    private static final String FULLNAME_KEY = "${fullName}";
    private static final String MONTHS_KEY = "${months}";

    static final String NON_ACTIVE_PAYMENT_PLAN_INDICATOR = "N";

    @Inject
    private ChorContactTypeResolver chorContactTypeResolver;

    @Inject
    private ChorContactFormatter chorContactFormatter;

    @Inject
    @OsgiService
    private CreateContactClient createContactClient;

    @Inject
    @OsgiService
    private EmailService emailService;

    @Inject
    @OsgiService
    private UserDao userDao;

    @Inject
    @OsgiService
    private MeteringConfigService meteringConfigService;

    @Inject
    private ChargesCalculator chargesCalculator;

    @Inject
    private ServiceFacade serviceFacade;

    @Override
    public ChorResponse moveHouseNew(ChorRequest request, String username, AccountBrand accountBrand) throws ChorException {
        request.setBillPayerAtMovingInAddess(true);
        return moveHouseNew(request, null, username, accountBrand);
    }

    @Override
    public ChorResponse moveHouseNew(ChorRequest request, ContactDto contactDto, String username, AccountBrand accountBrand) throws ChorException {

        validateChorRequestForNewCustomerMove(request);
        if (!request.isBillPayerAtMovingInAddess()) {
            request.setBillPayerAtMovingInAddess(true);
        }
        addPropertyBrandIfNeeded(request, username);

        ChorContext chorContext = ChorContext.newCustomer(request, username, ChorStateManager.newCustomer());
        ChorResponse response = moveHouseNew(chorContext);
        logger.info("Chor processed: {}", response);

        Account account = new Account();
        response.setEmailAlreadyExists(doesEmailAddressAlreadyExist(request.getEmailAddress(), request.getAccountNumber(), accountBrand));
        sendContact(chorContext);

        if (contactDto != null) {
            contactDto.setAccountNumber(chorContext.getAccountNumber());
            sendEmail(request, response, request.getEmailAddress(), contactDto, username, account, accountBrand, chorContext);
        } else {
            logger.error("Couldn't send Chor email due to missing contactDto");
        }

        return response;
    }

    @Override
    public ChorResponse moveHouseExisting(ChorRequest request, ContactDto contactDto, String username)
            throws ChorException {

        validateChorRequestForExistingCustomerMove(request);
        ChorResponse chorResponse;
        Account movingOutAccount;
        Long legalEntityId;
        try {
            legalEntityId = request.getCustomer().getLeNum();
            movingOutAccount = serviceFacade.getAccountService().getAccountSummary(request.getAccountNumber(), UNKNOWN_POSTCODE,
                    legalEntityId, null);
        } catch (IllegalArgumentException | STWBaseException e) {
            throw new ChorException("Couldn't retrieve account summary", e);
        }

        ChorStateManager chorStateManager = ChorStateManager.existingCustomer();
        ChorContext chorContext = ChorContext.existingCustomer(request, username, movingOutAccount, chorStateManager);
        try {
            getProcessorForExistingCustomer(chorContext.getChorStateManager()).process(chorContext);
            chorResponse = chorContext.getChorResponse();
            logger.info("Chor processed: {}", chorResponse);
        } catch (STWTechnicalException technicalException) {
            logger.error("A technical error occurred while attempting to move house for existing customer", technicalException);
            chorResponse = handleException(chorContext, technicalException);
        } catch (STWBusinessException businessException) {
            logger.warn("A business error occurred while attempting to move house for existing customer", businessException);
            chorResponse = handleException(chorContext, businessException);
        } catch (Exception e) {
            logger.error("A completely unexpected technical error occurred while attempting to move house for existing customer", e);
            chorResponse = handleException(chorContext, e);
        }

        sendContact(chorContext);
        sendEmail(request, chorResponse, request.getEmailAddress(), contactDto, username, chorContext.getMovingOutAccount(), chorContext.getAccountBrand(), chorContext);
        return chorResponse;
    }

    @Override
    public ChorResponse createBill(ChorDTO chorDTO, String authToken) {
        ChorStateManager chorStateManager = initChorStateManager(chorDTO);
        ChorProgressMonitor chorProgressMonitor = new ChorProgressMonitor(chorStateManager,
                isEmpty(chorDTO.getChorRequest().getMovingOutDetails().getMeterReadings()),
                isEmpty(chorDTO.getChorRequest().getMovingInDetails().getMeterReadings()));
        Bill bill = new Bill();
        bill.setAccountNumber(chorDTO.getChorRequest().getAccountNumber().getAccountNumberWithCheckDigit());
        if (chorDTO.getChorRequest() != null && chorDTO.getChorRequest().getMovingOutDetails() != null
                && chorDTO.getChorRequest().getMovingOutDetails().getAddress() != null
                && chorDTO.getChorRequest().getMovingOutDetails().getAddress().getPropertyNum() != null) {
            bill.setPropertyId(
                    String.valueOf(chorDTO.getChorRequest().getMovingOutDetails().getAddress().getPropertyNum()));
        }
        bill.setEndDate(chorDTO.getChorRequest().getMovingOutDetails().getDate());
        logger.debug("authToken is {}", authToken);

        try {
            Bill createdBill = serviceFacade.getBillService().create(bill, authToken, CREATE);
            updateChorStateManagerForSimBill(chorStateManager, COMPLETED);
            ChorResponse response = createChorResponse(chorDTO, chorProgressMonitor);
            response.setFinalBalanceAmount(createdBill.getFinalBalAmount());
            MoveCharges moveCharges = new MoveCharges();
            moveCharges.setAmount(createdBill.getFinalBalAmount());
            moveCharges.setFrom(createdBill.getBillStartDate());
            moveCharges.setTo(createdBill.getBillEndDate());
            response.setMoveOutCharges(moveCharges);
            return response;
        } catch (STWTechnicalException | STWBusinessException e) {
            logger.warn("an exception occurred while invoking sim bill", e);
            updateChorStateManagerForSimBill(chorStateManager, FAILED);
            ChorResponse response = createChorResponse(chorDTO, chorProgressMonitor);
            Account account = serviceFacade.getAccountService().getAccountSummary(chorDTO.getChorRequest().getAccountNumber(), UNKNOWN_POSTCODE, chorDTO.getChorRequest().getCustomer().getLeNum(), null);
            ChorContext chorContext = ChorContext.existingCustomer(chorDTO.getChorRequest(), authToken, account, chorStateManager, response);
            sendContact(chorContext);
            throw new ChorException("sim bill failed", e);
        }
    }

    private static ChorStateManager initChorStateManager(ChorDTO chorDTO) {
        ChorRequest chorRequest = chorDTO.getChorRequest();
        ChorStateManager chorStateManager;
        if (chorRequest.getMovingOutDetails() != null) {
            chorStateManager = ChorStateManager.existingCustomer();
            chorStateManager.moveOutChorOff(COMPLETED).moveOutNewAddress(COMPLETED).moveOutChorOn(COMPLETED)
                    .moveOutRole(COMPLETED);
            boolean doubleSidedChor = (chorRequest.getMovingInDetails() != null);
            if (doubleSidedChor) {
                chorStateManager.moveInChorOn(COMPLETED).moveInAddress(COMPLETED);
            } else {
                chorStateManager.moveInChorOn(NOT_ATTEMPTED).moveInAddress(NOT_ATTEMPTED);
            }
        } else {
            chorStateManager = ChorStateManager.newCustomer();
            chorStateManager.moveInChorOn(COMPLETED).moveInAddress(COMPLETED);
        }
        return chorStateManager;
    }

    private static void updateChorStateManagerForSimBill(ChorStateManager chorStateManager, ChorProgressMonitor.Progress progress) {
        if (chorStateManager.isExistingCustomer()) {
            chorStateManager.moveOutSimBill(progress);
        } else {
            chorStateManager.moveInSimBill(progress);
        }
    }

    private static ChorResponse handleException(ChorContext chorContext, STWBusinessException ex) {
        ChorResponse chorResponse = handleException(chorContext, (Exception) ex);
        chorResponse.setErrorCode(ex.getErrorCode());
        return chorResponse;
    }

    private static ChorResponse handleException(ChorContext chorContext, Exception ex) {
        ChorResponse chorResponse = chorContext.getChorResponse();
        chorResponse.setExceptionOccurred(true);
        chorResponse.setErrorMessage(ex.getMessage());
        return chorResponse;
    }

    private static void validateChorRequestForNewCustomerMove(ChorRequest request) {
        if (request == null)
            throw new IllegalArgumentException("Request object missing");
        if (request.getMovingInDetails() == null)
            throw new IllegalArgumentException("Moving In Details should not be null");
        if (request.getMovingInDetails().getDate() == null)
            throw new IllegalArgumentException("Moving in date should not be null");
        if (request.getMovingInDetails().getAddress() == null)
            throw new IllegalArgumentException("Moving in address should not be null");
        if (isEmpty(request.getNewResponsibilities())) {
            throw new IllegalArgumentException("New Responsibilities should not be null or empty");
        }
    }

    private static void validateChorRequestForExistingCustomerMove(ChorRequest request) {
        if (request == null)
            throw new IllegalArgumentException("Request object missing");
        if (request.getCustomer() == null)
            throw new IllegalArgumentException("Customer should not be null");
        if (request.getAccountNumber() == null)
            throw new IllegalArgumentException("Account number must be supplied");
        if (request.getCustomer().getLeNum() == null)
            throw new IllegalArgumentException("Customer le must be supplied");
        if (request.getMovingOutDetails() == null)
            throw new IllegalArgumentException("Moving Out Details should not be null");
        if (request.getMovingOutDetails().getDate() == null)
            throw new IllegalArgumentException("Move out date is required");
    }

    private void addPropertyBrandIfNeeded(ChorRequest request, String username) {
        try {
            // currently, the property brand may not be set - set it if we need to.
            if (request != null && request.getMovingInDetails() != null
                    && request.getMovingInDetails().getAddress() != null
                    && request.getMovingInDetails().getPropertyBrand() == null) {
                Long propertyNumber = request.getMovingInDetails().getAddress().getPropertyNum();
                logger.debug("attempting to set property brand for property number {}", propertyNumber);
                if (propertyNumber != null) {
                    final Brand propertyBrand = serviceFacade.getPropertiesService().getPropertyBrand(propertyNumber, username);
                    logger.debug("setting brand {} for property id {}", propertyBrand, propertyNumber);
                    if (propertyBrand != null) {
                        request.getMovingInDetails().setPropertyBrand(propertyBrand.getAccountBrand());
                    }
                } else {
                    logger.debug("property id is null, assuming out of area");
                }
            }
        } catch (STWBaseException e) {
            throw new ChorException("Couldn't retrieve property brand", e);
        }
    }

    private boolean doesEmailAddressAlreadyExist(String emailAddress, TargetAccountNumber accountNumber, AccountBrand accountBrand) {
        String site = (accountBrand != null ? accountBrand.getSite() : Constants.STW);
        List<User> users = userDao.findUsersByEmailAndSite(emailAddress, site);
        return users.stream().anyMatch(user -> user.getRegistrationType().equals("EAUN") || user.isLoginWithEmail()
                || user.getRegistrationType().equals("PARTIAL"));
    }

    private ChorResponse moveHouseNew(ChorContext chorContext) {

        MoveRequestDetail movingInDetails = chorContext.getMovingInDetails();

        // if we don't have the exact destination property information,
        // we just persist a contact request and simply discard the transaction request.
        // the same happens if the customer is not responsible for paying the bill
        if (!canPerformNewCustomerChor(movingInDetails.getAddress(), movingInDetails.getMeterReadings())) {
            logger.info("transfer request not performed, since destination address has not been set in the request.");
        } else if (ChorUtils.isForcedMeterReading(movingInDetails.getMeterReadings(), null)) {
            // JH 28/04/09 td1526 over ride flag has been set
            // i.e the user has confirmed the meter reading entered is correct even though
            // it has failed hi lo validation.
            logger.info("transfer request not performed, since meter reading has been forced.");
        } else {
            try {
                // Service Transfer for new customers is accomplished with the following web
                // service calls:
                // Common 1 - InsertMeterReading, For Moving In
                // Common 2 - SetChor (ON) : for moving in to new property
                // Common 3 - SetChor (ON) : for moving in to new property
                // 1 - AddAccountRole : For each additional Legal Entity
                // 2 - Get Personal Details : For each additional Legal Entity
                // 3 - Set Personal Details : For each additional Legal Entity

                logger.debug("Run method to perfom common 1, 2 and 3");
                // note we assume the first new responsibility in the list is the primary

                getProcessorForNewCustomer(chorContext.getChorStateManager()).process(chorContext);
            } catch (STWTechnicalException technicalException) {
                logger.error("A technical error occurred while attempting to move house for new customer",
                        technicalException);
                handleException(chorContext, technicalException);
            } catch (STWBusinessException businessException) {
                logger.info("A business error occurred while attempting to move house for new customer",
                        businessException);
                handleException(chorContext, businessException);
            } catch (STWBaseException e) {
                logger.info("An error occurred while attempting to move house for new customer", e);
                handleException(chorContext, e);
            } catch (Exception e) {
                logger.error("A completely unexpected technical error occurred while attempting to move house for new customer", e);
                handleException(chorContext, e);
            }
        }
        return chorContext.getChorResponse();
    }

    protected boolean canPerformNewCustomerChor(Address movingInAddress, List<ChorMeterRead> movingInMeterReadings) {

        if (movingInAddress.getPropertyNum() == null) {
            return false;
        } else {
            if (ChorUtils.isPreValidationCheckFailed(movingInMeterReadings, null)) {
                logger.debug("Moving in meter readings failed pre-validation checks");
                return false;
            }
        }
        return true;
    }

    private void sendEmail(ChorRequest request, ChorResponse response, String emailAddress, ContactDto contactDto,
                           String authToken, Account movingOutAccount, AccountBrand accountBrand, ChorContext chorContext) {
        switch (response.getStatus()) {
            case NEEDS_DOCUMENTATION:
                sendEmail041(emailAddress, contactDto, Objects.toString(response.getMonthLimitRequiringDocumentation()));
                break;
            case NEW_CUSTOMER_COMPLETED_NOT_REGISTERED:
            case NEW_CUSTOMER_COMPLETED_REGISTERED:
            case EXISTING_CREDIT_OR_ZERO:
            case EXISTING_DEBIT:
            case COMPLETED_SIMBILL_SUCCESS:
                if (movingOutAccount != null && ChorUtils.hasActivePaymentPlan(movingOutAccount)
                        && ChorUtils.ifMoveInMoveOutUnMeasuredAndInPast(request)) {
                    // no email
                } else {
                    sendEmail18_1(emailAddress, contactDto);
                }
                break;
            case AQ_RAISED:
                sendEmail009(request, emailAddress, contactDto, accountBrand);
                break;
            case COMPLETED_SIMBILL_FAILED:
                sendEmail18_1(emailAddress, contactDto);
                break;
            default:
                sendEmail009(request, emailAddress, contactDto, accountBrand);
        }
    }

    private void sendEmail18_1(String emailAddress, ContactDto contactDto) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put(FULLNAME_KEY, contactDto.getFullName());
        emailService.mailMergeAndSend(EMAIL_0181_REQUEST_SUCCESS, fieldData, emailAddress,
                contactDto.getAccountNumber(), contactDto.getLeId());
    }

    private void sendEmail009(ChorRequest request, String emailAddress, ContactDto contactDto, AccountBrand accountBrand) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put(FULLNAME_KEY, contactDto.getFullName());
        fieldData.put(BRAND_KEY, accountBrand.getSite());

        boolean isStwBrand = true;
        if (request.getMovingInDetails() != null && request.getMovingInDetails().getPropertyBrand() != null) {
            isStwBrand = AccountBrand.SEVERN_TRENT == request.getMovingInDetails().getPropertyBrand();
        }
        SendEmailRequest sendEmailRequest = new SendEmailRequest();
        sendEmailRequest.setFieldData(fieldData);
        sendEmailRequest.setRecipientAddress(emailAddress);
        sendEmailRequest.setLegalEntityId(contactDto.getLeId());

        if (!isStwBrand) {
            sendEmailRequest.setEmailReference(EMAIL_0185_REQUEST_SUCCESS);
            emailService.mailMergeAndSend(sendEmailRequest);
        } else {
            sendEmailRequest.setEmailReference(EMAIL_0182_REQUEST_SUCCESS);
            emailService.mailMergeAndSend(sendEmailRequest);
        }
    }

    private void sendEmail041(String emailAddress, ContactDto contactDto, String months) {
        Map<String, String> fieldData = new HashMap<>();
        fieldData.put(FULLNAME_KEY, contactDto.getFullName());
        fieldData.put(MONTHS_KEY, months);
        emailService.mailMergeAndSend(EMAIL_0184_REQUEST_SUCCESS, fieldData, emailAddress,
                contactDto.getAccountNumber(), contactDto.getLeId());
    }

    private void sendContact(ChorContext chorContext) throws ChorException {
        try {
            Long legalEntityId = chorContext.getCustomer() == null ? null : chorContext.getCustomer().getLeNum();
            List<ContactType> contactTypes = chorContactTypeResolver.getContactTypes(chorContext.getChorResponse(),
                    legalEntityId, chorContext.getAccount(), chorContext.getAccountNumber(),
                    chorContext.getMovingOutDetails(), chorContext.getMovingInDetails(),
                    chorContext.getNewAddressPreviousCustomer(), chorContext.isBillPayerAtMovingInAddress(),
                    chorContext.getAccountBrand());

            setChorStatus(contactTypes, chorContext);

            ContactNotesData contactNotesData = null;
            if (chorContext.getAccountNumber() != null && legalEntityId != null) {
                contactNotesData = createContactClient.getContactNotesData(chorContext.getAccountNumber(), legalEntityId);
            }

            ChorResponse response = chorContext.getChorResponse();
            for (ContactType contactType : contactTypes) {

                String note;
                if (response != null && response.isSuccess()) {
                    if (chorContext.isExistingCustomer()) {
                        note = chorContactFormatter.formatExistingCustomerSuccessful(contactType,
                                chorContext, contactNotesData, chorContext.getAccountNumber());
                    } else {
                        note = chorContactFormatter.formatNewCustomerSuccessful(contactType, chorContext, contactNotesData);
                    }
                } else {
                    if (chorContext.isExistingCustomer()) {
                        note = chorContactFormatter.formatExistingCustomerFailed(contactType,
                                chorContext, response.getErrorMessage(), contactNotesData);
                    } else {
                        note = chorContactFormatter.formatNewCustomerFailed(contactType, chorContext, response.getErrorMessage());
                    }
                }

                Long propertyNumber = null;
                if (!chorContext.isExistingCustomer()) {
                    if (chorContext.getMovingInDetails() != null && chorContext.getMovingInDetails().getAddress() != null) {
                        propertyNumber = chorContext.getMovingInDetails().getAddress().getPropertyNum();
                    }
                } else {
                    if (chorContext.getMovingOutDetails() != null && chorContext.getMovingOutDetails().getAddress() != null) {
                        propertyNumber = chorContext.getMovingOutDetails().getAddress().getPropertyNum();
                    }
                }

                ChorContact contact = new ChorContact(chorContext.getAccountNumberForContact(), legalEntityId, getPostcode(chorContext),
                        contactType.getType().toString(), note, contactType.getSubstantiveResponse(), propertyNumber);

                logger.info("Creating contact: {}", contact);
                createContactClient.createContact(contact);

            }
        } catch (STWTechnicalException | STWBusinessException | CustomerContactException | ParseException e) {
            logger.error("Unable to create contact", e);
            throw new ChorException("Unable to create contact", e);
        }
    }

    private static String getPostcode(ChorContext chorContext) {
        String postcode = UNKNOWN_POSTCODE;
        if (chorContext.getMovingOutDetails() != null && chorContext.getMovingOutDetails().getAddress() != null) {
            postcode = chorContext.getMovingOutDetails().getAddress().getPostcode();
        } else {
            if (chorContext.getMovingInDetails() != null && chorContext.getMovingInDetails().getAddress() != null) {
                postcode = chorContext.getMovingInDetails().getAddress().getPostcode();
            }
        }
        return postcode;
    }

    @Override
    public ChorRequest getChorDaysParameters() {
        ChorRequest chorRequest = new ChorRequest();
        chorRequest.setDaysInFutureChorAllowedFor(serviceFacade.getConfigService().getDaysInFutureChorAllowedFor());
        chorRequest
                .setDaysAfterEndDateMeterReadAllowedFor(meteringConfigService.getDaysAfterEndDateMeterReadAllowedFor());
        return chorRequest;
    }

    private ChorResponse createChorResponse(ChorDTO chorDTO, ChorProgressMonitor chorProgressMonitor) {
        ChorResponse chorResponse = new ChorResponse();
        chorResponse.setNewAccountNumber(chorDTO.getNewAccountNumber());
        chorResponse.setNewLegalEntityId(chorDTO.getNewLegalEntityId());
        chorResponse.setEmailAlreadyExists(chorDTO.getEmailAlreadyExists());
        chorResponse.setMonthLimitRequiringDocumentation(chorDTO.getMonthLimitRequiringDocumentation());
        chorResponse.setMoveInCharges(chorDTO.getMoveInCharges());
        chorResponse.setMoveOutCharges(chorDTO.getMoveOutCharges());
        chorResponse.setMeterReadRequired(chorDTO.getMeterReadRequired());
        chorResponse.setPaymentPlan(chorDTO.isHavePaymentPlan());
        chorResponse.setSupplyType(chorDTO.getSupplyType());
        chorResponse.setChorProgressMonitor(chorProgressMonitor);
        if (chorResponse.getChorProgressMonitor() != null && BooleanUtils.isTrue(chorDTO.getPlanCreationFailed())) {
            chorResponse.getChorProgressMonitor().setNewPaymentPlan(chorDTO.getPaymentPlan());
        }
        if (chorResponse.isExceptionOccurred()) {
            chorResponse.setErrorMessage(chorResponse.getErrorMessage());
        }
        chorResponse.setSuccess(chorDTO.isChorSuccess());
        return chorResponse;
    }

    public ChorStateProcessor getProcessorForExistingCustomer(ChorStateManager chorStateManager) {
        ChorStateProcessor doNothingProcessor = new ChorDoNothingProcessor();
        ChorStateProcessor simBillProcessor = new ChorSimBillProcessor(serviceFacade, chorStateManager, doNothingProcessor);
        ChorStateProcessor moveInProcessor = new ChorMoveInProcessor(serviceFacade, chorStateManager, simBillProcessor);
        ChorStateProcessor moveOutChorOnProcessor = new ChorUpdateResponsibilitiesProcessor(serviceFacade, chorStateManager, moveInProcessor);
        ChorStateProcessor moveOutMailingAddressProcessor = new ChorMoveOutAddressProcessor(serviceFacade, chorStateManager, moveOutChorOnProcessor);
        ChorStateProcessor moveOutChorOffProcessor = new ChorMoveOutProcessor(serviceFacade, chorStateManager, moveOutMailingAddressProcessor);

        return moveOutChorOffProcessor;
    }

    ChorStateProcessor getProcessorForNewCustomer(ChorStateManager chorStateManager) {
        ChorStateProcessor doNothingProcessor = new ChorDoNothingProcessor();
        ChorStateProcessor simBillProcessor = new ChorSimBillProcessor(serviceFacade, chorStateManager, doNothingProcessor);
        ChorMoveInProcessor moveInProcessor = new ChorMoveInProcessor(serviceFacade, chorStateManager, simBillProcessor);
        ChorMoveInPrePostProcessor chorMoveInPrePostProcessor = new ChorMoveInPrePostProcessor(serviceFacade);
        moveInProcessor.setChorPreProcessor(chorMoveInPrePostProcessor);
        moveInProcessor.setChorPostProcessor(chorMoveInPrePostProcessor);

        return moveInProcessor;
    }

    private static void setChorStatus(List<ContactType> contactTypes, ChorContext chorContext) {
        ChorResponse response = chorContext.getChorResponse();
        if (contactTypes.stream().map(ContactType::getType).anyMatch(ContactTypes.WEB652::equals)) {
            response.setStatus(ChorResponse.Status.NEEDS_DOCUMENTATION);
        } else if (response.isSuccess() && chorContext.isExistingCustomer()) {
            ChorStateManager chorStateManager = response.getChorProgressMonitor().getChorStateManager();
            if (contactTypes.stream().map(ContactType::getType).anyMatch(ContactTypes.WEB649::equals)
                    && response.getMoveOutCharges() == null && response.getMoveInCharges() == null
                    && response.isPaymentPlan() && !chorContext.getAccount().isDemandDirectDebit()) {
                response.setStatus(ChorResponse.Status.COMPLETED_MEASURED_MOVE_IN_SUCCESS);
            } else if (contactTypes.stream().map(ContactType::getType).anyMatch(ContactTypes.WEB649::equals)
                    && !(chorStateManager.hasAnyStates(
                            EnumSet.of(ChorState.MOVE_IN_SIM_BILL_FAILED, ChorState.MOVE_OUT_SIM_BILL_FAILED)))) {
                response.setStatus(ChorResponse.Status.COMPLETED_SIMBILL_SUCCESS);
            } else if (chorStateManager.hasAnyStates(
                    EnumSet.of(ChorState.MOVE_OUT_SIM_BILL_NOT_ATTEMPTED, ChorState.MOVE_IN_SIM_BILL_NOT_ATTEMPTED))
                    && chorContext.getAccount().isDemandDirectDebit()) {
                response.setStatus(ChorResponse.Status.COMPLETED_WITHOUT_SIMBILL_FOR_DD);
            } else if (response.getChorProgressMonitor() == null
                    || response.getChorProgressMonitor().getChorStateManager()
                            .hasState(ChorState.MOVE_IN_SIM_BILL_FAILED)
                    || response.getChorProgressMonitor().getChorStateManager()
                            .hasState(ChorState.MOVE_OUT_SIM_BILL_FAILED)) {
                response.setStatus(ChorResponse.Status.COMPLETED_SIMBILL_FAILED);
            } else if (response.getMoveOutCharges() != null) {
                float amount = response.getMoveOutCharges().getAmount();
                if (amount > 0f) {
                    response.setStatus(ChorResponse.Status.EXISTING_DEBIT);
                } else {
                    response.setStatus(ChorResponse.Status.EXISTING_CREDIT_OR_ZERO);
                }
            } else {
                response.setStatus(ChorResponse.Status.COMPLETED_SIMBILL_FAILED);
            }
        } else if (response.isSuccess() && !chorContext.isExistingCustomer() && response.getEmailAlreadyExists()) {
            response.setStatus(ChorResponse.Status.NEW_CUSTOMER_COMPLETED_NOT_REGISTERED);
        } else if (response.isSuccess() && !chorContext.isExistingCustomer() && !response.getEmailAlreadyExists()) {
            response.setStatus(ChorResponse.Status.NEW_CUSTOMER_COMPLETED_REGISTERED);
        } else if (chorContext.getMovingInDetails() != null
                && chorContext.getMovingInDetails().getPropertyBrand() != null
                && !chorContext.getAccountBrand().equals(chorContext.getMovingInDetails().getPropertyBrand())) {
            response.setStatus(ChorResponse.Status.INVALID_BRAND_PROPERTY);
        } else {
            response.setStatus(ChorResponse.Status.AQ_RAISED);
        }
    }
}