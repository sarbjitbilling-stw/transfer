package uk.co.stwater.api.osgi.chor.agent;

import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.customer.exception.STWBusinessCustomerException;
import uk.co.stwater.iib.client.api.customer.get.CustomerResponse;
import uk.co.stwater.iib.client.api.customer.update.IIBUpdateCustomerRequest;

import javax.inject.Named;

@Named
public class UpdateGeneralCustomerInfoRequestTransformer implements Transformer {

    /**
     * This is will update the General Customer Data only, and not the Additional Customer Data. (Better processing)
     * Note: Additional Customer Data(ex: employmentStatus,niNumber)  resides in different table,
     * and each additional data attribute is represented by a separate Row,
     * Therefore if 5 attributes are updated, then 5 rows needs updating (Also the cyclic check will be performed for each one)
     */
    @Override
    public Object transform(Object source) {
        IIBUpdateCustomerRequest request = null;
        if (null == source) {
            throw new STWBusinessCustomerException("source is a required parameter");
        }

        if (source instanceof CustomerResponse) {
            CustomerResponse response = (CustomerResponse) source;
            request = new IIBUpdateCustomerRequest();

            request.setId(response.getId());

            request.setTitle(response.getTitle());
            request.setFirstName(response.getFirstName());
            request.setMiddleInitial(response.getMiddleInitial());
            request.setLastName(response.getLastName());
            request.setPreferredName(response.getPreferredName());

            request.setDateOfBirth(response.getDateOfBirth());
            request.setIsIndividual(response.getIsIndividual());
            request.setEmailAddress(response.getEmailAddress());
            request.setIsWSSRegistered(response.getIsWSSRegistered());

            request.setVersion036(response.getVersion036());
            request.setVersion064(response.getVersion064());
            request.setVersion696(response.getVersion696());

            request.setSicCode(response.getSicCode());
            request.setTradingName(response.getTradingName());

        }

        return request;
    }

}
