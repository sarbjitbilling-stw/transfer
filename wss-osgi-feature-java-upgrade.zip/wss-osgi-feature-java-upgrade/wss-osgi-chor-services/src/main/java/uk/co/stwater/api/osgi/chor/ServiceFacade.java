package uk.co.stwater.api.osgi.chor;

import org.ops4j.pax.cdi.api.OsgiService;
import uk.co.stwater.api.bill.BillService;
import uk.co.stwater.api.osgi.account.AccountService;
import uk.co.stwater.api.osgi.property.PropertiesService;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.addaccountrole.AddAccountRoleClient;
import uk.co.stwater.targetconnector.client.api.insertmailingaddress.MailingAddressClient;
import uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsClient;
import uk.co.stwater.targetconnector.client.api.setchor.SetChorClient;

import javax.inject.Inject;
import javax.inject.Named;

@Named
public class ServiceFacade {

    @Inject
    @OsgiService
    private AccountService accountService;

    @OsgiService
    @Inject
    private AddAccountRoleClient addAccountRoleClient;

    @OsgiService
    @Inject
    private BillService billService;

    @OsgiService
    @Inject
    private SetChorClient chorClient;

    @Inject
    private ChorConfigService configService;

    @Inject
    @OsgiService
    private GetPropertiesForAccountNumberClient propertiesForAccountNumberService;

    @OsgiService
    @Inject
    private MailingAddressClient mailingAddressClient;

    @Inject
    @OsgiService
    private PropertiesService propertiesService;

    @Inject
    @OsgiService
    private SpecialConditionService specialConditionService;

    @Inject
    @OsgiService
    private PersonalDetailsClient personalDetailsClient;

    @Inject
    private ChargesCalculator chargesCalculator;

    public AccountService getAccountService() {
        return accountService;
    }

    public AddAccountRoleClient getAddAccountRoleClient() {
        return addAccountRoleClient;
    }

    public BillService getBillService() {
        return billService;
    }

    public SetChorClient getChorClient() {
        return chorClient;
    }

    public ChorConfigService getConfigService() {
        return configService;
    }

    public GetPropertiesForAccountNumberClient getPropertiesForAccountNumberService() {
        return propertiesForAccountNumberService;
    }

    public MailingAddressClient getMailingAddressClient() {
        return mailingAddressClient;
    }

    public PropertiesService getPropertiesService() {
        return propertiesService;
    }

    public SpecialConditionService getSpecialConditionService() {
        return specialConditionService;
    }

    public ChargesCalculator getChargesCalculator() { return chargesCalculator; }

    public PersonalDetailsClient getPersonalDetailsClient() {
        return personalDetailsClient;
    }
}
