package uk.co.stwater.api.osgi.chor.agent;

import javax.inject.Named;

import org.apache.commons.collections.Transformer;

@Named
public class PatchAccountTransformer implements Transformer {

	@Override
	public Object transform(Object arg0) {
		return null;
	}

}
