package uk.co.stwater.api.osgi.probate;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.model.PaperlessDetails;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.iib.client.api.roles.get.IIBGetRolesResponse;
import uk.co.stwater.iib.client.api.roles.update.IIBUpdateRoleRequest;

import javax.inject.Named;

@Named
public class IIBUpdateRoleRequestTransformer implements Transformer {

    @Override
    public Object transform(Object source) {
        IIBUpdateRoleRequest iibUpdateRoleRequest = null;
        if (null == source) {
            throw new STWBusinessException("source is a required parameter");
        }

        try {

            if (source instanceof IIBGetRolesResponse) {
                IIBGetRolesResponse rolesResponse = (IIBGetRolesResponse) source;
                iibUpdateRoleRequest = new IIBUpdateRoleRequest();

                iibUpdateRoleRequest.setAcceptsInserts(rolesResponse.getAcceptsInserts());
                iibUpdateRoleRequest.setDocCopiesNo(rolesResponse.getDocCopiesNo());
                iibUpdateRoleRequest.setDocRefNum(rolesResponse.getDocRefNum());
                iibUpdateRoleRequest.setEndDate(rolesResponse.getEndDate());
                iibUpdateRoleRequest.setFirstName(rolesResponse.getFirstName());
                iibUpdateRoleRequest.setLastName(rolesResponse.getLastName());
                iibUpdateRoleRequest.setLegalEntityNo(rolesResponse.getLegalEntityNo());
                iibUpdateRoleRequest.setMiddleInitial(rolesResponse.getMiddleInitial());
                iibUpdateRoleRequest.setPartyReq(rolesResponse.getPartyReq());
                iibUpdateRoleRequest.setPrintOnBill(rolesResponse.getPrintOnBill());
                iibUpdateRoleRequest.setRequestorRel(rolesResponse.getRequestorRel());
                iibUpdateRoleRequest.setRoleId(rolesResponse.getRoleId());
                if (rolesResponse.getRole() != null) {
                    RefData refDataRoleClone = new RefData();
                    BeanUtils.copyProperties(refDataRoleClone, rolesResponse.getRole());
                    iibUpdateRoleRequest.setRole(refDataRoleClone);
                }
                iibUpdateRoleRequest.setStartDate(rolesResponse.getStartDate());
                if (rolesResponse.getTitle() != null) {
                    RefData refDataTitleClone = new RefData();
                    BeanUtils.copyProperties(refDataTitleClone, rolesResponse.getTitle());
                    iibUpdateRoleRequest.setTitle(refDataTitleClone);
                }
                iibUpdateRoleRequest.setVersionNo(rolesResponse.getVersionNo());

                if (rolesResponse.getWebSelfServe() != null) {
                    PaperlessDetails paperlessDetailsClone = new PaperlessDetails();
                    BeanUtils.copyProperties(paperlessDetailsClone, rolesResponse.getWebSelfServe());
                    iibUpdateRoleRequest.setWebSelfServe(rolesResponse.getWebSelfServe());
                }

            } else {
                throw new STWBusinessException("source must be an instance of IIBGetRolesResponse");
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return iibUpdateRoleRequest;
    }

}
