package uk.co.stwater.api.callwrap.model;

import java.time.LocalDate;

import org.apache.commons.lang3.StringUtils;

import io.swagger.model.ContactEvent;
import io.swagger.model.RefData;
import lombok.Data;
import uk.co.stwater.api.callwrap.BaseContactEventBuilder;
import uk.co.stwater.api.callwrap.CallWrapException;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

@Data
public class AqContactEventRequest extends BaseContactEventBuilder {
    private TargetAccountNumber accountNumber;
    private Long legalEntityNo;
    // defaults to 0 if not set in request
    private Long propertyId = 0L;
    private String contactType;
    private String contactMethod;
    private String contactInitiatedBy;
    private String contactSubType;
    private String resolution;
    private Boolean complaint;
    private Boolean repeatCallChase;
    private Boolean subsetResponseMade;
    private Long organisationNumber;
    private String activityTypeCode;
    private String activityPriority;
    private LocalDate dueDate;
    private String rootCauseType;
    private String contactPackageId;
    private String notes;

    public void validate() {
        if (accountNumber == null) {
            throw new CallWrapException("accountNumber is required");
        }
        if (legalEntityNo == null || legalEntityNo == 0L) {
            throw new CallWrapException("legalEntityNo is required");
        }
        if (propertyId == null) {
            throw new CallWrapException("propertId is required");
        }
        if (StringUtils.isBlank(contactType)) {
            throw new CallWrapException("contactType is required");
        }
        if (StringUtils.isBlank(contactMethod)) {
            throw new CallWrapException("contactMethod is required");
        }
        if (StringUtils.isBlank(contactInitiatedBy)) {
            throw new CallWrapException("contactInitiatedBy is required");
        }
        if (StringUtils.isBlank(contactSubType)) {
            throw new CallWrapException("contactSubType is required");
        }
        if (organisationNumber == null || organisationNumber == 0L) {
            throw new CallWrapException("organisationNumber is required");
        }
        if (StringUtils.isBlank(activityTypeCode)) {
            throw new CallWrapException("activityTypeCode is required");
        }
        if (StringUtils.isBlank(activityPriority)) {
            throw new CallWrapException("activityPriority is required");
        }
        if (dueDate == null) {
            throw new CallWrapException("dueDate is required");
        }
        if (StringUtils.isBlank(rootCauseType)) {
            throw new CallWrapException("rootCauseType is required");
        }
        if (StringUtils.isBlank(contactPackageId)) {
            throw new CallWrapException("contactPackageId is required");
        }
        if (notes == null) {
            throw new CallWrapException("notes is required");
        }
        if (StringUtils.isBlank(resolution)) {
            throw new CallWrapException("resolution is required");
        }
    }

    @Override
    public ContactEvent build() {
        LocalDate currentDate = getCurrentDate();

        // notes not included in create ContactEvent, needs to be set in separate update request
        // @formatter:off
        ContactEvent contactEvent = new ContactEvent()
                .accountId(accountNumber.getAccountNumberAsLong())
                .legalEntityNo(legalEntityNo)
                .propertyId(propertyId)
                .contactType(new RefData().code(contactType))
                .contactMethod(contactMethod)
                .contactInitiatedBy(new RefData().code(contactInitiatedBy))
                .contactSubType(new RefData().code(contactSubType))
                .contactResolvedTime(currentDate)
                .contactAssignedTime(currentDate)
                .complaintReceivedFlag(toStringYN(complaint))
                .repeatReqFlag(toStringYN(repeatCallChase))
                .substituteRespFlag(toStringYN(subsetResponseMade, TARGET_NO))
                .orgNum(organisationNumber)
                .actTypeCode(activityTypeCode)
                .actPriority(new RefData().code(activityPriority))
                .dueDate(dueDate)
                .rootCauseType(new RefData().code(rootCauseType))
                .contactPackageId(contactPackageId);
        // @formatter:on

        setResolutionFields(contactEvent, resolution);

        return contactEvent;
    }

}
