package uk.co.stwater.api.callwrap;

import javax.ws.rs.core.Response;

import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

public class CallWrapException extends STWBusinessException {
    private static final long serialVersionUID = 7398311690838195252L;

    static final String DEFAULT_ERROR_CODE = "100";

    public CallWrapException(String msg) {
        this(DEFAULT_ERROR_CODE, msg);
    }

    public CallWrapException(String msg, Throwable t) {
        this(DEFAULT_ERROR_CODE, msg, t);
    }

    public CallWrapException(Response.Status httpStatus, String msg) {
        this(msg);
        this.httpStatusCode = httpStatus;
    }

    public CallWrapException(Response.Status httpStatus, String msg, Throwable t) {
        this(msg, t);
        this.httpStatusCode = httpStatus;
    }

    public CallWrapException(String errorCode, String msg) {
        super(msg, errorCode, ErrorCategory.CALL_WRAP);
    }

    public CallWrapException(String errorCode, String msg, Throwable t) {
        super(msg, errorCode, ErrorCategory.CALL_WRAP, t);
    }
}
