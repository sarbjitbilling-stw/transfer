package uk.co.stwater.api.callwrap;

import org.apache.commons.lang3.StringUtils;

import io.swagger.model.ContactEvent;
import io.swagger.model.RefData;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;

public class CallWrapContactEventBuilder extends BaseContactEventBuilder {
    private final CallWrapCustomerContact customerContact;
    private final CallWrapIncident mainIncident;

    public CallWrapContactEventBuilder(CallWrapCustomerContact customerContact, CallWrapIncident mainIncident) {
        this.customerContact = customerContact;
        this.mainIncident = mainIncident;
    }

    @Override
    public ContactEvent build() {
        // @formatter:off
        ContactEvent contactEvent = new ContactEvent()
                .accountId(customerContact.getAccountNumber().getAccountNumberAsLong())
                .legalEntityNo(customerContact.getLegalEntityNo())
                .propertyId(0L)
                .resolution(new RefData().code(customerContact.getResolution()))
                .contactPackageId(customerContact.getContactPackageId())
                .contactAssignedTime(toUkOffsetDateTime(customerContact.getContactDateTime()).toLocalDate())
                // reference data code that target converts into String
                .contactMethod(customerContact.getContactMethod())
                .contactType(new RefData().code(customerContact.getContactType()))
                .contactSubType(new RefData().code(customerContact.getContactSubType()))
                .contactInitiatedBy(new RefData().code(customerContact.getInitiator()))
                .substituteRespFlag(toStringYN(customerContact.getSubsetResponseMade(), TARGET_NO))
                .repeatReqFlag(toStringYN(customerContact.getRepeatCallChase()))
                .complaintReceivedFlag(toStringYN(customerContact.getComplaint()))
                .empNum(customerContact.getEmployeeNumber())
                .orgNum(customerContact.getOrganisationNumber());
        // @formatter:on

        if (mainIncident != null) {
            contactEvent.setRootCauseType(new RefData().code(mainIncident.getContactReason()));
        }

        if (StringUtils.isNotEmpty(customerContact.getResolution())) {
            contactEvent.setContactResolvedTime(getCurrentDate());
        }

        if (StringUtils.isNotEmpty(customerContact.getActivityTypeCode())) {
            contactEvent.setActTypeCode(customerContact.getActivityTypeCode());
        }

        if (StringUtils.isNotEmpty(customerContact.getActivityPriority())) {
            contactEvent.setActPriority(new RefData().code(customerContact.getActivityPriority()));
        }

        if (StringUtils.isNotEmpty(customerContact.getActivityQueueSourceCode())) {
            contactEvent.setActQueueSourceCode(new RefData().code(customerContact.getActivityQueueSourceCode()));
        }

        if (customerContact.getDueDate() != null) {
            contactEvent.setDueDate(customerContact.getDueDate().toLocalDate());
        }

        setResolutionFields(contactEvent, customerContact.getResolution());

        return contactEvent;
    }
}
