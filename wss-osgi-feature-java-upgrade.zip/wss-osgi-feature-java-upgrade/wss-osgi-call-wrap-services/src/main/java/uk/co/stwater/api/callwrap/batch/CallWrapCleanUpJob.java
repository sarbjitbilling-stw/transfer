package uk.co.stwater.api.callwrap.batch;

import javax.inject.Inject;
import javax.inject.Singleton;

import org.apache.aries.blueprint.annotation.service.Service;
import org.apache.aries.blueprint.annotation.service.ServiceProperty;
import org.apache.karaf.scheduler.Job;
import org.apache.karaf.scheduler.JobContext;
import org.apache.karaf.scheduler.Scheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.callwrap.CallWrapService;

//@formatter:off
@Service(classes = Job.class, properties = {
        @ServiceProperty(name = Scheduler.PROPERTY_SCHEDULER_NAME, values = "CallWrapCleanUpJob"),
        // daily at midnight
        @ServiceProperty(name = Scheduler.PROPERTY_SCHEDULER_EXPRESSION, values = "0 0 0 * * ?") 
})
//@formatter:on
@Singleton
public class CallWrapCleanUpJob implements Job {
    private static final Logger LOG = LoggerFactory.getLogger(CallWrapCleanUpJob.class);

    @Inject
    private CallWrapService callWrapService;

    @Override
    public void execute(JobContext context) {
        LOG.info("Starting call wrap clean up job");
        callWrapService.deleteExpiredProcessedRequests();
        LOG.info("Call wrap clean up job finished");
    }
}
