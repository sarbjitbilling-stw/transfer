package uk.co.stwater.api.callwrap;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import io.swagger.model.ContactEvent;
import io.swagger.model.RefData;

public abstract class BaseContactEventBuilder {
    protected static final ZoneId ZONE_ID_UK = ZoneId.of("Europe/London");

    public static final String ACTIVITY_QUEUE_SOURCE_CODE_CONTACT = "CNTCT";
    public static final String RESOLUTION_NOT_RESOLVED = "NOTRESOLVED";

    public static final String TARGET_NO = "N";
    public static final String TARGET_YES = "Y";

    public abstract ContactEvent build();

    protected void setResolutionFields(ContactEvent contactEvent, String resolution) {
        // if resolution exists then point of contact is treated as resolved
        contactEvent.setIsPointOfContactResolved(StringUtils.isNotEmpty(resolution));

        if (RESOLUTION_NOT_RESOLVED.equals(resolution)) {
            contactEvent.setIsPointOfContactResolved(false);
            contactEvent.setActQueueSourceCode(new RefData().code(ACTIVITY_QUEUE_SOURCE_CODE_CONTACT));
            contactEvent.setResolution(null);
        }
    }

    protected LocalDate getCurrentDate() {
        return LocalDate.now();
    }

    protected String toStringYN(Boolean bool) {
        return toStringYN(bool, null);
    }

    protected String toStringYN(Boolean bool, String nullString) {
        return BooleanUtils.toString(bool, TARGET_YES, TARGET_NO, nullString);
    }

    protected OffsetDateTime toUkOffsetDateTime(LocalDateTime localDateTime) {
        return ZonedDateTime.of(localDateTime, ZONE_ID_UK).toOffsetDateTime();
    }
}
