package uk.co.stwater.api.callwrap;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.io.IOUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.model.ContactEvent;
import io.swagger.model.RefData;
import uk.co.stwater.api.callwrap.model.AqContactEventRequest;
import uk.co.stwater.api.dao.callwrap.CallWrapCustomerContactDao;
import uk.co.stwater.api.dao.callwrap.CallWrapIncidentsDao;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;
import uk.co.stwater.api.dao.callwrap.entity.ContactReasonStatus;
import uk.co.stwater.api.dao.callwrap.entity.CustomerContactStatus;
import uk.co.stwater.api.osgi.cache.Cacheable;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.template.string.DynamicPlainStringTemplateService;
import uk.co.stwater.iib.client.api.contactevent.ContactEventClient;

@Named
@OsgiServiceProvider(classes = { CallWrapService.class })
public class CallWrapServiceImpl implements CallWrapService {
    private static final Logger LOG = LoggerFactory.getLogger(CallWrapServiceImpl.class);

    static final int CUSTOMER_CONTACT_EXPIRE_DAYS = 30;
    static final String NOTES_TYPE_INITIAL_COMMENTS = "INIT";
    static final int NOTES_MAX_LENGTH = 4_000;

    private static final Pattern SPECIAL_CHARS_SINGLE_SMART_QUOTE = Pattern.compile("[\u2018\u2019\u201A]");
    private static final Pattern SPECIAL_CHARS_DOUBLE_SMART_QUOTE = Pattern.compile("[\u201C\u201D\u201E]");
    private static final Pattern SPECIAL_CHARS_DASHES = Pattern.compile("[\u2013\u2014]");
    private static final Pattern SPECIAL_CHARS_SPACES = Pattern.compile("[\u02DC\u00A0]");

    private static final DateTimeFormatter customerContactNameDateTimeFormatter = DateTimeFormatter
            .ofPattern("ddMMyyyy - hh:mm:ss");

    /**
     * ThreadPool used for updating call wrap DB entries.
     * 
     * <p>
     * Used with request {@link CompletableFuture}'s, to avoid blocking either the
     * web client or {@link ForkJoinPool#commonPool()} pools with I/O operations.
     */
    private static final ExecutorService callWrapDbUpdateExecutorService = Executors.newFixedThreadPool(2);

    @Inject
    @OsgiService
    private ContactEventClient contactEventClient;

    @Inject
    @OsgiService
    private CallWrapCustomerContactDao callWrapCustomerContactDao;

    @Inject
    @OsgiService
    private CallWrapIncidentsDao callWrapIncidentsDao;

    @Inject
    @OsgiService
    private DynamicPlainStringTemplateService templateService;

    @Override
    public Optional<CallWrapCustomerContact> getCustomerContact(Long id) {
        return callWrapCustomerContactDao.findById(id);
    }

    @Override
    public CallWrapCustomerContact create(CallWrapCustomerContact customerContact, String authToken) {
        // setup default initial customer contact fields
        String name = String.format("Customer Contact - %s",
                customerContactNameDateTimeFormatter.format(getCurrentDateTime()));
        customerContact.setName(name);
        customerContact.setContactId(customerContact.getLegalEntityNo());
        customerContact.setContactStatus(CustomerContactStatus.NEW);
        customerContact.setSaveAsMemo(false);
        customerContact.setSubsetResponseMade(false);
        customerContact.setCreatedBy(authToken);

        LOG.info("Creating customer contact, accountNumber={} legalEntityNo={}", customerContact.getAccountNumber(),
                customerContact.getLegalEntityNo());
        CallWrapCustomerContact createdCustomerContact = callWrapCustomerContactDao.save(customerContact);
        LOG.debug("Customer contact customerContactId={} created", createdCustomerContact.getId());

        return createdCustomerContact;
    }

    @Override
    public CallWrapCustomerContact update(CallWrapCustomerContact customerContact, String authToken) {
        if (customerContact.getContactStatus() == CustomerContactStatus.SUBMITTED) {
            LOG.info("Submitting customer contact to Target, id={}", customerContact.getId());
            return submitContactEvent(customerContact, authToken);
        } else {
            LOG.info("Updating customer contact to details, id={}", customerContact.getId());
            return updateRecord(customerContact);
        }
    }

    private CallWrapCustomerContact submitContactEvent(CallWrapCustomerContact customerContact, String authToken) {
        customerContact.validateForTargetUpload();

        LOG.info("Building notes for customer contact, id={}", customerContact.getId());
        List<CallWrapIncident> incidents = callWrapIncidentsDao.getIncidentsForCustomer(customerContact.getId());
        // @formatter:off
        CallWrapIncident mainIncident = incidents.stream()
                .filter(incident -> incident.getIncidentId() == customerContact.getCaseReference())
                .findFirst()
                .orElseThrow(() -> new CallWrapException("Main incident not found for customer contact"));
        // @formatter:on
        String builtNotes = buildContactEventNotes(customerContact, incidents, mainIncident);
        customerContact.setBuiltNotes(builtNotes);

        CallWrapCustomerContact updatedCustomerContact = updateRecord(customerContact);

        sendContactEventToTarget(updatedCustomerContact, mainIncident, authToken);

        return updatedCustomerContact;
    }

    private CompletableFuture<CallWrapCustomerContact> sendContactEventToTarget(CallWrapCustomerContact customerContact,
            CallWrapIncident mainIncident, String authToken) {

        LOG.debug("Building ContactEvent for customer contact, id={}", customerContact.getId());
        CallWrapContactEventBuilder contactEventBuilder = new CallWrapContactEventBuilder(customerContact,
                mainIncident);
        ContactEvent contactEvent = contactEventBuilder.build();

        LOG.info("Sending customer contact details to Target as ContactEvent, id={}", customerContact.getId());
        CompletableFuture<ContactEvent> contactEventFuture = contactEventClient.patchAsync(contactEvent, authToken);

        // Target processing can take 4sec so done async for CMP call wrap performance
        return contactEventFuture.thenCompose(createdContactEvent -> {
            LOG.info("Sending customer contact notes to Target, id={} targetContactId={}",
                    customerContact.getId(), createdContactEvent.getContactId());
            customerContact.setContactEventId(createdContactEvent.getContactId());

            LOG.debug("Building notes ContactEvent for customer contact, id={}", customerContact.getId());
            ContactEvent notesContactEvent = buildContactEventNotes(customerContact);

            // Require 2 separate calls to the Target ContactEvent endpoint, as their are 2
            // separate Target SI's connected to the same endpoint. If contactId is supplied
            // the notes update SI is called whereas if it is not the SI to update the other
            // contact event details is called.
            return contactEventClient.patchAsync(notesContactEvent, authToken);
        }).thenApplyAsync(notesUpdateContactEvent -> {
            LOG.info("Storing customer contact Target upload details, id={} targetContactId={}",
                    customerContact.getId(), customerContact.getContactEventId());
            customerContact.setContactStatus(CustomerContactStatus.UPLOADED_TO_TARGET);

            CallWrapCustomerContact updatedCustomerContact = callWrapCustomerContactDao.update(customerContact);

            callWrapIncidentsDao.updateReasonStatusesForCustomerContact(customerContact.getId(),
                    ContactReasonStatus.UPLOADED_TO_TARGET);

            return updatedCustomerContact;
            // Done in callWrapDbUpdateExecutorService to release web client thread
        }, callWrapDbUpdateExecutorService).exceptionally(t -> {
            LOG.error("Error creating ContactEvent for customer contact, id={}", customerContact.getId(), t);
            return null;
        });
    }

    private CallWrapCustomerContact updateRecord(CallWrapCustomerContact customerContact) {
        LOG.info("Updating customer contact, id={}", customerContact.getId());
        return callWrapCustomerContactDao.update(customerContact);
    }

    ContactEvent buildContactEventNotes(CallWrapCustomerContact customerContact) {
        return buildContactEventNotes(customerContact.getContactEventId(), customerContact.getBuiltNotes());
    }

    ContactEvent buildContactEventNotes(String contactEventId, String notes) {
        String sanitisedNotes = replaceNotesSpecialCharacters(notes);

        if (sanitisedNotes.length() > NOTES_MAX_LENGTH) {
            LOG.info("Truncating ContactEvent notes as larger than Target max size");
            sanitisedNotes = sanitisedNotes.substring(0, NOTES_MAX_LENGTH);
        }

        // @formatter:off
        return new ContactEvent()
                .contactId(contactEventId)
                .notesType(new RefData().code(NOTES_TYPE_INITIAL_COMMENTS))
                .notesDescription(sanitisedNotes);
        // @formatter:on
    }

    private String replaceNotesSpecialCharacters(String notes) {
        LOG.debug("Replacing Notes special characters");
        String sanatisedNotes = notes;

        sanatisedNotes = SPECIAL_CHARS_SINGLE_SMART_QUOTE.matcher(sanatisedNotes).replaceAll("'");
        sanatisedNotes = SPECIAL_CHARS_DOUBLE_SMART_QUOTE.matcher(sanatisedNotes).replaceAll("\"");
        // ellipsis
        sanatisedNotes = sanatisedNotes.replace("\u2026", "...");
        sanatisedNotes = SPECIAL_CHARS_DASHES.matcher(sanatisedNotes).replaceAll("-");
        // circumflex
        sanatisedNotes = sanatisedNotes.replace("\u02C6", "^");
        // open angle bracket
        sanatisedNotes = sanatisedNotes.replace("\u2039", "<");
        // close angle bracket
        sanatisedNotes = sanatisedNotes.replace("\u203A", ">");
        sanatisedNotes = SPECIAL_CHARS_SPACES.matcher(sanatisedNotes).replaceAll(" ");

        return sanatisedNotes;
    }

    String buildContactEventNotes(CallWrapCustomerContact customerContact, List<CallWrapIncident> incidents,
            CallWrapIncident mainReason) {
        String template = getContactEventNotesTemplate();

        Map<String, Object> params = new HashMap<>();
        params.put("customerContact", customerContact);
        params.put("incidentList", incidents);
        params.put("mainReason", mainReason);

        return templateService.render(template, params);
    }

    @Cacheable(timeout = 1, timeUnit = TimeUnit.DAYS, level = 100)
    private String getContactEventNotesTemplate() {
        URL longTextTemplate = CallWrapServiceImpl.class.getResource("/call-wrap/contact-event-notes.twig");
        if (longTextTemplate == null) {
            throw new STWTechnicalException("Failed to find contact event notes template");
        }

        try (InputStream is = longTextTemplate.openStream()) {
            return IOUtils.toString(is, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new CallWrapException("Failed to read contact event notes template", e);
        }
    }

    @Override
    public Optional<CallWrapIncident> getIncident(Long incidentId) {
        return callWrapIncidentsDao.getIncident(incidentId);
    }

    @Override
    public CallWrapIncident createIncident(CallWrapIncident incident) {
        return callWrapIncidentsDao.createIncident(incident);
    }

    @Override
    public void updateIncident(CallWrapIncident incident) {
        // create Incident from IncidentRequest

        callWrapIncidentsDao.updateIncident(incident);
    }

    @Override
    public List<CallWrapIncident> getIncidentsForCustomerContact(Long customerContactId) {
        return callWrapIncidentsDao.getIncidentsForCustomer(customerContactId);
    }

    @Override
    public void deleteExpiredProcessedRequests() {
        LocalDateTime maxContactTime = getCurrentDateTime().minusDays(CUSTOMER_CONTACT_EXPIRE_DAYS);
        
        int deletedIncidents = callWrapIncidentsDao.deleteOlderThan(maxContactTime);
        LOG.info("Deleted {} expired customer contact incidents", deletedIncidents);
        
        int deletedCustomerContacts = callWrapCustomerContactDao.deleteOlderThan(maxContactTime);
        LOG.info("Deleted {} expired customer contacts", deletedCustomerContacts);
    }

    LocalDateTime getCurrentDateTime() {
        return LocalDateTime.now();
    }

    @Override
    public ContactEvent createAqContactEvent(AqContactEventRequest createAqContactEvent, String authToken) {
        LOG.info("Create ContactEvent with AQ type {} in Target for accountNumber={} legalEntityNo={}",
                createAqContactEvent.getActivityTypeCode(), createAqContactEvent.getAccountNumber(),
                createAqContactEvent.getLegalEntityNo());
        createAqContactEvent.validate();
        ContactEvent contactEvent = createAqContactEvent.build();
        ContactEvent createdContactEvent = contactEventClient.patch(contactEvent, authToken);

        LOG.info("Adding Notes to ContactEvent {}", createdContactEvent.getContactId());
        ContactEvent updateNotesContactEvent = buildContactEventNotes(createdContactEvent.getContactId(),
                createAqContactEvent.getNotes());
        // returns blank response
        contactEventClient.patch(updateNotesContactEvent, authToken);

        // will just contain contactId
        return createdContactEvent;
    }

}
