package uk.co.stwater.api.callwrap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.time.LocalDate;
import java.time.ZonedDateTime;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import io.swagger.model.ContactEvent;
import io.swagger.model.RefData;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;

public class CallWrapContactEventBuilderTest {
    private static final LocalDate CURRENT_DATE = LocalDate.of(2020, 5, 12);

    @Test
    public void buildWithOptionalFields() {
        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContactWithBuiltNotes();
        customerContact.setResolution(CallWrapContactEventBuilder.RESOLUTION_NOT_RESOLVED);
        CallWrapIncident mainIncident = CallWrapTestHelper.buildCallWrapIncident();
        CallWrapContactEventBuilder builder = setupCallWrapContactEventBuilder(customerContact, mainIncident);

        ContactEvent actual = builder.build();

        validateContactEvent(customerContact, mainIncident, actual);
    }

    @Test
    public void buildWithoutOptionalFields() {
        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContactWithBuiltNotes();
        customerContact.setResolution(null);
        customerContact.setActivityTypeCode(null);
        customerContact.setActivityPriority(null);
        customerContact.setActivityQueueSourceCode(null);
        customerContact.setDueDate(null);
        customerContact.setResolution(null);
        CallWrapIncident mainIncident = null;
        CallWrapContactEventBuilder builder = setupCallWrapContactEventBuilder(customerContact, mainIncident);

        ContactEvent actual = builder.build();

        validateContactEvent(customerContact, mainIncident, actual);
    }

    private CallWrapContactEventBuilder setupCallWrapContactEventBuilder(CallWrapCustomerContact customerContact,
            CallWrapIncident mainIncident) {
        CallWrapContactEventBuilder builder = spy(new CallWrapContactEventBuilder(customerContact, mainIncident));

        doReturn(CURRENT_DATE).when(builder).getCurrentDate();

        return builder;
    }

    private void validateContactEvent(CallWrapCustomerContact customerContact, CallWrapIncident mainIncident,
            ContactEvent actual) {
        assertEquals((Long) customerContact.getAccountNumber().getAccountNumberAsLong(), actual.getAccountId());
        assertEquals(customerContact.getLegalEntityNo(), actual.getLegalEntityNo());
        assertEquals((Long) 0L, actual.getPropertyId());
        // resolution validated at end of method with NOTRESOLVED logic
        assertEquals(customerContact.getContactPackageId(), actual.getContactPackageId());
        LocalDate expectedAssignedTime = ZonedDateTime
                .of(customerContact.getContactDateTime(), CallWrapContactEventBuilder.ZONE_ID_UK).toOffsetDateTime()
                .toLocalDate();
        assertEquals(expectedAssignedTime, actual.getContactAssignedTime());
        assertNull(actual.getUserName());
        assertEquals(customerContact.getContactMethod(), actual.getContactMethod());
        validateRefData(customerContact.getContactType(), actual.getContactType());
        validateRefData(customerContact.getContactSubType(), actual.getContactSubType());
        validateRefData(customerContact.getInitiator(), actual.getContactInitiatedBy());
        validateYN(customerContact.getRepeatCallChase(), actual.getRepeatReqFlag(), CallWrapContactEventBuilder.TARGET_NO);
        validateYN(customerContact.getComplaint(), actual.getComplaintReceivedFlag());
        assertEquals(customerContact.getEmployeeNumber(), actual.getEmpNum());
        assertEquals(customerContact.getOrganisationNumber(), actual.getOrgNum());
        

        if (mainIncident != null) {
            validateRefData(mainIncident.getContactReason(), actual.getRootCauseType());
        }

        if (StringUtils.isNotEmpty(customerContact.getResolution())) {
            assertEquals(CURRENT_DATE, actual.getContactResolvedTime());
        }

        if (StringUtils.isNotEmpty(customerContact.getActivityTypeCode())) {
            assertEquals(customerContact.getActivityTypeCode(), actual.getActTypeCode());
        }

        if (StringUtils.isNotEmpty(customerContact.getActivityPriority())) {
            validateRefData(customerContact.getActivityPriority(), actual.getActPriority());
        }

        if (customerContact.getDueDate() != null) {
            assertEquals(customerContact.getDueDate().toLocalDate(), actual.getDueDate());
        }

        if (CallWrapContactEventBuilder.RESOLUTION_NOT_RESOLVED.equals(customerContact.getResolution())) {
            assertFalse(actual.getIsPointOfContactResolved());
            validateRefData(CallWrapContactEventBuilder.ACTIVITY_QUEUE_SOURCE_CODE_CONTACT,
                    actual.getActQueueSourceCode());
            assertNull(actual.getResolution());
        } else {
            assertEquals(StringUtils.isNotEmpty(customerContact.getResolution()), actual.getIsPointOfContactResolved());
            validateRefData(customerContact.getResolution(), actual.getResolution());
            if (StringUtils.isNotEmpty(customerContact.getActivityQueueSourceCode())) {
                validateRefData(customerContact.getActivityQueueSourceCode(), actual.getActQueueSourceCode());
            }
        }
    }

    private void validateRefData(String expectedCode, RefData actual) {
        assertEquals(expectedCode, actual.getCode());
    }

    private void validateYN(Boolean expected, String actual) {
        validateYN(expected, actual, null);
    }

    private void validateYN(Boolean expected, String actual, String nullValue) {
        String expectedString = BooleanUtils.toString(expected, CallWrapContactEventBuilder.TARGET_YES,
                CallWrapContactEventBuilder.TARGET_NO, nullValue);
        assertEquals(expectedString, actual);
    }

}
