package uk.co.stwater.api.callwrap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import io.swagger.model.ContactEvent;
import uk.co.stwater.api.callwrap.model.AqContactEventRequest;
import uk.co.stwater.api.dao.callwrap.CallWrapCustomerContactDao;
import uk.co.stwater.api.dao.callwrap.CallWrapIncidentsDao;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;
import uk.co.stwater.api.template.string.DynamicPlainStringTemplateService;
import uk.co.stwater.api.template.string.JtwigDynamicPlainStringTemplateService;
import uk.co.stwater.iib.client.api.contactevent.ContactEventClient;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CallWrapServiceImplTest {
    private static final String AUTH_TOKEN = "agentId";
    private static final LocalDateTime CURRENT_DATE_TIME = LocalDateTime.of(2020, 4, 7, 13, 12);

    @Mock
    private ContactEventClient contactEventClient;

    @Mock
    private CallWrapCustomerContactDao callWrapCustomerContactDao;

    @Mock
    private CallWrapIncidentsDao callWrapIncidentsDao;

    @Spy
    private DynamicPlainStringTemplateService templateService = new JtwigDynamicPlainStringTemplateService();

    @Spy
    @InjectMocks
    private CallWrapServiceImpl callWrapService = new CallWrapServiceImpl();

    @Captor
    private ArgumentCaptor<ContactEvent> contactEventCaptor;

    @Before
    public void beforeEach() {
        doReturn(CURRENT_DATE_TIME).when(callWrapService).getCurrentDateTime();
    }

    @Test
    public void buildContactEventNotesSpecialCharacters() {
        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContact();
        customerContact.setBuiltNotes(
                "\u2018\u2019\u201A\u201C\u201D\u201E\u2026\u2013\u2014\u02C6\u2039\u203A\u02DC\u00A0");
        String expectedNotes = "'''\"\"\"...--^<>  ";

        ContactEvent actual = callWrapService.buildContactEventNotes(customerContact);

        assertEquals(CallWrapServiceImpl.NOTES_TYPE_INITIAL_COMMENTS, actual.getNotesType().getCode());
        assertEquals(expectedNotes, actual.getNotesDescription());
    }

    @Test
    public void buildContactEventNotes() throws IOException {
        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContact();
        CallWrapIncident mainIncident = CallWrapTestHelper.buildCallWrapIncident(3L, "incident 3",
                "sample description 3");
        customerContact.setCaseReference(mainIncident.getIncidentId());
        List<CallWrapIncident> incidents = Arrays.asList(
                CallWrapTestHelper.buildCallWrapIncident(1L, "incident 1", "sample description 1"),
                CallWrapTestHelper.buildCallWrapIncident(2L, "incident 2", "sample description 2"),
                mainIncident,
                CallWrapTestHelper.buildCallWrapIncident(4L, "incident 4", "sample description 4"));
        String expectedNotes = CallWrapTestHelper.readFromClasspathFile("/templates/expected/contact-event-notes.txt");

        String actual = callWrapService.buildContactEventNotes(customerContact, incidents, mainIncident);

        assertEquals(expectedNotes, actual);
    }

    @Test
    public void testGetIncidents() {

        CallWrapIncident incident = CallWrapTestHelper.buildCallWrapIncident(1L, "incident 1", "sample description 1");

        when(callWrapIncidentsDao.getIncident(1L)).thenReturn(Optional.of(incident));

        Optional<CallWrapIncident> result = callWrapService.getIncident(1L);

        assertTrue(result.isPresent());
        assertEquals(incident, result.get());
    }

    @Test
    public void testCreateIncident() {
        CallWrapIncident callWrapIncident = CallWrapTestHelper.buildCallWrapIncident(1L, "incident 1",
                "sample description 1");
        CallWrapIncident callWrapIncidentResponse = CallWrapTestHelper.buildCallWrapIncident(1000L, "incident 1",
                "sample description 1");

        when(callWrapIncidentsDao.createIncident(callWrapIncident)).thenReturn(callWrapIncidentResponse);

        CallWrapIncident response = callWrapService.createIncident(callWrapIncident);

        assertNotNull(response);

        assertEquals(1000L, response.getIncidentId());
    }

    @Test
    public void testGetIncidentsForCustomer() {
        List<CallWrapIncident> incidents = Arrays.asList(
                CallWrapTestHelper.buildCallWrapIncident(1L, "incident 1", "sample description 1"),
                CallWrapTestHelper.buildCallWrapIncident(2L, "incident 2", "sample description 2"),
                CallWrapTestHelper.buildCallWrapIncident(3L, "incident 3", "sample description 3"));

        when(callWrapIncidentsDao.getIncidentsForCustomer(12432L)).thenReturn(incidents);

        List<CallWrapIncident> responses = callWrapService.getIncidentsForCustomerContact(12432L);

        assertNotNull(responses);

        verify(callWrapIncidentsDao).getIncidentsForCustomer(12432L);
    }

    @Test
    public void testUpdateIncident() {

        CallWrapIncident incident = CallWrapTestHelper.buildCallWrapIncident(1L, "incident 1", "sample description 1");
        
        callWrapService.updateIncident(incident);

        verify(callWrapIncidentsDao).updateIncident(incident);
    }

    @Test
    public void testCreateCustomerContact() {

        String authToken = "";

        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContact();
        when(callWrapCustomerContactDao.save(customerContact)).thenReturn(customerContact);

        CallWrapCustomerContact createdCustomerContact = callWrapService.create(customerContact, authToken);

        assertNotNull(createdCustomerContact);

    }

    @Test
    public void testGetCustomerContact() {

        Long id = 1L;

        Optional<CallWrapCustomerContact> customerContact = Optional
                .of(CallWrapTestHelper.buildCallWrapCustomerContact());

        when(callWrapCustomerContactDao.findById(1L)).thenReturn(customerContact);

        Optional<CallWrapCustomerContact> createdCustomerContact = callWrapService.getCustomerContact(id);

        assertNotNull(createdCustomerContact);

        verify(callWrapCustomerContactDao).findById(1L);

    }

    @Test
    public void deleteExpiredProcessedRequests() {
        LocalDateTime expectedMaxContactTime = CURRENT_DATE_TIME
                .minusDays(CallWrapServiceImpl.CUSTOMER_CONTACT_EXPIRE_DAYS);

        callWrapService.deleteExpiredProcessedRequests();

        verify(callWrapIncidentsDao).deleteOlderThan(expectedMaxContactTime);
        verify(callWrapCustomerContactDao).deleteOlderThan(expectedMaxContactTime);
    }

    @Test
    public void createAqContactEvent() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        ContactEvent createContactEventRequest = aqContactEvent.build();
        AqContactEventRequest aqContactEventSpy = spy(aqContactEvent);
        String contactId = "24326342";
        ContactEvent createContactEvent = new ContactEvent().contactId(contactId);

        doReturn(createContactEventRequest).when(aqContactEventSpy).build();
        when(contactEventClient.patch(contactEventCaptor.capture(), eq(AUTH_TOKEN)))
                .thenReturn(createContactEvent).thenReturn(new ContactEvent());

        ContactEvent actual = callWrapService.createAqContactEvent(aqContactEventSpy, AUTH_TOKEN);

        assertEquals(2, contactEventCaptor.getAllValues().size());
        ContactEvent createInput = contactEventCaptor.getAllValues().get(0);
        assertSame(createContactEventRequest, createInput);
        ContactEvent updateNotesInput = contactEventCaptor.getAllValues().get(1);
        assertEquals(contactId, updateNotesInput.getContactId());
        assertEquals(contactId, actual.getContactId());
    }

}
