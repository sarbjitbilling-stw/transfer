package uk.co.stwater.api.callwrap;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.IOUtils;

import uk.co.stwater.api.callwrap.model.AqContactEventRequest;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;
import uk.co.stwater.api.dao.callwrap.entity.ContactReasonStatus;
import uk.co.stwater.api.dao.callwrap.entity.ContactReasonType;
import uk.co.stwater.api.dao.callwrap.entity.CustomerContactStatus;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

public class CallWrapTestHelper {

    private CallWrapTestHelper() {
    }

    public static String readFromClasspathFile(String classpath) throws IOException {
        try (InputStream is = CallWrapTestHelper.class.getResourceAsStream(classpath)) {
            return IOUtils.toString(is, StandardCharsets.UTF_8);
        }
    }

    public static CallWrapCustomerContact buildCallWrapCustomerContactWithBuiltNotes() {
        CallWrapCustomerContact customerContact = buildCallWrapCustomerContact();

        customerContact.setBuiltNotes("example of built notes");

        return customerContact;
    }

    public static CallWrapCustomerContact buildCallWrapCustomerContact() {
        return buildCallWrapCustomerContact(2314532L);
    }

    public static CallWrapCustomerContact buildCallWrapCustomerContact(Long id) {
        CallWrapCustomerContact customerContact = new CallWrapCustomerContact();

        customerContact.setId(id);
        customerContact.setName("Customer Contact - MR RICHARD AAAAAA - BILLING - BILLING  - 20200423133907263");
        customerContact.setContactId(431004805L);
        customerContact.setContactMethod("11");
        customerContact.setContactType("3");
        customerContact.setContactSubType("1");
        customerContact.setContactStatus(CustomerContactStatus.SUBMITTED);
        customerContact.setContactDateTime(LocalDateTime.of(2020, 11, 13, 14, 58));
        customerContact.setCaseReference(4L);
        customerContact.setInitiator("3");
        customerContact.setSaveAsMemo(false);
        customerContact.setSubsetResponseMade(false);
        customerContact.setAccountNumber(new TargetAccountNumber(604003564, null));
        customerContact.setCreatedBy("John Smith");
        customerContact.setComplaint(false);
        customerContact.setRepeatCallChase(false);
        customerContact.setLegalEntityNo(431004805L);
        customerContact.setAgentNotes("Sample custom agent notes");
        customerContact.setSmsPromptDate(LocalDateTime.of(2020, 12, 2, 0, 0));
        customerContact.setResolution("sample resoulition");
        customerContact.setContactPackageId("2036");
        customerContact.setEmployeeNumber(421L);
        customerContact.setOrganisationNumber(214L);
        customerContact.setActivityTypeCode("act type code");
        customerContact.setActivityPriority("3");
        customerContact.setActivityQueueSourceCode("44");
        customerContact.setDueDate(LocalDateTime.of(2021, 2, 3, 12, 0));

        return customerContact;
    }

    public static CallWrapIncident buildCallWrapIncident(Long id, String title, String description) {
        CallWrapIncident incident = buildCallWrapIncident(title, description);

        incident.setIncidentId(id);

        return incident;
    }

    public static CallWrapIncident buildCallWrapIncident(String title, String description) {
        CallWrapIncident incident = buildCallWrapIncident();

        incident.setTitle(title);
        incident.setDescription(description);

        return incident;
    }

    public static CallWrapIncident buildCallWrapIncident() {
        CallWrapIncident incident = new CallWrapIncident();

        incident.setIncidentId(231L);
        incident.setCustomerContactId(12432);
        incident.setCustomerId(234324L);
        incident.setReasonType(ContactReasonType.MANUAL);
        incident.setContactReasonStatus(ContactReasonStatus.NEW);
        incident.setContactReason("ContactReason");
        incident.setTitle("Change of Personal Details (Customer/Account/Property)");
        incident.setDescription(
                "Email:  What are assessed charges? was sent to MR RICHARD AAAAAA at test@severntrent.co.uk.  Email:  data summary:  [Email : What are assessed charges?]  Account Number: 6040035642;");

        return incident;
    }

    public static List<CallWrapIncident> buildCallWrapIncidentList() {
        return Arrays.asList(buildCallWrapIncident("incident 1", "sample description 1"),
                buildCallWrapIncident("incident 2", "sample description 2"),
                buildCallWrapIncident("incident 3", "aample description 3"));
    }

    public static AqContactEventRequest buildAqContactEventRequest() {
        AqContactEventRequest aqContactEvent = new AqContactEventRequest();

        aqContactEvent.setAccountNumber(new TargetAccountNumber("6500494015"));
        aqContactEvent.setLegalEntityNo(650039506L);
        aqContactEvent.setContactType("3");
        aqContactEvent.setContactMethod("7");
        aqContactEvent.setContactInitiatedBy("3");
        aqContactEvent.setContactSubType("419");
        aqContactEvent.setResolution(BaseContactEventBuilder.RESOLUTION_NOT_RESOLVED);
        aqContactEvent.setComplaint(false);
        aqContactEvent.setOrganisationNumber(200457L);
        aqContactEvent.setActivityTypeCode("SOAC");
        aqContactEvent.setActivityPriority("5");
        aqContactEvent.setDueDate(LocalDate.now());
        aqContactEvent.setRootCauseType("R060");
        aqContactEvent.setContactPackageId("2000992");
        aqContactEvent.setNotes("Sample notes");

        return aqContactEvent;
    }

}
