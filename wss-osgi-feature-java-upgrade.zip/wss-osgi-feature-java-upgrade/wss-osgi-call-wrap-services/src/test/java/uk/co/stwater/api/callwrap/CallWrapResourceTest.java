package uk.co.stwater.api.callwrap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import javax.ws.rs.core.Response;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import io.swagger.model.ContactEvent;
import uk.co.stwater.api.callwrap.model.AqContactEventRequest;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapCustomerContact;
import uk.co.stwater.api.dao.callwrap.entity.CallWrapIncident;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CallWrapResourceTest {
    private static final String AUTH_TOKEN = "agentId";

    @Mock
    private CallWrapService callWrapService;

    @Spy
    @InjectMocks
    private CallWrapResource callWrapResource = new CallWrapResource();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Before
    public void beforeEach() {
        when(callWrapResource.getTargetAuthToken()).thenReturn(AUTH_TOKEN);
    }

    @Test
    public void getCustomerContact() {
        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContact();

        when(callWrapService.getCustomerContact(customerContact.getId())).thenReturn(Optional.of(customerContact));

        Response actual = callWrapResource.getCustomerContact(customerContact.getId());

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(customerContact, actual.getEntity());
    }

    @Test
    public void getCustomerContactNotFound() {
        long id = 123L;

        when(callWrapService.getCustomerContact(id)).thenReturn(Optional.empty());

        try {
            callWrapResource.getCustomerContact(id);
            fail("Not found exception not thrown");
        } catch (CallWrapException e) {
            assertEquals("CustomerContact not found for id", e.getMessage());
            assertEquals(Response.Status.NOT_FOUND, e.getHttpStatusCode());
        }
    }

    @Test
    public void getCustomerContactIncidents() {
        Long id = 1254325L;
        List<CallWrapIncident> incidents = CallWrapTestHelper.buildCallWrapIncidentList();

        when(callWrapService.getIncidentsForCustomerContact(id)).thenReturn(incidents);

        Response actual = callWrapResource.getCustomerContactIncidents(id);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(incidents, actual.getEntity());
    }

    @Test
    public void createCustomerContact() {
        CallWrapCustomerContact customerContact = mock(CallWrapCustomerContact.class);
        CallWrapCustomerContact createdCustomerContact = CallWrapTestHelper.buildCallWrapCustomerContact();

        when(callWrapService.create(customerContact, AUTH_TOKEN)).thenReturn(createdCustomerContact);

        Response actual = callWrapResource.createCustomerContact(customerContact);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(createdCustomerContact, actual.getEntity());

        InOrder inOrderVerification = inOrder(customerContact, callWrapService);
        inOrderVerification.verify(customerContact).validate();
        inOrderVerification.verify(callWrapService).create(customerContact, AUTH_TOKEN);
        inOrderVerification.verifyNoMoreInteractions();
    }

    @Test
    public void updateCustomerContact() {
        CallWrapCustomerContact customerContact = mock(CallWrapCustomerContact.class);
        when(customerContact.getId()).thenReturn(15324L);
        CallWrapCustomerContact updatedCustomerContact = CallWrapTestHelper.buildCallWrapCustomerContact();

        when(callWrapService.update(customerContact, AUTH_TOKEN)).thenReturn(updatedCustomerContact);

        Response actual = callWrapResource.updateCustomerContact(customerContact.getId(), customerContact);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(updatedCustomerContact, actual.getEntity());

        InOrder inOrderVerification = inOrder(customerContact, callWrapService);
        inOrderVerification.verify(customerContact).validate();
        inOrderVerification.verify(callWrapService).update(customerContact, AUTH_TOKEN);
        inOrderVerification.verifyNoMoreInteractions();
    }

    @Test
    public void updateCustomerContactIdMismatch() {
        expectedException.expect(CallWrapException.class);
        expectedException.expectMessage("customerContact.id does not match path id");

        CallWrapCustomerContact customerContact = CallWrapTestHelper.buildCallWrapCustomerContact();
        customerContact.setId(1L);

        callWrapResource.updateCustomerContact(2L, customerContact);
    }

    @Test
    public void getIncident() {
        long id = 123L;
        CallWrapIncident incident = CallWrapTestHelper.buildCallWrapIncident();

        when(callWrapService.getIncident(id)).thenReturn(Optional.of(incident));

        Response actual = callWrapResource.getIncident(id);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(incident, actual.getEntity());
    }

    @Test
    public void updateIncident() {
        CallWrapIncident incident = CallWrapTestHelper.buildCallWrapIncident();

        Response actual = callWrapResource.updateIncident(incident.getIncidentId(), incident);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());

        verify(callWrapService).updateIncident(incident);
    }

    @Test
    public void createIncident() {
        CallWrapIncident incident = CallWrapTestHelper.buildCallWrapIncident();
        CallWrapIncident createdIncident = CallWrapTestHelper.buildCallWrapIncident();

        when(callWrapService.createIncident(incident)).thenReturn(createdIncident);

        Response actual = callWrapResource.createIncident(incident);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(createdIncident, actual.getEntity());
    }

    @Test
    public void createContactEventWithAq() {
        AqContactEventRequest aqContactEvent = CallWrapTestHelper.buildAqContactEventRequest();
        ContactEvent createdContactEvent = new ContactEvent().contactId("56234325");

        when(callWrapService.createAqContactEvent(aqContactEvent, AUTH_TOKEN)).thenReturn(createdContactEvent);

        Response actual = callWrapResource.createContactEventWithAq(aqContactEvent);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertEquals(createdContactEvent, actual.getEntity());
    }

}
