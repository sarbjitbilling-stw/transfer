package uk.co.stwater.api.bill;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.model.payment.bill.Bill;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWBaseException;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

@Named(BillResource.BILL_RESOURCE)
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public class BillResource extends AbstractResource {

	private static final int INVALID_REQUEST_CODE = 400;

	static final String BILL_RESOURCE = "billResource";

	private static final String ACTION = "action";

	private static final String INVALID_REQUEST = "Invalid request.";

	private static final String CREATE = "create";

	private static final String SIMULATE = "simulate";

	private static final String VALIDATE = "validate";

	Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Inject
	private BillService billService;

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response createOrSimulate(Bill bill, @QueryParam(ACTION) String action) {
		try {
			if (!isBillRequestEmpty(bill)) {
				String authToken = getUserIdentity().getUsername();
				LOGGER.debug("authToken is {}", authToken);
				LOGGER.debug("Action for bill is : {}", action);

				if (StringUtils.isNotEmpty(action)) {
					switch (action) {
					case CREATE:
						Bill createdBill = billService.create(bill, authToken, action);
						return Response.status(Response.Status.CREATED).entity(createdBill).build();
					case SIMULATE:
						Bill simulatedBill = billService.simulate(bill, authToken, action);
						return Response.status(Response.Status.OK).entity(simulatedBill).build();
					}
				}
			}
		} catch (STWTechnicalException | STWBusinessException e) {
			ErrorDto errorDto = getBillServicesErrorDTO(e);
			LOGGER.warn("A response exception occurred {}", errorDto.toString());
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		}
		ErrorDto errorDto = new ErrorDto(ErrorCategory.BILL_SERVICES, INVALID_REQUEST_CODE, INVALID_REQUEST);
		LOGGER.warn("An exception occurred {}", errorDto.toString());
		return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
	}

	@PUT
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response validate(Bill bill) {
		try {
			if (!isBillRequestEmpty(bill)) {
				String authToken = getUserIdentity().getUsername();
				LOGGER.debug("authToken is {}", authToken);
				Bill validatedBill = billService.validate(bill, authToken, VALIDATE);
				return Response.status(Response.Status.OK).entity(validatedBill).build();
			}
		} catch (STWTechnicalException | STWBusinessException e) {
			ErrorDto errorDto = getBillServicesErrorDTO(e);
			LOGGER.warn("A response exception occurred {}", errorDto.toString());
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		}
		ErrorDto errorDto = new ErrorDto(ErrorCategory.BILL_SERVICES, INVALID_REQUEST_CODE, INVALID_REQUEST);
		LOGGER.warn("An exception occurred {}", errorDto.toString());
		return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
	}

	private ErrorDto getBillServicesErrorDTO(STWBaseException e) {
		ErrorDto errorDto = null;
		if(e.getHttpStatusCode() != null && e.getHttpStatusCode().getStatusCode() >= 0) {
			 errorDto = new ErrorDto(ErrorCategory.BILL_SERVICES, e.getHttpStatusCode().getStatusCode(), e.getMessage());
		}else {
		 errorDto = new ErrorDto(ErrorCategory.BILL_SERVICES, INVALID_REQUEST_CODE, e.getMessage());
		}
		return errorDto;
	}

	private boolean isBillRequestEmpty(Bill bill) {
		if (null == bill) {
			LOGGER.warn("bill is empty {}", null == bill);
			return true;
		}
		return false;
	}
}
