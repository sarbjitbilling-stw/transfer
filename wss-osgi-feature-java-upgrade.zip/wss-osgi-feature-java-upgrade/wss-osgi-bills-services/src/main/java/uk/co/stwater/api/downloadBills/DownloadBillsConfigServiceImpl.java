package uk.co.stwater.api.downloadBills;

import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Named
@OsgiServiceProvider(classes = {DownloadBillsConfigService.class})
public class DownloadBillsConfigServiceImpl implements ManagedService, DownloadBillsConfigService {

    static final String PID = "wss.osgi.documentid.mappings";

    private static final Map<String, String> config = new HashMap<>();
    
    private static final Logger log = LoggerFactory.getLogger(DownloadBillsConfigServiceImpl.class);
    

    @Override
    public synchronized void updated(Dictionary dctnrIn) throws ConfigurationException {
        //Add some type saftey !!
        
        log.info("updating download bills config");

        if(dctnrIn!=null) {
            config.clear();
        	log.info("In dictionary method of download bills");
            Dictionary<String, String> dctnr = dctnrIn;

            Collections.list(dctnr.keys()).forEach(key -> config.put(key, dctnr.get(key)));
        }

    }

    @Override
    public String getColumbusDocType(String targetDocType) {
            return config.get(targetDocType);
    }

}
