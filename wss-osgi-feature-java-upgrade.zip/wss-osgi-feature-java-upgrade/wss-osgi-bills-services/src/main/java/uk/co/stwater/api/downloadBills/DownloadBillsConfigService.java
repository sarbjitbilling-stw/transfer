package uk.co.stwater.api.downloadBills;

public interface DownloadBillsConfigService {

    String getColumbusDocType(String targetDocId);
}
