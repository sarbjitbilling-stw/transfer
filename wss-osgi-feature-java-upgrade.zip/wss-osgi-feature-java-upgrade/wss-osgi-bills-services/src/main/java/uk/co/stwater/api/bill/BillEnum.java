package uk.co.stwater.api.bill;

public enum BillEnum {

    CREATE_BILL("createBill", "Create bill",
            "Unable to ‘Create Bill’ – Unsuccessful due to Target error for account number %s",
            "{}"),
	SIMULATE_BILL("simulateBill", "Simulate bill",
            "Unable to ‘Simulate Bill’ – Unsuccessful due to Target error for account number %s",
            "{}");

    String stepId;
    String description;
    String errorMessage;
    String path;

    BillEnum(String stepId, String description, String errorMessage, String path) {
        this.stepId = stepId;
        this.description = description;
        this.errorMessage = errorMessage;
        this.path = path;
    }

    public String getDescription() {

        return description;
    }

    public String getStepId() {
        return stepId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getPath() {
        return path;
    }

}
