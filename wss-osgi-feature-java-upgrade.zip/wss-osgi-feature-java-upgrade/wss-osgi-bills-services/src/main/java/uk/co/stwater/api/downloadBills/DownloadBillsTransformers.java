/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.downloadBills;

import org.apache.commons.collections.Transformer;
import uk.co.stwater.api.osgi.model.DownloadBillsResponse;
import uk.co.stwater.api.osgi.util.TransformerBase;
import uk.co.stwater.api.osgi.model.SearchDocInfoResponse;

public class DownloadBillsTransformers extends TransformerBase {

    public static final Transformer SOAP_RESPONSE_TO_DOWNLOADBILLS_RESPONSE_ENTITY = new Transformer() {
        @Override
        public DownloadBillsResponse transform(Object input) {
           return copy(input, new DownloadBillsResponse());
        }
        
    };

    public static final Transformer SOAP_RESPONSE_TO_PDFCONTENT_RESPONSE_ENTITY = new Transformer() {
        @Override
        public SearchDocInfoResponse transform(Object input) {
            return copy(input, new SearchDocInfoResponse());
        }

    };
}
