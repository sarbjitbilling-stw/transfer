package uk.co.stwater.api.bill;

public interface BillConstant {

	static final String ACTION_UPDATE = "U";

	static final String ACTION_SIMULATE = "X";

	static final String BILL = "Bill";

	static final String LAST_TWELVE_MONTHS = "L12M";

	static final String LAST_TWENTY_FOUR_MONTHS = "L24M";

	static final String CREATE = "create";

	static final String SIMULATE = "simulate";

	static final String VALIDATE = "validate";

	static final String UNMEASURED = "U";

	static final String MEASURED = "M";

	static final String ASSESSED = "A";

	static final String BEFORE_GETTING_PROPERTIES_FOR_ACCOUNT_NUMBER = "Before getting properties for account number %s";

	static final String BILL_END_DATE_IS_AFTER_MOVE_OUT_DATE = "Bill end date %s is after move out date %s";
	static final String BILL_END_DATE_IS_AFTER_MOVE_OUT_DATE_STEP = "billEndDateAfterMoveOutDateStep";

	static final String BILL_END_DATE_IS_BEFORE_MOVE_IN_DATE = "Bill end date %s is before move in date %s";
	static final String BILL_END_DATE_IS_BEFORE_MOVE_IN_DATE_STEP = "billEndDateBeforeMoveInDateStep";

	static final String BILL_END_DATE_IS_BEFORE_LAST_BILL_DATE = "Customer already billed until %s. Date selected %s is on or before this date.";
	static final String BILL_END_DATE_IS_BEFORE_LAST_BILL_DATE_STEP = "billEndDateBeforeLastBillDateStep";
	
	static final int ONE = 1;

	static final int THIRTY_ONE = 31;

	static final String NO_LATEST_START_DATE = "No latest start date available";
	static final String NO_LATEST_START_DATE_STEP = "noLatestStartDateStep";

	static final String NO_PROPERTIES_FOUND_FOR_THE_ACCOUNT = "No properties found for the account.";
	static final String NO_PROPERTIES_FOR_ACCOUNT_STEP = "noPropertiesForAccountStep";

	static final String NO_MATCHING_PROPERTIES_FOUND = "No matching properties found.";
	static final String NO_MATCHING_PROPERTIES_STEP = "noMatchingPropertiesStep";

	static final String BILL_END_DATE_BEFORE_PROPERTY_START_DATE_STEP = "billEndDateBeforePropertyStartDateStep";
	static final String BILL_END_DATE_BEFORE_PROPERTY_START_DATE = "Bill end date is before property start date";

	static final String NO_BILLABLE_METER_READ_ON_BILL_END_DATE = "No billable meter read on bill end date %s";
	
	static final String NO_BILLABLE_METER_READ_ON_BILL_END_DATE_STEP = "noBillableMeterReadOnBillEndDateStep";
	
	static final String BILLI = "BILLI";

	static final String REBIL = "REBIL";

	static final String CANCELLED = "CANCELLED";

}
