package uk.co.stwater.api.downloadBills;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.targetconnector.client.api.contentmanagement.GetContentClient;
import uk.co.stwater.targetconnector.client.api.contentmanagement.SearchContentClient;
import uk.co.stwater.api.osgi.model.DownloadBillsResponse;
import uk.co.stwater.api.osgi.model.SearchDocInfoResponse;
import uk.co.stwater.targetconnector.client.api.contentmanagement.PDFContent;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;

@Named
@OsgiServiceProvider(classes = {DownloadBillsService.class})
public class DownloadBillsServiceImpl implements DownloadBillsService {

    private static final String DOCTYPE_BC = "BC";

    private static final String DOCTYPE_CA = "CA";

    Logger log = LoggerFactory.getLogger(this.getClass());

    @OsgiService
    @Inject
    GetContentClient getContentClientService;

    @OsgiService
    @Inject
    SearchContentClient searchContentClientService;

    @Inject
    DownloadBillsConfigService downloadBillsConfigService;

    private static final String REMINDER = "YourReminder";

    @Override
    public DownloadBillsResponse getBills(TargetAccountNumber accountNumber, String documentIdentifier) throws STWTechnicalException, STWBusinessException {
        PDFContent content = getContentClientService.getPdfContent(accountNumber, documentIdentifier);
        DownloadBillsResponse downloadBillsResp = (DownloadBillsResponse) DownloadBillsTransformers.SOAP_RESPONSE_TO_DOWNLOADBILLS_RESPONSE_ENTITY.transform(content);
        return downloadBillsResp;

    }

  public DownloadBillsResponse searchDocumentInfo(TargetAccountNumber accountNumber, String invoiceNumber, String invoiceDate, String documentId) throws STWTechnicalException, STWBusinessException {

      DownloadBillsResponse downloadBillsResponse = null;
      String postcode = " ";

        if (StringUtils.isNotEmpty(documentId)) {
			if ((!StringUtils.contains(documentId, ",")) && (DOCTYPE_CA.equals(documentId.substring(0, 2))
					|| DOCTYPE_BC.equals(documentId.substring(0, 2)))) {

                String columbusDocumentId = getColumbusDocId(accountNumber, documentId, postcode, invoiceNumber, invoiceDate);
                downloadBillsResponse = getDocument(accountNumber, columbusDocumentId);
				if (downloadBillsResponse != null) {
					String fileName = new StringBuilder().append(REMINDER).append(documentId)
							.append(downloadBillsResponse.getFileName().substring(11)).toString();
					downloadBillsResponse.setFileName(fileName);
				}

            } else if (!documentId.substring(0, 1).matches("\\d")) {
                String columbusDocType = downloadBillsConfigService.getColumbusDocType(documentId.substring(0, 4)).trim().concat(" ");
                String documentIdentifier = "";

                documentIdentifier = new StringBuilder().append(StringUtils.isNotEmpty(columbusDocType) ?
                        new StringBuilder().append(documentId).replace(0, 5, columbusDocType) :
                        documentIdentifier).toString();

                List<uk.co.stwater.targetconnector.client.api.contentmanagement.DocumentInfo> documentInfoTarget = searchContentClientService.searchContent(accountNumber, postcode, invoiceNumber, invoiceDate, documentIdentifier);
                downloadBillsResponse = getDocument(accountNumber, documentInfoTarget.get(0).getDocumentIdentifier());
				if (downloadBillsResponse != null) {
					String fileName = new StringBuilder().append(REMINDER).append(documentIdentifier.substring(0, 5))
							.append(documentIdentifier.substring(6, 15))
							.append(downloadBillsResponse.getFileName().substring(11)).toString();
					downloadBillsResponse.setFileName(fileName);
				}
            }
        }else {

              String documentIdentifier = "";
              List<uk.co.stwater.targetconnector.client.api.contentmanagement.DocumentInfo> documentInfoTarget = searchContentClientService.searchContent(accountNumber, postcode, invoiceNumber, invoiceDate, documentIdentifier);

              SearchDocInfoResponse searchDocInfoResponse = null;
              List<SearchDocInfoResponse> docInfoDetls = new ArrayList<>();
              for (uk.co.stwater.targetconnector.client.api.contentmanagement.DocumentInfo docInfo : documentInfoTarget) {

                  searchDocInfoResponse = (SearchDocInfoResponse) DownloadBillsTransformers.SOAP_RESPONSE_TO_PDFCONTENT_RESPONSE_ENTITY.transform(docInfo);
                  docInfoDetls.add(searchDocInfoResponse);
              }

			Optional<SearchDocInfoResponse> docInfoWithMatchingInvoiceNumber = docInfoDetls.stream()
					.filter(docInfo -> docInfo.getInvoiceNumber().equals(invoiceNumber)).findFirst();
			if (StringUtils.isNotEmpty(invoiceNumber) && docInfoWithMatchingInvoiceNumber.isPresent()) {
				documentIdentifier = docInfoWithMatchingInvoiceNumber.get().getDocumentIdentifier();
				downloadBillsResponse = getDocument(accountNumber, documentIdentifier);
				if (downloadBillsResponse != null) {
					String fileName = new StringBuilder().append(downloadBillsResponse.getFileName().substring(0, 11))
							.append(invoiceNumber).append(downloadBillsResponse.getFileName().substring(11)).toString();
					downloadBillsResponse.setFileName(fileName);
				}
			} 
			else if (docInfoDetls.stream().findFirst().isPresent()) {
				SearchDocInfoResponse firstAvailableDocinfo = docInfoDetls.stream().findFirst().get();
				documentIdentifier = firstAvailableDocinfo.getDocumentIdentifier();
				downloadBillsResponse = getDocument(accountNumber, documentIdentifier);
				if (downloadBillsResponse != null) {
					String fileName = new StringBuilder().append(downloadBillsResponse.getFileName().substring(0, 11))
							.append(invoiceNumber).append(downloadBillsResponse.getFileName().substring(11)).toString();
					downloadBillsResponse.setFileName(fileName);
				}
			}
		}
		if (downloadBillsResponse == null) {
			throw new STWBusinessException(Response.Status.NOT_FOUND.toString(),
					String.valueOf(Response.Status.NOT_FOUND.getStatusCode()), ErrorCategory.STW_SERVICES);
		}
          return downloadBillsResponse;
  }

    public DownloadBillsResponse getDocument(TargetAccountNumber accountNumber, String documentIdentifier) throws STWTechnicalException, STWBusinessException {
        DownloadBillsResponse downloadBillsResp
                = (DownloadBillsResponse) DownloadBillsTransformers.SOAP_RESPONSE_TO_DOWNLOADBILLS_RESPONSE_ENTITY.transform(getContentClientService.getPdfContent(accountNumber, documentIdentifier));

        return downloadBillsResp;
    }

    public String getColumbusDocId(TargetAccountNumber accountNumber, String documentId, String postcode, String invoiceNumber, String invoiceDate) throws STWTechnicalException, STWBusinessException {
        List<uk.co.stwater.targetconnector.client.api.contentmanagement.DocumentInfo> documentInfoTarget = searchContentClientService.searchContent(accountNumber, postcode, invoiceNumber, invoiceDate, documentId);
        String documentIdentifier = documentInfoTarget.get(0).getDocumentIdentifier();

        return documentIdentifier;
    }
}