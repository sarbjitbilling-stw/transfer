package uk.co.stwater.api.downloadBills;

import uk.co.stwater.api.osgi.model.DownloadBillsResponse;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;


public interface DownloadBillsService {
    DownloadBillsResponse  getBills(TargetAccountNumber accountNumber, String documentIdentifier) throws STWTechnicalException, STWBusinessException;
    DownloadBillsResponse  searchDocumentInfo(TargetAccountNumber accountNumber, String invoiceNumber, String invoiceDate, String documentId) throws STWTechnicalException, STWBusinessException;
}
