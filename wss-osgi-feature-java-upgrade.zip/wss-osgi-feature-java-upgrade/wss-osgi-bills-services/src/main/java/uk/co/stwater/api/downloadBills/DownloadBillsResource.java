package uk.co.stwater.api.downloadBills;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.DownloadBillsResponse;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.io.IOException;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.util.STWBusinessException;

import static uk.co.stwater.api.osgi.model.constants.GlobalConstants.APPLICATION_PDF;

@Named
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})

public class DownloadBillsResource extends AbstractResource {

    Logger log = LoggerFactory.getLogger(this.getClass());
    private static final String  POST_CODE = "";
    public static final String MEDIA_TYPE_TEXT = "text/html";

    @Inject
    private DownloadBillsService downloadBillsService;

    @GET
    @Produces({APPLICATION_PDF, MEDIA_TYPE_TEXT,MediaType.APPLICATION_JSON})
    public Response getBillsPDF(
            @Context HttpServletResponse response,
            @QueryParam("documentId") String documentId,
            @QueryParam("accountNumber") TargetAccountNumber accountNumber) throws STWTechnicalException, STWBusinessException
    {
        try {
            DownloadBillsResponse downloadBillsResp = downloadBillsService.getBills(accountNumber,documentId);

            byte[] docBytes = downloadBillsResp.getDocumentBytes();

            response.setContentLength(docBytes.length);
            response.setHeader("Content-Disposition", "inline; filename="
                    + downloadBillsResp.getFileName());
            ServletOutputStream outStream = response.getOutputStream();
            response.setHeader("Content-Type", APPLICATION_PDF);
            outStream = response.getOutputStream();

            outStream.write(docBytes);

            outStream.flush();
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            throw new STWTechnicalException(e.getMessage(), e);
        } 
        
        return Response.ok().build();
    }
    @GET
    @Path("/search")
    @Produces({APPLICATION_PDF, MEDIA_TYPE_TEXT,MediaType.APPLICATION_JSON})
     public Response searchDocumentInfo(
            @Context HttpServletResponse response,
            @QueryParam("accountNumber") TargetAccountNumber accountNumber,
            @QueryParam("invoiceNumber") String invoiceNumber,
            @QueryParam("invoiceDate")   String invoiceDate,
            @QueryParam("documentId") String documentId) throws STWTechnicalException, STWBusinessException
    {
        try {
            DownloadBillsResponse downloadBillsResp =
                         downloadBillsService.searchDocumentInfo(accountNumber,invoiceNumber,invoiceDate,documentId);

            byte[] docBytes = downloadBillsResp.getDocumentBytes();

            response.setContentLength(docBytes.length);
            response.setHeader("Content-Disposition", "inline; filename="
                    + downloadBillsResp.getFileName());
            response.setHeader("Content-Type", APPLICATION_PDF);
            ServletOutputStream outStream = response.getOutputStream();
            outStream = response.getOutputStream();

            outStream.write(docBytes);

            outStream.flush();
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            throw new STWTechnicalException(e.getMessage(), e);
        } catch (STWTechnicalException e) {
            log.warn(e.getMessage());
            ErrorDto errorDto = new ErrorDto(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), e.getMessage());;
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }

        return Response.ok().build();
    }
}