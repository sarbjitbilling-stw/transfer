package uk.co.stwater.api.billcopy;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.common.ResponseDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.model.PaperCopyBillRequest;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

@Named
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Path("/bills")
public class BillCopyResource extends AbstractResource {

	Logger log = LoggerFactory.getLogger(this.getClass());

	private static final String PAPERCOPY_REQ_ACCEPTED_CODE = "DM12.1";
	private static final String PAPERCOPY_REQ_REJECTED_CODE = "DM12.4";
	private static final String PAPERCOPY_REQ_EXIST_CODE = "DM12.2";
	private static final String PAPERCOPY_REQ_EXIST_MSG = "Paper Copy Request Accepted";

	@Inject
	private BillCopyService billCopyService;

	@POST
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response createPaperBillCopyRequest(PaperCopyBillRequest paperCopyBillRequest)
	
	{
		try {

			billCopyService.createPaperBillCopyRequest(paperCopyBillRequest,getContactDto());
			paperCopyBillRequest.setMessageCode(PAPERCOPY_REQ_ACCEPTED_CODE);

		} catch (STWTechnicalException ex) {        	
			log.error(ex.getMessage(), ex);
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.BILLCOPY_SERVICES, PAPERCOPY_REQ_REJECTED_CODE, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		} catch (BillCopyException ex) {
			log.warn(ex.getMessage(), ex);
			ErrorDto errorDto = new ErrorDto(ErrorDto.ErrorCategory.BILLCOPY_SERVICES, PAPERCOPY_REQ_EXIST_CODE, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
		}
		ResponseDto responseDto = new ResponseDto(ResponseDto.Category.BILLCOPY_SERVICES, PAPERCOPY_REQ_ACCEPTED_CODE, PAPERCOPY_REQ_EXIST_MSG);
		return Response.status(Status.CREATED).entity(responseDto).build();
	}
}