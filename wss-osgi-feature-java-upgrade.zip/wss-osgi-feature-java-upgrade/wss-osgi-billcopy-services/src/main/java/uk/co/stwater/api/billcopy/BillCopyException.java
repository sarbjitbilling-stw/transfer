package uk.co.stwater.api.billcopy;

import uk.co.stwater.api.osgi.util.STWBusinessException;

/**
 * Created by jagad on 31/07/2017.
 */
public class BillCopyException extends STWBusinessException {

    public BillCopyException(String msg) {
        super(msg);
    }

    public BillCopyException(String msg, Throwable t) {
        super(msg, t);
    }
}
