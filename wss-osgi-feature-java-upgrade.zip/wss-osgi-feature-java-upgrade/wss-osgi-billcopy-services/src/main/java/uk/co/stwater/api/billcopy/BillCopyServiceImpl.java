package uk.co.stwater.api.billcopy;

import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.osgi.model.ContactTypes;
import uk.co.stwater.api.osgi.model.common.ContactDto;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.targetconnector.client.api.createcontact.ContactNotesData;
import uk.co.stwater.targetconnector.client.api.createcontact.CreateContactClient;
import uk.co.stwater.targetconnector.client.api.setcopybillflag.PaperCopyBillRequest;
import uk.co.stwater.targetconnector.client.api.setcopybillflag.SetCopyBillFlagClient;

@Named
@OsgiServiceProvider(classes = {BillCopyService.class})
public class BillCopyServiceImpl  implements BillCopyService {

	Logger log = LoggerFactory.getLogger(this.getClass());
	
	private static final String BILL_REQUESTED_CODE = "502530";

	@OsgiService
	@Inject
	SetCopyBillFlagClient setCopyBillFlagService;

	@Inject
	@OsgiService
	private CreateContactClient createContactClient;

	@Inject
	private BillCopyEmailService emailService;

    @Override
    public void createPaperBillCopyRequest(uk.co.stwater.api.osgi.model.PaperCopyBillRequest paperCopyBillRequest, Optional<ContactDto> contactDto) throws STWTechnicalException, STWBusinessException {

        PaperCopyBillRequest paperCopyReq = new PaperCopyBillRequest();
        try {

            paperCopyReq =  (PaperCopyBillRequest) BillCopyTransformers.SOAP_RESPONSE_TO_BILLCOPY_RESPONSE_ENTITY.transform(paperCopyBillRequest);
            setCopyBillFlagService.setCopyBillFlag(paperCopyReq);
            if (!contactDto.isPresent()) {
                throw new STWBusinessException("Unable to find ContactDto");
            }
            createWebContactAndEmail(paperCopyReq, contactDto.get());

		} catch (STWBusinessException e) {
			
			if (e.getErrorCode() != null && StringUtils.isNotEmpty(e.getErrorCode())
					&& e.getErrorCode().equals(BILL_REQUESTED_CODE)){
				//Case - DM12.2
				log.warn("A copy bill has already been requested", e);
				throw new BillCopyException("A copy bill has already been requested", e);
			} else {
				//Case - DM1.9
				ContactNotesData contactNotesData = createContactClient.getContactNotesData(paperCopyBillRequest.getAccountNumber(), Long.valueOf(paperCopyBillRequest.getLeId()));
				BillCopyContact contact = new BillCopyContact(contactNotesData, paperCopyReq, ContactTypes.WEB628);
				createContactClient.createContact(contact);				
				log.warn("Failed to request copy bill", e);
				throw new STWTechnicalException("Failed to request copy bill", e); 
			}
		}
	}

    private void createWebContactAndEmail(PaperCopyBillRequest paperCopyBillRequest, ContactDto contactDto) {
        ContactNotesData contactNotesData = createContactClient.getContactNotesData(paperCopyBillRequest.getAccountNumber(), Long.valueOf(paperCopyBillRequest.getLeId()));
		BillCopyContact contact = new BillCopyContact(contactNotesData, paperCopyBillRequest, ContactTypes.WEB618);
        createContactClient.createContact(contact);
        emailService.sendPaperCopyBillResponseEmail(paperCopyBillRequest.getEmail(),contactDto);
    }
}