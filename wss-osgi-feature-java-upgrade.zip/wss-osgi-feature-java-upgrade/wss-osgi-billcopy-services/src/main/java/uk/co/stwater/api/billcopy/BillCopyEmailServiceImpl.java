package uk.co.stwater.api.billcopy;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.ops4j.pax.cdi.api.OsgiService;
import uk.co.stwater.api.email.service.EmailService;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import uk.co.stwater.api.osgi.model.common.ContactDto;

import javax.inject.Named;
import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jagad on 20/07/2017.
 */
@Named
@OsgiServiceProvider(classes={BillCopyEmailService.class})

public class BillCopyEmailServiceImpl implements BillCopyEmailService {

    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String EMAIL_0121_REQUEST_SUCCESS = "E12.1";

    @Inject
    @OsgiService
    private EmailService emailService;

    @Override
    public void sendPaperCopyBillResponseEmail(String emailAddress, ContactDto contactDto) {

        Map<String,String> fieldData = new HashMap<>();
        fieldData.put("${fullName}", contactDto.getFullName());

        emailService.mailMergeAndSend(EMAIL_0121_REQUEST_SUCCESS, fieldData, emailAddress, contactDto.getAccountNumber(), contactDto.getLeId());
    }
}