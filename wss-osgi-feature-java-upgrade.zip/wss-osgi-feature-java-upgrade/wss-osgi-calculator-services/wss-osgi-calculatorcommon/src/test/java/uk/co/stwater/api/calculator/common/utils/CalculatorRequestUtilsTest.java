package uk.co.stwater.api.calculator.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;

import uk.co.stwater.api.dao.ServiceSupplierMapping;
import uk.co.stwater.api.osgi.model.CalculatorRequest;

public class CalculatorRequestUtilsTest {
    
    private static final String DEFAULT_SUPPLIER = "1";

    @Test
    public void testDefaultSupplierAssignments1() {
        CalculatorRequest calculatorRequest =  new CalculatorRequest();
        
        calculatorRequest.setHighwaysDrainageService(true);
        calculatorRequest.setHighwayDrainageSupplier("1");
        
        calculatorRequest.setSewerageService(true);
        calculatorRequest.setSewerageSupplier("2");
        
        calculatorRequest.setSurfaceWaterService(true);
        // SurfaceWaterSupplier not set
        
        calculatorRequest.setUsedWaterService(true);
        // UsedWaterSupplier not set
        
        calculatorRequest.setWaterService(true);
        // WaterSupplier not set
        
        List<ServiceSupplierMapping>serviceSuppliers =  CalculatorRequestUtils.getServiceSuppliers(calculatorRequest);
        
        // verify default suppliers are added to request
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getHighwayDrainageSupplier());
        assertEquals("2", calculatorRequest.getSewerageSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getSurfaceWaterSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getUsedWaterSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getWaterSupplier());
        
        assertNotNull(serviceSuppliers);
        assertEquals(5, serviceSuppliers.size());
    }
    
    @Test
    public void testDefaultSupplierAssignments_NoneSet() {
        CalculatorRequest calculatorRequest =  new CalculatorRequest();
        
        calculatorRequest.setHighwaysDrainageService(true);
        // HighwayDrainageSupplier not set;
        
        calculatorRequest.setSewerageService(true);
        // SewerageSupplier not set
        
        calculatorRequest.setSurfaceWaterService(true);
        // SurfaceWaterSupplier not set
        
        calculatorRequest.setUsedWaterService(true);
        // UsedWaterSupplier not set
        
        calculatorRequest.setWaterService(true);
        // WaterSupplier not set
        
        List<ServiceSupplierMapping>serviceSuppliers =  CalculatorRequestUtils.getServiceSuppliers(calculatorRequest);
        
        // verify default suppliers are added to request
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getHighwayDrainageSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getSewerageSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getSurfaceWaterSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getUsedWaterSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getWaterSupplier());
        
        assertNotNull(serviceSuppliers);
        assertEquals(5, serviceSuppliers.size());
    }
    
    @Test
    public void testDefaultSupplierAssignments_OnlyAssignSelectedServices() {
        CalculatorRequest calculatorRequest =  new CalculatorRequest();
        
        calculatorRequest.setHighwaysDrainageService(false);
        // HighwayDrainageSupplier not set;
        
        calculatorRequest.setSewerageService(false);
        // SewerageSupplier not set
        
        calculatorRequest.setSurfaceWaterService(true);
        // SurfaceWaterSupplier not set
        
        calculatorRequest.setUsedWaterService(false);
        // UsedWaterSupplier not set
        
        calculatorRequest.setWaterService(false);
        // WaterSupplier not set
        
        List<ServiceSupplierMapping>serviceSuppliers =  CalculatorRequestUtils.getServiceSuppliers(calculatorRequest);
        
        // verify default suppliers are added to request
        assertNull(calculatorRequest.getHighwayDrainageSupplier());
        assertNull(calculatorRequest.getSewerageSupplier());
        assertEquals(DEFAULT_SUPPLIER, calculatorRequest.getSurfaceWaterSupplier());
        assertNull(calculatorRequest.getUsedWaterSupplier());
        assertNull(calculatorRequest.getWaterSupplier());
        
        assertNotNull(serviceSuppliers);
        assertEquals(1, serviceSuppliers.size());
    }
    
    @Test
    public void testNoSupplierAssignments() {
        CalculatorRequest calculatorRequest =  new CalculatorRequest();
        
        calculatorRequest.setHighwaysDrainageService(false);
        // HighwayDrainageSupplier not set;
        
        calculatorRequest.setSewerageService(false);
        // SewerageSupplier not set
        
        calculatorRequest.setSurfaceWaterService(false);
        // SurfaceWaterSupplier not set
        
        calculatorRequest.setUsedWaterService(false);
        // UsedWaterSupplier not set
        
        calculatorRequest.setWaterService(false);
        // WaterSupplier not set
        
        List<ServiceSupplierMapping>serviceSuppliers =  CalculatorRequestUtils.getServiceSuppliers(calculatorRequest);
        
        // verify default suppliers are added to request
        assertNull(calculatorRequest.getHighwayDrainageSupplier());
        assertNull(calculatorRequest.getSewerageSupplier());
        assertNull(calculatorRequest.getSurfaceWaterSupplier());
        assertNull(calculatorRequest.getUsedWaterSupplier());
        assertNull(calculatorRequest.getWaterSupplier());
        
        assertNotNull(serviceSuppliers);
        assertEquals(0, serviceSuppliers.size());
    }

    @Test
    public void testDefaultSupplierAssignmentsSSSystemTest() {
        CalculatorRequest calculatorRequest = new CalculatorRequest();

        calculatorRequest.setWaterService(true);
        calculatorRequest.setWaterSupplier("1");

        calculatorRequest.setUsedWaterService(true);
        calculatorRequest.setUsedWaterSupplier("1");

        calculatorRequest.setHighwaysDrainageService(true);
        calculatorRequest.setHighwayDrainageSupplier("1");

        // won't appear
        calculatorRequest.setSewerageService(false);
        calculatorRequest.setSewerageSupplier("1");

        calculatorRequest.setSurfaceWaterService(true);
        calculatorRequest.setSurfaceWaterSupplier("1");

        List<ServiceSupplierMapping> serviceSuppliers = CalculatorRequestUtils.getServiceSuppliers(calculatorRequest);

        assertNotNull(serviceSuppliers);
        assertEquals(4, serviceSuppliers.size());
    }
}

