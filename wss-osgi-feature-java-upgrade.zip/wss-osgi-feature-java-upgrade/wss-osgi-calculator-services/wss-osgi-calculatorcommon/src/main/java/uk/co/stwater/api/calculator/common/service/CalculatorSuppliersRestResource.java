package uk.co.stwater.api.calculator.common.service;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.dao.entity.CalculateServiceSuppliers;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@Path("/calculation")
@Named("calculatorSuppliersRestResource")
public class CalculatorSuppliersRestResource extends AbstractResource {

	private static final String NO_SUPPLIERS_ERROR_CODE = "100";

    private static final String NO_SERVICE_SUPPLIERS_AVAILABLE = "No Service suppliers available";

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    private CalculatorSuppliersService calculatorSupplierService;

    @GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
    public Response getSuppliers() {
        List<CalculateServiceSuppliers> suppliers = calculatorSupplierService.getSuppliers();

        if (suppliers.isEmpty()) {
            throw new STWBusinessException(NO_SERVICE_SUPPLIERS_AVAILABLE, NO_SUPPLIERS_ERROR_CODE,
                    ErrorDto.ErrorCategory.CALCULATOR_SERVICES);
        }
        return Response.ok(suppliers).build();
	}
}
