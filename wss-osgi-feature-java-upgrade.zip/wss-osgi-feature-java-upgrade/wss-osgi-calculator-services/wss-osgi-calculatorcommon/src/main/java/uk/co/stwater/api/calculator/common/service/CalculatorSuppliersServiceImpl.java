package uk.co.stwater.api.calculator.common.service;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;

import uk.co.stwater.api.calculator.common.utils.CalculatorRequestUtils;
import uk.co.stwater.api.core.service.BaseService;
import uk.co.stwater.api.dao.CalculateServiceSuppliersDao;
import uk.co.stwater.api.dao.ServiceSupplierMapping;
import uk.co.stwater.api.dao.entity.AverageDailyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredPropertyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredUsageCharge;
import uk.co.stwater.api.dao.entity.CalculateServiceSuppliers;
import uk.co.stwater.api.osgi.model.CalculatorRequest;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;
import uk.co.stwater.api.osgi.model.calculator.consumption.BudgetType;
import uk.co.stwater.api.osgi.model.calculator.consumption.OccupantType;

@OsgiServiceProvider(classes = { CalculatorSuppliersService.class })
@Named
public class CalculatorSuppliersServiceImpl extends BaseService implements CalculatorSuppliersService {

    @OsgiService
	@Inject
    private CalculateServiceSuppliersDao calculateServiceSuppliersDao;

    @Override
    public List<CalculateServiceSuppliers> getSuppliers() {
        return calculateServiceSuppliersDao.findAllRows();
    }
    
    @Override
    public boolean canCalculateAllSuppliers(CalculatorRequest request, String calcType) {
        
        List<ServiceSupplierMapping> requestedServiceSuppliers = CalculatorRequestUtils.getServiceSuppliers(request);
        
        List<CalculateServiceSuppliers> matchingsuppliers = calculateServiceSuppliersDao
                .findAllMatchingRows(requestedServiceSuppliers, calcType);
        
        return requestedServiceSuppliers.size() == matchingsuppliers.size();
    }

    @Override
    public CalculateMeasuredPropertyCharge getMeasuredPropertyChargesBySupplierAndProperty(String supplierCode,
            PropertyType propertyType) {
        return calculateServiceSuppliersDao.getMeasuredPropertyChargesBySupplierAndProperty(supplierCode, propertyType);
    }

    @Override
    public CalculateMeasuredUsageCharge getMeasuredUsageChargesBySupplier(String supplierCode) {
        return calculateServiceSuppliersDao.getMeasuredUsageChargesBySupplier(supplierCode);
    }

    @Override
    public AverageDailyCharge findByNumberOfOccupants(int numberOfChildrenOccupants, OccupantType occupantType,
            BudgetType budgetType) {
        return calculateServiceSuppliersDao.findByNumberOfOccupants(numberOfChildrenOccupants, occupantType,
                budgetType);
    }
}
