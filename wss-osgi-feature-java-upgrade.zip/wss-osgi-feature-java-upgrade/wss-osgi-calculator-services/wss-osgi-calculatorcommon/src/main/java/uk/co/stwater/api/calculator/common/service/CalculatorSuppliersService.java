package uk.co.stwater.api.calculator.common.service;

import java.util.List;

import uk.co.stwater.api.dao.entity.AverageDailyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredPropertyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredUsageCharge;
import uk.co.stwater.api.dao.entity.CalculateServiceSuppliers;
import uk.co.stwater.api.osgi.model.CalculatorRequest;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;
import uk.co.stwater.api.osgi.model.calculator.consumption.BudgetType;
import uk.co.stwater.api.osgi.model.calculator.consumption.OccupantType;

public interface CalculatorSuppliersService {
    List<CalculateServiceSuppliers> getSuppliers();

    boolean canCalculateAllSuppliers(CalculatorRequest request, String calcType);

    CalculateMeasuredPropertyCharge getMeasuredPropertyChargesBySupplierAndProperty(String surfaceWaterSupplier,
            PropertyType propertyType);

    CalculateMeasuredUsageCharge getMeasuredUsageChargesBySupplier(String waterSupplier);

    AverageDailyCharge findByNumberOfOccupants(int numberOfChildrenOccupants, OccupantType child, BudgetType average);
}
