DROP TABLE IF EXISTS WSS_PROPERTY_TYPE_CHARGES;

CREATE TABLE WSS_PROPERTY_TYPE_CHARGES (UID bigint(19) NOT NULL, propertyDescription VARCHAR(255),standingUsedCharges DOUBLE, standingWaterCharges DOUBLE,swdCharges DOUBLE, PRIMARY KEY (UID))

INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('FLAT', 12.94, 28.34 ,32.95,1)
INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('TERRACED', 12.94, 28.34, 32.95,2)
INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('SEMI', 12.94, 28.34, 64.71,3)
INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('DETACHED', 12.94, 28.34, 76.24,4)

DROP TABLE IF EXISTS WSS_AVERAGE_DAILY_CHARGE;
CREATE TABLE WSS_AVERAGE_DAILY_CHARGE (UID bigint(20) NOT NULL,numberOfOccupants integer NOT NULL,occupantType varchar(10) NOT NULL,TYPE varchar(10) NOT NULL,VALUE double,PRIMARY KEY (UID))

INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (1, 'ADULT', 'LOW', 0.10, 1)

INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (0, 'STW','1','STW','Y','Y','Y','Y','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (1, 'STW','2','Chester - HD to STW - Called Zone 9/23','Y','N','N','N','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (2, 'STW','3','Wrexham - HD to STW - Called Zone 10/24','Y','N','N','N','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (3, 'HD','4','Powys - STW to HD - Called Zone A','Y','Y','Y','Y','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (4, 'HD','5','Wrexham - DV  to HD - Called Zone B','Y','N','N','N','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (5, 'HD','6','Chester - DV to HD - Called Zone C','Y','N','N','N','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (6, 'HD','7','Monmouthshire - STW to HD - Called Zone D','Y','Y','Y','Y','Y','Y','Y',null)
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (7, 'STW','8','Anglian','N','Y','Y','Y','N','Y','N','RV - Based on usage bands?? Assessed - Need usage?')
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (8, 'STW','9','Thames','N','Y','Y','Y','N','Y', 'N','RV - Requires Flip question Assessed - Requires number of bedrooms')
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (9,'STW/HD','10','United Utilities','N','Y','Y','Y','N','Y','N','RV - Requires DD question Assessed - Requires DD question')
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (10,'STW/HD','11','Welsh Water','N','Y','Y','Y','N','N','N','RV  - Cant understand the pricing… Measured -  Charges based on if you have SWD or not Assessed - Needs number of people and usage band')
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (11,'STW/HD','12','Wessex Water','N','Y','Y','Y','N','Y','N','RV - Cannot find pricing?')
INSERT INTO WSS_CALC_SUPPLIERS (uid, brand,supplier_Code, supplier_Text, provides_Fresh_Water, provides_Waste_Water, provides_SWD, provides_HD, rv_Works, measured_Works, assessed_Works, special_Processing) values (12,'STW','13','Yorkshire Water','N','Y','Y','Y','N','Y','Y','RV - Requires Septic Tank info')
