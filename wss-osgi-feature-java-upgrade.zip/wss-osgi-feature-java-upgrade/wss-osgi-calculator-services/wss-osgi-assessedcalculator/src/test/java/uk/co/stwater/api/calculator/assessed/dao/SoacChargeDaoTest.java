package uk.co.stwater.api.calculator.assessed.dao;

import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import uk.co.stwater.api.calculator.assessed.model.SoacCharge;

public class SoacChargeDaoTest {

	protected static EntityManagerFactory emf;
	protected static EntityManager entityManager;

	private SoacChargeDao soacChargeDao;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("wssPersistenceTest");
		entityManager = emf.createEntityManager();
		soacChargeDao = new SoacChargeDaoImpl(entityManager);
		entityManager.getTransaction().begin();
	}

	@After
	public void tearDown() throws Exception {
		entityManager.getTransaction().commit();
	}

	@Test
	public void persistAndGetSoacChargeForAKnownCategory() {
		String category = "CAT1";
		SoacCharge soacCharge = new SoacCharge();
		soacCharge.setCategory(category);
		soacCharge.setFullSewerage(20.00D);
		soacCharge.setSwdOnly(30.00D);
		soacCharge.setUsedWaterOnly(40.00D);
		soacCharge.setWaterOnly(60.00D);
		soacChargeDao.create(soacCharge);
		
		SoacCharge result = soacChargeDao.findByCategory(category);
		assertTrue(result!=null);
		assertEquals(category,result.getCategory());
	}

	@Test(expected=NoResultException.class)
	public void tryToGetASoacChargeForACategoryWhichHasNotBeenCreated() {
		soacChargeDao.findByCategory("NON_EXISTENT");
	}

}