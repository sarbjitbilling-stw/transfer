package uk.co.stwater.api.calculator.assessed.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.anyString;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.calculator.assessed.dao.AssessedChargeDao;
import uk.co.stwater.api.calculator.assessed.dao.SoacChargeDao;
import uk.co.stwater.api.calculator.assessed.model.AssessedCalculation;
import uk.co.stwater.api.calculator.assessed.model.AssessedCalculationRequest;
import uk.co.stwater.api.calculator.assessed.model.AssessedCharge;
import uk.co.stwater.api.calculator.assessed.model.SoacCharge;
import uk.co.stwater.api.calculator.common.service.CalculatorSuppliersService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.dao.entity.CalculateServiceSuppliers;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AssessedCalculationServiceImplTest {

    private static final String CALC_TYPE = "assessedWorks";

    AssessedCalculationRequest request;
    
    List<CalculateServiceSuppliers> daoList = new ArrayList<>();

	@Mock
	private SoacChargeDao soacChargeDao;
	
    @Mock
    private AssessedChargeDao assessedChargeDao;

    @Mock
    private CalculatorSuppliersService calculatorSuppliersService;
    
	@InjectMocks
	private AssessedCalculationService service = new AssessedCalculationServiceImpl();

	@Before
	public void setUp() throws Exception {
	    request = new AssessedCalculationRequest();
	    request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days

        daoList.add(new CalculateServiceSuppliers());

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected=ServiceException.class)
	public void calculateWithNoRequestShouldFail() throws Exception {
		service.calculate(null);
	}

	@Test(expected=ServiceException.class)
	public void calculateWithEmptyRequestShouldFail() throws Exception {
		service.calculate(request);
	}

	@Test
	public void calculateWithAllRequestServicesSOAC() throws Exception {
        request.setSingleOccupierAssessedVolume(true);

        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(true);
        request.setHighwaysDrainageService(true);
        
        request.setPropertyType(PropertyType.FLAT);
        
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days

        initialiseMatchingDaoList(5);

        SoacCharge soacCharge = getTestSoacCharge();
        
        Mockito.when(soacChargeDao.findByCategoryAndSupplier(anyString(), anyString())).thenReturn(soacCharge);
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);

        AssessedCalculation calculation = service.calculate(request);
        
        assertEquals(34.56, calculation.getAnnualDrainageAmount(), 0);
        assertEquals(102.67, calculation.getAnnualSewerageAmount(), 0);
        assertEquals(117.02, calculation.getAnnualUsedWaterAmount(), 0);
        assertEquals(12.28, calculation.getAnnualWaterAmount(), 0);
        
        assertEquals(12.31, calculation.getProrated(), 0);
        assertEquals(12.00, calculation.getProratedRounded(), 0);
        
        assertEquals(271.53, calculation.getTotal(), 0);
        
    }
	
	@Test
    public void calculateWithNoHighwaysDrainageSOAC() throws Exception {
        request.setSingleOccupierAssessedVolume(true);
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(true);
        request.setHighwaysDrainageService(false);
        
        request.setPropertyType(PropertyType.FLAT);
        
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days

        initialiseMatchingDaoList(4);

        SoacCharge soacCharge = getTestSoacCharge();
        
        Mockito.when(soacChargeDao.findByCategoryAndSupplier(anyString(), anyString())).thenReturn(soacCharge);
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        AssessedCalculation calculation = service.calculate(request);
        
        assertEquals(34.56, calculation.getAnnualDrainageAmount(), 0);
        assertEquals(102.67, calculation.getAnnualSewerageAmount(), 0);
        assertEquals(117.02, calculation.getAnnualUsedWaterAmount(), 0);
        assertEquals(12.28, calculation.getAnnualWaterAmount(), 0);
        
        assertEquals(7.31, calculation.getProrated(), 0);
        assertEquals(7.00, calculation.getProratedRounded(), 0);
        
        assertEquals(266.53, calculation.getTotal(), 0);
        
    }

	private SoacCharge getTestSoacCharge() {
        SoacCharge charge = new SoacCharge();
        
        charge.setFullSewerage(102.67);
        charge.setHighwaysDrainage(5.0);
        charge.setSwdOnly(34.56);
        charge.setUsedWaterOnly(117.02);
        charge.setWaterOnly(12.28);
        
        return charge;
    }

	private AssessedCharge getTestAssessedCharge() {
	    AssessedCharge charge = new AssessedCharge();
	    
	    charge.setFullSewerage(112.57);
        charge.setHighwaysDrainage(5.0);
        charge.setSwdOnly(37.56);
        charge.setUsedWaterOnly(107.02);
        charge.setWaterOnly(22.29);
        
	    return charge;
    }
	
    @Test
    public void calculateWithAllRequestServicesAssessed() throws Exception {
        request.setSingleOccupierAssessedVolume(false);
        
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(true);
        request.setHighwaysDrainageService(true);
        
        request.setPropertyType(PropertyType.FLAT);
        
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days

        initialiseMatchingDaoList(5);

        AssessedCharge assessedCharge = getTestAssessedCharge();
        
        Mockito.when(assessedChargeDao.findByCategoryAndSupplier(anyString(), anyString())).thenReturn(assessedCharge);
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        AssessedCalculation calculation = service.calculate(request);
        
        assertEquals(37.56, calculation.getAnnualDrainageAmount(), 0);
        assertEquals(112.57, calculation.getAnnualSewerageAmount(), 0);
        assertEquals(107.02, calculation.getAnnualUsedWaterAmount(), 0);
        assertEquals(22.29, calculation.getAnnualWaterAmount(), 0);
        
        assertEquals(12.65, calculation.getProrated(), 0);
        assertEquals(13.00, calculation.getProratedRounded(), 0);
        
        assertEquals(284.44, calculation.getTotal(), 0);
    }

    
    private void initialiseMatchingDaoList(int limit) {
        for (int i = 0; daoList.size() < limit; i++) {
            daoList.add(i, new CalculateServiceSuppliers());
        }
    }

    @Test
    public void calculateWithNoHighwaysDrainageAssessed() throws Exception {
        request.setSingleOccupierAssessedVolume(false);
        
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setSurfaceWaterService(true);
        request.setSewerageService(true);
        request.setHighwaysDrainageService(false);
        request.setHighwayDrainageSupplier("1");
        
        request.setPropertyType(PropertyType.FLAT);
        
        request.setStartDate(LocalDate.parse("2016-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-11")); // i.e. 10 days

        initialiseMatchingDaoList(4);
        AssessedCharge assessedCharge = getTestAssessedCharge();

        Mockito.when(assessedChargeDao.findByCategoryAndSupplier(anyString(), anyString())).thenReturn(assessedCharge);
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(true);
        
        AssessedCalculation calculation = service.calculate(request);
        
        assertEquals(37.56, calculation.getAnnualDrainageAmount(), 0);
        assertEquals(112.57, calculation.getAnnualSewerageAmount(), 0);
        assertEquals(107.02, calculation.getAnnualUsedWaterAmount(), 0);
        assertEquals(22.29, calculation.getAnnualWaterAmount(), 0);
        
        assertEquals(7.65, calculation.getProrated(), 0);
        assertEquals(8.00, calculation.getProratedRounded(), 0);
        
        assertEquals(279.44, calculation.getTotal(), 0);
    }
    
    @Test(expected = ServiceException.class)
    public void calculateWithWrongStartEndDatesShouldFail() throws Exception {
        request.setPropertyType(PropertyType.FLAT);
        
        request.setStartDate(LocalDate.parse("2017-01-01"));
        request.setEndDate(LocalDate.parse("2016-01-01"));
        
        service.calculate(request);
    }
    
    @Test(expected = ServiceException.class)
    public void calculateWithEqualStartAndEndDatesShouldFail() throws Exception {
        request.setPropertyType(PropertyType.FLAT);
        
        request.setStartDate(LocalDate.parse("2017-01-01"));
        request.setEndDate(LocalDate.parse("2017-01-01"));
        
        service.calculate(request);
    }
    
    @Test(expected = STWBusinessException.class)
    public void calculateWithIncompatibleServiceAndSupplier() throws Exception {
        request.setWaterService(true);
        request.setUsedWaterService(true);
        request.setUsedWaterSupplier("1");
        request.setSurfaceWaterService(true);
        request.setSurfaceWaterSupplier("1");
 
        request.setPropertyType(PropertyType.FLAT);
        
        // mock single size list
        Mockito.when(calculatorSuppliersService.canCalculateAllSuppliers(request, CALC_TYPE)).thenReturn(false);
        
        service.calculate(request);
    }
}