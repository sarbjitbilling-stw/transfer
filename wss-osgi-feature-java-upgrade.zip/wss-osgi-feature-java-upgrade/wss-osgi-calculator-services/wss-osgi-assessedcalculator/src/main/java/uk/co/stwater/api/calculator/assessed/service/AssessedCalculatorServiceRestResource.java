package uk.co.stwater.api.calculator.assessed.service;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.assessed.model.AssessedCalculationRequest;
import uk.co.stwater.api.calculator.assessed.model.AssessedCalculation;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.util.AbstractResource;

@Path("/calculation")
@Named("assessedCalculatorRestResource")
public class AssessedCalculatorServiceRestResource extends AbstractResource {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Inject
	private AssessedCalculationService assessedCalculationService;

	public AssessedCalculatorServiceRestResource() {

	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response calculate(AssessedCalculationRequest request) throws ServiceException {
        AssessedCalculation calculation = assessedCalculationService.calculate(request);
        return Response.ok(calculation).build();
	}
}
