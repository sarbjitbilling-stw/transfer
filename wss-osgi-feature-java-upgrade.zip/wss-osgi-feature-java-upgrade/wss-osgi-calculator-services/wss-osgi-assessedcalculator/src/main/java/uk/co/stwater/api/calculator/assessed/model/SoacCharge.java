package uk.co.stwater.api.calculator.assessed.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import uk.co.stwater.api.core.model.BaseModel;

@Entity()
@Table(name="WSS_SOAC_CHARGES")
public class SoacCharge extends BaseModel<Long> {

	private static final long serialVersionUID = 1L;

	private String category;
	private double waterOnly;
	private double usedWaterOnly;
	private double swdOnly;
	private double fullSewerage;
	private String supplierCode;
    private String supplierText;
	private double highwaysDrainage;
    
	@Column(nullable=false)
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	@Column(nullable=false)
	public double getWaterOnly() {
		return waterOnly;
	}
	public void setWaterOnly(double waterOnly) {
		this.waterOnly = waterOnly;
	}
	
	@Column(nullable=false)
	public double getUsedWaterOnly() {
		return usedWaterOnly;
	}
	public void setUsedWaterOnly(double usedWaterOnly) {
		this.usedWaterOnly = usedWaterOnly;
	}
	
	@Column(nullable=false)
	public double getSwdOnly() {
		return swdOnly;
	}
	public void setSwdOnly(double swdOnly) {
		this.swdOnly = swdOnly;
	}
	
	@Column(nullable=false)
	public double getFullSewerage() {
		return fullSewerage;
	}
	public void setFullSewerage(double fullSewerage) {
		this.fullSewerage = fullSewerage;
	}

	@Column(nullable=true)
    public String getSupplierCode() {
        return supplierCode;
    }
    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }
    @Column(nullable=true)
    public String getSupplierText() {
        return supplierText;
    }
    public void setSupplierText(String supplierText) {
        this.supplierText = supplierText;
    }
    @Column(nullable = true)
    public double getHighwaysDrainage() {
        return highwaysDrainage;
    }

    public void setHighwaysDrainage(double highwaysDrainage) {
        this.highwaysDrainage = highwaysDrainage;
    }
}
