package uk.co.stwater.api.calculator.assessed.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.assessed.dao.AssessedChargeDao;
import uk.co.stwater.api.calculator.assessed.dao.SoacChargeDao;
import uk.co.stwater.api.calculator.assessed.model.AssessedCalculation;
import uk.co.stwater.api.calculator.assessed.model.AssessedCalculationRequest;
import uk.co.stwater.api.calculator.assessed.model.AssessedCharge;
import uk.co.stwater.api.calculator.assessed.model.CalculationValue;
import uk.co.stwater.api.calculator.assessed.model.SoacCharge;
import uk.co.stwater.api.calculator.common.service.CalculatorSuppliersService;
import uk.co.stwater.api.calculator.common.utils.CalculatorRequestUtils;
import uk.co.stwater.api.core.error.ErrorCode;
import uk.co.stwater.api.core.service.BaseService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@OsgiServiceProvider(classes = { AssessedCalculationService.class })
@Named
@Transactional
@Singleton
public class AssessedCalculationServiceImpl extends BaseService implements AssessedCalculationService {

    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String ASSESSED_WORKS_FIELD = "assessedWorks";
	
    private static final String CANNOT_CALCULATE_NOT_FOUND_CODE = "ASSESSCALC007";

    private static final String CANNOT_CALCULATE_MSG = "Cannot calculate for specified services/suppliers";

	private static final int DAYS_IN_YEAR = 365;

  	@Inject
    private SoacChargeDao soacChargeDao;

    @Inject
    private AssessedChargeDao assessedChargeDao;

    @OsgiService
    @Inject
    private CalculatorSuppliersService calculatorsSupplierService;

	@Override
	public void init() {
		super.init();
	}

	@Override
	public AssessedCalculation calculate(AssessedCalculationRequest assessedCalculationRequest) throws ServiceException {
        log.debug("calculating for {}", assessedCalculationRequest);
		
		//Validation
		if (assessedCalculationRequest==null) throw new ServiceException(AssessedCalculatorErrorCodes.INVALID_REQUEST);
		if (assessedCalculationRequest.getPropertyType()==null) throw new ServiceException(AssessedCalculatorErrorCodes.INVALID_CATEGORY);
		PropertyType propertyType = assessedCalculationRequest.getPropertyType();
		LocalDate startDate = assessedCalculationRequest.getStartDate();
		LocalDate endDate = assessedCalculationRequest.getEndDate();
		if (startDate.isAfter(endDate) || startDate.isEqual(endDate)) throw new ServiceException(AssessedCalculatorErrorCodes.INVALID_START_END_DATE);
		
		//Calculation
		AssessedCalculation assessedCalculation = new AssessedCalculation();
		double futureCharges = 0.00D;
		double annualTotal = 0.00D;
		
		//Calculate number of days between start and end
		long daysBetween = ChronoUnit.DAYS.between(startDate,endDate);
		if (daysBetween > Integer.MAX_VALUE) throw new ServiceException(AssessedCalculatorErrorCodes.INVALID_DATES); //Protect from weirdness
		int numberOfDays = (int) daysBetween;
		assessedCalculation.setNumberOfDays(numberOfDays);
		Set<CalculationValue> calculation = new LinkedHashSet<>();

        if (!calculatorsSupplierService.canCalculateAllSuppliers(assessedCalculationRequest, ASSESSED_WORKS_FIELD)) {
            throw new STWBusinessException(CANNOT_CALCULATE_MSG, CANNOT_CALCULATE_NOT_FOUND_CODE,
                    ErrorCategory.CALCULATOR_SERVICES);
        }
        //assign defaults if not present for chosen service
        CalculatorRequestUtils.assignCalculationRequestDefaults(assessedCalculationRequest);

        if (assessedCalculationRequest.isSingleOccupierAssessedVolume()) {
			if (assessedCalculationRequest.isWaterService()) {
			    SoacCharge soacCharge = soacChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getWaterSupplier());
                
                setAnnualAmounts(assessedCalculation, soacCharge);
                
				double proratedChargeForService = round((soacCharge.getWaterOnly() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.WATER_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;	
				annualTotal = annualTotal + soacCharge.getWaterOnly();
			}
            if (assessedCalculationRequest.isUsedWaterService()) {
			    SoacCharge soacCharge = soacChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getUsedWaterSupplier());
                
                setAnnualAmounts(assessedCalculation, soacCharge);
				double proratedChargeForService = round((soacCharge.getUsedWaterOnly() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.USED_WATER_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + soacCharge.getUsedWaterOnly();
			}
			if (assessedCalculationRequest.isSurfaceWaterService()) {
			    SoacCharge soacCharge = soacChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getSurfaceWaterSupplier());
                
                setAnnualAmounts(assessedCalculation, soacCharge);
				double proratedChargeForService = round((soacCharge.getSwdOnly() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.SURFACE_WATER_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + soacCharge.getSwdOnly();
			}
			if (assessedCalculationRequest.isSewerageService()) {
			    SoacCharge soacCharge = soacChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getSewerageSupplier());
                
                setAnnualAmounts(assessedCalculation, soacCharge);
                
				double proratedChargeForService = round((soacCharge.getFullSewerage() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.SEWERAGE_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + soacCharge.getFullSewerage();
			}
            if (assessedCalculationRequest.isHighwaysDrainageService()) {
                SoacCharge soacCharge = soacChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getHighwayDrainageSupplier());
                
                setAnnualAmounts(assessedCalculation, soacCharge);
                
                double proratedChargeForService = soacCharge.getHighwaysDrainage();
                calculation.add(new CalculationValue(CalculationValue.HIGHWAYS_DRAINAGE_SERVICE, proratedChargeForService));
                futureCharges = futureCharges + proratedChargeForService;
                annualTotal = annualTotal + soacCharge.getHighwaysDrainage();
            }
		} else {
			if (assessedCalculationRequest.isWaterService()) {

                AssessedCharge assessedCharge = assessedChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getWaterSupplier());

                setAnnualAmounts(assessedCalculation, assessedCharge);

				double proratedChargeForService = round((assessedCharge.getWaterOnly() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.WATER_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + assessedCharge.getWaterOnly();
			}
			if (assessedCalculationRequest.isUsedWaterService()) {
                AssessedCharge assessedCharge = assessedChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getUsedWaterSupplier());

                setAnnualAmounts(assessedCalculation, assessedCharge);

				double proratedChargeForService = round((assessedCharge.getUsedWaterOnly() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.USED_WATER_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + assessedCharge.getUsedWaterOnly();
			}
			if (assessedCalculationRequest.isSurfaceWaterService()) {
                AssessedCharge assessedCharge = assessedChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getSurfaceWaterSupplier());

                setAnnualAmounts(assessedCalculation, assessedCharge);

				double proratedChargeForService = round((assessedCharge.getSwdOnly() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.SURFACE_WATER_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + assessedCharge.getSwdOnly();
			}
			if (assessedCalculationRequest.isSewerageService()) {
                AssessedCharge assessedCharge = assessedChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getSewerageSupplier());

                setAnnualAmounts(assessedCalculation, assessedCharge);

				double proratedChargeForService = round((assessedCharge.getFullSewerage() / DAYS_IN_YEAR) * numberOfDays,2);
				calculation.add(new CalculationValue(CalculationValue.SEWERAGE_SERVICE,proratedChargeForService));
				futureCharges = futureCharges + proratedChargeForService;				
				annualTotal = annualTotal + assessedCharge.getFullSewerage();
			}
            if (assessedCalculationRequest.isHighwaysDrainageService()) {
                AssessedCharge assessedCharge = assessedChargeDao.findByCategoryAndSupplier(propertyType.name(),
                        assessedCalculationRequest.getHighwayDrainageSupplier());

                setAnnualAmounts(assessedCalculation, assessedCharge);

                double proratedChargeForService = assessedCharge.getHighwaysDrainage();
                calculation.add(new CalculationValue(CalculationValue.HIGHWAYS_DRAINAGE_SERVICE, proratedChargeForService));
                futureCharges = futureCharges + proratedChargeForService;
                annualTotal = annualTotal + assessedCharge.getHighwaysDrainage();
            }
		}
		
		//Return results
		assessedCalculation.setCalculation(calculation);		
		double prorated = round(futureCharges,2);
		double proratedRounded = round(prorated,0);
		assessedCalculation.setTotal(annualTotal);
		assessedCalculation.setProrated(prorated);
		assessedCalculation.setProratedRounded(proratedRounded);
		
		return assessedCalculation;
	}


    private void setAnnualAmounts(AssessedCalculation assessedCalculation, AssessedCharge assessedCharge) {
        assessedCalculation.setAnnualWaterAmount(assessedCharge.getWaterOnly());
        assessedCalculation.setAnnualUsedWaterAmount(assessedCharge.getUsedWaterOnly());
        assessedCalculation.setAnnualDrainageAmount(assessedCharge.getSwdOnly());
        assessedCalculation.setAnnualSewerageAmount(assessedCharge.getFullSewerage());
    }

    private void setAnnualAmounts(AssessedCalculation assessedCalculation, SoacCharge soacCharge) {
        assessedCalculation.setAnnualWaterAmount(soacCharge.getWaterOnly());
        assessedCalculation.setAnnualUsedWaterAmount(soacCharge.getUsedWaterOnly());
        assessedCalculation.setAnnualDrainageAmount(soacCharge.getSwdOnly());
        assessedCalculation.setAnnualSewerageAmount(soacCharge.getFullSewerage());
    }
    private double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		long factor = (long) Math.pow(10, places);
		value = value * factor;
		long tmp = Math.round(value);
		return (double) tmp / factor;
	}

	private static class AssessedCalculatorErrorCodes {
		static ErrorCode INVALID_REQUEST = new ErrorCode("ASCALC001", "Must enter a valid request");
		static ErrorCode INVALID_CATEGORY = new ErrorCode("ASCALC002", "Invalid category entered");
		static ErrorCode INVALID_START_END_DATE = new ErrorCode("ASCALC003", "End date is before start date");
		static ErrorCode INVALID_DATES = new ErrorCode("ASCALC004", "Too long between start and end date");
		static ErrorCode INVALID_SERVICE_SUPPLIER = new ErrorCode("ASCALC005", "Invalid Service & Supplier combination");
	}
}
