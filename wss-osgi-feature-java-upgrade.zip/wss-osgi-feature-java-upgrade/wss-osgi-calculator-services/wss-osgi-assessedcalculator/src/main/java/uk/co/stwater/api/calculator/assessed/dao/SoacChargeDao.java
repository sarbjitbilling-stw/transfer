package uk.co.stwater.api.calculator.assessed.dao;

import uk.co.stwater.api.calculator.assessed.model.SoacCharge;
import uk.co.stwater.api.core.dao.CrudDao;

public interface SoacChargeDao extends CrudDao<Long, SoacCharge> {

	SoacCharge findByCategory(String category);

    SoacCharge findByCategoryAndSupplier(String category, String supplier);

}
