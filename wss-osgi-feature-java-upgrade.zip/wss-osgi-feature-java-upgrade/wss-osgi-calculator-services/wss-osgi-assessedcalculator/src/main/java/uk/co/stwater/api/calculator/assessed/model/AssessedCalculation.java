package uk.co.stwater.api.calculator.assessed.model;

import java.util.Set;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import uk.co.stwater.api.core.model.BaseModel;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AssessedCalculation extends BaseModel<Long> {

	private static final long serialVersionUID = -8706025954272168489L;

	@XmlElement
	private int numberOfDays;
	
	@XmlElement
	private double annualWaterAmount;
	
	@XmlElement
	private double annualSewerageAmount;
	
	@XmlElement
	private double annualDrainageAmount;
	
	@XmlElement
	private double annualUsedWaterAmount;
	
	@XmlElement
	private Set<CalculationValue> calculation;
	
	@XmlElement
	private double total;
	
	@XmlElement
	private double prorated;
	
	@XmlElement
	private double proratedRounded;
	
	public int getNumberOfDays() {
		return numberOfDays;
	}
	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}
	public double getAnnualWaterAmount() {
		return annualWaterAmount;
	}
	public void setAnnualWaterAmount(double annualWaterAmount) {
		this.annualWaterAmount = annualWaterAmount;
	}
	public double getAnnualSewerageAmount() {
		return annualSewerageAmount;
	}
	public void setAnnualSewerageAmount(double annualSewerageAmount) {
		this.annualSewerageAmount = annualSewerageAmount;
	}
	public double getAnnualDrainageAmount() {
		return annualDrainageAmount;
	}
	public void setAnnualDrainageAmount(double annualDrainageAmount) {
		this.annualDrainageAmount = annualDrainageAmount;
	}
	public double getAnnualUsedWaterAmount() {
		return annualUsedWaterAmount;
	}
	public void setAnnualUsedWaterAmount(double annualUsedWaterAmount) {
		this.annualUsedWaterAmount = annualUsedWaterAmount;
	}
	public Set<CalculationValue> getCalculation() {
		return calculation;
	}
	public void setCalculation(Set<CalculationValue> calculation) {
		this.calculation = calculation;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public double getProrated() {
		return prorated;
	}
	public void setProrated(double prorated) {
		this.prorated = prorated;
	}
	public double getProratedRounded() {
		return proratedRounded;
	}
	public void setProratedRounded(double proratedRounded) {
		this.proratedRounded = proratedRounded;
	}

}
