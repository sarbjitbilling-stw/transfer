package uk.co.stwater.api.calculator.assessed.dao;

import uk.co.stwater.api.calculator.assessed.model.AssessedCharge;
import uk.co.stwater.api.core.dao.CrudDao;

public interface AssessedChargeDao extends CrudDao<Long, AssessedCharge> {

	AssessedCharge findByCategory(String category);

    AssessedCharge findByCategoryAndSupplier(String name, String waterSupplier);

}
