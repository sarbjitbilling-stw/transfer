/**
 * 
 */
package uk.co.stwater.api.calculator.assessed.service;

import uk.co.stwater.api.calculator.assessed.model.AssessedCalculationRequest;
import uk.co.stwater.api.calculator.assessed.model.AssessedCalculation;
import uk.co.stwater.api.core.service.Service;
import uk.co.stwater.api.core.service.ServiceException;

public interface AssessedCalculationService extends Service {
	AssessedCalculation calculate(AssessedCalculationRequest request) throws ServiceException;
}
