INSERT INTO WSS_SOAC_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (1, "FLAT", 87.33, 56.96, 33.36, 90.32);
INSERT INTO WSS_SOAC_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (2, "TERRACED", 87.33, 56.96, 33.36, 90.32);
INSERT INTO WSS_SOAC_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (3, "SEMI", 87.33, 56.96, 56.06, 113.02);
INSERT INTO WSS_SOAC_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (4, "DETACHED", 87.33, 56.96, 78.54, 135.50);

INSERT INTO WSS_ASSESSED_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (1, "FLAT", 173.31, 105.69, 33.36, 139.05);
INSERT INTO WSS_ASSESSED_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (2, "TERRACED", 173.31, 105.69, 33.36, 139.05);
INSERT INTO WSS_ASSESSED_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (3, "SEMI", 186.09, 112.94, 56.06, 169.00);
INSERT INTO WSS_ASSESSED_CHARGES(uid, category, waterOnly, usedWaterOnly, swdOnly, fullSewerage) VALUES (4, "DETACHED", 224.36, 134.64, 78.54, 213.18);
