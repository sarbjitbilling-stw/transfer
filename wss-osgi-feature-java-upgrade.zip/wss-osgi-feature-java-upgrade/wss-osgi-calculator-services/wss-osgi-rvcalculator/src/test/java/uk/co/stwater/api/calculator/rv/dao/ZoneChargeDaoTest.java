package uk.co.stwater.api.calculator.rv.dao;

import static org.junit.Assert.assertTrue;

import java.util.List;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import uk.co.stwater.api.calculator.rv.dao.ZoneChargeDao;
import uk.co.stwater.api.calculator.rv.dao.ZoneChargeDaoImpl;
import uk.co.stwater.api.calculator.rv.model.ZoneCharge;

public class ZoneChargeDaoTest {

	protected static EntityManagerFactory emf;
	protected static EntityManager entityManager;

	private ZoneChargeDao zoneChargeDao;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("wssPersistenceTest");
		entityManager = emf.createEntityManager();
		zoneChargeDao = new ZoneChargeDaoImpl(entityManager);
		entityManager.getTransaction().begin();
	}

	@After
	public void tearDown() throws Exception {
		entityManager.getTransaction().commit();
	}

	@Test
	public void persistAndGetZoneChargeForAKnownZone() {
		int zone = 20;
		double waterChargePence = 114.31D;
		double fullSewerageChargePence = 117.01D;
		ZoneCharge zoneCharge = new ZoneCharge();
		zoneCharge.setZone(zone);
		zoneCharge.setUnmeasuredWaterPence(waterChargePence);
		zoneCharge.setFullUnmeasuredSeweragePence(fullSewerageChargePence);
		zoneChargeDao.create(zoneCharge);
		
		ZoneCharge result = zoneChargeDao.findByZone(zone);
		assertTrue(result!=null);
		assertEquals(zone,result.getZone());
		assertEquals(waterChargePence,result.getUnmeasuredWaterPence(),0.00D);
		assertEquals(fullSewerageChargePence,result.getFullUnmeasuredSeweragePence(),0.00D);
	}

	@Test(expected=NoResultException.class)
	public void tryToGetAZoneChargeForAZoneWhichHasNotBeenCreated() {
		int zone = 25;		
		zoneChargeDao.findByZone(zone);
	}

	@Test
	public void getAllZones() {
		zoneChargeDao.init();
		int zone1 = 1;
		double waterChargePence1 = 100.00D;
		double fullSewerageChargePence1 = 200.00D;
		ZoneCharge zoneCharge1 = new ZoneCharge();
		zoneCharge1.setZone(zone1);
		zoneCharge1.setUnmeasuredWaterPence(waterChargePence1);
		zoneCharge1.setFullUnmeasuredSeweragePence(fullSewerageChargePence1);
		zoneChargeDao.create(zoneCharge1);
		int zone2 = 2;
		double waterChargePence2 = 300.00D;
		double fullSewerageChargePence2 = 400.00D;
		ZoneCharge zoneCharge2 = new ZoneCharge();
		zoneCharge2.setZone(zone2);
		zoneCharge2.setUnmeasuredWaterPence(waterChargePence2);
		zoneCharge2.setFullUnmeasuredSeweragePence(fullSewerageChargePence2);
		zoneChargeDao.create(zoneCharge2);
		
		List<ZoneCharge> allZones = zoneChargeDao.findAll();
		assertEquals(16, allZones.size());
	}

}