package uk.co.stwater.api.calculator.rv.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

import org.junit.Before;
import org.junit.Test;

import uk.co.stwater.api.calculator.rv.model.ZoneCharge;
//import uk.co.stwater.api.dao.WSSDaoTest;

public class ZoneChargeDaoImplTest {

    private ZoneChargeDaoImpl zoneChargeDao;
    
    protected static EntityManagerFactory emf;
    protected static EntityManager em;
    
    @Before
    public void setUp() throws Exception {
        emf = Persistence.createEntityManagerFactory("wssPersistenceTest");
        em = emf.createEntityManager();
        zoneChargeDao = new ZoneChargeDaoImpl(em);
        em.getTransaction().begin();
    }

    @Test(expected=NoResultException.class)
    public void testBasicZoneChargeQueryInvalidZone() {
        ZoneCharge zoneCharge = zoneChargeDao.findByZone(0);
        assertNotNull(zoneCharge);
    }
    @Test
    public void testBasicZoneChargeQuery() {
        ZoneCharge zoneCharge = zoneChargeDao.findByZone(3);
        assertNotNull(zoneCharge);
    }
    @Test
    public void testBasicZoneAndSupplierChargeQuery() {
        ZoneCharge zoneCharge = zoneChargeDao.findByZoneAndSupplier(3, "1");
        assertNotNull(zoneCharge);
        
        assertEquals("1", zoneCharge.getSupplierCode());
        assertEquals(3, zoneCharge.getZone());
        assertEquals(101.65, zoneCharge.getUnmeasuredWaterPence(), 0);
    }
}
