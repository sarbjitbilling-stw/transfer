package uk.co.stwater.api.calculator.rv.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import uk.co.stwater.api.core.model.BaseModel;

@Entity()
@Table(name="WSS_ZONE_CHARGES")
public class ZoneCharge extends BaseModel<Long> {

	private static final long serialVersionUID = -1044390766822165404L;

	private int zone;
	private String supplierCode;
	private String supplierText;
    
	private double minimumWaterChargePence;
	private double unmeasuredWaterPence;
	private double fullUnmeasuredSeweragePence;
	private double propertySurfaceWaterPence;
	private double usedWaterPence;
	private double highwaysDrainagePence;
    // annual standing charge for water (in pounds even though name says pence)
	private double annualStandingPence;
    // annual standing charge for waste (in pounds)
    private Double annualStandingWaste;
	
	@Column(nullable=false)
	public int getZone() {
		return zone;
	}
	public void setZone(int zone) {
		this.zone = zone;
	}
	
	@Column(nullable=true)
	public double getMinimumWaterChargePence() {
        return minimumWaterChargePence;
    }
    public void setMinimumWaterChargePence(double minimumWaterChargePence) {
        this.minimumWaterChargePence = minimumWaterChargePence;
    }
    
    @Column(nullable=false)
	public double getUnmeasuredWaterPence() {
		return unmeasuredWaterPence;
	}
	public void setUnmeasuredWaterPence(double unmeasuredWaterPence) {
		this.unmeasuredWaterPence = unmeasuredWaterPence;
	}
	
	@Column(nullable=false)
	public double getFullUnmeasuredSeweragePence() {
		return fullUnmeasuredSeweragePence;
	}
	public void setFullUnmeasuredSeweragePence(double fullUnmeasuredSeweragePence) {
		this.fullUnmeasuredSeweragePence = fullUnmeasuredSeweragePence;
	}
	
	@Column(nullable=false)
	public double getPropertySurfaceWaterPence() {
		return propertySurfaceWaterPence;
	}
	public void setPropertySurfaceWaterPence(double propertySurfaceWaterPence) {
		this.propertySurfaceWaterPence = propertySurfaceWaterPence;
	}
	
	@Column(nullable=false)
	public double getUsedWaterPence() {
		return usedWaterPence;
	}
	public void setUsedWaterPence(double usedWaterPence) {
		this.usedWaterPence = usedWaterPence;
	}
	
	@Column(nullable=true)
	public double getHighwaysDrainagePence() {
		return highwaysDrainagePence;
	}
	
	public void setHighwaysDrainagePence(double highwaysDrainagePence) {
		this.highwaysDrainagePence = highwaysDrainagePence;
	}
	
	@Column(nullable=true)
	public double getAnnualStandingPence() {
		return annualStandingPence;
	}
	
	public void setAnnualStandingPence(double annualStandingPence) {
		this.annualStandingPence = annualStandingPence;
	}
	
	@Column(nullable=true)
    public String getSupplierCode() {
        return supplierCode;
    }
    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }
    
    @Column(nullable=true)
    public String getSupplierText() {
        return supplierText;
    }
    public void setSupplierText(String supplierText) {
        this.supplierText = supplierText;
    }

    @Column(name = "ANNUAL_STANDING_WASTE")
    public Double getAnnualStandingWaste() {
        return annualStandingWaste;
    }

    public void setAnnualStandingWaste(Double annualStandingWaste) {
        this.annualStandingWaste = annualStandingWaste;
    }
	
}
