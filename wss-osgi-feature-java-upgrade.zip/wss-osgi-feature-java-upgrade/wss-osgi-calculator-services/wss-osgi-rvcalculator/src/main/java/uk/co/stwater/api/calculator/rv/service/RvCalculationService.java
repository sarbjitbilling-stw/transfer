/**
 * 
 */
package uk.co.stwater.api.calculator.rv.service;

import uk.co.stwater.api.calculator.rv.model.RvCalculation;
import uk.co.stwater.api.calculator.rv.model.RvCalculationRequest;
import uk.co.stwater.api.core.service.Service;
import uk.co.stwater.api.core.service.ServiceException;

public interface RvCalculationService extends Service {
	RvCalculation calculate(RvCalculationRequest request) throws ServiceException;
}
