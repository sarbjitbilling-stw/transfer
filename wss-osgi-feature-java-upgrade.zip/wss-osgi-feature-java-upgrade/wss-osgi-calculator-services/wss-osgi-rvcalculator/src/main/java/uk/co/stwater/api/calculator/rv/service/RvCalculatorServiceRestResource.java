package uk.co.stwater.api.calculator.rv.service;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.rv.model.RvCalculation;
import uk.co.stwater.api.calculator.rv.model.RvCalculationRequest;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.util.AbstractResource;

@Path("/calculation")
@Named("rvCalculatorRestResource")
public class RvCalculatorServiceRestResource extends AbstractResource {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Inject
	private RvCalculationService rvCalculationService;

	public RvCalculatorServiceRestResource() {

	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response calculate(RvCalculationRequest request) throws ServiceException {

		GenericEntity<RvCalculation> entity = new GenericEntity<RvCalculation>(rvCalculationService.calculate(request)) {};
		return Response.status(200).entity(entity).build();	
		
	}
}
