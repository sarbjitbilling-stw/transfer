package uk.co.stwater.api.calculator.rv.dao;

import uk.co.stwater.api.calculator.rv.model.ZoneCharge;
import uk.co.stwater.api.core.dao.CrudDao;

public interface ZoneChargeDao extends CrudDao<Long, ZoneCharge> {

	ZoneCharge findByZone(int zone);

    ZoneCharge findByZoneAndSupplier(int zone, String supplierCode);

}
