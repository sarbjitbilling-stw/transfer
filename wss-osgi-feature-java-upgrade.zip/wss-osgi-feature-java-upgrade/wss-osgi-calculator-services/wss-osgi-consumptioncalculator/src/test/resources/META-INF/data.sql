INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('FLAT', 12.94, 28.34 ,32.95,1)
INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('TERRACED', 12.94, 28.34, 32.95,2)
INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('SEMI', 12.94, 28.34, 64.71,3)
INSERT INTO WSS_PROPERTY_TYPE_CHARGES(propertyDescription, standingUsedCharges, standingWaterCharges, swdCharges, uid) VALUES ('DETACHED', 12.94, 28.34, 76.24,4)


INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (1, 'ADULT', 'LOW', 0.10, 1)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (1, 'ADULT', 'AVERAGE', 0.15, 2)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (1, 'ADULT', 'HIGH', 0.20, 3)

INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (2, 'ADULT', 'LOW', 0.20, 4)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (2, 'ADULT', 'AVERAGE', 0.30, 5)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (2, 'ADULT', 'HIGH', 0.40, 6)

INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (3, 'ADULT', 'LOW', 0.30, 7)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (3, 'ADULT', 'AVERAGE', 0.45, 8)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (3, 'ADULT', 'HIGH', 0.60, 9)


INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (4, 'ADULT', 'LOW', 0.40, 10)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (4, 'ADULT', 'AVERAGE', 0.60, 11)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (4, 'ADULT', 'HIGH', 0.80, 12)


INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (5, 'ADULT', 'LOW', 0.50, 13)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (5, 'ADULT', 'AVERAGE', 0.75, 14)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (5, 'ADULT', 'HIGH', 1.00, 15)


INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (6, 'ADULT', 'LOW', 0.60, 16)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (6, 'ADULT', 'AVERAGE', 0.90, 17)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (6, 'ADULT', 'HIGH', 1.20, 18)


INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (1, 'CHILD', 'AVERAGE', 0.07, 19)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (2, 'CHILD', 'AVERAGE', 0.13, 20)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (3, 'CHILD', 'AVERAGE', 1.20, 21)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (4, 'CHILD', 'AVERAGE', 0.27, 22)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (5, 'CHILD', 'AVERAGE', 0.33, 23)
INSERT INTO WSS_AVERAGE_DAILY_CHARGE(numberOfOccupants, occupantType, type, value, uid) VALUES (6, 'CHILD', 'AVERAGE', 1.40, 24)




INSERT INTO WSS_WATER_CHARGE(unit,budgetType,type, value, uid) values('c/m3','LOW','FRESH', 1.3998, 1)
INSERT INTO WSS_WATER_CHARGE(unit,budgetType,type, value, uid) values('c/m3','AVERAGE','FRESH', 1.3998, 2)
INSERT INTO WSS_WATER_CHARGE(unit,budgetType,type, value, uid) values('c/m3','HIGH','FRESH', 1.3998, 3)

INSERT INTO WSS_WATER_CHARGE(unit,budgetType,type, value, uid) values('c/m3','LOW','USED', 0.9477, 4)
INSERT INTO WSS_WATER_CHARGE(unit,budgetType,type, value, uid) values('c/m3','AVERAGE','USED', 0.9477, 5)
INSERT INTO WSS_WATER_CHARGE(unit,budgetType,type, value, uid) values('c/m3','HIGH','USED', 0.9477, 6)
