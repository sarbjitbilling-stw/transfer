package uk.co.stwater.api.calculator.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.common.service.CalculatorSuppliersService;
import uk.co.stwater.api.core.error.ErrorCode;
import uk.co.stwater.api.core.service.BaseService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.dao.entity.AverageDailyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredPropertyCharge;
import uk.co.stwater.api.dao.entity.CalculateMeasuredUsageCharge;
import uk.co.stwater.api.osgi.model.calculator.PropertyType;
import uk.co.stwater.api.osgi.model.calculator.consumption.BudgetType;
import uk.co.stwater.api.osgi.model.calculator.consumption.CalculationValue;
import uk.co.stwater.api.osgi.model.calculator.consumption.EstimateRequest;
import uk.co.stwater.api.osgi.model.calculator.consumption.Estimates;
import uk.co.stwater.api.osgi.model.calculator.consumption.OccupantType;
import uk.co.stwater.api.osgi.model.calculator.consumption.ServiceType;
import uk.co.stwater.api.osgi.model.calculator.consumption.UsageBand;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

@OsgiServiceProvider(classes = { CalculationService.class })
@Named
@Transactional
@Singleton
public class CalculationServiceImpl extends BaseService implements CalculationService {

    Logger log = LoggerFactory.getLogger(this.getClass());
    public static final int DAYS_PER_YEAR = 365;
    public static final int DECIMAL_PLACES = 2;
    
    private static final String MEASURED_WORKS_FIELD = "measuredWorks";
    
    private static final String CANNOT_CALCULATE_NOT_FOUND_CODE = "MEASCALC001";
    private static final String CANNOT_CALCULATE_MSG = "Cannot calculate for specified services/suppliers";
    
    @OsgiService
    @Inject
    private CalculatorSuppliersService calculatorSuppliersService;

    @Override
    public Estimates calculate(EstimateRequest estimateRequest) {
        log.debug("calculate start");
        log.debug("estimateRequest: adults:{}, children:{}, property type:{}",
                estimateRequest.getNumberOfAdultOccupants(), estimateRequest.getNumberOfChildrenOccupants(),
                estimateRequest.getPropertyType());
        Estimates estimates = new Estimates();

        if (!calculatorSuppliersService.canCalculateAllSuppliers(estimateRequest, MEASURED_WORKS_FIELD)) {
            throw new STWBusinessException(CANNOT_CALCULATE_MSG, CANNOT_CALCULATE_NOT_FOUND_CODE,
                    ErrorCategory.MEASURED_CALCULATOR);
        }
        int numberOfDays = getNumberOfDays(estimateRequest);
        estimates.setNumberOfDays(numberOfDays);
        List<UsageBand> usageBands = new ArrayList<>();

        usageBands.add(getUserBand(estimateRequest, BudgetType.LOW, numberOfDays));
        usageBands.add(getUserBand(estimateRequest, BudgetType.HIGH, numberOfDays));
        usageBands.add(getUserBand(estimateRequest, BudgetType.AVERAGE, numberOfDays));

        estimates.setUsageBands(usageBands);
        log.debug("estimates :{}", estimates);
        log.debug("calculate end");
        return estimates;
    }

    protected int getNumberOfDays(EstimateRequest estimateRequest) throws ServiceException {
        LocalDate startDate = estimateRequest.getStartDate();
        LocalDate endDate = estimateRequest.getEndDate();
        long daysBetween = ChronoUnit.DAYS.between(startDate, endDate);
        if (daysBetween > Integer.MAX_VALUE)
            throw new ServiceException(ConsumptionCalculatorErrorCodes.INVALID_DATES); // Protect from weirdness
        return (int) daysBetween;
    }

    private UsageBand getUserBand(EstimateRequest estimateRequest, BudgetType budgetType, int numberOfDays) {
        log.debug("getUserBand start");
        log.debug("budgetType:{} / numberOfDays:{}", budgetType, numberOfDays);
        UsageBand usageBand = new UsageBand();
        usageBand.setType(budgetType);
        CalculationValue calculationValue = null;
        BigDecimal total = new BigDecimal(0);
        double totalConsumption = 0;
        Set<CalculationValue> calculation = new LinkedHashSet<>();
        if (estimateRequest.isWaterService()) {
            calculationValue = getCalculationValue(estimateRequest, ServiceType.WATER, budgetType, numberOfDays);
            calculation.add(calculationValue);
            total = total.add(BigDecimal.valueOf(calculationValue.getValue()));

        }
        if (estimateRequest.isUsedWaterService()) {
            calculationValue = getCalculationValue(estimateRequest, ServiceType.USED_WATER, budgetType, numberOfDays);
            calculation.add(calculationValue);
            total = total.add(BigDecimal.valueOf(calculationValue.getValue()));
        }
        if (estimateRequest.isSurfaceWaterService()) {
            calculationValue = getCalculationValue(estimateRequest, ServiceType.SURFACE_WATER, budgetType,
                    numberOfDays);
            calculation.add(calculationValue);
            total = total.add(BigDecimal.valueOf(calculationValue.getValue()));
        }
        if (estimateRequest.isHighwaysDrainageService()) {
            calculationValue = getCalculationValue(estimateRequest, ServiceType.HIGHWAYS_DRAINAGE, budgetType,
                    numberOfDays);
            calculation.add(calculationValue);
            total = total.add(BigDecimal.valueOf(calculationValue.getValue()));
        }

        usageBand.setCalculation(calculation);
        usageBand.setTotal(total.setScale(DECIMAL_PLACES, BigDecimal.ROUND_HALF_UP).doubleValue());

        if (calculationValue == null) {
            throw new STWBusinessException("Unable to calculate totalConsumption as consumtion not found");
        }
        totalConsumption = calculationValue.getConsumption();
        usageBand.setTotalConsumption(round(totalConsumption, DECIMAL_PLACES));
        usageBand.setDailyConsumption(round(totalConsumption / numberOfDays, DECIMAL_PLACES));
        log.debug("getUserBand end");
        return usageBand;

    }

    private CalculationValue getCalculationValue(EstimateRequest estimateRequest, ServiceType serviceType,
            BudgetType budgetType, int numberOfDays) throws ServiceException {
        log.debug("getCalculationValue start");
        log.debug("serviceType:{}", serviceType);
        CalculationValue calculationValue = new CalculationValue();
        double serviceCost = 0;
        double serviceConsumption = 0;
        double propertyTypeAddition = 0;
        double costPerUnit = 0;
        double adcAdultUsage = 0;
        double adcChildUsage = 0;

        AverageDailyCharge adc_child = null;
        if (estimateRequest.getNumberOfChildrenOccupants() > 0) {
            try {
                adc_child = calculatorSuppliersService.findByNumberOfOccupants(
                        estimateRequest.getNumberOfChildrenOccupants(),
                        OccupantType.CHILD, BudgetType.AVERAGE);
            } catch (NoResultException | NonUniqueResultException e2) {
                throwError(ConsumptionCalculatorErrorCodes.NO_OF_CHILDREN_DO_NOT_EXIST);
            }
            adcChildUsage = adc_child.getValue();
        }

        AverageDailyCharge adc_adult = null;
        try {
            adc_adult = calculatorSuppliersService.findByNumberOfOccupants(estimateRequest.getNumberOfAdultOccupants(),
                    OccupantType.ADULT, budgetType);

        } catch (NoResultException | NonUniqueResultException e2) {
            throwError(ConsumptionCalculatorErrorCodes.NO_OF_ADULT_DO_NOT_EXIST);
        }
        adcAdultUsage = adc_adult.getValue();

        CalculateMeasuredUsageCharge measuredUsageCharge = null;
        switch (serviceType) {
            case WATER:
                measuredUsageCharge = getMeasuredUsageChargeBySupplier(
                        estimateRequest.getWaterSupplier());

                costPerUnit = measuredUsageCharge.getFwUnitCharge();
                propertyTypeAddition = measuredUsageCharge.getFwFixedCharge();

                break;
            case USED_WATER:
                measuredUsageCharge = getMeasuredUsageChargeBySupplier(
                        estimateRequest.getUsedWaterSupplier());

                costPerUnit = measuredUsageCharge.getUwUnitCharge();
                propertyTypeAddition = measuredUsageCharge.getUwFixedCharge();

                break;
            case SURFACE_WATER:
                costPerUnit = 0;
                CalculateMeasuredPropertyCharge measuredPropertyCharge = getMeasuredPropertyChargeBySupplierAndProperty(
                        estimateRequest.getSurfaceWaterSupplier(), estimateRequest.getPropertyType());

                propertyTypeAddition = measuredPropertyCharge.getSwdFixedCharge();
                break;

            case HIGHWAYS_DRAINAGE:
                measuredUsageCharge = getMeasuredUsageChargeBySupplier(estimateRequest.getHighwayDrainageSupplier());
                costPerUnit = measuredUsageCharge.getHdUnitCharge();
                propertyTypeAddition = measuredUsageCharge.getHdFixedCharge();

                break;
        }
        calculationValue.setCostPerUnit(round(costPerUnit, DECIMAL_PLACES));
        calculationValue.setPropertyTypeAddition(round(propertyTypeAddition, DECIMAL_PLACES));

        serviceConsumption = getServiceConsumption(numberOfDays, adcAdultUsage, adcChildUsage);

        serviceCost = getServiceCost(propertyTypeAddition, numberOfDays, costPerUnit, serviceConsumption);
        calculationValue.setConsumption(round(serviceConsumption, DECIMAL_PLACES));
        calculationValue.setService(serviceType.toString());
        calculationValue.setValue(round(serviceCost, DECIMAL_PLACES));
        log.debug("getCalculationValue start");
        return calculationValue;
    }

    private CalculateMeasuredPropertyCharge getMeasuredPropertyChargeBySupplierAndProperty(String supplier,
            PropertyType propertyType) {
        CalculateMeasuredPropertyCharge measuredPropertyCharge = null;
        try {
            measuredPropertyCharge = calculatorSuppliersService
                    .getMeasuredPropertyChargesBySupplierAndProperty(supplier, propertyType);
        } catch (NoResultException | NonUniqueResultException e2) {
            throwError(ConsumptionCalculatorErrorCodes.PROPERTY_TYPE_NOT_CONFIGURED);
        }
        return measuredPropertyCharge;
    }

    private CalculateMeasuredUsageCharge getMeasuredUsageChargeBySupplier(String supplier) {
        CalculateMeasuredUsageCharge measuredUsageCharge = null;
        try {
            measuredUsageCharge = calculatorSuppliersService
                    .getMeasuredUsageChargesBySupplier(supplier);
        } catch (NoResultException | NonUniqueResultException e2) {
            throwError(ConsumptionCalculatorErrorCodes.SERVICE_USAGE_UNIT_COST_NOT_CONFIGURED);
        }
        return measuredUsageCharge;
    }

    private void throwError(ErrorCode errorCode) throws ServiceException {
        throw new ServiceException(errorCode);
    }

    private double getServiceConsumption(int noOfDays, double adcAdultUsage, double adcChildUsage) {
        double serviceConsumption = noOfDays * (adcAdultUsage + adcChildUsage);
        return serviceConsumption;
    }

    private double getServiceCost(double propertyTypeAddition, int noOfDays, double costPerUnit,
            double serviceConsumption) {
        double totalCost = (propertyTypeAddition * noOfDays / DAYS_PER_YEAR) + costPerUnit * serviceConsumption;
        return totalCost;
    }

    private double round(double value, int places) {
        if (places < 0)
            throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    protected static class ConsumptionCalculatorErrorCodes {
        static ErrorCode NO_OF_ADULT_ZERO = new ErrorCode("CONSCAL101", "No of Adults Should atleast be 1");
        static ErrorCode NO_OF_ADULT_DO_NOT_EXIST = new ErrorCode("CONSCAL102",
                "No of Adults Not configured in Database");
        static ErrorCode NO_OF_CHILDREN_DO_NOT_EXIST = new ErrorCode("CONSCAL103",
                "No of children not configured in Database");
        static ErrorCode PROPERTY_TYPE_NOT_CONFIGURED = new ErrorCode("CONSCAL104",
                "Property Type not configured in Database");
        static ErrorCode SERVICE_USAGE_UNIT_COST_NOT_CONFIGURED = new ErrorCode("CONSCAL105",
                "Service Usage unit cost not configured in Database");
        static ErrorCode INVALID_DATES = new ErrorCode("CONSCAL200", "Too long between start and end date");
        static ErrorCode INVALID_SERVICE_SUPPLIER = new ErrorCode("CONSCAL106",
                "Invalid Service & Supplier combination");
    }

}
