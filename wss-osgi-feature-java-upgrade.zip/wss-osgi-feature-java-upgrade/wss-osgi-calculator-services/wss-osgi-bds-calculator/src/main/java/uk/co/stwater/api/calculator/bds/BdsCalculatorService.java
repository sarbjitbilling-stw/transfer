package uk.co.stwater.api.calculator.bds;

import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorRequest;
import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorResponse;

public interface BdsCalculatorService {
    BdsPlanAmountCalculatorResponse calculatePlanAmounts(BdsPlanAmountCalculatorRequest calculatorRequest);
}
