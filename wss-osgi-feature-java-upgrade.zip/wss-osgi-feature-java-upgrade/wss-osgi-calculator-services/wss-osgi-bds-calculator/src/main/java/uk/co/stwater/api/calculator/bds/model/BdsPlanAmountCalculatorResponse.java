package uk.co.stwater.api.calculator.bds.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BdsPlanAmountCalculatorResponse {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private BdsPlanAmountCalculatorRequest request;

    @JsonProperty(required = true)
    private BigDecimal unadjustedYearlyTariffAmount;

    @JsonProperty(required = true)
    private BigDecimal unadjustedYearlyArrearsAmount;

    @JsonProperty(required = true)
    private BigDecimal monthlyTariffAmount;

    @JsonProperty(required = true)
    private BigDecimal monthlyArrearsAmount;

    public BdsPlanAmountCalculatorRequest getRequest() {
        return request;
    }

    public BigDecimal getUnadjustedYearlyTariffAmount() {
        return unadjustedYearlyTariffAmount;
    }

    public void setUnadjustedYearlyTariffAmount(BigDecimal unadjustedYearlyTariffAmount) {
        this.unadjustedYearlyTariffAmount = unadjustedYearlyTariffAmount;
    }

    public BigDecimal getUnadjustedYearlyArrearsAmount() {
        return unadjustedYearlyArrearsAmount;
    }

    public void setUnadjustedYearlyArrearsAmount(BigDecimal unadjustedYearlyArrearsAmount) {
        this.unadjustedYearlyArrearsAmount = unadjustedYearlyArrearsAmount;
    }

    public void setRequest(BdsPlanAmountCalculatorRequest request) {
        this.request = request;
    }

    public BigDecimal getMonthlyTariffAmount() {
        return monthlyTariffAmount;
    }

    public void setMonthlyTariffAmount(BigDecimal monthlyTariffAmount) {
        this.monthlyTariffAmount = monthlyTariffAmount;
    }

    public BigDecimal getMonthlyArrearsAmount() {
        return monthlyArrearsAmount;
    }

    public void setMonthlyArrearsAmount(BigDecimal monthlyArrearsAmount) {
        this.monthlyArrearsAmount = monthlyArrearsAmount;
    }
}
