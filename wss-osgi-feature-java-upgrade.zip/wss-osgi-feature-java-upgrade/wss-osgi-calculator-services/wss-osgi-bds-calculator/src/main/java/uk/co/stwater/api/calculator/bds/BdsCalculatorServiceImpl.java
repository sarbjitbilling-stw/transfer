package uk.co.stwater.api.calculator.bds;

import java.math.BigDecimal;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorRequest;
import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorResponse;
import uk.co.stwater.api.dao.BdsPaymentPlanAmountsDao;
import uk.co.stwater.api.dao.entity.BdsPaymentPlanAmount;

@Named
public class BdsCalculatorServiceImpl implements BdsCalculatorService {
    private static final Logger LOG = LoggerFactory.getLogger(BdsCalculatorServiceImpl.class);

    @Inject
    @OsgiService
    private BdsPaymentPlanAmountsDao bdsPaymentPlanAmountsDao;

    @Override
    public BdsPlanAmountCalculatorResponse calculatePlanAmounts(BdsPlanAmountCalculatorRequest calculatorRequest) {
        if (calculatorRequest.getPaidToDate() == null) {
            throw new BdsCalculationException("paidToDate amount is null");
        }
        if (calculatorRequest.getPaidToDate().signum() < 0) {
            throw new BdsCalculationException("paidToDate amount is negative");
        }

        LOG.debug("Retrieving BDS payment plan details for region={} bdsBand={}", calculatorRequest.getBdsPlanRegion(),
                calculatorRequest.getBand());
        // @formatter:off
        BdsPaymentPlanAmount bdsPaymentPlanAmount = bdsPaymentPlanAmountsDao
                .find(calculatorRequest.getBdsPlanRegion(), calculatorRequest.getBand())
                .orElseThrow(() -> new BdsCalculationException("BDS payment plan amount not found"));
        // @formatter:on

        BigDecimal tariffAmount = bdsPaymentPlanAmount.getTariffAmount();
        BigDecimal arrearsAmount = bdsPaymentPlanAmount.getArrearsAmount();
        if (!calculatorRequest.getInArrears()) {
            arrearsAmount = BigDecimal.ZERO;
            bdsPaymentPlanAmount.setArrearsAmount(BigDecimal.ZERO);
        }

        BigDecimal planAmount = tariffAmount.add(arrearsAmount);

        LOG.debug("BDS payment plan amount is {} (tariff={}, arrears={}) for region={} bdsBand={}", planAmount,
                tariffAmount, arrearsAmount, calculatorRequest.getBdsPlanRegion(), calculatorRequest.getBand());

        return calculateLeftToPayPlanAmounts(calculatorRequest, bdsPaymentPlanAmount, planAmount, tariffAmount,
                arrearsAmount);
    }

    private BdsPlanAmountCalculatorResponse calculateLeftToPayPlanAmounts(
            BdsPlanAmountCalculatorRequest calculatorRequest, BdsPaymentPlanAmount bdsPaymentPlanAmount,
            BigDecimal planAmount, BigDecimal tariffAmount, BigDecimal arrearsAmount) {
        BigDecimal paidToDate = calculatorRequest.getPaidToDate();
        BigDecimal tariffLeftToPay;
        BigDecimal arrearsLeftToPay;
        // amount paid to date should be first taken off arrears then tariff
        if (paidToDate.compareTo(arrearsAmount) <= 0) {
            tariffLeftToPay = tariffAmount;
            arrearsLeftToPay = arrearsAmount.subtract(paidToDate);
        } else if (paidToDate.compareTo(planAmount) < 0) {
            tariffLeftToPay = planAmount.subtract(paidToDate);
            arrearsLeftToPay = BigDecimal.ZERO;
        } else {
            throw new BdsCalculationException("Amount paid to date should be less than plan total");
        }

        BigDecimal leftToPay = tariffLeftToPay.add(arrearsLeftToPay);

        LOG.debug("BDS payment plan left to pay amount is {} (tariff={}, arrears={}) for region={} bdsBand={}",
                leftToPay, tariffLeftToPay, arrearsLeftToPay, calculatorRequest.getBdsPlanRegion(),
                calculatorRequest.getBand());

        BigDecimal monthsLeft = new BigDecimal(calculatorRequest.getMonthsLeft());
        BigDecimal montlyTariffAmount = tariffLeftToPay.divide(monthsLeft, 2, BigDecimal.ROUND_HALF_UP);
        BigDecimal montlyArrearsAmount = arrearsLeftToPay.divide(monthsLeft, 2, BigDecimal.ROUND_HALF_UP);

        BdsPlanAmountCalculatorResponse response = new BdsPlanAmountCalculatorResponse();

        response.setRequest(calculatorRequest);
        response.setUnadjustedYearlyTariffAmount(bdsPaymentPlanAmount.getTariffAmount());
        response.setUnadjustedYearlyArrearsAmount(bdsPaymentPlanAmount.getArrearsAmount());
        response.setMonthlyTariffAmount(montlyTariffAmount);
        response.setMonthlyArrearsAmount(montlyArrearsAmount);

        return response;
    }
}
