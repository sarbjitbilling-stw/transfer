package uk.co.stwater.api.calculator.bds.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import uk.co.stwater.api.dao.entity.BdsPlanRegion;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

public class BdsPlanAmountCalculatorRequest {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private BdsPlanAmountCalculatorRequest request;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String legalEntity;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private TargetAccountNumber accountNumber;
    @JsonInclude
    private BdsPlanRegion bdsPlanRegion;
    @JsonInclude
    private Boolean inArrears;
    @JsonInclude
    private String band;
    @JsonInclude
    private BigDecimal paidToDate;
    @JsonInclude
    private Integer monthsLeft;
    
    public BdsPlanAmountCalculatorRequest() {
    }

    public BdsPlanAmountCalculatorRequest(BdsPlanAmountCalculatorRequest calculationRequest) {
        this.request = calculationRequest.getRequest();
        this.legalEntity = calculationRequest.getLegalEntity();
        this.accountNumber = calculationRequest.getAccountNumber();
        this.bdsPlanRegion = calculationRequest.getBdsPlanRegion();
        this.inArrears = calculationRequest.getInArrears();
        this.band = calculationRequest.getBand();
        this.paidToDate = calculationRequest.getPaidToDate();
        this.monthsLeft = calculationRequest.getMonthsLeft();
    }

    public BdsPlanAmountCalculatorRequest getRequest() {
        return request;
    }

    public void setRequest(BdsPlanAmountCalculatorRequest request) {
        this.request = request;
    }

    public String getLegalEntity() {
        return legalEntity;
    }

    public void setLegalEntity(String legalEntity) {
        this.legalEntity = legalEntity;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(TargetAccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BdsPlanRegion getBdsPlanRegion() {
        return bdsPlanRegion;
    }

    public void setBdsPlanRegion(BdsPlanRegion bdsPlanRegion) {
        this.bdsPlanRegion = bdsPlanRegion;
    }

    public Boolean getInArrears() {
        return inArrears;
    }

    public void setInArrears(Boolean inArrears) {
        this.inArrears = inArrears;
    }

    public String getBand() {
        return band;
    }

    public void setBand(String band) {
        this.band = band;
    }

    public BigDecimal getPaidToDate() {
        return paidToDate;
    }

    public void setPaidToDate(BigDecimal paidToDate) {
        this.paidToDate = paidToDate;
    }

    public Integer getMonthsLeft() {
        return monthsLeft;
    }

    public void setMonthsLeft(Integer monthsLeft) {
        this.monthsLeft = monthsLeft;
    }

    public boolean hasCalculationInformation() {
        return bdsPlanRegion != null && inArrears != null && band != null && paidToDate != null && monthsLeft != null;
    }
}
