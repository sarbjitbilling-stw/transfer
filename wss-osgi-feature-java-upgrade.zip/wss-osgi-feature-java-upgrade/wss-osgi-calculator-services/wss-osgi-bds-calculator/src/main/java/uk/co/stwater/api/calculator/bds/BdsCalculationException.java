package uk.co.stwater.api.calculator.bds;

import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.util.STWBusinessException;

public class BdsCalculationException extends STWBusinessException {
    private static final long serialVersionUID = -4544441341812646487L;

    static final String DEFAULT_ERROR_CODE = "100";

    public BdsCalculationException(String msg) {
        this(DEFAULT_ERROR_CODE, msg);
    }

    public BdsCalculationException(String msg, Throwable t) {
        this(DEFAULT_ERROR_CODE, msg, t);
    }

    public BdsCalculationException(String errorCode, String msg) {
        super(msg, errorCode, ErrorCategory.BDS_CALCULATOR);
    }

    public BdsCalculationException(String errorCode, String msg, Throwable t) {
        super(msg, errorCode, ErrorCategory.BDS_CALCULATOR, t);
    }
}
