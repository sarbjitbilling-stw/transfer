package uk.co.stwater.api.calculator.bds;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import javax.ws.rs.core.Response;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorRequest;
import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorResponse;
import uk.co.stwater.api.dao.entity.BdsPlanRegion;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.iib.client.api.offers.OffersTargetService;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BdsCalculatorResourceTest {
    private static final TargetAccountNumber ACCOUNT_NUMBER = new TargetAccountNumber("123459");
    private static final String LEGAL_ENTTIY = "66635333";

    @Mock
    private GetPropertiesForAccountNumberClient targetAccountPropertiesClient;

    @Mock
    private OffersTargetService offersTargetService;

    @Mock
    private BdsCalculatorService bdsCalculatorService;

    @Spy
    @InjectMocks
    private BdsCalculatorResource bdsCalculatorResource = new BdsCalculatorResource();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void verifyPlanAmountRequestNullPlanType() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("bdsPlanRegion field is required");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setBdsPlanRegion(null);

        bdsCalculatorResource.verifyPlanAmountRequest(request);
    }

    @Test
    public void verifyPlanAmountRequestNullInArrears() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("inArrears field is required");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setInArrears(null);

        bdsCalculatorResource.verifyPlanAmountRequest(request);
    }

    @Test
    public void verifyPlanAmountRequestNullBand() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("band field is required");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setBand(null);

        bdsCalculatorResource.verifyPlanAmountRequest(request);
    }

    @Test
    public void verifyPlanAmountRequestNullMonthsLeft() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("monthsLeft field is required");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setMonthsLeft(null);

        bdsCalculatorResource.verifyPlanAmountRequest(request);
    }

    @Test
    public void verifyPlanAmountRequestNullPaidToDate() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("paidToDate field is required");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setPaidToDate(null);

        bdsCalculatorResource.verifyPlanAmountRequest(request);
    }

    @Test
    public void verifyPlanAmountRequestNegativePaidToDate() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("paidToDate field must not be negative");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setPaidToDate(new BigDecimal("-1.00"));

        bdsCalculatorResource.verifyPlanAmountRequest(request);
    }

    @Test
    public void calculatePlanAmountNullRequest() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("calculatorRequest body is required");

        bdsCalculatorResource.calculatePlanAmount(null);
    }

    @Test
    public void calculatePlanAmountRequestFieldNotNull() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("request field must not be specified");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setRequest(new BdsPlanAmountCalculatorRequest());

        bdsCalculatorResource.calculatePlanAmount(request);
    }

    @Test
    public void calculatePlanAmountCalculation() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        BdsPlanAmountCalculatorResponse mockResponse = new BdsPlanAmountCalculatorResponse();

        when(bdsCalculatorService.calculatePlanAmounts(request)).thenReturn(mockResponse);

        Response actual = bdsCalculatorResource.calculatePlanAmount(request);

        assertSame(mockResponse, actual.getEntity());
        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());

        verify(bdsCalculatorResource).verifyPlanAmountRequest(request);
    }

    @Test
    public void calculatePlanAmountDefaultsArrears() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequestDefaults();

        when(offersTargetService.isAccountInArrears(ACCOUNT_NUMBER, null)).thenReturn(true);

        Response actual = bdsCalculatorResource.calculatePlanAmount(request);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertTrue(actual.getEntity() instanceof BdsPlanAmountCalculatorRequest);
        BdsPlanAmountCalculatorRequest response = (BdsPlanAmountCalculatorRequest) actual.getEntity();
        assertTrue(response.getInArrears());

        verify(offersTargetService).isAccountInArrears(ACCOUNT_NUMBER, null);
    }

    @Test
    public void calculatePlanAmountDefaultsNoArrears() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequestDefaults();

        when(offersTargetService.isAccountInArrears(ACCOUNT_NUMBER, null)).thenReturn(false);

        Response actual = bdsCalculatorResource.calculatePlanAmount(request);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertTrue(actual.getEntity() instanceof BdsPlanAmountCalculatorRequest);
        BdsPlanAmountCalculatorRequest response = (BdsPlanAmountCalculatorRequest) actual.getEntity();
        assertFalse(response.getInArrears());

        verify(offersTargetService).isAccountInArrears(ACCOUNT_NUMBER, null);
    }

    @Test
    public void calculatePlanAmountDefaultsOverriddenByRequest() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequestDefaults();
        request.setInArrears(false);

        when(offersTargetService.isAccountInArrears(ACCOUNT_NUMBER, null)).thenReturn(true);

        Response actual = bdsCalculatorResource.calculatePlanAmount(request);

        assertEquals(Response.Status.OK.getStatusCode(), actual.getStatus());
        assertTrue(actual.getEntity() instanceof BdsPlanAmountCalculatorRequest);
        BdsPlanAmountCalculatorRequest response = (BdsPlanAmountCalculatorRequest) actual.getEntity();
        assertFalse(response.getInArrears());

        verifyZeroInteractions(offersTargetService);
    }

    @Test
    public void calculatePlanAmountMissingAccount() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("Missing fields for calculation and for calculating defaults");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequestDefaults();
        request.setAccountNumber(null);

        bdsCalculatorResource.calculatePlanAmount(request);
    }

    @Test
    public void calculatePlanAmountMissingLegalEntity() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("Missing fields for calculation and for calculating defaults");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequestDefaults();
        request.setLegalEntity(null);

        bdsCalculatorResource.calculatePlanAmount(request);
    }

    private BdsPlanAmountCalculatorRequest buildBdsPlanAmountCalculatorRequest() {
        BdsPlanAmountCalculatorRequest request = new BdsPlanAmountCalculatorRequest();

        request.setBdsPlanRegion(BdsPlanRegion.STW_REGION);
        request.setInArrears(false);
        request.setBand("5");
        request.setMonthsLeft(5);
        request.setPaidToDate(new BigDecimal("12.00"));

        return request;
    }

    private BdsPlanAmountCalculatorRequest buildBdsPlanAmountCalculatorRequestDefaults() {
        BdsPlanAmountCalculatorRequest request = new BdsPlanAmountCalculatorRequest();

        request.setAccountNumber(ACCOUNT_NUMBER);
        request.setLegalEntity(LEGAL_ENTTIY);

        return request;
    }

}
