package uk.co.stwater.api.calculator.bds;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorRequest;
import uk.co.stwater.api.calculator.bds.model.BdsPlanAmountCalculatorResponse;
import uk.co.stwater.api.dao.BdsPaymentPlanAmountsDao;
import uk.co.stwater.api.dao.entity.BdsPaymentPlanAmount;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BdsCalculatorServiceImplTest {

    @Mock
    private BdsPaymentPlanAmountsDao bdsPaymentPlanAmountsDao;

    @InjectMocks
    private BdsCalculatorServiceImpl bdsCalculatorService = new BdsCalculatorServiceImpl();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void calculatePlanAmountsNegativePaidToDate() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("paidToDate amount is negative");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();
        request.setPaidToDate(new BigDecimal("-1"));

        bdsCalculatorService.calculatePlanAmounts(request);
    }

    @Test
    public void calculatePlanAmountsBdsPlanAmountNotFound() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("BDS payment plan amount not found");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest();

        when(bdsPaymentPlanAmountsDao.find(request.getBdsPlanRegion(), request.getBand())).thenReturn(Optional.empty());

        bdsCalculatorService.calculatePlanAmounts(request);
    }

    @Test
    public void calculatePlanAmountsPaidToDateZero() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest(true, BigDecimal.ZERO);
        BdsPaymentPlanAmount bdsPaymentPlanAmount = buildBdsPaymentPlanAmount();

        when(bdsPaymentPlanAmountsDao.find(request.getBdsPlanRegion(), request.getBand()))
                .thenReturn(Optional.of(bdsPaymentPlanAmount));

        BdsPlanAmountCalculatorResponse actual = bdsCalculatorService.calculatePlanAmounts(request);

        assertSame(request, actual.getRequest());
        assertEquals(new BigDecimal("6.80"), actual.getMonthlyTariffAmount());
        assertEquals(new BigDecimal("2.41"), actual.getMonthlyArrearsAmount());
    }

    @Test
    public void calculatePlanAmountsPaidToDateLessThanArrears() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest(true, new BigDecimal("2.22"));
        BdsPaymentPlanAmount bdsPaymentPlanAmount = buildBdsPaymentPlanAmount();

        when(bdsPaymentPlanAmountsDao.find(request.getBdsPlanRegion(), request.getBand()))
                .thenReturn(Optional.of(bdsPaymentPlanAmount));

        BdsPlanAmountCalculatorResponse actual = bdsCalculatorService.calculatePlanAmounts(request);

        assertSame(request, actual.getRequest());
        assertEquals(new BigDecimal("6.80"), actual.getMonthlyTariffAmount());
        assertEquals(new BigDecimal("1.97"), actual.getMonthlyArrearsAmount());
    }

    @Test
    public void calculatePlanAmountsPaidToDateMoreThanArrears() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest(true, new BigDecimal("15.22"));
        BdsPaymentPlanAmount bdsPaymentPlanAmount = buildBdsPaymentPlanAmount();

        when(bdsPaymentPlanAmountsDao.find(request.getBdsPlanRegion(), request.getBand()))
                .thenReturn(Optional.of(bdsPaymentPlanAmount));

        BdsPlanAmountCalculatorResponse actual = bdsCalculatorService.calculatePlanAmounts(request);

        assertSame(request, actual.getRequest());
        assertEquals(new BigDecimal("6.17"), actual.getMonthlyTariffAmount());
        assertEquals(new BigDecimal("0.00"), actual.getMonthlyArrearsAmount());
    }

    @Test
    public void calculatePlanAmountsPaidToDateMoreThanPlanAmount() {
        expectedException.expect(BdsCalculationException.class);
        expectedException.expectMessage("Amount paid to date should be less than plan total");

        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest(true, new BigDecimal("65.22"));
        BdsPaymentPlanAmount bdsPaymentPlanAmount = buildBdsPaymentPlanAmount();

        when(bdsPaymentPlanAmountsDao.find(request.getBdsPlanRegion(), request.getBand()))
                .thenReturn(Optional.of(bdsPaymentPlanAmount));

        bdsCalculatorService.calculatePlanAmounts(request);
    }

    @Test
    public void calculatePlanAmountsNotInArrearsAndPaidToDateLessThanArrears() {
        BdsPlanAmountCalculatorRequest request = buildBdsPlanAmountCalculatorRequest(false, new BigDecimal("2.22"));
        BdsPaymentPlanAmount bdsPaymentPlanAmount = buildBdsPaymentPlanAmount();

        when(bdsPaymentPlanAmountsDao.find(request.getBdsPlanRegion(), request.getBand()))
                .thenReturn(Optional.of(bdsPaymentPlanAmount));

        BdsPlanAmountCalculatorResponse actual = bdsCalculatorService.calculatePlanAmounts(request);

        assertSame(request, actual.getRequest());
        assertEquals(new BigDecimal("6.36"), actual.getMonthlyTariffAmount());
        assertEquals(new BigDecimal("0.00"), actual.getMonthlyArrearsAmount());
    }

    private BdsPlanAmountCalculatorRequest buildBdsPlanAmountCalculatorRequest() {
        return buildBdsPlanAmountCalculatorRequest(true, new BigDecimal("4.052"));
    }

    private BdsPlanAmountCalculatorRequest buildBdsPlanAmountCalculatorRequest(boolean inArrears,
            BigDecimal paidToDate) {
        BdsPlanAmountCalculatorRequest request = new BdsPlanAmountCalculatorRequest();

        request.setInArrears(inArrears);
        request.setPaidToDate(paidToDate);
        request.setMonthsLeft(5);

        return request;
    }

    private BdsPaymentPlanAmount buildBdsPaymentPlanAmount() {
        BdsPaymentPlanAmount bdsPaymentPlanAmount = new BdsPaymentPlanAmount();

        // extra decimal precision used to check all fields rounded
        bdsPaymentPlanAmount.setTariffAmount(new BigDecimal("34.023"));
        bdsPaymentPlanAmount.setArrearsAmount(new BigDecimal("12.049"));

        return bdsPaymentPlanAmount;
    }

}
