package uk.co.stwater.api.calculator.offers.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory.OFFERS_CALCULATOR_SERVICES;


@Path("/calculation")
@Named("offersCalculatorRestResource")
public class OffersCalculatorServiceRestResource extends AbstractResource {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    private OffersCalculationService offersCalculationService;

    public OffersCalculatorServiceRestResource() {
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response calculate(OffersCalculationRequest offersCalculationRequest) {

        try {
            log.debug("OffersCalculatorServiceRestResource : start");

            GenericEntity<OffersCalculation> entity = new GenericEntity<OffersCalculation>(offersCalculationService.calculate(offersCalculationRequest,
                    getUserIdentity().getUsername())) {
            };
            log.debug("OffersCalculatorServiceRestResource : finish");
            return Response.status(Response.Status.OK).entity(entity).build();
        } catch (STWTechnicalException e) {
            ErrorDto errorDto = new ErrorDto(OFFERS_CALCULATOR_SERVICES, 100, e.getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        } catch (STWBusinessException ex) {
            ErrorDto errorDto = new ErrorDto(OFFERS_CALCULATOR_SERVICES, 100, ex.getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        } catch (ServiceException se) {
            ErrorDto errorDto = new ErrorDto(OFFERS_CALCULATOR_SERVICES, se.getCode().getCode(), se.getCode().getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }
    }
}
