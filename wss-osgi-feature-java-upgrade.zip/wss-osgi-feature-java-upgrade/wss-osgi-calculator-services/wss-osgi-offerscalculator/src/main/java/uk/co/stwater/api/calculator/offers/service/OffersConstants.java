package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;

public class OffersConstants {
    public static final BigDecimal DAYS_IN_YEAR = new BigDecimal("365");
    public static final BigDecimal NO_OF_MOTHS_IN_YEAR = new BigDecimal("12");

    public static final BigDecimal DEFAULT_UPLIFT = new BigDecimal("1.3");
    public static final String OFFERS_VERSION = "PI-1.6.4";
    public static final int DECIMAL_PLACES = 2;
    public static final int DECIMAL_PLACES_SIX = 6;
    public static final int UPLIFT_DECIMAL_PLACES = 10;
    public static final int DECIMAL_PLACES_IN_DAYS = 0;
    public static final int NEAREST_POUND = 0;
    public static final int DECIMAL_PLACES_FOUR = 4;

    public static final int NO_OF_INSTALLMENTS_IS_TWO = 2;
    public static final int NO_OF_INSTALLMENTS_IS_THREE = 3;
    public static final int SECOND_INSTALLMENT_LIST_POSITION = 1;

    public static final BigDecimal AVERAGE_NO_OF_DAYS_IN_MONTH = new BigDecimal("30.4167");
    public static final BigDecimal NO_OF_DAYS_IN_MONTHLY_FREQUENCY = new BigDecimal("29");
    public static final BigDecimal NO_OF_DAYS_IN_FOUR_WEEKLY_FREQUENCY = new BigDecimal("28");
    public static final BigDecimal NO_OF_DAYS_IN_FORTNIGHTLY_FREQUENCY = new BigDecimal("14");
    public static final BigDecimal NO_OF_DAYS_IN_WEEKLY_FREQUENCY = new BigDecimal("7");

    public static final int WEEKS_IN_WEEKLY = 1;
    public static final int WEEKS_IN_FORNIGHTLY = 2;
    public static final int WEEKS_IN_FOUR_WEEKLY = 4;

    public static final BigDecimal NO_OF_WEEKS_PER_MONTH = new BigDecimal("4.2");
    public static final BigDecimal NO_OF_WEEKS_PER_FORTNIGHT = new BigDecimal("2");

    public static final String CALCULATION_STATUS_FIRST_ELIGIBLE = "FIRST_ELIGIBLE";
    public static final String CALCULATION_STATUS_SUBSEQUENT_ELIGIBLE = "SUBSEQUENT_ELIGIBLE";

    public static final String PLAN_VARIANT_PPC_PATTERN = "PPC";
    public static final String PLAN_VARIANT_BDS = "BDS";
    public static final BigDecimal PPC_LENGTH_TWELVE = new BigDecimal("12");
    public static final String PLAN_VARIANT_FLEX_PATTERN = "Flex";
    public static final String PLAN_VARIANT_ZERO_PERCENTAGE_FLEX = "Flex0"; //Will be used when preferred payment Standard offer is modified, then 0% Flex will be renamed as Flex0.
    public static final String PREFERRED_PAYMENT_STANDARD_IDENTIFIER = "_PP_STD";
    public static final String PREFERRED_PAYMENT_FLEX_IDENTIFIER = "_PP_FLEX";
    public static final String PREFERRED_PAYMENT_PPC_IDENTIFIER = "_PP_PPC";
    public static final int DISPLAY_ORDER_MULTIPLIER = 10;
    public static final int DISPLAY_ORDER_INIT_VALUE_STANDARD = 1;
    public static final int DISPLAY_ORDER_INIT_VALUE_FLEX = 100;
    public static final int DISPLAY_ORDER_INIT_VALUE_PPC = 500;
    public static final int PREFERRED_PAYMENT_DISPLAY_ORDER_INCREMENT = 1;
    public static final Month TARGET_END_OF_BILLING_YEAR_MONTH = Month.MARCH;

    public static final BigDecimal MIN_WEEKLY_OR_FORTNIGHTLY_INSTALLMENT = new BigDecimal("1.00");
    public static final BigDecimal MIN_MONTHLY_OR_FOUR_WEEKLY_INSTALLMENT = new BigDecimal("3.00");
    public static final BigDecimal MIN_BDS_INSTALLMENT = new BigDecimal("1.00");
    public static final int FIRST_SERVICE_PROVISION_BUDGET = 0;
    public static final int INVOICE_FOR_UNMEASURED = 0;

    public static final BigDecimal MIN_WEEKLY_NO_OF_INSTALLMENTS = new BigDecimal("8");
    public static final BigDecimal MIN_FORTNIGHTLY_NO_OF_INSTALLMENTS = new BigDecimal("4");
    public static final BigDecimal MIN_FOUR_WEEKLY_NO_OF_INSTALLMENTS = new BigDecimal("2");
    public static final BigDecimal MIN_MONTHLY_NO_OF_INSTALLMENTS = new BigDecimal("2");

    public static final LocalDate MAIN_BILLING_DATE = LocalDate.of(LocalDate.now().getYear(), Month.MARCH, 31);

}

