package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.osgi.model.calculator.offers.WarningDTO;

public class OffersCalculatorWarnings {
    public static final WarningDTO WARNING_NO_HISTORY = new WarningDTO("OFFERS_WARN001",
            "No billing history has been found for your customer. Please update the usage calculator to forecast their expected cost",
            WarningDTO.WarningCategory.NO_HISTORY);

    public static final WarningDTO WARNING_LESS_THAN_ONE_YEAR_HISTORY = new WarningDTO("OFFERS_WARN002",
            "Less than a year's billing history has been found for your customer. Please update the usage calculator to forecast their expected cost",
            WarningDTO.WarningCategory.LESS_THAN_ONE_YEAR_HISTORY);

    public static final WarningDTO WARNING_LESS_THAN_MINIMUM_HISTORY = new WarningDTO("OFFERS_WARN003",
            "Insufficient billing history has been found for your customer. Please update the usage calculator to forecast their expected cost",
            WarningDTO.WarningCategory.LESS_THAN_MINIMUM_HISTORY);

    protected static WarningDTO WARNING_NO_ACTIVE_SERVICE_PROVISIONS_FOUND() {
        return new WarningDTO("OFFERS_WARN005",
                "WARNING: Service provision not found in active Service Provisions",
                WarningDTO.WarningCategory.NO_ACTIVE_SERVICE_PROVISIONS_FOUND);
    }
}