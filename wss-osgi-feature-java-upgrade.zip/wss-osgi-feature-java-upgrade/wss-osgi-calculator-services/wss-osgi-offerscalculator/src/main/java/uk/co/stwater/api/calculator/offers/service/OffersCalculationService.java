package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.core.service.Service;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;

public interface OffersCalculationService extends Service {
    OffersCalculation calculate(final OffersCalculationRequest request, final String authToken) throws ServiceException;
}
