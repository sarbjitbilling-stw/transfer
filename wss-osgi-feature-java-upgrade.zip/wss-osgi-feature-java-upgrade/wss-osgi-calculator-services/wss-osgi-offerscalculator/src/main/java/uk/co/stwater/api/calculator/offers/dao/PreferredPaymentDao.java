package uk.co.stwater.api.calculator.offers.dao;

import uk.co.stwater.model.calculator.offers.PreferredPayment;

import java.util.List;

public interface PreferredPaymentDao {
    List<PreferredPayment> find(int offerLevel);
}
