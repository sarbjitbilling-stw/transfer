package uk.co.stwater.api.calculator.offers.dao;

import java.util.List;

import uk.co.stwater.api.core.dao.CrudDao;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

public interface PaymentPlanDao extends CrudDao<Long, PaymentPlan> {

	PaymentPlan findByOfferId(String offerId);
	List<PaymentPlan> findAll();
	List<PaymentPlan> find(String serviceType);
	List<PaymentPlan> find(String serviceType, String paymentMethod, String paymentFrequency);

    List<PaymentPlan> find(String serviceType, String paymentMethod, String paymentFrequency, String planVariant,
            Integer length);
	List<PaymentPlan> findWithAllPpc(String serviceType, String paymentMethod,
                                     String paymentFrequency);
}
