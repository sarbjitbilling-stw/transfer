package uk.co.stwater.model.calculator.offers;

import uk.co.stwater.api.core.model.BaseModel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;

@Entity()
@Table(name = "WSS_PREFERRED_PAYMENT")
public class PreferredPayment extends BaseModel<Long> {
    private int offerLevel;
    private String paymentFrequency;
    private BigDecimal maxIncrement = BigDecimal.ZERO;

    @Column(nullable = false)
    public int getOfferLevel() {
        return offerLevel;
    }

    public void setOfferLevel(int offerLevel) {
        this.offerLevel = offerLevel;
    }

    @Column(nullable = false)
    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    @Column(nullable = false)
    public BigDecimal getMaxIncrement() {
        return maxIncrement;
    }

    public void setMaxIncrement(BigDecimal maxIncrement) {
        this.maxIncrement = maxIncrement;
    }
}