package uk.co.stwater.api.calculator.offers.dao;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.model.calculator.offers.PreferredPayment;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;
import java.util.List;

@OsgiServiceProvider(classes = {PreferredPaymentDao.class})
@Transactional
@Named
public class PreferredPaymentDaoImpl implements PreferredPaymentDao {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @PersistenceContext(unitName = "wssPersistence-offers")
    protected EntityManager entityManager;

    public PreferredPaymentDaoImpl() {
    }

    public PreferredPaymentDaoImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public List<PreferredPayment> find(int offerLevel) {
        log.debug("PreferredPaymentDaoImpl: find for offerLevel {} ", offerLevel);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PreferredPayment> criteriaQuery = criteriaBuilder.createQuery(PreferredPayment.class);
        Root<PreferredPayment> pp = criteriaQuery.from(PreferredPayment.class);
        Predicate offerLevelPredicate = criteriaBuilder.equal(pp.get("offerLevel"), offerLevel);
        criteriaQuery.where(offerLevelPredicate);
        TypedQuery<PreferredPayment> query = this.entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }
}
