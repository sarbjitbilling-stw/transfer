package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.osgi.model.calculator.offers.Invoice;
import uk.co.stwater.api.osgi.model.calculator.offers.InvoiceLine;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface InvoiceAnalyser {
    Optional<Invoice> getLatestNonCancelledInvoice(final List<Invoice> allInvoices);

    boolean isLatestInvoiceOfPastOneYearCancelled(final List<Invoice> allInvoices, final LocalDate targetDate);

    List<Invoice> getPastOneYearNonCancelledInvoices(final List<Invoice> allInvoices, final LocalDate targetDate);

    List<Invoice> getLatestNonCancelledInvoiceOfPastOneYear(final List<Invoice> allInvoices, final LocalDate targetDate);

    List<Invoice> getOrderedNonCancelledAndIssuedInvoices(final List<Invoice> allInvoices);

    List<InvoiceLine> getInvoiceLinesOfLatestMoveIn(final List<InvoiceLine> invoiceLines, final LocalDate oldestServiceStartDate);

}
