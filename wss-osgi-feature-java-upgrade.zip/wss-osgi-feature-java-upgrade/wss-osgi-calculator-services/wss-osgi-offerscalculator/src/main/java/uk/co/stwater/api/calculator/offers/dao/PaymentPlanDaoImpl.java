package uk.co.stwater.api.calculator.offers.dao;

import java.util.List;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.dao.AbstractCrudDao;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

@OsgiServiceProvider(classes = {PaymentPlanDao.class})
@Transactional
@Named
public class PaymentPlanDaoImpl extends AbstractCrudDao<Long, PaymentPlan> implements PaymentPlanDao {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @PersistenceContext(unitName = "wssPersistence-offers")
    protected EntityManager entityManager;

    public PaymentPlanDaoImpl() {
    }

    public PaymentPlanDaoImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public PaymentPlan findByOfferId(String offerId) {

        log.debug("PaymentPlanDaoImpl findByOfferId for offerId {}", offerId);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentPlan> criteriaQuery = criteriaBuilder.createQuery(PaymentPlan.class);
        Root<PaymentPlan> adc = criteriaQuery.from(PaymentPlan.class);

        Predicate adcPredicate = criteriaBuilder.equal(adc.get("offerId"), offerId);
        Predicate selectPredicate = criteriaBuilder.and(adcPredicate);
        criteriaQuery.where(selectPredicate);

        TypedQuery<PaymentPlan> query = this.entityManager.createQuery(criteriaQuery);

        return query.getSingleResult();
    }

    @Override
    public List<PaymentPlan> find(String serviceType) {

        log.debug("PaymentPlanDaoImpl find for serviceType {} ", serviceType);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentPlan> criteriaQuery = criteriaBuilder.createQuery(PaymentPlan.class);
        Root<PaymentPlan> root = criteriaQuery.from(PaymentPlan.class);

        Predicate activePredicate = criteriaBuilder.equal(root.get("active"), "Y");
        Predicate serviceTypePredicate = criteriaBuilder.equal(root.get("serviceType"), serviceType);
        Predicate selectPredicate = criteriaBuilder.and(activePredicate, serviceTypePredicate);
        criteriaQuery.where(selectPredicate);

        TypedQuery<PaymentPlan> query = this.entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }

    @Override
    public EntityManager getEntityManager() {
        return this.entityManager;
    }

    @Override
    public List<PaymentPlan> findAll() {
        log.debug("findAll PaymentPlans");
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<PaymentPlan> criteriaQuery = criteriaBuilder.createQuery(PaymentPlan.class);
        Root<PaymentPlan> root = criteriaQuery.from(PaymentPlan.class);
        criteriaQuery.select(root);
        return getEntityManager().createQuery(criteriaQuery).getResultList();
    }

    @Override
    public List<PaymentPlan> find(String serviceType, String paymentMethod, String paymentFrequency) {
        return find(serviceType, paymentMethod, paymentFrequency, null, null);
    }

    @Override
    public List<PaymentPlan> find(String serviceType, String paymentMethod, String paymentFrequency,
            String planVariant, Integer length) {
        log.debug("PaymentPlanDaoImpl findByPaymentMethodAndFrequency for {} and {} ", paymentMethod, paymentFrequency);

        if (paymentMethod == null && paymentFrequency == null) return find(serviceType);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentPlan> criteriaQuery = criteriaBuilder.createQuery(PaymentPlan.class);
        Root<PaymentPlan> adc = criteriaQuery.from(PaymentPlan.class);

        Predicate activePredicate = criteriaBuilder.equal(adc.get("active"), "Y");
        Predicate serviceTypePredicate = criteriaBuilder.equal(adc.get("serviceType"), serviceType);
        Predicate adcPredicate = criteriaBuilder.equal(adc.get("paymentMethod"), paymentMethod);
        Predicate freqPredicate = criteriaBuilder.equal(adc.get("paymentFrequency"), paymentFrequency);
        Predicate selectPredicate = criteriaBuilder.and(activePredicate, serviceTypePredicate, adcPredicate, freqPredicate);
        if (StringUtils.isNotEmpty(planVariant)) {
            Predicate planVariantPredicate = criteriaBuilder.equal(adc.get("planVariant"), planVariant);
            selectPredicate = criteriaBuilder.and(selectPredicate, planVariantPredicate);
        }
        if (length != null) {
            Predicate lengthPredicate = criteriaBuilder.equal(adc.get("length"), length);
            selectPredicate = criteriaBuilder.and(selectPredicate, lengthPredicate);
        }
        criteriaQuery.where(selectPredicate);

        TypedQuery<PaymentPlan> query = this.entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }

    @Override
    public List<PaymentPlan> findWithAllPpc(String serviceType, String paymentMethod, String paymentFrequency) {
        log.debug("PaymentPlanDaoImpl findByPaymentMethodAndFrequency for {} and {} ", paymentMethod, paymentFrequency);

        if (paymentMethod == null && paymentFrequency == null) return find(serviceType);

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentPlan> criteriaQuery = criteriaBuilder.createQuery(PaymentPlan.class);
        Root<PaymentPlan> adc = criteriaQuery.from(PaymentPlan.class);

        Predicate activePredicate = criteriaBuilder.equal(adc.get("active"), "Y");
        Predicate serviceTypePredicate = criteriaBuilder.equal(adc.get("serviceType"), serviceType);
        Predicate methodPredicate = criteriaBuilder.equal(adc.get("paymentMethod"), paymentMethod);
        Predicate freqPredicate = criteriaBuilder.equal(adc.get("paymentFrequency"), paymentFrequency);

        //Predicate for payment plans which match active, serviceType, method and frequency
        Predicate methodAndFreqPredicate = criteriaBuilder.and(activePredicate, serviceTypePredicate, methodPredicate, freqPredicate);

        //Predicate for payment plans which match active, serviceType, method, and have planVariant LIKE "PPC%"
        Predicate planVariantPredicate = criteriaBuilder.like(adc.get("planVariant"), "PPC%");
        Predicate ppcPredicate = criteriaBuilder.and(activePredicate, serviceTypePredicate, methodPredicate, planVariantPredicate);

        //Result must satisfy one or other predicate
        Predicate selectPredicate = criteriaBuilder.or(methodAndFreqPredicate, ppcPredicate);
        criteriaQuery.where(selectPredicate);

        TypedQuery<PaymentPlan> query = this.entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }


}
