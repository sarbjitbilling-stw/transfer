package uk.co.stwater.api.calculator.offers.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.transaction.Transactional;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.offers.dao.PaymentPlanDao;
import uk.co.stwater.api.calculator.offers.dao.PreferredPaymentDao;
import uk.co.stwater.api.core.service.BaseService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.calculator.offers.Arrears;
import uk.co.stwater.api.osgi.model.calculator.offers.Budget;
import uk.co.stwater.api.osgi.model.calculator.offers.BudgetPlanTypes;
import uk.co.stwater.api.osgi.model.calculator.offers.BudgetUplift;
import uk.co.stwater.api.osgi.model.calculator.offers.Invoice;
import uk.co.stwater.api.osgi.model.calculator.offers.InvoiceLine;
import uk.co.stwater.api.osgi.model.calculator.offers.MeasuredIndicator;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OfferPaymentFrequency;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.model.calculator.offers.PayPlanType;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanControls;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanOfferLevel;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvision;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvisionBudget;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.offers.OffersTargetService;
import uk.co.stwater.iib.client.api.specialconditions.LegalEntitySpecialConditionClient;
import uk.co.stwater.model.calculator.offers.PaymentPlan;
import uk.co.stwater.model.calculator.offers.PreferredPayment;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;

@OsgiServiceProvider(classes = {OffersCalculationService.class})
@Named
@Transactional
@Singleton
public class OffersCalculationServiceImpl extends BaseService implements OffersCalculationService {

    private static final String HIGHWAYS_DRAINAGE = "HIGHD";

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    private PaymentPlanDao paymentPlanDao;

    @Inject
    private PreferredPaymentDao preferredPaymentDao;

    @Inject
    private InstallmentGenerator installmentGenerator;

    @Inject
    private BasePeriodAnalyser basePeriodAnalyser;

    @Inject
    private OfferGenerator offerGenerator;

    @Inject
    private OfferGeneratorPreferredPayment offerGeneratorPreferredPayment;

    @Inject
    private InvoiceAnalyser invoiceAnalyser;

    @OsgiService
    @Inject
    private GetAccountSummaryClient getAccountSummaryClient;

    @OsgiService
    @Inject
    private OffersTargetService offersTargetService;

    @OsgiService
    @Inject
    private LegalEntitySpecialConditionClient legalEntitySpecialConditionClient;

    @Override
    public void init() {
        super.init();
    }

    @Override
    public OffersCalculation calculate(final OffersCalculationRequest offersCalculationRequest, final String authToken) throws ServiceException {
        log.debug("OffersCalc: calculating for {}", offersCalculationRequest);
        // --- Validation ---
        validateRequest(offersCalculationRequest);

        // --- Initialize output object ---
        OffersCalculation offersCalculation = new OffersCalculation();
        offersCalculation.setOffersVersion(OffersConstants.OFFERS_VERSION);
        offersCalculation.setAccountNumber(offersCalculationRequest.getAccountNumber());
        offersCalculation.setOffersCalculationRequest(offersCalculationRequest);
        offersCalculation.setTargetDate(getTargetDate(authToken));

        TargetAccountNumber targetAccountNumber = offersCalculationRequest.getAccountNumber();
        log.debug("Retrieved account: {}", targetAccountNumber);

        boolean isBdsPlan = offersCalculationRequest.isBds();

        // --- Determine Active Service Provisions ---
        List<ServiceProvision> activeServiceProvisions = getActiveServiceProvisions(targetAccountNumber, authToken);
        log.debug("OffersCalc: Found {}, AND active service provisions for account {}", activeServiceProvisions.size(), targetAccountNumber);
        offersCalculation.setServiceProvisions(activeServiceProvisions);

        boolean isArrearsPlan = CollectionUtils.isEmpty(activeServiceProvisions);//If not active service provisions, then it will be an Arrears Payment Plan.
        // BDS takes priority over arrears as BDS is specifically asked for by UI
        if (isBdsPlan) {
            return calculateBdsPaymentPlans(offersCalculationRequest, offersCalculation, authToken);
        } else if (isArrearsPlan) {
            return calculateArrearsPaymentPlans(offersCalculationRequest, offersCalculation, authToken);
        } else {
            return calculatePaymentPlans(offersCalculationRequest, offersCalculation, authToken);
        }
    }

    /**
     * @param offersCalculationRequest : Key output object which holds, offers, budget, etc.
     * @param authToken
     * @return
     * @throws ServiceException
     */
    public OffersCalculation calculatePaymentPlans(final OffersCalculationRequest offersCalculationRequest, final OffersCalculation offersCalculation, final String authToken) throws ServiceException {
        log.debug("OffersCalc: calculating for {}", offersCalculationRequest);

        // --- Get the type of account (measured or unmeasured) ---
        TargetAccountNumber targetAccountNumber = offersCalculationRequest.getAccountNumber();
        log.debug("Retrieved account: {}", targetAccountNumber);
        String measuredIndicator = getMeasuredIndicatorForAccount(targetAccountNumber, authToken);
        offersCalculation.setMeasuredIndicator(measuredIndicator);
        setMeasuredIndicatorFlags(offersCalculation);
        // --- Validation for Preferred payment needs measured indicators -------
        validateRequestForPreferredPayment(offersCalculationRequest, offersCalculation);

        populateAccountSummary(offersCalculationRequest, offersCalculation);

        // --- Get the amount of arrears on this account ---
        // AccountBal > 0, then there could be both 3rdPartyAreas + StwAccountAreas, so we need to get the breakdown.
        // AccountBal <= 0 , StwAccountAreas is in credit, and 3rdPartyAreas = 0.
        Arrears arrears = new Arrears();
        if (offersCalculation.getAccountBalance().signum() <= 0) {
            arrears.setAccountArrears(offersCalculation.getAccountBalance());
        } else {
            // If there is a positive balance on the account, Then we need to find out the split between 3rd party areas & STW Account arreas(Hence call service)
            arrears = getArrears(targetAccountNumber, authToken);
        }

        //OriginalArrears: 3rdParty and Account arrears before subtracting the upfront. This logic required by Target, during plan creation.
        offersCalculation.setOriginalArrears(arrears);

        //BaseArrears is derived by subtracting upfront into original Arrears.(By default this is for 12 months)
        //BaseArrears: will be further modified for PPC2-PPC8 to be for 3 months equivalant.
        offersCalculation.setBaseArrears(getAdjustArrearsUsingUpfront(arrears, offersCalculationRequest.getUpfrontPaymentAmount()));

        List<PaymentPlan> paymentPlans = getPaymentPlansBasedOnArrearsAndMonth(offersCalculationRequest, offersCalculation);
        BigDecimal maxMeasuredFlexVariantAmount = BigDecimal.ZERO;
        if (offersCalculation.isMeasured()) {
            maxMeasuredFlexVariantAmount = getMaxMeasuredFlexVariantAmount(paymentPlans);//required only for Measured journey.
        }
        populateUplifts(targetAccountNumber, offersCalculation, paymentPlans, offersCalculation.isArrearsPlan(), authToken);
        populateUpliftsWithInServiveProvisions(offersCalculation);

        // --- Calculate budget (i.e. the amounts and bills on which the calculation will be based, Git Invoices and InvoiceLines) ---
        Budget budget = getBudget(targetAccountNumber, offersCalculation, authToken);
        offersCalculation.setBudget(budget);
        evalauteMainBillingCompletion(offersCalculation);

        basePeriodAnalyser.calculateForecastAndAccruedDetails(offersCalculation, measuredIndicator);

        if (OffersUtil.exitIfNoHistoryAndNoForecast(offersCalculation)) {
            return offersCalculation;//exit immediately.
        }

        // --- Calculate plan amount ---
        BigDecimal planAmount;
        if (offersCalculationRequest.getPlanAmount().signum() == 1) {
            planAmount = offersCalculationRequest.getPlanAmount();
            log.debug("OffersCalc: planAmount passed in: set to {}", planAmount);
        } else {
            planAmount = offersCalculation.getBaseArrears().getTotalArrears().add(offersCalculation.getBaseForecast()).add(offersCalculation.getBaseAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

            if (planAmount.signum() <= 0) {
                log.debug("OffersCalc: planAmount ended up negative, so no plan possible. Value calculated as {} "
                        , planAmount);
                throw new ServiceException(OffersCalculatorErrorCodes.PLAN_NOT_POSSIBLE);
            }
            log.debug("OffersCalc: planAmount not passed in: calculated as {}", planAmount);
        }
        offersCalculation.setPlanAmount(planAmount);//This is a provisional value. Each offer will have its own planAmount.

        // --- Calculate offers ---
        log.debug("OffersCalc: getOffers...");

        //Get all offers, but not preferred payment offers.
        //For Measured will consist of Standard Offer, Flex Offers(Flex1 to Flex6), PPC Offers (PPC1 to PPC8)
        //For UnMeasured will consist of Standard Offer, extended flex Offers(will be based on months), PPC Offers (PPC1 to PPC8)
        //For Assessed will consist of Standard Offer, PPC Offers (PPC1 to PPC8)
        List<Offer> offers = offerGenerator.getOffers(paymentPlans, offersCalculation);
        log.debug("OffersCalc: getOffers. No of offers: {}", offers.size());

        // --- For each offer, calculate installments ---
        log.debug("OffersCalc: calculateAndSetInstallments...");
        installmentGenerator.calculateAndSetInstallments(offers, offersCalculation, maxMeasuredFlexVariantAmount);

        // --- Return result ---
        offersCalculation.setOffers(offers);

        List<PreferredPayment> preferredPaymentIncrements = getPreferredPayment(PaymentPlanOfferLevel.STANDARD.getOfferLevel());

        //calculate preferred payment offers
        boolean isPreferredPaymentOfferAdded = offerGeneratorPreferredPayment.addPreferredPaymentOffers(offersCalculation, preferredPaymentIncrements);
        if (isPreferredPaymentOfferAdded) {
            installmentGenerator.addPreferredPaymentInstallments(offersCalculation);//calculate preferred payment installments.
        }

        //Due to the rounding rules in Measured Flex, some offers will end up identical.(ie: planamount, installments, etc)
        //Currently we remove duplicates of Measured Flex offers only.
        installmentGenerator.removeDuplicateMeasuredFlexOffers(offersCalculation);

        //offer can be made invalid if it has installments below certain threshold.
        installmentGenerator.checkOfferValidity(offersCalculation);
        return offersCalculation;
    }

    public OffersCalculation calculateBdsPaymentPlans(OffersCalculationRequest offersCalculationRequest,
            OffersCalculation offersCalculation, String authToken) {
        if (!offersCalculationRequest.getBds().hasOffersInformation()) {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_BDS_REQUEST);
        }
        
        log.debug("OffersCalc: calculating for {}", offersCalculationRequest);
        TargetAccountNumber targetAccountNumber = offersCalculationRequest.getAccountNumber();

        String measuredIndicator = getMeasuredIndicatorForAccount(targetAccountNumber, authToken);
        offersCalculation.setMeasuredIndicator(measuredIndicator);
        setMeasuredIndicatorFlags(offersCalculation);

        populateAccountSummary(offersCalculationRequest, offersCalculation);

        /*
         * BDS plans are treated as PPC plans in some places but not others so setting
         * both types of fields
         */
        offersCalculation.setOriginalForecast(offersCalculationRequest.getBds().getTotalTariffAmount());
        offersCalculation.setOriginalForecastForPPC(offersCalculationRequest.getBds().getTotalTariffAmount());
        offersCalculation.setBaseForecast(offersCalculationRequest.getBds().getTotalTariffAmount());
        offersCalculation.setBaseForecastForPPC(offersCalculationRequest.getBds().getTotalTariffAmount());

        Arrears arrears = new Arrears();
        BigDecimal arrearsAmount = offersCalculationRequest.getBds().getTotalArrearsAmount()
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        arrears.setAccountArrears(arrearsAmount);
        offersCalculation.setBaseArrears(arrears);
        offersCalculation.setOriginalArrears(arrears);

        List<PaymentPlan> paymentPlans = getBdsPaymentPlans(offersCalculationRequest, offersCalculation);

        BigDecimal planAmount = offersCalculationRequest.getBds().getTotalTariffAmount()
                .add(offersCalculationRequest.getBds().getTotalArrearsAmount())
                .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
        offersCalculation.setPlanAmount(planAmount);// This is a provisional value. Each offer will have its own
                                                    // planAmount.

        log.debug("OffersCalc BDS: getOffers...");

        // Get all offers, but not preferred payment offers.
        // For Measured will consist of Standard Offer, Flex Offers(Flex1 to Flex6), PPC
        // Offers (PPC1 to PPC8)
        // For UnMeasured will consist of Standard Offer, extended flex Offers(will be
        // based on months), PPC Offers (PPC1 to PPC8)
        // For Assessed will consist of Standard Offer, PPC Offers (PPC1 to PPC8)
        List<Offer> offers = offerGenerator.getOffers(paymentPlans, offersCalculation);
        log.debug("OffersCalc BDS: getOffers. No of offers: {}", offers.size());

        log.debug("OffersCalc BDS: calculateAndSetInstallments...");
        installmentGenerator.calculateAndSetInstallments(offers, offersCalculation, null);

        offersCalculation.setOffers(offers);

        // offer can be made invalid if it has installments below certain threshold.
        installmentGenerator.checkOfferValidity(offersCalculation);
        return offersCalculation;
    }

    public OffersCalculation calculateArrearsPaymentPlans(final OffersCalculationRequest offersCalculationRequest, final OffersCalculation offersCalculation, final String authToken) throws ServiceException {
        log.debug("OffersCalc: calculating for {}", offersCalculationRequest);
        TargetAccountNumber targetAccountNumber = offersCalculationRequest.getAccountNumber();

        String measuredIndicator = MeasuredIndicator.ARREARS.getTargetCode();//All Arrears Payment Plan journey will be assigned measured indicator as "Arrears"
        offersCalculation.setMeasuredIndicator(measuredIndicator);
        setMeasuredIndicatorFlags(offersCalculation);

        populateAccountSummary(offersCalculationRequest, offersCalculation);

        // --- Get the amount of arrears on this account ---
        // AccountBal > 0, then there could be both 3rdPartyAreas + StwAccountAreas, so we need to get the breakdown.
        // AccountBal <= 0 , StwAccountAreas is in credit, and 3rdPartyAreas = 0.
        Arrears arrears = new Arrears();
        if (offersCalculation.getAccountBalance().signum() <= 0) {
            arrears.setAccountArrears(offersCalculation.getAccountBalance());
        } else {
            // If there is a positive balance on the account, Then we need to find out the split between 3rd party areas & STW Account arreas(Hence call service)
            arrears = getArrears(targetAccountNumber, authToken);
        }

        //OriginalArrears: 3rdParty and Account arrears before subtracting the upfront. This logic required by Target, during plan creation.
        offersCalculation.setOriginalArrears(arrears);

        //BaseArrears is derived by subtracting upfront into original Arrears.(By default this is for 12 months)
        //BaseArrears: will be further modified for PPC2-PPC8 to be for 3 months equivalant.
        offersCalculation.setBaseArrears(getAdjustArrearsUsingUpfront(arrears, offersCalculationRequest.getUpfrontPaymentAmount()));

        List<PaymentPlan> paymentPlans = getArrearsPaymentPlans(offersCalculationRequest);

        // --- Calculate plan amount ---
        BigDecimal planAmount;
        if (offersCalculationRequest.getPlanAmount().signum() == 1) {
            planAmount = offersCalculationRequest.getPlanAmount();
            log.debug("OffersCalc: planAmount passed in: set to {}", planAmount);
        } else {
            planAmount = offersCalculation.getBaseArrears().getTotalArrears().add(offersCalculation.getBaseForecast()).add(offersCalculation.getBaseAccrued())
                    .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);

            if (planAmount.signum() <= 0) {
                log.debug("OffersCalc: planAmount ended up negative, so no plan possible. Value calculated as {} "
                        , planAmount);
                throw new ServiceException(OffersCalculatorErrorCodes.PLAN_NOT_POSSIBLE);
            }
            log.debug("OffersCalc: planAmount not passed in: calculated as {}", planAmount);
        }
        offersCalculation.setPlanAmount(planAmount);//This is a provisional value. Each offer will have its own planAmount.

        // --- Calculate offers ---
        log.debug("OffersCalc: getOffers...");

        //Get all offers, but not preferred payment offers.
        //For Measured will consist of Standard Offer, Flex Offers(Flex1 to Flex6), PPC Offers (PPC1 to PPC8)
        //For UnMeasured will consist of Standard Offer, extended flex Offers(will be based on months), PPC Offers (PPC1 to PPC8)
        //For Assessed will consist of Standard Offer, PPC Offers (PPC1 to PPC8)
        List<Offer> offers = offerGenerator.getOffers(paymentPlans, offersCalculation);
        log.debug("OffersCalc: getOffers. No of offers: {}", offers.size());

        // --- For each offer, calculate installments ---
        log.debug("OffersCalc: calculateAndSetInstallments...");
        installmentGenerator.calculateAndSetInstallments(offers, offersCalculation, null);

        // --- Return result ---
        offersCalculation.setOffers(offers);

        //offer can be made invalid if it has installments below certain threshold.
        installmentGenerator.checkOfferValidity(offersCalculation);
        return offersCalculation;
    }

    /**
     * @return: Returns PaymentPlans based on Arrears And Month for Measured, Unmeasured, Assessed Journey.
     * Note: Before calling update the arrears in offersCalculation, as offerGenerator.getPaymentPlansBasedOnArrearsAndMonth relies on it.
     */
    private List<PaymentPlan> getPaymentPlansBasedOnArrearsAndMonth(final OffersCalculationRequest offersCalculationRequest, final OffersCalculation offersCalculation) {
        List<PaymentPlan> paymentPlans = null;

        if (offersCalculation.isMeasured()) {
            paymentPlans = getPaymentPlans(MeasuredIndicator.MEASURED.getDbValue(),
                    offersCalculationRequest.getPaymentMethod(), offersCalculationRequest.getPaymentFrequency(),
                    offersCalculationRequest.isGetAllPPCOffers());
        } else if (offersCalculation.isUnmeasured()) {
            paymentPlans = getPaymentPlans(MeasuredIndicator.UNMEASURED.getDbValue(),
                    offersCalculationRequest.getPaymentMethod(), offersCalculationRequest.getPaymentFrequency(),
                    offersCalculationRequest.isGetAllPPCOffers());
        } else if (offersCalculation.isAssessed()) {
            paymentPlans = getPaymentPlans(MeasuredIndicator.ASSESSED.getDbValue(),
                    offersCalculationRequest.getPaymentMethod(), offersCalculationRequest.getPaymentFrequency(),
                    offersCalculationRequest.isGetAllPPCOffers());
        }

        return offerGenerator.getPaymentPlansBasedOnArrearsAndMonth(paymentPlans, offersCalculation);
    }

    private List<PaymentPlan> getArrearsPaymentPlans(final OffersCalculationRequest offersCalculationRequest) {
        return getPaymentPlans(MeasuredIndicator.ARREARS.getDbValue(),
                offersCalculationRequest.getPaymentMethod(), offersCalculationRequest.getPaymentFrequency(),
                offersCalculationRequest.isGetAllPPCOffers());
    }

    private List<PaymentPlan> getBdsPaymentPlans(OffersCalculationRequest offersCalculationRequest,
            OffersCalculation offersCalculation) {
        MeasuredIndicator measuredIndicator;
        if (offersCalculation.isMeasured()) {
            measuredIndicator = MeasuredIndicator.MEASURED;
        } else if (offersCalculation.isUnmeasured()) {
            measuredIndicator = MeasuredIndicator.UNMEASURED;
        } else if (offersCalculation.isAssessed()) {
            measuredIndicator = MeasuredIndicator.ASSESSED;
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.NO_MEASURED_INDICATORS);
        }

        return paymentPlanDao.find(measuredIndicator.getDbValue(), offersCalculationRequest.getPaymentMethod(),
                offersCalculationRequest.getPaymentFrequency(), PaymentPlan.PLAN_VARIANT_BDS,
                offersCalculationRequest.getBds().getNumberOfMonths());
    }

    /**
     * Will set 3 helper attributes isMeasured, isAssessed ,isUnmeasured, or Arrears Payment Plan.
     */
    private void setMeasuredIndicatorFlags(final OffersCalculation offersCalculation) {
        if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.MEASURED.getTargetCode())) {
            offersCalculation.setMeasured(true);
        } else if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.UNMEASURED.getTargetCode())) {
            offersCalculation.setUnmeasured(true);
        } else if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.ASSESSED.getTargetCode())) {
            offersCalculation.setAssessed(true);
        } else if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.ARREARS.getTargetCode())) {
            offersCalculation.setArrearsPlan(true);
        }
    }

    /**
     * This method will subtract the upfrontpayment payment from existing arrears.
     * First the upfront will be subtracted from  thirdparty, thereafter from accountArrears.
     * If there is no arrears, then upfront will be subtracted only from accountArreas, which will make the account in Credit.
     */
    private Arrears getAdjustArrearsUsingUpfront(final Arrears arrears, final BigDecimal upfrontPaymentAmount) {
        Arrears adjustedArrears = OffersUtil.getArrearsClone(arrears);
        if (upfrontPaymentAmount.signum() == 1) {
            BigDecimal thirdPartyCharges = adjustedArrears.getThirdPartyCharges();
            BigDecimal accountArrears = adjustedArrears.getAccountArrears();
            if (thirdPartyCharges.signum() == 1) {
                if (thirdPartyCharges.compareTo(upfrontPaymentAmount) >= 1) {
                    thirdPartyCharges = thirdPartyCharges.subtract(upfrontPaymentAmount)
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                    adjustedArrears.setThirdPartyCharges(thirdPartyCharges);
                } else {
                    BigDecimal remainingUpfrontPaymentAmount = upfrontPaymentAmount.subtract(thirdPartyCharges)
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                    adjustedArrears.setThirdPartyCharges(BigDecimal.ZERO);
                    accountArrears = accountArrears.subtract(remainingUpfrontPaymentAmount)
                            .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                    adjustedArrears.setAccountArrears(accountArrears);
                }
            } else {
                accountArrears = accountArrears.subtract(upfrontPaymentAmount)
                        .setScale(OffersConstants.DECIMAL_PLACES, RoundingMode.HALF_UP);
                adjustedArrears.setAccountArrears(accountArrears);
            }
        }
        return adjustedArrears;
    }

    private BigDecimal getUpliftForPayPlanAndBudgetPlanType(final TargetAccountNumber targetAccountNumber, final String payPlanType, final String budgetPlanType, final String paymentFrequencyTargetCode, final String authToken) {
        PaymentPlanControls payPlanControls = offersTargetService.getPayPlanControls(targetAccountNumber, payPlanType, budgetPlanType, paymentFrequencyTargetCode, authToken);
        if (payPlanControls != null && payPlanControls.getPercentageUplift() != null && payPlanControls.getPercentageUplift().signum() == 1) {
            return payPlanControls.getPercentageUplift();
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.MISMATCH_IN_PROPERTY_TYPE_AND_ACCOUNT_DEBT_CLASS);
        }
    }

    private void populateUplifts(final TargetAccountNumber targetAccountNumber, OffersCalculation offersCalculation, final List<PaymentPlan> paymentPlans, final boolean isArrearsPlan, final String authToken) {
        List<String> budgetPlanTypes = getUniqueBudgetPlanTypes(paymentPlans);
        String paymentFrequencyTargetCode = getPaymentFrequencyTargetCode(offersCalculation.getOffersCalculationRequest().getPaymentFrequency());
        List<BudgetUplift> budgetUplifts = new ArrayList<>();
        offersCalculation.setBudgetUplifts(budgetUplifts);

        budgetPlanTypes.forEach(budgetPlanType -> {
            BudgetUplift budgetUplift = new BudgetUplift();
            budgetUplifts.add(budgetUplift);

            budgetUplift.setBudgetPlanType(budgetPlanType);
            budgetUplift.setBudgetPlanTypeTargetCode(getBudgetPlanTypeTargetCode(budgetPlanType));
            budgetUplift.setPayPlanType(isArrearsPlan ? PayPlanType.ARREARS.getPayPlanType() : PayPlanType.NONE.getPayPlanType());
            budgetUplift.setPaymentFrequency(offersCalculation.getOffersCalculationRequest().getPaymentFrequency());
            budgetUplift.setPaymentFrequencyTargetCode(paymentFrequencyTargetCode);

            BigDecimal uplift = getUpliftForPayPlanAndBudgetPlanType(targetAccountNumber, budgetUplift.getPayPlanType(), budgetUplift.getBudgetPlanTypeTargetCode(), budgetUplift.getPaymentFrequencyTargetCode(), authToken);
            budgetUplift.setUplift(uplift);
            budgetUplift.setPercentageUplift(calculatePercentageUplift(uplift));
        });

    }

    /**
     * This method will populate ServiceProvisionBudgetFromBills List and ServiceProvisionBudgetFromCalcs List.
     * Each List will be created based on the No of Uplifts. Generally will be one Standard Uplift(Combination/Equalized/Unmeasured) and another one for PPC.
     */
    private void populateUpliftsWithInServiveProvisions(final OffersCalculation offersCalculation) {
        List<ServiceProvision> serviceProvisions = offersCalculation.getServiceProvisions().stream()
                .map(serviceProvision -> {
                    serviceProvision.setServiceProvisionBudgetFromBills(new ArrayList<>());
                    serviceProvision.setServiceProvisionBudgetFromCalcs(new ArrayList<>());
                    populateUpliftInServiceProvisionBudget(serviceProvision.getServiceProvisionBudgetFromBills(), offersCalculation.getBudgetUplifts());
                    populateUpliftInServiceProvisionBudget(serviceProvision.getServiceProvisionBudgetFromCalcs(), offersCalculation.getBudgetUplifts());
                    return serviceProvision;
                })
                .collect(Collectors.toList());
        offersCalculation.setServiceProvisions(serviceProvisions);
    }

    private void populateUpliftInServiceProvisionBudget(final List<ServiceProvisionBudget> serviceProvisionBudgetFromBills, final List<BudgetUplift> budgetUplifts) {
        budgetUplifts.forEach(budgetUplift -> {
            ServiceProvisionBudget serviceProvisionBudget = new ServiceProvisionBudget();
            serviceProvisionBudget.setBudgetUplift(getBudgetUpliftClone(budgetUplift));
            serviceProvisionBudgetFromBills.add(serviceProvisionBudget);

        });
    }

    private BudgetUplift getBudgetUpliftClone(BudgetUplift budgetUplift) {
        try {
            BudgetUplift budgetUpliftClone = new BudgetUplift();
            BeanUtils.copyProperties(budgetUpliftClone, budgetUplift);
            return budgetUpliftClone;
        } catch (Exception e) {
            log.error("OffersCalculationServiceImpl: getBudgetUpliftClone, Error during clone BudgetUplift");
            throw new RuntimeException(e);
        }
    }

    private List<String> getUniqueBudgetPlanTypes(final List<PaymentPlan> paymentPlans) {
        return paymentPlans.stream().map(PaymentPlan::getPlanType).distinct()
                .collect(Collectors.toList());
    }

    private String getBudgetPlanTypeTargetCode(final String budgetPlanType) {
        if (budgetPlanType.equalsIgnoreCase(BudgetPlanTypes.COMBINATION.getCode())) {
            return BudgetPlanTypes.COMBINATION.getTargetCode();
        } else if (budgetPlanType.equalsIgnoreCase(BudgetPlanTypes.EQUALIZED.getCode())) {
            return BudgetPlanTypes.EQUALIZED.getTargetCode();
        } else if (budgetPlanType.equalsIgnoreCase(BudgetPlanTypes.UNMEASURED.getCode())) {
            return BudgetPlanTypes.UNMEASURED.getTargetCode();
        } else if (budgetPlanType.equalsIgnoreCase(BudgetPlanTypes.PPC.getCode())) {
            return BudgetPlanTypes.PPC.getTargetCode();
        } else if (budgetPlanType.equalsIgnoreCase(BudgetPlanTypes.NONE.getCode())) {
            return BudgetPlanTypes.NONE.getTargetCode();
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_BUDGET_PLAN_TYPE);
        }
    }

    private String getPaymentFrequencyTargetCode(final String paymentFrequency) {
        if (paymentFrequency.equals(OfferPaymentFrequency.WEEKLY.getCode())) {
            return OfferPaymentFrequency.WEEKLY.getTargetCode();
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FORTNIGHTLY.getCode())) {
            return OfferPaymentFrequency.FORTNIGHTLY.getTargetCode();
        } else if (paymentFrequency.equals(OfferPaymentFrequency.MONTHLY.getCode())) {
            return OfferPaymentFrequency.MONTHLY.getTargetCode();
        } else if (paymentFrequency.equals(OfferPaymentFrequency.FOUR_WEEKLY.getCode())) {
            return OfferPaymentFrequency.FOUR_WEEKLY.getTargetCode();
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_PAYMENT_PLANS_FREQUENCY);
        }
    }

    private BigDecimal calculatePercentageUplift(final BigDecimal uplift) {
        BigDecimal upliftAdder = new BigDecimal("100");
        return upliftAdder.add(uplift).divide(upliftAdder, OffersConstants.UPLIFT_DECIMAL_PLACES, RoundingMode.UNNECESSARY);
    }

    //do not need Authtoken
    //This will get the accountSummary via a SOAP call.
    private void populateAccountSummary(final OffersCalculationRequest offersCalculationRequest, final OffersCalculation offersCalculation) {
        AccountSummaryResponse accountSummary;
        TargetAccountNumber targetAccountNumber = offersCalculationRequest.getAccountNumber();
        try {
            accountSummary = getAccountSummaryClient.getAccountSummary(targetAccountNumber, offersCalculationRequest.getLegalEntityNo());
            BigDecimal accountBalance = accountSummary.getAccountBalance();
            offersCalculation.setTargetAccountSummary(accountSummary.toString());
            log.debug("Account balance from Target GetAccountSummary: {}", accountBalance);
            offersCalculation.setAccountBalance(accountBalance);
        } catch (STWTechnicalException | STWBusinessException e) {
            offersCalculation.setTargetAccountSummary(e.getMessage());
        }
    }

    private LocalDate getTargetDate(final String authToken) {
        return offersTargetService.getTargetDate(authToken);
    }

    /**
     * @param measuredIndicator: Measured/Assessed or UnMeasured
     * @param paymentMethod      : DirectDebit, Watercard, etc. This will be passed in the offersCalculationRequest via UI.
     * @param paymentFrequency   : values are Monthly, 4-weekly, fortnightly, weekly.
     * @param allPPCOffers       : if True, will retrive all PPC payment plans (for all frequency)
     * @return : List of Payment plans. Each payment plan , can create upto one offer. Note: there are more filters down the line.
     */
    private List<PaymentPlan> getPaymentPlans(final String measuredIndicator, final String paymentMethod, final String paymentFrequency,
                                              final boolean allPPCOffers) {
        log.debug("OffersCalc:getPaymentPlans for measuredIndicator:{} , paymentMethod:{}, paymentFrequency:{}, allPPCOffers:{} ", measuredIndicator, paymentMethod, paymentFrequency, allPPCOffers);
        List<PaymentPlan> paymentPlans;
        if (allPPCOffers) {
            paymentPlans = paymentPlanDao.findWithAllPpc(measuredIndicator,
                    paymentMethod, paymentFrequency);
        } else {
            paymentPlans = paymentPlanDao.find(measuredIndicator, paymentMethod,
                    paymentFrequency);
        }

        // exclude BDS payment plans
        return paymentPlans.stream().filter(plan -> !OffersUtil.isBdsPlan(plan)).collect(Collectors.toList());
    }

    /**
     * @param offerLevel : OfferLevels are standard, flex, unmeasured - short, unmeasured - Long, ppc
     * @Return: Standard Preferred payment has maximum upper limits, in terms of increments. They are configured based on Frequency.
     * This method will return the list of increments.(Currently only Standard is configured in the DB)
     */
    private List<PreferredPayment> getPreferredPayment(final int offerLevel) {
        return preferredPaymentDao.find(offerLevel);
    }

    /**
     * @param paymentPlans : All payment plans will be passed.
     * @return : MaxMeasuredFlexVariantAmount : get the maximum measured flex variant amount.
     * Measured Flex variant amounts are generally flex0: 0,  flex1: 0.5, flex2: 0.10, flex3: 0.15, flex4: 0.20, flex5 :0.25, flex6: 0.30
     */
    private BigDecimal getMaxMeasuredFlexVariantAmount(final List<PaymentPlan> paymentPlans) {
        // @formatter:off
        return paymentPlans.stream()
                .filter(OffersUtil::isMeasuredFlexPlan)
                .max(Comparator.comparing(PaymentPlan::getVariantAmount))
                .map(PaymentPlan::getVariantAmount)
                .orElseThrow(() -> new STWBusinessException("Unable to find measured flex plans"));
        // @formatter:on
    }

    /**
     * @param targetAccountNumber : AccountNumber of the customer. Will be passed as in the offersCalculationRequest
     * @return : Arrears is mainly made up of AccountArrears and ThirdPartyCharges. This service will provide the split between AccountArrears and ThirdPartyCharges.
     * Note: If there is a positive balance on the account, Then we need to find out the split between 3rd party areas & STW Account arreas.
     */
    private Arrears getArrears(final TargetAccountNumber targetAccountNumber, final String authToken) {
        return offersTargetService.getArrears(targetAccountNumber, authToken);
    }

    /**
     * @return: Returns List of Active ServiceProvisions of Active Properties for an given AccountNumber.
     */
    private List<ServiceProvision> getActiveServiceProvisions(final TargetAccountNumber targetAccountNumber, final String authToken) {
        log.debug("OffersCalc: Getting service provisions for {}", targetAccountNumber.getAccountNumber());
        List<ServiceProvision> activeServiceProvisions = offersTargetService
                .getActiveServiceProvisionsForAccount(targetAccountNumber, authToken);
        
        // Highways Drainage has been added to all customers starting from April 2020 
        // this code is to ignore these service from the calculation until customers have history.
        activeServiceProvisions = activeServiceProvisions.stream()
                .filter(sp->!HIGHWAYS_DRAINAGE.equals(sp.getServiceProvisionCode())).collect(Collectors.toList());
        log.debug("OffersCalc: Getting service provisions: returning {} ", activeServiceProvisions.size());
        return activeServiceProvisions;
    }

    /**
     * @return : An customer (le) can have multiple accounts. But each account needs to be configured as single type(Measured, Unmeasured or Assessed)
     * This service will read the measured Indicator, and if the account do have more than one measured indicator types,
     * it will throw an error. Currently CMP can only create offers for a single Measured Type(Measured/Unmeasured/Assessed)
     * @throws ServiceException : If mixuture of measured Indicators are received for a given Account.
     */
    private String getMeasuredIndicatorForAccount(final TargetAccountNumber targetAccountNumber, final String authToken) throws ServiceException {
        log.debug("OffersCalc: Getting measured indicator for {}", targetAccountNumber);

        List<String> measuredIndicators = offersTargetService.getMeasuredIndicatorsForAccount(targetAccountNumber, authToken);
        if (measuredIndicators.isEmpty())
            throw new ServiceException(OffersCalculatorErrorCodes.NO_MEASURED_INDICATORS);
        if (measuredIndicators.stream().allMatch(measuredIndicators.get(0)::equals)) {
            return measuredIndicators.get(0);
        } else {
            throw new ServiceException(OffersCalculatorErrorCodes.MIXED_MEASURED_INDICATORS);
        }
    }

    /**
     * @param offersCalculationRequest: Main input request of the REST endpoint. Currently  we do valid for basic input ranges.
     *                                  Note: Has some custom logic around preferredPaymentDay: By default the the preferredPaymentDay should be also reflected in the preferredPaymentDate.
     *                                  The only use-case where this can be different is if user wants to pay on 31, and the current month do not allow 31.
     * @throws ServiceException
     */
    private void validateRequest(final OffersCalculationRequest offersCalculationRequest) throws ServiceException {
        // Must have a request object
        if (offersCalculationRequest == null)
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST);

        // Must have all the mandatory properties
        if (offersCalculationRequest.getAccountNumber() == null)
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST);
        if (offersCalculationRequest.getLegalEntityNo() == null)
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST);
        if (offersCalculationRequest.getPaymentFrequency() == null)
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST);
        if (offersCalculationRequest.getPaymentMethod() == null)
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST);
        if (!AccountBrand.isValidBrand(offersCalculationRequest.getAccountBrand()))
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST);

        if (offersCalculationRequest.getPreferredPaymentDay() > 0) {
            if (offersCalculationRequest.getPreferredPaymentDate() != null) {
                int preferredPaymentDay = offersCalculationRequest.getPreferredPaymentDay();
                LocalDate preferredPaymentDate = offersCalculationRequest.getPreferredPaymentDate();
                int derivedPreferredPaymentDay = preferredPaymentDate.get(ChronoField.DAY_OF_MONTH);

                if (preferredPaymentDay != derivedPreferredPaymentDay) {
                    if (preferredPaymentDay > 28) {//edge case where current month is Feb, but wants to pay on 31st.
                        LocalDate adjustedStartDate = preferredPaymentDate.minus(1, ChronoUnit.DAYS);
                        offersCalculationRequest.setPreferredPaymentDate(adjustedStartDate);
                    } else {
                        throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST_PREFERRED_PAYMENT_DAYS);
                    }
                }
            }
        }

        if (offersCalculationRequest.getFirstInstallmentAmount().signum() == -1) {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST_NEGATIVE_1ST_INSTALLMENT);
        }

        if (offersCalculationRequest.getUpfrontPaymentAmount().signum() == -1) {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST_NEGATIVE_UPFRONT);
        }
    }

    /**
     * @param offersCalculationRequest: Main input request of the REST endpoint. Currently  we do valid for basic input ranges.
     *                                  This method is to validate the preferred payment inputs.
     */
    private void validateRequestForPreferredPayment(final OffersCalculationRequest offersCalculationRequest, final OffersCalculation offersCalculation) {
        if (offersCalculationRequest.getPreferredPaymentStandard().signum() != 0 && !offersCalculation.isMeasured()) {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST_STANDARD_PREFERRED_PAYMENT_NOT_ALLOWED);
        }
        if (offersCalculationRequest.getPreferredPaymentFlex().signum() != 0 && !offersCalculation.isMeasured()) {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST_FLEX_PREFERRED_PAYMENT_NOT_ALLOWED);
        }
        if (offersCalculationRequest.getPreferredPaymentStandard().signum() == -1 ||
                offersCalculationRequest.getPreferredPaymentFlex().signum() == -1 ||
                offersCalculationRequest.getPreferredPaymentPPC().signum() == -1) {
            throw new ServiceException(OffersCalculatorErrorCodes.INVALID_REQUEST_NEGATIVE_PREFERRED_PAYMENT);
        }
    }

    /**
     * @return: Budget mainly consist of invoices or latestInvoice.
     * Invoices For Measured/Assessed: All non cancelled invoices for past one year are retrieved.
     * use-case: If the latest invoice is 'CANCELLED', or there is no history in the past one year, latest non-cancelled invoice is used inorder to derive the accrued Start date.
     * Forecast will be used from the consumption calculator.
     * <p>
     * Invoices for Unmeasured: Latest non cancelled invoice in last one year is retrived.
     * <p>
     * Note: During the retrival, only invoicelines thats belongs to an activeService Provision is considered.
     */
    private Budget getBudget(final TargetAccountNumber targetAccountNumber, final OffersCalculation offersCalculation, final String authToken) {
        List<Invoice> allInvoices = offersTargetService.getInvoices(targetAccountNumber, authToken);
        LocalDate oldestServiceStartDate = getOldestServiceStartDate(offersCalculation.getServiceProvisions());

        if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.UNMEASURED.getTargetCode())) {
            return getBudgetForUnmeasured(targetAccountNumber, offersCalculation, authToken, allInvoices, oldestServiceStartDate);
        }
        return getBudgetForMeasured(targetAccountNumber, offersCalculation, authToken, allInvoices, oldestServiceStartDate);
    }

    private Budget getBudgetForMeasured(final TargetAccountNumber targetAccountNumber, final OffersCalculation offersCalculation, final String authToken, final List<Invoice> allInvoices, final LocalDate oldestServiceStartDate) {
        Budget budget = new Budget();
        List<Invoice> pastOneYearInvoices;
        boolean isLatestInvoiceOfPastOneYearCancelled = false;
        pastOneYearInvoices = invoiceAnalyser.getPastOneYearNonCancelledInvoices(allInvoices, offersCalculation.getTargetDate());

        pastOneYearInvoices.forEach((invoice) ->
                updateInvoiceLinesOfActiveServiceProvisions(targetAccountNumber, offersCalculation, authToken, invoice, oldestServiceStartDate)
        );
        //For Measured/Assessed check if lastest Bill in last one year is cancelled.
        isLatestInvoiceOfPastOneYearCancelled = invoiceAnalyser.isLatestInvoiceOfPastOneYearCancelled(allInvoices, offersCalculation.getTargetDate());
        if (CollectionUtils.isEmpty(pastOneYearInvoices) || isLatestInvoiceOfPastOneYearCancelled) {
            //if no history in last one year or lastInvoice is cancelled, then get latestBillEndDate of latest non-cancelled invoice.
            Optional<Invoice> latestNonCancelledInvoiceOptional = invoiceAnalyser.getLatestNonCancelledInvoice(allInvoices);
            latestNonCancelledInvoiceOptional.ifPresent(invoice -> {
                        budget.setLatestInvoice(invoice);
                        updateInvoiceLinesOfActiveServiceProvisions(targetAccountNumber, offersCalculation, authToken, invoice, oldestServiceStartDate);
                        if (!hasInvoiceLines(invoice)) {
                            budget.setLatestInvoice(null);
                        }
                    }
            );
        } else {
            pastOneYearInvoices = getInvoicesBasedOnServiceProvision(targetAccountNumber, offersCalculation, authToken, pastOneYearInvoices,
                    invoiceAnalyser.getOrderedNonCancelledAndIssuedInvoices(allInvoices), oldestServiceStartDate);
        }

        pastOneYearInvoices = getInvoicesWithInvoiceLines(pastOneYearInvoices);
        budget.setInvoices(pastOneYearInvoices);
        return budget;
    }

    private Budget getBudgetForUnmeasured(final TargetAccountNumber targetAccountNumber, final OffersCalculation offersCalculation, final String authToken, final List<Invoice> allInvoices, final LocalDate oldestServiceStartDate) {
        Budget budget = new Budget();
        List<Invoice> pastOneYearInvoices;
        pastOneYearInvoices = invoiceAnalyser.getLatestNonCancelledInvoiceOfPastOneYear(allInvoices, offersCalculation.getTargetDate());
        pastOneYearInvoices = getInvoicesBasedOnServiceProvision(targetAccountNumber, offersCalculation, authToken, pastOneYearInvoices,
                invoiceAnalyser.getOrderedNonCancelledAndIssuedInvoices(allInvoices), oldestServiceStartDate);
        pastOneYearInvoices = getInvoicesWithInvoiceLines(pastOneYearInvoices);
        budget.setInvoices(pastOneYearInvoices);
        return budget;
    }

    private LocalDate getNextBillingDate(final OffersCalculation offersCalculation) {
        LocalDate targetDate = offersCalculation.getTargetDate();
        LocalDate billingDateOfCurrentYear = LocalDate.of(targetDate.getYear(), OffersConstants.MAIN_BILLING_DATE.getMonth(), OffersConstants.MAIN_BILLING_DATE.getDayOfMonth());
        LocalDate nextBillingDate = billingDateOfCurrentYear;

        if (targetDate.isAfter(billingDateOfCurrentYear)) {
            nextBillingDate = billingDateOfCurrentYear.plusYears(1);
        }
        return nextBillingDate;
    }

    private void evalauteMainBillingCompletion(final OffersCalculation offersCalculation) {
        boolean isMainBillingCompleted = false;
        if (offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.UNMEASURED.getTargetCode())) {
            if (CollectionUtils.isNotEmpty(offersCalculation.getBudget().getInvoices())) {
                Invoice invoice = offersCalculation.getBudget().getInvoices().get(OffersConstants.INVOICE_FOR_UNMEASURED); // only once Invoice will be used for Unmeasured budget
                isMainBillingCompleted = invoice.getInvoiceLines().stream().anyMatch(
                        invoiceLine -> invoiceLine.getBillPeriodEndDate().isAfter(getNextBillingDate(offersCalculation))
                );
            }

        }
        offersCalculation.setMainBillingCompleted(isMainBillingCompleted);
    }

    private LocalDate getOldestServiceStartDate(final List<ServiceProvision> serviceProvisions) {
        Optional<ServiceProvision> serviceProvisionOptional = serviceProvisions.stream()
                .max(Comparator.comparing(ServiceProvision::getServiceStartDate));
        if (serviceProvisionOptional.isPresent()) {
            return serviceProvisionOptional.get().getServiceStartDate();
        }
        return null;
    }

    /**
     * Invoices for Unmeasured: Latest non cancelled invoice in last one year is retrived.
     * If latest non-cancelled invoice do not have invoice lines for all active service provisions, then more invoices will be retrived till all active service provisions do have an invoice line,out of which an forecast can be derived.
     * Note: "invoice do not have invoice lines for all active service provisions" check will be applied to measured, Assessed and Unmeasured.
     */
    private List<Invoice> getInvoicesBasedOnServiceProvision(final TargetAccountNumber targetAccountNumber, final OffersCalculation offersCalculation, final String authToken, final List<Invoice> pastOneYearInvoices,
                                                             final List<Invoice> orderedNonCancelledAndIssuedInvoices, final LocalDate oldestServiceStartDate) {
        if ((offersCalculation.getMeasuredIndicator().equalsIgnoreCase(MeasuredIndicator.UNMEASURED.getTargetCode()) && CollectionUtils.isEmpty(pastOneYearInvoices))
                || isAnyActiveServiceProvisionDoNotHaveAnInvoiceLine(offersCalculation)) {
            List<Invoice> invoicesWithAllActiveServiceProvisions = new ArrayList<>();
            orderedNonCancelledAndIssuedInvoices.forEach(invoice -> {
                if (isAnyActiveServiceProvisionDoNotHaveAnInvoiceLine(offersCalculation)) {
                    retriveMoreInvoiceLinesToCoverAllActiveServiceProvisions(targetAccountNumber, offersCalculation, authToken, invoice, invoicesWithAllActiveServiceProvisions, oldestServiceStartDate);
                }
            });
            return invoicesWithAllActiveServiceProvisions;
        }
        return pastOneYearInvoices;
    }

    private boolean isAnyActiveServiceProvisionDoNotHaveAnInvoiceLine(final OffersCalculation offersCalculation) {
        return offersCalculation.getServiceProvisions().stream().anyMatch(serviceProvision -> !serviceProvision.isFoundInvoiceLine());
    }

    /**
     * Invoices for Unmeasured: Latest non cancelled invoice in last one year is retrived.
     * If latest non-cancelled invoice do not have invoice lines for all active service provisions, then more invoices will be retrived till all active service provisions do have an invoice line,out of which an forecast can be derived.
     */
    private void retriveMoreInvoiceLinesToCoverAllActiveServiceProvisions(final TargetAccountNumber targetAccountNumber, final OffersCalculation offersCalculation, final String authToken,
                                                                          final Invoice invoice, final List<Invoice> invoicesWithAllActiveServiceProvisions, final LocalDate oldestServiceStartDate) {
        updateInvoiceLinesOfActiveServiceProvisions(targetAccountNumber, offersCalculation, authToken, invoice, oldestServiceStartDate);
        List<InvoiceLine> invoiceLines = invoice.getInvoiceLines();
        if (!CollectionUtils.isEmpty(invoiceLines)) {
            invoicesWithAllActiveServiceProvisions.add(invoice);
        }
        updateServiceProvisionsRegardingInvoiceLine(offersCalculation, invoice);
    }

    private void updateServiceProvisionsRegardingInvoiceLine(final OffersCalculation offersCalculation, final Invoice invoice) {
        List<InvoiceLine> invoiceLines = invoice.getInvoiceLines();
        //update serviceProisions
        invoiceLines.forEach(invoiceLine -> {
            Optional<ServiceProvision> serviceProvisionOptional = offersCalculation.getServiceProvisions().stream()
                    .filter(serviceProvision -> serviceProvision.getPropertyAndServiceProvisionNum().equalsIgnoreCase(invoiceLine.getPropertyAndServiceProvisionNum()))
                    .findFirst();

            serviceProvisionOptional.ifPresent(serviceProvision ->
                    serviceProvision.setFoundInvoiceLine(true)
            );
        });
    }

    /**
     * Invoice will be updated with the relevant invoice lines.
     * Note: Each invoice lines will be pre-modified to combined its BillSubPeriodStartDate, as Target always expect one invoiceLine in a invoice for a given serviceProvision.
     * (when invoice spans across the 31st March, having 2 billing periods, invoices can have multiple invoice lines for the same serviceProvision)
     */
    private void updateInvoiceLinesOfActiveServiceProvisions(final TargetAccountNumber targetAccountNumber, final OffersCalculation offersCalculation, final String authToken,
                                                             final Invoice invoice, final LocalDate oldestServiceStartDate) {
        List<InvoiceLine> invoiceLines = offersTargetService.getCombinedInvoiceLines(targetAccountNumber, invoice, authToken);
        invoiceLines = getInvoiceLinesWithActiveServiceProvisionsAndCharge(invoiceLines, offersCalculation.getServiceProvisions());
        invoiceLines = invoiceAnalyser.getInvoiceLinesOfLatestMoveIn(invoiceLines, oldestServiceStartDate);
        invoice.setInvoiceLines(invoiceLines);
        updateServiceProvisionsRegardingInvoiceLine(offersCalculation, invoice);
    }

    private List<Invoice> getInvoicesWithInvoiceLines(final List<Invoice> invoices) {
        return invoices.stream()
                .filter(this::hasInvoiceLines)
                .collect(Collectors.toList());
    }

    private boolean hasInvoiceLines(final Invoice invoice) {
        return !CollectionUtils.isEmpty(invoice.getInvoiceLines());
    }

    private List<InvoiceLine> getInvoiceLinesWithActiveServiceProvisionsAndCharge(final List<InvoiceLine> invoiceLines, final List<ServiceProvision> serviceProvisions) {
        return invoiceLines.stream().filter(invoiceLine ->
                isServiceProvisionActive(invoiceLine.getPropertyAndServiceProvisionNum(), serviceProvisions)
        ).collect(Collectors.toList());
    }

    private boolean isServiceProvisionActive(final String propertyAndServiceProvisionNum, final List<ServiceProvision> serviceProvisions) {
        return getDistinctServiceProvisions(serviceProvisions).contains(propertyAndServiceProvisionNum);

    }

    private List<String> getDistinctServiceProvisions(final List<ServiceProvision> serviceProvisions) {
        return serviceProvisions.stream()
                .map(ServiceProvision::getPropertyAndServiceProvisionNum)
                .distinct()
                .collect(Collectors.toList());
    }
}
