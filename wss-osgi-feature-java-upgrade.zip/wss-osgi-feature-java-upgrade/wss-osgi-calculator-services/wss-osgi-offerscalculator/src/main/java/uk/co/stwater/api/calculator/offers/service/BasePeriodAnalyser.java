package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;

public interface BasePeriodAnalyser {
    void calculateForecastAndAccruedDetails(final OffersCalculation offersCalculation, final String measuredIndicator) throws ServiceException;
}
