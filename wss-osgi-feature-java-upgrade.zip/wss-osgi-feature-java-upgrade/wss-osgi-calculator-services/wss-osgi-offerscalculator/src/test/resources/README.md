BasePeriodAnalyserTest
====================== 
M_1_YR_HIST_100

M_2_YR_HIST_100
M_10_MTH_HIST_100
M_6_MTH_HIST_100
M_1_MTH_HIST_100
M_2_YR_HIST_DIFF_ADC_100

M_LAST_BILL_CANCEL_USELATESTINVOICE_100
M_1_YR_NO_HIST_USELATESTINVOICE_100
M_LAST_BILL_CANCEL_USELATESTINVOICE_N_FORECAST_100
M_1_YR_NO_HIST_USELATESTINVOICE_N_FORECAST_100

M_NEW_CUST_100
M_NEW_CUST_N_FORECAST_100

M_FEW_SER_PRO_NO_HIST_100
M_FEW_SER_PRO_NO_HIST_N_FORECAST_100


----sql script for payment plans - Unmeasured--- 
SELECT * FROM wssV2.WSS_PAYMENT_PLANS where servicetype='Unmeasured' and paymentmethod='WC'
and (
( month=12 AND ARREARS='N' AND   paymentfrequency='M' ) 
OR (planvariant like 'PPC%' AND arrears='Y')
) 


----sql script for payment plans - Measured--- 
SELECT * FROM wssV2.WSS_PAYMENT_PLANS where servicetype='Measured' and paymentmethod='WC'
and (
(ARREARS='Y' AND   paymentfrequency='M' ) 
OR (planvariant like 'PPC%' AND arrears='Y')
) 

----sql script for payment plans - Assessed--- 
SELECT * FROM wssV2.WSS_PAYMENT_PLANS where servicetype='Assessed' and paymentmethod='WC'
and (
(ARREARS='Y' AND   paymentfrequency='M' ) 
OR (planvariant like 'PPC%' AND arrears='Y')
) 

----sql script for payment plans - Arrears--- 
SELECT * FROM wssV2.WSS_PAYMENT_PLANS where servicetype='Arrears' and paymentmethod='WC'
and (
(ARREARS='Y' AND   paymentfrequency='M' ) 
OR (planvariant like 'PPC%' AND arrears='Y')
) 


