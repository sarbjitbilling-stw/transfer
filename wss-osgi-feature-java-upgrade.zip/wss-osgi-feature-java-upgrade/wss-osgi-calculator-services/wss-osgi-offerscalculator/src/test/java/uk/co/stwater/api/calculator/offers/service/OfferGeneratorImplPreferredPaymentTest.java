package uk.co.stwater.api.calculator.offers.service;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.calculator.offers.model.ServiceExceptionWrapper;
import uk.co.stwater.api.calculator.offers.model.TestGroupSummary;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.model.calculator.offers.PreferredPayment;

import java.math.BigDecimal;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class OfferGeneratorImplPreferredPaymentTest {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @InjectMocks
    private OfferGeneratorPreferredPayment offerGeneratorPreferredPayment = new OfferGeneratorPreferredPaymentImpl();

    Map<String, TestGroupSummary> testGroupSummaryMap = null;
    Map<String, List<OffersCalculation>> inputOffersCalculationByGroupMap = null;
    Map<String, List<OffersCalculationRequest>> inputOffersCalculationRequestByGroupMap = null;
    Map<String, List<Offer>> inputOffersByGroupMap = null;///give output of installGenerator offer

    Map<String, List<Offer>> outputOffersByGroupMap = null;
    Map<String, List<ServiceExceptionWrapper>> outputErrorsByGroupMap = null;

    private String getFilePath(String fileName) {
        String platformIndependentPath;
        try {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            platformIndependentPath = Paths.get(classloader.getResource(fileName).toURI()).toString();
        } catch (Exception ex) {
            log.error("Error in InstallmentGeneratorImplTest.getFilePath, {} , {} ", ex.getMessage(), ex);
            throw new STWTechnicalException(ex.getMessage(), ex);
        }
        return platformIndependentPath;
    }

    @BeforeEach
    void setUp() throws Exception {
        testGroupSummaryMap = readTestGroupSummaryMap();
        inputOffersCalculationByGroupMap = readInputOffersCalculationByGroupMap();
        inputOffersCalculationRequestByGroupMap = readInputOffersCalculationRequestByGroupMap();
        inputOffersByGroupMap = readInputOffersByGroupMap();///give output of installGenerator offer

        outputOffersByGroupMap = readOutputOffersByGroupMap();
        outputErrorsByGroupMap = readOutputErrorsByGroupMap();
    }

    private Map<String, TestGroupSummary> readTestGroupSummaryMap() {
        return OffersCsvTransformers.readTestGroupSummaryMap(getFilePath("offer_generator_pref_pymt_test_group_summary.csv"));
    }

    private Map<String, List<OffersCalculation>> readInputOffersCalculationByGroupMap() {
        return OffersCsvTransformers.readInputOffersCalculationByGroupMap(getFilePath("offer_generator_pref_pymt_input_offerscalculation.csv"), true);
    }

    private Map<String, List<OffersCalculationRequest>> readInputOffersCalculationRequestByGroupMap() {
        return OffersCsvTransformers.readInputOffersCalculationRequestByGroupMap(getFilePath("offer_generator_pref_pymt_input_calculationrequest.csv"));
    }

    private Map<String, List<Offer>> readInputOffersByGroupMap() {
        return OffersCsvTransformers.readOffersByGroupMap(getFilePath("offer_generator_pref_pymt_input_offers.csv"));

    }

    private Map<String, List<Offer>> readOutputOffersByGroupMap() {
        return OffersCsvTransformers.readOffersByGroupMap(getFilePath("offer_generator_pref_pymt_output_offers.csv"));
    }

    private Map<String, List<ServiceExceptionWrapper>> readOutputErrorsByGroupMap() {
        return OffersCsvTransformers.readErrorsByGroupMap(getFilePath("offer_generator_pref_pymt_output_errors.csv"));
    }

    private List<PreferredPayment> getPreferredPaymentIncrements() {
        List<PreferredPayment> preferredPaymentIncrements = new ArrayList<>();
        PreferredPayment preferredPayment = new PreferredPayment();
        preferredPayment.setOfferLevel(1);
        preferredPayment.setPaymentFrequency("M");//MONTHLY
        preferredPayment.setMaxIncrement(new BigDecimal("75.00"));
        preferredPaymentIncrements.add(preferredPayment);

        preferredPayment = new PreferredPayment();
        preferredPayment.setOfferLevel(1);
        preferredPayment.setPaymentFrequency("4");//4-weekly
        preferredPayment.setMaxIncrement(new BigDecimal("75.00"));
        preferredPaymentIncrements.add(preferredPayment);

        preferredPayment = new PreferredPayment();
        preferredPayment.setOfferLevel(1);
        preferredPayment.setPaymentFrequency("F");//Fortnightly
        preferredPayment.setMaxIncrement(new BigDecimal("50.00"));
        preferredPaymentIncrements.add(preferredPayment);

        preferredPayment = new PreferredPayment();
        preferredPayment.setOfferLevel(1);
        preferredPayment.setPaymentFrequency("W");//WEEKLY
        preferredPayment.setMaxIncrement(new BigDecimal("25.00"));
        preferredPaymentIncrements.add(preferredPayment);

        return preferredPaymentIncrements;
    }

    private OffersCalculation getOffersCalculation(String groupId) {
        OffersCalculation offersCalculation = inputOffersCalculationByGroupMap.get(groupId).get(0);//Group will have only one OffersCalculation
        OffersCalculationRequest offersCalculationRequest = inputOffersCalculationRequestByGroupMap.get(groupId).get(0);//Group will have only one offersCalculationRequest
        offersCalculation.setOffersCalculationRequest(offersCalculationRequest);

        List<Offer> offers = inputOffersByGroupMap.get(groupId);
        offersCalculation.setOffers(offers);
        return offersCalculation;
    }

    @Test
    void addPreferredPaymentOffers() {
        testGroupSummaryMap.forEach((groupId, testGroupSummary) -> {
                    if (testGroupSummary.isActive()) {
                        addPreferredPaymentOffersOrExceptionTest(groupId, testGroupSummary);
                    }
                }
        );
    }

    private void addPreferredPaymentOffersOrExceptionTest(String groupId, TestGroupSummary testGroupSummary) {
        if (testGroupSummary.isThrowsException()) {
            addPreferredPaymentOffersExceptionTest(groupId);
        } else {
            addPreferredPaymentOffersTest(groupId);
        }
    }

    private void addPreferredPaymentOffersExceptionTest(String groupId) {
        String message = "GroupID : ".concat(groupId).concat(":[offer_generator_pref_pymt_test_group_summary.csv]:");
        OffersCalculation offersCalculation = getOffersCalculation(groupId);
        uk.co.stwater.api.core.service.ServiceException actualServiceException = assertThrows(uk.co.stwater.api.core.service.ServiceException.class, () -> {
            offerGeneratorPreferredPayment.addPreferredPaymentOffers(offersCalculation, getPreferredPaymentIncrements());
        });
        ServiceExceptionWrapper expectedServiceExceptionWrapper = outputErrorsByGroupMap.get(groupId).get(0);
        assertEquals(expectedServiceExceptionWrapper.getCode(), actualServiceException.getCode().getCode(), message.concat(" -> ExceptionCode :").concat(getMessageWithExceptionDetails("", expectedServiceExceptionWrapper, actualServiceException)));

        if (expectedServiceExceptionWrapper.getMessageSubset01() != null) {
            assertTrue(actualServiceException.getCode().getMessage().contains(expectedServiceExceptionWrapper.getMessageSubset01()), message.concat(" -> MessageSubset01 :").concat(getMessageWithExceptionDetails("", expectedServiceExceptionWrapper, actualServiceException)));
        }

        if (expectedServiceExceptionWrapper.getMessageSubset02() != null) {
            assertTrue(actualServiceException.getCode().getMessage().contains(expectedServiceExceptionWrapper.getMessageSubset02()), message.concat(" -> MessageSubset02 :").concat(getMessageWithExceptionDetails("", expectedServiceExceptionWrapper, actualServiceException)));
        }

        if (expectedServiceExceptionWrapper.getMessageSubset03() != null) {
            assertTrue(actualServiceException.getCode().getMessage().contains(expectedServiceExceptionWrapper.getMessageSubset03()), message.concat(" -> MessageSubset03 :").concat(getMessageWithExceptionDetails("", expectedServiceExceptionWrapper, actualServiceException)));
        }
    }

    private void addPreferredPaymentOffersTest(String groupId) {
        OffersCalculation offersCalculation = getOffersCalculation(groupId);
        log.debug("Start: {}", getTestDetails(groupId));
        offerGeneratorPreferredPayment.addPreferredPaymentOffers(offersCalculation, getPreferredPaymentIncrements());
//        printResult(getTestDetails(groupId), offersCalculation.getOffers());
        assertOffers(groupId, offersCalculation.getOffers(), outputOffersByGroupMap.get(groupId));
    }

    @Test
    void addPreferredPaymentOffersForSingleTestID() {
        String groupId = "M_M_100_WITH_FP_PPC_ERROR_BILLING";
        TestGroupSummary testGroupSummary = testGroupSummaryMap.get(groupId);
        addPreferredPaymentOffersOrExceptionTest(groupId, testGroupSummary);
    }

    private String getTestDetails(String groupId) {
        return "******TEST GROUP ID:".concat(groupId).concat(":").concat(testGroupSummaryMap.get(groupId).getDetails()).concat(":************");
    }

    private void printResult(String testDetails, List<Offer> list) {
        list.forEach(offer -> {
            log.debug("{} printResult: {} ", testDetails, offer.toString());
        });
    }

    private void assertOffers(String groupId, List<Offer> actualOffers, List<Offer> expectedOffers) {
        String message = "GroupID : ".concat(groupId).concat(":[offer_generator_pref_pymt_test_group_summary.csv]:");

        expectedOffers.forEach(expectedOffer -> {
            Optional<Offer> actualOfferOptional = actualOffers.stream()
                    .filter(offer -> offer.getOfferId().equalsIgnoreCase(expectedOffer.getOfferId()))
                    .findFirst();

            if (actualOfferOptional.isPresent()) {
                Offer actualOffer = actualOfferOptional.get();

                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> Accrued"), actualOffer.getAccrued(), Matchers.comparesEqualTo(expectedOffer.getAccrued()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> Arrears:AccountArrears"), actualOffer.getArrears().getAccountArrears(), Matchers.comparesEqualTo(expectedOffer.getArrears().getAccountArrears()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> Arrears:ThirdPartyCharges"), actualOffer.getArrears().getThirdPartyCharges(), Matchers.comparesEqualTo(expectedOffer.getArrears().getThirdPartyCharges()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> PotentialUnderPayment"), actualOffer.getPotentialUnderPayment(), Matchers.comparesEqualTo(expectedOffer.getPotentialUnderPayment()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> InstallmentArrearsAmount"), actualOffer.getInstallmentArrearsAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentArrearsAmount()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> InstallmentForecastAmount"), actualOffer.getInstallmentForecastAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentForecastAmount()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> InstallmentAmount"), actualOffer.getInstallmentAmount(), Matchers.comparesEqualTo(expectedOffer.getInstallmentAmount()));

                assertEquals(expectedOffer.getStartDate(), actualOffer.getStartDate(), getMessageWithOfferDetails(message, expectedOffer).concat(" -> StartDate"));
                assertEquals(expectedOffer.getEndDate(), actualOffer.getEndDate(), getMessageWithOfferDetails(message, expectedOffer).concat(" -> EndDate"));

                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> Forecast"), actualOffer.getForecast(), Matchers.comparesEqualTo(expectedOffer.getForecast()));
                assertThat(getMessageWithOfferDetails(message, expectedOffer).concat(" -> PlanAmount"), actualOffer.getPlanAmount(), Matchers.comparesEqualTo(expectedOffer.getPlanAmount()));
                assertEquals(expectedOffer.getOfferDetail(), actualOffer.getOfferDetail(), getMessageWithOfferDetails(message, expectedOffer).concat(" -> OfferDetail"));
                assertEquals(expectedOffer.getDisplayOrder(), actualOffer.getDisplayOrder(), getMessageWithOfferDetails(message, expectedOffer).concat(" -> DisplayOrder"));
                assertEquals(expectedOffer.getPlanVariant(), actualOffer.getPlanVariant(), getMessageWithOfferDetails(message, expectedOffer).concat(" -> PlanVariant"));
            } else {
                assertTrue(false, getMessageWithOfferDetails(message, expectedOffer).concat(" -> Missing Offer:").concat(expectedOffer.toString()));
            }

        });
    }

    private String getMessageWithOfferDetails(final String message, Offer expectedOffer) {
        return message.concat("; offerId =").concat(expectedOffer.getOfferId())
                .concat("; offer Details = ").concat(expectedOffer.getOfferDetail())
                .concat(";");
    }

    private String getMessageWithExceptionDetails(final String message, ServiceExceptionWrapper expectedServiceExceptionWrapper, ServiceException actualServiceException) {
        return message.concat("; Expected ExceptionCode =").concat(expectedServiceExceptionWrapper.getCode())
                .concat(getErrorAttributes("; Expected ExceptionMessage = ", expectedServiceExceptionWrapper.getMessage()))
                .concat(getErrorAttributes("; Expected MessageSubset01 = ", expectedServiceExceptionWrapper.getMessageSubset01()))
                .concat(getErrorAttributes("; Expected MessageSubset02 = ", expectedServiceExceptionWrapper.getMessageSubset02()))
                .concat(getErrorAttributes("; Expected MessageSubset03 = ", expectedServiceExceptionWrapper.getMessageSubset03()))
                .concat("; Actual ExceptionCode = ").concat(actualServiceException.getCode().getCode())
                .concat("; Actual ExceptionMessage = ").concat(actualServiceException.getCode().getMessage())
                .concat(";");
    }

    private String getErrorAttributes(String description, String attr) {
        return attr != null ? description.concat(attr) : "";
    }

}