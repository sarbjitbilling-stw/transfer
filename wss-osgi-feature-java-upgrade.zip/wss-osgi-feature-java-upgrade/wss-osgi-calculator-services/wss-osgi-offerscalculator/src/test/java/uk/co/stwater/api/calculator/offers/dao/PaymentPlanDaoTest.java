package uk.co.stwater.api.calculator.offers.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class PaymentPlanDaoTest {

	protected static EntityManagerFactory emf;
	protected static EntityManager entityManager;

	private PaymentPlanDao paymentPlanDao;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("wssPersistenceTest");
		entityManager = emf.createEntityManager();
		paymentPlanDao = new PaymentPlanDaoImpl(entityManager);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected=NoResultException.class)
	@Ignore
	public void tryToGetAPaymentPlanForAnOfferIdWhichHasNotBeenCreated() {
		paymentPlanDao.findByOfferId("NON_EXISTENT");
	}

}