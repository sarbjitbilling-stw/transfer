package uk.co.stwater.api.calculator.offers.service;

import org.apache.commons.lang3.builder.ToStringBuilder;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

import jakarta.xml.bind.annotation.XmlElement;
import java.math.BigDecimal;
import java.util.Date;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

public class TestAccountSummary implements AccountSummaryResponse {
    @XmlElement
    private BigDecimal accountBalance = BigDecimal.ZERO;

    @Override
    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    @Override
    public TargetAccountNumber getAccountNumber() {
        return null;
    }

    @Override
    public String getAccountStatus() {
        return null;
    }

    @Override
    public String getBillPrintMedium() {
        return null;
    }

    @Override
    public BigDecimal getCurrentAmountDue() {
        return null;
    }

    @Override
    public BigDecimal getLastInvoiceAmount() {
        return null;
    }

    @Override
    public Date getLastInvoiceDueDate() {
        return null;
    }

    @Override
    public Date getLastInvoiceIssueDate() {
        return null;
    }

    @Override
    public BigDecimal getLastPaymentAmount() {
        return null;
    }

    @Override
    public Date getLastPaymentDate() {
        return null;
    }

    @Override
    public boolean isIsDirectSpecialConditionSet() {
        return false;
    }

    @Override
    public boolean hasAmiMeterFlag() {
        return false;
    }

    @Override
    public boolean isIsPaperless() {
        return false;
    }

    @Override
    public boolean isIsPostClaimFlag() {
        return false;
    }

    @Override
    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }

    @Override
    public void setAccountStatus(String accountStatus) {

    }

    @Override
    public void setBillPrintMedium(String billPrintMedium) {

    }

    @Override
    public void setCurrentAmountDue(BigDecimal currentAmountDue) {

    }

    @Override
    public void setIsDirectSpecialConditionSet(boolean isDirectSpecialConditionSet) {

    }

    @Override
    public void setIsPaperless(boolean isPaperless) {

    }

    @Override
    public void setIsPostClaimFlag(boolean isPostClaimFlag) {

    }

    @Override
    public void setLastInvoiceAmount(BigDecimal lastInvoiceAmount) {

    }

    @Override
    public void setLastInvoiceDueDate(Date lastInvoiceDueDate) {

    }

    @Override
    public void setLastInvoiceIssueDate(Date lastInvoiceIssueDate) {

    }

    @Override
    public void setLastPaymentAmount(BigDecimal lastPaymentAmount) {

    }

    @Override
    public void setLastPaymentDate(Date lastPaymentDate) {

    }

    @Override
    public Long getPropertyNum() {
        return null;
    }

    @Override
    public boolean hasDemandDirectDebit() {
        return false;
    }

    @Override
    public boolean isPostJudgementFlag() {
        return false;
    }

    @Override
    public boolean isPreClaimFlag() {
        return false;
    }

    @Override
    public boolean isMaxDefaultedPlansFlag() {
        return false;
    }

    @Override
    public boolean isConditionalPayPlanFlag() {
        return false;
    }

    @Override
    public String getPayPlanStatus() {
        return null;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountBalance", accountBalance)
                .toString();
    }

    @Override
    public boolean isOutstandingAQFlag() {
        return false;
    }

    @Override
    public void setOutstandingAQFlag(boolean outstandingAQFlag) {
    }

    @Override
    public Long getOutstandingAQOrg() {
        return null;
    }

    @Override
    public void setOutstandingAQOrg(Long outstandingAQOrg) {
    }

    @Override
    public String getServAddress() {
        return null;
    }
}
