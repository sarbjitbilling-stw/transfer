package uk.co.stwater.api.calculator.offers.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyObject;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import uk.co.stwater.api.calculator.offers.dao.PaymentPlanDao;
import uk.co.stwater.api.calculator.offers.dao.PreferredPaymentDao;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.calculator.offers.Arrears;
import uk.co.stwater.api.osgi.model.calculator.offers.BdsOfferRequestDetails;
import uk.co.stwater.api.osgi.model.calculator.offers.Invoice;
import uk.co.stwater.api.osgi.model.calculator.offers.InvoiceLine;
import uk.co.stwater.api.osgi.model.calculator.offers.MeasuredIndicator;
import uk.co.stwater.api.osgi.model.calculator.offers.Offer;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculation;
import uk.co.stwater.api.osgi.model.calculator.offers.OffersCalculationRequest;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanControls;
import uk.co.stwater.api.osgi.model.calculator.offers.PaymentPlanOfferLevel;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvision;
import uk.co.stwater.api.osgi.model.calculator.offers.ServiceProvisionBudget;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.iib.client.api.offers.OffersTargetService;
import uk.co.stwater.model.calculator.offers.PaymentPlan;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;

@ExtendWith(MockitoExtension.class)
public class OffersCalculationServiceImplTest {
    private static final String AUTH_TOKEN = "SSUTER1";

    @Mock
    OffersTargetService offersTargetService;

    @Mock
    GetAccountSummaryClient accountSummaryClient;

    @Mock
    PaymentPlanDao paymentPlanDao;

    @Mock
    PreferredPaymentDao preferredPaymentDao;

    @Spy
    InvoiceAnalyser invoiceAnalyserSpy = new InvoiceAnalyserImpl();

    @Spy
    InstallmentGenerator installmentGeneratorSpy = new InstallmentGeneratorImpl();

    @Spy
    BasePeriodAnalyser basePeriodAnalyserSpy = new BasePeriodAnalyserImpl();

    @Spy
    OfferGenerator offerGeneratorSpy = new OfferGeneratorImpl();

    @Spy
    OfferGeneratorPreferredPayment offerGeneratorPreferredPaymentSpy = new OfferGeneratorPreferredPaymentImpl();


    @InjectMocks
    private OffersCalculationService service = new OffersCalculationServiceImpl();

    private LocalDate getTargetDate() {
        return LocalDate.of(2017, Month.SEPTEMBER, 1);
    }


    private List<String> getMeasuredIndicatorsForProperty() {
        List<String> measuredIndicator = new ArrayList<>();
        measuredIndicator.add("M");
        return measuredIndicator;
    }

    private List<String> getAssessedIndicatorsForProperty() {
        List<String> measuredIndicator = new ArrayList<>();
        measuredIndicator.add("A");
        return measuredIndicator;
    }

    private List<String> getUnMeasuredIndicatorsForProperty() {
        List<String> measuredIndicator = new ArrayList<>();
        measuredIndicator.add("U");
        return measuredIndicator;
    }

    private List<String> getArrearsIndicatorsForProperty() {
        List<String> measuredIndicator = new ArrayList<>();
//        measuredIndicator.add("U");
        return measuredIndicator;
    }

    private List<ServiceProvision> getActiveServiceProvisionsForAccount() {
        List<ServiceProvision> serviceProvisions = new ArrayList<>();
        serviceProvisions.add(getFirstServiceProvision());
        serviceProvisions.add(getSecondServiceProvision());
        return serviceProvisions;
    }

    private List<ServiceProvision> getActiveServiceProvisionsWithHDrainageForAccount() {
        List<ServiceProvision> serviceProvisions = new ArrayList<>();
        serviceProvisions.add(getFirstServiceProvision());
        serviceProvisions.add(getSecondServiceProvision());
        serviceProvisions.add(getThirdServiceProvision());
        
        return serviceProvisions;
    }
    
    private ServiceProvision getFirstServiceProvision() {
        ServiceProvision serviceProvision = new ServiceProvision();
        serviceProvision.setServiceProvisionCode("W");
        serviceProvision.setServiceProvisionDes("Meas Water");
        serviceProvision.setServiceProvisionNum(32L);
        serviceProvision.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("32"));
        serviceProvision.setServiceStartDate(LocalDate.of(2016, Month.JANUARY, 20));
        serviceProvision.setServiceProvisionBudgetFromBills(getFirstServiceProvisionBudget());
        serviceProvision.setServiceProvisionBudgetFromCalcs(getFirstServiceProvisionBudget());
        return serviceProvision;
    }

    private List<ServiceProvisionBudget> getFirstServiceProvisionBudget() {
        List<ServiceProvisionBudget> serviceProvisionBudgets = new ArrayList<>();
        ServiceProvisionBudget serviceProvisionBudget = new ServiceProvisionBudget();
        serviceProvisionBudgets.add(serviceProvisionBudget);
        return serviceProvisionBudgets;
    }

    private ServiceProvision getSecondServiceProvision() {
        ServiceProvision serviceProvision = new ServiceProvision();
        serviceProvision.setServiceProvisionCode("S");
        serviceProvision.setServiceProvisionDes("Meas Used Water");
        serviceProvision.setServiceProvisionNum(34L);
        serviceProvision.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("34"));
        serviceProvision.setServiceStartDate(LocalDate.of(2016, Month.JANUARY, 20));
        serviceProvision.setServiceProvisionBudgetFromBills(getFirstServiceProvisionBudget());
        serviceProvision.setServiceProvisionBudgetFromCalcs(getFirstServiceProvisionBudget());
        return serviceProvision;
    }

    private ServiceProvision getThirdServiceProvision() {
        ServiceProvision serviceProvision = new ServiceProvision();
        serviceProvision.setServiceProvisionCode("HIGHD");
        serviceProvision.setServiceProvisionDes("highways Drainage");
        serviceProvision.setServiceProvisionNum(34L);
        serviceProvision.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("34"));
        serviceProvision.setServiceStartDate(LocalDate.of(2016, Month.JANUARY, 20));
        serviceProvision.setServiceProvisionBudgetFromBills(getFirstServiceProvisionBudget());
        serviceProvision.setServiceProvisionBudgetFromCalcs(getFirstServiceProvisionBudget());
        return serviceProvision;
    }
    
    private OffersCalculationRequest getOffersCalculationRequestForMeasured() {
        OffersCalculationRequest request = new OffersCalculationRequest();
        request.setAccountNumber(new TargetAccountNumber("359002218", null));
        request.setLegalEntityNo("954002067");
        request.setPaymentMethod("DD");
        request.setPaymentFrequency("M");
        request.setFirstInstallmentAmount(new BigDecimal("90.00"));
        request.setUpfrontPaymentAmount(BigDecimal.ZERO);
        request.setGetAllPPCOffers(true);
        request.setPreferredPaymentDay(20);
        request.setForecast(new BigDecimal("1200.00"));
        request.setPreferredPaymentDate(LocalDate.of(2017, Month.AUGUST, 20));
        request.setAccountBrand("1");//ST
        return request;
    }

    private OffersCalculationRequest getOffersCalculationRequestForAssessed() {
        OffersCalculationRequest request = new OffersCalculationRequest();
        request.setAccountNumber(new TargetAccountNumber("359002218", null));
        request.setLegalEntityNo("954002067");
        request.setPaymentMethod("DD");
        request.setPaymentFrequency("M");
        request.setFirstInstallmentAmount(new BigDecimal("90.00"));
        request.setUpfrontPaymentAmount(BigDecimal.ZERO);
        request.setGetAllPPCOffers(true);
        request.setPreferredPaymentDay(20);
        request.setForecast(new BigDecimal("1000.00"));
        request.setPreferredPaymentDate(LocalDate.of(2017, Month.AUGUST, 20));
        request.setAccountBrand("1");//ST
        return request;
    }

    private OffersCalculationRequest getOffersCalculationRequestForUnmeasured() {
        OffersCalculationRequest request = new OffersCalculationRequest();
        request.setAccountNumber(new TargetAccountNumber("359002218", null));
        request.setLegalEntityNo("954002067");
        request.setPaymentMethod("DD");
        request.setPaymentFrequency("M");
        request.setFirstInstallmentAmount(new BigDecimal("90.00"));
        request.setUpfrontPaymentAmount(BigDecimal.ZERO);
        request.setGetAllPPCOffers(true);
        request.setPreferredPaymentDay(28);
        request.setPreferredPaymentDate(LocalDate.of(2017, Month.DECEMBER, 28));
        request.setAccountBrand("1");//ST
        return request;
    }

    private OffersCalculationRequest getOffersCalculationRequestForArrears() {
        OffersCalculationRequest request = new OffersCalculationRequest();
        request.setAccountNumber(new TargetAccountNumber("359002218", null));
        request.setLegalEntityNo("954002067");
        request.setPaymentMethod("DD");
        request.setPaymentFrequency("M");
        request.setFirstInstallmentAmount(new BigDecimal("90.00"));
        request.setUpfrontPaymentAmount(BigDecimal.ZERO);
        request.setGetAllPPCOffers(true);
        request.setPreferredPaymentDay(20);
        request.setForecast(new BigDecimal("1200.00"));
        request.setPreferredPaymentDate(LocalDate.of(2017, Month.AUGUST, 20));
        request.setAccountBrand("1");//ST
        return request;
    }

    private Arrears getAccountEventsOutstandingAmounts() {
        BigDecimal arrearsAmount = new BigDecimal("500.20");
        BigDecimal thirdPartyChargesAmount = new BigDecimal("300.30");
        return new Arrears(arrearsAmount, thirdPartyChargesAmount);
    }

    private List<Invoice> getInvoices() {
        List<Invoice> invoices = new ArrayList<>();
        invoices.add(getFirstInvoice());
        invoices.add(getSecondInvoice());
        return invoices;
    }

    private List<Invoice> getInvoicesForLast3Years() {
        List<Invoice> invoices = new ArrayList<>();
        invoices.add(getFirstInvoice());
        invoices.add(getSecondInvoice());
        invoices.add(getThirdInvoice());
        invoices.add(getFourthInvoice());
        return invoices;
    }

    private Invoice getFirstInvoice() {
        Invoice invoice = new Invoice();
        invoice.setCreatedTime(LocalDateTime.of(2016, Month.JULY, 18, 19, 37, 32));
        invoice.setEventAmount(new BigDecimal("88.82"));
        RefData accountEventType = new RefData();
        accountEventType.setCode("BILLI");
        invoice.setAccountEventType(accountEventType);

        invoice.setInvoiceNum(703048439L);
        invoice.setAccountStatus("UNPAID");
        invoice.setBillStartDate(LocalDate.of(2016, Month.JULY, 18));
        invoice.setBillEndDate(LocalDate.of(2016, Month.NOVEMBER, 19));
        invoice.setThirdPartyStatus(null);
        return invoice;
    }

    private Invoice getSecondInvoice() {
        Invoice invoice = new Invoice();
        invoice.setCreatedTime(LocalDateTime.of(2016, Month.NOVEMBER, 20, 20, 21, 32));
        invoice.setEventAmount(new BigDecimal("100.15"));
        RefData accountEventType2 = new RefData();
        accountEventType2.setCode("BILLI");
        invoice.setAccountEventType(accountEventType2);

        invoice.setInvoiceNum(498072678L);
        invoice.setAccountStatus("PART PAID");
        invoice.setBillStartDate(LocalDate.of(2016, Month.NOVEMBER, 20));
        invoice.setBillEndDate(LocalDate.of(2016, Month.DECEMBER, 19));
        invoice.setThirdPartyStatus(null);
        return invoice;
    }

    private Invoice getThirdInvoice() {
        Invoice invoice = new Invoice();
        invoice.setCreatedTime(LocalDateTime.of(2015, Month.APRIL, 10, 20, 21, 32));
        invoice.setEventAmount(new BigDecimal("150.35"));
        RefData accountEventType2 = new RefData();
        accountEventType2.setCode("BILLI");
        invoice.setAccountEventType(accountEventType2);

        invoice.setInvoiceNum(498072678L);
        invoice.setAccountStatus("PART PAID");
        invoice.setBillStartDate(LocalDate.of(2015, Month.APRIL, 10));
        invoice.setBillEndDate(LocalDate.of(2015, Month.OCTOBER, 9));
        invoice.setThirdPartyStatus(null);
        return invoice;
    }

    private Invoice getFourthInvoice() {
        Invoice invoice = new Invoice();
        invoice.setCreatedTime(LocalDateTime.of(2015, Month.JANUARY, 10, 20, 21, 32));
        invoice.setEventAmount(new BigDecimal("220.58"));
        RefData accountEventType2 = new RefData();
        accountEventType2.setCode("BILLI");
        invoice.setAccountEventType(accountEventType2);

        invoice.setInvoiceNum(498072678L);
        invoice.setAccountStatus("PART PAID");
        invoice.setBillStartDate(LocalDate.of(2015, Month.JANUARY, 10));
        invoice.setBillEndDate(LocalDate.of(2015, Month.MARCH, 31));
        invoice.setThirdPartyStatus(null);
        return invoice;
    }

    private InvoiceLine getFirstInvoiceLine() {
        InvoiceLine invoiceLine = new InvoiceLine();
        invoiceLine.setServiceProvisionNum(32L);
        invoiceLine.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("32"));
        invoiceLine.setServiceProvisionCode("W");
        invoiceLine.setServiceProvisionDes("Meas Water");
        invoiceLine.setBillPeriodStartDate(LocalDate.of(2016, Month.MAY, 11));
        invoiceLine.setBillSubPeriodStartDate(LocalDate.of(2016, Month.MAY, 11));
        invoiceLine.setApplicableBillPeriodEndDate(LocalDate.of(2016, Month.NOVEMBER, 10));
        invoiceLine.setBillPeriodEndDate(LocalDate.of(2016, Month.NOVEMBER, 10));
        invoiceLine.setSubPeriodChargeAmount(new BigDecimal("52.56"));
        return invoiceLine;
    }

    private InvoiceLine getSecondInvoiceLine() {
        InvoiceLine invoiceLine = new InvoiceLine();
        invoiceLine.setServiceProvisionNum(34L);
        invoiceLine.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("34"));
        invoiceLine.setServiceProvisionCode("UD");
        invoiceLine.setServiceProvisionDes("Unmeas Drainage");
        invoiceLine.setBillPeriodStartDate(LocalDate.of(2016, Month.MAY, 11));
        invoiceLine.setBillSubPeriodStartDate(LocalDate.of(2016, Month.MAY, 11));
        invoiceLine.setApplicableBillPeriodEndDate(LocalDate.of(2016, Month.NOVEMBER, 10));
        invoiceLine.setBillPeriodEndDate(LocalDate.of(2016, Month.NOVEMBER, 10));
        invoiceLine.setSubPeriodChargeAmount(new BigDecimal("31.48"));
        return invoiceLine;
    }


    private InvoiceLine getThirdInvoiceLine() {
        InvoiceLine invoiceLine = new InvoiceLine();
        invoiceLine.setServiceProvisionNum(32L);
        invoiceLine.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("32"));
        invoiceLine.setServiceProvisionCode("W");
        invoiceLine.setServiceProvisionDes("Meas Water");
        invoiceLine.setBillPeriodStartDate(LocalDate.of(2015, Month.APRIL, 10));
        invoiceLine.setBillSubPeriodStartDate(LocalDate.of(2015, Month.APRIL, 10));
        invoiceLine.setApplicableBillPeriodEndDate(LocalDate.of(2015, Month.OCTOBER, 9));
        invoiceLine.setBillPeriodEndDate(LocalDate.of(2015, Month.OCTOBER, 9));

        invoiceLine.setSubPeriodChargeAmount(new BigDecimal("66.66"));
        return invoiceLine;
    }

    private InvoiceLine getFourthInvoiceLine() {
        InvoiceLine invoiceLine = new InvoiceLine();
        invoiceLine.setServiceProvisionNum(34L);
        invoiceLine.setPropertyAndServiceProvisionNum("5000001".concat("_").concat("34"));
        invoiceLine.setServiceProvisionCode("UD");
        invoiceLine.setServiceProvisionDes("Unmeas Drainage");
        invoiceLine.setBillPeriodStartDate(LocalDate.of(2015, Month.JANUARY, 10));
        invoiceLine.setBillSubPeriodStartDate(LocalDate.of(2015, Month.JANUARY, 10));
        invoiceLine.setApplicableBillPeriodEndDate(LocalDate.of(2015, Month.MARCH, 31));
        invoiceLine.setBillPeriodEndDate(LocalDate.of(2015, Month.MARCH, 31));
        invoiceLine.setSubPeriodChargeAmount(new BigDecimal("67.22"));
        return invoiceLine;
    }


    private List<InvoiceLine> getInvoiceLinesForLast3Years() {
        List<InvoiceLine> invoiceLines = new ArrayList<>();
        invoiceLines.add(getFirstInvoiceLine());
        invoiceLines.add(getSecondInvoiceLine());
        invoiceLines.add(getThirdInvoiceLine());
        invoiceLines.add(getFourthInvoiceLine());
        return invoiceLines;
    }

    private List<InvoiceLine> getInvoiceLines() {
        List<InvoiceLine> invoiceLines = new ArrayList<>();
        invoiceLines.add(getFirstInvoiceLine());
        invoiceLines.add(getSecondInvoiceLine());
        return invoiceLines;
    }

    private AccountSummaryResponse getAccountSummary() {
        TestAccountSummary response = new TestAccountSummary();
        response.setAccountBalance(new BigDecimal("800.50"));
        response.setLastPaymentDate(new Date(System.currentTimeMillis()));
        return response;
    }

    private PaymentPlanControls getPayPlanControls() {
        PaymentPlanControls paymentPlanControls = new PaymentPlanControls();
        paymentPlanControls.setPercentageUplift(new BigDecimal("1.3"));
        return paymentPlanControls;
    }

    private List<PaymentPlan> getPaymentPlans() {
        return readPaymentPlans();
    }

    private String getFilePath(String fileName) {
        String platformIndependentPath;
        try {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            platformIndependentPath = Paths.get(classloader.getResource(fileName).toURI()).toString();
        } catch (Exception ex) {
            throw new STWTechnicalException(ex.getMessage(), ex);
        }
        return platformIndependentPath;
    }

    private List<PaymentPlan> readPaymentPlans() {
        return OffersCsvTransformers.readPaymentPlans(getFilePath("measured_payment_plans.csv"));
    }

    private List<PaymentPlan> readMeasuredWithAllPpcPaymentPlans() {
        return OffersCsvTransformers.readPaymentPlans(getFilePath("measured_payment_plans_all_ppc.csv"));
    }

    private List<PaymentPlan> readUnmeasuredWithAllPpcPaymentPlans() {
        return OffersCsvTransformers.readPaymentPlans(getFilePath("unmeasured_payment_plans.csv"));
    }

    private List<PaymentPlan> readAssessedWithAllPpcPaymentPlans() {
        return OffersCsvTransformers.readPaymentPlans(getFilePath("assessed_payment_plans_all_ppc.csv"));
    }

    private List<PaymentPlan> readArrearsPaymentPlans() {
        return OffersCsvTransformers.readPaymentPlans(getFilePath("arrears_payment_plans.csv"));
    }

    private TargetAccountNumber getTargetAccountNumber(final String accountNumber) {
        return new TargetAccountNumber(accountNumber, '1');
    }

    @BeforeEach
    void setUp() throws Exception {
        TargetAccountNumber targetAccountNumber = getTargetAccountNumber("359002218");
        Mockito.when(accountSummaryClient.getAccountSummary(anyObject(), anyString()))
                .thenReturn(getAccountSummary());

        Mockito.when(offersTargetService.getArrears(targetAccountNumber, AUTH_TOKEN))
                .thenReturn(getAccountEventsOutstandingAmounts());

        Mockito.when(offersTargetService.getCombinedInvoiceLines(anyObject(), anyObject(), anyString()))
                .thenReturn(getInvoiceLines());

        Mockito.when(offersTargetService.getInvoices(anyObject(), anyString()))
                .thenReturn(getInvoices());

        Mockito.when(offersTargetService.getPayPlanControls(targetAccountNumber, "N", "C", "M", AUTH_TOKEN))
                .thenReturn(getPayPlanControls());
        Mockito.when(offersTargetService.getPayPlanControls(targetAccountNumber, "N", "U", "M", AUTH_TOKEN))
                .thenReturn(getPayPlanControls());
        Mockito.when(offersTargetService.getPayPlanControls(targetAccountNumber, "N", "P", "M", AUTH_TOKEN))
                .thenReturn(getPayPlanControls());
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testMeasuredOffers() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForMeasured();

        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(getTargetDate());

        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(getActiveServiceProvisionsForAccount());

        Mockito.when(paymentPlanDao.findWithAllPpc("Measured", "DD", "M")).thenReturn(getPaymentPlans());
        Mockito.when(paymentPlanDao.find("Measured", "DD", "M")).thenReturn(getPaymentPlans());

        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getMeasuredIndicatorsForProperty());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
        BigDecimal expectedPlanAmount = new BigDecimal("3006.82");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 15;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(8, ppcOffers.size());
        assertEquals(6, measuredFlexOffers.size());
        assertEquals(6, unmeasuredFlexOffers.size());
    }

    @Test
    void testMeasuredOffersWithAllPPC() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForMeasured();

        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(getTargetDate());

        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(getActiveServiceProvisionsForAccount());

        Mockito.when(paymentPlanDao.findWithAllPpc("Measured", "DD", "M")).thenReturn(readMeasuredWithAllPpcPaymentPlans());
        Mockito.when(paymentPlanDao.find("Measured", "DD", "M")).thenReturn(readMeasuredWithAllPpcPaymentPlans());

        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getMeasuredIndicatorsForProperty());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
        BigDecimal expectedPlanAmount = new BigDecimal("3006.82");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 39;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(32, ppcOffers.size());
        assertEquals(6, measuredFlexOffers.size());
        assertEquals(6, unmeasuredFlexOffers.size());
    }

    @Test
    void testMeasuredOffersWithAllPPCForMultiplePreviousYearsInvoices() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForMeasured();

        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(getTargetDate());

        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(getActiveServiceProvisionsForAccount());

        Mockito.when(paymentPlanDao.findWithAllPpc("Measured", "DD", "M")).thenReturn(readMeasuredWithAllPpcPaymentPlans());
        Mockito.when(paymentPlanDao.find("Measured", "DD", "M")).thenReturn(readMeasuredWithAllPpcPaymentPlans());

        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getMeasuredIndicatorsForProperty());

        Mockito.when(offersTargetService.getCombinedInvoiceLines(anyObject(), anyObject(), anyString()))
                .thenReturn(getInvoiceLinesForLast3Years());

        Mockito.when(offersTargetService.getInvoices(anyObject(), anyString()))
                .thenReturn(getInvoicesForLast3Years());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
//        BigDecimal expectedPlanAmount = new BigDecimal("2020.66");
        BigDecimal expectedPlanAmount = new BigDecimal("3006.82");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 39;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(32, ppcOffers.size());
        assertEquals(6, measuredFlexOffers.size());
        assertEquals(6, unmeasuredFlexOffers.size());
    }

    
    @Test
    void testMeasuredOffersWithHDrainageWithAllPPCForMultiplePreviousYearsInvoices() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForMeasured();

        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(getTargetDate());

        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(getActiveServiceProvisionsWithHDrainageForAccount());

        Mockito.when(paymentPlanDao.findWithAllPpc("Measured", "DD", "M")).thenReturn(readMeasuredWithAllPpcPaymentPlans());
        Mockito.when(paymentPlanDao.find("Measured", "DD", "M")).thenReturn(readMeasuredWithAllPpcPaymentPlans());

        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getMeasuredIndicatorsForProperty());

        Mockito.when(offersTargetService.getCombinedInvoiceLines(anyObject(), anyObject(), anyString()))
                .thenReturn(getInvoiceLinesForLast3Years());

        Mockito.when(offersTargetService.getInvoices(anyObject(), anyString()))
                .thenReturn(getInvoicesForLast3Years());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
//        BigDecimal expectedPlanAmount = new BigDecimal("2020.66");
        BigDecimal expectedPlanAmount = new BigDecimal("3006.82");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 39;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(32, ppcOffers.size());
        assertEquals(6, measuredFlexOffers.size());
        assertEquals(6, unmeasuredFlexOffers.size());
    }

    
    
    @Test
    void testAssessedOffers() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForAssessed();

        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(getTargetDate());

        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(getActiveServiceProvisionsForAccount());

        Mockito.when(paymentPlanDao.findWithAllPpc("Assessed", "DD", "M")).thenReturn(readAssessedWithAllPpcPaymentPlans());
        Mockito.when(paymentPlanDao.find("Assessed", "DD", "M")).thenReturn(readAssessedWithAllPpcPaymentPlans());


        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getAssessedIndicatorsForProperty());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
        BigDecimal expectedPlanAmount = new BigDecimal("2632.40");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 33;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(32, ppcOffers.size());
        assertEquals(0, measuredFlexOffers.size());
        assertEquals(0, unmeasuredFlexOffers.size());
    }

    @Test
    void testUnMeasuredOffers() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForUnmeasured();

        LocalDate targetDate = LocalDate.of(2017, Month.DECEMBER, 10);
        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(targetDate);

        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(getActiveServiceProvisionsForAccount());

        Mockito.when(paymentPlanDao.findWithAllPpc("Unmeasured", "DD", "M")).thenReturn(readUnmeasuredWithAllPpcPaymentPlans());
        Mockito.when(paymentPlanDao.find("Unmeasured", "DD", "M")).thenReturn(readUnmeasuredWithAllPpcPaymentPlans());

        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getUnMeasuredIndicatorsForProperty());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
        BigDecimal expectedPlanAmount = new BigDecimal("970.30");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 47;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(32, ppcOffers.size());
        assertEquals(12, measuredFlexOffers.size());
        assertEquals(14, unmeasuredFlexOffers.size());

    }

    @Test
    void testArrearsOffer() throws Exception {
        OffersCalculationRequest offersCalculationService = getOffersCalculationRequestForArrears();

        LocalDate targetDate = LocalDate.of(2017, Month.DECEMBER, 10);
        Mockito.when(offersTargetService.getTargetDate(AUTH_TOKEN))
                .thenReturn(targetDate);

        List<ServiceProvision> serviceProvisions = new ArrayList<>();
        Mockito.when(offersTargetService.getActiveServiceProvisionsForAccount(anyObject(), anyString()))
                .thenReturn(serviceProvisions);

        Mockito.when(paymentPlanDao.findWithAllPpc("Arrears", "DD", "M")).thenReturn(readArrearsPaymentPlans());
        Mockito.when(paymentPlanDao.find("Arrears", "DD", "M")).thenReturn(readArrearsPaymentPlans());

        Mockito.when(offersTargetService.getMeasuredIndicatorsForAccount(anyObject(), anyString()))
                .thenReturn(getArrearsIndicatorsForProperty());

        OffersCalculation offersCalculation = service.calculate(offersCalculationService, AUTH_TOKEN);
        BigDecimal expectedBalance = new BigDecimal("800.50");
        BigDecimal expectedPlanAmount = new BigDecimal("800.50");
        assertThat("Balance", offersCalculation.getAccountBalance(), Matchers.comparesEqualTo(expectedBalance));
        assertThat("Plan Amount", offersCalculation.getPlanAmount(), Matchers.comparesEqualTo(expectedPlanAmount));
        int expectedNoOfOffers = 11;
        assertEquals(expectedNoOfOffers, offersCalculation.getOffers().size());
        List<Offer> standardOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.STANDARD.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> ppcOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.PPC.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> measuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.FLEX.getOfferLevel())
                .collect(Collectors.toList());

        List<Offer> unmeasuredFlexOffers = offersCalculation.getOffers().stream()
                .filter(offer -> offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_SHORT.getOfferLevel()
                        || offer.getGroup() == PaymentPlanOfferLevel.UNMEASURED_FLEX_LONG.getOfferLevel())
                .collect(Collectors.toList());

        assertEquals(1, standardOffers.size());
        assertEquals(0, ppcOffers.size());
        assertEquals(0, measuredFlexOffers.size());
        assertEquals(10, unmeasuredFlexOffers.size());

    }

    @Test
    public void calculateBdsOffer() {
        OffersCalculationRequest offersCalculationRequest = buildOffersCalculationRequestForBds();
        BdsOfferRequestDetails bdsOfferDetails = offersCalculationRequest.getBds();
        MeasuredIndicator measuredIndicator = MeasuredIndicator.UNMEASURED;
        PaymentPlan bdsPaymentPlan = buildBdsPaymentPlan(measuredIndicator, bdsOfferDetails.getNumberOfMonths());

        LocalDate targetDate = LocalDate.of(2017, Month.DECEMBER, 10);
        when(offersTargetService.getTargetDate(any())).thenReturn(targetDate);
        when(offersTargetService.getActiveServiceProvisionsForAccount(any(), any()))
                .thenReturn(Collections.emptyList());
        when(offersTargetService.getMeasuredIndicatorsForAccount(any(), any())).thenReturn(Arrays.asList(measuredIndicator.getTargetCode()));
        when(paymentPlanDao.find(measuredIndicator.getDbValue(), offersCalculationRequest.getPaymentMethod(),
                offersCalculationRequest.getPaymentFrequency(), PaymentPlan.PLAN_VARIANT_BDS,
                bdsOfferDetails.getNumberOfMonths())).thenReturn(Arrays.asList(bdsPaymentPlan));

        OffersCalculation actual = service.calculate(offersCalculationRequest, AUTH_TOKEN);

        assertEquals(new BigDecimal("800.50"), actual.getAccountBalance());
        assertEquals(new BigDecimal("72.94"), actual.getPlanAmount());
        // offer validation
        assertEquals(1, actual.getOffers().size());
        Offer bdsOffer = actual.getOffers().get(0);
        assertTrue(bdsOffer.isValid());
        assertEquals(new BigDecimal(bdsOfferDetails.getNumberOfMonths()), bdsOffer.getNumOfInstallments());

        assertEquals(new BigDecimal("10.42"), bdsOffer.getInstallmentAmount());
        assertEquals(new BigDecimal("8.52"), bdsOffer.getInstallmentForecastAmount());
        assertEquals(new BigDecimal("1.90"), bdsOffer.getInstallmentArrearsAmount());
        assertEquals(new BigDecimal("13.30"), bdsOffer.getArrears().getTotalArrears());
    }
    
    @Test
    public void calculateBdsOfferNotReturnedForNonArrearsPpc() {
        OffersCalculationRequest offersCalculationRequest = getOffersCalculationRequestForUnmeasured();
        offersCalculationRequest.setGetAllPPCOffers(true);
        calculateBdsOfferNotReturnedTemplate(offersCalculationRequest);
    }

    @Test
    public void calculateBdsOfferNotReturnedForNonArrearsNonPpc() {
        OffersCalculationRequest offersCalculationRequest = getOffersCalculationRequestForUnmeasured();
        offersCalculationRequest.setGetAllPPCOffers(false);
        calculateBdsOfferNotReturnedTemplate(offersCalculationRequest);
    }

    @Test
    public void calculateBdsOfferNotReturnedForArrearsPpc() {
        OffersCalculationRequest offersCalculationRequest = getOffersCalculationRequestForArrears();
        offersCalculationRequest.setGetAllPPCOffers(true);
        calculateBdsOfferNotReturnedTemplate(offersCalculationRequest);
    }

    @Test
    public void calculateBdsOfferNotReturnedForArrearsNonPpc() {
        OffersCalculationRequest offersCalculationRequest = getOffersCalculationRequestForArrears();
        offersCalculationRequest.setGetAllPPCOffers(false);
        calculateBdsOfferNotReturnedTemplate(offersCalculationRequest);
    }

    private void calculateBdsOfferNotReturnedTemplate(OffersCalculationRequest offersCalculationRequest) {
        MeasuredIndicator measuredIndicator = MeasuredIndicator.UNMEASURED;
        PaymentPlan bdsPaymentPlan = buildBdsPaymentPlan(measuredIndicator, 5);

        LocalDate targetDate = LocalDate.of(2017, Month.DECEMBER, 10);
        when(offersTargetService.getTargetDate(any())).thenReturn(targetDate);
        when(offersTargetService.getActiveServiceProvisionsForAccount(any(), any()))
                .thenReturn(Collections.emptyList());
        when(offersTargetService.getMeasuredIndicatorsForAccount(any(), any())).thenReturn(Arrays.asList(measuredIndicator.getTargetCode()));
        when(paymentPlanDao.find(any(), any(), any())).thenReturn(Arrays.asList(bdsPaymentPlan));
        when(paymentPlanDao.findWithAllPpc(any(), any(), any())).thenReturn(Arrays.asList(bdsPaymentPlan));
        when(offersTargetService.getMeasuredIndicatorsForAccount(any(), any()))
                .thenReturn(getArrearsIndicatorsForProperty());

        ServiceException thrown = assertThrows(ServiceException.class,
                () -> service.calculate(offersCalculationRequest, AUTH_TOKEN));
        
        assertSame(OffersCalculatorErrorCodes.NO_VALID_OFFERS, thrown.getCode());

        verify(paymentPlanDao, atMost(1)).find(any(), any(), any());
        verify(paymentPlanDao, atMost(1)).findWithAllPpc(any(), any(), any());
        verifyNoMoreInteractions(paymentPlanDao);
    }


    private OffersCalculationRequest buildOffersCalculationRequestForBds() {
        OffersCalculationRequest request = new OffersCalculationRequest();
        request.setAccountNumber(new TargetAccountNumber("359002218", null));
        request.setLegalEntityNo("954002067");
        request.setPaymentMethod("DD");
        request.setPaymentFrequency("M");
        request.setUpfrontPaymentAmount(BigDecimal.ZERO);
        request.setGetAllPPCOffers(true);
        request.setPlanAmount(new BigDecimal("66.02"));
        request.setPreferredPaymentDay(20);
        request.setPreferredPaymentDate(LocalDate.of(2017, Month.AUGUST, 20));
        request.setAccountBrand("1");// ST
        BdsOfferRequestDetails bdsDetails = new BdsOfferRequestDetails();
        bdsDetails.setMonthlyTariffAmount(new BigDecimal("8.52"));
        bdsDetails.setMonthlyArrearsAmount(new BigDecimal("1.90"));
        bdsDetails.setNumberOfMonths(7);
        request.setBds(bdsDetails);
        return request;
    }

    private PaymentPlan buildBdsPaymentPlan(MeasuredIndicator measuredIndicator, int length) {
        PaymentPlan paymentPlan = new PaymentPlan();

        paymentPlan.setServiceType(measuredIndicator.getDbValue());
        paymentPlan.setArrears("Y");
        paymentPlan.setOfferLevel(1);
        paymentPlan.setPlanType("PPC");
        paymentPlan.setPaymentFrequency("M");
        paymentPlan.setPaymentMethod("DD");
        paymentPlan.setLength(new BigDecimal(length));
        paymentPlan.setPlanVariant("BDS");
        paymentPlan.setReconciliationMethodCode("DS");
        paymentPlan.setConditional("N");
        paymentPlan.setActive("Y");
        paymentPlan.setMonth(0);
        paymentPlan.setIncludeForecast("Y");

        return paymentPlan;
    }

}
