package uk.co.stwater.api.calculator.offers.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TestGroupSummary {
    private String groupId;
    private String details;
    private boolean isActive = Boolean.TRUE;
    private boolean throwsException = Boolean.FALSE;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public boolean isThrowsException() {
        return throwsException;
    }

    public void setThrowsException(final boolean throwsException) {
        this.throwsException = throwsException;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("groupId", groupId)
                .append("details", details)
                .append("isActive", isActive)
                .append("throwsException", throwsException)
                .toString();
    }
}
