package uk.co.stwater.api.calculator.offers.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ServiceExceptionWrapper {
    private String code;
    private String message;
    private String messageSubset01;
    private String messageSubset02;
    private String messageSubset03;

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public String getMessageSubset01() {
        return messageSubset01;
    }

    public void setMessageSubset01(final String messageSubset01) {
        this.messageSubset01 = messageSubset01;
    }

    public String getMessageSubset02() {
        return messageSubset02;
    }

    public void setMessageSubset02(final String messageSubset02) {
        this.messageSubset02 = messageSubset02;
    }

    public String getMessageSubset03() {
        return messageSubset03;
    }

    public void setMessageSubset03(final String messageSubset03) {
        this.messageSubset03 = messageSubset03;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("code", code)
                .append("message", message)
                .append("messageSubset01", messageSubset01)
                .append("messageSubset02", messageSubset02)
                .append("messageSubset03", messageSubset03)
                .toString();
    }
}
