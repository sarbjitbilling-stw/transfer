package uk.co.stwater.api.calculator.offers.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TestSummary {
    private String id;
    private String groupId;
    private String details;
    private boolean isActive = Boolean.TRUE;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("groupId", groupId)
                .append("details", details)
                .append("isActive", isActive)
                .toString();
    }
}
