package uk.co.stwater.api.calculator.offers.service;


import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.calculator.offers.model.TestGroupSummary;
import uk.co.stwater.api.osgi.model.calculator.offers.*;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.math.BigDecimal;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class BasePeriodAnalyserImplTest {
    Logger log = LoggerFactory.getLogger(this.getClass());
    final static String USE_LATEST_NON_CANCELLED_INVOICE = "USELATESTINVOICE";
    final static BigDecimal PERCENTAGE_UPLIFT = new BigDecimal("1.013");

    @InjectMocks
    private BasePeriodAnalyser basePeriodAnalyser = new BasePeriodAnalyserImpl();

    Map<String, TestGroupSummary> testGroupSummaryMap = null;
    Map<String, List<Invoice>> inputInvoiceByGroupMap = null;
    Map<String, List<InvoiceLine>> inputInvoiceLineByGroupMap = null;
    Map<String, List<OffersCalculation>> inputOffersCalculationByGroupMap = null;
    Map<String, List<OffersCalculationRequest>> inputOffersCalculationRequestByGroupMap = null;
    Map<String, List<ServiceProvision>> inputServiceProvisionByGroupMap = null;
    Map<String, List<ServiceProvision>> outputServiceProvisionByGroupMap = null;
    Map<String, List<OffersCalculation>> outputOffersCalculationByGroupMap = null;

    @BeforeEach
    void setUp() throws Exception {
        testGroupSummaryMap = readTestGroupSummaryMap();
        inputInvoiceLineByGroupMap = readInputInvoiceLineByGroupMap();
//        printInvoiceLineByGroupMap(inputInvoiceLineByGroupMap);
        inputInvoiceByGroupMap = readInputInvoiceByGroupMap();
//        printInvoiceByGroupMap(inputInvoiceByGroupMap);
        inputOffersCalculationByGroupMap = readInputOffersCalculationByGroupMap();
        inputOffersCalculationRequestByGroupMap = readInputOffersCalculationRequestByGroupMap();
        inputServiceProvisionByGroupMap = readInputServiceProvisionByGroupMap();

        outputOffersCalculationByGroupMap = readOutputOffersCalculationByGroupMap();
        outputServiceProvisionByGroupMap = readOutputServiceProvisionByGroupMap();

    }

    private Map<String, List<OffersCalculation>> readOutputOffersCalculationByGroupMap() {
        return OffersCsvTransformers.readInputOffersCalculationByGroupMap(getFilePath("base_period_analyser_output_offerscalculation.csv"), true);
    }

    private Map<String, List<OffersCalculation>> readInputOffersCalculationByGroupMap() {
        return OffersCsvTransformers.readInputOffersCalculationByGroupMap(getFilePath("base_period_analyser_input_offerscalculation.csv"), true);
    }

    private Map<String, List<OffersCalculationRequest>> readInputOffersCalculationRequestByGroupMap() {
        return OffersCsvTransformers.readInputOffersCalculationRequestByGroupMap(getFilePath("base_period_analyser_input_calculationrequest.csv"));
    }

    private Map<String, TestGroupSummary> readTestGroupSummaryMap() {
        return OffersCsvTransformers.readTestGroupSummaryMap(getFilePath("base_period_analyser_test_group_summary.csv"));
    }

    private String getFilePath(String fileName) {
        String platformIndependentPath;
        try {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            platformIndependentPath = Paths.get(classloader.getResource(fileName).toURI()).toString();
        } catch (Exception ex) {
            log.error("Error in InstallmentGeneratorImplTest.getFilePath, {} , {} ", ex.getMessage(), ex);
            throw new STWTechnicalException(ex.getMessage(), ex);
        }
        return platformIndependentPath;
    }

    private Map<String, List<Invoice>> readInputInvoiceByGroupMap() {
        return OffersCsvTransformers.readInvoiceByGroupMap(getFilePath("base_period_analyser_input_invoice.csv"));
    }

    private Map<String, List<ServiceProvision>> readInputServiceProvisionByGroupMap() {
        return OffersCsvTransformers.readServiceProvisionByGroupMap(getFilePath("base_period_analyser_input_service_provision.csv"));
    }

    private Map<String, List<ServiceProvision>> readOutputServiceProvisionByGroupMap() {
        return OffersCsvTransformers.readServiceProvisionByGroupMap(getFilePath("base_period_analyser_output_service_provision.csv"));
    }

    private Map<String, List<InvoiceLine>> readInputInvoiceLineByGroupMap() {
        return OffersCsvTransformers.readInvoiceLineByGroupMap(getFilePath("base_period_analyser_input_invoiceline.csv"));
    }

    private List<ServiceProvision> getServiceProvisions(String groupId) {
        return inputServiceProvisionByGroupMap.get(groupId);
    }

    private OffersCalculation getOffersCalculation(String groupId) {
        OffersCalculation offersCalculation = inputOffersCalculationByGroupMap.get(groupId).get(0);//Group will have only one OffersCalculation
        OffersCalculationRequest offersCalculationRequest = inputOffersCalculationRequestByGroupMap.get(groupId).get(0);//Group will have only one offersCalculationRequest
        offersCalculation.setOffersCalculationRequest(offersCalculationRequest);

        offersCalculation.setServiceProvisions(getServiceProvisions(groupId));


        Budget budget = new Budget();
        List<Invoice> invoices = getInvoices(groupId);
        if (groupId.contains(USE_LATEST_NON_CANCELLED_INVOICE)) {
            budget.setLatestInvoice(invoices.get(0));//Should be only one invoice
        } else {
            budget.setInvoices(invoices);
        }
        offersCalculation.setBudget(budget);

        return offersCalculation;
    }


    private List<Invoice> getInvoices(String groupId) {

        List<Invoice> invoices = inputInvoiceByGroupMap.get(groupId);
        List<InvoiceLine> invoiceLinesInGroup = inputInvoiceLineByGroupMap.get(groupId);

        invoices.forEach((invoice) -> {
            List<InvoiceLine> invoiceLines = invoiceLinesInGroup.stream()
                    .filter(invoiceLine -> invoiceLine.getInvoiceNum().longValue() == invoice.getInvoiceNum().longValue())
                    .collect(Collectors.toList());
            invoice.setInvoiceLines(invoiceLines);
        });
        return invoices;

    }

    @Test
    void calculateForecastAndAccruedDetailsForSingleTestID() {
        String groupId = "M_10_MTH_HIST_1101_WITH_DIFF_PPC_UPLIFT";
        calculateForecastAndAccruedDetailsTest(groupId);
    }

    @Test
    void calculateForecastAndAccruedDetails() {
        testGroupSummaryMap.forEach((groupId, testGroupSummary) -> {
                    if (testGroupSummary.isActive()) {
                        calculateForecastAndAccruedDetailsTest(groupId);
                    }
                }
        );
    }

    private void calculateForecastAndAccruedDetailsTest(String groupId) {
        OffersCalculation offersCalculation = getOffersCalculation(groupId);
        String measuredIndicator = offersCalculation.getMeasuredIndicator();
        basePeriodAnalyser.calculateForecastAndAccruedDetails(offersCalculation, measuredIndicator);
        printOffersCalculation(getTestDetails(groupId), offersCalculation);
        assertOffersCalculation(groupId, offersCalculation, outputOffersCalculationByGroupMap.get(groupId).get(0));
        assertServiceProvision(groupId, offersCalculation.getServiceProvisions(), outputServiceProvisionByGroupMap.get(groupId));

    }

    private void assertServiceProvision(final String groupId, final List<ServiceProvision> actualServiceProvisions, final List<ServiceProvision> expectedServiceProvisions) {
        String message = "Te≤stID : ".concat(groupId).concat(":BasePeriod ServiceProvision Check:");

        actualServiceProvisions.forEach(actualServiceProvision -> {
            Optional<ServiceProvision> expectedServiceProvisionOptional = expectedServiceProvisions.stream()
                    .filter(expectedServiceProv -> expectedServiceProv.getPropertyAndServiceProvisionNum().equalsIgnoreCase(actualServiceProvision.getPropertyAndServiceProvisionNum()))
                    .findFirst();

            if (expectedServiceProvisionOptional.isPresent()) {
                ServiceProvision expectedServiceProvision = expectedServiceProvisionOptional.get();

                assertEquals(expectedServiceProvision.getServiceProvisionNum(), actualServiceProvision.getServiceProvisionNum(), message.concat(" -> ServiceProvisionNum"));

                assertThat(getMessageWithServiceProvision(message, expectedServiceProvision.getPropertyAndServiceProvisionNum()).concat(" -> Total"), actualServiceProvision.getTotal(), Matchers.comparesEqualTo(expectedServiceProvision.getTotal()));
                assertThat(getMessageWithServiceProvision(message, expectedServiceProvision.getPropertyAndServiceProvisionNum()).concat(" -> Days"), actualServiceProvision.getDays(), Matchers.comparesEqualTo(expectedServiceProvision.getDays()));

                assertServiceProvisionBudgetList(message, expectedServiceProvision.getPropertyAndServiceProvisionNum(), true,
                        actualServiceProvision.getServiceProvisionBudgetFromBills(), expectedServiceProvision.getServiceProvisionBudgetFromBills());

                assertServiceProvisionBudgetList(message, expectedServiceProvision.getPropertyAndServiceProvisionNum(), false,
                        actualServiceProvision.getServiceProvisionBudgetFromCalcs(), expectedServiceProvision.getServiceProvisionBudgetFromCalcs());

            }

        });

    }

    private void assertServiceProvisionBudgetList(String message, String propertyAndServiceProvisionNum, boolean assertServiceProvisionBudgetBills,
                                                  List<ServiceProvisionBudget> actualServiceProvisionBudgetList, List<ServiceProvisionBudget> expectedServiceProvisionBudgetList) {

        actualServiceProvisionBudgetList.forEach(actualServiceProvisionBudget -> {
            Optional<ServiceProvisionBudget> expectedServiceProvisionBudgetOptional = expectedServiceProvisionBudgetList.stream()
                    .filter(expectedServiceProvisionBudget ->
                            expectedServiceProvisionBudget.getBudgetUplift().getBudgetPlanType()
                                    .equalsIgnoreCase(actualServiceProvisionBudget.getBudgetUplift().getBudgetPlanType()))
                    .findFirst();

            expectedServiceProvisionBudgetOptional.ifPresent(expectedServiceProvisionBudget -> {
                assertServiceProvisionBudget(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, expectedServiceProvisionBudget.getBudgetUplift().getBudgetPlanType(),
                        actualServiceProvisionBudget, expectedServiceProvisionBudget);
            });
        });
    }

    private void assertServiceProvisionBudget(String message, String propertyAndServiceProvisionNum, boolean assertServiceProvisionBudgetBills, String budgetPlanType,
                                              ServiceProvisionBudget actualServiceProvisionBudget, ServiceProvisionBudget expectedServiceProvisionBudget) {
        assertThat(getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> AverageDailyCharge"),
                actualServiceProvisionBudget.getAverageDailyCharge(),
                Matchers.comparesEqualTo(expectedServiceProvisionBudget.getAverageDailyCharge()));

        assertThat(getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> ForecastWithUplift"),
                actualServiceProvisionBudget.getForecastWithUplift(),
                Matchers.comparesEqualTo(expectedServiceProvisionBudget.getForecastWithUplift()));

        assertEquals(expectedServiceProvisionBudget.getAccruedStartDate(),
                actualServiceProvisionBudget.getAccruedStartDate(),
                (getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> AccruedStartDate")));

        assertThat(getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> AccruedDays"),
                actualServiceProvisionBudget.getAccruedDays(),
                Matchers.comparesEqualTo(expectedServiceProvisionBudget.getAccruedDays()));

        assertThat(getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> AccruedChargeWithUplift"),
                actualServiceProvisionBudget.getAccruedChargeWithUplift(),
                Matchers.comparesEqualTo(expectedServiceProvisionBudget.getAccruedChargeWithUplift()));

        assertEquals(expectedServiceProvisionBudget.getBudgetUplift().getBudgetPlanType(),
                actualServiceProvisionBudget.getBudgetUplift().getBudgetPlanType(),
                (getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> BudgetPlanType")));

        assertThat(getMessageWithServiceProvisionBase(message, propertyAndServiceProvisionNum, assertServiceProvisionBudgetBills, budgetPlanType)
                        .concat(" -> PercentageUplift"),
                actualServiceProvisionBudget.getBudgetUplift().getPercentageUplift(),
                Matchers.comparesEqualTo(expectedServiceProvisionBudget.getBudgetUplift().getPercentageUplift()));


    }

    private String getMessageWithServiceProvisionBase(final String message, String propertyAndServiceProvisionNum, boolean fromBills, String budgetPlanType) {
        String fromBillDescription = fromBills ? " of Bills of : " : " of Calcs of : ";
        return getMessageWithServiceProvision(message, propertyAndServiceProvisionNum).concat(": ServiceProvisionBudget ").concat(fromBillDescription).concat(budgetPlanType).concat(" : ");
    }

    private String getMessageWithServiceProvision(final String message, String propertyAndServiceProvisionNum) {
        return message.concat(": Property And ServiceProvionNum ").concat(propertyAndServiceProvisionNum).concat(":");
    }

    private String getTestDetails(String groupId) {
        return "******TEST GROUP ID:".concat(groupId).concat(":").concat(testGroupSummaryMap.get(groupId).getDetails()).concat(":************");
    }

    private void assertOffersCalculation(String groupId, OffersCalculation actualOffersCalculation, OffersCalculation expectedOffersCalculation) {
        String message = "Te≤stID : ".concat(groupId).concat(":BasePeriod OffersCalculation Check:");

        assertThat(message.concat(" -> BaseForecast"), actualOffersCalculation.getBaseForecast(), Matchers.comparesEqualTo(expectedOffersCalculation.getBaseForecast()));
        assertThat(message.concat(" -> BaseAccrued"), actualOffersCalculation.getBaseAccrued(), Matchers.comparesEqualTo(expectedOffersCalculation.getBaseAccrued()));

        assertThat(message.concat(" -> BaseForecastForPPC"), actualOffersCalculation.getBaseForecastForPPC(), Matchers.comparesEqualTo(expectedOffersCalculation.getBaseForecastForPPC()));
        assertThat(message.concat(" -> BaseAccruedForPPC"), actualOffersCalculation.getBaseAccruedForPPC(), Matchers.comparesEqualTo(expectedOffersCalculation.getBaseAccruedForPPC()));


    }

    private void printOffersCalculation(String testDetails, OffersCalculation offersCalculation) {
        log.debug("{}, printInput:  offersCalculation: {} ", testDetails, offersCalculation.toString());
    }

    private void printInvoiceByGroupMap(Map<String, List<Invoice>> inputInvoiceByGroupMap) {
        if (inputInvoiceByGroupMap != null) {
            inputInvoiceByGroupMap.forEach((groupId, list) -> {
                log.debug("==========groupID======={}=====", groupId);
                list.forEach(invoice ->
                        log.debug("paymentPlan : {}", invoice.toString()));
            });
        }
    }

    private void printInvoiceLineByGroupMap(Map<String, List<InvoiceLine>> inputInvoiceLineByGroupMap) {
        if (inputInvoiceLineByGroupMap != null) {
            inputInvoiceLineByGroupMap.forEach((groupId, list) -> {
                log.debug("==========groupID======={}=====", groupId);
                list.forEach(invoiceLine ->
                        log.debug("paymentPlan : {}", invoiceLine.toString()));
            });
        }
    }

}