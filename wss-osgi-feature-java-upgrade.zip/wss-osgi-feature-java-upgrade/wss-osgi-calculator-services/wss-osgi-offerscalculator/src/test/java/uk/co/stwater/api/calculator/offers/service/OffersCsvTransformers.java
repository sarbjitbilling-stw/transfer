package uk.co.stwater.api.calculator.offers.service;

import uk.co.stwater.api.calculator.offers.model.ServiceExceptionWrapper;
import uk.co.stwater.api.calculator.offers.model.TestGroupSummary;
import uk.co.stwater.api.calculator.offers.model.TestSummary;
import uk.co.stwater.api.osgi.model.calculator.offers.*;
import uk.co.stwater.model.calculator.offers.PaymentPlan;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static uk.co.stwater.api.calculator.offers.service.OffersCsvUtil.createRefData;
import static uk.co.stwater.api.calculator.offers.service.OffersCsvUtil.getArrearsObject;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

public class OffersCsvTransformers {
    static private final String CSV_COMMA_DELIMITER = ",";
    static private final int TESTID_COLUMN_POSITION = 0;
    static private final int GROUP_TESTID_COLUMN_POSITION = 1;

    static private Map<String, List<Installment>> getOutputInstallmentMap(String itemLine) {
        final int INST_1_INSTALLMENTAMOUNT = 2;
        final int INST_1_INSTALLMENTARREARSAMOUNT = 3;
        final int INST_1_INSTALLMENTFORECASTAMOUNT = 4;
        final int INST_1_EXPECTEDPAYMENTDATE = 5;
        final int INST_2_INSTALLMENTAMOUNT = 6;
        final int INST_2_INSTALLMENTARREARSAMOUNT = 7;
        final int INST_2_INSTALLMENTFORECASTAMOUNT = 8;
        final int INST_2_EXPECTEDPAYMENTDATE = 9;
        final int INST_3_INSTALLMENTAMOUNT = 10;
        final int INST_3_INSTALLMENTARREARSAMOUNT = 11;
        final int INST_3_INSTALLMENTFORECASTAMOUNT = 12;
        final int INST_3_EXPECTEDPAYMENTDATE = 13;

        final int FINAL_INSTALLMENTAMOUNT = 14;
        final int FINAL_INSTALLMENTARREARSAMOUNT = 15;
        final int FINAL_INSTALLMENTFORECASTAMOUNT = 16;
        final int FINAL_EXPECTEDPAYMENTDATE = 17;

        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        String testID = itemArray[TESTID_COLUMN_POSITION];

        List<Installment> installments = new ArrayList<>();
        installments.add(getInstallment(new BigDecimal(itemArray[INST_1_INSTALLMENTAMOUNT]),
                new BigDecimal(itemArray[INST_1_INSTALLMENTARREARSAMOUNT]),
                new BigDecimal(itemArray[INST_1_INSTALLMENTFORECASTAMOUNT]),
                LocalDate.parse(itemArray[INST_1_EXPECTEDPAYMENTDATE])));

        installments.add(getInstallment(new BigDecimal(itemArray[INST_2_INSTALLMENTAMOUNT]),
                new BigDecimal(itemArray[INST_2_INSTALLMENTARREARSAMOUNT]),
                new BigDecimal(itemArray[INST_2_INSTALLMENTFORECASTAMOUNT]),
                LocalDate.parse(itemArray[INST_2_EXPECTEDPAYMENTDATE])));

        LocalDate inst_3_expectedPaymentDate = null;
        if (!itemArray[INST_3_EXPECTEDPAYMENTDATE].isEmpty()) {
            inst_3_expectedPaymentDate = LocalDate.parse(itemArray[INST_3_EXPECTEDPAYMENTDATE]);
        }

        installments.add(getInstallment(new BigDecimal(itemArray[INST_3_INSTALLMENTAMOUNT]),
                new BigDecimal(itemArray[INST_3_INSTALLMENTARREARSAMOUNT]),
                new BigDecimal(itemArray[INST_3_INSTALLMENTFORECASTAMOUNT]),
                inst_3_expectedPaymentDate));

        installments.add(getInstallment(new BigDecimal(itemArray[FINAL_INSTALLMENTAMOUNT]),
                new BigDecimal(itemArray[FINAL_INSTALLMENTARREARSAMOUNT]),
                new BigDecimal(itemArray[FINAL_INSTALLMENTFORECASTAMOUNT]),
                LocalDate.parse(itemArray[FINAL_EXPECTEDPAYMENTDATE])));

        Map<String, List<Installment>> map = new HashMap<>();
        map.put(testID, installments);
        return map;
    }

    static private Installment getInstallment(final BigDecimal installmentAmount, final BigDecimal arrearsAmount,
                                              final BigDecimal forecastAmount, final LocalDate expectedPaymentDate) {
        Installment installment = new Installment();
        installment.setInstallmentAmount(installmentAmount);
        installment.setInstallmentArrearsAmount(arrearsAmount);
        installment.setInstallmentForecastAmount(forecastAmount);
        installment.setExpectedPaymentDate(expectedPaymentDate);
        return installment;
    }

    static private Map<String, Offer> getOfferMap(String itemLine) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        Offer offer = getOfferMap(itemArray);
        String testId = getID(itemArray, false);

        Map<String, Offer> map = new HashMap<>();
        map.put(testId, offer);
        return map;
    }

    static private Offer getOfferMap(String[] itemArray) {
        Offer offer = new Offer();
        final int OFFERID = 3; //UID(2) is skipped
        final int OFFERDESCRIPTION = 4;
        final int OFFERLEVEL = 7; //SERVICETYPE(5), ARREARS(6) skipped
        final int PAYMENTFREQUENCY = 9;//PLANTYPE(8) skipped
        final int PAYMENTMETHOD = 10;
        final int LENGTH = 11;
        final int VARIANTAMOUNT = 12;
        final int PLANVARIANT = 13;
        final int MONTH = 17;//RECONCILIATIONMETHODCODE(14), CONDITIONAL(15), ACTIVE(16) skipped
        final int MONTHNAME = 18;

        final int NUMOFINSTALLMENTS = 20;//INCLUDEFORECAST(20) skipped.
        final int PLANAMOUNT = 21;

        final int FORECAST = 22;
        final int BASEFORECAST = 23;
        final int ORIGINALFORECAST = 24;
        final int ACCRUED = 25;
        final int BASEACCRUED = 26;
        final int ORIGINALACCRUED = 27;
        final int ARREARS_ACCOUNTARREARS = 28;
        final int ARREARS_THIRDPARTYCHARGES = 29;
        final int BASEARREARS_ACCOUNTARREARS = 30;
        final int BASEARREARS_THIRDPARTYCHARGES = 31;
        final int ORIGINALARREARS_ACCOUNTARREARS = 32;
        final int ORIGINALARREARS_THIRDPARTYCHARGES = 33;

        final int DISPLAYORDER = 34;
        final int POTENTIALUNDERPAYMENT = 35;
        final int INSTALLMENTARREARSAMOUNT = 36;
        final int INSTALLMENTFORECASTAMOUNT = 37;
        final int INSTALLMENTAMOUNT = 38;
        final int STARTDATE = 39;
        final int ENDDATE = 40;

        offer.setOfferId(itemArray[OFFERID]);
        offer.setOfferDetail(itemArray[OFFERDESCRIPTION]); //Note Different attributes used
        offer.setGroup(Integer.parseInt(itemArray[OFFERLEVEL]));//Note Different attributes used
        offer.setPaymentFrequency(itemArray[PAYMENTFREQUENCY]);
        offer.setPaymentMethod(itemArray[PAYMENTMETHOD]);
        offer.setLengthInMonths(Integer.parseInt(itemArray[LENGTH])); //Note Different attributes used
        offer.setVariantAmount(new BigDecimal(itemArray[VARIANTAMOUNT]));
        offer.setPlanVariant(itemArray[PLANVARIANT]);
        offer.setMonth(Integer.parseInt(itemArray[MONTH]));
        offer.setMonthName(itemArray[MONTHNAME]);

        offer.setNumOfInstallments(new BigDecimal(itemArray[NUMOFINSTALLMENTS]));
        offer.setPlanAmount(new BigDecimal(itemArray[PLANAMOUNT]));

        offer.setForecast(new BigDecimal(itemArray[FORECAST]));
        offer.setBaseForecast(new BigDecimal(itemArray[BASEFORECAST]));
        offer.setOriginalForecast(new BigDecimal(itemArray[ORIGINALFORECAST]));
        offer.setAccrued(new BigDecimal(itemArray[ACCRUED]));
        offer.setBaseAccrued(new BigDecimal(itemArray[BASEACCRUED]));
        offer.setOriginalAccrued(new BigDecimal(itemArray[ORIGINALACCRUED]));

        Arrears arrears = getArrearsObject(new BigDecimal(itemArray[ARREARS_ACCOUNTARREARS]), new BigDecimal(itemArray[ARREARS_THIRDPARTYCHARGES]));
        offer.setArrears(arrears);

        Arrears baseArrears = getArrearsObject(new BigDecimal(itemArray[BASEARREARS_ACCOUNTARREARS]), new BigDecimal(itemArray[BASEARREARS_THIRDPARTYCHARGES]));
        offer.setBaseArrears(baseArrears);

        Arrears originalArrears = getArrearsObject(new BigDecimal(itemArray[ORIGINALARREARS_ACCOUNTARREARS]), new BigDecimal(itemArray[ORIGINALARREARS_THIRDPARTYCHARGES]));
        offer.setOriginalArrears(originalArrears);

        offer.setDisplayOrder(Integer.parseInt(itemArray[DISPLAYORDER]));

        offer.setPotentialUnderPayment(new BigDecimal(itemArray[POTENTIALUNDERPAYMENT]));
        offer.setInstallmentArrearsAmount(new BigDecimal(itemArray[INSTALLMENTARREARSAMOUNT]));
        offer.setInstallmentForecastAmount(new BigDecimal(itemArray[INSTALLMENTFORECASTAMOUNT]));
        offer.setInstallmentAmount(new BigDecimal(itemArray[INSTALLMENTAMOUNT]));
        if (!itemArray[STARTDATE].isEmpty()) {
            offer.setStartDate(LocalDate.parse(itemArray[STARTDATE]));
        }
        if (!itemArray[ENDDATE].isEmpty()) {
            offer.setEndDate(LocalDate.parse(itemArray[ENDDATE]));
        }
        return offer;
    }

    static private ServiceExceptionWrapper getErrorMap(String[] itemArray) {
        final int ERROR_CODE = 2;
        final int ERROR_MESSAGE = 3;
        final int ERROR_MESSAGE_SUBSET01 = 4;
        final int ERROR_MESSAGE_SUBSET02 = 5;
        final int ERROR_MESSAGE_SUBSET03 = 6;

        ServiceExceptionWrapper serviceExceptionWrapper = new ServiceExceptionWrapper();
        serviceExceptionWrapper.setCode(itemArray[ERROR_CODE]);
        serviceExceptionWrapper.setMessage(itemArray[ERROR_MESSAGE]);
        serviceExceptionWrapper.setMessageSubset01(itemArray[ERROR_MESSAGE_SUBSET01]);
        serviceExceptionWrapper.setMessageSubset02(itemArray[ERROR_MESSAGE_SUBSET02]);
        serviceExceptionWrapper.setMessageSubset03(itemArray[ERROR_MESSAGE_SUBSET03]);
        return serviceExceptionWrapper;
    }

    static private OffersCalculationRequest getInputOffersCalculationRequestMap(String[] itemArray) {
        final int ACCOUNTNUMBER = 2;
        final int UPFRONTPAYMENTAMOUNT = 3;
        final int PREFERREDPAYMENTDATE = 4;
        final int PREFERREDPAYMENTDAY = 5;
        final int FIRSTINSTALLMENTAMOUNT = 6;
        final int FORECAST = 7;
        final int PLANAMOUNT = 8;
        final int PAYMENTMETHOD = 9;
        final int PAYMENTFREQUENCY = 10;
        final int LEGALENTITYNO = 11;
        final int GETALLPPCOFFERS = 12;
        final int PREFERREDPAYMENTSTANDARD = 13;
        final int PREFERREDPAYMENTFLEX = 14;
        final int PREFERREDPAYMENTPPC = 15;
        final int USERHASIOCROLE = 16;

        OffersCalculationRequest offersCalculationRequest = new OffersCalculationRequest();
        offersCalculationRequest.setAccountNumber(new TargetAccountNumber(itemArray[ACCOUNTNUMBER], null));
        offersCalculationRequest.setUpfrontPaymentAmount(new BigDecimal(itemArray[UPFRONTPAYMENTAMOUNT]));
        offersCalculationRequest.setPreferredPaymentDate(LocalDate.parse(itemArray[PREFERREDPAYMENTDATE]));
        offersCalculationRequest.setPreferredPaymentDay(Integer.parseInt(itemArray[PREFERREDPAYMENTDAY]));
        offersCalculationRequest.setFirstInstallmentAmount(new BigDecimal(itemArray[FIRSTINSTALLMENTAMOUNT]));
        offersCalculationRequest.setForecast(new BigDecimal(itemArray[FORECAST]));
        offersCalculationRequest.setPlanAmount(new BigDecimal(itemArray[PLANAMOUNT]));
        offersCalculationRequest.setPaymentMethod(itemArray[PAYMENTMETHOD]);
        offersCalculationRequest.setPaymentFrequency(itemArray[PAYMENTFREQUENCY]);
        offersCalculationRequest.setLegalEntityNo(itemArray[LEGALENTITYNO]);
        offersCalculationRequest.setGetAllPPCOffers(Boolean.parseBoolean(itemArray[GETALLPPCOFFERS]));
        offersCalculationRequest.setPreferredPaymentStandard(new BigDecimal(itemArray[PREFERREDPAYMENTSTANDARD]));
        offersCalculationRequest.setPreferredPaymentFlex(new BigDecimal(itemArray[PREFERREDPAYMENTFLEX]));
        offersCalculationRequest.setPreferredPaymentPPC(new BigDecimal(itemArray[PREFERREDPAYMENTPPC]));
        if (!itemArray[USERHASIOCROLE].isEmpty()) {
            offersCalculationRequest.setUserHasIOCRole(Boolean.parseBoolean(itemArray[USERHASIOCROLE]));
        }

        return offersCalculationRequest;
    }

    static private OffersCalculation getInputOffersCalculationMapForOfferGenerator(String[] itemArray) {
        final int MEASUREDINDICATOR = 2;

        final int IS_MEASURED = 3;
        final int IS_ASSESSED = 4;
        final int IS_UNMEASURED = 5;
        final int TARGETDATE = 6;
        final int PLANAMOUNT = 7;
        final int BASEFORECAST = 9;//FORECAST(8), skipped due placeholders
        final int ORIGINALFORECAST = 10;
        final int BASEACCRUED = 12;//ACCRUED(11), skipped due placeholders,
        final int ORIGINALACCRUED = 13;
        final int BASEARREARS_ACCOUNTARREARS = 16;//ARREARS_ACCOUNTARREARS(14), ARREARS_THIRDPARTYCHARGES(15), skipped due placeholders,
        final int BASEARREARS_THIRDPARTYCHARGES = 17;
        final int ORIGINALARREARS_ACCOUNTARREARS = 18;
        final int ORIGINALARREARS_THIRDPARTYCHARGES = 19;

        final int BASEFORECAST_FORPPC = 20;
        final int ORIGINALFORECAST_FORPPC = 21;
        final int BASEACCRUED_FORPPC = 22;
        final int ORIGINALACCRUED_FORPPC = 23;
        final int IS_ARREARS_PLAN = 24;

        OffersCalculation offersCalculation = new OffersCalculation();

        offersCalculation.setMeasuredIndicator(itemArray[MEASUREDINDICATOR]);
        offersCalculation.setMeasured(Boolean.parseBoolean(itemArray[IS_MEASURED]));
        offersCalculation.setAssessed(Boolean.parseBoolean(itemArray[IS_ASSESSED]));
        offersCalculation.setUnmeasured(Boolean.parseBoolean(itemArray[IS_UNMEASURED]));
        offersCalculation.setTargetDate(LocalDate.parse(itemArray[TARGETDATE]));

        offersCalculation.setPlanAmount(new BigDecimal(itemArray[PLANAMOUNT]));
        offersCalculation.setBaseForecast(new BigDecimal(itemArray[BASEFORECAST]));
        offersCalculation.setOriginalForecast(new BigDecimal(itemArray[ORIGINALFORECAST]));
        offersCalculation.setBaseAccrued(new BigDecimal(itemArray[BASEACCRUED]));
        offersCalculation.setOriginalAccrued(new BigDecimal(itemArray[ORIGINALACCRUED]));

        Arrears baseArrears = getArrearsObject(new BigDecimal(itemArray[BASEARREARS_ACCOUNTARREARS]), new BigDecimal(itemArray[BASEARREARS_THIRDPARTYCHARGES]));
        offersCalculation.setBaseArrears(baseArrears);

        Arrears originalArrears = getArrearsObject(new BigDecimal(itemArray[ORIGINALARREARS_ACCOUNTARREARS]), new BigDecimal(itemArray[ORIGINALARREARS_THIRDPARTYCHARGES]));
        offersCalculation.setOriginalArrears(originalArrears);

        offersCalculation.setBaseForecastForPPC(new BigDecimal(itemArray[BASEFORECAST_FORPPC]));
        offersCalculation.setOriginalForecastForPPC(new BigDecimal(itemArray[ORIGINALFORECAST_FORPPC]));
        offersCalculation.setBaseAccruedForPPC(new BigDecimal(itemArray[BASEACCRUED_FORPPC]));
        offersCalculation.setOriginalAccruedForPPC(new BigDecimal(itemArray[ORIGINALACCRUED_FORPPC]));

        offersCalculation.setArrearsPlan(Boolean.parseBoolean(itemArray[IS_ARREARS_PLAN]));

        return offersCalculation;
    }

    static private OffersCalculation getInputOffersCalculationMapForInstallmentGenerator(String[] itemArray) {
        final int MEASUREDINDICATOR = 2;
        final int IS_MEASURED = 3;
        final int IS_ASSESSED = 4;
        final int IS_UNMEASURED = 5;
        final int TARGETDATE = 6;
        final int IS_ARREARS_PLAN = 7;

        OffersCalculation offersCalculation = new OffersCalculation();
        offersCalculation.setMeasuredIndicator(itemArray[MEASUREDINDICATOR]);
        offersCalculation.setMeasured(Boolean.parseBoolean(itemArray[IS_MEASURED]));
        offersCalculation.setAssessed(Boolean.parseBoolean(itemArray[IS_ASSESSED]));
        offersCalculation.setUnmeasured(Boolean.parseBoolean(itemArray[IS_UNMEASURED]));
        offersCalculation.setTargetDate(LocalDate.parse(itemArray[TARGETDATE]));

        offersCalculation.setArrearsPlan(Boolean.parseBoolean(itemArray[IS_ARREARS_PLAN]));
        return offersCalculation;
    }

    static protected Map<String, TestSummary> readTestSummaryMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, TestSummary> testSummaryMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, TestSummary> map = OffersCsvTransformers.getTestSummaryMap(item);
            if (map != null) {
                testSummaryMap.putAll(map);
            }
        });
        return testSummaryMap;
    }

    static protected Map<String, TestGroupSummary> readTestGroupSummaryMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, TestGroupSummary> testGroupSummaryMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, TestGroupSummary> map = OffersCsvTransformers.getTestGroupSummaryMap(item);
            if (map != null) {
                testGroupSummaryMap.putAll(map);
            }
        });
        return testGroupSummaryMap;
    }

    static private Map<String, TestGroupSummary> getTestGroupSummaryMap(String itemLine) {
        final int TESTGROUPID = 0;
        final int TEST_DETAILS = 1;
        final int TEST_IS_ACTIVE = 2;
        final int THROWS_EXCEPTION = 3;

        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        TestGroupSummary testGroupSummary = new TestGroupSummary();
        testGroupSummary.setGroupId(itemArray[TESTGROUPID]);
        testGroupSummary.setDetails(itemArray[TEST_DETAILS]);
        testGroupSummary.setActive(Boolean.parseBoolean(itemArray[TEST_IS_ACTIVE]));
        testGroupSummary.setThrowsException(Boolean.parseBoolean(itemArray[THROWS_EXCEPTION]));

        Map<String, TestGroupSummary> map = new HashMap<>();
        map.put(testGroupSummary.getGroupId(), testGroupSummary);
        return map;
    }

    static private Map<String, TestSummary> getTestSummaryMap(String itemLine) {
        final int TESTID = 0;
        final int TESTGROUPID = 1;
        final int TEST_DETAILS = 2;
        final int TEST_IS_ACTIVE = 3;

        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        TestSummary testSummary = new TestSummary();
        testSummary.setId(itemArray[TESTID]);
        testSummary.setGroupId(itemArray[TESTGROUPID]);
        testSummary.setDetails(itemArray[TEST_DETAILS]);
        testSummary.setActive(Boolean.parseBoolean(itemArray[TEST_IS_ACTIVE]));

        Map<String, TestSummary> map = new HashMap<>();
        map.put(testSummary.getId(), testSummary);
        return map;
    }

    static private boolean isCsvHeaderRow(String[] itemArray) {
        final String FIRST_COLUMN_IGNORE = "IGNORE";
        final String FIRST_COLUMN_IGNORE_TESTID = "TESTID";
        final String FIRST_COLUMN_IGNORE_GROUPID = "TESTGROUPID";
        final int FIRST_COLUMN = 0;

        return itemArray[FIRST_COLUMN].contains(FIRST_COLUMN_IGNORE) ||
                itemArray[FIRST_COLUMN].contains(FIRST_COLUMN_IGNORE_TESTID) ||
                itemArray[FIRST_COLUMN].contains(FIRST_COLUMN_IGNORE_GROUPID);
    }

    static private Map<String, PaymentPlan> getInputPaymentPlanMap(String itemLine) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        PaymentPlan paymentPlan = getPaymentPlan(itemArray);
        String testID = getID(itemArray, false);
        Map<String, PaymentPlan> map = new HashMap<>();
        map.put(testID, paymentPlan);
        return map;
    }

    static protected Map<String, PaymentPlan> readPaymentPlanMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, PaymentPlan> inputPaymentPlanMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, PaymentPlan> map = OffersCsvTransformers.getInputPaymentPlanMap(item);
            if (map != null) {
                inputPaymentPlanMap.putAll(map);
            }
        });
        return inputPaymentPlanMap;
    }

    static protected Map<String, List<PaymentPlan>> readPaymentPlanByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<PaymentPlan>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<PaymentPlan>> groupMap = OffersCsvTransformers.getInputPaymentPlanGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, List<Installment>> readInstallmentMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<Installment>> outputInstallmentMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<Installment>> map = OffersCsvTransformers.getOutputInstallmentMap(item);
            if (map != null) {
                outputInstallmentMap.putAll(map);
            }
        });
        return outputInstallmentMap;
    }

    static protected Map<String, List<PaymentPlan>> getInputPaymentPlanGroupMap(String itemLine, Map<String, List<PaymentPlan>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        PaymentPlan paymentPlan = getPaymentPlan(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(paymentPlan);
        } else {
            List<PaymentPlan> paymentPlans = new ArrayList<>();
            paymentPlans.add(paymentPlan);
            groupMap.put(groupID, paymentPlans);
        }
        return groupMap;
    }

    static private Map<String, List<Invoice>> getInputInvoiceGroupMap(String itemLine, Map<String, List<Invoice>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        Invoice invoice = getInvoice(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(invoice);
        } else {
            List<Invoice> invoices = new ArrayList<>();
            invoices.add(invoice);
            groupMap.put(groupID, invoices);
        }
        return groupMap;
    }

    static private Map<String, List<ServiceProvision>> getInputServiceProvisionByGroupMap(String itemLine, Map<String, List<ServiceProvision>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        ServiceProvision serviceProvision = getServiceProvision(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(serviceProvision);
        } else {
            List<ServiceProvision> serviceProvisions = new ArrayList<>();
            serviceProvisions.add(serviceProvision);
            groupMap.put(groupID, serviceProvisions);
        }
        return groupMap;
    }

    static private Map<String, List<InvoiceLine>> getInputInvoiceLineGroupMap(String itemLine, Map<String, List<InvoiceLine>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        InvoiceLine invoiceLine = getInvoiceLine(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(invoiceLine);
        } else {
            List<InvoiceLine> invoiceLines = new ArrayList<>();
            invoiceLines.add(invoiceLine);
            groupMap.put(groupID, invoiceLines);
        }
        return groupMap;
    }

    static protected Map<String, OffersCalculation> readInputOffersCalculationMap(String filePath, boolean isForOfferGenerator) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, OffersCalculation> inputOffersCalculationMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, OffersCalculation> map = getInputOffersCalculationMap(item, isForOfferGenerator);
            if (map != null) {
                inputOffersCalculationMap.putAll(map);
            }
        });
        return inputOffersCalculationMap;
    }

    static protected Map<String, List<OffersCalculation>> readInputOffersCalculationByGroupMap(String filePath, boolean isForOfferGenerator) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<OffersCalculation>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<OffersCalculation>> groupMap = getInputOffersCalculationByGroupMap(item, mergedGroupMap, isForOfferGenerator);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, List<ServiceProvision>> readServiceProvisionByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<ServiceProvision>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<ServiceProvision>> groupMap = OffersCsvTransformers.getInputServiceProvisionByGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, List<OffersCalculationRequest>> readInputOffersCalculationRequestByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<OffersCalculationRequest>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<OffersCalculationRequest>> groupMap = getInputOffersCalculationRequestByGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, List<Offer>> readOffersByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<Offer>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<Offer>> groupMap = getOffersByGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, List<ServiceExceptionWrapper>> readErrorsByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<ServiceExceptionWrapper>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<ServiceExceptionWrapper>> groupMap = getErrorsByGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, Offer> readOffersMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, Offer> offersMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, Offer> map = getOfferMap(item);
            if (map != null) {
                offersMap.putAll(map);
            }
        });
        return offersMap;
    }

    static private Map<String, OffersCalculationRequest> getInputOffersCalculationRequestMap(String itemLine) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        OffersCalculationRequest offersCalculationRequest = getInputOffersCalculationRequestMap(itemArray);
        String testId = getID(itemArray, false);

        Map<String, OffersCalculationRequest> map = new HashMap<>();
        map.put(testId, offersCalculationRequest);
        return map;
    }

    static private Map<String, OffersCalculation> getInputOffersCalculationMap(String itemLine, boolean isForOfferGenerator) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        OffersCalculation offersCalculation = getInputOffersCalculationForOfferOrInstallment(itemArray, isForOfferGenerator);
        String testId = getID(itemArray, false);

        Map<String, OffersCalculation> map = new HashMap<>();
        map.put(testId, offersCalculation);
        return map;
    }

    static private Map<String, List<OffersCalculation>> getInputOffersCalculationByGroupMap(String itemLine, Map<String, List<OffersCalculation>> groupMap, boolean isForOfferGenerator) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        OffersCalculation offersCalculation = getInputOffersCalculationForOfferOrInstallment(itemArray, isForOfferGenerator);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(offersCalculation);
        } else {
            List<OffersCalculation> offersCalculations = new ArrayList<>();
            offersCalculations.add(offersCalculation);
            groupMap.put(groupID, offersCalculations);
        }
        return groupMap;
    }

    static private Map<String, List<OffersCalculationRequest>> getInputOffersCalculationRequestByGroupMap(String itemLine, Map<String, List<OffersCalculationRequest>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        OffersCalculationRequest offersCalculationRequest = getInputOffersCalculationRequestMap(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(offersCalculationRequest);
        } else {
            List<OffersCalculationRequest> offersCalculationRequests = new ArrayList<>();
            offersCalculationRequests.add(offersCalculationRequest);
            groupMap.put(groupID, offersCalculationRequests);
        }
        return groupMap;
    }

    static private Map<String, List<Offer>> getOffersByGroupMap(String itemLine, Map<String, List<Offer>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        Offer offer = getOfferMap(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(offer);
        } else {
            List<Offer> offers = new ArrayList<>();
            offers.add(offer);
            groupMap.put(groupID, offers);
        }
        return groupMap;
    }

    static private Map<String, List<ServiceExceptionWrapper>> getErrorsByGroupMap(String itemLine, Map<String, List<ServiceExceptionWrapper>> groupMap) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }

        ServiceExceptionWrapper serviceExceptionWrapper = getErrorMap(itemArray);
        String groupID = getID(itemArray, true);
        if (groupMap.containsKey(groupID)) {
            groupMap.get(groupID).add(serviceExceptionWrapper);
        } else {
            List<ServiceExceptionWrapper> serviceExceptions = new ArrayList<>();
            serviceExceptions.add(serviceExceptionWrapper);
            groupMap.put(groupID, serviceExceptions);
        }
        return groupMap;
    }

    static protected Map<String, List<Invoice>> readInvoiceByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<Invoice>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<Invoice>> groupMap = OffersCsvTransformers.getInputInvoiceGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static protected Map<String, List<InvoiceLine>> readInvoiceLineByGroupMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, List<InvoiceLine>> mergedGroupMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, List<InvoiceLine>> groupMap = OffersCsvTransformers.getInputInvoiceLineGroupMap(item, mergedGroupMap);
            if (groupMap != null) {
                mergedGroupMap.putAll(groupMap);
            }
        });
        return mergedGroupMap;
    }

    static private OffersCalculation getInputOffersCalculationForOfferOrInstallment(String[] itemArray, boolean isForOfferGenerator) {
        if (isForOfferGenerator) {
            return getInputOffersCalculationMapForOfferGenerator(itemArray);
        }
        return getInputOffersCalculationMapForInstallmentGenerator(itemArray);
    }

    static private ServiceProvision getServiceProvision(String[] itemArray) {
        final int PROPERTYANDSERVICEPROVISIONNUM = 2;
        final int SERVICEPROVISIONCODE = 3;
        final int SERVICEPROVISIONDES = 4;
        final int SERVICESTARTDATE = 5;
        final int TARIFFSTARTDATE = 6;
        final int MEASUREDINDICATOR_CODE = 7;
        final int SERVICEINDICATOR_CODE = 8;
        final int SERVICETYPE_CODE = 9;
        final int SERVICEPROVISIONNUM = 10;
        final int TARIFFCODE = 11;
        final int TARIFFDESCRIPTION = 12;
        final int ISACTIVE = 13;
        final int TOTAL = 14;
        final int DAYS = 15;
        final int FROM_BILLS_AVERAGEDAILYCHARGE = 16;
        final int FROM_BILLS_FORECASTWITHUPLIFT = 17;
        final int FROM_BILLS_ACCRUEDSTARTDATE = 18;
        final int FROM_BILLS_ACCRUEDDAYS = 19;
        final int FROM_BILLS_ACCRUEDCHARGEWITHUPLIFT = 20;

        final int FROM_BILLS_BUDGETUPLIFT_BUDGETPLANTYPE = 21;
        final int FROM_BILLS_BUDGETUPLIFT_PERCENTAGEUPLIFT = 22;

        final int FROM_BILLS_AVERAGEDAILYCHARGE_FORPPC = 23;
        final int FROM_BILLS_FORECASTWITHUPLIFT_FORPPC = 24;
        final int FROM_BILLS_ACCRUEDSTARTDATE_FORPPC = 25;
        final int FROM_BILLS_ACCRUEDDAYS_FORPPC = 26;
        final int FROM_BILLS_ACCRUEDCHARGEWITHUPLIFT_FORPPC = 27;

        final int FROM_BILLS_BUDGETUPLIFT_BUDGETPLANTYPE_FORPPC = 28;
        final int FROM_BILLS_BUDGETUPLIFT_PERCENTAGEUPLIFT_FORPPC = 29;

        final int FROM_CALCS_AVERAGEDAILYCHARGE = 30;
        final int FROM_CALCS_FORECASTWITHUPLIFT = 31;
        final int FROM_CALCS_ACCRUEDSTARTDATE = 32;
        final int FROM_CALCS_ACCRUEDDAYS = 33;
        final int FROM_CALCS_ACCRUEDCHARGEWITHUPLIFT = 34;

        final int FROM_CALCS_BUDGETUPLIFT_BUDGETPLANTYPE = 35;
        final int FROM_CALCS_BUDGETUPLIFT_PERCENTAGEUPLIFT = 36;

        final int FROM_CALCS_AVERAGEDAILYCHARGE_FORPPC = 37;
        final int FROM_CALCS_FORECASTWITHUPLIFT_FORPPC = 38;
        final int FROM_CALCS_ACCRUEDSTARTDATE_FORPPC = 39;
        final int FROM_CALCS_ACCRUEDDAYS_FORPPC = 40;
        final int FROM_CALCS_ACCRUEDCHARGEWITHUPLIFT_FORPPC = 41;

        final int FROM_CALCS_BUDGETUPLIFT_BUDGETPLANTYPE_FORPPC = 42;
        final int FROM_CALCS_BUDGETUPLIFT_PERCENTAGEUPLIFT_FORPPC = 43;

        ServiceProvision serviceProvision = new ServiceProvision();

        serviceProvision.setPropertyAndServiceProvisionNum(itemArray[PROPERTYANDSERVICEPROVISIONNUM]);
        serviceProvision.setServiceProvisionCode(itemArray[SERVICEPROVISIONCODE]);
        serviceProvision.setServiceProvisionDes(itemArray[SERVICEPROVISIONDES]);

        if (!itemArray[SERVICESTARTDATE].isEmpty()) {
            serviceProvision.setServiceStartDate(LocalDate.parse(itemArray[SERVICESTARTDATE]));
        }
        if (!itemArray[TARIFFSTARTDATE].isEmpty()) {
            serviceProvision.setTariffStartDate(LocalDate.parse(itemArray[TARIFFSTARTDATE]));
        }

        serviceProvision.setMeasuredIndicator(createRefData(itemArray[MEASUREDINDICATOR_CODE], "", ""));
        serviceProvision.setServiceIndicator(createRefData(itemArray[SERVICEINDICATOR_CODE], "", ""));
        serviceProvision.setServiceType(createRefData(itemArray[SERVICETYPE_CODE], "", ""));
        serviceProvision.setServiceProvisionNum(Long.valueOf(itemArray[SERVICEPROVISIONNUM]));
        serviceProvision.setTariffCode(itemArray[TARIFFCODE]);
        serviceProvision.setTariffDescription(itemArray[TARIFFDESCRIPTION]);
        serviceProvision.setActive(Boolean.parseBoolean(itemArray[ISACTIVE]));
        serviceProvision.setTotal(new BigDecimal(itemArray[TOTAL]));
        serviceProvision.setDays(new BigDecimal(itemArray[DAYS]));

        List<ServiceProvisionBudget> serviceProvisionBudgetBills = new ArrayList<>();
        serviceProvision.setServiceProvisionBudgetFromBills(serviceProvisionBudgetBills);

        ServiceProvisionBudget serviceProvisionBudgetBillNonPPC = new ServiceProvisionBudget();
        serviceProvisionBudgetBills.add(serviceProvisionBudgetBillNonPPC);
        serviceProvisionBudgetBillNonPPC.setAverageDailyCharge(new BigDecimal(itemArray[FROM_BILLS_AVERAGEDAILYCHARGE]));
        serviceProvisionBudgetBillNonPPC.setForecastWithUplift(new BigDecimal(itemArray[FROM_BILLS_FORECASTWITHUPLIFT]));
        if (!itemArray[FROM_BILLS_ACCRUEDSTARTDATE].isEmpty()) {
            serviceProvisionBudgetBillNonPPC.setAccruedStartDate(LocalDate.parse(itemArray[FROM_BILLS_ACCRUEDSTARTDATE]));
        }
        serviceProvisionBudgetBillNonPPC.setAccruedDays(new BigDecimal(itemArray[FROM_BILLS_ACCRUEDDAYS]));
        serviceProvisionBudgetBillNonPPC.setAccruedChargeWithUplift(new BigDecimal(itemArray[FROM_BILLS_ACCRUEDCHARGEWITHUPLIFT]));

        BudgetUplift budgetUpliftBillNonPPC = new BudgetUplift();
        budgetUpliftBillNonPPC.setBudgetPlanType(itemArray[FROM_BILLS_BUDGETUPLIFT_BUDGETPLANTYPE]);
        budgetUpliftBillNonPPC.setPercentageUplift(new BigDecimal(itemArray[FROM_BILLS_BUDGETUPLIFT_PERCENTAGEUPLIFT]));
        serviceProvisionBudgetBillNonPPC.setBudgetUplift(budgetUpliftBillNonPPC);

        //PPC
        ServiceProvisionBudget serviceProvisionBudgetBillPPC = new ServiceProvisionBudget();
        serviceProvisionBudgetBills.add(serviceProvisionBudgetBillPPC);
        serviceProvisionBudgetBillPPC.setAverageDailyCharge(new BigDecimal(itemArray[FROM_BILLS_AVERAGEDAILYCHARGE_FORPPC]));
        serviceProvisionBudgetBillPPC.setForecastWithUplift(new BigDecimal(itemArray[FROM_BILLS_FORECASTWITHUPLIFT_FORPPC]));
        if (!itemArray[FROM_BILLS_ACCRUEDSTARTDATE_FORPPC].isEmpty()) {
            serviceProvisionBudgetBillPPC.setAccruedStartDate(LocalDate.parse(itemArray[FROM_BILLS_ACCRUEDSTARTDATE_FORPPC]));
        }
        serviceProvisionBudgetBillPPC.setAccruedDays(new BigDecimal(itemArray[FROM_BILLS_ACCRUEDDAYS_FORPPC]));
        serviceProvisionBudgetBillPPC.setAccruedChargeWithUplift(new BigDecimal(itemArray[FROM_BILLS_ACCRUEDCHARGEWITHUPLIFT_FORPPC]));

        BudgetUplift budgetUpliftBillPPC = new BudgetUplift();
        budgetUpliftBillPPC.setBudgetPlanType(itemArray[FROM_BILLS_BUDGETUPLIFT_BUDGETPLANTYPE_FORPPC]);
        budgetUpliftBillPPC.setPercentageUplift(new BigDecimal(itemArray[FROM_BILLS_BUDGETUPLIFT_PERCENTAGEUPLIFT_FORPPC]));
        serviceProvisionBudgetBillPPC.setBudgetUplift(budgetUpliftBillPPC);

        //FOR CALCS
        List<ServiceProvisionBudget> serviceProvisionBudgetCalcs = new ArrayList<>();
        serviceProvision.setServiceProvisionBudgetFromCalcs(serviceProvisionBudgetCalcs);

        ServiceProvisionBudget serviceProvisionBudgetCalcNonPPC = new ServiceProvisionBudget();
        serviceProvisionBudgetCalcs.add(serviceProvisionBudgetCalcNonPPC);
        serviceProvisionBudgetCalcNonPPC.setAverageDailyCharge(new BigDecimal(itemArray[FROM_CALCS_AVERAGEDAILYCHARGE]));
        serviceProvisionBudgetCalcNonPPC.setForecastWithUplift(new BigDecimal(itemArray[FROM_CALCS_FORECASTWITHUPLIFT]));
        if (!itemArray[FROM_CALCS_ACCRUEDSTARTDATE].isEmpty()) {
            serviceProvisionBudgetCalcNonPPC.setAccruedStartDate(LocalDate.parse(itemArray[FROM_CALCS_ACCRUEDSTARTDATE]));
        }
        serviceProvisionBudgetCalcNonPPC.setAccruedDays(new BigDecimal(itemArray[FROM_CALCS_ACCRUEDDAYS]));
        serviceProvisionBudgetCalcNonPPC.setAccruedChargeWithUplift(new BigDecimal(itemArray[FROM_CALCS_ACCRUEDCHARGEWITHUPLIFT]));

        BudgetUplift budgetUpliftCalcNonPPC = new BudgetUplift();
        budgetUpliftCalcNonPPC.setBudgetPlanType(itemArray[FROM_CALCS_BUDGETUPLIFT_BUDGETPLANTYPE]);
        budgetUpliftCalcNonPPC.setPercentageUplift(new BigDecimal(itemArray[FROM_CALCS_BUDGETUPLIFT_PERCENTAGEUPLIFT]));
        serviceProvisionBudgetCalcNonPPC.setBudgetUplift(budgetUpliftCalcNonPPC);

        //PPC
        ServiceProvisionBudget serviceProvisionBudgetCalcPPC = new ServiceProvisionBudget();
        serviceProvisionBudgetCalcs.add(serviceProvisionBudgetCalcPPC);
        serviceProvisionBudgetCalcPPC.setAverageDailyCharge(new BigDecimal(itemArray[FROM_CALCS_AVERAGEDAILYCHARGE_FORPPC]));
        serviceProvisionBudgetCalcPPC.setForecastWithUplift(new BigDecimal(itemArray[FROM_CALCS_FORECASTWITHUPLIFT_FORPPC]));
        if (!itemArray[FROM_CALCS_ACCRUEDSTARTDATE_FORPPC].isEmpty()) {
            serviceProvisionBudgetCalcPPC.setAccruedStartDate(LocalDate.parse(itemArray[FROM_CALCS_ACCRUEDSTARTDATE_FORPPC]));
        }
        serviceProvisionBudgetCalcPPC.setAccruedDays(new BigDecimal(itemArray[FROM_CALCS_ACCRUEDDAYS_FORPPC]));
        serviceProvisionBudgetCalcPPC.setAccruedChargeWithUplift(new BigDecimal(itemArray[FROM_CALCS_ACCRUEDCHARGEWITHUPLIFT_FORPPC]));

        BudgetUplift budgetUpliftCalcPPC = new BudgetUplift();
        budgetUpliftCalcPPC.setBudgetPlanType(itemArray[FROM_CALCS_BUDGETUPLIFT_BUDGETPLANTYPE_FORPPC]);
        budgetUpliftCalcPPC.setPercentageUplift(new BigDecimal(itemArray[FROM_CALCS_BUDGETUPLIFT_PERCENTAGEUPLIFT_FORPPC]));
        serviceProvisionBudgetCalcPPC.setBudgetUplift(budgetUpliftCalcPPC);

        return serviceProvision;
    }

    static private Invoice getInvoice(String[] itemArray) {

        final int CREATEDTIME = 2;
        final int DATEOFISSUE = 3;
        final int BILLSTARTDATE = 4;
        final int BILLENDDATE = 5;
        final int INVOICENUM = 6;
        final int ACCOUNTEVENTTYPE_CODE = 7;
        final int THIRDPARTYSTATUS_CODE = 8;
        final int ACCOUNTSTATUS = 9;
        final int CALCULATIONSTATUS = 10;
        final int EVENTAMOUNT = 11;
        final int OUTSTANDINGAMOUNT = 12;
        final int CANCELLEDAMOUNT = 13;
        final int BALANCEAMOUNT = 14;
        final int BILLDAYSNUM = 15;
        final int ATTACHMENTLOCATION = 16;

        Invoice invoice = new Invoice();
        if (!itemArray[CREATEDTIME].isEmpty()) {
            invoice.setCreatedTime(LocalDateTime.parse(itemArray[CREATEDTIME]));
        }

        if (!itemArray[DATEOFISSUE].isEmpty()) {
            invoice.setDateOfIssue(LocalDate.parse(itemArray[DATEOFISSUE]));
        }

        if (!itemArray[BILLSTARTDATE].isEmpty()) {
            invoice.setBillStartDate(LocalDate.parse(itemArray[BILLSTARTDATE]));
        }

        if (!itemArray[BILLENDDATE].isEmpty()) {
            invoice.setBillEndDate(LocalDate.parse(itemArray[BILLENDDATE]));
        }

        if (!itemArray[INVOICENUM].isEmpty()) {
            invoice.setInvoiceNum(Long.valueOf(itemArray[INVOICENUM]));
        }

        invoice.setAccountEventType(OffersCsvUtil.createRefData(itemArray[ACCOUNTEVENTTYPE_CODE], "", ""));
        invoice.setThirdPartyStatus(OffersCsvUtil.createRefData(itemArray[THIRDPARTYSTATUS_CODE], "", ""));
        invoice.setAccountStatus(itemArray[ACCOUNTSTATUS]);
        invoice.setCalculationStatus(itemArray[CALCULATIONSTATUS]);
        invoice.setEventAmount(new BigDecimal(itemArray[EVENTAMOUNT]));
        invoice.setOutstandingAmount(new BigDecimal(itemArray[OUTSTANDINGAMOUNT]));
        invoice.setCancelledAmount(new BigDecimal(itemArray[CANCELLEDAMOUNT]));
        invoice.setBalanceAmount(new BigDecimal(itemArray[BALANCEAMOUNT]));
        invoice.setBillDaysNum(new BigDecimal(itemArray[BILLDAYSNUM]));
        invoice.setAttachmentLocation(itemArray[ATTACHMENTLOCATION]);

        return invoice;
    }

    static private InvoiceLine getInvoiceLine(String[] itemArray) {

        final int INVOICENUM = 2;
        final int PROPERTYANDSERVICEPROVISIONNUM = 3;
        final int SERVICEPROVISIONCODE = 4;
        final int SERVICEPROVISIONDES = 5;
        final int BILLPERIODSTARTDATE = 6;
        final int BILLPERIODENDDATE = 7;
        final int BILLSUBPERIODSTARTDATE = 8;
        final int APPLICABLEBILLPERIODENDDATE = 9;
        final int SUBPERIODCHARGEAMOUNT = 10;
        final int AVGDAILYCONSUMAMOUNT = 11;
        final int AMOUNTUSAGE = 12;
        final int PROPERTYID = 13;
        final int SERVICEPROVISIONNUM = 14;
        final int ADDRESS = 15;
        final int CANCELDISPUTEIND = 16;
        final int ALTERNATEID = 17;
        final int TARIFFCODE = 18;
        final int UNITOFMEASURECODE = 19;
        final int REGSPECDES = 20;
        final int MEASUREDFLAG = 21;
        final int ADJUSTEDFLAG = 22;
        final int BILLEVENTSTATUS_CODE = 23;
        final int ADDRESSCODE = 24;
        final int LEVELNUM = 25;
        final int COMBINEDNUM = 26;
        final int VERSIONNUM = 27;
        final int TARIFFVERSION = 28;

        InvoiceLine invoiceLine = new InvoiceLine();

        invoiceLine.setInvoiceNum(Long.valueOf(itemArray[INVOICENUM]));
        invoiceLine.setPropertyAndServiceProvisionNum(itemArray[PROPERTYANDSERVICEPROVISIONNUM]);
        invoiceLine.setServiceProvisionCode(itemArray[SERVICEPROVISIONCODE]);
        invoiceLine.setServiceProvisionDes(itemArray[SERVICEPROVISIONDES]);

        if (!itemArray[BILLPERIODSTARTDATE].isEmpty()) {
            invoiceLine.setBillPeriodStartDate(LocalDate.parse(itemArray[BILLPERIODSTARTDATE]));
        }
        if (!itemArray[BILLPERIODENDDATE].isEmpty()) {
            invoiceLine.setBillPeriodEndDate(LocalDate.parse(itemArray[BILLPERIODENDDATE]));
        }
        if (!itemArray[BILLSUBPERIODSTARTDATE].isEmpty()) {
            invoiceLine.setBillSubPeriodStartDate(LocalDate.parse(itemArray[BILLSUBPERIODSTARTDATE]));
        }
        if (!itemArray[APPLICABLEBILLPERIODENDDATE].isEmpty()) {
            invoiceLine.setApplicableBillPeriodEndDate(LocalDate.parse(itemArray[APPLICABLEBILLPERIODENDDATE]));
        }

        invoiceLine.setSubPeriodChargeAmount(new BigDecimal(itemArray[SUBPERIODCHARGEAMOUNT]));
        invoiceLine.setAvgDailyConsumAmount(new BigDecimal(itemArray[AVGDAILYCONSUMAMOUNT]));
        invoiceLine.setAmountUsage(new BigDecimal(itemArray[AMOUNTUSAGE]));
        invoiceLine.setPropertyId(Long.valueOf(itemArray[PROPERTYID]));
        invoiceLine.setServiceProvisionNum(Long.valueOf(itemArray[SERVICEPROVISIONNUM]));
        invoiceLine.setAddress(itemArray[ADDRESS]);
        invoiceLine.setCancelDisputeInd(itemArray[CANCELDISPUTEIND]);
        invoiceLine.setAlternateId(itemArray[ALTERNATEID]);
        invoiceLine.setTariffCode(itemArray[TARIFFCODE]);
        invoiceLine.setUnitOfMeasureCode(itemArray[UNITOFMEASURECODE]);
        invoiceLine.setRegSpecDes(itemArray[REGSPECDES]);
        invoiceLine.setMeasuredFlag(itemArray[MEASUREDFLAG]);
        invoiceLine.setAdjustedFlag(itemArray[ADJUSTEDFLAG]);
        invoiceLine.setBillEventStatus(createRefData(itemArray[BILLEVENTSTATUS_CODE], "", ""));
        invoiceLine.setAddressCode(Long.valueOf(itemArray[ADDRESSCODE]));
        invoiceLine.setLevelNum(Long.valueOf(itemArray[LEVELNUM]));
        invoiceLine.setCombinedNum(Long.valueOf(itemArray[COMBINEDNUM]));
        invoiceLine.setVersionNum(Long.valueOf(itemArray[VERSIONNUM]));
        invoiceLine.setTariffVersion(Long.valueOf(itemArray[TARIFFVERSION]));
        return invoiceLine;
    }

    static private String getID(String[] itemArray, boolean isGroupID) {
        if (isGroupID) {
            return itemArray[GROUP_TESTID_COLUMN_POSITION];
        } else {
            return itemArray[TESTID_COLUMN_POSITION];
        }
    }

    static private PaymentPlan getPaymentPlan(String itemLine) {
        String[] itemArray = itemLine.split(CSV_COMMA_DELIMITER);// a CSV has comma separated lines
        if (isCsvHeaderRow(itemArray)) {
            return null;
        }
        return getPaymentPlan(itemArray);
    }

    static protected List<PaymentPlan> readPaymentPlans(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);

        List<PaymentPlan> paymentPlans = new ArrayList<>();
        list.forEach(item -> {
            PaymentPlan paymentPlan = OffersCsvTransformers.getPaymentPlan(item);
            if (paymentPlan != null) {
                paymentPlans.add(paymentPlan);
            }
        });
        return paymentPlans;
    }

    static protected Map<String, OffersCalculationRequest> readOffersCalculationRequestMap(String filePath) {
        List<String> list = OffersCsvUtil.readFile(filePath);
        Map<String, OffersCalculationRequest> inputOffersCalculationRequestMap = new HashMap<>();
        list.forEach(item -> {
            Map<String, OffersCalculationRequest> map = getInputOffersCalculationRequestMap(item);
            if (map != null) {
                inputOffersCalculationRequestMap.putAll(map);
            }
        });
        return inputOffersCalculationRequestMap;
    }

    static private PaymentPlan getPaymentPlan(String[] itemArray) {
        final int UID = 2;
        final int OFFERID = 3;
        final int OFFERDESCRIPTION = 4;
        final int SERVICETYPE = 5;
        final int ARREARS = 6;
        final int OFFERLEVEL = 7;
        final int PLANTYPE = 8;
        final int PAYMENTFREQUENCY = 9;
        final int PAYMENTMETHOD = 10;
        final int LENGTH = 11;
        final int VARIANTAMOUNT = 12;
        final int PLANVARIANT = 13;
        final int RECONCILIATIONMETHODCODE = 14;
        final int CONDITIONAL = 15;
        final int ACTIVE = 16;
        final int MONTH = 17;
        final int MONTHNAME = 18;
        final int INCLUDEFORECAST = 19;

        PaymentPlan paymentPlan = new PaymentPlan();

        paymentPlan.setUid(Long.valueOf(itemArray[UID]));
        paymentPlan.setOfferId(itemArray[OFFERID]);
        paymentPlan.setOfferDescription(itemArray[OFFERDESCRIPTION]);
        paymentPlan.setServiceType(itemArray[SERVICETYPE]);
        paymentPlan.setArrears(itemArray[ARREARS]);
        paymentPlan.setOfferLevel(Integer.parseInt(itemArray[OFFERLEVEL]));
        paymentPlan.setPlanType(itemArray[PLANTYPE]);
        paymentPlan.setPaymentFrequency(itemArray[PAYMENTFREQUENCY]);
        paymentPlan.setPaymentMethod(itemArray[PAYMENTMETHOD]);
        paymentPlan.setLength(new BigDecimal(itemArray[LENGTH]));
        paymentPlan.setVariantAmount(new BigDecimal(itemArray[VARIANTAMOUNT]));
        paymentPlan.setPlanVariant(itemArray[PLANVARIANT]);
        paymentPlan.setReconciliationMethodCode(itemArray[RECONCILIATIONMETHODCODE]);
        paymentPlan.setConditional(itemArray[CONDITIONAL]);
        paymentPlan.setActive(itemArray[ACTIVE]);
        paymentPlan.setMonth(Integer.parseInt(itemArray[MONTH]));
        paymentPlan.setMonthName(itemArray[MONTHNAME]);
        if (!itemArray[INCLUDEFORECAST].isEmpty()) {
            paymentPlan.setIncludeForecast(itemArray[INCLUDEFORECAST]);
        }

        return paymentPlan;
    }

}
