INSERT INTO WSS_PAYMENT_METHODS(uid, paymentFrequency, paymentMethod, properties) VALUES (1, "W", "DD", "...");
INSERT INTO WSS_PAYMENT_METHODS(uid, paymentFrequency, paymentMethod, properties) VALUES (2, "B", "DD", "...");
INSERT INTO WSS_PAYMENT_METHODS(uid, paymentFrequency, paymentMethod, properties) VALUES (3, "M", "CH", "...");