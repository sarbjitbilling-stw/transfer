package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.util.List;
import java.util.Map;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTypeConstants;

public class POCBCreateSpecialConditionsCheck extends SpecialConditionsBaseCheck implements EligiblityCheck {

	@Override
	public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
			List<Property> propertyList, String channel,
			Map<String, List<SpecialConditionRestriction>> specialConditionsMap, CreatePaymentPlanContext ctx) {

		EligibilityStatus status = new EligibilityStatus();
		status.setStatus(EligabilityStatusConstants.ELIGIBLE);

		if (!method.isPlan() && method.getPaymentMethodCode().equalsIgnoreCase(PaymentMethodTypeConstants.DIRECT_DEBIT)) {

			List<SpecialConditionRestriction> specialConditionsList = specialConditionsMap.get(SpecialConditionsContants.CREATE_POCB_KEY);

			if (null != specialConditionsList && specialConditionsList.size() > 0) {
				status.setStatus(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING);
				SpecialConditionRestriction sc = specialConditionsList.get(0);
				status.setText(sc.getDefaultMessage());
			}
		}

		return status;
	}

}
