package uk.co.stwater.api.calculator.paymentarrangement.entity;

import uk.co.stwater.api.core.model.BaseModel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author zali
 */

@Table(name = "WSS_PAYMENT_METHODS")
@Entity()
public class PaymentMethodEntity extends BaseModel<Long> {

    @Column(name = "UID")
    private Long uid;

    @Column(name = "BRANDID")
    private Integer brandId;

    @Column(name = "PAYMENTFREQUENCYCODE")
    private String paymentFrequencyCode;

    @Column(name = "PAYMENTDETAILSCODE")
    private String paymentDetailsCode;

    @Column(name = "PAYMENTMETHODCODE")
    private String paymentMethodCode;

    @Column(name = "PAYMENTMETHODTEXT")
    private String paymentMethodText;

    @Column(name = "PAYMENTFREQUENCTTEXT")
    private String paymentFrequencyText;

    @Column(name = "PAYMENTPLAN")
    private boolean paymentPlan;

    @Column(name = "DEFAULTPAYMENTTYPE")
    private boolean defaultPaymentType;

    @Column(name = "FACILITYCODE")
    private String facilityCode;

    @Column(name = "DAYTYPE")
    private String dayType;

    @Column(name = "SCHEDULEDFREQCODE")
    private String scheduleFreqCode;

    @Column(name = "EARLIESTSTARTDATEDAYS")
    // earliest number of days the plan can be executed from the current target
    // date.
    private Integer earliestStartDateDays;

    @Column(name = "LATESTSTARTDATEDAYS")
    // latest number of days the plan can be executed from the current target date.
    private Integer latestStartDateDays;

    @Column(name = "PAYMENTMETHODORDER")
    private Integer paymentMethodOrder;

    @Column(name = "PAYMENTFREQUENCYORDER")
    private Integer paymentFrequencyOrder;

    @Column(name = "HOVEROVERTEXT")
    private String hoverOverText;

    @Column(name = "ACTIVE")
    private boolean active;

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    /**
     * @return the paymentDetailsCode
     */
    public String getPaymentDetailsCode() {
        return paymentDetailsCode;
    }

    /**
     * @param paymentDetailsCode the paymentDetailsCode to set
     */
    public void setPaymentDetailsCode(String paymentDetailsCode) {
        this.paymentDetailsCode = paymentDetailsCode;
    }

    /**
     * @return the paymentMethodText
     */
    public String getPaymentMethodText() {
        return paymentMethodText;
    }

    /**
     * @param paymentMethodText the paymentMethodText to set
     */
    public void setPaymentMethodText(String paymentMethodText) {
        this.paymentMethodText = paymentMethodText;
    }

    /**
     * @return the planable
     */
    public boolean isPaymentPlan() {
        return paymentPlan;
    }

    /**
     * @param planable the planable to set
     */
    public void setPaymentPlan(boolean planable) {
        this.paymentPlan = planable;
    }

    public boolean isDefaultPaymentType() {
        return defaultPaymentType;
    }

    public void setDefaultPaymentType(boolean defaultPaymentType) {
        this.defaultPaymentType = defaultPaymentType;
    }

    /**
     * @return the paymentFrequencyCode
     */
    public String getPaymentFrequencyCode() {
        return paymentFrequencyCode;
    }

    /**
     * @param paymentFrequencyCode the paymentFrequencyCode to set
     */
    public void setPaymentFrequencyCode(String paymentFrequencyCode) {
        this.paymentFrequencyCode = paymentFrequencyCode;
    }

    /**
     * @return the paymentFrequencyText
     */
    public String getPaymentFrequencyText() {
        return paymentFrequencyText;
    }

    /**
     * @param paymentFrequencyText the paymentFrequencyText to set
     */
    public void setPaymentFrequencyText(String paymentFrequencyText) {
        this.paymentFrequencyText = paymentFrequencyText;
    }

    public String getFacilityCode() {
        return facilityCode;
    }

    public void setFacilityCode(String facilityCode) {
        this.facilityCode = facilityCode;
    }

    public String getDayType() {
        return dayType;
    }

    public void setDayType(String dayType) {
        this.dayType = dayType;
    }

    public String getPaymentMethodCode() {
        return paymentMethodCode;
    }

    public void setPaymentMethodCode(String paymentMethodCode) {
        this.paymentMethodCode = paymentMethodCode;
    }

    public Integer getEarliestStartDateDays() {
        return earliestStartDateDays;
    }

    public void setEarliestStartDateDays(Integer earliestStartDateDays) {
        this.earliestStartDateDays = earliestStartDateDays;
    }

    public Integer getLatestStartDateDays() {
        return latestStartDateDays;
    }

    public void setLatestStartDateDays(Integer latestStartDateDays) {
        this.latestStartDateDays = latestStartDateDays;
    }

    public String getScheduleFreqCode() {
        return scheduleFreqCode;
    }

    public void setScheduleFreqCode(String scheduleFreqCode) {
        this.scheduleFreqCode = scheduleFreqCode;
    }

    public Integer getPaymentMethodOrder() {
        return paymentMethodOrder;
    }

    public void setPaymentMethodOrder(Integer paymentMethodOrder) {
        this.paymentMethodOrder = paymentMethodOrder;
    }

    public Integer getPaymentFrequencyOrder() {
        return paymentFrequencyOrder;
    }

    public void setPaymentFrequencyOrder(Integer paymentFrequencyOrder) {
        this.paymentFrequencyOrder = paymentFrequencyOrder;
    }

    public String getHoverOverText() {
        return hoverOverText;
    }

    public void setHoverOverText(String hoverOverText) {
        this.hoverOverText = hoverOverText;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(final Integer brandId) {
        this.brandId = brandId;
    }
}
