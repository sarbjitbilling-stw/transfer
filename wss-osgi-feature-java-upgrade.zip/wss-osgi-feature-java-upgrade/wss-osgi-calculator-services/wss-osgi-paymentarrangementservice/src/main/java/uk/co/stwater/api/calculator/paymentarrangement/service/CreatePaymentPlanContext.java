package uk.co.stwater.api.calculator.paymentarrangement.service;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

public class CreatePaymentPlanContext {

    private TargetAccountNumber accountNumber;

    private Long legalEntityId;

    private boolean hasPendingDirectDebitPayment;

    private String brandId;

    public CreatePaymentPlanContext(TargetAccountNumber accountNumber, Long legalEntityId, String brandId) {
        super();
        this.accountNumber = accountNumber;
        this.legalEntityId = legalEntityId;
        this.brandId = brandId;
    }

    public TargetAccountNumber getAccountNumber() {
        return accountNumber;
    }

    public Long getLegalEntityId() {
        return legalEntityId;
    }

    public boolean isHasPendingDirectDebitPayment() {
        return hasPendingDirectDebitPayment;
    }

    public void setHasPendingDirectDebitPayment(boolean hasPendingDirectDebitPayment) {
        this.hasPendingDirectDebitPayment = hasPendingDirectDebitPayment;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(final String brandId) {
        this.brandId = brandId;
    }
}
