/**
 *
 */
package uk.co.stwater.api.calculator.paymentarrangement.service;

import static uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory.PAYMENT_METHOD_SERVICES;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.common.ErrorDto;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.util.AbstractResource;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.ServiceStatus;

/**
 * @author DRoberts
 */
@Path("/paymentmethod")
@Named("paymentArrangementRestResource")
public class PaymentMethodRestResource extends AbstractResource {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Inject
    private PaymentMethodService paymentMethodService;

    @GET
    @Path("/{legalEntity}/{accountnumber}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPaymentArrangements(@Context HttpServletRequest request,
                                           @PathParam("legalEntity") String legalEntity, @PathParam("accountnumber") TargetAccountNumber accountnumber,
                                           @QueryParam("channel") String channel, @QueryParam("runChecks") String runChecks,
                                           @QueryParam("brand") String brandId) {

        try {
            log.debug("getPaymentArrangements starting");
            log.debug("legalentity:{}", legalEntity);
            log.debug("accountNumber:{}", accountnumber);
            log.debug("channel:{}", channel);

            boolean applyChecks = false;

            if (null != runChecks && runChecks.equalsIgnoreCase("Y")) {
                applyChecks = true;
            }

            Long theLegalEntityNumber = Long.valueOf(legalEntity);

            CreatePaymentPlanContext ctx = new CreatePaymentPlanContext(accountnumber, theLegalEntityNumber, brandId);

            GenericEntity<List<PaymentMethod>> entity;
            List<PaymentMethod> methods = paymentMethodService.getAvailablePaymentArrangements(ctx, channel, applyChecks,
                    getUserIdentity().getUsername());
            entity = new GenericEntity<List<PaymentMethod>>(methods) {
            };

            log.debug("getPaymentArrangements finished");

            return Response.status(Response.Status.OK).entity(entity).build();
        } catch (STWTechnicalException e) {
            ErrorDto errorDto = new ErrorDto(PAYMENT_METHOD_SERVICES, 100, e.getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        } catch (ServiceException se) {
            ErrorDto errorDto = new ErrorDto(PAYMENT_METHOD_SERVICES, se.getCode().getCode(), se.getCode().getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(errorDto).build();
        }
    }

    @Override
    protected ServiceStatus getServiceStatus() {
        ServiceStatus status = super.getServiceStatus();
        status.addDependencyStatus("paymentMethodService", paymentMethodService != null);
        return status;
    }

}
