package uk.co.stwater.api.calculator.paymentarrangement.service;

import org.apache.commons.collections.Transformer;

import uk.co.stwater.api.calculator.paymentarrangement.entity.PaymentMethodEntity;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;

/**
 * Transformer class - moves data between the persistent entity and the
 * resource/domain object.
 * 
 * @author droberts
 *
 */

public class PaymentMethodTransformer implements Transformer {

	@Override
	public Object transform(Object thePaymentMethodEntity) {

		PaymentMethod paymentMethod = null;
		if (null != thePaymentMethodEntity && thePaymentMethodEntity instanceof PaymentMethodEntity) {
			paymentMethod = new PaymentMethod();

			PaymentMethodEntity thePaymentMethod = (PaymentMethodEntity) thePaymentMethodEntity;

			paymentMethod.setPaymentMethodCode(thePaymentMethod.getPaymentMethodCode());
			paymentMethod.setPaymentFrequencyCode(thePaymentMethod.getPaymentFrequencyCode());
			paymentMethod.setPaymentMethodText(thePaymentMethod.getPaymentMethodText());
			paymentMethod.setPaymentFrequencyText(thePaymentMethod.getPaymentFrequencyText());
			paymentMethod.setDefaultPaymentType(thePaymentMethod.isDefaultPaymentType());
			paymentMethod.setScheduleFreqCode(thePaymentMethod.getScheduleFreqCode());
			paymentMethod.setPlan(thePaymentMethod.isPaymentPlan());
			paymentMethod.setFacilityCode(thePaymentMethod.getFacilityCode());
			paymentMethod.setDayType(thePaymentMethod.getDayType());
			paymentMethod.setPaymentMethodOrder(thePaymentMethod.getPaymentMethodOrder());
			paymentMethod.setPaymentFrequencyOrder(thePaymentMethod.getPaymentFrequencyOrder());
			paymentMethod.setHoverOverText(thePaymentMethod.getHoverOverText());

		}

		return paymentMethod;
	}

}
