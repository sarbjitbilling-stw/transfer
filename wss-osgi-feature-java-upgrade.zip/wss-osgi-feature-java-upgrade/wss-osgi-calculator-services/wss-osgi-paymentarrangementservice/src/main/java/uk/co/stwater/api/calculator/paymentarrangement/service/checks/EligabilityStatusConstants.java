package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

public interface EligabilityStatusConstants {

    Integer ELIGIBLE = 1;
    Integer ELIGIBLE_AGENT_WARNING = 2;
    Integer NOT_ELIGIBLE_BUT_MODEL = 3;
    Integer NOT_ELIGIBLE = 4;

    String ARREARS_PAYMENT_PLAN_NOT_ALLOWED = "Cannot offer an arrears payment plan due to the account balance being zero or in credit";
    String HD_NON_HOUSEHOLD_ASSESSED_NOT_ALLOWED = "HD Non-Household account is Assessed - Please drop to Target to create payment arrangement";
}
