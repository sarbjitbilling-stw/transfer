package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.inject.Named;
import javax.inject.Singleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.common.ErrorDto.ErrorCategory;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

@Named
@Singleton
public class AccountInDebtCheck implements EligiblityCheck {
	static final String UNMEASURED_FUTURE_START_MESSAGE = "Customer has no arrears so plan will start with their annual bill in April";

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
			List<Property> propertyList, String channel,
			Map<String, List<SpecialConditionRestriction>> specialConditionsMap, CreatePaymentPlanContext ctx) {

		if (null == accountSummary) {
			throw new IllegalArgumentException("accountSummary is a required parameter");
		}

		if (null == propertyList) {
			throw new IllegalArgumentException("propertyList is a required parameter");
		}

		EligibilityStatus status = new EligibilityStatus();
		status.setStatus(EligabilityStatusConstants.ELIGIBLE);

		if (method.isPlan()) {

			log.debug("PaymentMethod.isPlan == true");
			BigDecimal accountBalance = accountSummary.getAccountBalance();

			if (hasUnmeasuredProperty(propertyList) && accountBalance.signum() <= 0) {

				log.debug("Customer has no arears!");
				log.debug("hasUnmeasuredProperty==true , accountBalance:{}", accountBalance);
				status.setStatus(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING);
				status.setText(UNMEASURED_FUTURE_START_MESSAGE);
			}
		}

		return status;
	}

	private boolean hasUnmeasuredProperty(List<Property> propertyList) {
		boolean isUnmeasured = false;

		// used for checking that we don't have dodgy data coming back from
		// Target - there shouldn't be a situation with active different supply
		// types.
		int activeNotUnmeasuredPropertyCount = 0;
		int activeUnmeasuredPropertyCount = 0;

		for (Property property : propertyList) {
			// check status first as we are only interested in active properties
			if (property.isActive()) {
				if (property.isUnmeasured()) {
					isUnmeasured = true;
					activeUnmeasuredPropertyCount++;
				} else {
					activeNotUnmeasuredPropertyCount++;
				}
			}

		}

		if (activeNotUnmeasuredPropertyCount > 0 && activeUnmeasuredPropertyCount > 0) {
			throw new STWBusinessException(EligibilityErrors.MULTIPLE_ACTIVE_SUPPLIES_DIFF_TYPES.getMessage(),
					EligibilityErrors.MULTIPLE_ACTIVE_SUPPLIES_DIFF_TYPES.getCode(),
					ErrorCategory.PAYMENT_METHOD_SERVICES);
		}

		return isUnmeasured;
	}

}
