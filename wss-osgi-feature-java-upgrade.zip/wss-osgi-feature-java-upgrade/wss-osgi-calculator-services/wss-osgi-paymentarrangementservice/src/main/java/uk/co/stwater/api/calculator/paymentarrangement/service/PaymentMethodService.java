/**
 *
 */
package uk.co.stwater.api.calculator.paymentarrangement.service;

import uk.co.stwater.api.core.service.Service;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;

import java.util.List;

/**
 * @author DRoberts
 */
public interface PaymentMethodService extends Service {

    /**
     * Provides a tailed list of payment methods according to the customer data
     * passed in and the business rules being applied to that data.
     *
     * @param accountNumber The unique account number.
     * @param channel       The channel (Web or Agent).
     * @param legalEntity   The legal entity for the account.
     * @return Returns a list of PaymentMethod objects with the status
     * representing the application of the business rules.
     * @throws ServiceException
     */
    public List<PaymentMethod> getAvailablePaymentArrangements(CreatePaymentPlanContext ctx, String channel, boolean applyChecks, String authToken)
            throws ServiceException;

    public PaymentMethod lookupPaymentMethod(String paymentMethod, String frequency, String brandId);
}
