package uk.co.stwater.api.calculator.paymentarrangement.service;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.ops4j.pax.cdi.api.OsgiService;

import uk.co.stwater.api.calculator.paymentarrangement.service.checks.AccountInDebtCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.ActiveSupplyCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.BdsCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.CreateSpecialConditionsCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.DeleteSpecialConditionsCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.DirectDebitCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.EligiblityCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.HdAssessedCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.POCBCreateSpecialConditionsCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.PaperlessCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.PendingBillTriggersCheck;
import uk.co.stwater.api.osgi.util.feature.FeatureService;

/**
 * @author droberts
 */
@Named
public class BusinessCheckFactoryImpl implements BusinessCheckFactory {

    @Inject
    private AccountInDebtCheck accountInDebtCheck;

    @Inject
    private PendingBillTriggersCheck pendingBillTriggersCheck;

    @Inject
    private BdsCheck bdsCheck;

    @Inject
    @OsgiService
    private FeatureService featureService;

    @Override
    public List<EligiblityCheck> getChecks(boolean hasExistingPlans) {

        List<EligiblityCheck> checkList = new ArrayList<>();

        checkList.add(new ActiveSupplyCheck());
        // needs to be run before AccountInDebtCheck so that it's eligibility messages
        // have higher precedence
        checkList.add(pendingBillTriggersCheck);
        checkList.add(accountInDebtCheck);
        checkList.add(new HdAssessedCheck());
        checkList.add(new PaperlessCheck());
        checkList.add(new DirectDebitCheck());
        // appears before special condition checks to give its messages priority
        checkList.add(bdsCheck);
        if (hasExistingPlans) {
            checkList.add(new DeleteSpecialConditionsCheck());
        }
        checkList.add(new CreateSpecialConditionsCheck());
        checkList.add(new POCBCreateSpecialConditionsCheck());
        return checkList;
    }

}
