package uk.co.stwater.api.calculator.paymentarrangement.service;

import java.util.List;

import uk.co.stwater.api.calculator.paymentarrangement.service.checks.EligiblityCheck;

/**
 * Factory responsible for creating the list of EligibilityChecks.
 * @author droberts
 *
 */
public interface BusinessCheckFactory {

	/**
	 * 
	 * @return Returns a list of ELigibilityChecks.
	 */
	public List<EligiblityCheck> getChecks(boolean hasExistingPlans);

}
