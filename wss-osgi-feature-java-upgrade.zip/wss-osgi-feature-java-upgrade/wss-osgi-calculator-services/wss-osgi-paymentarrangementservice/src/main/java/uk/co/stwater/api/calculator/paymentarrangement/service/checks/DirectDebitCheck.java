package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.util.List;
import java.util.Map;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

public class DirectDebitCheck implements EligiblityCheck {

	@Override
	public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
			List<Property> propertyList, String channel,
			Map<String, List<SpecialConditionRestriction>> specialConditions, CreatePaymentPlanContext ctx) {
		EligibilityStatus status = new EligibilityStatus();
		status.setStatus(EligabilityStatusConstants.ELIGIBLE);

		if (ctx.isHasPendingDirectDebitPayment()) {
			status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE_BUT_MODEL);
			status.setText(
					"Direct Debit is due within 5 working days, so new payment arrangement cannot be set up. Advise customer to cancel payment with bank");
		}

		return status;
	}

}
