package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTypeConstants;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.feature.Feature;
import uk.co.stwater.api.osgi.util.feature.FeatureService;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

/**
 * Ensures that for BDS (Big Difference Scheme) accounts only monthly direct
 * debit and monthly watercard payment options are eligible.
 * 
 * <p>
 * Provides warning and error messages when an account's BDS special condition
 * is expiring soon.
 */
@Named
public class BdsCheck implements EligiblityCheck {
    private static final Logger LOG = LoggerFactory.getLogger(BdsCheck.class);

    static final String BDS_ACCOUNT_SPECIAL_CONDITION = "SOCIALTAR";
    static final String BDS_ACCOUNT_WARNING = "Please be aware this is a BDS Account. A BDS Payment plan can be set up on the next screen, but if you need any assistance please contact the CAT team.";
    static final String BDS_PLANS_BLOCKED_ERROR = "Please be aware this is a BDS Account. Please contact the CAT team for assistance in creating a Payment Plan";
    static final String BDS_INVALID_PAYMENT_METHOD_ERROR = "BDS can only use Monthly Direct Debit or Monthly Watercard";
    static final String BDS_RENEWAL_SOON_WARNING = "Customers BDS Renewal is due soon. Advise customer they will shortly hear from us.";
    static final String BDS_EXPIRING_SOON_ERROR = "Customers BDS Special Condition expires within 4 weeks. Please advise the customer that a new payment plan will be set up in 4 week.";

    static final int EXPIRY_ERROR_WEEKS = 4;
    static final int RENEWAL_WARNING_WEEKS = 8;

    private enum BdsStatus {
        INELIGIBLE, ENDING_IN_4_WEEKS, ENDING_IN_8_WEEKS, ELIGIBLE;
    }

    @Inject
    @OsgiService
    private FeatureService featureService;

    @Override
    public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
            List<Property> propertyList, String channel,
            Map<String, List<SpecialConditionRestriction>> specialConditions, CreatePaymentPlanContext ctx) {

        EligibilityStatus status = new EligibilityStatus();
        status.setStatus(EligabilityStatusConstants.ELIGIBLE);

        BdsStatus bdsStatus = getBdsStatus(specialConditions);

        if (bdsStatus != BdsStatus.INELIGIBLE) {
            if (!featureService.isActive(Feature.BDS_PAYMENT_PLAN)) {
                LOG.trace("BDS payment plans are not active");
                status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
                status.setText(BDS_PLANS_BLOCKED_ERROR);
            } else {
                LOG.trace("Target account {} is eligible for BDS payment plans", accountSummary.getAccountNumber());
                if (isValidBdsPaymentMethod(method)) {
                    if (bdsStatus == BdsStatus.ELIGIBLE) {
                        status.setStatus(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING);
                        status.setText(BDS_ACCOUNT_WARNING);
                    } else if (bdsStatus == BdsStatus.ENDING_IN_8_WEEKS) {
                        LOG.trace("Target account {} is eligible for BDS payment plans, but renewal is due soon",
                                accountSummary.getAccountNumber());
                        status.setStatus(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING);
                        status.setText(BDS_RENEWAL_SOON_WARNING);
                    } else if (bdsStatus == BdsStatus.ENDING_IN_4_WEEKS) {
                        LOG.trace("Target account {} BDS special condition is expiring soon",
                                accountSummary.getAccountNumber());
                        status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
                        status.setText(BDS_EXPIRING_SOON_ERROR);
                    } else {
                        // should never reach this line
                        throw new STWTechnicalException(String.format("Unrecognised account BDS status %s", bdsStatus));
                    }
                } else {
                    status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
                    status.setText(BDS_INVALID_PAYMENT_METHOD_ERROR);
                }
            }
        }

        return status;
    }

    /**
     * @see #getBdsStatus(List)
     */
    private BdsStatus getBdsStatus(Map<String, List<SpecialConditionRestriction>> specialConditionsMap) {
        List<SpecialConditionRestriction> specialConditionsList = new ArrayList<>();

        List<SpecialConditionRestriction> allKeySpecialConditions = specialConditionsMap
                .get(SpecialConditionsContants.ALL_KEY);

        if (allKeySpecialConditions != null) {
            specialConditionsList.addAll(allKeySpecialConditions);
        }

        // @formatter:off
        List<SpecialConditionRestriction> bdsSpecialConditions = specialConditionsList.stream()
                .filter(specialCondition -> BDS_ACCOUNT_SPECIAL_CONDITION.equals(specialCondition.getTypeName()))
                .collect(Collectors.toList());
        // @formatter:on

        return getBdsStatus(bdsSpecialConditions);
    }

    /**
     * Gets the eligibility of an account for a BDS payment plan based on the
     * accounts special conditions.
     * 
     * <p>
     * If an account has multiple BDS special conditions then the one with the
     * latest end is used to decide on the eligibility state for BDS payment plans.
     * A null end date means the special condition does not end at the moment.
     * 
     * <p>
     * Based on the BDS special condition end date latest end date either a
     * eligible, renewal or expiry messages will be displayed.
     */
    private BdsStatus getBdsStatus(List<SpecialConditionRestriction> specialConditions) {
        if (CollectionUtils.isEmpty(specialConditions)) {
            return BdsStatus.INELIGIBLE;
        }

        // @formatter:off
        LocalDate latestStartDate = specialConditions.stream()
                .map(SpecialConditionRestriction::getStartDate)
                .filter(Objects::nonNull)
                .max(Comparator.naturalOrder())
                .orElseThrow(() -> new STWTechnicalException("Latest BDS special condition start date not found"));
        // @formatter:on
        
        // BDS special condition end date is calculated as one year after the start date
        LocalDate latestEndDate = latestStartDate.plusYears(1);

        LocalDate now = getCurrentDate();
        LocalDate renewalWarnDate = now.plusWeeks(RENEWAL_WARNING_WEEKS);
        LocalDate expiryErrorDate = now.plusWeeks(EXPIRY_ERROR_WEEKS);
        if (latestEndDate.isAfter(renewalWarnDate)) {
            return BdsStatus.ELIGIBLE;
        } else if (latestEndDate.isAfter(expiryErrorDate)) {
            return BdsStatus.ENDING_IN_8_WEEKS;
        } else {
            return BdsStatus.ENDING_IN_4_WEEKS;
        }
    }

    private boolean isValidBdsPaymentMethod(PaymentMethod method) {
        boolean isDirectDebit = PaymentMethodTypeConstants.DIRECT_DEBIT.equals(method.getPaymentMethodCode());
        boolean isWatercard = PaymentMethodTypeConstants.PAYMENT_METHOD_WATERCARD.equals(method.getPaymentMethodCode());
        boolean isMonthly = PaymentMethodTypeConstants.PAYMENT_FREQUENCY_MONTHLY
                .equals(method.getPaymentFrequencyCode());

        return isMonthly && (isDirectDebit || isWatercard);
    }

    LocalDate getCurrentDate() {
        return LocalDate.now();
    }
}
