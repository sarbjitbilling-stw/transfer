package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.calculator.offers.MeasuredIndicator;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

public class HdAssessedCheck implements EligiblityCheck {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    public EligibilityStatus checkStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
                                         List<Property> propertyList, String channel,
                                         Map<String, List<SpecialConditionRestriction>> specialConditionsMap, CreatePaymentPlanContext ctx) {

        if (null == accountSummary) {
            throw new IllegalArgumentException("accountSummary is a required parameter");
        }

        if (null == propertyList) {
            throw new IllegalArgumentException("propertyList is a required parameter");
        }

        EligibilityStatus status = new EligibilityStatus();
        status.setStatus(EligabilityStatusConstants.ELIGIBLE);

        if (method.isPlan() && ctx.getBrandId().equalsIgnoreCase(AccountBrand.HD_NON_HOUSE_HOLD.getAccountBrand())
                && isAllActivePropertiesAsssessed(propertyList)) {
            log.debug("Assessed Property - HD Non-Household Customer - AccountBrand = {}", ctx.getBrandId());
            status.setStatus(EligabilityStatusConstants.NOT_ELIGIBLE);
            status.setText(EligabilityStatusConstants.HD_NON_HOUSEHOLD_ASSESSED_NOT_ALLOWED);
        }

        return status;
    }

    private boolean isAllActivePropertiesAsssessed(List<Property> propertyList) {
        List<Property> activePropertyList = getCurrentAndFutureActiveProperties(propertyList);
        return CollectionUtils.isNotEmpty(activePropertyList) && hasSameServices(MeasuredIndicator.ASSESSED.getTargetCode(), activePropertyList);
    }

    /**
     * Active Property has endDate = null;
     */
    private List<Property> getCurrentAndFutureActiveProperties(final List<Property> propertyList) {
        if (CollectionUtils.isEmpty(propertyList)) {
            return new ArrayList<>();
        }
        return propertyList.stream().filter(property -> property.getEndDate() == null).collect(Collectors.toList());
    }

    private boolean hasSameServices(String serviceType, List<Property> propertyList) {
        return propertyList.stream()
                .allMatch(property -> property.getMeasuredIndicator().getCode().equalsIgnoreCase(serviceType));
    }

}
