/**
 *
 */
package uk.co.stwater.api.calculator.paymentarrangement.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.drools.core.util.StringUtils;
import org.ops4j.pax.cdi.api.OsgiService;
import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.paymentarrangement.dao.PaymentMethodDao;
import uk.co.stwater.api.calculator.paymentarrangement.entity.PaymentMethodEntity;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.AccountInDebtCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.EligabilityStatusConstants;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.EligibilityStatus;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.EligiblityCheck;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.SpecialConditionsContants;
import uk.co.stwater.api.core.error.ErrorCode;
import uk.co.stwater.api.core.service.BaseService;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.AccountBrand;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialCondition;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.util.STWBusinessException;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionChannel;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.iib.client.api.date.DateClient;
import uk.co.stwater.iib.client.api.directdebit.check.DirectDebitCheckClient;
import uk.co.stwater.iib.client.api.directdebit.check.DirectDebitCheckResponse;
import uk.co.stwater.iib.client.api.paymentplan.check.CheckActivePaymentPlansClient;
import uk.co.stwater.iib.client.api.paymentplan.check.CheckActivePaymentPlansResponse;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;

/**
 * @author DRoberts
 * <p>
 * Implementation of the PaymentMethodServiceInterface. PaymentMethods
 * are stored in the WSS database and then business rules applied, using
 * customer information as input to the decision making process.
 */

@OsgiServiceProvider(classes = {PaymentMethodService.class})
@Named
@Transactional
@Singleton
public class PaymentMethodServiceImpl extends BaseService implements PaymentMethodService {

    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String PAYMENT_STATUS_ACTIVE = "A";
    private static final String PAYMENT_STATUS_PENDING = "P";

    public static final ErrorCode INVALID_BRAND = new ErrorCode("PAYMT001", "Invalid Brand");

	private static final String DAY_TYPE_MONTH = "1";

    @Inject
    private PaymentMethodDao paymentMethodDao;

    @Inject
    private BusinessCheckFactory businessCheckFactory;

    @OsgiService
    @Inject
    private GetAccountSummaryClient getAccountSummaryClient;

    @OsgiService
    @Inject
    private GetPropertiesForAccountNumberClient propertiesService;

    @OsgiService
    @Inject
    private SpecialConditionService specialConditionsService;

    @OsgiService
    @Inject
    private DateClient dateService;

    @OsgiService
    @Inject
    private DirectDebitCheckClient directDebitCheckClient;

    @Inject
    @OsgiService
    private CheckActivePaymentPlansClient checkActivePaymentPlansClient;

    @Inject
    private AccountInDebtCheck accountInDebtCheck;

    private PaymentMethodTransformer transformer;

    public PaymentMethodServiceImpl() {
        super();
        transformer = new PaymentMethodTransformer();
    }

    @Override
    public List<PaymentMethod> getAvailablePaymentArrangements(CreatePaymentPlanContext ctx, String channel,
                                                               boolean applyChecks,
                                                               String authToken) throws ServiceException {

        if (log.isDebugEnabled()) {
            log.debug("getAvailablePaymentArrangements:applyChecks:{}", applyChecks);
        }

        List<PaymentMethod> paymentMethodList = new ArrayList<>();

        validateBrand(ctx.getBrandId());
        List<PaymentMethodEntity> thePaymentMethodList = paymentMethodDao.findActivePaymentMethods(ctx.getBrandId());

        // SOAP call not authToken required.
        AccountSummaryResponse accountDetails = getAccountDetails(ctx.getLegalEntityId(), ctx.getAccountNumber());

        boolean hasExistingPlans = hasExistingPlans(ctx.getAccountNumber(), authToken);

        List<Property> propertyList = getPropertyDetails(ctx.getAccountNumber(), authToken);

        LocalDate targetDate = dateService.getTargetDate(authToken);
        LocalDate futureHomeMoveInDate = getFutureHomeMoveInDate(targetDate, propertyList);

        DirectDebitCheckResponse checkDirectDebitSent = directDebitCheckClient.checkDirectDebit(ctx.getAccountNumber(), authToken);

        ctx.setHasPendingDirectDebitPayment(checkDirectDebitSent.isSent());

        // SOAP calls not authToken required
        Map<String, List<SpecialConditionRestriction>> specialConditionsMap = getSpecialConditions(
                ctx.getAccountNumber(), channel, authToken);

        for (PaymentMethodEntity paymentMethodEntity : thePaymentMethodList) {
            PaymentMethod paymentMethod = (PaymentMethod) transformer.transform(paymentMethodEntity);

            if (null != targetDate) {

                paymentMethod.setTargetDate(targetDate);
                LocalDate baseDate = futureHomeMoveInDate != null ? futureHomeMoveInDate : targetDate;

                if (null != paymentMethodEntity.getEarliestStartDateDays()) {
                    // using Target's date to allow payments before the move in date
                    LocalDate earliestStartDate = addDays(targetDate, paymentMethodEntity.getEarliestStartDateDays(),
                            paymentMethodEntity.getDayType());
                    paymentMethod.setEarliestStartDate(earliestStartDate);
                }
                if (null != paymentMethodEntity.getLatestStartDateDays()) {
                    paymentMethod.setLatestStartDate(addDays(baseDate, paymentMethodEntity.getLatestStartDateDays(),
                            paymentMethodEntity.getDayType()));
                }
            } else {
                log.error("Could not set earliest and latest start dates as targetDate is null");
            }

            if (applyChecks) {
                if (targetDate == null) {
                    throw new STWBusinessException("Unable to perform eligibility checks as Target date is null");
                }
                performEligibilityChecks(targetDate, paymentMethod, accountDetails, propertyList, channel, ctx,
                        hasExistingPlans, specialConditionsMap);
            }

            paymentMethodList.add(paymentMethod);
        }

        // now apply the customer / account / property specific rules to the
        // list of payment methods.

        return paymentMethodList;
    }

    public void validateBrand(String brandId) throws ServiceException {
        if (!AccountBrand.isValidBrand(brandId)) throw new ServiceException(INVALID_BRAND);
    }

    @Override
    public PaymentMethod lookupPaymentMethod(String paymentMethod, String frequency, String brandId) {
        log.debug("lookupPaymentMethod start");
        log.debug("paymentMethod:{} / frequency:{}", paymentMethod, frequency);
        PaymentMethod method = null;

        PaymentMethodEntity thePaymentMethod = paymentMethodDao.findActivePaymentMethod(paymentMethod, frequency, brandId);

        if (null != thePaymentMethod) {
            method = (PaymentMethod) transformer.transform(thePaymentMethod);

        }

        if (method != null) {
            log.debug("paymentMethodCode:{} / methodText:{}", method.getPaymentMethodCode(),
                    method.getPaymentMethodText());
        } else {
            log.debug("paymentMethod is null");
        }
        log.debug("lookupPaymentMethod end");

        return method;
    }

    private void performEligibilityChecks(LocalDate targetDate, PaymentMethod paymentMethod,
            AccountSummaryResponse accountSummary, List<Property> propertyList, String channel,
            CreatePaymentPlanContext context, boolean hasExistingPlans,
            Map<String, List<SpecialConditionRestriction>> specialConditionsMap) {

        EligibilityStatus status = getEligibilityStatus(paymentMethod, accountSummary, propertyList, channel, context,
                hasExistingPlans, specialConditionsMap);

        // check is done here again as status object will only hold the highest priority
        // message and do not want to overwrite an error/non-eligible message
        if (status.isEligibleOrWarning()) {
            EligibilityStatus accountInDebtCheckEligStatus = accountInDebtCheck.checkStatus(paymentMethod,
                    accountSummary, propertyList, channel, specialConditionsMap, context);

            // if account has no debt
            if (EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING.equals(accountInDebtCheckEligStatus.getStatus())) {
                status = accountInDebtCheckEligStatus;

                int futurePlanStartYear;
                if (targetDate.isBefore(LocalDate.of(targetDate.getYear(), Month.APRIL, 1))) {
                    futurePlanStartYear = targetDate.getYear();
                } else {
                    futurePlanStartYear = targetDate.getYear() + 1;
                }

                // overwrite payment dates with future payment plan dates
                YearMonth startDateMonth = YearMonth.of(futurePlanStartYear, Month.APRIL);
                paymentMethod.setEarliestStartDate(startDateMonth.atDay(1));
                paymentMethod.setLatestStartDate(startDateMonth.atEndOfMonth());
            }
        }

        paymentMethod.setEligible(status.getStatus());
        paymentMethod.setEligibleText(status.getText());
    }

    /**
     * Performs eligibility checks and returns the {@link EligibilityStatus} for the
     * highest severity from the checks performed.
     * 
     * <p>
     * <font color="red"><b>Warning</b>: this means that eligibility error/warning
     * messages will be suppressed if more than one exists. The error/warning
     * message that will be returned will be the one with the highest severity, if
     * multiple exist with the same severity then the one that was the result of the
     * earliest check will be returned.</font>
     */
    private EligibilityStatus getEligibilityStatus(PaymentMethod method, AccountSummaryResponse accountSummary,
            List<Property> propertyList, String channel, CreatePaymentPlanContext context, boolean hasExistingPlans,
            Map<String, List<SpecialConditionRestriction>> specialConditionsMap) {
        EligibilityStatus resultStatus = new EligibilityStatus();
        resultStatus.setStatus(EligabilityStatusConstants.ELIGIBLE);

        List<EligiblityCheck> checkList = businessCheckFactory.getChecks(hasExistingPlans);

        for (EligiblityCheck eligiblityCheck : checkList) {
            EligibilityStatus checkStatus = eligiblityCheck.checkStatus(method, accountSummary, propertyList, channel,
                    specialConditionsMap, context);

            // give preference to higher severity check messages
            if (checkStatus.isHigherThan(resultStatus)) {
                resultStatus = checkStatus;
            }

            if (resultStatus.isHighest()) {
                // no need to continue fail fast
                break;
            }
        }

        return resultStatus;
    }

    private boolean hasExistingPlans(TargetAccountNumber accountNumber, String authToken) {
        boolean hasPlans = false;
        List<CheckActivePaymentPlansResponse> paymentPlanList = checkActivePaymentPlansClient
                .getPaymentPlansForAccount(accountNumber, authToken);

        hasPlans = paymentPlanList.stream()
                .anyMatch(plan -> PAYMENT_STATUS_ACTIVE.equalsIgnoreCase(plan.getPayPlanStatus())
                        || PAYMENT_STATUS_PENDING.equalsIgnoreCase(plan.getPayPlanStatus()));

        return hasPlans;
    }

    private Map<String, List<SpecialConditionRestriction>> getSpecialConditions(TargetAccountNumber accountNumber,
                                                                                String channelName, String authToken) {

        Map<String, List<SpecialConditionRestriction>> specialConditionsList = new HashMap<>();

        // Only call target once
        List<SpecialCondition> specialConditions = specialConditionsService.getSpecialConditions(accountNumber, StringUtils.EMPTY, Optional.ofNullable(authToken));

        List<SpecialConditionRestriction> specialConditionsRestrictions = specialConditions.stream()
                .map(SpecialConditionRestriction::new).collect(Collectors.toList());
        specialConditionsList.put(SpecialConditionsContants.ALL_KEY, specialConditionsRestrictions);

        if (specialConditions.isEmpty())
            return specialConditionsList;

        List<SpecialConditionRestriction> createSpecialConditions = specialConditionsService.checkSpecialConditions(
                specialConditions, SpecialConditionChannel.byName(channelName),
                SpecialConditionAction.PAYMENT_PLAN_CREATE);

        specialConditionsList.put(SpecialConditionsContants.CREATE_KEY, createSpecialConditions);

        List<SpecialConditionRestriction> deleteSpecialConditions = specialConditionsService.checkSpecialConditions(
                specialConditions, SpecialConditionChannel.byName(channelName),
                SpecialConditionAction.PAYMENT_PLAN_DELETE);

        specialConditionsList.put(SpecialConditionsContants.DELETE_KEY, deleteSpecialConditions);

        List<SpecialConditionRestriction> createPCOBSpecialConditions = specialConditionsService.checkSpecialConditions(
                specialConditions, SpecialConditionChannel.byName(channelName),
                SpecialConditionAction.PAYMENT_PLAN_CREATE_POCB);

        specialConditionsList.put(SpecialConditionsContants.CREATE_POCB_KEY, createPCOBSpecialConditions);

        return specialConditionsList;
    }

    private AccountSummaryResponse getAccountDetails(Long legalEntityNumber, TargetAccountNumber accountNumber) {

        AccountSummaryResponse accountDetails = getAccountSummaryClient.getAccountSummary(accountNumber, legalEntityNumber);

        return accountDetails;
    }

    private List<Property> getPropertyDetails(TargetAccountNumber accountNumber, String authToken) {

        List<Property> properties = propertiesService.getPropertiesForAccountNumber(accountNumber, authToken);
        return properties;

    }

    private void invoiceCustomer() {

    }

    private LocalDate addDays(LocalDate targetDate, Integer numberOfDays, String dayType) {

        LocalDate newDate = targetDate.plusDays(numberOfDays);

		if (StringUtils.isEmpty(dayType) || !DAY_TYPE_MONTH.equalsIgnoreCase(dayType)) {
			if (newDate.getDayOfWeek().getValue() == DayOfWeek.SATURDAY.getValue()) {
				// roll forward from Saturday to Monday
				newDate = newDate.plusDays(2);
			} else if (newDate.getDayOfWeek().getValue() == DayOfWeek.SUNDAY.getValue()) {
				// rolled forward from Sunday to Monday
				newDate = newDate.plusDays(1);
			}
		}

        return newDate;

    }

    private LocalDate getFutureHomeMoveInDate(final LocalDate targetDate, final List<Property> propertyList) {
        if (CollectionUtils.isEmpty(propertyList)) {
            return null;
        }

        LocalDate futureHomeMoveInDate = null;

        // get the latest startdate of current or future active property
        // Active Property have EndDate = null
        Optional<Property> activePropertyOptional = propertyList.stream()
                .filter(property -> property.getEndDate() == null
                ).max(Comparator.comparing(Property::getStartDate));

        if (activePropertyOptional.isPresent()) {
            futureHomeMoveInDate = activePropertyOptional.get().getStartDate();
        }

        return futureHomeMoveInDate != null && futureHomeMoveInDate.isAfter(targetDate) ? futureHomeMoveInDate : null;
    }


}
