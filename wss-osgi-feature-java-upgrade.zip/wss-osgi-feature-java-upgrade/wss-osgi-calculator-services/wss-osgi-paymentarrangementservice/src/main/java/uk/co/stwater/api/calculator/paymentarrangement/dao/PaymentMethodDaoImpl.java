/**
 *
 */
package uk.co.stwater.api.calculator.paymentarrangement.dao;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.co.stwater.api.calculator.paymentarrangement.entity.PaymentMethodEntity;
import uk.co.stwater.api.core.dao.AbstractCrudDao;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

/**
 * @author DRoberts
 */
@OsgiServiceProvider(classes = {PaymentMethodDao.class})
@Transactional
@Named
public class PaymentMethodDaoImpl extends AbstractCrudDao<Long, PaymentMethodEntity> implements PaymentMethodDao {

    Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String PAYMENT_METHOD_CODE = "paymentMethodCode";
    private static final String PAYMENT_FREQUENCY_CODE = "paymentFrequencyCode";
    private static final String BRANDID = "brandId";
    private static final String ACTIVE = "active";
    private static final String PAYMENT_METHOD_ORDER = "paymentMethodOrder";
    private static final String PAYMENT_FREQUENCY_ORDER = "paymentFrequencyOrder";

    @PersistenceContext(unitName = "wssPersistence-pas")
    protected EntityManager entityManager;

    @Override
    public EntityManager getEntityManager() {
        return this.entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public PaymentMethodEntity findActivePaymentMethod(String method, String frequency, String brandId) {

        PaymentMethodEntity paymentMethod = null;

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentMethodEntity> criteriaQuery = criteriaBuilder.createQuery(PaymentMethodEntity.class);
        Root<PaymentMethodEntity> pme = criteriaQuery.from(PaymentMethodEntity.class);

        Predicate methodPredicate = criteriaBuilder.equal(pme.get(PAYMENT_METHOD_CODE), method);
        Predicate frequenctPredicate = criteriaBuilder.equal(pme.get(PAYMENT_FREQUENCY_CODE), frequency);
        Predicate activePredicate = criteriaBuilder.equal(pme.get(ACTIVE), true);
        Predicate brandPredicate = criteriaBuilder.equal(pme.get(BRANDID), brandId);
        Predicate selectPredicate = criteriaBuilder.and(methodPredicate, frequenctPredicate, activePredicate, brandPredicate);
        criteriaQuery.where(selectPredicate);

        List<Order> orderList = new ArrayList();

        orderList.add(criteriaBuilder.desc(pme.get(PAYMENT_METHOD_ORDER)));
        orderList.add(criteriaBuilder.desc(pme.get(PAYMENT_FREQUENCY_ORDER)));

        criteriaQuery.orderBy(orderList);

        TypedQuery<PaymentMethodEntity> query = this.entityManager.createQuery(criteriaQuery);

        try {
            paymentMethod = query.getSingleResult();
        } catch (NoResultException e) {
            log.warn("No active payment method found for paymenMethodCode {} and frequency {}", paymentMethod,
                    frequency);
        }

        return paymentMethod;

    }


    @Override
    public List<PaymentMethodEntity> findActivePaymentMethods(String brandId) {
        List<PaymentMethodEntity> paymentMethodList = new ArrayList<>();

        CriteriaBuilder criteriaBuilder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentMethodEntity> criteriaQuery = criteriaBuilder.createQuery(PaymentMethodEntity.class);
        Root<PaymentMethodEntity> pme = criteriaQuery.from(PaymentMethodEntity.class);

        Predicate activePredicate = criteriaBuilder.equal(pme.get(ACTIVE), true);
        Predicate brandPredicate = criteriaBuilder.equal(pme.get(BRANDID), brandId);
        Predicate selectPredicate = criteriaBuilder.and(activePredicate, brandPredicate);
        criteriaQuery.where(selectPredicate);

        List<Order> orderList = new ArrayList();

        orderList.add(criteriaBuilder.desc(pme.get(PAYMENT_METHOD_ORDER)));
        orderList.add(criteriaBuilder.desc(pme.get(PAYMENT_FREQUENCY_ORDER)));

        criteriaQuery.orderBy(orderList);

        TypedQuery<PaymentMethodEntity> query = this.entityManager.createQuery(criteriaQuery);

        try {
            paymentMethodList = query.getResultList();
        } catch (NoResultException e) {
            log.warn("No active payment methods found");
        }

        return paymentMethodList;

    }

}
