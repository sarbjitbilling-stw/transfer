package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

public interface SpecialConditionsContants {

	public static final String CREATE_KEY = "PaymentPlanCreate";
	public static final String CREATE_POCB_KEY = "PaymentplanCreatePOCB";
	public static final String DELETE_KEY = "PaymentPlanDelete";
    public static final String ALL_KEY = "AllWithDetails";

}
