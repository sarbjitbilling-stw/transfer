/**
 *
 */
package uk.co.stwater.api.calculator.paymentarrangement.dao;

import uk.co.stwater.api.calculator.paymentarrangement.entity.PaymentMethodEntity;
import uk.co.stwater.api.core.dao.CrudDao;

import java.util.List;

/**
 * @author DRoberts
 */
public interface PaymentMethodDao extends CrudDao<Long, PaymentMethodEntity> {

    /**
     * Looks up an active PaymentMethod using the specified criteria.
     *
     * @param paymentMethodCode The paymentMethodCode criteria.
     * @param frequency         The frequency criteria.
     * @return The PaymentMethodEntity if found, else null.
     */
    public PaymentMethodEntity findActivePaymentMethod(String paymentMethodCode, String frequency, String brandId);

    /**
     * Looks up all active PaymentMethods.
     *
     * @return Returns a list of active payment methods, if none are found, then an
     * empty List.
     */
    public List<PaymentMethodEntity> findActivePaymentMethods(String brandId);

}
