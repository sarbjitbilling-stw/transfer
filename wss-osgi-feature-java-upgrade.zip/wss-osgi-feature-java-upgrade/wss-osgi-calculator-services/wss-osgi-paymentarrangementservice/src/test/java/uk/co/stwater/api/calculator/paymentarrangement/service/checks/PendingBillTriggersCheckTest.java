package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import io.swagger.model.NextBillStatus;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.calculator.offers.MeasuredIndicator;
import uk.co.stwater.api.osgi.model.calculator.offers.PropertyStatus;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.iib.client.api.bill.status.AccountBillStatusClient;
import uk.co.stwater.iib.client.api.bill.status.NextBillStatusResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PendingBillTriggersCheckTest {

    @Mock
    private AccountBillStatusClient accountBillStatusClient;

    @InjectMocks
    private PendingBillTriggersCheck eligibilityCheck = new PendingBillTriggersCheck();

    @Test(expected = IllegalArgumentException.class)
    public void nullAccountSummaryResponse() {
        eligibilityCheck.checkStatus(null, null, new ArrayList<>(), null, null, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void nullTargetAccountNumber() {
        AccountSummaryResponse accountSumary = mockAccountSummaryResponse(null);

        eligibilityCheck.checkStatus(null, accountSumary, new ArrayList<>(), null, null, null);
    }

    @Test
    public void eligibleWhenNoActiveUnmeasuredPropertyWithIsOffCyleBillTrigger() {
        AccountSummaryResponse accountSumary = mockAccountSummaryResponse();
        List<Property> propertyList = Arrays.asList(
                buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.UNMEASURED, false),
                buildProperty(PropertyStatus.IN_ACTIVE, MeasuredIndicator.UNMEASURED, true),
                buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.MEASURED, false),
                buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.ASSESSED, false));

        EligibilityStatus actual = eligibilityCheck.checkStatus(null, accountSumary, propertyList, null, null, null);

        assertEquals(EligabilityStatusConstants.ELIGIBLE, actual.getStatus());
    }

    @Test
    public void notEligibleActiveUnmeasuredWithIsOffCyleBillTrigger() {
        AccountSummaryResponse accountSumary = mockAccountSummaryResponse();
        List<Property> propertyList = Arrays
                .asList(buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.UNMEASURED, true));

        EligibilityStatus actual = eligibilityCheck.checkStatus(null, accountSumary, propertyList, null, null, null);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, actual.getStatus());
    }

    @Test
    public void notEligibleOnePropertyWithIsOffCyleBillTrigger() {
        AccountSummaryResponse accountSumary = mockAccountSummaryResponse();
        List<Property> propertyList = Arrays.asList(
                buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.ASSESSED, false),
                buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.UNMEASURED, true),
                buildProperty(PropertyStatus.ACTIVE, MeasuredIndicator.MEASURED, false));

        EligibilityStatus actual = eligibilityCheck.checkStatus(null, accountSumary, propertyList, null, null, null);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, actual.getStatus());
    }

    private AccountSummaryResponse mockAccountSummaryResponse() {
        TargetAccountNumber accountNumber = new TargetAccountNumber("123459");
        return mockAccountSummaryResponse(accountNumber);
    }

    private AccountSummaryResponse mockAccountSummaryResponse(TargetAccountNumber accountNumber) {
        AccountSummaryResponse accountSummary = mock(AccountSummaryResponse.class);
        when(accountSummary.getAccountNumber()).thenReturn(accountNumber);
        return accountSummary;
    }

    private Property buildProperty(PropertyStatus propertyStatus, MeasuredIndicator measuredIndicator,
            boolean isOffCycleBillTrigger) {
        Property property = new Property();

        // PropertyStatus
        RefData propertyStatusRefData = new RefData();
        propertyStatusRefData.setCode(propertyStatus.getStatus());
        property.setStatus(propertyStatusRefData);

        // MeasuredIndicator
        RefData measuredIndicatorRefData = new RefData();
        measuredIndicatorRefData.setCode(measuredIndicator.getTargetCode());
        property.setMeasuredIndicator(measuredIndicatorRefData);

        NextBillStatusResponse response = buildNextBillStatus(isOffCycleBillTrigger);
        when(accountBillStatusClient.getNextBillStatus(any(), eq(property))).thenReturn(response);

        return property;
    }

    private NextBillStatusResponse buildNextBillStatus(boolean isOffCycleBillTrigger) {
        NextBillStatus nextBillStatus = new NextBillStatus();
        nextBillStatus.setIsOffCycleBillTrigger(isOffCycleBillTrigger);
        // to avoid NullPointerException when auto un-boxing Boolean
        nextBillStatus.setIsFutureStartMainBill(false);
        nextBillStatus.setIsMainBilled(false);
        return new NextBillStatusResponse(nextBillStatus);
    }

}
