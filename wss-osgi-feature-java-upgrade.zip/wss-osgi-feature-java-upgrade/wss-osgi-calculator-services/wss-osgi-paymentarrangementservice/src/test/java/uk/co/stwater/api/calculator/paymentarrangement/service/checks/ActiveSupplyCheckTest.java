package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import org.junit.Test;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ActiveSupplyCheckTest {

    @Test
    public void testCheckActiveSupplyStatus() {
        Property property = new Property();
        RefData status = new RefData();
        status.setCode("A");
        status.setValue("Active");
        status.set("20002");
        property.setStatus(status);
        property.setEndDate(null);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(true);

        List<Property> propertyList = new ArrayList<Property>();
        propertyList.add(property);

        EligiblityCheck statusCheck = new ActiveSupplyCheck();

        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(method, null, propertyList, null, null, null);

        assertNotNull(activeSupplyStatus);
        assertEquals(EligabilityStatusConstants.ELIGIBLE, activeSupplyStatus.getStatus());

    }

    @Test
    public void testNonPlanMethod() {
        Property property = new Property();
        RefData status = new RefData();
        status.setCode("A");
        status.setValue("Active");
        status.set("20002");
        property.setStatus(status);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(false);

        List<Property> propertyList = new ArrayList<Property>();
        propertyList.add(property);

        EligiblityCheck statusCheck = new ActiveSupplyCheck();

        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(method, null, propertyList, null, null, null);

        assertNotNull(activeSupplyStatus);
        assertEquals(EligabilityStatusConstants.ELIGIBLE, activeSupplyStatus.getStatus());

    }

    @Test
    public void testCheckInactiveSupplyStatusWithZeroAccountBalance() {

        Property property = new Property();
        RefData status = new RefData();
        status.setCode("I");
        status.setValue("Inactive");
        status.set("20002");
        property.setStatus(status);
        property.setEndDate(LocalDate.now());

        List<Property> propertyList = new ArrayList<Property>();
        propertyList.add(property);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(true);

        AccountSummaryResponse accountSummary = new TestAccountSummary();
        BigDecimal balance = new BigDecimal(0);
        accountSummary.setAccountBalance(balance);
        EligiblityCheck statusCheck = new ActiveSupplyCheck();

        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(method, accountSummary, propertyList, null, null, null);

        assertNotNull(activeSupplyStatus);
        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, activeSupplyStatus.getStatus());
        assertEquals(EligabilityStatusConstants.ARREARS_PAYMENT_PLAN_NOT_ALLOWED, activeSupplyStatus.getText());

    }

    @Test(expected = IllegalArgumentException.class)
    public void testThrowIllegalArgumentException() {
        List<Property> propertyList = null;
        EligiblityCheck statusCheck = new ActiveSupplyCheck();
        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(null, null, propertyList, null, null, null);

    }

    @Test
    public void testMultipleSuppliesVaryingStatus() {
        List<Property> propertyList = new ArrayList<Property>();

        Property activeProperty = new Property();
        RefData activeStatus = new RefData();
        activeStatus.setCode("A");
        activeProperty.setStatus(activeStatus);
        propertyList.add(activeProperty);

        Property inactiveProperty = new Property();
        RefData inactiveStatus = new RefData();
        inactiveStatus.setCode("I");
        propertyList.add(inactiveProperty);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(true);

        EligiblityCheck statusCheck = new ActiveSupplyCheck();
        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(method, null, propertyList, null, null, null);

        assertEquals(EligabilityStatusConstants.ELIGIBLE, activeSupplyStatus.getStatus());

    }

    @Test
    public void testMultipleSuppliesNoActiveStatusWithZeroAccountBalance() {
        List<Property> propertyList = new ArrayList<Property>();

        Property property1 = new Property();
        RefData inactiveStatus = new RefData();
        inactiveStatus.setCode("I");
        property1.setStatus(inactiveStatus);
        property1.setEndDate(LocalDate.now());
        propertyList.add(property1);

        Property property2 = new Property();
        property2.setStatus(inactiveStatus);
        property2.setEndDate(LocalDate.now().minusYears(1));

        propertyList.add(property2);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(true);

        AccountSummaryResponse accountSummary = new TestAccountSummary();
        BigDecimal balance = new BigDecimal(0);
        accountSummary.setAccountBalance(balance);

        EligiblityCheck statusCheck = new ActiveSupplyCheck();
        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(method, accountSummary, propertyList, null, null, null);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, activeSupplyStatus.getStatus());

    }

    @Test
    public void testMultipleSuppliesNoActiveStatusWithAccountBalance() {
        List<Property> propertyList = new ArrayList<Property>();

        Property property1 = new Property();
        RefData inactiveStatus = new RefData();
        inactiveStatus.setCode("I");
        property1.setStatus(inactiveStatus);
        propertyList.add(property1);

        Property property2 = new Property();
        property2.setStatus(inactiveStatus);

        propertyList.add(property2);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(true);

        AccountSummaryResponse accountSummary = new TestAccountSummary();
        BigDecimal balance = new BigDecimal(300.25);
        accountSummary.setAccountBalance(balance);

        EligiblityCheck statusCheck = new ActiveSupplyCheck();
        EligibilityStatus activeSupplyStatus = statusCheck.checkStatus(method, accountSummary, propertyList, null, null, null);

        assertEquals(EligabilityStatusConstants.ELIGIBLE, activeSupplyStatus.getStatus());

    }

}
