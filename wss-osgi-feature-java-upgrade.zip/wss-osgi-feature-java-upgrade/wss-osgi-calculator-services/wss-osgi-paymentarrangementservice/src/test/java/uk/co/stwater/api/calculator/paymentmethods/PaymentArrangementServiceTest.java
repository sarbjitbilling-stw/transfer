package uk.co.stwater.api.calculator.paymentmethods;

import org.apache.commons.lang3.StringUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import uk.co.stwater.api.calculator.paymentarrangement.dao.PaymentMethodDao;
import uk.co.stwater.api.calculator.paymentarrangement.entity.PaymentMethodEntity;
import uk.co.stwater.api.calculator.paymentarrangement.service.CreatePaymentPlanContext;
import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodService;
import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodServiceImpl;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.EligabilityStatusConstants;
import uk.co.stwater.api.calculator.paymentarrangement.service.checks.TestAccountSummary;
import uk.co.stwater.api.core.service.ServiceException;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.SpecialCondition;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.api.specialconditions.SpecialConditionAction;
import uk.co.stwater.api.specialconditions.SpecialConditionChannel;
import uk.co.stwater.api.specialconditions.SpecialConditionService;
import uk.co.stwater.iib.client.api.date.DateClient;
import uk.co.stwater.iib.client.api.directdebit.check.DirectDebitCheckClient;
import uk.co.stwater.iib.client.api.directdebit.check.DirectDebitCheckResponse;
import uk.co.stwater.iib.client.api.paymentplan.check.CheckActivePaymentPlansClient;
import uk.co.stwater.iib.client.api.paymentplan.check.CheckActivePaymentPlansResponse;
import uk.co.stwater.iib.client.api.properties.get.GetPropertiesForAccountNumberClient;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;
import uk.co.stwater.targetconnector.client.api.accountsummary.GetAccountSummaryClient;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PaymentArrangementServiceTest {

    private List<PaymentMethodEntity> getPaymentMethods(boolean isPlan) {
        List<PaymentMethodEntity> thePaymentMethodList = new ArrayList<PaymentMethodEntity>();

        PaymentMethodEntity directDebit = new PaymentMethodEntity();
        directDebit.setPaymentMethodCode("DD");
        directDebit.setPaymentMethodText("Direct Debit");
        directDebit.setPaymentPlan(isPlan);
        directDebit.setEarliestStartDateDays(1);
        directDebit.setLatestStartDateDays(10);
        directDebit.setDayType("A");
        directDebit.setFacilityCode("FA");
        directDebit.setHoverOverText("HoverOverText");
        directDebit.setPaymentFrequencyCode("M");
        directDebit.setPaymentFrequencyOrder(1);
        directDebit.setPaymentFrequencyText("Monthly");
        directDebit.setPaymentMethodOrder(2);

        thePaymentMethodList.add(directDebit);

        return thePaymentMethodList;
    }

    private AccountSummaryResponse getAccountSummaryResponse(BigDecimal balance, boolean paperless) {
        TestAccountSummary response = new TestAccountSummary();
        response.setAccountBalance(balance);
        response.setIsPaperless(paperless);
        response.setLastPaymentDate(new Date(System.currentTimeMillis()));
        TargetAccountNumber accountNumber = new TargetAccountNumber("12345");
        response.setAccountNumber(accountNumber);

        return response;
    }

    private List<Property> getPropertiesList(String type, String activeStatus) {
        List<Property> propertiesList = new ArrayList<Property>();

        Property p1 = new Property();
        RefData measuredIndicator = new RefData();
        measuredIndicator.setCode(type);
        p1.setMeasuredIndicator(measuredIndicator);
        RefData status = new RefData();
        status.setCode(activeStatus);
        p1.setStatus(status);

        propertiesList.add(p1);

        return propertiesList;
    }

    private DirectDebitCheckResponse getDirectDebitCheckResponse() {

        DirectDebitCheckResponse response = new DirectDebitCheckResponse();
        response.setSent(false);
        return response;

    }

    @Mock
    PaymentMethodDao paymentMethodDAO;

    @Mock
    GetAccountSummaryClient getAccountSummaryClient;

    @Mock
    DateClient dateClient;

    @Mock
    GetPropertiesForAccountNumberClient propertiesService;

    @InjectMocks
    PaymentMethodService service = new PaymentMethodServiceImpl();

    @Mock
    SpecialConditionService specialconditionsService;

    @Mock
    CheckActivePaymentPlansClient checkActivePaymentPlansClient;

    @Mock
    DirectDebitCheckClient directDebitCheckClient;

    @Test
    @Ignore
    public void testGetAvailablePaymentArrangementsForActiveUnMeasuredPropertyWithNoArrears() throws Exception {
        String postCode = "";
        String authToken = "droberb";
        String accountNumber = new String("12345");
        String brandId = "1"; //Severn Trent

        TargetAccountNumber targetAccountNumber = new TargetAccountNumber(accountNumber, null);

        Mockito.when(getAccountSummaryClient.getAccountSummary(targetAccountNumber, new Long(5678)))
                .thenReturn(getAccountSummaryResponse(new BigDecimal(0), false));
        Mockito.when(paymentMethodDAO.findActivePaymentMethods(brandId)).thenReturn(getPaymentMethods(true));
        Mockito.when(propertiesService.getPropertiesForAccountNumber(targetAccountNumber, postCode))
                .thenReturn(getPropertiesList("U", "A"));


        Mockito.when(checkActivePaymentPlansClient.getPaymentPlansForAccount(Mockito.any(TargetAccountNumber.class), Mockito.anyString()))
                .thenReturn(new ArrayList<CheckActivePaymentPlansResponse>());

        Mockito.when(directDebitCheckClient.checkDirectDebit(Mockito.any(TargetAccountNumber.class), Mockito.anyString()))
                .thenReturn(getDirectDebitCheckResponse());

        List<SpecialCondition> specialConditions = new ArrayList<SpecialCondition>();
        specialConditions.add(new SpecialCondition("LEGAL", "test"));

        Mockito.when(specialconditionsService.getSpecialConditions(targetAccountNumber, StringUtils.EMPTY, Optional.of(authToken))).thenReturn(specialConditions);
        String str = "2015-03-15";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate now = LocalDate.parse(str, formatter);
        Mockito.when(dateClient.getTargetDate(authToken)).thenReturn(now);

        List<PaymentMethod> paymentMethods = null;
        String channel = "IOC";
        Long legalEntity = new Long(5678);

        CreatePaymentPlanContext ctx = new CreatePaymentPlanContext(targetAccountNumber, legalEntity, brandId);
        try {
            paymentMethods = service.getAvailablePaymentArrangements(ctx, channel, true, authToken);
        } catch (ServiceException e) {
            throw new RuntimeException(e);
        }

        Mockito.verify(getAccountSummaryClient).getAccountSummary(targetAccountNumber, legalEntity);
        Mockito.verify(paymentMethodDAO).findActivePaymentMethods(brandId);
        Mockito.verify(dateClient).getTargetDate(authToken);
        Mockito.verify(propertiesService).getPropertiesForAccountNumber(targetAccountNumber, authToken);

        Mockito.verify(specialconditionsService).checkSpecialConditions(specialConditions,
                SpecialConditionChannel.valueOf(channel), SpecialConditionAction.PAYMENT_PLAN_CREATE);

        Mockito.verify(specialconditionsService).checkSpecialConditions(specialConditions,
                SpecialConditionChannel.valueOf(channel), SpecialConditionAction.PAYMENT_PLAN_CREATE_POCB);

        Mockito.verify(specialconditionsService).checkSpecialConditions(specialConditions,
                SpecialConditionChannel.valueOf(channel), SpecialConditionAction.PAYMENT_PLAN_DELETE);

        assertNotNull(paymentMethods);
        assertEquals(1, paymentMethods.size());
        PaymentMethod method = paymentMethods.get(0);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, method.getEligible());

        assertNotNull(method.getEarliestStartDate());
        assertNotNull(method.getLatestStartDate());
        assertNotNull(method.getDayType());
        assertNotNull(method.getHoverOverText());
        assertNotNull(method.getEligibleText());
        assertNotNull(method.getPaymentFrequencyCode());
        assertNotNull(method.getPaymentFrequencyText());

    }

}
