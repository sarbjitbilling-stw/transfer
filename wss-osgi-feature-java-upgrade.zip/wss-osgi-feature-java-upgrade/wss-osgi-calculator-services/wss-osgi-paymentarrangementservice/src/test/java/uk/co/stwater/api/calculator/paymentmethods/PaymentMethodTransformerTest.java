package uk.co.stwater.api.calculator.paymentmethods;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

import uk.co.stwater.api.calculator.paymentarrangement.entity.PaymentMethodEntity;
import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTransformer;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;

public class PaymentMethodTransformerTest {

	@Test
	public void testTransform() {

		PaymentMethodEntity entity = new PaymentMethodEntity();
		entity.setDayType("1");
		entity.setDefaultPaymentType(true);
		entity.setPaymentPlan(true);

		entity.setFacilityCode("facilityCode");
		entity.setEarliestStartDateDays(10);
		entity.setLatestStartDateDays(40);
		entity.setPaymentDetailsCode("paymentDetailsCode");
		entity.setPaymentMethodCode("paymentMethodCode");
		entity.setPaymentFrequencyCode("paymentFrequencyCode");
		entity.setPaymentFrequencyText("paymentFrequencyText");
		entity.setPaymentMethodText("paymentMethodText");
		entity.setScheduleFreqCode("scheduleFreqCode");


		PaymentMethodTransformer transformer = new PaymentMethodTransformer();

		Object target = transformer.transform(entity);

		assertNotNull(target);

		if (target instanceof PaymentMethod) {
			PaymentMethod method = (PaymentMethod) target;

			assertTrue(method.isDefaultPaymentType());
			assertTrue(method.isPlan());

			assertEquals("facilityCode", method.getFacilityCode());
			assertEquals("paymentMethodCode", method.getPaymentMethodCode());
			assertEquals("paymentFrequencyCode", method.getPaymentFrequencyCode());
			assertEquals("paymentFrequencyText", method.getPaymentFrequencyText());
			assertEquals("paymentMethodText", method.getPaymentMethodText());
			assertEquals("scheduleFreqCode", method.getScheduleFreqCode());

		} else {
			fail();
		}

	}

	@Test
	public void testNullTransform() {

		PaymentMethodTransformer transformer = new PaymentMethodTransformer();

		Object target = transformer.transform(null);

		assertNull(target);

	}
	
	@Test
	public void testNulEarliestLatestDatesTransform() {

		PaymentMethodTransformer transformer = new PaymentMethodTransformer();
		
		PaymentMethodEntity entity = new PaymentMethodEntity();

		Object target = transformer.transform(entity);

		assertNotNull(target);

	}

}
