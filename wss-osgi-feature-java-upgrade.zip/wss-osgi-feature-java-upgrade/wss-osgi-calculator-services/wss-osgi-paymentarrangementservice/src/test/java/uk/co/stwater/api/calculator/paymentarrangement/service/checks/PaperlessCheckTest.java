package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTypeConstants;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;


public class PaperlessCheckTest {

	@Test
	public void testPaperlessStatusCheck() {

		PaperlessCheck check = new PaperlessCheck();
		PaymentMethod method = new PaymentMethod();
		method.setPlan(true);
		method.setPaymentMethodCode(PaymentMethodTypeConstants.PAPERLESS);

		AccountSummaryResponse accountSummary = new TestAccountSummary();
		accountSummary.setIsPaperless(true);

		EligibilityStatus status = check.checkStatus(method, accountSummary, null, null, null, null);

		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, status.getStatus());
		assertEquals("Payment Booklet not allowed for Paperless customers", status.getText());
	}

	@Test
	public void testPaperlessStatusInvalidPlanTypeCheck() {

		PaperlessCheck check = new PaperlessCheck();
		PaymentMethod method = new PaymentMethod();
		method.setPlan(true);
		method.setPaymentMethodCode(PaymentMethodTypeConstants.PAPERLESS);

		AccountSummaryResponse accountSummary = new TestAccountSummary();
		accountSummary.setIsPaperless(false);

		EligibilityStatus status = check.checkStatus(method, accountSummary, null, null, null, null);

		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());

	}

	@Test
	public void testPaperlessStatusInvalidPaymentMethod() {
		PaperlessCheck check = new PaperlessCheck();
		PaymentMethod method = new PaymentMethod();
		method.setPlan(false);
		method.setPaymentMethodCode(PaymentMethodTypeConstants.PAPERLESS);

		AccountSummaryResponse accountSummary = new TestAccountSummary();
		accountSummary.setIsPaperless(true);

		EligibilityStatus status = check.checkStatus(method, accountSummary, null, null, null, null);

		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testPaperlessStatusNullPaymentMethod() {
		PaperlessCheck check = new PaperlessCheck();
		PaymentMethod method = null;

		AccountSummaryResponse accountSummary = new TestAccountSummary();
		accountSummary.setIsPaperless(true);

		EligibilityStatus status = check.checkStatus(method, accountSummary, null, null, null, null);

	}

	@Test(expected = IllegalArgumentException.class)
	public void testPaperlessStatusNullAccountSummary() {
		PaperlessCheck check = new PaperlessCheck();
		PaymentMethod method = new PaymentMethod();
		method.setPlan(false);

		AccountSummaryResponse accountSummary = null;

		EligibilityStatus status = check.checkStatus(method, accountSummary, null, null, null, null);

	}

}
