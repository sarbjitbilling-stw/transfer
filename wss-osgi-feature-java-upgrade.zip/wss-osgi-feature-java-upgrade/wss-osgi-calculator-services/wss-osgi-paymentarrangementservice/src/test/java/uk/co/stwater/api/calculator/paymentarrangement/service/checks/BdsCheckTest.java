package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTypeConstants;
import uk.co.stwater.api.osgi.model.SpecialConditionRestriction;
import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.util.STWTechnicalException;
import uk.co.stwater.api.osgi.util.feature.Feature;
import uk.co.stwater.api.osgi.util.feature.FeatureService;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BdsCheckTest {
    private static final TargetAccountNumber ACCOUNT_NUMBER = new TargetAccountNumber("123459");
    private static final LocalDate CURRENT_DATE = LocalDate.now();

    @Mock
    private FeatureService featureService;

    @Spy
    @InjectMocks
    private BdsCheck bdsCheck = new BdsCheck();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Before
    public void setup() {
        doReturn(CURRENT_DATE).when(bdsCheck).getCurrentDate();
        when(featureService.isActive(Feature.BDS_PAYMENT_PLAN)).thenReturn(true);
    }

    @Test
    public void checkStatusNoBdsSpecialCondition() {
        PaymentMethod paymentMethod = buildPaymentMethod();

        EligibilityStatus actual = checkStatusWithoutBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.ELIGIBLE, actual.getStatus());
        assertTrue(StringUtils.isEmpty(actual.getText()));
    }

    @Test
    public void checkStatusBdsMontlyDirectDebit() {
        PaymentMethod paymentMethod = buildPaymentMethod(PaymentMethodTypeConstants.DIRECT_DEBIT,
                PaymentMethodTypeConstants.PAYMENT_FREQUENCY_MONTHLY);

        EligibilityStatus actual = checkStatusWithBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING, actual.getStatus());
        assertEquals(BdsCheck.BDS_ACCOUNT_WARNING, actual.getText());
    }

    @Test
    public void checkStatusBdsMontlyWatercard() {
        PaymentMethod paymentMethod = buildPaymentMethod(PaymentMethodTypeConstants.PAYMENT_METHOD_WATERCARD,
                PaymentMethodTypeConstants.PAYMENT_FREQUENCY_MONTHLY);

        EligibilityStatus actual = checkStatusWithBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING, actual.getStatus());
        assertEquals(BdsCheck.BDS_ACCOUNT_WARNING, actual.getText());
    }

    @Test
    public void checkStatusBdsNotMontly() {
        PaymentMethod paymentMethod = buildPaymentMethod(PaymentMethodTypeConstants.PAYMENT_METHOD_WATERCARD, "W");

        EligibilityStatus actual = checkStatusWithBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, actual.getStatus());
        assertEquals(BdsCheck.BDS_INVALID_PAYMENT_METHOD_ERROR, actual.getText());
    }

    @Test
    public void checkStatusBdsNotDirectDebitOrWatercard() {
        PaymentMethod paymentMethod = buildPaymentMethod("PB", PaymentMethodTypeConstants.PAYMENT_FREQUENCY_MONTHLY);

        EligibilityStatus actual = checkStatusWithBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, actual.getStatus());
        assertEquals(BdsCheck.BDS_INVALID_PAYMENT_METHOD_ERROR, actual.getText());
    }

    @Test
    public void checkStatusBdsNotActiveBdsAccount() {
        PaymentMethod paymentMethod = buildPaymentMethod();

        reset(featureService);
        when(featureService.isActive(Feature.BDS_PAYMENT_PLAN)).thenReturn(false);

        EligibilityStatus actual = checkStatusWithBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, actual.getStatus());
        assertEquals(BdsCheck.BDS_PLANS_BLOCKED_ERROR, actual.getText());
    }

    @Test
    public void checkStatusBdsNotActiveNonBdsAccount() {
        PaymentMethod paymentMethod = buildPaymentMethod();

        reset(featureService);
        when(featureService.isActive(Feature.BDS_PAYMENT_PLAN)).thenReturn(false);

        EligibilityStatus actual = checkStatusWithoutBdsSpecialCondition(paymentMethod);

        assertEquals(EligabilityStatusConstants.ELIGIBLE, actual.getStatus());
        assertTrue(StringUtils.isEmpty(actual.getText()));
    }

    @Test
    public void checkStatusNullStartDateThrowsException() {
        expectedException.expect(STWTechnicalException.class);
        expectedException.expectMessage("Latest BDS special condition start date not found");

        PaymentMethod paymentMethod = buildPaymentMethod();
        Map<String, List<SpecialConditionRestriction>> specialConditions = buildBdsSpecialConditionMap(
                (LocalDate) null);

        checkStatus(paymentMethod, specialConditions);
    }

    @Test
    public void checkStatusLateEndDateEligible() {
        PaymentMethod paymentMethod = buildPaymentMethod();
        // plus 2 days to allow for leap years
        Map<String, List<SpecialConditionRestriction>> specialConditions = buildBdsSpecialConditionMap(
                CURRENT_DATE.plusWeeks(BdsCheck.RENEWAL_WARNING_WEEKS).plusDays(2));

        EligibilityStatus actual = checkStatus(paymentMethod, specialConditions);

        assertEquals(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING, actual.getStatus());
        assertEquals(BdsCheck.BDS_ACCOUNT_WARNING, actual.getText());
    }

    @Test
    public void checkStatusRenewalWarning() {
        PaymentMethod paymentMethod = buildPaymentMethod();
        Map<String, List<SpecialConditionRestriction>> specialConditions = buildBdsSpecialConditionMap(
                CURRENT_DATE.plusDays(5), CURRENT_DATE.plusWeeks(6), CURRENT_DATE.plusDays(10));

        EligibilityStatus actual = checkStatus(paymentMethod, specialConditions);

        assertEquals(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING, actual.getStatus());
        assertEquals(BdsCheck.BDS_RENEWAL_SOON_WARNING, actual.getText());
    }

    @Test
    public void checkStatusExpiryError() {
        PaymentMethod paymentMethod = buildPaymentMethod();
        Map<String, List<SpecialConditionRestriction>> specialConditions = buildBdsSpecialConditionMap(
                CURRENT_DATE.plusWeeks(3), CURRENT_DATE.plusDays(10));

        EligibilityStatus actual = checkStatus(paymentMethod, specialConditions);

        assertEquals(EligabilityStatusConstants.NOT_ELIGIBLE, actual.getStatus());
        assertEquals(BdsCheck.BDS_EXPIRING_SOON_ERROR, actual.getText());
    }

    private PaymentMethod buildPaymentMethod() {
        return buildPaymentMethod(PaymentMethodTypeConstants.PAYMENT_METHOD_WATERCARD,
                PaymentMethodTypeConstants.PAYMENT_FREQUENCY_MONTHLY);
    }

    private PaymentMethod buildPaymentMethod(String methodCode, String frequencyCode) {
        PaymentMethod paymentMethod = new PaymentMethod();

        paymentMethod.setPaymentMethodCode(methodCode);
        paymentMethod.setPaymentFrequencyCode(frequencyCode);

        return paymentMethod;
    }

    private EligibilityStatus checkStatusWithBdsSpecialCondition(PaymentMethod paymentMethod) {
        Map<String, List<SpecialConditionRestriction>> specialConditions = new HashMap<>();
        specialConditions.put(SpecialConditionsContants.ALL_KEY,
                buildBdsSpecialConditionList(CURRENT_DATE.plusMonths(5)));
        return checkStatus(paymentMethod, specialConditions);
    }

    private Map<String, List<SpecialConditionRestriction>> buildBdsSpecialConditionMap(LocalDate... endDateList) {
        Map<String, List<SpecialConditionRestriction>> specialConditionsMap = new HashMap<>();
        specialConditionsMap.put(SpecialConditionsContants.ALL_KEY, buildBdsSpecialConditionList(endDateList));
        return specialConditionsMap;
    }

    private List<SpecialConditionRestriction> buildBdsSpecialConditionList(LocalDate... endDateList) {
        return Arrays.stream(endDateList).map(this::buildBdsSpecialCondition).collect(Collectors.toList());
    }

    private SpecialConditionRestriction buildBdsSpecialCondition(LocalDate endDate) {
        SpecialConditionRestriction specialCondition = new SpecialConditionRestriction();
        specialCondition.setTypeName(BdsCheck.BDS_ACCOUNT_SPECIAL_CONDITION);

        if (endDate != null) {
            // for BDs special conditions end date is calculated based off start date
            specialCondition.setStartDate(endDate.minusYears(1));
        }

        return specialCondition;
    }

    private EligibilityStatus checkStatusWithoutBdsSpecialCondition(PaymentMethod paymentMethod) {
        Map<String, List<SpecialConditionRestriction>> specialConditions = new HashMap<>();
        specialConditions.put(SpecialConditionsContants.ALL_KEY, null);
        return checkStatus(paymentMethod, specialConditions);
    }

    private EligibilityStatus checkStatus(PaymentMethod paymentMethod,
            Map<String, List<SpecialConditionRestriction>> specialConditions) {
        AccountSummaryResponse accountSummary = mock(AccountSummaryResponse.class);
        when(accountSummary.getAccountNumber()).thenReturn(ACCOUNT_NUMBER);
        return bdsCheck.checkStatus(paymentMethod, accountSummary, null, null, specialConditions, null);
    }

}
