/**
 * 
 */
package uk.co.stwater.api.calculator.paymentmethods.dao;

import java.math.BigDecimal;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import jakarta.xml.ws.Holder;

import uk.co.severntrent.billing_service.servicewsdl.getaccountsummary.v1.FaultDetailSTWError;
import uk.co.severntrent.billing_service.servicewsdl.getaccountsummary.v1.PortTypeGetAccountSummary;
import uk.co.severntrent.billing_service.types.getaccountsummaryrequest.v1.CTypeGetAccountSummaryRequest;
import uk.co.severntrent.billing_service.types.getaccountsummaryresponse.v1.CTypeGetAccountSummaryResponse;
import uk.co.severntrent.billing_service.types.getaccountsummaryresponse.v1.CTypeReplyBody;
import uk.co.severntrent.billing_service.types.getaccountsummaryresponse.v1.ObjectFactory;
import uk.co.severntrent.common_technical.types.msgenvelopeheader.v1.CTypeMsgEnvelopeHeader;

/**
 * @author zali
 *
 */
public class PortTypeGetAccountSummaryImpl implements PortTypeGetAccountSummary {

	/*
	 * (non-Javadoc)
	 * 
	 * @see uk.co.severntrent.billing_service.servicewsdl.getaccountsummary.v1.
	 * PortTypeGetAccountSummary#opGetAccountSummary(uk.co.severntrent.
	 * billing_service.types.getaccountsummaryrequest.v1.
	 * CTypeGetAccountSummaryRequest, jakarta.xml.ws.Holder)
	 */
	@WebMethod(operationName = "Op_GetAccountSummary", action = "Action_GetAccountSummary")
	@WebResult(name = "GetAccountSummaryResponse", targetNamespace = "http://severntrent.co.uk/billing-service/types/GetAccountSummaryResponse/V1", partName = "GetAccountSummaryResponse")
	public CTypeGetAccountSummaryResponse opGetAccountSummary(
			@WebParam(name = "GetAccountSummaryRequest", 
					  targetNamespace = "http://severntrent.co.uk/billing-service/types/GetAccountSummaryRequest/V1", 
					  partName = "GetAccountSummaryRequest") 
			CTypeGetAccountSummaryRequest getAccountSummaryRequest,
			@WebParam(name = "MsgEnvelopeHeader", 
					  targetNamespace = "http://severntrent.co.uk/common-technical/types/MsgEnvelopeHeader/V1", 
					  header = true, mode = WebParam.Mode.INOUT, 
					  partName = "MsgEnvelopeHeader") 
			Holder<CTypeMsgEnvelopeHeader> msgEnvelopeHeader)
			throws FaultDetailSTWError {
		
		return populateResponse(getAccountSummaryRequest.getRequestBody().getAccountNum());
	}

	private CTypeGetAccountSummaryResponse populateResponse(long accountnumber) {
		ObjectFactory objectFactory = new ObjectFactory();
		CTypeGetAccountSummaryResponse accountSummaryResponse = objectFactory.createCTypeGetAccountSummaryResponse();
		CTypeReplyBody responseBody = objectFactory.createCTypeReplyBody();
		responseBody.setAccountBalance(new BigDecimal(200));
		
		return accountSummaryResponse;	
	}

}
