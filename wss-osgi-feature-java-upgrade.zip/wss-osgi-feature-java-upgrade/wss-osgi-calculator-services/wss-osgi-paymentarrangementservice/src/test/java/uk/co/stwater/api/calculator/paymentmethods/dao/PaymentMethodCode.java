package uk.co.stwater.api.calculator.paymentmethods.dao;

public enum PaymentMethodCode {
	
	DDR("DD", "Direct Debit", "R", "On Recipt of Bill", false,"",""), 
	DDM("DD", "Direct Debit", "M", "Monthly", true, "D", "M"), 
	DDF("DD","Direct Debit", "F", "Fortnightly", true,"D","F"),

	WCR("WC", "Water Card", "R", "On Recipt of Bill", false,"",""), 
	WCM("WC", "Water Card", "M", "Monthly", true,"PC","M"), 
	WCF("WC", "Water Card","F", "Fortnightly", true,"PC","F"), 
	WCW("WC", "Water Card", "W", "Weekly", true,"PC","W"),

	PBM("PB", "Payment Booklet", "M", "Monthly", true,"B","M"), 
	PBF("PB", "Payment Booklet", "F", "Fortnightly", true,"B","F"), 
	PBW("PB","Payment Booklet", "W", "Weekly", true,"B","W"),

	CD("CD", "Credit/Debit Card", "R", "On Recipt of Bill", false,"",""), 
	PI("PI", "Pingit", "R", "On Recipt of Bill", false,"",""), 
	VB("VB","Via Bank", "R", "On Recipt of Bill", false,"",""), 
	CHR("CH", "Cheque", "R", "On Recipt of Bill", false,"","");
	
	String code, codeDescription, frequecyCode, frequencyCodeDescription, facilityCode, scheduleFrequencyCode;
	boolean planable;

	private PaymentMethodCode(String code, String codeDescription, String frequencyCode,
			String frequencyCodeDescription, boolean planable, String facilityCode, String scheduleFrequencyCode) {
		this.code = code;
		this.codeDescription = codeDescription;
		this.frequecyCode = frequencyCode;
		this.frequencyCodeDescription = frequencyCodeDescription;
		this.planable = planable;
		this.facilityCode = facilityCode;
		this.scheduleFrequencyCode = scheduleFrequencyCode;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the text
	 */
	public String getCodeDescription() {
		return codeDescription;
	}

	/**
	 * @param text
	 *            the text to set
	 */
	public void setCodeDescription(String text) {
		this.codeDescription = text;
	}

	/**
	 * @return the frequecyCode
	 */
	public String getFrequecyCode() {
		return frequecyCode;
	}

	/**
	 * @param frequecyCode
	 *            the frequecyCode to set
	 */
	public void setFrequecyCode(String frequecyCode) {
		this.frequecyCode = frequecyCode;
	}

	/**
	 * @return the frequencyDescription
	 */
	public String getFrequencyCodeDescription() {
		return frequencyCodeDescription;
	}

	/**
	 * @param frequencyDescription
	 *            the frequencyDescription to set
	 */
	public void setFrequencyCodeDescription(String frequencyCodeDescription) {
		this.frequencyCodeDescription = frequencyCodeDescription;
	}

	/**
	 * @return the planable
	 */
	public boolean isPlanable() {
		return planable;
	}

	/**
	 * @param planable
	 *            the planable to set
	 */
	public void setPlanable(boolean planable) {
		this.planable = planable;
	}

	/**
	 * @return the facilityCode
	 */
	public String getFacilityCode() {
		return facilityCode;
	}

	/**
	 * @param facilityCode the facilityCode to set
	 */
	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}

	/**
	 * @return the scheduleFrequencyCode
	 */
	public String getScheduleFrequencyCode() {
		return scheduleFrequencyCode;
	}

	/**
	 * @param scheduleFrequencyCode the scheduleFrequencyCode to set
	 */
	public void setScheduleFrequencyCode(String scheduleFrequencyCode) {
		this.scheduleFrequencyCode = scheduleFrequencyCode;
	}

}
