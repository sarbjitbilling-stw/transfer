package uk.co.stwater.api.calculator.paymentarrangement.service.checks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import uk.co.stwater.api.calculator.paymentarrangement.service.PaymentMethodTypeConstants;
import uk.co.stwater.api.osgi.model.Property;
import uk.co.stwater.api.osgi.model.payment.PaymentMethod;
import uk.co.stwater.api.osgi.model.referencedata.RefData;
import uk.co.stwater.targetconnector.client.api.accountsummary.AccountSummaryResponse;

public class AccountInDebtCheckTest {
    private AccountInDebtCheck accountInDebtCheck = new AccountInDebtCheck();

    @Rule
    public ExpectedException expectedExeption = ExpectedException.none();

	/**
	 * If they are un-measured and have no arrears (balance 0 or negative), then
	 * they are NOT eligible.
	 */

	@Test
	public void testCheckNoArrears() {
		// set the payment method to Direct Debit.
		PaymentMethod method = new PaymentMethod();
		method.setPlan(true);
		method.setPaymentMethodCode(PaymentMethodTypeConstants.DIRECT_DEBIT);

		// set the property to Active status
		Property property = new Property();
		RefData propertyStatus = new RefData();
		propertyStatus.setCode("A");
		property.setStatus(propertyStatus);

		// set the property to "Unmeasured"
		RefData measuredIndicator = new RefData();
		measuredIndicator.setCode("U");
		property.setMeasuredIndicator(measuredIndicator);

		List<Property> propertyList = new ArrayList<Property>();
		propertyList.add(property);

		// set the account to be in credit
		AccountSummaryResponse accountSummary = new TestAccountSummary();
		BigDecimal balance = new BigDecimal(1);
		accountSummary.setAccountBalance(balance);

        EligibilityStatus status = accountInDebtCheck.checkStatus(method, accountSummary, propertyList, null, null,
                null);

		// should not be allowed to go direct debit as there is no debt on the
		// account
		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());

	}

	/**
	 * If property is measured then they are eligible regardless of whether they are
	 * in arrears on not.
	 */

	@Test
	public void testCheckArrearsAndMeasuredProperty() {
		// set the method to Direct Debit
		PaymentMethod method = new PaymentMethod();
		method.setPlan(true);
		method.setPaymentMethodCode(PaymentMethodTypeConstants.DIRECT_DEBIT);

		// set the property to Active
		Property property = new Property();
		RefData propertyStatus = new RefData();
		propertyStatus.setCode("A");
		property.setStatus(propertyStatus);

		// set the property to Metered
		RefData measuredIndicator = new RefData();
		measuredIndicator.setCode("M");
		property.setMeasuredIndicator(measuredIndicator);

		List<Property> propertyList = new ArrayList<Property>();
		propertyList.add(property);

		// make sure the account is in arrears
		AccountSummaryResponse accountSummary = new TestAccountSummary();
		BigDecimal balance = new BigDecimal(10);
		accountSummary.setAccountBalance(balance);

        EligibilityStatus status = accountInDebtCheck.checkStatus(method, accountSummary, propertyList, null, null,
                null);

		// ensure that the payment method is eligible
		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());
	}

	/**
	 * If property is un-measured and not in arears then they are eligible.
	 */

	@Test
	public void testCheckArrearsAndUnmeasuredProperty() {

		/*
		 * Customer is in arrears and the property is un-measured, so should not be
		 * allowed a plan.
		 */

		// ensure payment method is a plan
		PaymentMethod method = new PaymentMethod();
		method.setPlan(true);

		// make sure property is active
		Property property = new Property();
		RefData propertyStatus = new RefData();
		propertyStatus.setCode("A");
		property.setStatus(propertyStatus);

		// make sure property is unmeasured
		RefData measuredIndicator = new RefData();
		measuredIndicator.setCode("U");
		property.setMeasuredIndicator(measuredIndicator);

		List<Property> propertyList = new ArrayList<Property>();
		propertyList.add(property);

		// make sure the account is in arrears
		AccountSummaryResponse accountSummary = new TestAccountSummary();
		BigDecimal balance = new BigDecimal(10);
		accountSummary.setAccountBalance(balance);

        EligibilityStatus status = accountInDebtCheck.checkStatus(method, accountSummary, propertyList, null, null,
                null);

		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());

	}

	@Test(expected = java.lang.RuntimeException.class)
	public void testMultipleActiveSupplyTypes() {
		// set the account to be in credit
		AccountSummaryResponse accountSummary = new TestAccountSummary();
		BigDecimal balance = new BigDecimal(-1);
		accountSummary.setAccountBalance(balance);

		// make sure properties are active

		RefData propertyStatus = new RefData();
		propertyStatus.setCode("A");

		Property measuredProperty = new Property();
		// make sure property is metered
		RefData measuredIndicator = new RefData();
		measuredIndicator.setCode("M");
		measuredProperty.setMeasuredIndicator(measuredIndicator);
		measuredProperty.setStatus(propertyStatus);
		// make sure the property is unmeasured
		Property unmeasuredProperty = new Property();
		RefData unmeasuredIndicator = new RefData();
		unmeasuredIndicator.setCode("U");
		unmeasuredProperty.setMeasuredIndicator(unmeasuredIndicator);
		unmeasuredProperty.setStatus(propertyStatus);

		List<Property> propertyList = new ArrayList<Property>();
		propertyList.add(measuredProperty);
		propertyList.add(unmeasuredProperty);

		PaymentMethod method = new PaymentMethod();
		method.setPlan(true);

        EligibilityStatus status = accountInDebtCheck.checkStatus(method, accountSummary, propertyList, null, null,
                null);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());

	}

    @Test
	public void paymentMethodNotPlan() {
		AccountSummaryResponse accountSummary = new TestAccountSummary();
		BigDecimal balance = new BigDecimal(1);
		accountSummary.setAccountBalance(balance);

		// make sure property is active

		RefData propertyStatus = new RefData();
		propertyStatus.setCode("A");

		Property measuredProperty = new Property();
		// make sure property is unmeasured
		RefData measuredIndicator = new RefData();
		measuredIndicator.setCode("M");
		measuredProperty.setMeasuredIndicator(measuredIndicator);
		measuredProperty.setStatus(propertyStatus);

		Property unmeasuredProperty = new Property();
		RefData unmeasuredIndicator = new RefData();
		unmeasuredIndicator.setCode("U");
		unmeasuredProperty.setMeasuredIndicator(unmeasuredIndicator);
		unmeasuredProperty.setStatus(propertyStatus);

		List<Property> propertyList = new ArrayList<Property>();
		propertyList.add(measuredProperty);
		propertyList.add(unmeasuredProperty);

		PaymentMethod method = new PaymentMethod();
		method.setPlan(false);

        EligibilityStatus status = accountInDebtCheck.checkStatus(method, accountSummary, propertyList, null, null,
                null);

		assertNotNull(status);
		assertEquals(EligabilityStatusConstants.ELIGIBLE, status.getStatus());

	}

    @Test
    public void checkStatusUnmeasuredFutureStart() {
        AccountSummaryResponse accountSummary = new TestAccountSummary();
        accountSummary.setAccountBalance(BigDecimal.ZERO);

        // make sure property is active

        RefData propertyStatus = new RefData();
        propertyStatus.setCode("A");

        Property unmeasuredProperty = new Property();
        RefData unmeasuredIndicator = new RefData();
        unmeasuredIndicator.setCode("U");
        unmeasuredProperty.setMeasuredIndicator(unmeasuredIndicator);
        unmeasuredProperty.setStatus(propertyStatus);

        List<Property> propertyList = new ArrayList<Property>();
        propertyList.add(unmeasuredProperty);

        PaymentMethod method = new PaymentMethod();
        method.setPlan(true);

        EligibilityStatus status = accountInDebtCheck.checkStatus(method, accountSummary, propertyList, null, null,
                null);

        assertEquals(EligabilityStatusConstants.ELIGIBLE_AGENT_WARNING, status.getStatus());
        assertEquals(AccountInDebtCheck.UNMEASURED_FUTURE_START_MESSAGE, status.getText());
    }

    @Test
    public void checkStatusAccountSummaryNull() {
        expectedExeption.expect(IllegalArgumentException.class);
        expectedExeption.expectMessage("accountSummary is a required parameter");

        accountInDebtCheck.checkStatus(null, null, Collections.emptyList(), null, null, null);
    }

    @Test
    public void checkStatusPropertyListNull() {
        expectedExeption.expect(IllegalArgumentException.class);
        expectedExeption.expectMessage("propertyList is a required parameter");

        AccountSummaryResponse accountSummary = new TestAccountSummary();

        accountInDebtCheck.checkStatus(null, accountSummary, null, null, null, null);
    }

}
