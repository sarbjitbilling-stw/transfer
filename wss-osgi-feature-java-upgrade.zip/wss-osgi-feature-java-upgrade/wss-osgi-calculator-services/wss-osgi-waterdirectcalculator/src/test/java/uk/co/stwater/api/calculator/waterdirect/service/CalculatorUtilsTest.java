package uk.co.stwater.api.calculator.waterdirect.service;

import static org.junit.Assert.assertEquals;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorUtils.toDate;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Test;

public class CalculatorUtilsTest {
    @Test
    public void should_getBillingStartDate() throws Exception {
        LocalDate today = toDate("2019-07-19");
        CalculatorUtils calculatorUtils = new CalculatorUtils(today);

        LocalDate billingStartDate = calculatorUtils.getBillingStartDate();

        assertEquals("Expected correct date", billingStartDate, LocalDate.of(2019, Month.APRIL, 1));
    }

    @Test
    public void should_getBillingStartDate_when_passedPreviousYear() throws Exception {
        LocalDate today = toDate("2018-07-19");
        CalculatorUtils calculatorUtils = new CalculatorUtils(today);

        LocalDate billingStartDate = calculatorUtils.getBillingStartDate();

        assertEquals("Expected correct date", billingStartDate, LocalDate.of(2018, Month.APRIL, 1));
    }

    @Test
    public void getBillingStartDateBeforeNextBillCycle() throws Exception {
        LocalDate today = LocalDate.of(2018, 3, 11);
        CalculatorUtils calculatorUtils = new CalculatorUtils(today);

        LocalDate actual = calculatorUtils.getBillingStartDate();

        assertEquals(LocalDate.of(2017, 4, 1), actual);
    }

    @Test
    public void should_getBillingEndDate() throws Exception {
        LocalDate today = toDate("2019-07-19");
        CalculatorUtils calculatorUtils = new CalculatorUtils(today);

        LocalDate billingEndDate = calculatorUtils.getBillingEndDate();

        assertEquals("Expected correct date", billingEndDate, LocalDate.of(2020, Month.MARCH, 31));
    }

    @Test
    public void getBillingEndDateBeforeNextBillCycle() throws Exception {
        LocalDate today = LocalDate.of(2019, 3, 11);
        CalculatorUtils calculatorUtils = new CalculatorUtils(today);

        LocalDate actual = calculatorUtils.getBillingEndDate();

        assertEquals(LocalDate.of(2019, 3, 31), actual);
    }
}
