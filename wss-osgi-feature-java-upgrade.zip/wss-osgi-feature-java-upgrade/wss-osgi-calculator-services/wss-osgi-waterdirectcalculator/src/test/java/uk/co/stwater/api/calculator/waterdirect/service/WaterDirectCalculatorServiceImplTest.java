package uk.co.stwater.api.calculator.waterdirect.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorUtils.toDate;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationRequest;
import uk.co.stwater.api.calculator.waterdirect.model.ClaimType;

@RunWith(MockitoJUnitRunner.Silent.class)
public class WaterDirectCalculatorServiceImplTest {
    private static final LocalDate TEST_DATE = toDate("2019-07-22");
    private static final LocalDate START_BILLING_PERIOD = toDate("2019-04-01");
    private static final LocalDate END_BILLING_PERIOD = toDate("2020-03-30");

    private WaterDirectCalculatorService calculatorService;

    @Before
    public void setUp() throws Exception {
        class WaterDirectCalculatorServiceTest extends WaterDirectCalculatorServiceImpl {
            @Override
            protected LocalDate getToday() {
                return TEST_DATE;
            }
        }

        this.calculatorService = new WaterDirectCalculatorServiceTest();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void calculate_waterDirectUnmeasured() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setUnmeasured(true);
        request.setWaterDirect(true);
        request.setBillAmount(365.00);
        request.setDaysInBill(365);
        request.setAccountBalance(365.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 111.00, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 7.00, calculation.getCalculationValue().getWeeklyConsumption(), 0);
        assertEquals("Expected correct rate", 10.75, calculation.getCalculationValue().getDeductionRateWeekly(), 0);
        assertEquals("Expected correct rate", 21.5, calculation.getCalculationValue().getDeductionRateFortnightly(), 0);
        assertEquals("Expected correct days till qualification", 0, calculation.getCalculationValue().getDaysUntilQualification());
        assertFalse("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_waterDirectUnmeasured_should_notQualify() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setUnmeasured(true);
        request.setWaterDirect(true);
        request.setBillAmount(20.00);
        request.setDaysInBill(365);
        request.setAccountBalance(40.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 25.55, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 0.35, calculation.getCalculationValue().getWeeklyConsumption(), 0);
        assertEquals("Expected correct rate", 4.1, calculation.getCalculationValue().getDeductionRateWeekly(), 0);
        assertEquals("Expected correct rate", 8.2, calculation.getCalculationValue().getDeductionRateFortnightly(), 0);
        assertEquals("Expected correct days till qualification", 489,
                calculation.getCalculationValue().getDaysUntilQualification());
        assertTrue("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_waterDirectMeasured() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setMeasured(true);
        request.setWaterDirect(true);
        request.setBillAmount(365.00);
        request.setDaysInBill(365);
        request.setBillDate(START_BILLING_PERIOD);
        request.setNextBillDate(END_BILLING_PERIOD);
        request.setAccountBalance(365.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 477.00, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct arrears", 252.00, calculation.getCalculationValue().getChargesNotAsArrears(), 0);
        assertEquals("Expected correct rate", 7.00, calculation.getCalculationValue().getWeeklyConsumption(), 0);
        assertEquals("Expected correct rate", 10.75, calculation.getCalculationValue().getDeductionRateWeekly(), 0);
        assertEquals("Expected correct rate", 21.5, calculation.getCalculationValue().getDeductionRateFortnightly(), 0);
        assertEquals("Expected correct days till qualification", 0, calculation.getCalculationValue().getDaysUntilQualification());
        assertFalse("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_waterDirectMeasured_should_averagePreviousBill() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setMeasured(true);
        request.setWaterDirect(true);
        request.setBillAmount(365.00);
        request.setDaysInBill(365);
        request.setPreviousBillAmount(1000.00);
        request.setPreviousDaysInBill(180);
        request.setBillDate(START_BILLING_PERIOD);
        request.setNextBillDate(END_BILLING_PERIOD);
        request.setAccountBalance(365.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 645.00, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct arrears", 630.00, calculation.getCalculationValue().getChargesNotAsArrears(), 0);
        assertEquals("Expected correct rate", 17.50, calculation.getCalculationValue().getWeeklyConsumption(), 0);
        assertEquals("Expected correct rate", 21.25, calculation.getCalculationValue().getDeductionRateWeekly(), 0);
        assertEquals("Expected correct rate", 42.5, calculation.getCalculationValue().getDeductionRateFortnightly(), 0);
        assertEquals("Expected correct days till qualification", 0, calculation.getCalculationValue().getDaysUntilQualification());
        assertFalse("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_waterDirectMeasured_should_notQualify() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setMeasured(true);
        request.setWaterDirect(true);
        request.setBillAmount(20.00);
        request.setDaysInBill(365);
        request.setBillDate(START_BILLING_PERIOD);
        request.setNextBillDate(END_BILLING_PERIOD);
        request.setAccountBalance(40.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 45.60, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct arrears", 12.60, calculation.getCalculationValue().getChargesNotAsArrears(), 0);
        assertEquals("Expected correct rate", 0.35, calculation.getCalculationValue().getWeeklyConsumption(), 0);
        assertEquals("Expected correct rate", 4.1, calculation.getCalculationValue().getDeductionRateWeekly(), 0);
        assertEquals("Expected correct rate", 8.2, calculation.getCalculationValue().getDeductionRateFortnightly(), 0);
        // Slight deviation, 89
        assertEquals("Expected correct days till qualification", 88, calculation.getCalculationValue().getDaysUntilQualification());
        assertTrue("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_universalCreditUnmeasuredSingleUnder25() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setUnmeasured(true);
        request.setUniversalCredit(true);
        request.setBillAmount(365.00);
        request.setDaysInBill(365);
        request.setAccountBalance(365.00);
        request.setClaimType(ClaimType.SINGLE_UNDER_25);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 111.00, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 30.42, calculation.getCalculationValue().getMonthlyConsumption(), 0);
        assertEquals("Expected correct rate", 43.22, calculation.getCalculationValue().getDeductionRate(), 0);
        assertEquals("Expected correct days till qualification", 0, calculation.getCalculationValue().getDaysUntilQualification());
        assertFalse("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_universalCreditUnmeasuredJointOver25_should_notQualify() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setUnmeasured(true);
        request.setUniversalCredit(true);
        request.setClaimType(ClaimType.JOINT_OVER_25);
        request.setBillAmount(365.00);
        request.setDaysInBill(365);
        request.setAccountBalance(365.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 111.00, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 30.42, calculation.getCalculationValue().getMonthlyConsumption(), 0);
        assertEquals("Expected correct rate", 55.79, calculation.getCalculationValue().getDeductionRate(), 0);
        assertEquals("Expected correct days till qualification", 14,
                calculation.getCalculationValue().getDaysUntilQualification());
        assertTrue("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_universalCreditUnmeasuredSingleUnder25_should_notQualify() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setUnmeasured(true);
        request.setUniversalCredit(true);
        request.setClaimType(ClaimType.SINGLE_UNDER_25);
        request.setBillAmount(20.00);
        request.setDaysInBill(365);
        request.setAccountBalance(40.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 26.08, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 1.67, calculation.getCalculationValue().getMonthlyConsumption(), 0);
        assertEquals("Expected correct rate", 14.47, calculation.getCalculationValue().getDeductionRate(), 0);
        assertEquals("Expected correct days till qualification", 673,
                calculation.getCalculationValue().getDaysUntilQualification());
        assertTrue("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_universalCreditUnmeasuredSingleUnder25_should_notQualify_when_accountBalanceIsLow() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setUnmeasured(true);
        request.setUniversalCredit(true);
        request.setClaimType(ClaimType.SINGLE_UNDER_25);
        request.setBillAmount(20.00);
        request.setDaysInBill(365);
        request.setAccountBalance(10.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", -3.92, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 1.67, calculation.getCalculationValue().getMonthlyConsumption(), 0);
        assertEquals("Expected correct rate", 14.47, calculation.getCalculationValue().getDeductionRate(), 0);
        // Slight deviation, 1220
        assertEquals("Expected correct days till qualification", 1220,
                calculation.getCalculationValue().getDaysUntilQualification());
        assertTrue("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_universalCreditMeasured() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setMeasured(true);
        request.setUniversalCredit(true);
        request.setClaimType(ClaimType.SINGLE_UNDER_25);
        request.setBillAmount(365.00);
        request.setDaysInBill(365);
        request.setBillDate(START_BILLING_PERIOD);
        request.setNextBillDate(END_BILLING_PERIOD);
        request.setAccountBalance(365.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 477.00, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 30.42, calculation.getCalculationValue().getMonthlyConsumption(), 0);
        assertEquals("Expected correct rate", 43.22, calculation.getCalculationValue().getDeductionRate(), 0);
        assertEquals("Expected correct days till qualification", 0, calculation.getCalculationValue().getDaysUntilQualification());
        assertFalse("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void calculate_universalCreditMeasured_should_notQualify() throws Exception {
        CalculationRequest request = new CalculationRequest();

        request.setMeasured(true);
        request.setUniversalCredit(true);
        request.setClaimType(ClaimType.SINGLE_UNDER_25);
        request.setBillAmount(20.00);
        request.setDaysInBill(365);
        request.setBillDate(START_BILLING_PERIOD);
        request.setNextBillDate(END_BILLING_PERIOD);
        request.setAccountBalance(40.00);

        Calculation calculation = this.calculatorService.calculate(request);

        assertEquals("Expected correct arrears", 46.14, calculation.getCalculationValue().getArrearsAccrued(), 0);
        assertEquals("Expected correct rate", 1.67, calculation.getCalculationValue().getMonthlyConsumption(), 0);
        assertEquals("Expected correct rate", 14.47, calculation.getCalculationValue().getDeductionRate(), 0);
        assertEquals("Expected correct days till qualification", 307, calculation.getCalculationValue().getDaysUntilQualification());
        assertTrue("Expected correct qualify", calculation.getCalculationValue().getDoesNotQualify());
    }

    @Test
    public void validate_should_validate() {
        CalculationRequest request = new CalculationRequest();
        request.setDaysInBill(1);
        request.setBillAmount(1.0);

        boolean result = this.calculatorService.validate(request);

        assertTrue("Expected to validate", result);
    }

    @Test
    public void validate_should_notValidate_when_missingDaysInBill() {
        CalculationRequest request = new CalculationRequest();
        request.setBillAmount(1.0);

        boolean result = this.calculatorService.validate(request);

        assertFalse("Expected to not validate", result);
    }

    @Test
    public void validate_should_notValidate_when_missingBillAmount() {
        CalculationRequest request = new CalculationRequest();
        request.setDaysInBill(1);

        boolean result = this.calculatorService.validate(request);

        assertFalse("Expected to not validate", result);
    }

    @Test
    public void validate_should_notValidate_when_inputsAreDefaulted() {
        CalculationRequest request = new CalculationRequest();

        boolean result = this.calculatorService.validate(request);

        assertFalse("Expected to not validate", result);
    }
}
