package uk.co.stwater.api.calculator.waterdirect.service;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public abstract class AbstractUnmeasuredCalculator implements Calculator {
    protected UnmeasuredInputs inputs;
    protected Calculation calculation;
    protected LocalDate today;

    protected BigDecimal calculateAverageDailyCharge(int decimalPlaces) {
        return this.inputs.getBillAmountAsBigDecimal().divide(this.inputs.getDaysInBillAsBigDecimal(), decimalPlaces, RoundingMode.HALF_UP);
    }
}
