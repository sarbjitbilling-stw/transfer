package uk.co.stwater.api.calculator.waterdirect.service;

import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.DAYS_IN_WEEK;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.INTERMEDIATE_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.TIMES_TWO;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.TWO_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_MIN_PAYMENT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_MIN_QUALIFICATION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_PROPERTIES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WHOLE_NUMBER;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Properties;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationValue;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

public class MeasuredWaterDirectCalculatorImpl extends AbstractMeasuredCalculator {
    private final BigDecimal minQualificationAmount;
    private final BigDecimal minPayment;

    public MeasuredWaterDirectCalculatorImpl(MeasuredInputs inputs, Calculation calculation,
            LocalDate today) {
        this.inputs = inputs;
        this.calculation = calculation;
        this.today = today;

        calculation.setDaysInBill(inputs.getDaysInBill());
        calculation.setAccountBalance(inputs.getAccountBalance());
        calculation.setBillAmount(inputs.getBillAmount());
        calculation.setBillDate(inputs.getBillDate());
        calculation.setNextBillDate(inputs.getNextBillDate());
        calculation.setPreviousBillAmount(inputs.getPreviousBillAmount());
        calculation.setPreviousDaysInBill(inputs.getPreviousDaysInBill());

        try (InputStream is = MeasuredWaterDirectCalculatorImpl.class.getClassLoader().getResourceAsStream(WATERDIRECT_PROPERTIES)) {
            Properties properties = new Properties();
            properties.load(is);
            this.minQualificationAmount = new BigDecimal(properties.getProperty(WATERDIRECT_MIN_QUALIFICATION_AMOUNT));
            this.minPayment = new BigDecimal(properties.getProperty(WATERDIRECT_MIN_PAYMENT));
        } catch (IOException | NumberFormatException e) {
            throw new STWTechnicalException("Failed to load properties", e);
        }
    }

    @Override
    public void calculate() {
        BigDecimal averageDailyCharge = this.calculateAverageDailyCharge(TWO_DECIMAL_PLACES);

        long daysInNextBill = ChronoUnit.DAYS.between(this.inputs.getBillDate(), this.inputs.getNextBillDate());

        long daysTillNextBill = ChronoUnit.DAYS.between(this.today, this.inputs.getNextBillDate());

        BigDecimal nextBill = averageDailyCharge.multiply(BigDecimal.valueOf(daysInNextBill)).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal chargesRemaining = averageDailyCharge.multiply(BigDecimal.valueOf(daysTillNextBill)).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal chargesToDate = nextBill.subtract(chargesRemaining).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal totalArrearsToDate = this.inputs.getAccountBalanceAsBigDecimal().add(chargesToDate).setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP);

        CalculationValue calculationValue = new CalculationValue();

        calculationValue.setAverageDailyCharge(averageDailyCharge);

        calculationValue.setArrearsAccrued(totalArrearsToDate.doubleValue());

        BigDecimal chargesNotAsArrears = nextBill.subtract(chargesToDate);
        calculationValue.setChargesNotAsArrears(chargesNotAsArrears.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        if (totalArrearsToDate.doubleValue() < this.minQualificationAmount.doubleValue()) {
            calculationValue.setDoesNotQualify(true);
            BigDecimal daysUntilQualification = this.minQualificationAmount.subtract(totalArrearsToDate)
                    .divide(averageDailyCharge, INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
            calculationValue.setDaysUntilQualification(daysUntilQualification.setScale(WHOLE_NUMBER, RoundingMode.HALF_UP));
        }

        BigDecimal weeklyConsumption = averageDailyCharge.multiply(DAYS_IN_WEEK).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
        calculationValue.setWeeklyConsumption(weeklyConsumption.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        BigDecimal deductionRateWeekly = weeklyConsumption.add(this.minPayment).setScale(INTERMEDIATE_DECIMAL_PLACES,
                RoundingMode.HALF_UP);
        calculationValue.setDeductionRateWeekly(deductionRateWeekly.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        BigDecimal deductionRateFortnightly = deductionRateWeekly.multiply(TIMES_TWO).setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP);
        calculationValue.setDeductionRateFortnightly(deductionRateFortnightly.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        this.calculation.setCalculationValue(calculationValue);
    }
}
