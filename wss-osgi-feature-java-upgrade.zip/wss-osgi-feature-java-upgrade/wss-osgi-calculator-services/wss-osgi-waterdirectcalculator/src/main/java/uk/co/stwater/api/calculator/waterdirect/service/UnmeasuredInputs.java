package uk.co.stwater.api.calculator.waterdirect.service;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.math.BigDecimal;

public class UnmeasuredInputs {
    private final int daysInBill;
    private final double accountBalance;
    private final double billAmount;

    public UnmeasuredInputs(int daysInBill, double accountBalance, double billAmount) {
        this.daysInBill = daysInBill;
        this.accountBalance = accountBalance;
        this.billAmount = billAmount;
    }

    public int getDaysInBill() {
        return this.daysInBill;
    }

    public BigDecimal getDaysInBillAsBigDecimal() {
        return BigDecimal.valueOf(this.daysInBill);
    }

    public double getAccountBalance() {
        return this.accountBalance;
    }

    public BigDecimal getAccountBalanceAsBigDecimal() {
        return BigDecimal.valueOf(this.accountBalance);
    }

    public double getBillAmount() {
        return this.billAmount;
    }

    public BigDecimal getBillAmountAsBigDecimal() {
        return BigDecimal.valueOf(this.billAmount);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("daysInBill", this.daysInBill)
                .toString();
    }
}
