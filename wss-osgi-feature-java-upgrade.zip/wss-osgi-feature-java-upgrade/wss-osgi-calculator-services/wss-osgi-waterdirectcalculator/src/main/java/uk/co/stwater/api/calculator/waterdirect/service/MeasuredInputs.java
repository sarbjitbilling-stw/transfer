package uk.co.stwater.api.calculator.waterdirect.service;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MeasuredInputs {
    private final int daysInBill;
    private final double accountBalance;
    private final double billAmount;
    private final LocalDate billDate;
    private final LocalDate nextBillDate;
    private final double previousBillAmount;
    private final int previousDaysInBill;

    public MeasuredInputs(int daysInBill, double accountBalance, double billAmount,
            LocalDate billDate, LocalDate nextBillDate, double previousBillAmount,
            int previousDaysInBill) {
        this.daysInBill = daysInBill;
        this.accountBalance = accountBalance;
        this.billAmount = billAmount;
        this.billDate = billDate;
        this.nextBillDate = nextBillDate;
        this.previousBillAmount = previousBillAmount;
        this.previousDaysInBill = previousDaysInBill;
    }

    public int getDaysInBill() {
        return this.daysInBill;
    }

    public BigDecimal getDaysInBillAsBigDecimal() {
        return BigDecimal.valueOf(this.daysInBill);
    }

    public double getAccountBalance() {
        return this.accountBalance;
    }

    public BigDecimal getAccountBalanceAsBigDecimal() {
        return BigDecimal.valueOf(this.accountBalance);
    }

    public double getBillAmount() {
        return this.billAmount;
    }

    public BigDecimal getBillAmountAsBigDecimal() {
        return BigDecimal.valueOf(this.billAmount);
    }

    public LocalDate getBillDate() {
        return this.billDate;
    }

    public LocalDate getNextBillDate() {
        return this.nextBillDate;
    }

    public double getPreviousBillAmount() {
        return this.previousBillAmount;
    }

    public BigDecimal getPreviousBillAmountAsBigDecimal() {
        return BigDecimal.valueOf(this.previousBillAmount);
    }

    public int getPreviousDaysInBill() {
        return this.previousDaysInBill;
    }

    public BigDecimal getPreviousDaysInBillAsBigDecimal() {
        return BigDecimal.valueOf(this.previousDaysInBill);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("daysInBill", this.daysInBill)
                .toString();
    }
}
