package uk.co.stwater.api.calculator.waterdirect.service;

import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.DAYS_IN_WEEK;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.INTERMEDIATE_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.TIMES_TWO;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.TWO_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_MIN_PAYMENT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_MIN_QUALIFICATION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_PROPERTIES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WHOLE_NUMBER;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Properties;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationValue;

public class UnmeasuredWaterDirectCalculatorImpl extends AbstractUnmeasuredCalculator {
    private final CalculatorUtils calculatorUtils;
    private final BigDecimal minQualificationAmount;
    private final BigDecimal minPayment;

    public UnmeasuredWaterDirectCalculatorImpl(UnmeasuredInputs inputs, Calculation calculation,
            LocalDate today) {
        this.inputs = inputs;
        this.calculation = calculation;
        this.today = today;

        calculation.setDaysInBill(inputs.getDaysInBill());
        calculation.setAccountBalance(inputs.getAccountBalance());
        calculation.setBillAmount(inputs.getBillAmount());

        this.calculatorUtils = new CalculatorUtils(today);

        try (InputStream is = UnmeasuredWaterDirectCalculatorImpl.class.getClassLoader().getResourceAsStream(WATERDIRECT_PROPERTIES)) {
            Properties properties = new Properties();
            properties.load(is);
            this.minQualificationAmount = new BigDecimal(properties.getProperty(WATERDIRECT_MIN_QUALIFICATION_AMOUNT));
            this.minPayment = new BigDecimal(properties.getProperty(WATERDIRECT_MIN_PAYMENT));
        } catch (IOException | NumberFormatException e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public void calculate() {
        LocalDate dateOfBill = this.calculatorUtils.getBillingEndDate()
                .minusDays((long) this.inputs.getDaysInBill() - 1);

        long daysSinceBill = ChronoUnit.DAYS.between(dateOfBill, this.today);

        BigDecimal averageDailyCharge = this.calculateAverageDailyCharge(TWO_DECIMAL_PLACES);

        BigDecimal chargesToDate = BigDecimal.valueOf(daysSinceBill).multiply(averageDailyCharge);

        BigDecimal chargesRemaining = this.inputs.getBillAmountAsBigDecimal().subtract(chargesToDate);

        BigDecimal arrearsAccrued = this.inputs.getAccountBalanceAsBigDecimal().subtract(chargesRemaining).setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP);

        CalculationValue calculationValue = new CalculationValue();

        calculationValue.setAverageDailyCharge(averageDailyCharge);

        calculationValue.setArrearsAccrued(arrearsAccrued.doubleValue());

        if (arrearsAccrued.doubleValue() < this.minQualificationAmount.doubleValue()) {
            calculationValue.setDoesNotQualify(true);
            BigDecimal daysUntilQualification = this.minQualificationAmount.subtract(arrearsAccrued)
                    .divide(averageDailyCharge, INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
            calculationValue.setDaysUntilQualification(daysUntilQualification.setScale(WHOLE_NUMBER, RoundingMode.HALF_UP));
        }

        BigDecimal weeklyConsumption = averageDailyCharge.multiply(DAYS_IN_WEEK).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
        calculationValue.setWeeklyConsumption(weeklyConsumption.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        BigDecimal deductionRateWeekly = weeklyConsumption.add(this.minPayment).setScale(INTERMEDIATE_DECIMAL_PLACES,
                RoundingMode.HALF_UP);
        calculationValue.setDeductionRateWeekly(deductionRateWeekly.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        BigDecimal deductionRateFortnightly = deductionRateWeekly.multiply(TIMES_TWO).setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP);
        calculationValue.setDeductionRateFortnightly(deductionRateFortnightly.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        this.calculation.setCalculationValue(calculationValue);
    }
}
