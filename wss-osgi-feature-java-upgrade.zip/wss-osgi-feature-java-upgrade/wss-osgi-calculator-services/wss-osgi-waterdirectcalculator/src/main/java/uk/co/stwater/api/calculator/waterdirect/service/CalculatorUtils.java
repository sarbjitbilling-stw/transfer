package uk.co.stwater.api.calculator.waterdirect.service;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;

public class CalculatorUtils {
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final LocalDate today;

    public CalculatorUtils(LocalDate today) {
        this.today = today;
    }

    public LocalDate getBillingStartDate() {
        int year = isBeforeYearBillCycleStart() ? (this.today.getYear() - 1) : this.today.getYear();
        return LocalDate.of(year, Month.APRIL, 1);
    }

    public LocalDate getBillingEndDate() {
        int nextYear = isBeforeYearBillCycleStart() ? this.today.getYear() : (this.today.getYear() + 1);
        return LocalDate.of(nextYear, Month.MARCH, 31);
    }

    private boolean isBeforeYearBillCycleStart() {
        LocalDate billCycleStartDate = LocalDate.of(this.today.getYear(), Month.APRIL, 1);
        return this.today.isBefore(billCycleStartDate);
    }

    public LocalDate getNextBillingStartDate() {
        return this.getBillingEndDate().plusDays(1);
    }

    public static LocalDate toDate(String date) {
        return LocalDate.parse(date, FORMATTER);
    }
}
