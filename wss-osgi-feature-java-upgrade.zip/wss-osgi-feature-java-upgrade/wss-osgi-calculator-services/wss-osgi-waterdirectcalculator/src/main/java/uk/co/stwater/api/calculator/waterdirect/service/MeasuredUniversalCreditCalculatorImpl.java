package uk.co.stwater.api.calculator.waterdirect.service;

import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.DAYS_IN_MONTH;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.INTERMEDIATE_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.TWO_DECIMAL_PLACES;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WHOLE_NUMBER;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationValue;
import uk.co.stwater.api.calculator.waterdirect.model.ClaimType;

public class MeasuredUniversalCreditCalculatorImpl extends AbstractMeasuredCalculator {
    private final UniversalCreditUtils universalCreditUtils;

    public MeasuredUniversalCreditCalculatorImpl(MeasuredInputs inputs, ClaimType claimType,
            Calculation calculation, LocalDate today) {
        this.inputs = inputs;
        this.calculation = calculation;
        this.today = today;

        calculation.setDaysInBill(inputs.getDaysInBill());
        calculation.setAccountBalance(inputs.getAccountBalance());
        calculation.setBillAmount(inputs.getBillAmount());
        calculation.setBillDate(inputs.getBillDate());
        calculation.setNextBillDate(inputs.getNextBillDate());
        calculation.setPreviousBillAmount(inputs.getPreviousBillAmount());
        calculation.setPreviousDaysInBill(inputs.getPreviousDaysInBill());
        calculation.setClaimType(claimType);

        this.universalCreditUtils = new UniversalCreditUtils(claimType);
    }

    public void calculate() {
        BigDecimal averageDailyCharge = this.calculateAverageDailyCharge(INTERMEDIATE_DECIMAL_PLACES);

        long daysInNextBill = ChronoUnit.DAYS.between(this.inputs.getBillDate(), this.inputs.getNextBillDate());

        long daysTillNextBill = ChronoUnit.DAYS.between(this.today, this.inputs.getNextBillDate());

        BigDecimal nextBill = averageDailyCharge.multiply(BigDecimal.valueOf(daysInNextBill)).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal chargesRemaining = averageDailyCharge.multiply(BigDecimal.valueOf(daysTillNextBill)).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal chargesToDate = nextBill.subtract(chargesRemaining).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);

        BigDecimal totalArrearsToDate = this.inputs.getAccountBalanceAsBigDecimal().add(chargesToDate).setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP);

        CalculationValue calculationValue = new CalculationValue();

        calculationValue.setAverageDailyCharge(averageDailyCharge);

        calculationValue.setArrearsAccrued(totalArrearsToDate.doubleValue());

        BigDecimal monthlyConsumption = averageDailyCharge.multiply(DAYS_IN_MONTH).setScale(INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
        calculationValue.setMonthlyConsumption(monthlyConsumption.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        BigDecimal deductionRate = monthlyConsumption.add(this.universalCreditUtils.getDeductionAmount());
        calculationValue.setDeductionRate(deductionRate.setScale(TWO_DECIMAL_PLACES, RoundingMode.HALF_UP));

        if (totalArrearsToDate.doubleValue() < this.universalCreditUtils.getMinQualification().doubleValue()) {
            calculationValue.setDoesNotQualify(true);
            BigDecimal daysUntilQualification = this.universalCreditUtils.getMinQualification().subtract(totalArrearsToDate).divide(averageDailyCharge, INTERMEDIATE_DECIMAL_PLACES, RoundingMode.HALF_UP);
            calculationValue.setDaysUntilQualification(daysUntilQualification.setScale(WHOLE_NUMBER, RoundingMode.HALF_UP));
        }

        this.calculation.setCalculationValue(calculationValue);
    }
}
