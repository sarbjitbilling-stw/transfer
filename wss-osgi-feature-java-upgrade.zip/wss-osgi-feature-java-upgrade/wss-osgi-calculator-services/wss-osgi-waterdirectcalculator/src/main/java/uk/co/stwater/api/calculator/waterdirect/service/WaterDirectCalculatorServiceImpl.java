package uk.co.stwater.api.calculator.waterdirect.service;

import java.time.LocalDate;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.transaction.Transactional;

import org.ops4j.pax.cdi.api.OsgiServiceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.stwater.api.calculator.waterdirect.model.Calculation;
import uk.co.stwater.api.calculator.waterdirect.model.CalculationRequest;
import uk.co.stwater.api.core.service.BaseService;

@OsgiServiceProvider(classes = {WaterDirectCalculatorService.class})
@Named
@Transactional
@Singleton
public class WaterDirectCalculatorServiceImpl extends BaseService implements WaterDirectCalculatorService {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    public boolean validate(CalculationRequest request) {
        if ((request.getDaysInBill() == 0) ||
                (request.getBillAmount() == 0)) {
            return false;
        }

        return true;
    }

    @Override
    public Calculation calculate(CalculationRequest request) {
        this.log.info("Calculation request {}", request);

        Calculation calculation = new Calculation();

        Calculator calculator;

        if (request.isUnmeasured()) {
            UnmeasuredInputs inputs = new UnmeasuredInputs(request.getDaysInBill(),
                    request.getAccountBalance(), request.getBillAmount());

            if (request.isWaterDirect()) {
                calculator = new UnmeasuredWaterDirectCalculatorImpl(inputs, calculation,
                        getToday());
            } else if (request.isUniversalCredit()) {
                calculator = new UnmeasuredUniversalCreditCalculatorImpl(inputs,
                        request.getClaimType(), calculation, getToday());
            } else {
                throw new IllegalStateException("Invalid value for water direct/universal credit");
            }
        } else if (request.isMeasured()) {
            MeasuredInputs inputs = new MeasuredInputs(request.getDaysInBill(),
                    request.getAccountBalance(), request.getBillAmount(), request.getBillDate(),
                    request.getNextBillDate(), request.getPreviousBillAmount(), request.getPreviousDaysInBill());

            if (request.isWaterDirect()) {
                calculator = new MeasuredWaterDirectCalculatorImpl(inputs, calculation,
                        getToday());
            } else if (request.isUniversalCredit()) {
                calculator = new MeasuredUniversalCreditCalculatorImpl(inputs, request.getClaimType(),
                        calculation, getToday());
            } else {
                throw new IllegalStateException("Invalid value for water direct/universal credit");
            }
        } else {
            throw new IllegalStateException("Invalid value for unmeasured/measured");
        }

        calculator.calculate();

        this.log.info("Calculation response {}", calculator);
        return calculation;
    }

    protected LocalDate getToday() {
        return LocalDate.now();
    }
}
