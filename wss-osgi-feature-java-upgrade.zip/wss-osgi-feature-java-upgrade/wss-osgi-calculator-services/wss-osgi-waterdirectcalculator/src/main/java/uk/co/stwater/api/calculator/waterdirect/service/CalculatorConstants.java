package uk.co.stwater.api.calculator.waterdirect.service;

import java.math.BigDecimal;

public final class CalculatorConstants {
    private CalculatorConstants() {
    }

    public static final String WATERDIRECT_PROPERTIES = "waterdirect.properties";
    public static final int INTERMEDIATE_DECIMAL_PLACES = 10;
    public static final int TWO_DECIMAL_PLACES = 2;
    public static final int WHOLE_NUMBER = 0;
    public static final BigDecimal TIMES_TWO = BigDecimal.valueOf(2);
    public static final BigDecimal DAYS_IN_WEEK = BigDecimal.valueOf(7);
    public static final BigDecimal DAYS_IN_MONTH = BigDecimal.valueOf(30.416);

    public static final String WATERDIRECT_MIN_QUALIFICATION_AMOUNT = "waterdirect.min-qualification-amount";
    public static final String WATERDIRECT_MIN_PAYMENT = "waterdirect.min-payment";

    public static final String UNIVERSALCREDIT_SINGLE_UNDER25_MIN_QUALIFICATION_AMOUNT = "universalcredit.single-under25.min-qualification-amount";
    public static final String UNIVERSALCREDIT_SINGLE_OVER25_MIN_QUALIFICATION_AMOUNT = "universalcredit.single-over25.min-qualification-amount";
    public static final String UNIVERSALCREDIT_JOINT_UNDER25_MIN_QUALIFICATION_AMOUNT = "universalcredit.joint-under25.min-qualification-amount";
    public static final String UNIVERSALCREDIT_JOINT_OVER25_MIN_QUALIFICATION_AMOUNT = "universalcredit.joint-over25.min-qualification-amount";
    public static final String UNIVERSALCREDIT_SINGLE_UNDER25_DEDUCTION_AMOUNT = "universalcredit.single-under25.deduction-amount";
    public static final String UNIVERSALCREDIT_SINGLE_OVER25_DEDUCTION_AMOUNT = "universalcredit.single-over25.deduction-amount";
    public static final String UNIVERSALCREDIT_JOINT_UNDER25_DEDUCTION_AMOUNT = "universalcredit.joint-under25.deduction-amount";
    public static final String UNIVERSALCREDIT_JOINT_OVER25_DEDUCTION_AMOUNT = "universalcredit.joint-over25.deduction-amount";
}
