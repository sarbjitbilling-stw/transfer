package uk.co.stwater.api.calculator.waterdirect.service;

import uk.co.stwater.api.calculator.waterdirect.model.ClaimType;
import uk.co.stwater.api.osgi.util.STWTechnicalException;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Properties;

import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_JOINT_OVER25_DEDUCTION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_JOINT_OVER25_MIN_QUALIFICATION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_JOINT_UNDER25_DEDUCTION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_JOINT_UNDER25_MIN_QUALIFICATION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_SINGLE_OVER25_DEDUCTION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_SINGLE_OVER25_MIN_QUALIFICATION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_SINGLE_UNDER25_DEDUCTION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.UNIVERSALCREDIT_SINGLE_UNDER25_MIN_QUALIFICATION_AMOUNT;
import static uk.co.stwater.api.calculator.waterdirect.service.CalculatorConstants.WATERDIRECT_PROPERTIES;

public class UniversalCreditUtils {
    private final ClaimType claimType;

    private final BigDecimal singleUnder25MinQualificationAmount;
    private final BigDecimal singleOver25MinQualificationAmount;
    private final BigDecimal jointUnder25MinQualificationAmount;
    private final BigDecimal jointOver25MinQualificationAmount;

    private final BigDecimal singleUnder25DeductionAmount;
    private final BigDecimal singleOver25DeductionAmount;
    private final BigDecimal jointUnder25DeductionAmount;
    private final BigDecimal jointOver25DeductionAmount;

    public UniversalCreditUtils(ClaimType claimType) {
        this.claimType = claimType;

        try (InputStream is = UniversalCreditUtils.class.getClassLoader().getResourceAsStream(WATERDIRECT_PROPERTIES)) {
            Properties properties = new Properties();
            properties.load(is);

            this.singleUnder25MinQualificationAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_SINGLE_UNDER25_MIN_QUALIFICATION_AMOUNT));
            this.singleOver25MinQualificationAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_SINGLE_OVER25_MIN_QUALIFICATION_AMOUNT));
            this.jointUnder25MinQualificationAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_JOINT_UNDER25_MIN_QUALIFICATION_AMOUNT));
            this.jointOver25MinQualificationAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_JOINT_OVER25_MIN_QUALIFICATION_AMOUNT));

            this.singleUnder25DeductionAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_SINGLE_UNDER25_DEDUCTION_AMOUNT));
            this.singleOver25DeductionAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_SINGLE_OVER25_DEDUCTION_AMOUNT));
            this.jointUnder25DeductionAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_JOINT_UNDER25_DEDUCTION_AMOUNT));
            this.jointOver25DeductionAmount = new BigDecimal(properties.getProperty(UNIVERSALCREDIT_JOINT_OVER25_DEDUCTION_AMOUNT));
        } catch (IOException | NumberFormatException e) {
            throw new STWTechnicalException("Failed to load properties", e);
        }
    }

    public BigDecimal getMinQualification() {
        switch (this.claimType) {
            case SINGLE_UNDER_25:
                return this.singleUnder25MinQualificationAmount;
            case SINGLE_OVER_25:
                return this.singleOver25MinQualificationAmount;
            case JOINT_UNDER_25:
                return this.jointUnder25MinQualificationAmount;
            case JOINT_OVER_25:
                return this.jointOver25MinQualificationAmount;
            default:
                throw new STWTechnicalException("Invalid claim type " + claimType);
        }
    }

    public BigDecimal getDeductionAmount() {
        switch (this.claimType) {
            case SINGLE_UNDER_25:
                return this.singleUnder25DeductionAmount;
            case SINGLE_OVER_25:
                return this.singleOver25DeductionAmount;
            case JOINT_UNDER_25:
                return this.jointUnder25DeductionAmount;
            case JOINT_OVER_25:
                return this.jointOver25DeductionAmount;
            default:
                throw new IllegalStateException("Invalid claim type " + claimType);
        }
    }
}
