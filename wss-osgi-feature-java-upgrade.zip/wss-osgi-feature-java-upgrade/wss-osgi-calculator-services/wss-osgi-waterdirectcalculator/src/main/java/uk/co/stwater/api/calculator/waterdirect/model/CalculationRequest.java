package uk.co.stwater.api.calculator.waterdirect.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import uk.co.stwater.api.core.model.BaseModel;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.time.LocalDate;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CalculationRequest extends BaseModel<Long> {
    private static final long serialVersionUID = -7654474060371781666L;

    @XmlElement(required = true)
    private boolean isWaterDirect = false;

    @XmlElement(required = true)
    private boolean isUniversalCredit = false;

    @XmlElement(required = true)
    private boolean isMeasured = false;

    @XmlElement(required = true)
    private boolean isUnmeasured = false;

    @XmlElement
    private int daysInBill;

    @XmlElement
    private double accountBalance;

    @XmlElement
    private double billAmount;

    @XmlElement
    private LocalDate billDate;

    @XmlElement
    private LocalDate nextBillDate;

    @XmlElement
    private double previousBillAmount;

    @XmlElement
    private int previousDaysInBill;

    @XmlElement
    private ClaimType claimType;

    public boolean isWaterDirect() {
        return this.isWaterDirect;
    }

    public void setWaterDirect(boolean isWaterDirect) {
        this.isWaterDirect = isWaterDirect;
    }

    public boolean isUniversalCredit() {
        return this.isUniversalCredit;
    }

    public void setUniversalCredit(boolean universalCredit) {
        this.isUniversalCredit = universalCredit;
    }

    public boolean isMeasured() {
        return this.isMeasured;
    }

    public void setMeasured(boolean isMeasured) {
        this.isMeasured = isMeasured;
    }

    public boolean isUnmeasured() {
        return this.isUnmeasured;
    }

    public void setUnmeasured(boolean isUnmeasured) {
        this.isUnmeasured = isUnmeasured;
    }

    public int getDaysInBill() {
        return this.daysInBill;
    }

    public void setDaysInBill(int daysInBill) {
        this.daysInBill = daysInBill;
    }

    public double getAccountBalance() {
        return this.accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public double getBillAmount() {
        return this.billAmount;
    }

    public void setBillAmount(double billAmount) {
        this.billAmount = billAmount;
    }

    public LocalDate getBillDate() {
        return this.billDate;
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate = billDate;
    }

    public LocalDate getNextBillDate() {
        return this.nextBillDate;
    }

    public void setNextBillDate(LocalDate nextBillDate) {
        this.nextBillDate = nextBillDate;
    }

    public double getPreviousBillAmount() {
        return this.previousBillAmount;
    }

    public void setPreviousBillAmount(double previousBillAmount) {
        this.previousBillAmount = previousBillAmount;
    }

    public int getPreviousDaysInBill() {
        return this.previousDaysInBill;
    }

    public void setPreviousDaysInBill(int previousDaysInBill) {
        this.previousDaysInBill = previousDaysInBill;
    }

    public ClaimType getClaimType() {
        return this.claimType;
    }

    public void setClaimType(ClaimType claimType) {
        this.claimType = claimType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .toString();

    }
}
