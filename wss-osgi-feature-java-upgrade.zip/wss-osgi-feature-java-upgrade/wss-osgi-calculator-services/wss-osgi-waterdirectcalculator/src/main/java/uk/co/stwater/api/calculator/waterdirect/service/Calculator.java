package uk.co.stwater.api.calculator.waterdirect.service;

public interface Calculator {
    void calculate();
}
