/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Mark
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface Cacheable {
     public long timeout() default 10; //defualt to 10 seconds
     public TimeUnit timeUnit() default TimeUnit.SECONDS;
     public Class type() default void.class;

    /**
     * Level assigned to cache so that an environment is able to use a subset of the
     * caching using a system cache level.
     * 
     * <p>
     * This was added as CMP environments require some caching to be turned off as
     * users can also use the Target client to perform actions.
     * 
     * <p>
     * The higher the level the more likely the method will be cached. By convention
     * we are using values {@code 0-100} but there are no coded logic restrictions
     * on this. The WSS system cache level is set to {@code 0} (so all caching is
     * used) and the CMP system cache level is set to {@code 60} (so only cache
     * methods with level {@code 60} or greater are used).
     * 
     * <p>
     * By default the level is {@code 50} which will be on in WSS but off for CMP.
     */
    int level() default 50;
}
