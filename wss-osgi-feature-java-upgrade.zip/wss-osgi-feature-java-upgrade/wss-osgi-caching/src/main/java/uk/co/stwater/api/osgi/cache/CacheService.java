/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.cache;//CacheService

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.stats.CacheStats;
import java.util.List;

/**
 *
 * @author Mark
 */
public interface CacheService {
    
    static final String PID = "wss.osgi.util.cache";
    
    Cache<Integer, CacheEntry> getCacheInstance();
    
    boolean isCacheEnabled();
    
    void invalidate(List<Integer> parmaterKeyHashes);

    void invalidate(Object argValue, Class argClass, Class targetClass);
    
    void index(Integer methodHash, List<Integer> paramHashes);

    CacheStats getCacheStats();

    void invalidateAll();

}
