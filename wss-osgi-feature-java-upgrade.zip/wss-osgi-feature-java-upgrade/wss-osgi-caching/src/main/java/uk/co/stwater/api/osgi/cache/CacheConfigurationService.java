package uk.co.stwater.api.osgi.cache;

import java.util.Optional;

public interface CacheConfigurationService {
    boolean isCacheServiceEnable();
    Optional<Long> getMethodCacheDuration(String methodName);

    /**
     * Returns system cache level that is used to control what method caching is
     * used in an environment. A {@link Cacheable} method is cached if their cache
     * level is greater than or equal to this system cache value. By conventions
     * method cache level are in {@code 0-100} so a system cache level of {@code 0}
     * means all caching is going to be used.
     */
    int getSystemCacheLevel();
}
