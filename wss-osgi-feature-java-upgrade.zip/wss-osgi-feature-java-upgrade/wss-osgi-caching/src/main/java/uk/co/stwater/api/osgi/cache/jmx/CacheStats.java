/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.cache.jmx;

import javax.inject.Named;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanInfo;
import javax.management.MBeanOperationInfo;
import javax.management.NotCompliantMBeanException;
import javax.management.StandardMBean;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import uk.co.stwater.api.osgi.cache.CacheService;


/**
 *
 * @author Mark
 */
@Named
@Component(property = {"jmx.objectname=uk.co.stwater.api.osgi.util.cache:type=service,name=caching"},
           service = {CacheStatsMBean.class} )
public class CacheStats extends StandardMBean implements CacheStatsMBean{
   
    private CacheService cacheService;
    private final Object previousStatsLock = new Object();
    private com.github.benmanes.caffeine.cache.stats.CacheStats previousStats;

    @Reference
    public void setCacheSrvice(CacheService cacheService) {
        this.cacheService = cacheService;
    }
    
    public CacheStats() throws NotCompliantMBeanException {
        super(CacheStatsMBean.class);
    }

    @Override
    public String getCumulativeCacheStats() {
        com.github.benmanes.caffeine.cache.stats.CacheStats stats = cacheService.getCacheStats();
        StringBuilder sb = new StringBuilder();
        sb.append("Cumulative values = ").append(stats.toString());
        return sb.toString();
    }
    
    @Override
    public String getDeltaCacheStats() {
        com.github.benmanes.caffeine.cache.stats.CacheStats stats = cacheService.getCacheStats();
        StringBuilder sb = new StringBuilder();
        synchronized (previousStatsLock) {
            if (previousStats != null) {
                sb.append("Delta values = ").append(stats.minus(previousStats).toString());
            }
            previousStats = stats;
        }
        return sb.toString();
    }
    
    @Override
    public String getIsCacheEnabled(){
        return String.format("Cache is enabled = %1$b", cacheService.isCacheEnabled());
    }
    
    @Override
    public void invalidateAll(){
        cacheService.invalidateAll();
    }

    /*
        Return bean metadata
    */
    @Override
    protected String getDescription(MBeanInfo info) {
        return "Manage method cache";
    }

    @Override
    protected String getDescription(MBeanAttributeInfo info) {
        switch (info.getName()){
            case "CumulativeCacheStats":
                return "Show Cumulative cache stats";
            case "DeltaCacheStats":
                return "Show delte cache stats";
            case "IsCacheEnabled":
                return "Show if cache is enabled";
            default:
                return info.getDescription();
        }
    }

    @Override
    protected String getDescription(MBeanOperationInfo info) {
        switch (info.getName()){
            case "invalidateAll":
                return "Invalidate ALL cache entries";
            default:
                return info.getDescription();
        }
    }
   
}
