/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.cache;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Mark
 */
class CacheEntry {
    final private Object payload;
    final private long dob;
    final private long timeout; //held in nanoseconds

    CacheEntry(Object payload, long nsTimeout) {
        this.payload = payload;
        this.timeout = nsTimeout;
        this.dob = System.nanoTime();
    }

    Object getPayload() {
        //We need to make a shallow copy of any collection to stop 
        //possible concurrent modification exceptions 
        if(payload instanceof Collection<?>){
            if(payload instanceof List<?>){
                return new ArrayList((List)payload);
             } else if (payload instanceof Set<?>){
                 return new HashSet((Set)payload);
            }
        } else if(payload instanceof Map<?,?>){
            return new HashMap((Map)payload);
        }
        return payload;
    }

    long getDob() {
        return dob;
    }
    
    boolean isException(){
        return (payload instanceof Throwable);
    }
    
    void throwException() throws Throwable{
        throw (Throwable)payload;
    }
    
    long getTTL(long currentTime){
        return dob + timeout - currentTime;
    }
}
