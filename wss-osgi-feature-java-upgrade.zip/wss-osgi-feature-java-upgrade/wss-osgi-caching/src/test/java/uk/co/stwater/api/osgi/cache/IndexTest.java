package uk.co.stwater.api.osgi.cache;

import uk.co.stwater.api.osgi.cache.Index;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 *
 * @author Mark
 */
public class IndexTest {
    
    public IndexTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testAdd() {
        Index<Object, Object> i = new Index();
        Object key = new Object();
        i.put(key, new Object());
        i.put(key, new Object());
        assertEquals(2, i.size());
        assertEquals(2,i.get(key).size());
    }
    
    @Test
    public void testAdd2() {
        Index<Integer, Object> i = new Index();
        i.put(1, new Object());
        i.put(2, new Object());
        assertEquals(2, i.size());
        assertEquals(1,i.get(1).size());
        assertEquals(1,i.get(2).size());
    }

    @Test
    public void testContains() {
        Index<Integer, Object> i = new Index();
        i.put(1, new Object());
        i.put(2, new Object());
         
        assertFalse(i.containsKey(99));
        assertTrue(i.containsKey(1));
        assertTrue(i.containsKey(2));
    }

    @Test
    public void testGet1() {
        Index<Integer, Object> i = new Index();
        Object obj = new Object();
        i.put(1, obj);
        assertEquals(1, i.size());
        assertEquals(1, i.get(1).size());
        assertEquals(obj, i.get(1).get(0));
    }
    
    @Test
    public void testGet2() {
        Index<Integer, Object> i = new Index();
        Object obj = new Object();
        i.put(1, obj);
        i.put(1, obj);
        i.put(2, obj);
        assertEquals(3, i.size());
        assertEquals(2, i.get(1).size());
        assertEquals(1, i.get(2).size());
        assertEquals(obj, i.get(1).get(0));
        assertEquals(obj, i.get(1).get(1));
        assertEquals(obj, i.get(2).get(0));
    }
    
    @Test
    public void testGet3() {
        //testing -> public List<V> get(List<K> kList)
        Index<Integer, Object> i = new Index();
        Object obj1 = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        i.put(1, obj1);
        i.put(1, obj2);
        i.put(2, obj1);
        i.put(2, obj2);
        i.put(3, obj1);
        i.put(3, obj3);
        
        List<Object>result = i.get(Arrays.asList(1,3));
        assertEquals(4, result.size());
        assertEquals(obj1, result.get(0));
        assertEquals(obj2, result.get(1));
        assertEquals(obj1, result.get(2));
        assertEquals(obj3, result.get(3));
        
    }
    

    @Test
    public void testRemoveAllWithValue1() {
        Index<Integer, Object> i = new Index();
        Object obj1 = new Object();
        Object obj2 = new Object();
        i.put(1, obj1);
        i.put(1, obj2);
        i.put(2, obj1);
        
        i.removeAllWithValue(obj1);
        
        assertEquals(1, i.size());
        assertEquals(1, i.get(1).size());
        assertEquals(obj2, i.get(1).get(0));

    }
    
    @Test
    public void testRemoveAllWithValue2() {
        Index<Integer, Object> i = new Index();
        Object obj1 = new Object();
        Object obj2 = new Object();
        i.put(1, obj1);
        i.put(1, obj2);
        i.put(2, obj1);
        
        i.removeAllWithValue(Arrays.asList(obj1, obj2));
        
        assertEquals(0, i.size());

    }

    
}
