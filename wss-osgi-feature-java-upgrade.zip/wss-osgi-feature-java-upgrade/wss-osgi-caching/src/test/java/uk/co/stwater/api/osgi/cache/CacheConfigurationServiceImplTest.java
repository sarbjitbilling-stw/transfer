package uk.co.stwater.api.osgi.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.osgi.service.cm.ConfigurationException;

public class CacheConfigurationServiceImplTest {
    private static final String METHOD_SIGNATURE = "uk.co.stwater.targetconnector.client.api.specialconditions.ListSpecialConditionsClientImpl.getSpecialConditions(uk.co.stwater.api.osgi.model.account.TargetAccountNumber,java.lang.Long)";
    private static final String METHOD_SIGNATURE_NOT_SET = "uk.co.stwater.targetconnector.client.api.leregistration.GetLEDataForWSSClientService.getLEData(uk.co.stwater.api.osgi.model.account.TargetAccountNumber,java.lang.Long)";
    private static final String METHOD_SIGNATURE_ARGS_SPACED = "uk.co.stwater.targetconnector.client.api.personaldetails.PersonalDetailsClientService.getPersonalDetails(uk.co.stwater.api.osgi.model.account.TargetAccountNumber, java.lang.String, java.lang.String)";

    private Map<String, String> config = buildConfigMap();

    private CacheConfigurationServiceImpl cacheConfigService = new CacheConfigurationServiceImpl();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void updatedCacheEnabled() throws ConfigurationException {
        config.put(CacheConfigurationServiceImpl.CACHE_ENABLED, "true");

        cacheConfigService.updated(config);

        assertTrue(cacheConfigService.isCacheServiceEnable());
    }

    @Test
    public void updatedCacheDisabled() throws ConfigurationException {
        config.put(CacheConfigurationServiceImpl.CACHE_ENABLED, "false");

        cacheConfigService.updated(config);

        assertFalse(cacheConfigService.isCacheServiceEnable());
    }

    @Test
    public void updatedValidCacheLevel() throws ConfigurationException {
        config.put(CacheConfigurationServiceImpl.CACHE_LEVEL, "75");

        cacheConfigService.updated(config);

        assertEquals(75, cacheConfigService.getSystemCacheLevel());
    }

    @Test
    public void updatedInvalidCacheLevel() throws ConfigurationException {
        expectedException.expect(ConfigurationException.class);
        expectedException.expectMessage("System cache level should be in range 0-100 but is 130");

        config.put(CacheConfigurationServiceImpl.CACHE_LEVEL, "130");

        cacheConfigService.updated(config);
    }

    @Test
    public void updatedMethodCacheLevel() throws ConfigurationException {
        updatedMethodCacheLevelTemplate(METHOD_SIGNATURE, 15_000L);
    }

    @Test
    public void updatedMethodCacheLevelNotDefined() throws ConfigurationException {
        updatedMethodCacheLevelTemplate(METHOD_SIGNATURE_NOT_SET, null);
    }

    @Test
    public void updatedMethodCacheLevelWithSpaces() throws ConfigurationException {
        updatedMethodCacheLevelTemplate(METHOD_SIGNATURE_ARGS_SPACED, 30_000L);
    }

    private void updatedMethodCacheLevelTemplate(String methodSignature, Long expectedTimout)
            throws ConfigurationException {
        cacheConfigService.updated(config);

        Optional<Long> actual = cacheConfigService.getMethodCacheDuration(methodSignature);

        if (expectedTimout != null) {
            assertTrue(actual.isPresent());
            assertEquals(expectedTimout, actual.get());
        } else {
            assertFalse(actual.isPresent());
        }
    }

    private Map<String, String> buildConfigMap() {
        Map<String, String> config = new HashMap<>();

        config.put(CacheConfigurationServiceImpl.CACHE_ENABLED, "true");
        config.put(CacheConfigurationServiceImpl.CACHE_LEVEL, "60");
        config.put(CacheConfigurationServiceImpl.CACHE_METHOD + METHOD_SIGNATURE, "15000");
        config.put(CacheConfigurationServiceImpl.CACHE_METHOD + METHOD_SIGNATURE_ARGS_SPACED, "30000");

        return config;
    }

}
