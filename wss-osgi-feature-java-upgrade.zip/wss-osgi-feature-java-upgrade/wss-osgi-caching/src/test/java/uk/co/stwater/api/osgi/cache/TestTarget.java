/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.co.stwater.api.osgi.cache;

import uk.co.stwater.api.osgi.model.account.TargetAccountNumber;

/**
 *
 * @author Mark
 */

public class TestTarget {
    
     private CacheService cacheService;
        
    @Cacheable
    public void cacheMe1(String param){
    }
    
    @Cacheable
    public String cacheMe2(String param){
        return param;
    }
    
    @Cacheable(timeout = 20)
    public String cacheMe3(String param){
        return param;
    }
    
    @Cacheable(type = Long.class)
    public void cacheMe4(String param, Long id) {
    }
    
    @Cacheable(type = Long.class)
    public String cacheMe5(String param){
        return param;
    }
    
    @Cacheable
    public String cacheMe6(String param1, Integer param2){
        return param1;
    }
    
    @Cacheable
    public String cacheMe7(@CacheKey String param1, Integer param2){
        return param1;
    }
    
    @Cacheable
    public String cacheMe8(String param1, @CacheKey(type = String.class) Integer param2){
        return param1;
    }
    
    @Cacheable
    public String cacheMe9(@CacheKey String param1, @CacheKey Integer param2){
        return param1;
    }
    
    @Cacheable(type = Long.class)
    public void cacheMe10(String param){
    }
    
    @Cacheable
    public String cacheMeParamOrderMatters(String param1, String param2) {
        return String.format("%s-%s", param1, param2);
    }

    @InvalidateCache()
    public void invalidateMe0(String param){
    }
    
    @InvalidateCache(type=Long.class)
    public void invalidateMe1(@CacheKey(type = Long.class)  String param){
    }
    
    @InvalidateCache(type=String.class)
    public void invalidateMe2(@CacheKey String param, String test){
    }
    
    @InvalidateCache
    public String invalidateMe3(@CacheKey String param, @CacheKey String test){
         return param;
    }
    
    @InvalidateCache
    public String invalidateMe4(@CacheKey String param, @Dummy  @CacheKey(type = Integer.class) String test){
         return param;
    }
    
    @InvalidateCache
    public String invalidateMe5(@Dummy String param){
         return param;
    }
    
    @InvalidateCache
    public String paymentTest(@CacheKey TargetAccountNumber tan){
        return null;
    }
}
