package uk.co.stwater.api.osgi.cache;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.annotation.IncompleteAnnotationException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoJUnitRunner;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Ticker;

/**
 *
 * @author Mark
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class CachingAspectTest {
    
    //Define expected hash values for target types
    private static final int RTN_LONG = 398795216;
    private static final int RTN_STRING = 1195259493;

    //Define expected hash values for paramaters i.e. PARAM_(method return type)_(paramater type)_(argument value)
    private static final int PARAM_LONG_STRING_ARG1 = 1597057232; 
    private static final int PARAM_LONG_LONG_ARG1 = 800592955; 
    private static final int PARAM_STRING_STRING_ARG1 = -1901445787;
    private static final int PARAM_STRING_STRING_ARG2 = -1901445786;
    private static final int PARAM_STRING_STRING_INT_1 = -1904448309;
    private static final int PARAM_STRING_INTEGER_INT_1 = -861557808;
    private static final int PARAM_STRING_INTEGER_ARG2 = -858555285;
           
    //Define expected hash values for method signatures 
    //i.e. MTH_(method return type)_(paramater 1 type)_(argument 1 value)[_(paramater n type)_(argument n value)]
    private static final int MTH_STRING_STRING_ARG1 = -1926472714;
    private static final int MTH_LONG_STRING_ARG1 = 1572030305;
    private static final int MTH_LONG_STRING_ARG2 = 1662106927;
    private static final int MTH_STRING_STRING_ARG1_INTEGER_INT_1 = -1836396093;
    
    @Mock
    private BundleContext bundleContext;
  
    @Mock
    private JoinPoint joinPoint;
    
    @Mock
    private ProceedingJoinPoint proceedingJoinPoint;
    
    @Mock
    private MethodSignature methodSignature;
    
    @Mock
    private Cache<Integer, CacheEntry> mockCache;
    
    @Mock
    private CacheConfigurationService generalConfigurationService;
    
    static private Cache<Integer, CacheEntry> realCache;
  
    static class MockTicker implements Ticker{
        long ticks = 0;

        @Override
        public long read() {
            return ticks;
        }
        
        public void advance(long time, TimeUnit timeUnit){
            ticks += timeUnit.toNanos(time);
        }
    }
    
    @InjectMocks
    private CachingAspect testAspect;
    
    static MockTicker ticker = new MockTicker();
        
    @BeforeClass
    public static void setUpClass() {
        realCache = Caffeine.newBuilder()
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .executor(Runnable::run)
            .ticker(ticker::read)
            .maximumSize(10_000)
            .build();
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        realCache.invalidateAll();
        setUpBundleContext(realCache);
    }
    
    @After
    public void tearDown() {
    }
    
    @Rule
    public ExpectedException expectedException = ExpectedException.none(); 

    @Test
    public void testTimeoutDirectly() {
        CacheEntry testEntry = new CacheEntry(new Object(), TimeUnit.MINUTES.toNanos(10));
        Integer key = 1;
        realCache.put(key, testEntry);
        ticker.advance(9, TimeUnit.MINUTES);
        assertThat(realCache.getIfPresent(key), is(testEntry));
        ticker.advance(2, TimeUnit.MINUTES);
        assertThat(realCache.getIfPresent(key), is(nullValue()));
    }
    
    @Captor
    private ArgumentCaptor<Iterable<Integer>> keyCaptor ; 
    
    @Test 
    public void testAddToCache_no_target_type() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations as this is a void method
          and no type is given in the Cacheable annotation a IncompleteAnnotationException
          shoudld be thrown
        
          @Cacheable
          public void cacheMe1(String name) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe1", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        expectedException.expect(IncompleteAnnotationException.class);
        expectedException.expectMessage(Cacheable.class.getName()+" missing element "+"type");
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
    }
    
    @Test 
    public void cacheMethodThrowsException() throws NoSuchMethodException, Throwable {
        Method testMethod = TestTarget.class.getMethod("cacheMe2", String.class);
        Exception mockException = new Exception("sample exception message");

        expectedException.expect(Exception.class);
        expectedException.expectMessage("sample exception message");

        setMocks(testMethod, new Object[] { "arg1" });
        when(proceedingJoinPoint.proceed()).thenThrow(mockException);

        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
    }

    @Test
    public void testAddToCache_method_target_type_with_default_timeout() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that the targetType 
          is the method return type and time out is the default value.
        
          @Cacheable
          public String cacheMe2(String param) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe2", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertTrue(realCache.asMap().containsKey(MTH_STRING_STRING_ARG1));
        
        verify(cacheService).index(MTH_STRING_STRING_ARG1, Arrays.asList(PARAM_STRING_STRING_ARG1));
        
        CacheEntry entry = realCache.<Integer,CacheEntry>asMap().get(MTH_STRING_STRING_ARG1);
        assertThat(TimeUnit.SECONDS.toNanos(10), is( entry.getTTL(entry.getDob()) ));
    }
        
    @Test 
    public void testAddToCache_method_target_type_with_annotated_timeout() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that the targetType 
          is the method return type and time out is the annotated value.
        
          @Cacheable(timeout = 20)
          public String cacheMe3(String param) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe3", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertTrue(realCache.asMap().containsKey(MTH_STRING_STRING_ARG1));

        verify(cacheService).index(MTH_STRING_STRING_ARG1, Arrays.asList(PARAM_STRING_STRING_ARG1));

        CacheEntry entry = realCache.<Integer,CacheEntry>asMap().get(MTH_STRING_STRING_ARG1);
        assertThat(TimeUnit.SECONDS.toNanos(20), is( entry.getTTL(entry.getDob()) ));
    }
    
    
    //Note the following two tests MUST retuen the same hashes
    @Test 
    public void testAddToCache_annotated_target_type_with_config_timeout() throws NoSuchMethodException, Throwable{
        /*
         * Testing with the following method and annotations to test that the targetType
         * is the method return type and time out is the value from the config service.
         * 
         * @Cacheable(type = Long.class) public void cacheMe4(String param, Long id)
         */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe4", String.class, Long.class);
        setMocks(testMethod, new Object[] { "arg1", 2L });
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertTrue(realCache.asMap().containsKey(MTH_LONG_STRING_ARG2));
        verify(cacheService).index(MTH_LONG_STRING_ARG2, Arrays.asList(PARAM_LONG_STRING_ARG1, 797590434));
        
        CacheEntry entry = realCache.asMap().get(MTH_LONG_STRING_ARG2);
        assertThat(TimeUnit.SECONDS.toNanos(30), is( entry.getTTL(entry.getDob()) ));
    }
    
    @Test 
    public void testAddToCache_annotated_target_type_overides_return_type() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that the targetType 
          is the method return type has been overidden by the anotated type.
        
          @Cacheable(type = Long.class)
          public String cacheMe5(String param) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe5", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertTrue(realCache.asMap().containsKey(MTH_LONG_STRING_ARG1));
        verify(cacheService).index(MTH_LONG_STRING_ARG1, Arrays.asList(PARAM_LONG_STRING_ARG1));
    }
    
   
    
    @Test 
    public void testAddToCache_mutilpe_params() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that two param index
          values are added for this entry
        
          @Cacheable
          public String cacheMe6(String param1, Integer param2) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe6", String.class, Integer.class);
        setMocks(testMethod, new Object[]{"arg1", 1} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        
        assertThat(1, is(realCache.asMap().size()));
        assertTrue(realCache.asMap().containsKey(MTH_STRING_STRING_ARG1_INTEGER_INT_1));
        verify(cacheService).index(MTH_STRING_STRING_ARG1_INTEGER_INT_1, Arrays.asList(PARAM_STRING_STRING_ARG1, PARAM_STRING_INTEGER_INT_1));
    }
    
    @Test 
    public void testAddToCache_mutilpe_params_anotation_overide() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that two param index but
          CacheKey is used on only one param so only ONE param index value is added
        
           @Cacheable
           public String cacheMe7(@CacheKey String param1, Integer param2) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe7", String.class, Integer.class);
        setMocks(testMethod, new Object[]{"arg1", 1} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        verify(cacheService).index(MTH_STRING_STRING_ARG1_INTEGER_INT_1, Arrays.asList(PARAM_STRING_STRING_ARG1));
    }
    
    @Test 
    public void testAddToCache_mutilpe_params_anotation_overide_with_type() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that two params but
          CacheKey is used on only one param and that has a type overide so only ONE param index value 
          for the anotated type
        
          @Cacheable
          public String cacheMe8(String param1, @CacheKey(type = String.class) Integer param2) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe8", String.class, Integer.class);
        setMocks(testMethod, new Object[]{"arg1", 1} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertThat(1, is(realCache.asMap().size()));
        verify(cacheService).index(MTH_STRING_STRING_ARG1_INTEGER_INT_1, Arrays.asList(PARAM_STRING_STRING_INT_1));
    }
        
    @Test 
    public void testAddToCache_mutilpe_params_anotation_all_overide() throws NoSuchMethodException, Throwable{
        /*Testing with the following method and annotations to test that two params and
          CacheKey is used on both (one has a type overide) so two param index value should be added
          for the anotated type
        
          @Cacheable
          public String cacheMe9(@CacheKey String param1, @CacheKey(type = String.class) Integer param2) */
        
        Method testMethod = TestTarget.class.getMethod("cacheMe9", String.class, Integer.class);
        setMocks(testMethod, new Object[]{"arg1", 1} );
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertThat(1, is(realCache.asMap().size()));
        assertTrue(realCache.asMap().containsKey(MTH_STRING_STRING_ARG1_INTEGER_INT_1));
        verify(cacheService).index(MTH_STRING_STRING_ARG1_INTEGER_INT_1, Arrays.asList(PARAM_STRING_STRING_ARG1, PARAM_STRING_INTEGER_INT_1));
    }
       
    @Test  
    public void testCacheEviction() throws NoSuchMethodException, Throwable{
        /*
         @InvalidateCache
         public String invalidateMe4(@CacheKey String param, @Dummy  @CacheKey(type = Integer.class) String test){
        */
        
        // use Mock Cache for this test
        setUpBundleContext(mockCache);
        
        Method testMethod = TestTarget.class.getMethod("invalidateMe4", String.class, String.class);
        setMocks(testMethod, new Object[]{"arg1", "arg2"} );
        
        testAspect.beforeInvalidateCache(joinPoint, testMethod.getAnnotation(InvalidateCache.class));

        //Check that the correct invalidation request was made
        verify(cacheService).invalidate(Arrays.asList(PARAM_STRING_STRING_ARG1, PARAM_STRING_INTEGER_ARG2));
    }
       
    @Test
    public void testGetTargetType_voidMethod_with_no_type_given() throws NoSuchMethodException{
        Method testMethod = TestTarget.class.getMethod("invalidateMe0", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        expectedException.expect(IncompleteAnnotationException.class);
        expectedException.expectMessage(InvalidateCache.class.getName()+" missing element "+"type");
        
        testAspect.getTargetType(joinPoint, testMethod.getAnnotation(InvalidateCache.class));
    }
    
    @Test
    public void testGetTargetType_non_voidMethod() throws NoSuchMethodException{
        /*
            @InvalidateCache
            public String invalidateMe5(@Dummy String param)
        */
        Method testMethod = TestTarget.class.getMethod("invalidateMe5", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        Class<?> clazz = testAspect.getTargetType(joinPoint, testMethod.getAnnotation(InvalidateCache.class));
        
        assertThat(clazz.getTypeName(), is(String.class.getName()));
        assertThat(clazz.getTypeName().hashCode(), is(RTN_STRING));
    }
    
    @Test
    public void testGetTargetType_non_voidMethod_type_given() throws NoSuchMethodException{
        /*
            @InvalidateCache(type=Long.class)
            public void invalidateMe1(@CacheKey(type = Long.class)  String param)
        */
        Method testMethod = TestTarget.class.getMethod("invalidateMe1", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        Class<?> clazz = testAspect.getTargetType(joinPoint, testMethod.getAnnotation(InvalidateCache.class));
        
        assertThat(clazz.getTypeName(), is(Long.class.getName()));
        assertThat(clazz.getTypeName().hashCode(), is(RTN_LONG));
    }
  
    
    @Test
    public void testGetParmaterKeyHashes_1_Params_0_Anotated_Params() throws NoSuchMethodException{
        
        /*Testing with the following method and annotation
          @InvalidateCache()
          public void invalidateMe0(String param) */
        
        Method testMethod = TestTarget.class.getMethod("invalidateMe0", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_LONG);
                
        assertThat(1, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_LONG_STRING_ARG1));
    }
    
    @Test
    public void testGetParmaterKeyHashes_1_Params_1_Anotated_Params_Supply_Type() throws NoSuchMethodException{
        
        /*Testing with the following method and annotations
          @InvalidateCache(type=Long.class)
          public void invalidateMe1(@CacheKey(type = Long.class)  String param) */
      
        Method testMethod = TestTarget.class.getMethod("invalidateMe1", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
                
        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_LONG);
                
        assertThat(1, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_LONG_LONG_ARG1));
        
    }
    
    @Test
    public void testGetParmaterKeyHashes_2_Params_1_Anotated_Params() throws NoSuchMethodException{
                
        /*
           @InvalidateCache(type=String.class)
           public void invalidateMe2(@CacheKey String param, String test)
        */
        
        Method testMethod = TestTarget.class.getMethod("invalidateMe2", String.class, String.class);
        setMocks(testMethod, new Object[]{"arg1", "arg2"} );

        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_LONG);
                
        assertThat(1, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_LONG_STRING_ARG1));
    }
    
    @Test
    public void testGetParmaterKeyHashes_2_Params_2_Anotated_Params() throws NoSuchMethodException{
               
        /*
            @InvalidateCache
            public String invalidateMe3(@CacheKey String param, @CacheKey String test)
        */
        
        Method testMethod = TestTarget.class.getMethod("invalidateMe3", String.class, String.class);
        setMocks(testMethod, new Object[]{"arg1", "arg2"} );
        
        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_STRING);
                
        assertThat(2, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_STRING_STRING_ARG1));        
        assertTrue(hashList.contains(PARAM_STRING_STRING_ARG2));
    }
    

    
    @Test
    public void testGetParmaterKeyHashes_2_Params_2_Anotated_Params_Supply_Type() throws NoSuchMethodException{
        
        /*
            @InvalidateCache
            public String invalidateMe4(@CacheKey String param, @Dummy  @CacheKey(type = Integer.class) String test)
        */
                
        Method testMethod = TestTarget.class.getMethod("invalidateMe4", String.class, String.class);
        setMocks(testMethod, new Object[]{"arg1", "arg2"} );

        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_STRING);
                
        assertThat(2, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_STRING_STRING_ARG1));
        assertTrue(hashList.contains(PARAM_STRING_INTEGER_ARG2));
    }
    
    @Test
    public void testGetParmaterKeyHashes_1_Param_1_Other_Anotated_Param() throws NoSuchMethodException{
              
        /*
            @InvalidateCache
            public String invalidateMe5(@Dummy String param)
        */
        
        Method testMethod = TestTarget.class.getMethod("invalidateMe5", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_LONG);
                
        assertThat(1, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_LONG_STRING_ARG1));
    }
    
    @Test
    public void test_CacheDisabledInConfig() throws NoSuchMethodException, Throwable{
        /*
            @Cacheable(type = Long.class)
            public void cacheMe10(String param)
        */
        Method testMethod = TestTarget.class.getMethod("cacheMe10", String.class);
        setMocks(testMethod, new Object[]{"arg1"} );
        
        when(generalConfigurationService.isCacheServiceEnable()).thenReturn(Boolean.FALSE);
        
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        
        assertFalse(realCache.asMap().containsKey(MTH_LONG_STRING_ARG1));
        verify(cacheService, never()).index(any(Integer.class), anyList());
    }
    
    @Test
    public void test_CacheDisabled_SystemCacheLevelHigherThanMethodCacheLevel()
            throws NoSuchMethodException, Throwable {
        Method testMethod = TestTarget.class.getMethod("cacheMe10", String.class);
        setMocks(testMethod, new Object[] { "arg1" });

        when(generalConfigurationService.getSystemCacheLevel()).thenReturn(101);

        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));

        assertFalse(realCache.asMap().containsKey(MTH_LONG_STRING_ARG1));
        verify(cacheService, never()).index(any(Integer.class), anyList());
    }

    @Test
    public void test_CacheEnabled_SystemCacheLevelEqualMethodCacheLevel() throws NoSuchMethodException, Throwable {
        Method testMethod = TestTarget.class.getMethod("cacheMe10", String.class);
        setMocks(testMethod, new Object[] { "arg1" });

        when(generalConfigurationService.getSystemCacheLevel()).thenReturn(50);

        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));

        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_LONG);

        assertThat(1, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_LONG_STRING_ARG1));
    }

    @Test
    public void test_CacheEnabled_SystemCacheLevelLessThanMethodCacheLevel() throws NoSuchMethodException, Throwable {
        Method testMethod = TestTarget.class.getMethod("cacheMe10", String.class);
        setMocks(testMethod, new Object[] { "arg1" });

        when(generalConfigurationService.getSystemCacheLevel()).thenReturn(0);

        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));

        List<Integer> hashList = testAspect.getParameterKeyHashes(joinPoint, RTN_LONG);

        assertThat(1, is(hashList.size()));
        assertTrue(hashList.contains(PARAM_LONG_STRING_ARG1));
    }

    @Test
    public void cacheParameterOrderMatters() throws NoSuchMethodException, Throwable {
        Method testMethod = TestTarget.class.getMethod("cacheMeParamOrderMatters", String.class, String.class);

        setMocks(testMethod, new Object[] { "arg1", "arg2" });
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));

        setMocks(testMethod, new Object[] { "arg2", "arg1" });
        testAspect.aroundCacheable(proceedingJoinPoint, testMethod.getAnnotation(Cacheable.class));
        assertEquals(2, realCache.asMap().size());
    }

    private void setMocks(Method testMethod, Object[] args){
        when(methodSignature.getMethod()).thenReturn(testMethod);
        when(methodSignature.getReturnType()).thenReturn(testMethod.getReturnType());
        when(methodSignature.toLongString()).thenReturn(testMethod.toGenericString());
        when(methodSignature.getDeclaringTypeName()).thenReturn(testMethod.getDeclaringClass().getTypeName());
        when(methodSignature.getName()).thenReturn(testMethod.getName());
        when(methodSignature.getParameterTypes()).thenReturn(testMethod.getParameterTypes());
        when(joinPoint.getArgs()).thenReturn(args);
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(proceedingJoinPoint.getArgs()).thenReturn(args);
        when(proceedingJoinPoint.getSignature()).thenReturn(methodSignature);
    }
    
    @Mock
    private CacheService cacheService;
    
    private void setUpBundleContext(Cache<Integer, CacheEntry> cache){

        ServiceReference serviceReference1 = mock(ServiceReference.class);
        ServiceReference serviceReference2 = mock(ServiceReference.class);

        when(cacheService.getCacheInstance()).thenReturn(cache);
        doNothing().when(cacheService).index(any(Integer.class), anyList());
        doNothing().when(cacheService).invalidate(anyList());

        when(generalConfigurationService.getMethodCacheDuration(anyString())).thenReturn(Optional.empty());
        when(generalConfigurationService
                .getMethodCacheDuration(
                        "uk.co.stwater.api.osgi.cache.TestTarget.cacheMe4(java.lang.String,java.lang.Long)"))
                .thenReturn(Optional.of(TimeUnit.SECONDS.toMillis(30)));
        
        when(generalConfigurationService.isCacheServiceEnable()).thenReturn(Boolean.TRUE);
        when(generalConfigurationService.getSystemCacheLevel()).thenReturn(0);

        when(bundleContext.getServiceReference(CacheService.class.getName())).thenReturn(serviceReference1);
        when(bundleContext.getService(serviceReference1)).thenReturn(cacheService);
         
        when(bundleContext.getServiceReference(CacheConfigurationService.class.getName())).thenReturn(serviceReference2);
        when(bundleContext.getService(serviceReference2)).thenReturn(generalConfigurationService);
    }
    
}
