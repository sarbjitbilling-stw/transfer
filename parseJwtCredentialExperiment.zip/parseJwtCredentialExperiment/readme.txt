- parse a jwt into components manually.

- parse a jwt into components using google lib.

- verify credential using google lib.
