package sb;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.json.webtoken.JsonWebSignature;
import org.junit.Test;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class MainTest {
    @Test
    public void should_parseGwt() throws Exception {
        final String jwtToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ4NmYxNjQ4MjAwNWEyY2RhZjI2ZDkyMTQwMThkMDI5Y2E0NmZiNTYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2NTMzMDEzMTksImF1ZCI6IjE1NzA0MjY5NzY4OS10NzljZjg5dHZzOTA0Nmxhbm45Z2lzYnVnYzFhYWtoNC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjExMDUzMjI3NjU1NzI2OTcyMTIxNSIsImVtYWlsIjoic2FyYmppdC5iaWxsaW5nQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxNTcwNDI2OTc2ODktdDc5Y2Y4OXR2czkwNDZsYW5uOWdpc2J1Z2MxYWFraDQuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiU2FyYmppdCBCaWxsaW5nIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FBVFhBSnlIdmtyTTlzbU1aZE5yMTY0RkZ3enM1dG1RQ0I0S3dfa2pycFVrPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IlNhcmJqaXQiLCJmYW1pbHlfbmFtZSI6IkJpbGxpbmciLCJpYXQiOjE2NTMzMDE2MTksImV4cCI6MTY1MzMwNTIxOSwianRpIjoiNzUxMTE0Yzg5Y2IwMTk0NjgxN2Q2ZWU0MjFkOTlkNzdjNjU3MTU3YiJ9.OumUEB4Sq28P9KeyxtnebJarZNosxF71M63gBgpZN9zZ76LL34ZgM5iMRLS_9I6V3QP7r3M7JH8plT8PJ9DqvcdY9zaaA454ao_fGT75retvg440Xm6pV982PlnpIKJ3vxOsZ-gp5R2wbATQP1lrjUxuBAxYlBwwUSnipzIVIn-UzwqbUbhx4EICoyjRSCpdMCmwUxJYTQ_8KxkWg1AEaxzzXAUx5j3tR-jUyLdCd0AYeaOJT24xSXEQ7JXONcohBCsQJOPceGO_22VmDzSGrDmw6kwEHzBBlVRpQu6uLVnHbOPVX48_XT6eLdTmeKoYjEC5udNq78QOkLJStXSPOQ";
        final String userDataAsBase64 = jwtToken.split("\\.")[1];
        final byte[] userDataAsBytes = Base64.getDecoder().decode(userDataAsBase64);
        final String userData = new String(userDataAsBytes);
        Map<String, String> userDataAsMap = new ObjectMapper().readValue(userData, HashMap.class);

        final String userId = userDataAsMap.get("sub");
        System.out.println("### userId is " + userId);
        final String email = userDataAsMap.get("email");
        System.out.println("### email is " + email);
    }

    @Test
    public void should_parseGwtUsingLibrary() throws Exception {
        final String jwToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ4NmYxNjQ4MjAwNWEyY2RhZjI2ZDkyMTQwMThkMDI5Y2E0NmZiNTYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2NTMzMDEzMTksImF1ZCI6IjE1NzA0MjY5NzY4OS10NzljZjg5dHZzOTA0Nmxhbm45Z2lzYnVnYzFhYWtoNC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjExMDUzMjI3NjU1NzI2OTcyMTIxNSIsImVtYWlsIjoic2FyYmppdC5iaWxsaW5nQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxNTcwNDI2OTc2ODktdDc5Y2Y4OXR2czkwNDZsYW5uOWdpc2J1Z2MxYWFraDQuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiU2FyYmppdCBCaWxsaW5nIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FBVFhBSnlIdmtyTTlzbU1aZE5yMTY0RkZ3enM1dG1RQ0I0S3dfa2pycFVrPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IlNhcmJqaXQiLCJmYW1pbHlfbmFtZSI6IkJpbGxpbmciLCJpYXQiOjE2NTMzMDE2MTksImV4cCI6MTY1MzMwNTIxOSwianRpIjoiNzUxMTE0Yzg5Y2IwMTk0NjgxN2Q2ZWU0MjFkOTlkNzdjNjU3MTU3YiJ9.OumUEB4Sq28P9KeyxtnebJarZNosxF71M63gBgpZN9zZ76LL34ZgM5iMRLS_9I6V3QP7r3M7JH8plT8PJ9DqvcdY9zaaA454ao_fGT75retvg440Xm6pV982PlnpIKJ3vxOsZ-gp5R2wbATQP1lrjUxuBAxYlBwwUSnipzIVIn-UzwqbUbhx4EICoyjRSCpdMCmwUxJYTQ_8KxkWg1AEaxzzXAUx5j3tR-jUyLdCd0AYeaOJT24xSXEQ7JXONcohBCsQJOPceGO_22VmDzSGrDmw6kwEHzBBlVRpQu6uLVnHbOPVX48_XT6eLdTmeKoYjEC5udNq78QOkLJStXSPOQ";
        JsonFactory jsonFactory = new GsonFactory();
        JsonWebSignature jsonWebSignature =
                JsonWebSignature.parser(jsonFactory).setPayloadClass(GoogleIdToken.Payload.class).parse(jwToken);
        System.out.println("### jsonWebSignature subject is " + jsonWebSignature.getPayload().getSubject());
        System.out.println("### jsonWebSignature email is " + jsonWebSignature.getPayload().get("email"));
    }

    @Test
    public void should_parseCredentialUsingLibrary() throws Exception {
        String credential = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ4NmYxNjQ4MjAwNWEyY2RhZjI2ZDkyMTQwMThkMDI5Y2E0NmZiNTYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2NTM0MDUwNjgsImF1ZCI6IjE1NzA0MjY5NzY4OS10NzljZjg5dHZzOTA0Nmxhbm45Z2lzYnVnYzFhYWtoNC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjExMDUzMjI3NjU1NzI2OTcyMTIxNSIsImVtYWlsIjoic2FyYmppdC5iaWxsaW5nQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxNTcwNDI2OTc2ODktdDc5Y2Y4OXR2czkwNDZsYW5uOWdpc2J1Z2MxYWFraDQuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiU2FyYmppdCBCaWxsaW5nIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FBVFhBSnlIdmtyTTlzbU1aZE5yMTY0RkZ3enM1dG1RQ0I0S3dfa2pycFVrPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IlNhcmJqaXQiLCJmYW1pbHlfbmFtZSI6IkJpbGxpbmciLCJpYXQiOjE2NTM0MDUzNjgsImV4cCI6MTY1MzQwODk2OCwianRpIjoiNDQ3OGI5ZTExYWQ2YTVhZWRkMDk2NGE2ZDJhNzgyYTJkYTFmMzY1MiJ9.TabQW2SMN90JjlLXpF3YHrpDH4j9Nc67zmYvS_-9e3g5x1i20RvpBC5uphhjgrScp6MdMLHzwwxPyepVVsSIxp18GCrkU4aCN-sBY7w7-PLLP3YOmr3FbemqNK23I7MXXcCCxlDaUNlCYwDbKwbWZ2-Fj9WfYW2lF8rKCQXwYJ8iG5p4f4HOmisAvaAnRZnrNIQT3-etaieLOQu2lT9Y0R33ZYygciJ4rxgTYkZM0f0dyNr583EtlP8fUB68y5NaLixVTOA7KAbUSSaq12TuL9PdG-nvoM8CoCDZ9Ia4RYKsAamW_PmWoh_lJf7fqP3mfqa8VPh4elKRy3yDYyHL2w";

        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = new GsonFactory();
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier(transport, jsonFactory);
        GoogleIdToken idToken = null;
        try {
            idToken = verifier.verify(credential);
        } catch (GeneralSecurityException | IOException e) {
            System.out.println("### e is " + e);
        }

        System.out.println("### idToken is " + idToken);

        GoogleIdToken.Payload payload = idToken.getPayload();

        System.out.println("### payload.getEmail() is " + payload.getEmail());
        System.out.println("### payload.getSubject()) is " + payload.getSubject());
    }
}
